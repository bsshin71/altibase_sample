. .tdb.real

TBSQL="tbsql -s $DB_CONN"

wait4tbload()
{
    while(true)
    do
        CNT=`ps -ef|grep -v grep | grep -c "tbsql"`
        if [ $CNT -ge 16 ]; then
            sleep 1;
        else
            break;
        fi
    done
}

for I in ${IO_TABLES[@]} ${IE_TABLES[@]}
do
        FILE=$I

        wait4tbload 
        $E $TBSQL @$S_DIR/${FILE}.sql |tee -a work.out &
done

cp $D_DIR//*.ctl $C_DIR/ 2>/dev/null
wait
