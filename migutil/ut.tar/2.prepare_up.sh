. .list

for I in ${IO_TABLES[@]}
do
    TABLE=$I
    echo $TABLE
vim -e $C_DIR/$I.ctl <<EOF
#:%g/CHARACTERSET/d
#a
#CHARACTERSET EUCKR
#.
#:%g/TRAILING/d
#a
#TRAILING NULLCOLS
#.
:%g/LOGFILE/d
:%g/BADFILE/d
:%g/^\<TRUNCATE\>/d
:%g/^\<APPEND\>/d
:%g/^\<TRAILING\>/d
:/(
i
TRAILING NULLCOLS
.
:/INFILE
a
LOGFILE 'logs/${TABLE}_up.log'
BADFILE 'logs/${TABLE}.bad'
TRUNCATE
.
:wq!
EOF
done
