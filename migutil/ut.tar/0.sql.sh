. .tdb.real

rm -f $S_DIR//*.sql

mkcols()
{
tbsql -s $DB_CONN <<EOF |egrep -v ">"
set echo off;
set sqlprompt "";
set heading off;
set TERMOUT off;
set pages 0;
set feedback off;
set timing off;

SELECT DECODE(ROWNUM, 1, ' ',',')|| COL_NM 
FROM (
SELECT  A.TIB_COL_NM COL_NM
FROM SYS.LCK_POC_TIBERO_DIFF A
WHERE 1=1
AND   TIB_TAB_NM is not NULL
AND   TIB_TAB_NM = '$TABLE'
AND   DIFF_FG != '4'
ORDER BY TO_NUMBER(POC_COL_SEQ)
) X
;

quit;
EOF
}

mksql()
{
    #COLS=`mkcols`
    COLS="*"
    echo "set echo off;"
    echo "set heading off;"
    echo "set TERMOUT off;"
    echo "set pages 0;"
    echo "set feedback off;"
    echo "set timing off;"
    echo "spool $L_DIR/$TABLE.log" 
    echo ""

    echo "select 'BEGIN: '||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') from dual;"
    echo ""
    echo "export query '$D_DIR/$TABLE.dat' FIELDS ENCLOSED BY '' TERMINATED BY '^col|^' LINES TERMINATED BY 'Rr_r\\n'" 
    echo "select " 
    echo "$COLS " 
    echo "FROM   ${OWNER}.${TABLE};" 
    echo "select 'END: '||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') from dual;"
    echo "quit;" 
}

for I in ${IO_TABLES[@]/#/US_IOWN_} ${IE_TABLES[@]/#/US_IEAIOWN_}
do
    OWNER=`echo $I |cut -d_ -f1,2`
    TABLE=`echo $I |cut -d_ -f3-`
    S_FILE=$S_DIR/$TABLE.sql

    mksql > $S_FILE
done

