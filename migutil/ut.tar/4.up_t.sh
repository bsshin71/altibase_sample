. .tdb.dev

TL="tbloader "

Download()
{
    C_FILE=$C_DIR/$TABLE.ctl
    #$E $IL userid=$DB_CONN control=$C_FILE rows=100000 errors=100000 direct=y &
    RET=`echo ${IE_TABLES[@]} | grep -c "\<$TABLE\>" `
    if [ $RET -eq 0 ]; then
        OWNER=$IOWN_USER
        PWD=$IOWN_PWD
    else
        OWNER=$IEAI_USER
        PWD=$IEAI_PWD
    fi
    DB_CONN=$DB_USER/$DB_PWD@$DB_SERVER
    S_OPT="bindsize=1048576"
    $E $TL userid=$DB_CONN control=$C_FILE $S_OPT rows=100000 errors=100000 direct=y disable_idx=y &
}

loop()
{
if [ $TABLE != "X" ];then
    echo $TABLE
    Download
fi
}

wait4tbloader()
{
    while(true)
    do
        CNT=`ps -ef|grep -v grep | grep -c tbloader`
        if [ $CNT -ge 32 ]; then
            sleep 1;
        else
            break;
        fi
    done
}

## main

rm -f up.out

#for I in `ls $C_DIR//*.ctl`
for I in ${IO_TABLES[@]}
do
    #TABLE=`basename $I '.ctl'`
    TABLE=$I
    
    wait4tbloader
    loop
done #1>>up.out 2>>up.out

wait
