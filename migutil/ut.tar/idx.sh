. .tdb.dev

loop()
{
tbsql -s $DB_CONN <<EOF |grep -v "SYS>" | grep -v "US_IOWN>"
set sqlprompt "";
set heading off;
set echo off;
set TERMOUT off;
set pages 0;
set feedback off;
set timing off;

SELECT distinct  'alter index '||index_name||' rebuild parallel 16 ;' 
       --,'alter index '||index_name||' logging;'
FROM all_indexes
WHERE owner = 'US_IOWN'
and   table_name = '$TABLE'
and   status = 'UNUSABLE'
;

quit;
EOF
}

wait4tbsql()
{
    while(true)
    do
        CNT=`ps -ef|grep -v grep | grep -c tbsql`
        if [ $CNT -ge 8 ]; then
            sleep 1;
        else
            break;
        fi
    done
}

mksql()
{
for I in `ls $C_DIR//*.ctl`
do
    TABLE=`basename $I '.ctl'`
    FILE=index/$TABLE.sql
    echo "spool index/$TABLE.out;" >$FILE
    echo "ALTER SESSION ENABLE PARALLEL DDL;" >> $FILE
    loop >>$FILE
    echo "quit;" >> $FILE
done
}


mkindex()
{
#for I in `ls $I_DIR//*.sql`
for I in ${IO_TABLES[@]}
do
    #TABLE=`basename $I '.sql'`
    TABLE=$I
    S_FILE=$I_DIR/${I}.sql
    RET=`echo ${US_IEAIOWN_TABLES[@]} | grep -c "\<$TABLE\>" `
    if [ $RET -eq 0 ]; then
        OWNER=us_iown
        PWD="dlfwkfldhvms#123"
    else
        OWNER=us_ieaiown
        PWD="dlfwkfldkswjd#123"
    fi
    $E tbsql $DB_CONN @${S_FILE} &
    wait4tbsql
done
}

date >> idx.t

### make index script
mksql

### run crete index
mkindex
wait
date >> idx.t
