. .tdb.dev

loop()
{
#for J in ${IO_TABLES[@]}
for J in `ls logs//*_up.log`
do
    T=`basename $J '_up.log'`
    D_FILE=logs/${T}.log
    U_FILE=logs/${T}_up.log

    NAME=$T
    if [ ! -f $D_FILE ]; then
        printf "%-30s|%'10d|%'10d|%'10d\n" "$NAME" -1 -1 -1
        continue
    fi
    if [ ! -f $U_FILE ]; then
        printf "%-30s|%'10d|%'10d|%'10d\n" "$NAME" -1 -1 -1
        continue
    fi
    U_LIST=`grep " Rows were " $U_FILE |awk '{printf("%d\n", $1 );}' `
    d_cnt=`grep " exported\." $D_FILE |awk '{printf("%d\n", $1 );}' `

    u_cnt=( $(echo $U_LIST) ) # upload
    if [ "x$d_cnt" = "x" -o ${#u_cnt[@]} -eq 0 ]; then
        printf "%-30s|%'10d|%'10d|%'10d\n" "$NAME" 1 -1 -1
        continue
    fi
    m_cnt=$(( ${d_cnt[0]} - ${u_cnt[0]} )) # minus

    printf "%-30s|%'10d|%'10d|%'10d\n" "$NAME" ${d_cnt[0]} ${u_cnt[1]} $m_cnt
 
done
}

echo "����|NAME|Download|Upload|Diff"
echo "---|---|---:|---:|---:|"

loop | sort -t"|" -k6 |awk '{printf("%03d|%s\n", NR,$0);}' 

