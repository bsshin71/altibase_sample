#!/usr/bin/bash 2>/dev/null

. .list

FLAG=$1

time_diff()
{
    d1=$1; d2=$2;
    t1=`echo $d1 |cut -d"-" -f2-`
    t2=`echo $d2 |cut -d"-" -f2-`
 
    if [ "x$t2" = "x" ]; then
        t2=$t1
    fi
    t1h=`echo $t1|cut -c1-2`
    t2h=`echo $t2|cut -c1-2`

    t1mm=`echo $t1|cut -c4-5`
    t2mm=`echo $t2|cut -c4-5`

    t1ss=`echo $t1|cut -c7-8`
    t2ss=`echo $t2|cut -c7-8`

    if [ $t2h -lt $t1h ]; then
        t2h=`expr $t2h + 24`;
    fi
    hour=`expr $t2h - $t1h`
    th=$((  $hour * 60 * 60      ))
    min=`expr $t2mm - $t1mm`
    tmm=$(( min * 60 ))
    tss=`expr $t2ss - $t1ss`

    elapsed=$(( th + tmm + tss ))
    sec=$(( elapsed % 60 ))
    hour=$(( ( elapsed - sec ) / 3600 ))
    min=$(( ( elapsed - ( hour * 3600) ) / 60 ))

    if [ $t2h -ge 24 ]; then
        t2h=`expr $t2h - 24`;
    fi
    #printf "%02d:%02d:%02d ~ %02d:%02d:%02d" $t1h $t1mm $t1ss $t2h $t2mm $t2ss;
    printf "%s ~ %s" $d1 $d2
    printf " (%02d:%02d:%02d)" $hour $min $sec 
}


body()
{

for I in ${IO_TABLES[@]}
do
    
    L_FILE=$L_DIR/${I}.log
    CNT=`grep " exported" $L_FILE |awk '{printf(" %d", $1);}' `
    stime=`grep "BEGIN: " $L_FILE |awk '{printf("%02d-%s\n", substr($2,9), $3);}'|sort |tail -1 `
    etime=`grep "END:"   $L_FILE |awk '{printf("%02d-%s\n", substr($2,9), $3);}'|sort |tail -1 `

    stime=${stime="01-00:00:00"}
    etime=${etime="01-00:00:00"}

    DIFF=`time_diff $stime $etime 2>/dev/null`

    NAME=`basename $I '.log'`

    printf "%-20s|%'10d|%s\n" $NAME $CNT "$DIFF"
 
done
XDIFF=`time_diff $S_TIME $E_TIME 2>/dev/null`
export XDIFF=$XDIFF
}

LIST=`body 2>/dev/null |sort -t"|" -k3 |awk '{printf("%3d|%s\n", NR,$0);}'`

#-------------------
# display total 
#-------------------
S_TIME=`echo "$LIST"|tr -d ' ' | awk -F[\|\~\(] '$4!=""{print $4}' |sort    |head -1`
E_TIME=`echo "$LIST"|tr -d ' ' | awk -F[\|\~\(] '      {print $5}' |sort -r |head -1`
#S_TIME=19:30:00

XDIFF=`time_diff $S_TIME $E_TIME 2>/dev/null`

echo "����|NAME|�Ǽ�|�ҿ�ð�"
echo "---|---|---:|---"

echo "$LIST" |sed 's/[0-9][0-9]-//g' 
echo
echo ">"
echo "TOTAL TIME : $XDIFF" |sed 's/[0-9][0-9]-//g'
echo

echo 

