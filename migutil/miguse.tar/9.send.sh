S_DIR=data
T_DIR=data_end
wait4scp()
{
    while(true)
    do
        CNT=`ps -ef|grep -v grep | grep "gzip" |grep -c ssh`
        if [ $CNT -ge 8 ]; then
            sleep 1;
        else
            break;
        fi
    done
}

#for I in `ls $S_DIR//*.dat`
for I in `cat s.txt`
do
    echo $I
    NAME=`basename $I`
    wait4scp
    gzip -c data/$I.dat | ssh tb1 "(cd /work/data; gzip -dc > $NAME.ing; mv $NAME.ing $NAME.dat )" & 
done

wait
