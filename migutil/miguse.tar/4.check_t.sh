. .tdb.real

loop()
{
for J in ${AP_TABLES[@]} ${CM_TABLES[@]}
#for J in `ls logs//*_up.log`
do
    I=logs/${J}_up.log
    L_FILE=$I
    #NAME=`basename $I '_up.log'`

    #L_FILE=$J
    NAME=`basename $J '_up.log'`
    if [ ! -f $L_FILE ]; then
        printf "%-20s|%'10d|%'10d|%'10d|%'10d|%s\n" $NAME 0 0 0 0 ""
        continue
    fi
    LIST=`grep " Rows were " $L_FILE |awk '{printf(" %d", $1);}' `

    DIFF=`grep -i "Elapsed time was" $L_FILE |awk '{print $NF}'`
    echo $LIST |while :
        read tcnt scnt ecnt
    do
        tcnt=${tcnt:=0}
        scnt=${scnt:=0}
        ecnt=${ecnt:=0}

        printf "%-20s|%'10d|%'10d|%'10d|%'10d|%s\n" $NAME $tcnt $scnt $ecnt $ecnt "$DIFF"
    done
 
done
}

echo "����|NAME|�ѰǼ�|�����Ǽ�|�����Ǽ�|�����Ǽ�|�ҿ�ð�|"
echo "---|---|---:|---:|---:|---:|---|"

loop | sort -t"|" -k6 |awk '{printf("%03d|%s\n", NR,$0);}' 

echo
sh elap.sh
echo
