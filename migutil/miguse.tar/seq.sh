awk '{
    print "drop sequence " $2 ";" ;
}' seq.txt
