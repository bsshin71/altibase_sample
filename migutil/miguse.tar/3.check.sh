#!/usr/bin/bash 2>/dev/null

. .list

FLAG=$1

time_diff()
{
    t1=$1; t2=$2;
    if [ "x$t2" = "x" ]; then
        t2=$t1
    fi
    t1h=`echo $t1|cut -c1-2`
    t2h=`echo $t2|cut -c1-2`

    t1mm=`echo $t1|cut -c4-5`
    t2mm=`echo $t2|cut -c4-5`

    t1ss=`echo $t1|cut -c7-8`
    t2ss=`echo $t2|cut -c7-8`

    if [ $t2h -lt $t1h ]; then
        t2h=`expr $t2h + 24`;
    fi
    hour=`expr $t2h - $t1h`
    th=$((  $hour * 60 * 60      ))
    min=`expr $t2mm - $t1mm`
    tmm=$(( min * 60 ))
    tss=`expr $t2ss - $t1ss`

    elapsed=$(( th + tmm + tss ))
    sec=$(( elapsed % 60 ))
    hour=$(( ( elapsed - sec ) / 3600 ))
    min=$(( ( elapsed - ( hour * 3600) ) / 60 ))

    printf "%s:%s:%s ~ %s:%s:%s" $t1h $t1mm $t1ss $t2h $t2mm $t2ss;
    printf " (%02d:%02d:%02d)" $hour $min $sec 
}


loop()
{
for I in ${AP_TABLES[@]} ${CM_TABLES[@]} ${CM_TABLES_20180130[@]} ${MT_TABLES[@]}
do
    
    if [ "$FLAG" = "up" ]; then
        L_FILE=logs/${I}_up.log
    else
        L_FILE=logs/${I}.log
    fi
    #L_FILE=logs/${I}_up.log
    LIST=`grep "Row Count" $L_FILE |awk '{printf(" %d", $NF);}' `
    stime=`grep "Start Time" $L_FILE |awk '{print $7;}' `
    etime=`grep "End Time" $L_FILE |awk '{printf $7;}' `

    stime=${stime="00:00:00"}
    etime=${etime="00:00:00"}

    DIFF=`time_diff $stime $etime 2>/dev/null`

    NAME=`basename $I '.log'`
    echo $LIST |while :
        read tcnt scnt ecnt
    do
        tcnt=${tcnt:=0}
        scnt=${scnt:=0}
        ecnt=${ecnt:=0}

        printf "%-20s|%'10d|%'10d|%'10d|%'10d|%s\n" $NAME $tcnt $scnt $ecnt $ecnt "$DIFF"
    done
 
done
XDIFF=`time_diff $S_TIME $E_TIME 2>/dev/null`
export XDIFF=$XDIFF
}

echo "����|NAME|�ѰǼ�|�����Ǽ�|�����Ǽ�|�����Ǽ�|�ҿ�ð�|"
echo "---|---|---:|---:|---:|---:|---|"

#-------------------
# display table body
# --- print all
#-------------------
    LIST=`loop 2>/dev/null | sort -t"|" -k2 |awk '{printf("%03d|%s\n", NR,$0);}'`

#-------------------
# display total 
#-------------------
S_TIME=`echo "$LIST"| grep "~"|awk -F[\~\("|"] '{print $7}' |sort  |head -1`
E_TIME=`echo "$LIST"| grep "~"|awk -F[\~\("|"] '{print $8}' |sort  |tail -1`

XDIFF=`time_diff $S_TIME $E_TIME 2>/dev/null`


echo "$LIST" 
echo
echo "----------------------------------------------------------------------------------------"
echo "TOTAL TIME : $XDIFF"
echo "----------------------------------------------------------------------------------------"
echo

echo 

