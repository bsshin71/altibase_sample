. .adb.poc

F_DIR=form
D_DIR=data
L_DIR=logs
OWNER=US_APLYOWN

Scp()
{
    DATE=`date "+%Y%m%d"`
    #HOUR=`date "+%H"`
    #HOUR=$(( HOUR - 1 ))
    #$E scp poc:/dbdata_backup2/DB_HOUR_$DATE/$HOUR/DAT/$U_TABLE.DAT data/$TABLE.dat &
    DATE=`date -d "yesterday 13:00" '+%Y%m%d'`
    $E scp poc:/dbdata_backup/DB_DAY_$DATE/DAT/$U_TABLE.DAT data/$TABLE.dat &
}

loop()
{
if [ $TABLE != "X" ];then
    Scp
fi
}

wait4iloader()
{
    while(true)
    do
        CNT=`ps -ef|grep -v grep | grep -c scp`
        if [ $CNT -ge 8 ]; then
            sleep 1;
        else
            break;
        fi
    done
}

## main

#for I in ${AP_TABLES[@]}
#for I in ${CM_TABLES[@]/#/US_COMMOWN_}
for I in ${AP_TABLES[@]/#/US_APLYOWN_} ${CM_TABLES[@]/#/US_COMMOWN_}
do
    #TABLE=`basename $I '.fmt'`
    U_TABLE=$I
    TABLE=${I:${#OWNER}+1}
    #echo $U_TABLE $TABLE
    
    wait4iloader
    loop
done

