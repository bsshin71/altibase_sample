. .tdb.real

F_META=table.meta

getMeta()
{
tbsql -s sys/rmsqhreks#123@DBPJSS1 <<EOF |grep -v "SYS>"
set sqlprompt "";
set heading off;
set echo off;
set TERMOUT off;
set pages 0;
set feedback off;
set timing off;

SELECT  DISTINCT 
        CASE WHEN A.POC_TAB_NM = A.TIB_TAB_NM THEN
            A.POC_TAB_NM ||','
        ELSE
            A.POC_TAB_NM ||','|| A.TIB_TAB_NM
        END
FROM SYS.LCK_POC_TIBERO_DIFF A
WHERE 1=1
AND   TIB_TAB_NM is not NULL
AND   DIFF_FG != '4'
;

quit;
EOF
}

loop()
{
for J in `ls logs//*_up.log`
do
    TABLE=`basename $J '_up.log'`

    T_FILE=$J
    A_FILE=logs/$TABLE.log

    NAME=`grep "${TABLE}," $F_META `
    if [ ! -f $T_FILE ]; then
        printf "%-30s|%'10d|%'10d|%'10d\n" "$NAME" -1 -1 -1
        continue
    fi
    T_LIST=`grep " Rows were " $T_FILE |awk '{printf("%d\n", $1 );}' `
    A_LIST=`grep " Row Count"  $A_FILE |awk '{printf("%d\n", $NF);}' `

    t_cnt=( $(echo $T_LIST) )
    a_cnt=( $(echo $A_LIST) )
    d_cnt=$(( ${a_cnt[0]} - ${t_cnt[1]} ))

    printf "%-30s|%'10d|%'10d|%'10d\n" "$NAME" ${a_cnt[0]} ${t_cnt[1]} $d_cnt
 
done
}

rm -f $F_META
getMeta > $F_META

echo "����|NAME|Download|Upload|Diff"
echo "---|---|---:|---:|---:|"

loop | sort -t"|" -k6 |awk '{printf("%03d|%s\n", NR,$0);}' 

