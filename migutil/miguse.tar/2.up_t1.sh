. .tdb.real

#E=echo
F_DIR=ctl
D_DIR=data
L_DIR=logs
OWNER=US_IOWN
IL="tbloader "

MODE="parallel=8"
Download()
{
    F_FILE=ctl/$TABLE.ctl
    #$E $IL userid=$DB_CONN control=$F_FILE rows=100000 errors=100000 direct=y &
    RET=`echo ${US_IEAIOWN_TABLES[@]} | grep -c "\<$TABLE\>" `
    if [ $RET -eq 0 ]; then
        OWNER=us_iown
    else
        OWNER=us_ieaiown
    fi
    DB_CONN=$OWNER/$OWNER@$DB_SERVER
    S_OPT="bindsize=1048576"
    $E $IL userid=$DB_CONN control=$F_FILE $S_OPT rows=100000 errors=100000 direct=y disable_idx=y &
}

loop()
{
if [ $TABLE != "X" ];then
    echo $TABLE
    Download
fi
}

wait4tbloader()
{
    while(true)
    do
        CNT=`ps -ef|grep -v grep | grep -c tbloader`
        if [ $CNT -ge 32 ]; then
            sleep 1;
        else
            break;
        fi
    done
}

## main

for I in `ls ctl//*.ctl`
do
    TABLE=`basename $I '.ctl'`
    
    wait4tbloader
    loop
done

