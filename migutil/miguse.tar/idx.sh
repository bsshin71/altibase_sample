. .adb.poc

loop()
{
tbsql -s sys/rmsqhreks#123@DBPJSS1 <<EOF |grep -v "SYS>"
set sqlprompt "";
set heading off;
set echo off;
set TERMOUT off;
set pages 0;
set feedback off;
set timing off;

SELECT distinct  'alter index '||index_name||' rebuild parallel 16 ;' 
       ,'alter index '||index_name||' logging;'
FROM all_indexes
WHERE owner = 'US_IOWN'
and   table_name = '$TABLE'
;

quit;
EOF
}

wait4tbsql()
{
    while(true)
    do
        CNT=`ps -ef|grep -v grep | grep -c tbsql`
        if [ $CNT -ge 8 ]; then
            sleep 1;
        else
            break;
        fi
    done
}

date >> idx.t
#for I in `ls form//*.ctl`
#do
#    TABLE=`basename $I '.ctl'`
#    FILE=index/$TABLE.sql
#    echo "spool index/$TABLE.out;" >$FILE
#    loop >>$FILE
#    echo "quit;" >> $FILE
#done


for I in `ls index//*.sql`
do
    TABLE=`basename $I '.sql'`
    RET=`echo ${US_IEAIOWN_TABLES[@]} | grep -c "\<$TABLE\>" `
    if [ $RET -eq 0 ]; then
        OWNER=us_iown
        PWD="dlfwkfldhvms#123"
    else
        OWNER=us_ieaiown
        PWD="dlfwkfldkswjd#123"
    fi
    $E tbsql $OWNER/$PWD@DBPJSS1 @${I} &
    wait4tbsql
done

wait
date >> idx.t
