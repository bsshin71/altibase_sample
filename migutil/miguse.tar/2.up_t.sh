. .tdb.real

F_DIR=form
D_DIR=data
L_DIR=logs
OWNER=US_IOWN
IL="tbloader "

MODE="parallel=8"
Download()
{
    F_FILE=form/$TABLE.ctl
    #$E $IL userid=$DB_CONN control=$F_FILE rows=100000 errors=100000 direct=y &
    RET=`echo ${US_IEAIOWN_TABLES[@]} | grep -c "\<$TABLE\>" `
    if [ $RET -eq 0 ]; then
        OWNER=us_iown
        PWD="dlfwkfldhvms#123"
    else
        OWNER=us_ieaiown
        PWD="dlfwkfldkswjd#123"
    fi
    DB_CONN=$OWNER/$DB_PWD@$DB_SERVER
    S_OPT="bindsize=1048576"
    $E $IL userid=$DB_CONN control=$F_FILE $S_OPT rows=100000 errors=100000 direct=y disable_idx=y &
}

loop()
{
if [ $TABLE != "X" ];then
    echo $TABLE
    Download
fi
}

wait4tbloader()
{
    while(true)
    do
        CNT=`ps -ef|grep -v grep | grep -c tbloader`
        if [ $CNT -ge 32 ]; then
            sleep 1;
        else
            break;
        fi
    done
}

## main

rm -f up.out

for I in `ls form//*.ctl`
do
    TABLE=`basename $I '.ctl'`
    #TABLE=$I
    
    wait4tbloader
    loop
done 1>>up.out 2>>up.out

wait
