. .adb.poc

F_DIR=form
D_DIR=data
L_DIR=logs
IL="iloader $DB_CONN"

getFormout()
{
    FORM=${F_DIR}/${TABLE}.fmt
    $E $IL -silent formout -T ${OWNER}.$TABLE -f $FORM &
}

loop()
{
if [ $TABLE != "X" ];then
    echo $TABLE
    getFormout
    #Download
fi
}

wait4iloader()
{
    #sleep 1;
    while(true)
    do
        CNT=`ps -ef|grep -v grep | grep -c iloader`
        if [ $CNT -ge 16 ]; then
            sleep 1;
        else
            break;
        fi
    done
}


## main

mkdir -p $F_DIR
mkdir -p $D_DIR
mkdir -p $L_DIR
#mv form form_$DATE
#mkdir form

OWNER=US_APLYOWN

for TABLE in ${AP_TABLES[@]} 
do
    TABLE=${TABLE:="X"}

    wait4iloader
    loop
done

OWNER=US_COMMOWN
DB_USER=$OWNER
DB_PWD=$OWNER
DB_CONN="-s $DB_SERVER -u $DB_USER -p $DB_PWD -port $DB_PORT"
IL="iloader $DB_CONN"

for TABLE in ${CM_TABLES[@]} 
do
    TABLE=${TABLE:="X"}

    wait4iloader
    loop
done

#OWNER=US_MTCOWN
#for TABLE in ${MT_TABLES[@]}
#do
#    TABLE=${TABLE:="X"}
#
#    wait4iloader
#    loop
#done

wait

vim -e form/KAA046MT.fmt <<EOF
:g/\<JS_JIKJONG_FG\>/d
:wq!
EOF

vim -e form/ZAA201MT.fmt <<EOF
:g/\<BOSU_CHONGAK_FAX_DDD\>/d
:g/\<BOSU_CHONGAK_FAX_TEL1\>/d
:g/\<BOSU_CHONGAK_FAX_TEL2\>/d
:wq!
EOF

vim -e form/ZAA301MT.fmt <<EOF
:g/\<JAEJIK_FG\>/d
:g/\<USER_JIKWI_CD\>/d
:wq!
EOF

vim -e form/ZAA456MT.fmt <<EOF
:g/\<BOHEOM_FG\>/d
:g/\<BOSANG_FG\>/d
:g/\<DAMDANGJA_ID\>/d
:g/\<GSJ_NM\>/d
:g/\<GY_FG\>/d
:g/\<HOSPITAL_CD\>/d
:g/\<HOSPITAL_RGNO\>/d
:g/\<HOSPITAL_SAEOPJA_DRNO\>/d
:g/\<JAEHAEJA_NM\>/d
:g/\<JAEHAEJA_RGNO\>/d
:g/\<JEOPSU_DT\>/d
:g/\<RGNO\>/d
:g/\<SAEOPGAESI_NO\>/d
:g/\<SAEOPJANG_NM\>/d
:g/\<SJ_FG\>/d
:g/\<TONGJI_DAESANG_FG_CD\>/d
:g/\<WONBU_NO\>/d
:g/\<YEOLRAM_ILSI\>/d
:$
a
DOWNLOAD CONDITION "WHERE MINWON_DOC_CD like '6%'"
HINT "INDEX(ZAA456MT IX_ZAA456MT_NI02)"
.
:wq

EOF

