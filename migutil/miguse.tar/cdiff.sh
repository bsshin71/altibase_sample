#RecordCount.out
R_FILE=d.txt
#0c.cnt.sh
C_FILE=c.txt

awk -F"|" 'gsub(/ |,/, "", $0) {print $2,$3}' $C_FILE |while :
    read t c 
do 
    X=`grep "\<$t\>" $R_FILE |cut -d"|" -f3`  
    if [ $c -ne $X ]; then 
        echo $t,$c,$X 
    fi 
done
