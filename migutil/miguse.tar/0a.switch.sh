F_DIR=form
C_DIR=ctl
D_DIR=data

loop()
{
tbsql -s sys/rmsqhreks#123@DBPJSS1 <<EOF |grep -v "SYS>"
set sqlprompt "";
set heading off;
set echo off;
set TERMOUT off;
set pages 0;
set feedback off;
set timing off;

SELECT  DISTINCT A.POC_TAB_NM ||' '|| A.TIB_TAB_NM 
FROM SYS.LCK_POC_TIBERO_DIFF A
WHERE 1=1
AND   TIB_TAB_NM IS NOT NULL
AND   POC_TAB_NM != TIB_TAB_NM
AND   DIFF_FG != '4'
;

quit;
EOF
}

#E=echo

loop | while :
    read aT tT
do
    if [  -f $F_DIR/$aT.ctl ];then
        $E mv $F_DIR/$aT.ctl $F_DIR/$tT.ctl
        $E sed -i "s/\<$aT\>/$tT/" $F_DIR/$tT.ctl
        $E sed -i "s/\<$aT\>_up/${tT}_up/" $F_DIR/$tT.ctl
    fi
    if [  -f $D_DIR/$aT.dat ];then
        $E mv $D_DIR/$aT.dat $D_DIR/$tT.dat
    fi
done 
