. .tdb.real

F_DIR=form
L_DIR=logs
D_DIR=data

loop()
{
tbsql -s sys/rmsqhreks#123@DBPJSS1 <<EOF |grep -v "SYS>"
set sqlprompt "";
set heading off;
set echo off;
set TERMOUT off;
set pages 0;
set feedback off;
set timing off;

SELECT DECODE(ROWNUM, 1, ' ',',')|| COL_NM ||
       DECODE(DATA_TYPE, 'DATE', ' DATE "YYYY/MM/DD HH24:MI:SS"', '')
FROM (
SELECT  A.TIB_COL_NM COL_NM, A.POC_DATA_TYPE DATA_TYPE
FROM SYS.LCK_POC_TIBERO_DIFF A
WHERE 1=1
AND   TIB_TAB_NM is not NULL
AND   POC_TAB_NM = '$TABLE'
AND   DIFF_FG != '4'
ORDER BY TO_NUMBER(POC_COL_SEQ)
) X
;

quit;
EOF
}

rm -f form//*.ctl

#for I in `ls form//*.fmt`
for I in ${AP_TABLES[@]} ${CM_TABLES[@]}
do
    TABLE=`basename $I '.fmt'`
    #TABLE=$I
    F_FILE=$F_DIR/$TABLE.ctl

    vim -e template.ctl <<EOF
:%s/#TABLE#/$TABLE/g
:wq! $F_FILE
EOF

    echo $TABLE
    loop >> $F_FILE
    echo ")" >> $F_FILE
done

sh -x 0a.switch.sh
