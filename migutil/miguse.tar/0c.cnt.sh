. .list

OUTFILE=RecordCount.out
rm -rf $OUTFILE

AP_TABLES_CNT=${#AP_TABLES[@]}
CM_TABLES_CNT=${#CM_TABLES[@]}
EAI_TABLES_CNT=${#US_IEAIOWN_TABLES[@]}
TOTAL_TABLES_CNT=$(( AP_TABLES_CNT + CM_TABLES_CNT + MT_TABLES_CNT ))

display()
{

echo "#####################################"
echo "# FULL OJBECT COUNT                  "
echo "#####################################"
#echo
echo "AP_TABLES_CNT=$AP_TABLES_CNT"
echo "CM_TABLES_CNT=$CM_TABLES_CNT"
echo "MT_TABLES_CNT=$MT_TABLES_CNT"
echo "TOTAL_TABLES_CNT=$TOTAL_TABLES_CNT"
echo
}

ValidIndex()
{
    LIST="$1"
    for I in $LIST
    do
        RET=`grep "$I" last/${OWNER}_CRT_INDEX.sql |grep -v "^\-\-"`
        RET=${RET:="x"}
        if [ "$RET" = "x" ]; then
            echo $I
        fi
    done
}

RecordCount()
{
    LIST="$*"
    for I in $LIST
    do
isp -silent <<EOF |grep "|" 
connect $OWNER/$OWNER;
set heading off;
SELECT CNT ||'|'||
       (SELECT COUNT(*) FROM $I) 
FROM
(
SELECT '${I}|'||
       ROUND((B.DISK_PAGE_CNT*8*1024)/1024/1024/1024, 2) CNT 
  FROM SYSTEM_.SYS_TABLES_ A,
       V\$DISKTBL_INFO B,
       SYSTEM_.SYS_USERS_ C
 WHERE A.TABLE_OID = B.TABLE_OID
   AND A.USER_ID = C.USER_ID
   AND '${OWNER}' = C.USER_NAME
   AND C.USER_ID <> 1
   AND TABLE_TYPE = 'T'
   AND TABLE_NAME = '$I'
UNION ALL
select '${I}|'||
       round((c.fixed_alloc_mem + c.var_alloc_mem)/1024/1024/1024, 2)  CNT
    from system_.sys_users_ a,
                system_.sys_tables_ b,
       v\$memtbl_info c,
       v\$tablespaces d
    where a.user_name <> 'SYSTEM_'
  and b.table_type = 'T'
  AND '${OWNER}' = A.USER_NAME
  and a.user_id = b.user_id
  and b.table_oid = c.table_oid
  and b.tbs_id = d.id
  AND TABLE_NAME = '$I'
) X
;
EOF
    done |tee -a $OUTFILE
}

display |tee -a $OUTFILE

echo "#------------------------------------"
echo "# Table have no Indexs               "
echo "#------------------------------------"

OWNER=US_APLYOWN
#ValidIndex ${AP_TABLES[@]}
OWNER=US_COMMOWN
#ValidIndex ${CM_TABLES[@]}
echo

echo "#------------------------------------"
echo "# Table RecordCount "
echo "#------------------------------------"

OWNER=US_APLYOWN
RecordCount ${AP_TABLES[@]}
OWNER=US_COMMOWN
RecordCount ${CM_TABLES[@]}
#RecordCount ${MT_TABLES[@]}
