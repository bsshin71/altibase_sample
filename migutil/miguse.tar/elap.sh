time_diff()
{
    #t1=$1; t2=$2;
    d1=$1; d2=$2;
    t1=`echo $d1 |cut -d"-" -f2-`
    t2=`echo $d2 |cut -d"-" -f2-`
    if [ "x$t2" = "x" ]; then
        t2=$t1
    fi
    t1h=`echo $t1|cut -c1-2`
    t2h=`echo $t2|cut -c1-2`

    t1mm=`echo $t1|cut -c4-5`
    t2mm=`echo $t2|cut -c4-5`

    t1ss=`echo $t1|cut -c7-8`
    t2ss=`echo $t2|cut -c7-8`

    if [ $t2h -lt $t1h ]; then
        t2h=`expr $t2h + 24`;
    fi
    hour=`expr $t2h - $t1h`
    th=$((  $hour * 60 * 60      ))
    min=`expr $t2mm - $t1mm`
    tmm=$(( min * 60 ))
    tss=`expr $t2ss - $t1ss`

    elapsed=$(( th + tmm + tss ))
    sec=$(( elapsed % 60 ))
    hour=$(( ( elapsed - sec ) / 3600 ))
    min=$(( ( elapsed - ( hour * 3600) ) / 60 ))

    if [ $t2h -ge 24 ]; then
        t2h=`expr $t2h - 24`;
    fi
    printf "%s ~ %s" $d1 $d2
    printf " (%02d:%02d:%02d)" $hour $min $sec
}

LIST=`find logs -name "*_up.log" -ls |awk '{print $9"-"$10":00"}' |sort`

T=($( echo $LIST ))

STIME=${T[1]}
IDX=$(( ${#T[@]} - 1 ))
ETIME=${T[$IDX]}

time_diff $STIME $ETIME |sed 's/[0-9][0-9]-//g'
echo

