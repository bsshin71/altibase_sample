loop()
{
tbsql -s sys/tibero@DBPJSS1 <<EOF |grep -v "SYS>"
set sqlprompt "";
set heading off;
set echo off;
set TERMOUT off;
set pages 0;
set feedback off;
set timing off;

SELECT
      distinct POC_TAB_NM
FROM SYS.LCK_POC_TIBERO_DIFF A
WHERE 1=1
AND   TIB_TAB_NM is not NULL
AND   DIFF_FG != '4'
AND   POC_USER = '$OWNER'
;
EOF
}

#for U in US_IOWN US_IEAIOWN
for U in US_APLYOWN US_COMMOWN
do
    OWNER=$U
    loop
done
