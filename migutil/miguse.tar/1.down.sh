. .adb.poc

F_DIR=form
D_DIR=data
L_DIR=logs
OWNER=US_APLYOWN
IL="iloader $DB_CONN"

Download()
{
    FMT="-f ${F_DIR}/${TABLE}.fmt"
    LOG="-log $L_DIR/${TABLE}.log"
    BAD="-bad $L_DIR/${TABLE}.bad"
    DAT="-d $D_DIR/${TABLE}.dat"
    TBL="-T ${TABLE}"
    #---------------------------------------------------------
    # check same table working
    #---------------------------------------------------------
    PID=`ps -ef|grep $LOGNAME|grep " \-T \<$TABLE\>"| grep -v grep |awk '{print $2}'`
    PID=${PID:=0}
    if [ $PID -ne 0 ]; then
        return 
    fi
    #---------------------------------------------------------
    # Run ILoader
    #---------------------------------------------------------
    $E $IL -silent out $CONN -r "Rr_r%n" -t "^col|^" ${DAT} ${FMT} ${LOG} ${BAD} ${TBL} &
}

loop()
{
if [ $TABLE != "X" ];then
    echo $TABLE
    Download
fi
}

wait4iloader()
{
    #sleep 1;
    while(true)
    do
        CNT=`ps -ef|grep -v grep | grep -c iloader`
        if [ $CNT -ge 32 ]; then
            sleep 1;
        else
            break;
        fi
    done
}

## main

#for I in ${BIG_TABLES[@]} ${AP_TABLES[@]} ${CM_TABLES[@]}
#for I in ${CM_TABLES[@]} 
for I in ${AP_TABLES[@]} ${CM_TABLES[@]}
do
    #TABLE=`basename $I '.fmt'`
    TABLE=$I
    
    wait4iloader
    loop
done

