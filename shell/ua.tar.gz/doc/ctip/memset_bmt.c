/**
 * http://stackoverflow.com/questions/3654905/faster-way-to-zero-memory-than-with-memset
 */

#include "apue.h"

#define TIME(body) do {                                                     \
        struct timeval t1, t2; double elapsed;                                  \
        gettimeofday(&t1, NULL);                                                \
        body                                                                    \
        gettimeofday(&t2, NULL);                                                \
        elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0 + (t2.tv_usec - t1.tv_usec) / 1000.0; \
        printf("\t%40s ==> %3.06lf msec\n", #body, elapsed); } while(0)                 \


#define SIZE 0x1000000
#define _32M 0x2000000

void zero_1 ( void* buff , size_t size )
{
    size_t i;
    char* foo = buff;
    for ( i = 0; i < size; i++ )
        foo[i] = 0;

}

/* I foolishly assume size_t has register width */
void zero_sizet ( void* buff , size_t size )
{
    size_t i;
    char* bar;
    size_t* foo = buff;
    for ( i = 0; i < size / sizeof(size_t); i++ )
        foo[i] = 0;

    // fixes bug pointed out by tristopia
    bar = (char*) buff + size - size % sizeof(size_t);
    for ( i = 0; i < size % sizeof(size_t); i++ )
        bar[i] = 0;
}

void drop_cache ()
{
    static char* pSrcBuf = NULL;
    static char* pDstBuf = NULL;
    static int   sLen = _32M;       // L3 보다 크게.
    int     i;

    if ( pSrcBuf == NULL )
    {
        // 보다 정확하게 할려면, 이건 CPU 2번 소켓
        pSrcBuf = malloc ( sLen );
        memset ( pSrcBuf, 0xE8, sLen );

        // 이건 1번 소켓 ( 테스트 대상 CPU)
        pDstBuf = malloc ( sLen * 10 );
        memset ( pDstBuf, 0x00, sLen * 10 );
    }

    for ( i = 0; i < 10; i++ )
    {
        memcpy ( pDstBuf + (i * sLen), pSrcBuf, sLen );
    }

    if ( pDstBuf[100] == '\0' ) abort();
}

int main ( int argc, char** argv )
{
    char*   buffer = malloc ( SIZE );
    int     ix = 0;

    printf ( "\n>> [%d] size=%d,%.02lf,%.02lf\n", ++ix, SIZE, SIZE/1024.0, SIZE/1024.0/1024.0 );
    {
        // 이게 없으면, 속도가 순서에 따라 달라진다.
        TIME( drop_cache(); );
        if ( argc == 1 )
            TIME( memset(buffer, 0, SIZE); );
        else
            TIME( __builtin_memset(buffer, 0, SIZE); );
        TIME( { drop_cache(); } );
        TIME( zero_1(buffer, SIZE); );
        TIME( { drop_cache(); } );
        TIME( zero_sizet(buffer, SIZE); );
        TIME( { drop_cache(); } );
        TIME( memset(buffer, 0, SIZE); );
    }

    printf ( "\n>> [%d] size=%d,%.02lf,%.02lf\n", ++ix, SIZE, SIZE/1024.0, SIZE/1024.0/1024.0 );
    {
        drop_cache();
        TIME( memset(buffer, 0, SIZE); );
        drop_cache();
        TIME( zero_1(buffer, SIZE); );
        drop_cache();
        TIME( zero_sizet(buffer, SIZE); );
        drop_cache();
        TIME( __builtin_memset(buffer, 0, SIZE); );
        drop_cache();
        TIME( memset(buffer, 0, SIZE); );
    }

    printf ( "\n>> [%d] size=%d,%.02lf,%.02lf\n", ++ix, SIZE, SIZE/1024.0, SIZE/1024.0/1024.0 );
    {
        drop_cache();
        TIME( __builtin_memset(buffer, 0, SIZE); );
        drop_cache();
        TIME( memset(buffer, 0, SIZE); );
        drop_cache();
        TIME( __builtin_memset(buffer, 0, SIZE); );
        drop_cache();
        TIME( memset(buffer, 0, SIZE); );
    }

    printf ( "\n>> [%d] size=%d,%.02lf,%.02lf\n", ++ix, SIZE, SIZE/1024.0, SIZE/1024.0/1024.0 );
    {
        TIME( __builtin_memset(buffer, 0, SIZE); );
        TIME( __builtin_memset(buffer, 0, SIZE); );
        TIME( memset(buffer, 0, SIZE); );
        TIME( memset(buffer, 0, SIZE); );
        TIME( __builtin_memset(buffer, 0, SIZE); );
        TIME( __builtin_memset(buffer, 0, SIZE); );
    }

    return 0;
}
