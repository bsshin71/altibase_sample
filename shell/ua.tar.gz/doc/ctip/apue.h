#ifndef __APUE_H__
#define __APUE_H__

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <assert.h>
#include <getopt.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <stddef.h>

#include <sys/mman.h>
//#include <sys/stat.h>
#include <fcntl.h>           /* For O_* constants */

//#include <sys/eventfd.h>

//#include "log.h"
//#include "exception.h"


#ifdef __cplusplus
extern "C"
{
#endif  

// do something ..

#ifdef __cplusplus
}
#endif  

#endif
