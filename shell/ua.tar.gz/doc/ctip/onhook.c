/*
 * @build	$ gcc -fPIC -rdynamic -g -shared -o libonhook.so onhook.c -lc -ldl
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/stat.h>

#define __USE_GNU
#include <dlfcn.h>

//#include "mfwApi.h"
//#include "myDef.h"

int		g_trace_fd = -1;

int shm_open ( const char* name, int oflag, mode_t mode )
{
	static int ( *orig_open ) ( const char* name, int oflag, mode_t mode ) = NULL;
	char*	error;
	int		fd;

//abort();

	if ( g_trace_fd == -1 )
	{
		char* pChar = getenv ( "DBM_TRACE_FD" );
		if ( pChar != NULL )
		{
			g_trace_fd = atoi ( pChar );
		}
	}

	if ( !orig_open )
	{
		orig_open = dlsym ( RTLD_NEXT, "shm_open" );
		if ( ( error = dlerror() ) != NULL )
		{
			write ( 2, "error \n", 7 );
			abort();
//			exit ( EXIT_FAILURE );
		}
	}

	fd = ( *orig_open ) ( name, oflag, mode );

	if ( g_trace_fd != -1 && fd == g_trace_fd )
	{
		printf ( "\t%s:%d [DBM_TRACE_FD] name=%s fd=%d (err=%d)\n", __FUNCTION__, __LINE__, name, fd, errno ); fflush (stdout);
	}

	return fd;
}

//        int open(const char *pathname, int flags, mode_t mode);
int open64 ( const char* path, int oflag, ... )
{
	static int ( *orig_open64 ) ( const char* path, int oflag, ... ) = NULL;
	va_list	argptr;
	char*	error;
	int		fd;

	if ( g_trace_fd == -1 )
	{
		char* pChar = getenv ( "DBM_TRACE_FD" );
		if ( pChar != NULL )
		{
			g_trace_fd = atoi ( pChar );
		}
	}

	if ( !orig_open64 )
	{
		orig_open64 = dlsym ( RTLD_NEXT, "open64" );
		if ( ( error = dlerror() ) != NULL )
		{
			write ( 2, "error \n", 7 );
			abort();
//			exit ( EXIT_FAILURE );
		}
	}

	va_start ( argptr, oflag );
	fd = ( *orig_open64 ) ( path, oflag, argptr );
	va_end ( argptr );

	if ( g_trace_fd != -1 && fd == g_trace_fd )
	{
		printf ( "\t%s:%d [DBM_TRACE_FD] path=%s fd=%d (err=%d)\n", __FUNCTION__, __LINE__, path, fd, errno ); fflush (stdout);
	}

	return fd;
}

int fclose ( FILE* fp )
{
	static int ( *orig_fclose ) ( FILE* fp ) = NULL;
	char*	error;

//abort();
	if ( g_trace_fd == -1 )
	{
		char* pChar = getenv ( "DBM_TRACE_FD" );
		if ( pChar != NULL )
		{
			g_trace_fd = atoi ( pChar );
		}
	}

	if ( !orig_fclose )
	{
		//orig_close = dlsym ( RTLD_NEXT, "open64" );
		orig_fclose = dlsym ( RTLD_NEXT, "fclose" );
		if ( ( error = dlerror() ) != NULL )
		{
			write ( 2, "error \n", 7 );
			abort();
//			exit ( EXIT_FAILURE );
		}
	}

	int fd = fileno ( fp );
	if ( g_trace_fd != -1 && fd == g_trace_fd )
	{
		printf ( "\t%s:%d [DBM_TRACE_FD] fd=%d (err=%d)\n", __FUNCTION__, __LINE__, fd, errno ); fflush (stdout);
	}

	return ( *orig_fclose ) ( fp );
}

int g_nClose = 0;
int close ( int fd )
{
	static int ( *orig_close ) ( int fd ) = NULL;
	char*	error;

//abort();
	if ( g_trace_fd == -1 )
	{
		char* pChar = getenv ( "DBM_TRACE_FD" );
		if ( pChar != NULL )
		{
			g_trace_fd = atoi ( pChar );
		}
	}

	if ( !orig_close )
	{
		//orig_close = dlsym ( RTLD_NEXT, "open64" );
		orig_close = dlsym ( RTLD_NEXT, "close" );
		if ( ( error = dlerror() ) != NULL )
		{
			write ( 2, "error \n", 7 );
			abort();
//			exit ( EXIT_FAILURE );
		}
	}

	if ( g_trace_fd != -1 && fd == g_trace_fd )
	{
		g_nClose++;
		printf ( "\t%s:%d [DBM_TRACE_FD] (%d) fd=%d (err=%d)\n", __FUNCTION__, __LINE__, g_nClose, fd, errno ); fflush (stdout);
		if ( g_nClose > 16 ) 
		{
			//abort();
		}
	}

	return ( *orig_close ) ( fd );
}

#if 0
int open ( const char* path, int oflag )
{
	static int ( *orig_open ) ( const char* path, int oflag ) = NULL;
	char*	error;
	int		fd;

//abort();

	if ( g_trace_fd == -1 )
	{
		char* pChar = getenv ( "DBM_TRACE_FD" );
		if ( pChar != NULL )
		{
			g_trace_fd = atoi ( pChar );
		}
	}

	if ( !orig_open )
	{
		//orig_open = dlsym ( RTLD_NEXT, "open64" );
		orig_open = dlsym ( RTLD_NEXT, "open" );
		if ( ( error = dlerror() ) != NULL )
		{
			write ( 2, "error \n", 7 );
			abort();
//			exit ( EXIT_FAILURE );
		}
	}

	fd = ( *orig_open ) ( path, oflag );

	if ( g_trace_fd != -1 && fd == g_trace_fd )
	{
		printf ( "\t%s:%d [DBM_TRACE_FD] path=%s fd=%d (err=%d)\n", __FUNCTION__, __LINE__, path, fd, errno ); fflush (stdout);
	}

	return fd;
}
#endif /* open */

#if 0
int open ( const char* path, int oflag, ... )
{
	static int ( *orig_open ) ( const char* path, int oflag, ... ) = NULL;
	va_list	argptr;
	char*	error;
	int		fd;

	if ( g_trace_fd == -1 )
	{
		char* pChar = getenv ( "DBM_TRACE_FD" );
		if ( pChar != NULL )
		{
			g_trace_fd = atoi ( pChar );
		}
	}

	if ( !orig_open )
	{
		orig_open = dlsym ( RTLD_NEXT, "open" );
		if ( ( error = dlerror() ) != NULL )
		{
			write ( 2, "error \n", 7 );
			abort();
//			exit ( EXIT_FAILURE );
		}
	}

	va_start ( argptr, oflag );
	fd = ( *orig_open ) ( path, oflag, argptr );
	va_end ( argptr );

	if ( g_trace_fd != -1 && fd == g_trace_fd )
	{
		printf ( "\t%s:%d [DBM_TRACE_FD] path=%s fd=%d (err=%d)\n", __FUNCTION__, __LINE__, path, fd, errno ); fflush (stdout);
	}

	return fd;
}
#endif
