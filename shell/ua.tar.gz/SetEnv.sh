#!/bin/sh

export VERSION=2.2.11.8

if [ "x"$BUILD_MODE == "x_debug" ]
then
    export MAKEPATH=Debug               # 나중에 *.o 빌드 경로를 release/debug 분리하는 용도
    export LIBMODE=debug
    export LIBMODEPATH=debug            # *.so 생성 경로
    export RELEASE=$BUILD_MODE
    export VERSION=$VERSION"_debug"
else
    export MAKEPATH=RELEASE
    export LIBMODE=release
    export LIBMODEPATH=""
    unset RELEASE
fi
unset BUILD_MODE


# LD_LIBRARY_PATH_BCK3 은 반복수행시 경로가 계속 길어지는 것을 방지한다.
# [note] SetEnv.sh 수행 후 수작업으로 특정경로를 LD_LIBRARY_PATH 에 추가후 재수행시 반영이 되지 않는 문제가 있음
if [ "x$LD_LIBRARY_PATH_BCK3" == "x" ]
then
    export LD_LIBRARY_PATH_BCK3=$LD_LIBRARY_PATH
else
    export LD_LIBRARY_PATH=$LD_LIBRARY_PATH_BCK3
fi

if [ "x$PATH_BCK3" == "x" ]
then
    export PATH_BCK3=$PATH
else
    export PATH=$PATH_BCK3
fi

# LD_LIBRARY_PATH=`pwd`/common/lib/src:$LD_LIBRARY_PATH           # libcmn.so
# LD_LIBRARY_PATH=`pwd`/goldilocks/src:$LD_LIBRARY_PATH           # libdbm.so
# LD_LIBRARY_PATH=`pwd`/gtest/lib:$LD_LIBRARY_PATH 
# export LD_LIBRARY_PATH


########################################
# Build Time Env
########################################

export DBM_DEV3=`pwd`
export DBM_HOME=$DBM_DEV3/dbm_home        # 컴파일의 DBM_HOME 과 실행이 다를 수 있다. 때문에 중복

# 3rd-party source ( ex. gtest )
export OUTSRC=$DBM_DEV3/3rd
export OUTLIB=$OUTSRC/lib
export OUTINC=$OUTSRC/inc

# common library
export CMNSRC=$DBM_DEV3/src/common
export CMNINC=$CMNSRC/inc
export CMNBIN=$DBM_HOME/bin/$LIBMODEPATH
export CMNLIB=$DBM_HOME/lib/$LIBMODEPATH

# goldilocks v3
export DFSRC=$DBM_DEV3/dataCatcher
export GDSRC=$DBM_DEV3/src/goldilocks
export GDINC=$GDSRC/inc
export GDBIN=$DBM_HOME/bin/$LIBMODEPATH
export GDLIB=$DBM_HOME/lib/$LIBMODEPATH


if [ ! -f $DBM_HOME/conf/dbm.cfg ]
then
    cd $DBM_HOME/conf
    if [ -f defs/dbm.cfg.$USER ]
    then
        cp defs/dbm.cfg.$USER dbm.cfg
    else
        cp defs/dbm.cfg.defs dbm.cfg
    fi
    cd - > /dev/null
fi

if [ ! -f $DBM_HOME/conf/rdiff.cfg ]
then
    cd $DBM_HOME/conf
    if [ -f defs/rdiff.cfg.$USER ]
    then
        cp defs/rdiff.cfg.$USER rdiff.cfg
    else
        cp defs/rdiff.cfg.defs rdiff.cfg
    fi
    cd - > /dev/null
fi

########################################
# Run Time Env
########################################

# DBM_HOME은 외부에서 정의되어서 바뀔수 있는 경로 이고, DBM_DEV3는 소스의 최상위를 의미한다.
# 필요하다면 변경
export DBM_HOME=$DBM_DEV3/dbm_home
export DBM_INSTANCE=demo                # dbm instance name

if [ "x$WINDIR" != "x" ]
then
export PATH=.:$DBM_HOME/lib/$LIBMODEPATH:$DBM_HOME/bin/$LIBMODEPATH:$DBM_HOME/shl:$PATH
else
export PATH=.:$DBM_HOME/bin/$LIBMODEPATH:$DBM_HOME/shl:$PATH
fi

export LD_LIBRARY_PATH=$DBM_HOME/lib/$LIBMODEPATH:$LD_LIBRARY_PATH        # for 3rd or internal, ex) GTEST


export DBM_SHM_PREFIX=$USER
#export DBM_FILE_MODE=0660              # 내부적으로 생성되는 파일( DISK 로그, shm 등 )의 권한설정

# 아래설정은 배포 패키지에는 설정되지 않는다. (그러나, 배포패키지의 기본값과 동일하다.)
# 그럼에도 굳이 설정읗 하는 이유는 개발환경에서 debug 모드와 release 모드를 전환할때. 설정 원복을 위해서이다.
export DBM_TRCLOG_ECHO=0                # 1: 로그메시지 화면 출력, 0: 화면에 아무 출력하지 않음


export DBM_TRCLOG_LEVEL=2               # [TODO] 0: NOLOG, 1: ERROR, 2: WARN, 3: INFO, 4: HEXA, 5: DEBUG, 6:TRACE, 9: ALL

export DBM_TRCLOG_NAME_TYPE=1           # 1: dbm.<UNDO_NAME>.MMDD.log (default)
                                        # 2: yyyymmdd_<comm>.log ( 개발단계에서 tail을 거는 편의를 위해서 )
                                        # 3: yyyymmdd_<comm>_<pid>.log
export DBM_TRCLOG_PID_TYPE=0            # 0: PID, 1: TID

export DBM_UPLOAD_THR_NUM=4


########################################
# Goldilocks v1 ( PB )
########################################
# export DBM_IO_TYPE=3


########################################
# TESTCASE ( test를 위한 환경변수 )
########################################
export DBM_RTF_ON=0                       # 0: OFF, 1: ON ( RTF_POINT 활성화 )

# gtest 에서 로딩하는 테스트케이스 so 목록
export _DBM_TEST_LIBS=libtest_api.so:libtest_biz.so:libtest_etc.so:libtest_idx.so:libtest_seg.so

export LD_LIBRARY_PATH=$GDSRC/test/lib:$LD_LIBRARY_PATH


########################################
# Hidden Property ( _DBM_XX )
# 
# 통상 DEBUG 빌드에서만 적용됨
########################################
#export _DBM_SEGMGR_DBLFREE_CHECK=1
#export _DBM_USE_SIGNAL_HANDLER=1


########################################
# Member
########################################
# Build syntastic.config ( by ckh0618 )
echo -I$OUTINC > syntastic.conf
echo -I$CMNINC >> syntastic.conf
echo -I$CMNSRC/header >> syntastic.conf
echo -I$GDINC >> syntastic.conf
echo -I$GDSRC/header >> syntastic.conf


########################################
# aliases
########################################
alias ons='cd $DBM_DEV3 ; echo "LIBMODE=[$LIBMODE]"'  # ons = dbm src directory
alias onh='cd $DBM_HOME'
alias onb='cd $DBM_HOME/bin/$LIBMODEPATH'
alias onc='cd $DBM_HOME/shl'
alias onl='cd $DBM_HOME/trc'
alias onp='vi $DBM_HOME/conf/dbm.cfg'
alias ont='tail -f $DBM_HOME/trc/alert_*.log'

if [ `which rlwrap` ]
then
    alias mm='rlwrap $DBM_HOME/bin/$LIBMODEPATH/metaManager'
else
    alias mm='$DBM_HOME/bin/$LIBMODEPATH/metaManager'
fi 2> /dev/null


# just recommend (dummy)
alias grep='grep --color=auto'
# [충돌] strace: -c and -ff are mutually exclusive options
#alias strace='strace -f'
