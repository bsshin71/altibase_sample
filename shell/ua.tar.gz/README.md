for goldilocks
3rd_iter : r5206