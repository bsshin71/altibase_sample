#!/bin/sh

#
# 테스트 시간을 줄이기 위해, 가장 오래걸리는 반복 테스트를 test.all3.sh 에서 수행
#

ulimit -c unlimited

run()
{
    cd $1
    echo ""
    echo "[`date "+%Y/%m/%d %H:%M:%S (%a)"`] start test (`basename $1`)"
    echo "----------------------------------------"

    time sh run.sh 
    rc=$?
    if [ "x"$rc != "x0" ]
    then
        echo "[`date "+%Y/%m/%d %H:%M:%S (%a)"`] test error (`basename $1`)"
        cd -
        exit $rc
    fi

    echo "[`date "+%Y/%m/%d %H:%M:%S (%a)"`]   end test (`basename $1`)"
    cd - > /dev/null
}

run100()
{
    cd $1
    echo ""
    echo "[`date "+%Y/%m/%d %H:%M:%S (%a)"`] start test (`basename $1`)"
    echo "----------------------------------------"

    time sh run100.sh 
    rc=$?
    if [ "x"$rc != "x0" ]
    then
        echo "[`date "+%Y/%m/%d %H:%M:%S (%a)"`] test error (`basename $1`)"
        cd -
        exit $rc
    fi

    echo "[`date "+%Y/%m/%d %H:%M:%S (%a)"`]   end test (`basename $1`)"
    cd - > /dev/null
}

$DBM_DEV3/dbm_home/shl/test.all2.sh
test "x"$? != "x0" && exit 1

# Index Test
run100 $DBM_DEV3/src/goldilocks/unitTest/IndexManager/

# Index Test
run100 $DBM_DEV3/src/goldilocks/unitTest/IndexManager/non_unique

echo "! "
echo "! 테스트가 완료되었습니다. 쌩유"
echo "! "; echo ""
exit 0

