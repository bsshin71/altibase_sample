#!/bin/sh

PVSZ=0
PRSS=0

pid=`ps -ef |grep $USER |grep dbmReplRec |grep -v gdb |grep -v vim |grep -v grep |awk '{print $2}'`
while :
do
    DT=`date "+%H:%M:%S"`
    R=`ps -p $pid -ovsz,rss |grep -v VSZ`

    VSZ=`echo $R |awk '{print $1}'`
    RSS=`echo $R |awk '{print $2}'`
    DVSZ=`expr $VSZ - $PVSZ`
    DRSS=`expr $RSS - $PRSS`

    echo "[$DT] M[ $R ] D[ $DVSZ , $DRSS ] "

    PVSZ=$VSZ
    PRSS=$RSS

    sleep 1
done

