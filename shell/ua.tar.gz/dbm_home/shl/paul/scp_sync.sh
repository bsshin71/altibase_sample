F=$1
DIR=`pwd`

if [ "x"$USER == "xpaul" ]
then
    DIR1=`echo $DIR |sed -e "s;/home/paul;/ssd/onmir;g"`
    DIR2=`echo $DIR |sed -e "s;/home/paul;/ssd/isuha85;g"`

    if [ "x$F" != "x" ]
    then
        #scp $F dev3:$DIR/$F
        scp $F onmir@sun:$DIR1/$F
        scp $F isuha85@sun:$DIR2/$F
    else
        for F in `svn st |grep "^M" |awk '{print $2}'`
        do
            scp $F onmir@sun:$DIR1/$F
            scp $F isuha85@sun:$DIR2/$F
        done
    fi
fi

