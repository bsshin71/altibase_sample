#!/bin/sh

function run()
{
    ( cd $DBM_DEV3 ; make -j1 $1 )
    test "x"$? != "x0" && exit 1
}

make clean;

loop=0
while :
do
    loop=`expr $loop + 1`

    run &
    sleep `expr $loop + 30`

    if [ $loop -gt 10 ]
    then
        chk=`ps -ef|grep make |grep $LOGNAME |wc -l`
        test "x"$chk == "x0" && exit 0
    fi

    ps -ef|grep make |grep $LOGNAME |awk '{print "kill -9 "$2}' |sh -v
    sleep 1
    ps -ef|grep make |grep $LOGNAME |awk '{print "kill -9 "$2}' |sh -v
done

exit 0
