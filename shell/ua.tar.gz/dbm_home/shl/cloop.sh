#!/bin/sh

ulimit -c unlimited 

run="sh run.sh"
#run="sh run_person.sh"

if [ "x"$1 != "x" ]
then
    if [ -f "./"$1 ]
    then
        run="sh $1"
    else
        run="$1"
    fi
fi

loop=0
while :
do 
    loop=`expr $loop + 1`
    #sleep 2

    echo "[$loop] Start .. `date`"

    time ${run}
    rc=$?
    if [ "x"$rc != "x0" ]
    then
        echo "[$loop] [FATAL] error.. `date`"
        exit $rc 
    fi  

    echo "[$loop]   End .. `date`"

    # 앞에 LANG을 붙이는 이유는 만일 en_US.UTF-8이면 파일 사이즈 다음에 년 대신 월 이기 때문
    # core 가 생기거나 diff가 생기면 중단한다.
    #chk=`LANG=ko_KR.UTF-8 ls -l *.diff core.* 2> /dev/null |grep -v " 0 201[0-9]" |wc -l`
    chk=`LANG=ko_KR.UTF-8 ls -l core.* 2> /dev/null |grep -v " 0 201[0-9]" |wc -l`
    if [ "x"$chk != "x0" ]
    then
        echo "[$loop] [FATAL] error.. `date`"
        exit 1
    fi
    sleep 2
done
