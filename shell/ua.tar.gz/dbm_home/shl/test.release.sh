#!/bin/sh

##################################################
# 사용법
#
# $ . SetEnv.sh
# $ make --> testcase 실행파일 컴파일
# $ make dist --> 패키지 생성
# $ test.release.sh --> 최소 환경변수 (배포와 거의 동일)로 테스트 수행.
##################################################

export LC_ALL=C

##################################################
# MAIN
##################################################

TEST_HOME=$HOME/dbm_home
#TEST_HOME=$DBM_DEV3/release
test "x"$1 != "x" && TEST_HOME=$1

if [ ! -f $TEST_HOME/goldilocks.dbm.env ]
then
    echo "[Error] \$HOME/dbm_home directory not founded." && exit 1
fi

echo "!! TEST START !! ( $TEST_HOME )"

cd $DBM_DEV3
OLDPWD=`pwd`

# DBM 관련 모든 환경설정을 날림
env |grep -i DBM |sed -e "s/=.*$//g" |awk '{print "unset "$1}' > _unset.env
source _unset.env

PATH=/bin:/usr/bin

# goldilocks.dbm.env
export DBM_DEV3=$OLDPWD                     # test.all.sh 내부에서 사용

export DBM_HOME=$TEST_HOME
export DBM_INSTANCE=demo
export PATH=$DBM_HOME/bin:$DBM_HOME/bin/trace:$PATH

export LD_LIBRARY_PATH=$DBM_HOME/lib:$LD_LIBRARY_PATH
if [ "x"$LIBMODE == "xdebug" ]
then
    echo "[Error] \$LIBMODE must be release" && exit 1
    # 아래로 바꾸면 DEBUG에서도 테스트 가능하기는 하다.
    export LD_LIBRARY_PATH=$DBM_HOME/lib/$LIBMODE:$LD_LIBRARY_PATH
fi

env > /tmp/test.release.sh.env.txt

if [ ! -d $DBM_HOME/shl ]
then
    mkdir -p $DBM_HOME/shl
    ln -s $DBM_DEV3/dbm_home/shl/rmipc $DBM_HOME/shl/rmipc
    ln -s $DBM_DEV3/dbm_home/shl/rmlog $DBM_HOME/shl/rmlog
    ln -s $DBM_DEV3/dbm_home/bin/odiff $DBM_HOME/bin/odiff
    ln -s $DBM_DEV3/dbm_home/conf/dbm.license $DBM_HOME/conf/dbm.license
    ln -s $DBM_DEV3/dbm_home/lib/libgtest.so.0 $DBM_HOME/lib/libgtest.so.0
fi

export PATH=$DBM_HOME/shl:$PATH:.
$DBM_DEV3/dbm_home/shl/test.all2.sh
test "x"$? != "x0" && exit 1

exit 0

