#!/bin/sh

#################################################################################
# default global variables
#################################################################################

SUPP="--suppressions=$DBM_HOME/conf/dbm.supp"
#SUPP=${SUPP}" --gen-suppressions=all"
#VGDB="--vgdb=yes --vgdb-error=0"
VOPT="--max-stackframe=22000000 --trace-children=yes --child-silent-after-fork=yes --run-libc-freeres=yes --demangle=yes ${SUPP} ${VGDB}"
export VALGRIND="valgrind -v --track-origins=yes --malloc-fill=88 --free-fill=99 --leak-check=full ${VOPT}"


##########################################
# test_and_run
##########################################
declare run=""
test_and_valgrind ()
{
    if [ "x"$test_run == "x1" ]
    then 
        echo "${VALGRIND} ${run}"
    else 
        echo "${VALGRIND} ${run}"; ${VALGRIND} ${run}
    fi   
}

test_and_run ()
{
    if [ "x"$test_run == "x1" ]
    then 
        echo "${run}"
    else 
        if [ "x"$1 == "x" ]
        then 
            echo "${run}"; ${run}
        else 
            echo "${run}"; ${run} &
        fi   
    fi   
}

##########################################
# echo_sleep
##########################################
echo_sleep ()
{
    echo "sleep "$1

    if [ "x"$test_run != "x1" ]
    then 
        sleep $1
    fi   
}

##########################################
# process 구동 체크
##########################################
cond_wait ()
{
    test "x"$test_run == "x1" && return

    sTxt=$1
    check_count=$2

    while :
    do
        cnt=`ps -ef |grep ${sTxt} |grep -v grep |grep -v vi |grep -v gdb |grep -v tail |wc -l`
        if [ "x"$cnt == "x"$check_count ]
        then
            return
        fi
        echo_sleep 1
    done
}

