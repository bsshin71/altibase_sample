#!/bin/bash

if [ $# -gt 0 ]
then
    LOG=$1
    if [ ! -f ${LOG}  ]
    then
        if [ ! -f ${DBM_HOME}/trc/${LOG}  ]
        then
            printf "(E) No such file '${LOG}'\n"
            exit 1
        else
            LOG=${DBM_HOME}/trc/${LOG}
        fi
    fi
else
    printf "Usage: \n\tdump_stack.sh <log file name> [max log line num]\n"
    exit 1
fi

DMP=${LOG}_dump
LOG_LINENO=40000
test "x"$2 != "x" && LOG_LINENO=$2

start_line=`tail -n ${LOG_LINENO} ${LOG} |strings |grep -n "======= Backtrace: =========" |tail -1 |sed -e "s/:.*$//g"`
if [ "x"$start_line == "x" ]
then
    printf "Backtrace Msg ('======= Backtrace: =========') not found. Check LogFile Name. (=${LOG}) or LogFile Trace LineNo (=${LOG_LINENO})\n"
    exit 1
fi

total_line=`cat ${LOG} |wc -l`
tail_line=`expr $total_line - $start_line + 400`                            # 위에 400라인까지 오류를 함께 찍는 목적
tail -n ${tail_line} ${LOG} |head -n ${LOG_LINENO} |strings > ${DMP}        # 로그 파일이 매우 크고, DUMP가 앞쪽에 있을때, 파일을 최대 4만 라인까지 자름

declare -A ppLibBase
declare -A ppLibPath

# echo ${DMP}
ppLibName=(`cat ${DMP} |grep -e ") \[0x" |grep -v -E "\.c|\.h|/lib64" |sed -e "s/(.*//g" |sed -e "s;.*/;;g" |uniq`)

#echo "(1) 필요한 so 파일에 대한 BASE Address를 구한다."
for (( i=0; i<${#ppLibName[@]}; i++ ))
do
    #echo $i"/"${#ppLibName[@]}
    # 'tail -1' 이 필요한 이유는 2번 비정상 종료 로그의 위치가 인접하여 예를들면 libmfw.so에 대핸 maps 정보가 2개 라인일 수 있다.
    ppLibBase[${ppLibName[$i]}]=`cat ${DMP} |grep "r-xp.*${ppLibName[$i]}" |tail -1 |sed -e "s/-.*$//g" |sed -e "s/^/0x/g"`
    #echo ${ppLibName[$i]}
    #echo ${ppLibBase[${ppLibName[$i]}]}
done


#echo "(1) 필요한 so 파일에 대한 Path를 구한다."
for (( i=0; i<${#ppLibName[@]}; i++ ))
do
    ppLibPath[${ppLibName[$i]}]=`cat ${DMP} |grep "r-xp.*${ppLibName[$i]}" |tail -1 |sed -e "s/^.* //g"`
done



echo "======= Backtrace: =========" 
#echo "(2) Backtrace 로그를 통해 원하는 라인 번호를 출력한다."
#   1. '@'는 line_buf 를 통해 한줄을 읽기 위한 편의상 추가된 의미없는 임의의 문자이다.
#   2. 결과에 "(discriminator at 2)" 이런 구문이 있는 것은 해당 so가 변경되었을 가능성이 높다
for line_buf in `cat ${DMP} |grep -e "^.[S|E]" -e ") \[0x" |c++filt |sed -e "s/ /@/g" |sed 's/.\x00//g'`
do
    #set -x
    #echo "line_buf=[${line_buf}]"
    X=`echo "${line_buf}" |sed -e "s/@/ /g"`

    bErr=`echo "${line_buf}" |grep "^.[S|E]" |wc -l`

    find=0
    for (( i=0; i<${#ppLibName[@]}; i++ ))
    do
        F=`echo "${X}" |grep -e ") \[0x" |grep -v -E "\.c|\.h|/lib64" |grep ${ppLibName[$i]} |wc -l`
        if [ ${F} -eq 1 ]
        then
            addr=`echo "${X}" |sed -e "s/.*\[//g" |sed -s "s/\].*//g"`
            # echo "########################################"
            # echo "[연산검증] 두줄이면 안된다. ${addr} - ${ppLibBase[${ppLibName[$i]}]}"
            # echo "########################################"
# set -x && echo "X=[${X}]" && echo "LibName=${ppLibName[$i]}"
            offset=`printf "0x%x\n" $(( ${addr} - ${ppLibBase[${ppLibName[$i]}]} ))`

            # ".so" 인 경우는 offset을 사용하고실행파일은 addr을 사용한다.
            #echo ${ppLibPath[${ppLibName[$i]}]}
            case ${ppLibPath[${ppLibName[$i]}]} in
            *.so* )
                pLineNo=`addr2line -e ${ppLibPath[${ppLibName[$i]}]} ${offset} |sed -e "s;^.*/\.;.;g"`
                ;;
            * )
                pLineNo=`addr2line -e ${ppLibPath[${ppLibName[$i]}]} ${addr} |sed -e "s;^.*/\.;.;g"`
                ;;
            esac

            find=1
            printf "\t%s at %s\n" "${X}" ${pLineNo}
# set +x && exit
            break;
        fi
    done

    if [ ${find} -eq 0 ]
    then
        if [ ${bErr} -eq 0 ]
        then
            printf "\t%s\n" "${X}"
        else
            printf "%s\n" "${X}"
        fi
    fi

    #set +x
done

rm -f ${DMP}
exit 0
