#!/bin/sh

set -x
( cd $DBM_DEV3 ; make -j3 $1 )
test "x"$? != "x0" && exit 1
set +x

exit 0
