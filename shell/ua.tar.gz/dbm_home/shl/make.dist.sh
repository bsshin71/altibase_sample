#!/bin/sh

#
# DB 호환성에 변동이 생기면 변경한다.
# 자동화 되어 있지 않고, 현재는 수작업이다. 
#
#VERSION=2.2.7.x

FILES="./goldilocks.dbm.env "
FILES+="./bin/trace/dbm.trace.env "
if [ "x"$WINDIR == "x" ]
then
FILES+="./lib/libdbm.so ./lib/libcmn.so ./lib/debug/libcmn.so ./lib/debug/libdbm.so "
else
FILES+="./lib/libdbm.dll ./lib/libcmn.dll ./lib/debug/libcmn.dll ./lib/debug/libdbm.dll "
FILES+="./lib/libdbmVC.lib ./lib/debug/libdbmVC.lib ./lib/libgcc_s_seh-1.dll ./lib/libstdc++-6.dll ./lib/libwinpthread-1.dll "
fi

# 암호화 배포 여부
if [ "x"$WINDIR == "x" ]
then
FILES+="./lib/debug/liblz4.so "

FILES+="./bin/metaManager ./bin/dbmExp ./bin/dbmImp ./bin/olsnr ./bin/merr ./bin/dbmMon "
FILES+="./bin/dbmRecover ./bin/dbmReplReceiver ./bin/dbmReplSender ./bin/dbmReplGap ./bin/rdiff "

# ?/bin/trace 로 이동
DUMP_TOOLS="./bin/dump_idx ./bin/dump_log ./bin/dump_txlog ./bin/dump_txtbl ./bin/dump_row "
FILES+=$DUMP_TOOLS
fi

FILES+="./demo "

FILES+="./conf/dbm.cfg.sample ./conf/rdiff.cfg.sample ./conf/dbm.banner ./conf/dbm.error "
FILES+="./include/dbmAPI.h ./include/dbmDef.h "

if [ "x"$WINDIR != "x" ]
then
FILES+="./include/dbmWinAPI.h "
fi

#echo "[$FILES]" && exit 0

########################################
# CHECK
########################################
if [ "x"$DBM_DEV3"/dbm_home" != "x$DBM_HOME" ]
then
    echo "check \$DBM_HOME must be ($DBM_DEV3/dbm_home)"
    exit 1
fi


########################################
# MAIN
########################################

# 지워준다.
rmipc > /dev/null 2>&1
rmlog > /dev/null 2>&1

PWDOLD=`pwd`
cd $DBM_HOME
cp ./conf/defs/dbm.cfg.defs ./conf/dbm.cfg.sample
cp ./conf/defs/rdiff.cfg.defs ./conf/rdiff.cfg.sample

# 파일정리
(cd $DBM_HOME/demo; make clean)

if [ ! -d $DBM_DEV3/release ]
then
    echo "[Error] \$DBM_DEV3/release not found.!" && exit 1
fi

# 작업디렉토리 정리
rm -rf $DBM_DEV3/release/*
cd $DBM_DEV3/release/
(cd $DBM_HOME; tar -cf - $FILES)|tar -xf -

# 빈경로생성
mkdir ./dic ./WAL ./trc

# 파일경로변경
for s in `echo $DUMP_TOOLS`
do
    d=`echo ${s} |sed -e "s;bin/;bin/trace/;g"`
    mv ${s} ${d}
done

# 파일경로변경
chmod -R 775 *

# 패키지 생성
tar -cf - . |gzip -c - > $DBM_DEV3/goldilocks-${VERSION}.el6.x86_64.tgz 

cd $PWDOLD > /dev/null 2>&1

exit 0
