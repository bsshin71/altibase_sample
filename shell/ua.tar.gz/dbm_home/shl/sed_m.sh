#!/bin/sh

########################################
# 공통 설정
########################################
src=$1

OLD=memset
OLD=memcpy
OLD=strcpy
OLD=strncmp
OLD=malloc
OLD=strlen
OLD=strcmp
NEW=${OLD}_s

NEW=memset
NEW=memcpy
NEW=strcpy
NEW=strncmp
NEW=malloc
NEW=strlen
NEW=strcmp
OLD=${NEW}_s

OLD="unsigned long"
NEW="uint64_t"

OLD="long    "
NEW="int64_t "

OLD="long\*    "
NEW="int64_t* "

OLD="long \*"
NEW="int64_t*"

OLD="long"
NEW="int64_t"

OLD="pid_t"
NEW="mvp_pid_t"

OLD="pthread_yield"
NEW=${OLD}_s

OLD="uint64_t"
NEW="unsigned long long"

OLD="int64_t"
NEW="long long"

OLD="aType"
NEW="aEQCnt"

########################################
# MAIN.
########################################

chk=`basename $src |grep -e "\.cpp" -e "\.h" |wc -l`
#chk=`basename $src |grep -e "\.cpp" -e "\.h" |wc -l`
#chk=`basename $src |grep -e "\.sh" |wc -l`
test "x"$chk != "x1" && exit 0

if [ "x"$src != "x" ]
then
set -x
    sed -i "s/\b${OLD}\b/${NEW}/g" $src
    #sed -i "s/\b${OLD}/${NEW}/g" $src
set +x
	exit $ret
fi

exit 0

########################################
# END.
########################################
# @usage
# find . -type f -exec sed_m.sh {} \;

