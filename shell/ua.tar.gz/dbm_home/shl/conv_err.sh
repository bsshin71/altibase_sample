#!/bin/sh

SRC_FILE=${DBM_HOME}/conf/dbm.error
INC_FILE=${CMNINC}/dbmErrorCode.h

echo "##############################  Make dbmErrorCode.h ( START ) ######################################"

#rm -f $INC_FILE

############################################################
# IF DEF
############################################################
echo "#ifndef __O_DBM_ERROR_CODE_H__"      > $INC_FILE
echo "#define __O_DBM_ERROR_CODE_H__  1"   >> $INC_FILE
echo "#ifdef __cplusplus"                  >> $INC_FILE
echo "extern \"C\""                        >> $INC_FILE
echo "{"                                   >> $INC_FILE
echo "#endif"                              >> $INC_FILE
echo ""

############################################################
# CODE DEF
############################################################
while read DEF CODE FORMAT
do
    if [ $DEF"X" = "X" ]; then
        echo ""                                 >> $INC_FILE
    elif [ `echo $DEF | cut -c 1` = '#' ]; then
        echo "/*"                               >> $INC_FILE
        echo "$DEF $CODE Error Code"            >> $INC_FILE
        echo "*/"                               >> $INC_FILE
    else
        printf "#define %-39s %s\n" $DEF $CODE  >> $INC_FILE
    fi
done < $SRC_FILE

############################################################
# IF DEF
############################################################
echo "#ifdef __cplusplus"     >> $INC_FILE
echo "};"                     >> $INC_FILE
echo "#endif"                 >> $INC_FILE
echo "#endif"                 >> $INC_FILE

echo "##############################  Make dbmErrorCode.h (SUCCESS) ######################################"

