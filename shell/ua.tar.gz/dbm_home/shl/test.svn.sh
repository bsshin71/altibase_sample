#!/bin/sh

########################################
# performance test script with some revision 
#
# usage:
#   test.svn.sh [test revision no]
#
# flow:
#   1. $HOME/cron 경로로 이동.
#   2. MMDD.REVNO 디렉토리 생성
#   3. build - 기본은 release 만일 해당 창에서 SetEnv.sh_debug 수행했으면 debug
#   4. metaManager Test 수행
#
#   9. 실패시 /tmp/$USER.env.log 환경변수 로그 생성
########################################

export LC_ALL=C

function err_chk()
{
    RESULT=$?

    if [ $RESULT -ne 0 ]
    then
        DT=`date "+%m/%d %H:%M:%S"`
        if [ $# -gt 0 ]
        then
            echo "[$DT] $1 (err=$RESULT)"
        else
            echo "[$DT] (err=$RESULT)"
        fi

        env > /tmp/$USER.env.log
        exit $RESULT
    fi
}

function build()
{
    target=$1
    export CURRDIR=`pwd`
    echo "[$target BUILD] - $CURRDIR"

    #현재 makefile에서 외부 설정을 받을 수 없다.
    #export CFLAGS="-O3"
    #export CXXFLAGS="-O3"
    #export LDFLAGS="-O3"

    # RELEASE 변수가 _debug 인지 여부를 결정
    source SetEnv.sh${RELEASE}
    make clean
    make
    err_chk "[$target] BUILD failed..."

    # make check
    # err_chk "[$target] UNIT TEST failed..."

    # make install
    # err_chk "[$target] INSTALL failed..."
}

function f_check()
{
    # RELEASE 변수가 _debug 인지 여부를 결정
    source SetEnv.sh${RELEASE}

    #ulimit -c unlimited
    # 필수적이지 않은 경우 Stack 크기를 조정하지 않는다.
    #ulimit -s unlimited

    echo ">> unitTest/metaManager"

    export DBM_SHM_PREFIX=test_${DBM_SHM_PREFIX}
    $DBM_HOME/shl/test.all2.sh
    # cd $GDSRC/unitTest/metaManager
    # time sh run.sh
    err_chk "[$target] f_check failed..."
    cd -
}

##################################################
# MAIN
#
# 1. 리턴값 중요 : 성공시 0, 실패시 non-zero
##################################################

#rmipc

# 전역변수
export SDT=`date "+%Y-%m-%d %H:%M:%S"`

#URL="svn://192.168.0.220/3rd_iter/trunk"
URL="svn://svn/3rd_iter/trunk"

# 인자가 없으면 최신 리비전 테스트
REVNO=`svn info $URL |grep "^Revision:" |awk '{print $2}'`
test $# -gt 0 && REVNO=$1

# cron 에서 실행된 경우
if [ "x"$PWD == "x"$HOME"/cron" ]
then

    # cron 에서 실행된 경우 SRCDIR를 고정하여 disk full 방지
    # 최근 1주칠치를 유지한다.
    SRCDIR=`date "+%u"`
else
    SRCDIR=`date "+%m%d"`.$REVNO
fi

if [ ! -d $HOME/cron ]
then
    mkdir $HOME/cron
fi

cd $HOME/cron

if [ ! -d ./log ]
then
    mkdir log
fi

if [ ! -d $SRCDIR ]
then
    mkdir $SRCDIR
fi

cd $SRCDIR
SRCDIR=`pwd`

# build 가 성공하면 test 만 재수행 가능
echo "### build ###"
if [ ! -f $SRCDIR/build.ok.$REVNO ]
then
    if [ ! -d $SRCDIR/dbmapi4comm ]
    then
        svn co -r $REVNO $URL .
        err_chk "SUBVERSION UPDATE failed..."
    else
        # 컴파일 안되는 리비젼을 수정 후 수행할때
        cd $SRCDIR
        svn update --accept mine-full
        make clean
    fi

    build "r$REVNO"

    DT=`date "+%m/%d %H:%M:%S"`
    echo "[$DT] build ok ($REVNO)" > $SRCDIR/build.ok.$REVNO
fi

echo ""
echo "### build check ###"
f_check

echo ""
#echo "### perf test ###"
#test_perf

echo "### OK ###"
rm -f /tmp/$USER.env.log
exit 0

