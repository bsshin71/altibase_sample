#!/bin/sh

run()
{
    cd $1
    echo ""
    echo "[`date "+%Y/%m/%d %H:%M:%S (%a)"`] start test (`basename $1`)"
    echo "----------------------------------------"

    time sh run.sh 
    rc=$?
    if [ "x"$rc != "x0" ]
    then
        echo "[`date "+%Y/%m/%d %H:%M:%S (%a)"`] test error (`basename $1`)"
        cd -
        exit $rc
    fi

    echo "[`date "+%Y/%m/%d %H:%M:%S (%a)"`]   end test (`basename $1`)"
    cd - > /dev/null
}

if [ "x"$LIBMODE != "xdebug" ]
then
    # Perf Test
    sleep 1; sync; sync; free
    run $DBM_DEV3/src/goldilocks/unitTest/API
    echo ""
    echo "!! 릴리즈모드에서는 기본성능을 맨앞에 위치하여, 매번 수행시마다. 한번씩 볼수있게 한다. !!"
    sleep 1
fi

# 2015.01.25 -okt- 시간이 오래 걸리는 테스트 이므로, 완료되면 test.all2.sh 로 이동한다. 
# echo "!! 당면한 POC 테스트가 먼저 위치 !!"
# run $DBM_DEV3/src/goldilocks/unitTest/orderbook_poc/poc3

run $DBM_HOME/demo

run $DBM_DEV3/src/goldilocks/unitTest/SegmentManager

run $DBM_DEV3/src/goldilocks/unitTest/metaManager

run $DBM_DEV3/src/goldilocks/unitTest/TransManager

run $DBM_DEV3/src/goldilocks/unitTest/util

if [ "x"$LIBMODE == "xdebug" ]
then
    # Perf Test
    run $DBM_DEV3/src/goldilocks/unitTest/API
fi

# Index Test
run $DBM_DEV3/src/goldilocks/unitTest/IndexManager

# Perf Test
run $DBM_DEV3/src/goldilocks/unitTest/API

echo "! "
echo "! 테스트가 완료되었습니다. 쌩유"
echo "! "; echo ""
exit 0

