/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmSelectRow
 */
#include <dbmAPI.h>
#include "demo.h"

#define LOOP 1000000

typedef struct data
{
    long long   s_BRANCH_NO;
    long long   s_ORDER_NO;
    char        s_ASK_BID[1];
    long long   s_ACCOUNT_NO;
    long long   s_ITEM_NO;
    long long   s_QUANTITY;
    long long   s_PRICE;
    long long   s_FILL_COUNT;
    long long   s_FILL_QUANTITY;
    long long   s_FILL_AMOUNT;
    long long   s_PTIME;
} data;

typedef struct data2
{
    int     c1;
    char    c2[10];
} data2;

typedef struct MARKET
{
    long long   market_no;
    char        yn_open[1];
    long long   ptime;
} MARKET;

typedef struct ITEM
{
    long long   item_no     ;
    char        item_name[64];
    char        yn_trade[1] ;
    long long   limit_up    ;
    long long   limit_down  ;
    long long   current     ;
    long long   ptime       ;
} ITEM;

typedef struct FILL
{
    long long   branch_no ;
    long long   order_no  ;
    long long   fill_count;
    long long   fill_time ;
    char        ask_bid[1];
    long long   account_no;
    long long   item_no   ;
    long long   quantity  ;
    long long   price     ;
    long long   ptime     ;
} FILL;

typedef struct BRANCH
{
    long long   branch_no   ;
    char        branch_name [32];
    long long   order_no    ;
    long long   ptime       ;
} BRANCH;

typedef struct BALANCE
{
    long long   account_no  ;
    long long   item_no     ;
    long long   quantity    ;
    long long   ask_quantity;
    long long   ptime       ;
} BALANCE;

typedef struct ACCOUNT
{
    long long   account_no  ;
    long long   branch_no   ;
    char        status[1]   ;
    long long   deposit     ;
    long long   used_deposit;
    long long   ptime       ;
} ACCOUNT;


void *thr_func( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    data*       pdata;
    int         rc;
    int         i;

    pdata = (data*) malloc ( sizeof(data) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, "ACCT_ORDER2" );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(data) );

    for ( i = 0; i < LOOP ; i++ )
    {

        pdata->s_BRANCH_NO = i;
        pdata->s_ORDER_NO = i;
        strcpy(pdata->s_ASK_BID,"A");
        pdata->s_ACCOUNT_NO = i;
        pdata->s_ITEM_NO = i;
        pdata->s_QUANTITY = i;
        pdata->s_PRICE = i;
        pdata->s_FILL_COUNT = i;
        pdata->s_FILL_QUANTITY = i;
        pdata->s_FILL_AMOUNT = i;
        pdata->s_PTIME = i;

        rc = dbmInsertRow ( &handle, "ACCT_ORDER2", pdata, sizeof(data) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}

void *thr_func2( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    data2*      pdata;
    int         rc;
    int         i;
    pdata = (data2*) malloc ( sizeof(data2) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, "Q2" );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(data2) );

    for ( i = 0; i < 10000; i++ )
    {

        pdata->c1 = i;
        sprintf(pdata->c2,"%d",i);

        rc = dbmEnqueue ( &handle, "Q2", pdata, sizeof(data2) );
        CHK_ERROR( "dbmEnqueue", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }


    memset ( pdata, 0x00, sizeof(data2) );
    for ( i = 0; i < 1000; i++ )
    {
        rc = dbmDequeue ( &handle, "Q2", pdata, 4000000 );
        CHK_ERROR( "dbmDequeue", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}

void *thr_func3( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    data*       pdata;
    int         rc;
    int         i;

    pdata = (data*) malloc ( sizeof(data) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, "ACCT_ORDER2" );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(data) );

    for ( i = 0; i < LOOP ; i++ )
    {

        pdata->s_BRANCH_NO = i;
        pdata->s_ORDER_NO = i;
        strcpy(pdata->s_ASK_BID,"A");
        pdata->s_ACCOUNT_NO = 10;
        pdata->s_ITEM_NO = 10;
        pdata->s_QUANTITY = 10;
        pdata->s_PRICE = 10;
        pdata->s_FILL_COUNT = 10;
        pdata->s_FILL_QUANTITY = 10;
        pdata->s_FILL_AMOUNT = 10;
        pdata->s_PTIME = 10;

        rc = dbmUpdateRow ( &handle, "ACCT_ORDER2", pdata );
        CHK_ERROR( "dbmUpdateRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}

void *thr_func4( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    MARKET*       pdata;
    int         rc;
    int         i;

    pdata = (MARKET*) malloc ( sizeof(MARKET) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, "MARKET2" );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(MARKET) );

    for ( i = 0; i < LOOP; i++ )
    {

        pdata->market_no = i;
        strcpy(pdata->yn_open,"A");
        pdata->ptime = i;

        rc = dbmInsertRow ( &handle, "MARKET2", pdata, sizeof(MARKET) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}

void *thr_func5( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    ITEM*       pdata;
    int         rc;
    int         i;

    pdata = (ITEM*) malloc ( sizeof(ITEM) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, "ITEM2" );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(ITEM) );

    for ( i = 0; i < LOOP; i++ )
    {

        pdata->item_no= i;
        strcpy(pdata->item_name,"DATA");
        strcpy(pdata->yn_trade ,"A");
        pdata->limit_up = i;
        pdata->limit_down = i;
        pdata->current = i;
        pdata->ptime = i;

        rc = dbmInsertRow ( &handle, "ITEM2", pdata, sizeof(ITEM) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}

void *thr_func6( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    FILL*       pdata;
    int         rc;
    int         i;

    pdata = (FILL*) malloc ( sizeof(FILL) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, "FILL2" );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(FILL) );

    for ( i = 0; i < LOOP; i++ )
    {

        pdata->branch_no = i;
        pdata->order_no = i;
        pdata->fill_count = i;
        pdata->fill_time = i;
        strcpy(pdata->ask_bid,"A");
        pdata->account_no = i;
        pdata->item_no = i;
        pdata->quantity = i;
        pdata->price = i;
        pdata->ptime = i;

        rc = dbmInsertRow ( &handle, "FILL2", pdata, sizeof(FILL) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}

void *thr_func7( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    BRANCH*     pdata;
    int         rc;
    int         i;

    pdata = (BRANCH*) malloc ( sizeof(BRANCH) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, "BRANCH2" );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(BRANCH) );

    for ( i = 0; i < LOOP; i++ )
    {

        pdata->branch_no = i;
        strcpy(pdata->branch_name ,"DATA");
        pdata->order_no = i;
        pdata->ptime = i;

        rc = dbmInsertRow ( &handle, "BRANCH2", pdata, sizeof(BRANCH) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}

void *thr_func8( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    BALANCE*    pdata;
    int         rc;
    int         i;

    pdata = (BALANCE*) malloc ( sizeof(BALANCE) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, "BALANCE2" );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(BALANCE) );

    for ( i = 0; i < LOOP; i++ )
    {

        pdata->account_no = i;
        pdata->item_no = i;
        pdata->quantity = i;
        pdata->ask_quantity = i;
        pdata->ptime = i;

        rc = dbmInsertRow ( &handle, "BALANCE2", pdata, sizeof(BALANCE) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}


void *thr_func9( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    ACCOUNT*    pdata;
    int         rc;
    int         i;

    pdata = (ACCOUNT*) malloc ( sizeof(ACCOUNT) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, "ACCOUNT2" );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(ACCOUNT) );

    for ( i = 0; i < LOOP; i++ )
    {

        pdata->account_no = i;
        pdata->branch_no = i;
        strcpy(pdata->status, "A");
        pdata->deposit = i;
        pdata->used_deposit = i;
        pdata->ptime = i;

        rc = dbmInsertRow ( &handle, "ACCOUNT2", pdata, sizeof(ACCOUNT) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}

int main(int argc,char **argv)
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    pthread_t   tid[10];
    int         rc;
    int         i;

    for ( i = 0; i < 9; i++ )
    {
        if( i == 0 )
        {
            rc = pthread_create ( &tid[i], NULL, thr_func, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }

        if( i == 1 )
        {
            rc = pthread_create ( &tid[i], NULL, thr_func2, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }

        if( i == 2 )
        {
            rc = pthread_create ( &tid[i], NULL, thr_func9, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }

        if( i == 3 )
        {
            rc = pthread_create ( &tid[i], NULL, thr_func4, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }

        if( i == 4 )
        {
            rc = pthread_create ( &tid[i], NULL, thr_func5, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }
        if( i == 5 )
        {
            rc = pthread_create ( &tid[i], NULL, thr_func6, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }
        if( i == 6 )
        {
            rc = pthread_create ( &tid[i], NULL, thr_func7, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }
        if( i == 7 )
        {
            rc = pthread_create ( &tid[i], NULL, thr_func8, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }
        if( i == 8 )
        {
//            /* update 시간을 주어 해당 Update 처리 예문 */
//            sleep(5);

            rc = pthread_create ( &tid[i], NULL, thr_func3, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }

        usleep ( 100000 );
    }

    for ( i = 0; i < 9; i++ )
    {
        rc = pthread_join ( tid[i], NULL );
        CHK_ERROR( "pthread_join", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return 0;
}

