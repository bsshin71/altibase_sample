#define _DBM_SRC

#include <dbmAPI.h>

typedef struct TABLE
{
    char c1[20];
    int c2;
    int c3;
} TABLE;


#define UNDO_NAME   "demo"
#define T1          "T1"

//#define THR  1
#define THR  4
//#define THR  6
//#define THR  8
//#define THR  12
//#define THR  16
#define LOOP 5000000    // 500만
//#define LOOP 10000000 // 1천만
//#define LOOP 50000000 // 5천만

volatile int go = 0;

typedef struct
{
    int start;
    int aCount;
} PARAM;


static void* thr1( void* );
static void* thr2( void* );


void* thr1( void* param )
{
    dbmHandle sHandle;
    int rc;
    int i;
    int		nStart;
    int		nEnd;
    TABLE  data;
    struct timespec start, end;


    nStart = (int)(((PARAM*)param)->start);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);


    rc = dbmInitHandle (&sHandle, UNDO_NAME);
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, T1);
    if (rc)
    {
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    while ( go == 0 ) { sched_yield(); }

    clock_gettime(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    //for (i=nEnd-1; i>=nStart; i--)
    {
        //rc = dbmPrepareTable (&sHandle, T1);

        memset(&data, 0x00, sizeof(TABLE));
        sprintf(data.c1, "%019d", i);
        //data.c1 = i;
        data.c2 = i;
        data.c3 = 0;

        rc = dbmInsertRow (&sHandle, T1, &data, sizeof(TABLE));
        if (rc)
        {
            printf("Insert (%s) (row=%d) rc=%d (%s)\n", T1, i, rc, dbmGetError(rc) );
            exit(-1);
        }

        rc = dbmCommit (&sHandle);
        if (rc)
        {
            //printf("Commit t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }

#if 0
        if (i !=0 && (i % 10000) == 0) printf ("%d rows inserted..\n", i - nStart);
#endif
    }
    clock_gettime(CLOCK_REALTIME, &end);
    printf( "LOOP=%d, i=%d, Elap=%.9f (tid=%d)\n",
            LOOP, i, (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0)), gettid_s() );

    dbmFreeHandle (&sHandle);

    return NULL;
} /* thr1 */


void* thr2( void* param )
{
    dbmHandle sHandle;
    int rc;
    int i;
    int		nStart;
    int		nEnd;
    TABLE  data;
    struct timespec start, end;


    nStart = (int)(((PARAM*)param)->start);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);


    rc = dbmInitHandle (&sHandle, UNDO_NAME);
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, T1);
    if (rc)
    {
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    while ( go == 0 ) { sched_yield(); }

    clock_gettime(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    {
        memset(&data, 0x00, sizeof(TABLE));
        sprintf(data.c1, "%019d", i);
        //data.c1 = i;
        data.c2 = i;

        rc = dbmSelectRow (&sHandle, T1, &data);
        if (rc)
        {
            printf("SelectFail (%s) (row=%d) rc=%d (%s)\n", T1, i, rc, dbmGetError(rc) );
            exit(-1);
        }

#if 0
        rc = dbmCommit (&sHandle);
        if (rc)
        {
            printf("Commit t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }
#endif
#if 0
        if (i !=0 && (i % 10000) == 0) printf ("%d rows inserted..\n", i - nStart);
#endif
    }
    clock_gettime(CLOCK_REALTIME, &end);
    printf( "LOOP=%d, i=%d, Elap=%.9f (tid=%d)\n",
            LOOP, i, (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0)), gettid_s() );

    dbmFreeHandle (&sHandle);
    return NULL;
} /* thr2 */


void* thr3( void* param )
{
    dbmHandle sHandle;
    int rc;
    int i, j;
    int		nStart;
    int		nEnd;
    TABLE  data;
    struct timespec start, end;


    nStart = (int)(((PARAM*)param)->start);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);


    rc = dbmInitHandle (&sHandle, UNDO_NAME);
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, T1);
    if (rc)
    {
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    while ( go == 0 ) { sched_yield(); }

    j = 1784;
    clock_gettime(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    {
        memset(&data, 0x00, sizeof(TABLE));
        sprintf(data.c1, "%019d", j);
        //data.c1 = j;
        data.c2 = j;

        rc = dbmSelectForUpdateRow (&sHandle, T1, &data);
        if (rc)
        {
            printf("SelectFail (%s) (row=%d) rc=%d (%s)\n", T1, i, rc, dbmGetError(rc) );
            break;
        }

        data.c3 = data.c3 + 1;
        rc = dbmUpdateRow (&sHandle, T1, &data);
        if (rc)
        {
            printf("SelectFail (%s) (row=%d) rc=%d (%s)\n", T1, i, rc, dbmGetError(rc) );
            break;
        }

#if 1
        rc = dbmCommit (&sHandle);
        if (rc)
        {
            printf("Commit t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }
#endif
#if 0
        if (i !=0 && (i % 10000) == 0) printf ("%d rows inserted..\n", i - nStart);
#endif
    }
    clock_gettime(CLOCK_REALTIME, &end);
    printf( "LOOP=%d, i=%d, Elap=%.9f (tid=%d)\n",
            LOOP, i, (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0)), gettid_s() );

    memset(&data, 0x00, sizeof(TABLE));
    sprintf(data.c1, "%019d", j);
    //data.c1 = j;
    data.c2 = j;

    rc = dbmSelectRow (&sHandle, T1, &data);
    if (rc)
    {
        printf("SelectFail (%s) (row=%d) rc=%d (%s)\n", T1, i, rc, dbmGetError(rc) );
        exit(-1);
    }
    printf("last Select c3 = %d\n", data.c3);


    dbmFreeHandle (&sHandle);
    return NULL;
} /* thr3 */


////////////////////////////////////////
// MAIN
////////////////////////////////////////
int main ( int argc , char** argv )
{
    pthread_t tid[THR];
    PARAM   param[THR];
    int     start;
    int     i;

    // Table creation
    {
	    dbmHandle sHandle;
        char    sSql[1024];
        char*   pChar = NULL;
        int     rc;

        rc = dbmInitHandle ( &sHandle, UNDO_NAME );
        if (rc)
        {
            printf( "Connect Fail. rc=%d (err=%d,tid=%d)\n", rc, errno, gettid_s() );
            exit( rc );
        }

        dbmDropTable ( &sHandle, T1 );

        pChar = (char*)_dbm_getArg( "dbm_table_type:" );
        sprintf ( sSql, "create %s table %s ( "
                   "c1 char(20), "
                   "c2 int, "
                   "c3 int ) "
                  "init 10000000 extend 10000000 max 120000000",
                  (pChar==NULL)?"":pChar,
                   T1 );
        rc = dbmExecuteDDL ( &sHandle, sSql ) ;
        if (rc)
        {
            printf( "DDL Fail. rc=%d (err=%d,tid=%d)\n", rc, errno, gettid_s() );
            exit( rc );
        }

        sprintf ( sSql, "create index idx_%s on %s ( c2 )", T1, T1 );
        rc = dbmExecuteDDL ( &sHandle, sSql ) ;
        if (rc)
        {
            printf( "DDL Fail. rc=%d (err=%d,tid=%d)\n", rc, errno, gettid_s() );
            exit( rc );
        }

        dbmFreeHandle ( &sHandle );
    }


#if 1
    // Perf Test
    go = 0;
    start = 0;
    for (i=0;i<THR;i++)
    {
        param[i].start = start;
        param[i].aCount = 0;
        pthread_create(&tid[i], NULL, thr1, &param[i]);
        start = start + (LOOP / THR);
    }

    go = 1;
    for (i=0;i<THR;i++)
    {
        pthread_join(tid[i], NULL);
    }
#endif
    if ( argc > 1 )
    {
        printf ( "too many args [%s]", argv[1] ); // dummy for no-build-warning
        exit ( -1 );
    }

    //exit(0);

#if 1
    // Perf Test
    go = 0;
    start = 0;
    for (i=0;i<THR;i++)
    {
        param[i].start = start;
        param[i].aCount = 0;
        pthread_create(&tid[i], NULL, thr2, &param[i]);
        start = start + (LOOP / THR);
    }
    go = 1;
    for (i=0;i<THR;i++)
    {
        pthread_join(tid[i], NULL);
    }
#endif

#if 1
    // Perf Test
    go = 0;
    start = 0;
    for (i=0;i<THR;i++)
    {
        param[i].start = start;
        param[i].aCount = 0;
        pthread_create(&tid[i], NULL, thr3, &param[i]);
        start = start + (LOOP / THR);
    }
    go = 1;
    for (i=0;i<THR;i++)
    {
        pthread_join(tid[i], NULL);
    }
#endif

    return 0;
}
