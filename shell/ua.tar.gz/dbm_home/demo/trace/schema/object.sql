connect demo;
show instance;

drop table T1;
drop table T2;
drop queue Q1;
drop queue Q2;
drop table T1_DIRECT;
drop table SEQ1;

create table T1 ( c1 int, c2 char(10) );
create index T1_IDX1 on T1 ( c1 );
create index T1_IDX2 on T1 ( c2 );

create table T2 ( eno int, ename char(10), ename2 char(10), eno2 int );
create index T2_IDX1 on T2 ( eno );

create table T3 ( c1 int, c2 char(10) );
create non unique index T3_IDX1 on T3 ( c1 );

create queue Q1 msgsize 600 init 100 extend 100 max 100000;
create queue Q2 msgsize 600;
create direct table T1_DIRECT ( c1 int );
create index T1_DIRECT_IDX1 on T1_DIRECT c1;
create direct table T2_DIRECT ( c1 int , c2 char(10) );
create index T2_DIRECT_IDX1 on T2_DIRECT c1;

create table ACCT_ORDER
(
    branch_no        long,
    order_no         long,
    ask_bid          char(1),
    account_no       long,
    item_no	         long,
    quantity         long,
    price            long,
    fill_count       long,
    fill_quantity    long,
    fill_amount      long,
    ptime            long
);

create index ACCT_ORDER_IDX1 on ACCT_ORDER branch_no,order_no;

create table MARKET
(
    market_no   long,
    yn_open     char(1),
    ptime       long
);

create index ix_market on MARKET ( market_no );

create table ITEM
(
    item_no     long,
    item_name   char(64),
    yn_trade    char(1),
    limit_up    long,
    limit_down  long,
    current     long,
    ptime       long
);

create index ix_item on ITEM ( item_no );

create table FILL
(
    branch_no   long,
    order_no    long,
    fill_count  long,
    fill_time   long,
    ask_bid     char(1),
    account_no  long,
    item_no     long,
    quantity    long,
    price       long,
    ptime       long
);

create index ix_fill on FILL ( branch_no, order_no, fill_count );

create table BRANCH
(
    branch_no   long,
    branch_name char(32),
    order_no    long,
    ptime       long
);

create index ix_branch on BRANCH ( branch_no );

create table BALANCE
(
    account_no  long,
    item_no     long,
    quantity    long,
    ask_quantity    long,
    ptime       long
);

create index ix_balance on BALANCE ( account_no, item_no );

create table ACCOUNT
(
    account_no      long,
    branch_no       long,
    status          char(1),
    deposit         long,
    used_deposit    long,
    ptime           long
) ;

create index ix_account on ACCOUNT ( account_no );

create sequence SEQ1;

