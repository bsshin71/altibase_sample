truncate table T1 ;
truncate table T2 ;
truncate table T3 ;
truncate queue Q1 ;
truncate queue Q2 ;
truncate table T1_DIRECT ;
truncate table T2_DIRECT ;
truncate table ACCT_ORDER
truncate table MARKET
truncate table ITEM
truncate table FILL
truncate table BRANCH
truncate table BALANCE
truncate table ACCOUNT
truncate sequence SEQ1;
