# rm -f $DBM_HOME/dic/*
# rm -f $DBM_HOME/WAL/*
# rm -rf /dev/shm/$DBM_SHM_PREFIX/\$sys_dic_inst
# rm -rf /dev/shm/$DBM_SHM_PREFIX/demo

metaManager << EOF_
--initdb;
--connect \$sys_dic_inst
--drop instance demo;
--create instance demo;
connect demo;

drop table item;
create table item
itemcd char 8
itemnm char 20
highprc double 10 2
lowprc double 10 2
smaxprc double 10 2
minprc double 10 2
currprc double 10 2
trdqty long 15 0
trdamt long 15 0
init 10000 extend 10000 max 1000000;
create index item_idx1 on item itemcd;

drop table accnt;
create table accnt
accntno char 8
accntnm char 20
ablemoney long 15 0
unsettle long 15 0
init 30000 extend 10000 max 1000000;
create index accnt_idx1 on accnt accntno;

drop table ordno;
create table ordno
brcd char 3
ordno long 8 0
init 10 extend 100 max 1000;
create index ordno_idx1 on ordno brcd;

drop table order;
create table order
accntno char 8
itemcd  char 8
ordprc  long 8 0
ordqty  long 8 0
ordno   long 8 0
init 1000000 extend 100000 max 10000000;
create index order_idx1 on order accntno itemcd ordno;
create index order_idx2 on order ordno;
list
exit

EOF_
