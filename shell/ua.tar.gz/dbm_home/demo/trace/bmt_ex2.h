#ifndef  __TEST30_H__
#define  __TEST30_H__

typedef struct
{
    char   itemcd  [8];
    char   itemnm  [20];
    long   highprc;
    long   lowprc ;
    long   smaxprc;
    long   minprc ;
    long   currprc;
    long   trdqty ;
    long   trdamt ;
} item;


typedef struct
{
    char    accntno [8];
    char    accntnm [20];
    long    ablemoney;
    long    unsettle;
} accnt;


typedef struct
{
    char    brcd[3];
    long    ordno;
} ordno;



typedef struct
{
    char   accntno [8];
    char   itemcd  [8];
    long   ordprc;
    long   ordqty;
    long   ordno;
} order;

#endif /* __TEST30_H__ */
