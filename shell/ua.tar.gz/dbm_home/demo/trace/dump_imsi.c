#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>

typedef struct dbmReplSeqInfo
{
    int         sTxID;            //mTxID
    long long   sLSN;             //mLSN
    int         sCurFileNo;       //currFileNo
    int         sTotalBlockNo;    // block transaction 에서의 block count
    int         sTranTotalSize;   // block transaction total size

    long long   sSeq;             // check sequence
    long long   sMagicNo;         // check value

} dbmReplSeqInfo;

typedef struct queuedLogBlock
{
    char        data[512];
} queuedLogBlock;


typedef struct  dbmLogFileHeader
{
    long long   mEndLSN ;
} dbmLogFileHeader;


typedef enum dbmLogType
{
    DBM_ALLOC_SLOT_LOG              = 1
  , DBM_ALLOC_IDX_SLOT_LOG
  , DBM_FREE_SLOT_LOG
  , DBM_INSERT_SLOT_LOG
  , DBM_UPDATE_SLOT_LOG

  , DBM_DELETE_SLOT_LOG
  , DBM_INSERT_INDEX_LOG
  , DBM_DELETE_INDEX_LOG
  , DBM_DELETE_DATA_LOG
  , DBM_SELECT_FOR_UPDATE_LOG

  , DBM_TRUNCATE_LOG
  , DBM_ENQUE_LOG
  , DBM_DEQUE_LOG
  , DBM_DDL_CREATE_QUEUE_LOG
  , DBM_DDL_CREATE_TABLE_LOG

  , DBM_DDL_CREATE_DIRECT_LOG
  , DBM_DDL_DROP_TABLE_LOG
  , DBM_DDL_CREATE_INDEX_LOG
  , DBM_DDL_DROP_INDEX_LOG
  , DBM_DDL_DROP_QUEUE_LOG

  , DBM_DDL_CREATE_TRIG_LOG
  , DBM_DDL_DROP_TRIG_LOG
  , DBM_DDL_DROP_USER_LOG
  , DBM_LOCK_ROW_LOG

  , DBM_DEFER_INSERT_LOG
  , DBM_DEFER_UPDATE_LOG
  , DBM_BEGIN_TX_LOG
  , DBM_REPL_COMMIT_LOG
  , DBM_REPL_ROLLBACK_LOG

  , DBM_COMMIT_LOG
  , DBM_ROLLBACK_LOG
  , DBM_COMMIT_ACK_LOG
  , DBM_CLEAR_DEFER_LOG
  , DBM_DEQUE_CONFIRM_LOG

  , DBM_DUMMY_ACK_LOG
} dbmLogType;

typedef struct dbmTransLog
{
    dbmLogType      mLogType;         // 로그형태
    int             mObjectID;        // ObjectID
    long long       mSlot  ;          // Slot 번호
    long long       mSCN ;            // SCN 번호
    char            mObjectName[32] ; // ObjectName
    char*           mImagePtr;        // Image 주소
    int             mImageSize;       // Image 크기
    long long       mLSN ;            // LSN
} dbmTransLog ;

/****************************************************************
 * Disk 에 사용할 LogBlock Header
 ****************************************************************/
typedef struct dbmLogBlockHeader
{
    long long   mLSN ;              // 이번에 쓰여질 LSN
    int         mTotalBlockNo;      // 전체 Block 의 갯수
    int         mCurrentBlockNo;    // 내가 쓰여진 Block 의 갯수
    int         mTranTotalSize;     // 본 트렌젝션의 전체 사이즈
    int         mIsCompressF;
    struct timeval mWriteTime;      // 본 블럭이 쓰여진 시점
} dbmLogBlockHeader;


typedef struct dbmReplRecvSeq
{
    long long   sSeqOffset;
    long long   sSeq;
} dbmReplRecvSeq;


#define DBM_LOG_BLOCK_SIZE 512

int main()
{
    long long   sMagicNo = (long long)(1365678123409192L);
    int         sGap;
    char*       sImage = NULL;
    int         fd;
    int         sRC;

    dbmReplSeqInfo* mSeqInfo;
    queuedLogBlock sQueueBlock;
    dbmLogFileHeader sLogFileHeader;
    dbmTransLog* aLog;
    dbmLogBlockHeader   *sLogBlockHeader;
    dbmReplRecvSeq  sRecvSeq;


    mSeqInfo = (dbmReplSeqInfo*)malloc(sizeof(dbmReplSeqInfo));

    memset(mSeqInfo, 0x00, sizeof(dbmReplSeqInfo));
    memset(&sRecvSeq, 0x00, sizeof(dbmReplRecvSeq));

#if 0 // write
    mSeqInfo->sTxID = 1;
    mSeqInfo->sLSN = 1;
    mSeqInfo->sTotalBlockNo = 10;
    mSeqInfo->sTranTotalSize = 100;
    mSeqInfo->sSeq = 1;
    mSeqInfo->sMagicNo = sMagicNo;


    fd = open ( "/home/son2865/tmp/socket/demo.repl.seq", O_RDWR | O_CREAT , 0666 ) ;
    if(fd < 0)
    {
        printf("open error \n");
        free(mSeqInfo);
        exit(0);
    }


    sRC = pwrite(fd, mSeqInfo, sizeof(dbmReplSeqInfo), sizeof(dbmReplSeqInfo)*0);

    if( sRC != sizeof(dbmReplSeqInfo) )
    {
        printf("read error \n");
        free(mSeqInfo);
        exit(0);
    }

    free(mSeqInfo);

#endif

#if 0 // open
    fd = open("/dev/shm/WAL/demo.repl.seq", O_RDONLY, 0666);
    //fd = open("/home/son2865/dbm/trunk/dbm_home/WAL/demo.repl.seq", O_RDONLY, 0666);
    //fd = open("/home/son2865/tmp/socket/demo.repl.seq", O_RDONLY, 0666);
    if(fd < 0)
    {
        printf("open error \n");
        free(mSeqInfo);
        exit(0);
    }


    lseek(fd , sizeof(dbmReplSeqInfo) , SEEK_SET);

    while((int)(read(fd,mSeqInfo,sizeof(dbmReplSeqInfo))) == sizeof(dbmReplSeqInfo))
    {
        printf("sMagicNo[%ld] sTxID[%ld] sLSN[%d]  sCurFileNo[%d] sTotalBlockNo[%d] sTranTotalSize[%d] \n",
                mSeqInfo->sMagicNo, mSeqInfo->sTxID, mSeqInfo->sLSN, mSeqInfo->sCurFileNo,mSeqInfo->sTotalBlockNo,mSeqInfo->sTranTotalSize);


    }

    free(mSeqInfo);
#endif

#if 0 // open
    fd = open("/u4/hwson/demo.repl.seq", O_RDONLY, 0666);
    //fd = open("/home/son2865/dbm/trunk/dbm_home/WAL/demo.repl.seq", O_RDONLY, 0666);
    //fd = open("/home/son2865/tmp/socket/demo.repl.seq", O_RDONLY, 0666);
    if(fd < 0)
    {
        printf("open error \n");
        free(mSeqInfo);
        exit(0);
    }


    //lseek(fd , 123023232 , SEEK_SET);
    lseek(fd , 123023280 , SEEK_SET);

    sRC = read(fd,mSeqInfo,sizeof(dbmReplSeqInfo));

    if( sRC != sizeof(dbmReplSeqInfo) )
    {
        printf("read failure!!! [%d] \n", sRC );
    }
    else
    {
        printf("[%d] \n", sizeof(dbmReplSeqInfo));
        printf("sMagicNo[%ld] sTxID[%ld] sLSN[%d]  sCurFileNo[%d] sTotalBlockNo[%d] sTranTotalSize[%d] \n",
                mSeqInfo->sMagicNo, mSeqInfo->sTxID, mSeqInfo->sLSN, mSeqInfo->sCurFileNo,mSeqInfo->sTotalBlockNo,mSeqInfo->sTranTotalSize);
    }


    free(mSeqInfo);
#endif

#if 0 // gap file open
    fd = open("/home/son2865/dbm/trunk/dbm_home/WAL/demo.gap.seq", O_RDONLY, 0666);
    //fd = open("/home/son2865/tmp/socket/demo.repl.seq", O_RDONLY, 0666);
    if(fd < 0)
    {
        printf("open error \n");
        free(mSeqInfo);
        exit(0);
    }


    //lseek(fd , sizeof(int) , SEEK_SET);

    while((int)(read(fd,&sGap,sizeof(int))) == sizeof(int))
    {
        printf("gap[%d] \n", sGap);
    }
#endif

#if 1 // open
    //fd = open("/home/son2865/dbm/trunk/dbm_home/WAL/demo.tx.4.0", O_RDONLY, 0666);
    //fd = open("/u4/hwson/demo.tx.0.46", O_RDONLY, 0666);
    fd = open("/u4/hwson/demo.tx.5.79", O_RDONLY, 0666);
    //fd = open("/home/son2865/dbm/trunk/dbm_home/WAL/demo.tx.3.0", O_RDONLY, 0666);
    //fd = open("/home/son2865/tmp/socket/demo.repl.seq", O_RDONLY, 0666);
    if(fd < 0)
    {
        printf("open error \n");
        free(mSeqInfo);
        close(fd);
        exit(0);
    }

    sRC = read( fd , &sLogFileHeader, DBM_LOG_BLOCK_SIZE );
    if( sRC != DBM_LOG_BLOCK_SIZE )
    {
        printf("read error[%d] \n", sRC );
        free(mSeqInfo);
        close(fd);
        exit(0);
    }


    while(1)
    {
        sRC = read( fd , &sQueueBlock, DBM_LOG_BLOCK_SIZE );
        if( sRC != DBM_LOG_BLOCK_SIZE )
        {
            printf("read error[%d] \n", sRC);
            free(mSeqInfo);
            close(fd);
            exit(0);
        }

        sLogBlockHeader = (dbmLogBlockHeader *)sQueueBlock.data;
        //sHeader         = (dbmLogBlockHeader *)mFirstBlock[sCurrentIdx].data

        //mFirstBlock[sCurrentIdx].data + sizeof (dbmLogBlockHeader)
        aLog = (dbmTransLog*)((char*)sQueueBlock.data+sizeof(dbmLogBlockHeader));
        //aLog = (dbmTransLog*)(sLogBlockHeader + sizeof(dbmLogBlockHeader));
        //printf("Type[%d] image size[%d] slot[%d] objectName[%s] block lsn[%ld] block Total size[%d]\n",
        //        aLog->mLogType, aLog->mImageSize, aLog->mSlot, aLog->mObjectName, sLogBlockHeader->mLSN, sLogBlockHeader->mTranTotalSize );
        //sImage = (char*)sQueueBlock.data + sizeof(dbmTransLog) , (*aLog)->mImageSize;
        sImage = (char*)aLog + sizeof(dbmTransLog);

        //if( sLogBlockHeader->mLSN == 2562984 )
        if( sLogBlockHeader->mLSN == 2562985 )
        {
            printf("Type[%d] image size[%d] slot[%d] objectName[%s] block lsn[%ld] block Total size[%d]\n",
                    aLog->mLogType, aLog->mImageSize, aLog->mSlot, aLog->mObjectName, sLogBlockHeader->mLSN, sLogBlockHeader->mTranTotalSize );

            printf("data[%ld][%ld][%.1s][%ld] \n", *(long long*)sImage, *(long long*)(sImage+8),(char*)sImage+16,*(long long*)(sImage+24));
        }
    }


    free(mSeqInfo);
#endif

#if 0
    fd = open("/u4/hwson/demo.tx.4.0", O_RDONLY, 0666);
    if(fd < 0)
    {
        printf("open error \n");
        free(mSeqInfo);
        exit(0);
    }

    //sRC = read( fd , &sLogFileHeader, sizeof(dbmLogFileHeader));
    //if( sRC != sizeof(dbmLogFileHeader) )
    sRC = read( fd , &sLogFileHeader, DBM_LOG_BLOCK_SIZE );
    if ( sRC != DBM_LOG_BLOCK_SIZE )
    {
        printf("read error \n");
        free(mSeqInfo);
        exit(0);
    }


    while(1)
    {
        sRC = read( fd , &sQueueBlock, DBM_LOG_BLOCK_SIZE );
        if( sRC != 512 )
        {
            printf("read error \n");
            free(mSeqInfo);
            exit(0);
        }

        sLogBlockHeader = (dbmLogBlockHeader *)sQueueBlock.data;
        //sHeader         = (dbmLogBlockHeader *)mFirstBlock[sCurrentIdx].data

        //mFirstBlock[sCurrentIdx].data + sizeof (dbmLogBlockHeader)
        //aLog = (dbmTransLog*)(sQueueBlock.data+sizeof(dbmLogBlockHeader));
        aLog = (dbmTransLog*)((char*)sLogBlockHeader + sizeof(dbmLogBlockHeader));
        printf("image size[%d] slot[%d] objectName[%s] \n", aLog->mImageSize, aLog->mSlot, aLog->mObjectName );
    }


    free(mSeqInfo);
#endif



#if 0 // open
    //fd = open("/home/son2865/dbm/trunk/dbm_home/WAL/demo.repl.info", O_RDONLY, 0666);
    fd = open("/dev/shm/WAL/demo.repl.info", O_RDONLY, 0666);
    if(fd < 0)
    {
        printf("open error \n");
        free(mSeqInfo);
        exit(0);
    }

    sRC = pread(fd,&sRecvSeq,sizeof(dbmReplRecvSeq),0);

    if( sRC != sizeof(dbmReplRecvSeq) )
    {
        printf("read error \n");
        free(mSeqInfo);
        exit(0);
    }

    printf("sSeqOffset[%ld] sSeq[%ld]  \n", sRecvSeq.sSeqOffset, sRecvSeq.sSeq);

    free(mSeqInfo);
#endif

    close(fd);
    return 0;

}
