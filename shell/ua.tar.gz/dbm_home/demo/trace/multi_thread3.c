/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmSelectRow
 */
#include <dbmAPI.h>
#include "demo.h"

typedef struct data
{
    long long   s_BRANCH_NO;
    long long   s_ORDER_NO;
    char        s_ASK_BID[1];
    long long   s_ACCOUNT_NO;
    long long   s_ITEM_NO;
    long long   s_QUANTITY;
    long long   s_PRICE;
    long long   s_FILL_COUNT;
    long long   s_FILL_QUANTITY;
    long long   s_FILL_AMOUNT;
    long long   s_PTIME;
} data;


void *thr_func( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    data*       pdata;
    int         rc;
    int         i;

    pdata = (data*) malloc ( sizeof(data) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, "ACCT_ORDER" );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(data) );

    for ( i = 0; i < 10000000; i++ )
    {

        pdata->s_BRANCH_NO = i;
        pdata->s_ORDER_NO = i;
        strcpy(pdata->s_ASK_BID,"A");
        pdata->s_ACCOUNT_NO = i;
        pdata->s_ITEM_NO = i;
        pdata->s_QUANTITY = i;
        pdata->s_PRICE = i;
        pdata->s_FILL_COUNT = i;
        pdata->s_FILL_QUANTITY = i;
        pdata->s_FILL_AMOUNT = i;
        pdata->s_PTIME = i;

        rc = dbmInsertRow ( &handle, "ACCT_ORDER", pdata, sizeof(data) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}


#if 0
void *thr_func2( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    data*       pdata;
    int         rc;
    int         i;
    pdata = (data*) malloc ( sizeof(data) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, QUEUE_NAME );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(data) );

    for ( i = 0; i < 10000; i++ )
    {

        pdata->c1 = i;
        sprintf(pdata->c2,"%d",i);

        rc = dbmEnqueue ( &handle, QUEUE_NAME, pdata, sizeof(data) );
        CHK_ERROR( "dbmEnqueue", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }


    memset ( pdata, 0x00, sizeof(data) );
    for ( i = 0; i < 1000; i++ )
    {
        rc = dbmDequeue ( &handle, QUEUE_NAME, pdata, 4000000 );
        CHK_ERROR( "dbmDequeue", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}
#endif
int main(int argc,char **argv)
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    pthread_t   tid[4];
    int         rc;
    int         i;

    for ( i = 0; i < 1; i++ )
    {
        if( i == 0 )
        {
            rc = pthread_create ( &tid[i], NULL, thr_func, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }

#if 0
        if( i == 1 )
        {
            rc = pthread_create ( &tid[i], NULL, thr_func2, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }
#endif
        usleep ( 100000 );
    }

    for ( i = 0; i < 1; i++ )
    {
        rc = pthread_join ( tid[i], NULL );
        CHK_ERROR( "pthread_join", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return 0;
}

