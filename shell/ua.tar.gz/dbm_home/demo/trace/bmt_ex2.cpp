#define _DBM_SRC
#include <dbmAPI.h>

#include "bmt_ex2.h"


/************************************************
 * define
************************************************/
#define LOOP    250000      // 한 쓰레드당 25만건씩 주문처리를 한다.
#define THR     4

#undef  _LOG
#define _LOG(a,...)         { printf( "%s:%d "a, __FILE__, __LINE__, ##__VA_ARGS__); fflush(stdout); }
//#define _LOG(a,...)       { printf( a, ##__VA_ARGS__); }

#define DBError(a,b)        if ( a != 0 ) DBError_(a, b, __FILE__, __FUNCTION__, __LINE__ )


/************************************************
 * struct
************************************************/
typedef struct
{
    int     start;
    double  tps;
} PARAM;


/************************************************
 * static function
************************************************/
static void DBError_( int rc , dbmHandle *aHandle, const char* file, const char* func, int line );
static void init ( );
static void* run ( void *param );

int     g_debug_ix = -1;     // 루프내의 어디서 죽었는지 알고자 할때.


/************************************************
 * MAIN
************************************************/
int main ( int argc , char **argv )
{
    pthread_t   tid[THR];
    PARAM       param[THR];
    double      sum = 0;
    int         i;

    if ( argc > 1 )
    {
        // 인자가 있으면 초기 데이타 구축
        _LOG ( "@@ START - data initialize @@\n" );
        init ( );
        exit ( 0 );
    }

    _LOG ( "@@ START - main test @@\n" );
    for ( i = 0; i < THR; i++ )
    {
        param[i].tps = 0;
        pthread_create ( &tid[i], NULL, run, &param[i] );
    }

    for ( i = 0; i < THR; i++ )
    {
        pthread_join ( tid[i], NULL );
    }

    for ( i = 0; i < THR; i++ )
    {
        sum = sum + param[i].tps;
    }

    _LOG ( "[SUM] Latency Average: %.6f,  Throughput (Call/sec): %.1f\n", sum / THR, (double) ( 1.0 / sum ) );

    return 0;
}


/************************************************
 * DBM 에러가 발생하는지 체크한다.
 ************************************************/
void DBError_ ( int aRC , dbmHandle *aHandle, const char* file, const char* func, int line )
{
    //if ( rc == 0 ) return;    // 매크로에서 처리됨

    if ( g_debug_ix != -1 )_LOG ( "loop=%d\n", g_debug_ix );
    _LOG ( "(%s:%d) dbm error. rc =%d, (err=%d,tid=%d)\n\t%s\n", func, line, aRC, errno, gettid_s(), dbmGetError( aRC ) );

    (void) dbmRollback ( aHandle );
    exit ( aRC );
}

/************************************************
 * 주문처리를 위한 계좌, 종목 정보를 간단히 초기화한다.
 ************************************************/
void init ( )
{
    dbmHandle   sHandle;
    item        sItem;
    ordno       sOrdno;
    accnt       sAccnt;
    int         sRC;
    int         i;

    sRC = dbmInitHandle ( &sHandle, "demo" );
    DBError ( sRC, &sHandle );

    // 테이블은 스크립트에서 생성되어 있다.
    dbmTruncate ( &sHandle, "item" );
    dbmTruncate ( &sHandle, "accnt" );
    dbmTruncate ( &sHandle, "ordno" );
    dbmTruncate ( &sHandle, "order" );

    sRC = dbmPrepareTable ( &sHandle, "item" );
    DBError ( sRC, &sHandle );

    sRC = dbmPrepareTable ( &sHandle, "accnt" );
    DBError ( sRC, &sHandle );

    sRC = dbmPrepareTable ( &sHandle, "ordno" );
    DBError ( sRC, &sHandle );

    for ( i = 0; i < 10000; i++ )
    {
        // item
        {
            memset ( &sItem, 0x00, sizeof( sItem ) );
            sprintf ( sItem.itemcd, "%08d", i );
            sprintf ( sItem.itemnm, "%08d", i );
            sItem.highprc = 10000;
            sItem.lowprc = 1;
            sItem.smaxprc = 10000;
            sItem.minprc = 1;
            sItem.currprc = 10000;
            sItem.trdqty = 0;
            sItem.trdamt = 0;

            sRC = dbmInsertRow ( &sHandle, "item", &sItem, sizeof( sItem ) );
            DBError ( sRC, &sHandle );
        }

        // accnt
        {
            memset ( &sAccnt, 0x00, sizeof( sAccnt ) );
            sprintf ( sAccnt.accntno, "%08d", i );
            sprintf ( sAccnt.accntnm, "NAME%08d", i );
            sAccnt.ablemoney = 100000000L;
            sAccnt.unsettle = 0;

            sRC = dbmInsertRow ( &sHandle, "accnt", &sAccnt, sizeof( sAccnt ) );
            DBError ( sRC, &sHandle );
        }

        //g_debug_ix = i;
        /*
         * [note] 골디락스 메모리 UNDO 크기는 유한하기 때문에, 커밋 없는 루핑은
         *
         * $ merr 1039
         * ## dbm err code ##
         *    errno   = 1039
         *     name   = ERR_DBM_WRITE_LOG
         *      msg   = ERR-1039] Fail to write memory undo log.
         *
         * 오류가 발생한다.
         * 커밋 없이 진행가능한 최대 건수는 제한이 있으며, UNDO_MAX_SIZE = 4000 (디폴트)에서 77826건의 INSERT가 가능하다.
         * 테이블의 레코드사이즈와는 무관하며, INDEX개수가 1개 보다 많으면, 수치는 줄어든다.
         *
         */
        sRC = dbmCommit ( &sHandle );
        DBError ( sRC, &sHandle );
    } /* for */

    // ordno
    for ( i = 1; i <= 4; i++ )
    {
        sprintf ( sOrdno.brcd, "%03d", i ); // 뒤에 NULL 패딩없이 3Byte 복사.
        sOrdno.ordno = 0;
        sRC = dbmInsertRow ( &sHandle, "ordno", &sOrdno, sizeof( sOrdno ) );
        DBError ( sRC, &sHandle );
    }

    sRC = dbmCommit ( &sHandle );
    DBError ( sRC, &sHandle );

    dbmFreeHandle ( &sHandle );
} /* init */


/************************************************
 * 실제 주문을 처리하는 쓰레드 함수 부분이다.
 ************************************************/
void* run ( void *param )
{
    dbmHandle   sHandle;
    accnt       sAccnt;
    item        sItem;
    ordno       sOrdno;
    order       sOrder;
    double      sum = 0;
    int         sRC;
    int         i, k;

    struct timespec start;
    struct timespec end;

    dbmInitHandle ( &sHandle, "demo" );

    sRC = dbmPrepareTable ( &sHandle, "item" );
    DBError ( sRC, &sHandle );

    sRC = dbmPrepareTable ( &sHandle, "accnt" );
    DBError ( sRC, &sHandle );

    sRC = dbmPrepareTable ( &sHandle, "ordno" );
    DBError ( sRC, &sHandle );

    sRC = dbmPrepareTable ( &sHandle, "order" );
    DBError ( sRC, &sHandle );

//#define TEST_RUSH

#ifdef TEST_RUSH
    clock_gettime ( CLOCK_REALTIME, &start );
#endif

    for ( i = 0; i < LOOP; i++ )
    {
#ifndef TEST_RUSH
        clock_gettime ( CLOCK_REALTIME, &start );
#endif
        /* 계좌, 주문종목 만들기 */
        sprintf ( sOrder.accntno, "%08d", i % 3000 );
        sprintf ( sOrder.itemcd, "%08d", i % 3000 );
        sOrder.ordqty = i + 1;
        sOrder.ordprc = i + 1;

        /* 계좌 체크 */
        memset ( &sAccnt, 0x00, sizeof( sAccnt ) );
        memcpy ( sAccnt.accntno, sOrder.accntno, sizeof( sOrder.accntno ) );
        sRC = dbmSelectForUpdateRow ( &sHandle, "accnt", &sAccnt );
        DBError ( sRC, &sHandle );

        if ( sAccnt.ablemoney <= 0 )
        {
            _LOG ( "This Account has no money to order. [%ld]\n", sAccnt.ablemoney );
            break;
        }

        /* 종목 체크: 한 10번쯤 요런 비슷한 테이블Select를 한다고 가정한다.  */
        for ( k = 0; k < 1; k++ )
        {
            memcpy ( sItem.itemcd, sOrder.itemcd, sizeof( sOrder.itemcd ) );
            sRC = dbmSelectRow ( &sHandle, "item", &sItem );
            DBError ( sRC, &sHandle );
        }

        if ( sOrder.ordprc > ( sItem.smaxprc + i ) )
        {
            _LOG ( "This Order prices is greater than max price of item.\n" );
            break;
        }

        if ( sOrder.ordprc < sItem.minprc )
        {
            _LOG ( "This Order prices is lower than min price of item.\n" );
            break;
        }

        /* 채번 : 동일지점으로 채번을 하도록 하여 병목을 여기에 몰리게 한다.     */
        memset ( &sOrdno, 0x00, sizeof( sOrdno ) );
        sprintf ( sOrdno.brcd, "001" );
        sRC = dbmSelectForUpdateRow ( &sHandle, "ordno", &sOrdno );
        DBError ( sRC, &sHandle );

        sOrdno.ordno = sOrdno.ordno + 1;
        sRC = dbmUpdateRow ( &sHandle, "ordno", &sOrdno );
        DBError ( sRC, &sHandle );

        /* 계좌 잔고 update */
        sAccnt.unsettle = sAccnt.unsettle + i;
        sRC = dbmUpdateRow ( &sHandle, "accnt", &sAccnt );
        DBError ( sRC, &sHandle );

        /* 주문내역 삽입 */
        sOrder.ordno = sOrdno.ordno;
        sRC = dbmInsertRow ( &sHandle, "order", &sOrder, sizeof( sOrder ) );
        DBError ( sRC, &sHandle );

        sRC = dbmCommit ( &sHandle );
        DBError ( sRC, &sHandle );

#ifndef TEST_RUSH
        clock_gettime ( CLOCK_REALTIME, &end );
        sum = sum + ( end.tv_sec + end.tv_nsec / 1000000000.0 ) - ( start.tv_sec + start.tv_nsec / 1000000000.0 );

        // [note] 천천히 쏘고자 할때.
        //usleep(100);
#endif
    } /* for */

#ifdef TEST_RUSH
    clock_gettime ( CLOCK_REALTIME, &end );
    sum = ( end.tv_sec + end.tv_nsec / 1000000000.0 ) - ( start.tv_sec + start.tv_nsec / 1000000000.0 );
#endif

    dbmFreeHandle ( &sHandle );
    DBError ( sRC, &sHandle );

    _LOG ( "ElapsedTime [%.9f], Average [%.9f]\n", sum, sum / LOOP );
    ( (PARAM*) param )->tps = sum / LOOP;

    return NULL;
} /* run */
