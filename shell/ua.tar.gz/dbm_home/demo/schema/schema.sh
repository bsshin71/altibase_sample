#!/bin/sh

########################################
# Pre-Check
########################################
metaManager << EOF > .schema.log
quit
EOF
ret=$?

if [ "x"$ret == "x0" ]
then
    chk=`cat .schema.log |grep "ERR-" |wc -l`
    if [ "x"$chk != "x0" ]
    then
        cat .schema.log |grep "ERR-"

        printf "\n>> dbm pre-check failed. check install guide. or below common errors\n"
        printf "   ****************************************\n"
        printf " * ERR-1103] System dictionay file does not exist - run 'initdb'\n"
        printf " * ERR-3002] Fail to load property. check \$DBM_INSTANCE environ variable\n"
        printf " * ERR-3006] License file(\$DBM_HOME/conf/dbm.license) does not exist\n"
        printf " * ERR-3007] Invalid license key\n"
        printf " * ERR-3008] Expired license key\n"

        exit 1
    fi
else
    printf "\n>> dbm connect failed. check install guide.\n"
    exit $ret
fi


########################################
# MAIN
########################################

#
# create demo instance
#
metaManager -f $DBM_HOME/demo/schema/instance.sql >> .schema.log 2>&1

#
# create objects for demo
#
metaManager -f $DBM_HOME/demo/schema/object.sql >> .schema.log 2>&1

#
# show list info (dictionary, instance, objects)
#
metaManager -s -i $DBM_INSTANCE << EOF
list;
quit;
EOF
ret=$?


########################################
# END
########################################
if [ "x"$ret == "x0" ]
then
    rm -f .schema.log
fi

exit $ret
