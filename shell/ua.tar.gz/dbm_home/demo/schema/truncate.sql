truncate table T1 ;
truncate table T2 ;
truncate table T3 ;
truncate queue Q1 ;
truncate queue Q2 ;
truncate table T1_DIRECT ;
truncate table T2_DIRECT ;
--truncate sequence SEQ1;
