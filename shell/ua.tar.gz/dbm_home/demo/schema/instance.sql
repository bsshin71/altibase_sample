
--initdb;

connect $sys_dic_inst
show instance;

drop instance demo;
create instance demo;

