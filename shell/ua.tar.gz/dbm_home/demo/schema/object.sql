connect demo;
show instance;

drop table T1;
drop table T2;
drop table T3;
drop queue Q1;
drop queue Q2;
drop table T1_DIRECT;
drop table T2_DIRECT;
drop table SEQ1;
drop table T4;

create table T1 ( eno int, ename char(10), ename2 char(10), eno2 int );
create index T1_IDX1 on T1 ( eno );
create index T1_IDX2 on T1 ( ename );

create table T2 ( eno int, ename char(10), ename2 char(10), eno2 int );
create index T2_IDX1 on T2 ( eno );

create table T3 ( eno int, ename char(10), ename2 char(10), eno2 int );
create non unique index T3_IDX1 on T3 ( eno );

create table T4 ( eno int, ename char(10), ename2 char(10), eno2 int );
create index T4_IDX1 on T4 ( eno );
create index T4_IDX2 on T4 ( ename );
create non unique index T4_IDX3 on T4 ( eno2 );

create queue Q1 msgsize 600 init 100 extend 100 max 100000;
create queue Q2 msgsize 600;
create direct table T1_DIRECT ( eno int, ename char(10), ename2 char(10), eno2 int );
create index T1_DIRECT_IDX1 on T1_DIRECT eno;
create direct table T2_DIRECT ( eno int, ename char(10), ename2 char(10), eno2 int );
create index T2_DIRECT_IDX1 on T2_DIRECT eno;

create sequence SEQ1;
