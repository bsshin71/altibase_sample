/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmSelectRow
 */
#include <dbmAPI.h>
#include "demo.h"

void *thr_func( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    data*       pdata;
    int         thr_idx = *(int *)arg;
    int         rc;
    int         i;

    pdata = (data*) malloc ( sizeof(data) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    for ( i = 0; i < 10; i++ )
    {
        pdata->eno = i;

        rc = dbmSelectRow ( &handle, TABLE_NAME, pdata );
        if ( rc == 0 )
        {
            printf ( "thr(%d) eno(%d) ename(%s)\n", thr_idx, pdata->eno, pdata->ename );
        }
        else
        {
            exit ( 1 );
        }
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}

int main(int argc,char **argv)
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    data*       pdata;
    pthread_t   tid[4];
    int         rc;
    int         i;

    pdata = (data*) malloc ( sizeof(data) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * insert record into table
     ------------------------------------------------------*/
    for ( i = 0; i < 10; i++ )
    {
        memset ( pdata, 0x00, sizeof(data) );

        pdata->eno = i;
        sprintf ( pdata->ename, "%d", i );
        sprintf ( pdata->ename2, "%d", i );
        pdata->eno2 = i;

        rc = dbmInsertRow ( &handle, TABLE_NAME, pdata, sizeof(data) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    for ( i = 0; i < 4; i++ )
    {
        rc = pthread_create ( &tid[i], NULL, thr_func, (void *) &i );
        CHK_ERROR( "pthread_create", rc );

        usleep ( 100000 );
    }

    for ( i = 0; i < 4; i++ )
    {
        rc = pthread_join ( tid[i], NULL );
        CHK_ERROR( "pthread_join", rc );
    }

    /*------------------------------------------------------
     * truncate table ( remove test dependency )
     ------------------------------------------------------*/
    rc = dbmTruncate ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmTruncate", rc );

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return 0;
}

