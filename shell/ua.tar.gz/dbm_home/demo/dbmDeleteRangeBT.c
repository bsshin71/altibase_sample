/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmSelectRow
 */
#include <dbmAPI.h>
#include "demo.h"

int main ( int argc , char **argv )
{
    dbmHandle   handle;
    data*       pdata;
    data*       pdata2;
    int         rc;
    int         i;

    pdata = (data*)malloc ( sizeof(data));
    pdata2= (data*)malloc ( sizeof(data));

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmPrepareTable", rc );

    rc = dbmPrepareTable ( &handle, TABLE_NAME3 );
    CHK_ERROR( "dbmPrepareTable", rc );

    rc = dbmPrepareTable ( &handle, DIRECT_NAME2 );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * insert record into table(UNIQUE)
     ------------------------------------------------------*/
    for ( i = 0; i < 10; i++ )
    {
        memset ( pdata, 0x00, sizeof(data) );

        pdata->eno = i;
        sprintf ( pdata->ename, "%d", i );
        sprintf ( pdata->ename2, "%d", i );
        pdata->eno2 = i;

        rc = dbmInsertRow ( &handle, TABLE_NAME, pdata, sizeof(data) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * insert record into table(DIRECT)
     ------------------------------------------------------*/
    for ( i = 0; i < 10; i++ )
    {
        memset ( pdata, 0x00, sizeof(data) );

        pdata->eno = i;
        sprintf ( pdata->ename, "%d", i );
        sprintf ( pdata->ename2, "%d", i );
        pdata->eno2 = i;

        rc = dbmInsertRow ( &handle, DIRECT_NAME2, pdata, sizeof(data) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * insert record into table(NON UNIQUE)
     ------------------------------------------------------*/
    for ( i = 0; i < 10; i++ )
    {
        memset ( pdata, 0x00, sizeof(data) );

        pdata->eno = i;
        sprintf ( pdata->ename, "%d", i );
        sprintf ( pdata->ename2, "%d", i );
        pdata->eno2 = i;

        rc = dbmInsertRow ( &handle, TABLE_NAME3, pdata, sizeof(data) );
        CHK_ERROR( "dbmInsertRow", rc );

        pdata->eno = i;
        sprintf ( pdata->ename, "%d", i );
        sprintf ( pdata->ename2, "%d", i );
        pdata->eno2 = i;

        rc = dbmInsertRow ( &handle, TABLE_NAME3, pdata, sizeof(data) );
        CHK_ERROR( "dbmInsertRow", rc );

        pdata->eno = i;
        sprintf ( pdata->ename, "%d", i );
        sprintf ( pdata->ename2, "%d", i );
        pdata->eno2 = i;

        rc = dbmInsertRow ( &handle, TABLE_NAME3, pdata, sizeof(data) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * Range delete record.
     ------------------------------------------------------*/

    memset(pdata,0x00,sizeof(data));
    pdata->eno = 5;
    pdata2->eno = 7;
    rc = dbmDeleteRangeBT ( &handle, TABLE_NAME, pdata, pdata2 );
    CHK_ERROR( "dbmDeleteRangeBT ", rc );
    dbmCommit(&handle);
    printf(" dbmDeleteRangeBT success !!! \n");

    memset(pdata,0x00,sizeof(data));
    pdata->eno = 5;
    pdata2->eno = 7;
    rc = dbmDeleteRangeBT ( &handle, DIRECT_NAME2, pdata, pdata2 );
    CHK_ERROR( "dbmDeleteRangeBT ", rc );
    dbmCommit(&handle);
    printf(" dbmDeleteRangeBT(DIRECT) success !!! \n");


    memset(pdata,0x00,sizeof(data));
    pdata->eno = 5;
    pdata2->eno = 7;
    rc = dbmDeleteRangeBT ( &handle, TABLE_NAME3, pdata, pdata2 );
    CHK_ERROR( "dbmDeleteRangeBT ", rc );
    dbmCommit(&handle);
    printf(" dbmDeleteRangeBT(NON UNIQUE) success !!! \n");

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );
    free(pdata);
    free(pdata2);

    return 0;
}

