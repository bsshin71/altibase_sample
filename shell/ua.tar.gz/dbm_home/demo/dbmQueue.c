/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmEnqueue & dbmDequeue
 */
#include <dbmAPI.h>
#include "demo.h"

int main ( int argc , char **argv )
{
    dbmHandle   handle;
    qdata*      pdata;
    int         rc;
    int         i;

    pdata = (qdata*) malloc ( sizeof(qdata) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, QUEUE_NAME2 );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * Enqueue messages
     ------------------------------------------------------*/
    for ( i = 0; i < 10; i++ )
    {
        pdata->eno = i;
        strcpy ( pdata->ename, "enque" );

        rc = dbmEnqueue ( &handle, QUEUE_NAME2, pdata, sizeof(qdata) );
        CHK_ERROR( "dbmEnqueue", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * Dequeue message from the queue.
     ------------------------------------------------------*/
    for ( i = 0; i < 10; i++ )
    {
        rc = dbmDequeue ( &handle, QUEUE_NAME2, pdata, 4000000 );
        CHK_ERROR( "dbmDequeue", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return 0;
}

