/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmSequence
 */
#include <dbmAPI.h>
#include "demo.h"

int main ( int argc , char **argv )
{
    dbmHandle   handle;
    dbmHandle   shandle;
    data*       pdata;
    int         rc;
    long long   sSeq;

    pdata = (data*) malloc ( sizeof(data) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
    CHK_ERROR( "dbmInitHandle", rc );

    rc = dbmInitHandle ( &shandle, INSTANCE_NAME );
    CHK_ERROR( "dbmInitHandle", rc );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
    CHK_ERROR( "dbmConnect", rc );

    rc = dbmConnect ( &shandle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
    CHK_ERROR( "dbmConnect", rc );
#endif

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmPrepareTable", rc );

    rc = dbmPrepareTable ( &shandle, SEQUENCE_NAME );
    CHK_ERROR( "dbmPrepareTable", rc );


    /*------------------------------------------------------
     * sequence nextval
     ------------------------------------------------------*/
    rc = dbmSeqNextVal ( &shandle, SEQUENCE_NAME, &sSeq );
    CHK_ERROR( "dbmSeqNextVal", rc );

    /*------------------------------------------------------
     * insert record into table
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(data) );

    pdata->eno = sSeq;
    sprintf ( pdata->ename, "%d", (int)sSeq );
    sprintf ( pdata->ename2, "%d", (int)sSeq );
    pdata->eno2 = sSeq;

    rc = dbmInsertRow ( &handle, TABLE_NAME, pdata, sizeof(data) );
    CHK_ERROR( "dbmInsertRow", rc );

    /*------------------------------------------------------
     * sequence nextval
     ------------------------------------------------------*/
    rc = dbmSeqNextVal ( &shandle, SEQUENCE_NAME, &sSeq );
    CHK_ERROR( "dbmSeqNextVal", rc );

    /*------------------------------------------------------
     * insert record into table
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(data) );

    pdata->eno = sSeq;
    sprintf ( pdata->ename, "%d", (int)sSeq );
    sprintf ( pdata->ename2, "%d", (int)sSeq );
    pdata->eno2 = sSeq;

    rc = dbmInsertRow ( &handle, TABLE_NAME, pdata, sizeof(data) );
    CHK_ERROR( "dbmInsertRow", rc );

    /*------------------------------------------------------
     * sequence nextval
     ------------------------------------------------------*/
    rc = dbmSeqNextVal ( &shandle, SEQUENCE_NAME, &sSeq );
    CHK_ERROR( "dbmSeqNextVal", rc );

    /*------------------------------------------------------
     * insert record into table
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(data) );

    pdata->eno = sSeq;
    sprintf ( pdata->ename, "%d", (int)sSeq );
    sprintf ( pdata->ename2, "%d", (int)sSeq );
    pdata->eno2 = sSeq;

    rc = dbmInsertRow ( &handle, TABLE_NAME, pdata, sizeof(data) );
    CHK_ERROR( "dbmInsertRow", rc );

    rc = dbmCommit ( &handle );
    CHK_ERROR( "dbmCommit", rc );

    /*------------------------------------------------------
     * sequence currval
     ------------------------------------------------------*/
    rc = dbmSeqCurrVal ( &shandle, SEQUENCE_NAME, &sSeq );
    CHK_ERROR( "dbmSeqCurrVal", rc );

    pdata->eno = sSeq;

    /*------------------------------------------------------
     * select record table
     ------------------------------------------------------*/
    rc = dbmSelectRow ( &handle, TABLE_NAME, pdata );
    CHK_ERROR( "dbmSelectRow", rc );

    printf ( "eno(%d) ename(%s)\n", pdata->eno, pdata->ename );

    /*------------------------------------------------------
     * truncate table ( remove test dependency )
     ------------------------------------------------------*/
    rc = dbmTruncate ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmTruncate", rc );

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return 0;
}

