#!/bin/sh

source $GDSRC/unitTest/shl/testenv

# 2015.04.07 -okt-
# 사용자 데모이니깐. 로그 레벨을 '릴리즈'기준으로 고정하고 
# 이정도 로그로 추적가능한지 경험하자.
export DBM_TRCLOG_LEVEL=2

########################################
# INIT
########################################
echo "## TEST START ##"

# diff 파일여부로 결과를 판단하므로 *.diff 를 정리
chk=`ls core* *.diff 2>/dev/null |wc -l`
if [ "x"$chk != "x0" ]
then
    DT=`date "+%d_%H%M"`
    echo "이전 diff 파일 존제, $DT 경로로 백업"

    mkdir $DT
    mv core* *.out *.diff $DT > /dev/null 2>&1
fi


function runDemo()
{
    metaManager -S -f schema/truncate.sql > /dev/null 2>&1

    runTest $*
}

########################################
# MAIN.
########################################
initdb

if [ "x"$1 == "xremote" ]
then
    TMP=`id -u`
    # 테스트 자동화를 할려면, 다른 계정에서 동시 수행해야한다.
    export TEST_REMOTE_PORT=`expr 40000 + $TMP`

    pid=`ps -ef |grep $USER |grep "olsnr" |grep -v grep |grep -v vim |grep -v gdb |awk '{print $2}'`
    if [ "x"$pid != "x" ]
    then
        kill $pid > /dev/null 2>&1;
        kill $pid > /dev/null 2>&1;
        kill -9 $pid > /dev/null 2>&1;
        sleep 1
    fi
    olsnr -p $TEST_REMOTE_PORT

    # 안전하게 하나만 지워둔다.
    rm -f dbmColBind
    cp -p demo.h demo.h.orig
    sed -i -e "s/#define.*SERVER_PORT.*20326.*/#define SERVER_PORT \"${TEST_REMOTE_PORT}\"/g" demo.h
    ( make clean; make -f makefile.net ) > /dev/null 2>&1
    cp -p demo.h.orig demo.h
else
    # remote 테스트를 돌렸으면, 엉킬수도 있으므로, 재 컴파일해준다.
    ( make clean; make -f makefile ) > /dev/null 2>&1
fi

(cd schema; sh schema.sh ) > schema.out 2>&1
show_diff schema

runDemo dbmColBind
# TODO: BUGBUG
# runDemo dbmDeferCommit
runDemo dbmDeleteRangeBT
runDemo dbmDeleteRangeGT
runDemo dbmDeleteRangeLT
runDemo dbmDeleteRow
runDemo dbmExecuteDDL
runDemo dbmFetchNextGT
runDemo dbmFetchNextLT
runDemo dbmFetchNextGT_Ex
runDemo dbmFetchNextLT_Ex
runDemo dbmInsertRow
runDemo dbmQueue
runDemo dbmSelectCountBT
runDemo dbmSelectCount
runDemo dbmSelectCountGT
runDemo dbmSelectCountLT
runDemo dbmSelectForUpdateRow
runDemo dbmSelectRow
runDemo dbmSelectRowGT
runDemo dbmSelectRowLT
runDemo dbmSelectMin
runDemo dbmSelectMax
runDemo dbmSequence

# TODO: [BUGBUG] Hang
# runDemo dbmSetIndex
# runDemo dbmTruncate

runDemo dbmUpdateRangeBT
runDemo dbmUpdateRangeGT
runDemo dbmUpdateRangeLT
runDemo dbmUpdateRow
runDemo multi_thread
runDemo multi_thread2

# TODO: [BUGBUG]
# runDemo cpp_demo

# [DODEL or NOT] demo/trace
# runDemo multi_thread3
# runDemo multi_thread4
# runDemo multi_thread5
# runDemo multi_thread6
# runDemo multi_thread7
# runDemo bmt_ex1
# runDemo bmt_ex2

########################################
# PBT.
########################################
# runDemo cpp_demo

########################################
# END.
########################################

if [ "x"$1 == "xremote" ]
then
    pid=`ps -ef |grep $USER |grep "olsnr" |grep -v grep |grep -v vim |grep -v gdb |awk '{print $2}'`
    if [ "x"$pid != "x" ]
    then
        kill $pid > /dev/null 2>&1;
        kill $pid > /dev/null 2>&1;
        kill -9 $pid > /dev/null 2>&1;
    fi

    # 원복해주어야한다.
    ( make clean; make -f makefile ) > /dev/null 2>&1
fi

# 정상종료 여부를 상위단으로 알려주어야 한다.
chk=`ls core* *.diff 2>/dev/null |wc -l`
if [ "x"$chk != "x0" ]
then
    echo "[ERROR] 테스트 실패 !!"
    exit 1
fi

initdb
exit 0
