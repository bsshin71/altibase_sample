/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Definition for demo program
 */
#define INSTANCE_NAME                   "demo"
#define TABLE_NAME                      "T1"
#define TABLE_NAME2                     "T2"
#define TABLE_NAME3                     "T3"
#define TABLE_NAME4                     "T4"
#define INDEX_NAME                      "T1_IDX1"
#define INDEX_NAME2                     "T2_IDX1"
#define INDEX_NAME3                     "T1_IDX2"
#define INDEX_NAME4                     "T3_IDX1"
#define QUEUE_NAME                      "Q1"
#define QUEUE_NAME2                     "Q2"
#define DIRECT_NAME                     "T1_DIRECT"
#define DIRECT_NAME2                    "T2_DIRECT"
#define TRIG_NAME                       "DEMO_T1_Q1"
#define SEQUENCE_NAME                   "SEQ1"

#define SERVER_USER                     "demo"
#define SERVER_IP                       "127.0.0.1"
#define SERVER_PORT                     "20326"

typedef struct data
{
    int     eno;
    char    ename[10];
    char    ename2[10];
    int     eno2;
} data;

typedef struct qdata
{
    int     eno;
    char    ename[10];
} qdata;

/* error handling macro */
#ifndef __cplusplus

#define CHK_ERROR(func,rc)              \
{                                       \
    char errmsg[1024];                  \
    if ( rc != 0 )                      \
    {                                   \
        dbmGetError( rc, errmsg );      \
        printf( "\n%s error. line(%d) : %s\n\n", func, __LINE__, errmsg ); \
        exit(1);                        \
    }                                   \
}

#else

#define CHK_ERROR(func,rc)              \
{                                       \
    if ( rc != 0 )                      \
    {                                   \
        printf( "\n%s error. line(%d) : %s\n\n", func, __LINE__, dbmGetError(rc) ); \
        exit(1);                        \
    }                                   \
}

#endif
