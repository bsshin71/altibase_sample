/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmExecuteDDL
 */
#include <dbmAPI.h>
#include "demo.h"

#undef TABLE_NAME
#undef TABLE_NAME2
#undef INDEX_NAME
#undef INDEX_NAME2
#undef QUEUE_NAME
#undef QUEUE_NAME2
#undef DIRECT_NAME
#undef TRIG_NAME
#define TABLE_NAME                      "DEMO_T1"
#define TABLE_NAME2                     "DEMO_T2"
#define INDEX_NAME                      "_IDX1"
#define INDEX_NAME2                     "_IDX2"
#define QUEUE_NAME                      "DEMO_Q1"
#define QUEUE_NAME2                     "DEMO_Q2"
#define DIRECT_NAME                     "DEMO_T1_DIRECT"
#define TRIG_NAME                       "DEMO_T1_Q1"

int main()
{
    dbmHandle   handle;
    char        sql[1024];
    int         rc;

    memset ( sql, 0x00, sizeof( sql ) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * drop demo objects
     ------------------------------------------------------*/
    sprintf ( sql, "drop table %s", TABLE_NAME );
    rc = dbmExecuteDDL ( &handle, sql );

    sprintf ( sql, "drop table %s", TABLE_NAME2 );
    rc = dbmExecuteDDL ( &handle, sql );

    sprintf ( sql, "drop table %s", DIRECT_NAME );
    rc = dbmExecuteDDL ( &handle, sql );

    sprintf ( sql, "drop queue %s", QUEUE_NAME );
    rc = dbmExecuteDDL ( &handle, sql );

    sprintf ( sql, "drop queue %s", QUEUE_NAME2 );
    rc = dbmExecuteDDL ( &handle, sql );


    /*------------------------------------------------------
     * recreate demo objects
     ------------------------------------------------------*/
    sprintf ( sql, "create table %s ( eno int, ename char(10), ename2 char(10), eno2 int )", TABLE_NAME );
    rc = dbmExecuteDDL ( &handle, sql );
    CHK_ERROR( "dbmExecuteDDL", rc );

    sprintf ( sql, "create index %s%s on %s ( eno )", TABLE_NAME, INDEX_NAME, TABLE_NAME );
    rc = dbmExecuteDDL ( &handle, sql );
    CHK_ERROR( "dbmExecuteDDL", rc );

    sprintf ( sql, "create index %s%s on %s ( ename )", TABLE_NAME, INDEX_NAME2, TABLE_NAME );
    rc = dbmExecuteDDL ( &handle, sql );
    CHK_ERROR( "dbmExecuteDDL", rc );

    sprintf ( sql, "create table %s ( eno int, ename char(10), ename2 char(10), eno2 int )", TABLE_NAME2 );
    rc = dbmExecuteDDL ( &handle, sql );
    CHK_ERROR( "dbmExecuteDDL", rc );

    sprintf ( sql, "create index %s%s on %s ( eno )\n", TABLE_NAME2, INDEX_NAME, TABLE_NAME2 );
    rc = dbmExecuteDDL ( &handle, sql );
    CHK_ERROR( "dbmExecuteDDL", rc );

    sprintf ( sql, "create queue %s msgsize 600 init 100 extend 100 max 1000", QUEUE_NAME );
    rc = dbmExecuteDDL ( &handle, sql );
    CHK_ERROR( "dbmExecuteDDL", rc );

    sprintf ( sql, "create queue %s msgsize 600", QUEUE_NAME2 );
    rc = dbmExecuteDDL ( &handle, sql );
    CHK_ERROR( "dbmExecuteDDL", rc );

    sprintf ( sql, "create direct table %s ( eno int, ename char(10), ename2 char(10), eno2 int )", DIRECT_NAME );
    rc = dbmExecuteDDL ( &handle, sql );
    CHK_ERROR( "dbmExecuteDDL", rc );

    sprintf ( sql, "create index %s%s on %s ( eno )\n", DIRECT_NAME, INDEX_NAME, DIRECT_NAME );
    rc = dbmExecuteDDL ( &handle, sql );
    CHK_ERROR( "dbmExecuteDDL", rc );

    sprintf ( sql, "create trigger %s %s %s", TRIG_NAME, TABLE_NAME, QUEUE_NAME );
    rc = dbmExecuteDDL ( &handle, sql );
    CHK_ERROR( "dbmExecuteDDL", rc );


    /*------------------------------------------------------
     * drop demo objects again
     ------------------------------------------------------*/
    sprintf ( sql, "drop table %s", TABLE_NAME );
    rc = dbmExecuteDDL ( &handle, sql );

    sprintf ( sql, "drop table %s", TABLE_NAME2 );
    rc = dbmExecuteDDL ( &handle, sql );

    sprintf ( sql, "drop table %s", DIRECT_NAME );
    rc = dbmExecuteDDL ( &handle, sql );

    sprintf ( sql, "drop queue %s", QUEUE_NAME );
    rc = dbmExecuteDDL ( &handle, sql );

    sprintf ( sql, "drop queue %s", QUEUE_NAME2 );
    rc = dbmExecuteDDL ( &handle, sql );


    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return 0;
}
