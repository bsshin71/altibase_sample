/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmInsertRow
 */
#include <dbmAPI.h>
#include "demo.h"

int main ( int argc , char **argv )
{
    dbmHandle   handle;
    data*       pdata;
    int         rc;
    int         i;

    pdata = (data*) malloc ( sizeof(data) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * insert record into table
     ------------------------------------------------------*/


    for ( i = 0; i < 1000; i++ )
    {
        memset ( pdata, 0x00, sizeof(data) );

        pdata->eno = i;
        sprintf ( pdata->ename, "%d", i );
        sprintf ( pdata->ename2, "%d", i );
        pdata->eno2 = i;

        rc = dbmInsertRow ( &handle, TABLE_NAME, pdata, sizeof(data) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmDeferCommit ( &handle );
        CHK_ERROR( "dbmDeferCommit", rc );

        rc = dbmDeferSync ( &handle );
        CHK_ERROR( "dbmDeferSync", rc );
    }

    /*------------------------------------------------------
     * truncate table ( remove test dependency )
     ------------------------------------------------------*/
    rc = dbmTruncate ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmTruncate", rc );

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return 0;
}

