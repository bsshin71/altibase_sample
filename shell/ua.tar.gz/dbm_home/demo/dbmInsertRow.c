/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmInsertRow
 */
#include <dbmAPI.h>
#include "demo.h"
#define MAX_CNT 1000000

int main ( int argc , char **argv )
{
    dbmHandle   handle;
    data*       pdata;
    int         rc;
    int         i;

    pdata = (data*) malloc ( sizeof(data) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * insert record into table
     ------------------------------------------------------*/
    for ( i = 0; i < 1000000; i++ )
    {
        memset ( pdata, 0x00, sizeof(data) );

#ifndef __MSVCRT_VERSION__
        pdata->eno = (lrand48()%MAX_CNT)+1;
#else
        pdata->eno = (rand()%MAX_CNT)+1;
#endif
        sprintf ( pdata->ename, "%d", pdata->eno );
        sprintf ( pdata->ename2, "%d", pdata->eno );
        pdata->eno2 = pdata->eno;

        rc = dbmInsertRow ( &handle, TABLE_NAME, pdata, sizeof(data) );

        if( rc != 1064 )
        {
            CHK_ERROR( "dbmInsertRow", rc );
        }

        if( rc != 1064 )
        {
            rc = dbmCommit ( &handle );
            CHK_ERROR( "dbmCommit", rc );
        }
       else
       {
           rc = dbmRollback ( &handle );
           CHK_ERROR( "dbmCommit", rc );
       }
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return 0;
}

