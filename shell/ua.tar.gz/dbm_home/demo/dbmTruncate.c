/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmTruncate
 */
#include <dbmAPI.h>
#include "demo.h"


int main ( int argc , char **argv )
{
    dbmHandle   handle;
    int         rc;

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * truncate table
     ------------------------------------------------------*/
    rc = dbmTruncate ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmTruncate", rc );

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return 0;
}

