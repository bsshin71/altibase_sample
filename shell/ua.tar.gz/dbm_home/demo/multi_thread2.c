/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmSelectRow
 */
#include <dbmAPI.h>
#include "demo.h"

void *thr_func( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    data*       pdata;
    int         rc;
    int         i;

    pdata = (data*) malloc ( sizeof(data) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(data) );

    for ( i = 0; i < 100000; i++ )
    {

        pdata->eno = i;
        sprintf( pdata->ename, "%d", i );
        sprintf( pdata->ename2, "%d", i );
        pdata->eno2 = i;

        rc = dbmInsertRow ( &handle, TABLE_NAME, pdata, sizeof(data) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}

void *thr_func2( void * arg )
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    qdata*      pdata;
    int         rc;
    int         i;
    pdata = (qdata*) malloc ( sizeof(qdata) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, QUEUE_NAME );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * select records in table sequentially
     ------------------------------------------------------*/
    memset ( pdata, 0x00, sizeof(qdata) );

    for ( i = 0; i < 10000; i++ )
    {

        pdata->eno = i;
        sprintf( pdata->ename, "%d", i);

        rc = dbmEnqueue ( &handle, QUEUE_NAME, pdata, sizeof(qdata) );
        CHK_ERROR( "dbmEnqueue", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }


    memset ( pdata, 0x00, sizeof(qdata) );
    for ( i = 0; i < 1000; i++ )
    {
        rc = dbmDequeue ( &handle, QUEUE_NAME, pdata, 4000000 );
        CHK_ERROR( "dbmDequeue", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return NULL;
}

int main(int argc,char **argv)
{
    dbmHandle   handle;    /* You must use unique handle per thread. */
    pthread_t   tid[4];
    int         rc;
    int         i;

    for ( i = 0; i < 2; i++ )
    {
        if( i == 0 )
        {
            rc = pthread_create ( &tid[i], NULL, thr_func, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }

        if( i == 1 )
        {
            rc = pthread_create ( &tid[i], NULL, thr_func2, (void *) &i );
            CHK_ERROR( "pthread_create", rc );
        }
        usleep ( 100000 );
    }

    for ( i = 0; i < 2; i++ )
    {
        rc = pthread_join ( tid[i], NULL );
        CHK_ERROR( "pthread_join", rc );
    }

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return 0;
}

