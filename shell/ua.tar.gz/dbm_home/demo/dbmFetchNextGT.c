/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmOpenCursorGT & dbmFetchNextGT
 */
#include <dbmAPI.h>
#include "demo.h"

int main ( int argc , char **argv )
{
    dbmHandle   handle;
    data*       pdata;
    int         rc;
    int         i;

    pdata = (data*) malloc ( sizeof(data) );

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
#else
    rc = dbmConnect ( &handle, INSTANCE_NAME, SERVER_USER, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmPrepareTable", rc );

    /*------------------------------------------------------
     * insert record into table
     ------------------------------------------------------*/
    for ( i = 0; i < 1000; i++ )
    {
        memset ( pdata, 0x00, sizeof(data) );

        pdata->eno = i;
        sprintf ( pdata->ename, "%d", i );
        sprintf ( pdata->ename2, "%d", i );
        pdata->eno2 = i;

        rc = dbmInsertRow ( &handle, TABLE_NAME, pdata, sizeof(data) );
        CHK_ERROR( "dbmInsertRow", rc );

        rc = dbmCommit ( &handle );
        CHK_ERROR( "dbmCommit", rc );
    }

    /*------------------------------------------------------
     * fetch records greater than key(-1) by using cursor
     ------------------------------------------------------*/
    pdata->eno = 500;

    rc = dbmOpenCursorGT ( &handle, TABLE_NAME, pdata, 0 );
    CHK_ERROR( "dbmOpenCursorGT", rc );

    while ( 1 )
    {
        rc = dbmFetchNextGT ( &handle, TABLE_NAME, pdata, 0 );

        if( pdata->eno == 700 )
        {
            printf("pdata->eno[%d] break \n", pdata->eno );
            break;
        }

        if ( rc )
        {
            if ( rc == ERR_DBM_NO_MATCH_RECORD )
            {
                break;
            }

            CHK_ERROR( "dbmFetchNextGT", rc );
        }

        printf ( "eno[%d] ename[%s] \n", pdata->eno, pdata->ename );
    }

    dbmCloseCursor ( &handle );

    pdata->eno = 500;

    rc = dbmOpenCursorGT ( &handle, TABLE_NAME, pdata, 0 );
    CHK_ERROR( "dbmOpenCursorGT", rc );

    printf("open cursor ok \n");

    /*------------------------------------------------------
     * truncate table ( remove test dependency )
     ------------------------------------------------------*/
    rc = dbmTruncate ( &handle, TABLE_NAME );
    CHK_ERROR( "dbmTruncate", rc );

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return 0;
}
