/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : C++ demo program
 */
#include <dbmAPI.h>
#include "demo.h"

/*------------------------------------------------------
 * data structure associated with table
 ------------------------------------------------------*/
typedef struct table
{
    int     eno;
    char    ename[10];
} table;


/*------------------------------------------------------
 * class definition for table operation
 ------------------------------------------------------*/
class myTableJob
{
public:
    myTableJob ( );
    myTableJob ( const char* instance , const char* name , int rowsize );
    ~myTableJob ( );

    int init ( );
    int insert ( int eno, const char* ename );
    int select ( int eno );
    int update ( int eno, const char* ename );
    int delete_( int eno );
    int commit ( );
    void finalize ( );

private:
    char        m_instance_name[32];
    char        m_table_name[32];
    table       m_data;
    dbmHandle   m_handle;
};


/*------------------------------------------------------
 * member function definition
 ------------------------------------------------------*/
myTableJob::myTableJob ( const char* instance , const char* name , int rowsize )
{
    strcpy ( m_instance_name, instance );
    strcpy ( m_table_name, name );

    memset( &m_data, 0x00, sizeof(table) );
}

myTableJob::~myTableJob()
{
}

int myTableJob::init ( )
{
    int rc;

    /*------------------------------------------------------
     * connect
     ------------------------------------------------------*/
#ifndef _GDL_NET
    rc = dbmInitHandle ( &m_handle, m_instance_name );
#else
    rc = dbmConnect ( &m_handle, m_instance_name, m_instance_name, SERVER_IP, SERVER_PORT );
#endif
    CHK_ERROR( "dbmInitHandle", rc );

    rc = dbmPrepareTable ( &m_handle, m_table_name );
    CHK_ERROR( "dbmPrepareTable", rc );

    return rc;
}

int myTableJob::insert ( int eno , const char* ename )
{
    int rc;

    memset ( &m_data, 0x00, sizeof(table) );

    m_data.eno = eno;
    strcpy ( m_data.ename, ename );

    rc = dbmInsertRow ( &m_handle, m_table_name, &m_data, sizeof(table) );
    CHK_ERROR( "insert", rc );

    return rc;
}

int myTableJob::update ( int eno , const char* ename )
{
    int rc;

    memset ( &m_data, 0x00, sizeof(table) );

    m_data.eno = eno;
    strcpy ( m_data.ename, ename );

    rc = dbmUpdateRow ( &m_handle, m_table_name, &m_data );
    CHK_ERROR( "update", rc );

    return rc;
}

int myTableJob::select ( int eno )
{
    int rc;

    memset ( &m_data, 0x00, sizeof(table) );

    m_data.eno = eno;

    rc = dbmSelectRow ( &m_handle, m_table_name, &m_data );
    if ( rc == 0 )
    {
        printf ( "eno : %d, ename : %s\n", m_data.eno, m_data.ename );
    }
    else
    {
        CHK_ERROR( "select", rc );
    }

    return rc;
}

int myTableJob::delete_ ( int eno )
{
    int rc;

    memset ( &m_data, 0x00, sizeof(table) );

    m_data.eno = eno;

    rc = dbmDeleteRow ( &m_handle, m_table_name, &m_data );
    CHK_ERROR( "delete", rc );

    return rc;
}

int myTableJob::commit ( )
{
    int rc;

    rc = dbmCommit ( &m_handle );
    CHK_ERROR( "commit", rc );

    return rc;
}

void myTableJob::finalize ( )
{
    dbmFreeHandle ( &m_handle );
}


int main ( int argc , char** argv )
{
    int i;

    /* table object */
    myTableJob * tbl = new myTableJob ( INSTANCE_NAME, TABLE_NAME, sizeof(table) );

    /*------------------------------------------------------
     * allocate handle & transaction and prepare table
     ------------------------------------------------------*/
    tbl->init ( );

    /*------------------------------------------------------
     * do various operations
     ------------------------------------------------------*/
    printf( "\n1. INSERT\n" );
    for ( i = 0; i < 3; i++ )
    {
        tbl->insert ( i, "Kevin.Lee" );
        tbl->commit ( );
    }

    for ( i = 0; i < 3; i++ )
    {
        tbl->select ( i );
    }

    printf( "\n2. UPDATE\n" );
    for ( i = 0; i < 3; i++ )
    {
        tbl->update ( i, "Justin.Lee" );
        tbl->commit ( );
    }

    for ( i = 0; i < 3; i++ )
    {
        tbl->select ( i );
    }

    printf( "\n3. DELETE\n" );
    for ( i = 0; i < 3; i++ )
    {
        tbl->delete_ ( i );
        tbl->commit ( );
    }

    /*------------------------------------------------------
     * finalize handle & memory
     ------------------------------------------------------*/
    tbl->finalize ( );

    return 0;
}

