/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.IMPORT_DLL
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/

#ifndef __ONMIR_DBM_WIN_API_H__
#define __ONMIR_DBM_WIN_API_H__

#include <malloc.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#ifdef __cplusplus
extern "C"
{
#endif

#define IMPORT_DLL __declspec(dllimport)

typedef struct dbmHandle
{
	/*
	* dont use 'long' type on Windows
	*       LLP64 :       long long, point : 64bit
	*       LP64  : long, long long, point : 64bit
	*               other types are same with 32bit
	*/
	long long   mMark;
	void*       mHandle;
	int         mIndexType;
	int         mDummy;
} dbmHandle;
/******************************************************************************
 * User API
******************************************************************************/
extern IMPORT_DLL int dbmInitHandle(dbmHandle* aHandle, const char* aInstance);
extern IMPORT_DLL int dbmInitHandleRepl(dbmHandle* aHandle, const char* aInstance);
extern IMPORT_DLL int dbmConnect(dbmHandle* aHandle, const char* aInstance, const char* aUser, const char* aIP, const char* aPort);
extern int IMPORT_DLL dbmFreeHandle(dbmHandle* aHandle);


#ifdef __cplusplus
extern IMPORT_DLL char* dbmGetError(int aCode, char* aMsg = NULL);
#else
extern IMPORT_DLL char* dbmGetError(int aCode, char* aMsg);
#endif


extern int IMPORT_DLL dbmPrepareTable  ( dbmHandle* aHandle, const char* aTable );


extern int IMPORT_DLL dbmSelectRow     ( dbmHandle* aHandle, const char* aTable, void* aData );

#ifdef __cplusplus
extern int IMPORT_DLL dbmSelectRowLT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
extern int IMPORT_DLL dbmSelectRowGT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
#else
extern int IMPORT_DLL dbmSelectRowLT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
extern int IMPORT_DLL dbmSelectRowGT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
#endif


extern int IMPORT_DLL dbmOpenCursor    ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int IMPORT_DLL dbmFetchRow      ( dbmHandle* aHandle, const char* aTable, void* aData );

#ifdef __cplusplus
extern int IMPORT_DLL dbmOpenCursorGT  ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
extern int IMPORT_DLL dbmFetchNextGT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
extern int IMPORT_DLL dbmOpenCursorLT  ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
extern int IMPORT_DLL dbmFetchNextLT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
#else
extern int IMPORT_DLL dbmOpenCursorGT  ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
extern int IMPORT_DLL dbmFetchNextGT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
extern int IMPORT_DLL dbmOpenCursorLT  ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
extern int IMPORT_DLL dbmFetchNextLT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
#endif

extern int IMPORT_DLL dbmCloseCursor   ( dbmHandle* aHandle );


extern int IMPORT_DLL dbmSelectForUpdateRow ( dbmHandle* aHandle, const char* aTable, void* aData );


extern int IMPORT_DLL dbmSelectCount   ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int IMPORT_DLL dbmSelectCountGT ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int IMPORT_DLL dbmSelectCountLT ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int IMPORT_DLL dbmSelectCountBT ( dbmHandle* aHandle, const char* aTable, void* aData, void* aDataTwo, int* aCount );

extern int IMPORT_DLL dbmUpdateRangeGT ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int IMPORT_DLL dbmUpdateRangeLT ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int IMPORT_DLL dbmUpdateRangeBT ( dbmHandle* aHandle, const char* aTable, void* aData, void* aDataTwo );

extern int IMPORT_DLL dbmDeleteRangeGT ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int IMPORT_DLL dbmDeleteRangeLT ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int IMPORT_DLL dbmDeleteRangeBT ( dbmHandle* aHandle, const char* aTable, void* aData, void* aDataTwo );

extern int IMPORT_DLL dbmSeqNextVal    ( dbmHandle* aHandle, const char* aTable, long long* aData );
extern int IMPORT_DLL dbmSeqCurrVal    ( dbmHandle* aHandle, const char* aTable, long long* aData );

extern int IMPORT_DLL dbmInsertRow     ( dbmHandle* aHandle, const char* aTable, void* aData, int aSize );
extern int IMPORT_DLL dbmUpdateRow     ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int IMPORT_DLL dbmDeleteRow     ( dbmHandle* aHandle, const char* aTable, void* aData );

extern int IMPORT_DLL dbmUpdateKey     ( dbmHandle* aHandle, const char* aTable, void* aData );

extern int IMPORT_DLL dbmCommit        ( dbmHandle* aHandle );
extern int IMPORT_DLL dbmAsyncCommit   ( dbmHandle* aHandle );
extern int IMPORT_DLL dbmDeferCommit   ( dbmHandle* aHandle );
extern int IMPORT_DLL dbmDeferSync     ( dbmHandle* aHandle );
extern int IMPORT_DLL dbmRollback      ( dbmHandle* aHandle );


extern int IMPORT_DLL dbmEnqueue       ( dbmHandle* aHandle, const char* aTable, void* aData, int aDataSize );
extern int IMPORT_DLL dbmDequeue       ( dbmHandle* aHandle, const char* aTable, void* aData, int aTimeOut );


extern int IMPORT_DLL dbmListLpush     ( dbmHandle* aHandle, const char* aTable, void* aData, int aDataSize );
extern int IMPORT_DLL dbmListRpush     ( dbmHandle* aHandle, const char* aTable, void* aData, int aDataSize );
extern int IMPORT_DLL dbmListLpop      ( dbmHandle* aHandle, const char* aTable, void* aData, int aDataSize );
extern int IMPORT_DLL dbmListRpop      ( dbmHandle* aHandle, const char* aTable, void* aData, int aDataSize );
extern int IMPORT_DLL dbmListRange     ( dbmHandle* aHandle, const char* aTable, void* aData, int aDataSize );


extern int IMPORT_DLL dbmGetRowSize    ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int IMPORT_DLL dbmSetIndex      ( dbmHandle* aHandle, const char* aTable, const char* aIndexName );
extern int EXPORT_DLL dbmGetIndex      ( dbmHandle* aHandle, const char* aTable, const char* aIndexName, int* aIndexNo );
extern int IMPORT_DLL dbmColBind       ( dbmHandle* aHandle, const char* aTable, const char* aColName, void* aUserData, int aColSize );
extern int IMPORT_DLL dbmUpdateRowByCols ( dbmHandle* aHandle, const char* aTable );
extern int IMPORT_DLL dbmClearBind     ( dbmHandle* aHandle );


extern int IMPORT_DLL dbmExecuteDDL    ( dbmHandle* aHandle, const char* aSQL );
extern int IMPORT_DLL dbmTruncate      ( dbmHandle* aHandle, const char* aTable );
extern int IMPORT_DLL dbmDrop          ( dbmHandle* aHandle, const char* aTable );
#define dbmDropTable  dbmDrop
#define dbmDropIndex  dbmDrop
#define dbmDropQueue  dbmDrop
#define dbmDropSeq    dbmDrop


extern int IMPORT_DLL dbmMetaDeleteRow ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int IMPORT_DLL dbmMetaUpdateRow ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int IMPORT_DLL dbmMetaUpdateRowByCols ( dbmHandle* aHandle, const char* aTable, int* aCount );

#ifdef __cplusplus
};
#endif

#endif /* __ONMIR_DBM_API_H__ */
