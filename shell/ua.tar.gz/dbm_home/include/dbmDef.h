/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/

#ifndef __ONMIR_DBM_DEF_H__
#define __ONMIR_DBM_DEF_H__

#ifndef __NO_SYSTEM_INCLUDES
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/time.h>
#include <string.h>
#include <unistd.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdarg.h>
#include <signal.h>
#include <limits.h>
#include <float.h>

#ifdef __linux__

#include <syscall.h>
#include <sys/socket.h>
#include <sys/shm.h>
#include <sys/mman.h>
#include <sys/ipc.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>

#endif /* __linux__ */

#endif /* __NO_SYSTEM_INCLUDES */

#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************
 * User Handle
******************************************************************************/
typedef struct dbmHandle
{
    /*
     * dont use 'long' type on Windows
     *       LLP64 :       long long, point : 64bit
     *       LP64  : long, long long, point : 64bit
     *               other types are same with 32bit
     */
    long long   mMark;
    void*       mHandle;
    int         mIndexType;
    int         mDummy;
} dbmHandle ;

#define DBM_HANDLE_INITIALIZER          { -1, NULL, 0, 0xFF }


/******************************************************************************
 * Error Code Define
 *       if you want full error code, see '?/conf/dbm.error'
******************************************************************************/
#define ERR_DBM_NO_MATCH_RECORD         1027
#define ERR_DBM_DUP_ERROR               1064
#define ERR_DBM_QUEUE_FULL              1042
#define ERR_DBM_DEADLOCK_DETECTED       1121
#define ERR_DBM_TABLE_NOT_PREPARED      1031
#define ERR_DBM_FETCH_SCN_INVISIBLE     1137

#define ERR_DBM_INIT_HANDLE_FAIL        1108
#define ERR_DBM_REMOTE_CONNECT_FAIL     1024


#ifdef _DBM_SRC

/******************************************************************************
 * define
******************************************************************************/
#define _INLINE                         static __inline__

#ifdef __GNUC__
#  define likely(x)                     __builtin_expect ((x), 1)
#  define unlikely(x)                   __builtin_expect ((x), 0)
#else
#  define likely(x)                     (x)
#  define unlikely(x)                   (x)
#endif


/******************************************************************************
 * another utility function
******************************************************************************/
extern int              _dbm_argc;
extern const char**     _dbm_argv;

#ifdef __cplusplus
extern char* _dbm_getArg ( const char* name, const char* long_name = NULL );
#else
extern char* _dbm_getArg ( const char* name, const char* long_name );
#endif
extern int   _dbm_setArg ( int* pArgc, char** ppArgv );

extern void cmnUSleep ( long long uSec );
extern void cmnNanoSleep ( long long nSec );

extern int cmnInitTimer     ( void** aTimerHandle , int aUnit , int aBegin , int aInterval , int aSecCount );
extern int cmnFinalTimer    ( void** aTimerHandle );
extern int cmnStartTimer    ( void* aTimerHandle );
extern int cmnStartTimer2   ( void* aTimerHandle, struct timespec* aStartTime );
extern int cmnSumTimer      ( void* aTimerHandle, void* aTimerSumHandle );
extern int cmnEndTimer      ( void* aTimerHandle );
extern int cmnElapseTimer   ( void* aTimerHandle, int aIterCount, const char* aTestName );
extern int cmnWaitTimer    ( void* aTimerHandle );

//extern char* cmnTime2Str ( int aFmtLen, char* pDst = NULL, int flag = -1, struct timeval* input_time = NULL );

/******************************************************************************
 * system call wrapper function
******************************************************************************/

//extern mvp_pid_t gettid_s ( );
extern int gettid_s ( );

#define free_s(ptr)         if ( likely ( ptr != 0 ) ) { free (ptr); ptr = 0; }
#define delete_s(ptr)       if ( likely ( ptr != 0 ) ) { delete ptr; ptr = 0; }

#define close_s(fd)         if ( likely ( fd  > 0 ) ) { (void)close( fd ); fd = -1; }
#define fclose_s(fp)        if ( likely ( fp != 0 ) ) { (void)fclose( fp ); fp = 0; }

#endif /* _DBM_SRC */

#ifdef __cplusplus
}
#endif

#endif /* __ONMIR_DBM_DEF_H__ */
