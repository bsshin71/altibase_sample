/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/

#ifndef __ONMIR_DBM_API_H__
#define __ONMIR_DBM_API_H__

#include "dbmDef.h"

#ifdef __cplusplus
extern "C"
{
#endif

#if defined(__MINGW32__) || defined(__MINGW64__)
#define EXPORT_DLL __declspec(dllexport)
//#define EXPORT_DLL
#else
#define EXPORT_DLL
#endif
/******************************************************************************
 * User API
******************************************************************************/
extern int EXPORT_DLL dbmInitHandle    ( dbmHandle* aHandle, const char* aInstance );
extern int EXPORT_DLL dbmInitHandleRepl( dbmHandle* aHandle, const char* aInstance );
extern int EXPORT_DLL dbmConnect       ( dbmHandle* aHandle, const char* aInstance, const char* aUser, const char* aIP, const char* aPort );
extern int EXPORT_DLL dbmFreeHandle    ( dbmHandle* aHandle );


#ifdef __cplusplus
extern int EXPORT_DLL dbmExecInternalLib ( dbmHandle* aHandle, const char* aTable, void* aData, void* aDataTwo, int aTransType, int* aCount = NULL, long long* aSeq = NULL );
#else
extern int EXPORT_DLL dbmExecInternalLib ( dbmHandle* aHandle, const char* aTable, void* aData, void* aDataTwo, int aTransType, int* aCount, long long* aSeq );
#endif

extern int EXPORT_DLL dbmExecUpdateLib ( dbmHandle* aHandle, const char* aTable, void* aData, int aTransType, int* aColBindCheck );

#ifdef __cplusplus
extern char* EXPORT_DLL dbmGetError  ( int aCode, char* aMsg = NULL );
#else
extern char* EXPORT_DLL dbmGetError    ( int aCode, char* aMsg );
#endif


extern int  EXPORT_DLL dbmPrepareTable  ( dbmHandle* aHandle, const char* aTable );


extern int EXPORT_DLL dbmSelectMax     ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int EXPORT_DLL dbmSelectMin     ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int EXPORT_DLL dbmSelectRow     ( dbmHandle* aHandle, const char* aTable, void* aData );

#ifdef __cplusplus
extern int EXPORT_DLL dbmSelectRowLT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
extern int EXPORT_DLL dbmSelectRowGT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
#else
extern int EXPORT_DLL dbmSelectRowLT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
extern int EXPORT_DLL dbmSelectRowGT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
#endif


extern int EXPORT_DLL dbmOpenCursor_Ex    ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int EXPORT_DLL dbmOpenCursor    ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int EXPORT_DLL dbmFetchRow      ( dbmHandle* aHandle, const char* aTable, void* aData );

#ifdef __cplusplus
extern int EXPORT_DLL dbmOpenCursorGT_Ex  ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
extern int EXPORT_DLL dbmOpenCursorGT  ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
extern int EXPORT_DLL dbmFetchNextGT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
extern int EXPORT_DLL dbmOpenCursorLT_Ex  ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
extern int EXPORT_DLL dbmOpenCursorLT  ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
extern int EXPORT_DLL dbmFetchNextLT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt = 0 );
#else
extern int EXPORT_DLL dbmOpenCursorGT_Ex  ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
extern int EXPORT_DLL dbmOpenCursorGT  ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
extern int EXPORT_DLL dbmFetchNextGT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
extern int EXPORT_DLL dbmOpenCursorLT_Ex  ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
extern int EXPORT_DLL dbmOpenCursorLT  ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
extern int EXPORT_DLL dbmFetchNextLT   ( dbmHandle* aHandle, const char* aTable, void* aData, int aEQCnt );
#endif

extern int EXPORT_DLL dbmCloseCursor   ( dbmHandle* aHandle );


extern int EXPORT_DLL dbmSelectForUpdateRow ( dbmHandle* aHandle, const char* aTable, void* aData );


extern int EXPORT_DLL dbmSelectCount   ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int EXPORT_DLL dbmSelectCountGT ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int EXPORT_DLL dbmSelectCountLT ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int EXPORT_DLL dbmSelectCountBT ( dbmHandle* aHandle, const char* aTable, void* aData, void* aDataTwo, int* aCount );

extern int EXPORT_DLL dbmSelectCount_Ex   ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int EXPORT_DLL dbmSelectCountGT_Ex ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int EXPORT_DLL dbmSelectCountLT_Ex ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int EXPORT_DLL dbmSelectCountBT_Ex ( dbmHandle* aHandle, const char* aTable, void* aData, void* aDataTwo, int* aCount );

extern int EXPORT_DLL dbmUpdateRangeGT ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int EXPORT_DLL dbmUpdateRangeLT ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int EXPORT_DLL dbmUpdateRangeBT ( dbmHandle* aHandle, const char* aTable, void* aData, void* aDataTwo );

extern int EXPORT_DLL dbmDeleteRangeGT ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int EXPORT_DLL dbmDeleteRangeLT ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int EXPORT_DLL dbmDeleteRangeBT ( dbmHandle* aHandle, const char* aTable, void* aData, void* aDataTwo );

extern int EXPORT_DLL dbmSeqNextVal    ( dbmHandle* aHandle, const char* aTable, long long* aData );
extern int EXPORT_DLL dbmSeqCurrVal    ( dbmHandle* aHandle, const char* aTable, long long* aData );

extern int EXPORT_DLL dbmInsertRow     ( dbmHandle* aHandle, const char* aTable, void* aData, int aSize );
extern int EXPORT_DLL dbmUpdateRow     ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int EXPORT_DLL dbmDeleteRow     ( dbmHandle* aHandle, const char* aTable, void* aData );


extern int EXPORT_DLL dbmCommit        ( dbmHandle* aHandle );
extern int EXPORT_DLL dbmAsyncCommit   ( dbmHandle* aHandle );
extern int EXPORT_DLL dbmDeferCommit   ( dbmHandle* aHandle );
extern int EXPORT_DLL dbmDeferSync     ( dbmHandle* aHandle );
extern int EXPORT_DLL dbmRollback      ( dbmHandle* aHandle );


extern int EXPORT_DLL dbmEnqueue       ( dbmHandle* aHandle, const char* aTable, void* aData, int aDataSize );
extern int EXPORT_DLL dbmDequeue       ( dbmHandle* aHandle, const char* aTable, void* aData, int aTimeOut );


extern int EXPORT_DLL dbmListLpush     ( dbmHandle* aHandle, const char* aTable, void* aData, int aDataSize );
extern int EXPORT_DLL dbmListRpush     ( dbmHandle* aHandle, const char* aTable, void* aData, int aDataSize );
extern int EXPORT_DLL dbmListLpop      ( dbmHandle* aHandle, const char* aTable, void* aData, int aDataSize );
extern int EXPORT_DLL dbmListRpop      ( dbmHandle* aHandle, const char* aTable, void* aData, int aDataSize );
extern int EXPORT_DLL dbmListRange     ( dbmHandle* aHandle, const char* aTable, void* aData, int aDataSize );


extern int EXPORT_DLL dbmGetRowSize    ( dbmHandle* aHandle, const char* aTable, void* aData );
extern int EXPORT_DLL dbmGetIndex      ( dbmHandle* aHandle, const char* aTable, char* aIndexName );
extern int EXPORT_DLL dbmSetIndex      ( dbmHandle* aHandle, const char* aTable, const char* aIndexName );
extern int EXPORT_DLL dbmColBind       ( dbmHandle* aHandle, const char* aTable, const char* aColName, void* aUserData, int aColSize );
extern int EXPORT_DLL dbmUpdateRowByCols ( dbmHandle* aHandle, const char* aTable );
extern int EXPORT_DLL dbmUpdateRowByColsGT ( dbmHandle* aHandle, const char* aTable );
extern int EXPORT_DLL dbmUpdateRowByColsLT ( dbmHandle* aHandle, const char* aTable );
extern int EXPORT_DLL dbmClearBind     ( dbmHandle* aHandle );


extern int EXPORT_DLL dbmExecuteDDL    ( dbmHandle* aHandle, const char* aSQL );
extern int EXPORT_DLL dbmTruncate      ( dbmHandle* aHandle, const char* aTable );

extern int EXPORT_DLL dbmDrop          ( dbmHandle* aHandle, const char* aTable );
#define dbmDropTable  dbmDrop
#define dbmDropIndex  dbmDrop
#define dbmDropQueue  dbmDrop
#define dbmDropSeq    dbmDrop


extern int EXPORT_DLL dbmMetaDeleteRow ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int EXPORT_DLL dbmMetaUpdateRow ( dbmHandle* aHandle, const char* aTable, void* aData, int* aCount );
extern int EXPORT_DLL dbmMetaUpdateRowByCols ( dbmHandle* aHandle, const char* aTable, int* aCount );

#ifdef __cplusplus
};
#endif

#endif /* __ONMIR_DBM_API_H__ */
