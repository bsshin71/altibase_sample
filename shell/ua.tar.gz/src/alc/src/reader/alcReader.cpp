#include <common.h>
#include <commErr.h>
#include <string>
#include <map>
#include <iostream>
#include <dbmAPI.h>



/*************************************************
 * STL 사용
*************************************************/
using namespace std;


/*************************************************
 * DIR Max
*************************************************/
#define D_RULE   ":::"
#define D_TAG    "$TAG="
#define MAX_THR  1024
#define MAX_SLEEP   3
#define MAX_READ 4096
#define MAX_TAG    32
#define MAX_FLAG   32

#define TYPE_C     1
#define TYPE_G     2
#define TYPE_B     3

int bFlag = 0;
void GetTag (char*);


typedef struct
{
    int  mUniqIndex;
    int  mSeq;
    int  mStart;
    int  mBytes;
} SUB_RULE;


typedef struct
{
    char mFileName [32];
    char mDir [512];
    int  mUniqIndex;
} FileInfo;


typedef struct
{
    int   mUniqIndex;
    int   mSeq;
    int   mActSeq;
    char  mVal[255];
} ActLog;

char gToken[32][1024];
SUB_RULE gRule [32];
int  gRuleInd;
int  gInd = 0;
int  gActSeq = 1;
char gUserMsg [1024];


/*************************************************
 * Thread Param
*************************************************/
typedef struct
{
    volatile int     mIndex;           // My Thread ID
    volatile int     mStatus;          // Status Status
    char             mFileName[1024];  // Thread Source FileName
} PARAM;

PARAM gParam [MAX_THR];

/*************************************************
 * Thread Concurrency
*************************************************/
pthread_mutex_t   gMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_t         gTID [MAX_THR];
volatile int      gIndex = 0;




void MatchIt (dbmHandle *aHandle, FileInfo *aFileInfo, char *aBuff)
{
    int  i, j, sum, sum2, sInd, pInd=0;
    int sPos[10];
    char sTmp[1024];
    ActLog sAct;
    int rc;

    rc = dbmPrepareTable (aHandle, "user_log");

    memset (gToken, 0x00, sizeof(gToken));
    for (i=0; i<gRuleInd; i++)
    {
        memset (sTmp, 0x00, sizeof(sTmp));
        memcpy (sTmp, aBuff + gRule[i].mStart, gRule[i].mBytes);   

        memset (&sAct, 0x00, sizeof(ActLog));
        sAct.mUniqIndex = aFileInfo->mUniqIndex;
        sAct.mSeq       = i + 1;
        sAct.mActSeq    = gActSeq++;
        memcpy (&sAct.mVal, sTmp, strlen(sTmp));

        rc = dbmInsertRow (aHandle, "user_log", &sAct, sizeof(ActLog));
        if (rc) 
        {
            //printf("Act Log Insert fail rc=%d\n", rc);
        }
    }
    rc = dbmCommit (aHandle);
}



void GetFromDB (dbmHandle *aHandle, char *aFileName, FileInfo *aFileInfo)
{
    int  rc;
    SUB_RULE  sRule;

    rc = dbmPrepareTable (aHandle, "log_master");
    if (rc)
    {
        printf("prepare log_master fail rc=%d\n", rc);
        return;
    }

    rc = dbmPrepareTable (aHandle, "format_info");
    if (rc)
    {
        printf("prepare format_info fail rc=%d\n", rc);
        return;
    }

    memset (aFileInfo, 0x00, sizeof(FileInfo));
    strcpy (aFileInfo->mFileName, aFileName);
    rc = dbmSelectRow (aHandle, "log_master", aFileInfo);
    if (rc)
    {
        printf("Select log_master fail rc=%d\n", rc);
        exit(-1);
    }


    gRuleInd = 0;
    memset (&sRule, 0x00, sizeof(sRule));
    sRule.mUniqIndex = aFileInfo->mUniqIndex;
    sRule.mSeq       = -1;

    while (1)
    {
        rc = dbmSelectRowGT (aHandle, "format_info", &sRule);
        if (rc) break;

        memcpy (&gRule[gRuleInd], &sRule, sizeof(SUB_RULE));
        gRuleInd++;
    }
 
}


/****************************************************
 * Finder Thread
****************************************************/
void *Reader (void *aParam)
{
    FILE *sFile = NULL;
    char *sBuff = NULL;
    long sPos = 0L;
    int  sInd;
    int  rc;
    FileInfo sFileInfo;
    char sFullName[1024];
    dbmHandle sHandle;


    rc = dbmInitHandle (&sHandle, getenv ("DBM_SHM_PREFIX"));
    if (rc)
    {
        printf("Init Handle fail rc=%d\n", rc);
        goto end_step;
    }



    /***********************************************
     * My Thread ID
    ***********************************************/
    sInd = (int)(((PARAM*)aParam)->mIndex);

    sBuff = (char*)malloc(MAX_READ);
    if (sBuff == NULL)
    {
        printf("alloc fail rc=%d\n", errno);
        gParam[sInd].mStatus = -1;
        return NULL;
    }

    memset (&sFileInfo, 0x00, sizeof(FileInfo));
    GetFromDB (&sHandle, gParam[sInd].mFileName, &sFileInfo);
    sprintf(sFullName, "%s/%s", sFileInfo.mDir, sFileInfo.mFileName);

printf("Thread <%s> starting.\n", sFullName);
    /***********************************************
     * My Thread Status 
    ***********************************************/
    gParam [sInd].mStatus = 1;

    /***********************************************
     * Start working
    ***********************************************/
    while (gParam[sInd].mStatus == 1)
    {
        /***********************************************
         * Open File
        ***********************************************/
        sFile = fopen (sFullName, "r");
        if (sFile == NULL) 
        {
            printf("Open fail rc=%d\n", errno);
            break;
        }
        fseek(sFile, sPos, SEEK_SET);

        /***********************************************
         * Read File
        ***********************************************/
        while (!feof(sFile))
        {
            memset (sBuff, 0x00, MAX_READ);
            if (!fgets (sBuff, MAX_READ, sFile))
            {
                 break;
            }

            printf("New Log catch from <%s>...\n", sFullName);
            MatchIt (&sHandle, &sFileInfo, sBuff);
        } // While Loop

        sPos = ftell(sFile);
        fclose(sFile);
        sleep (MAX_SLEEP);
    }

end_step:
    printf("MyFile <%s> Reader terminated\n", gParam[sInd].mFileName);
    gParam[sInd].mStatus = -1;
   
    if (sBuff != NULL)
    {
        free(sBuff);
    }
    return NULL;
}



/**************************************************
 * Main
**************************************************/
int main(int argc, char *argv[])
{
    int         i;

    if (getenv ("DBM_SHM_PREFIX") == NULL)
    {
        printf("At first, Set DBM_SHM_PREFIX\n");
        exit(-1);
    }

    /**************************************************
     * Check parent working dir
    **************************************************/
    if (argc < 2)
    {
        printf("Usage] %s <FileName> ...\n", argv[0]);
        exit(-1);
    }

    
    memset (&gRule,  0x00, sizeof(gRule));
    memset (gToken,  0x00, sizeof(gToken));
    memset (&gParam, 0x00, sizeof(gParam));
    gRuleInd = 0;
    gIndex   = 0;

    /**************************************************
     * Create first finder thread
    **************************************************/
    printf("Argc = %d\n", argc);
    for (i=1; i<argc; i++)
    {
        gParam [gIndex].mStatus = 0;
        gParam [gIndex].mIndex = gIndex;
        strcpy (gParam[gIndex].mFileName, argv[i]);
        pthread_create (&gTID[gIndex], NULL, Reader, &gParam[gIndex]);

        /**************************************************
         * Waiting until a thread is ready to work.
        **************************************************/
        while (gParam[gIndex].mStatus == 0)
        {
            usleep(1000);
        }
        pthread_detach (gTID[gIndex]);
        gIndex++;
    }
    
    /**************************************************
     * Holding.
    **************************************************/
    while (1)
    {
        sleep (1);
    }

    exit (0);
}
