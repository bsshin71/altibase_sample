#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>


typedef struct
{
    int mStart;
    int mBytes;
} SUB_RULE;



main(int argc, char *argv[])
{
    FILE *fp;
    SUB_RULE sRule;


    fp = fopen("test.format1", "w+");

    sRule.mStart = 1;
    sRule.mBytes = 1;
    fwrite (&sRule, sizeof(sRule), 1, fp);

    sRule.mStart = 3;
    sRule.mBytes = 15;
    fwrite (&sRule, sizeof(sRule), 1, fp);

    sRule.mStart = 19;
    sRule.mBytes = 6;
    fwrite (&sRule, sizeof(sRule), 1, fp);

    fclose(fp);
}
