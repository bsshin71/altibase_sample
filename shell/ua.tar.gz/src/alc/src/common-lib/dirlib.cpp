#include <dirlib.h>
#include <commErr.h>


dirlib::dirlib()
{
    memset (mDirName, 0x00, sizeof(mDirName));
}



dirlib::~dirlib()
{
}



void dirlib::SetDirName (char *aDirName)
{
    strcpy (mDirName, aDirName);
}


char* dirlib::GetDirName ()
{
    return (char*)mDirName;
}


int dirlib::ReadDir ()
{
    struct dirent *sDir, pDir;;

    mDir = opendir (mDirName);
    if (mDir == NULL)
    {
        return ERR_OPEN_DIR_FAIL;
    }

    while (sDir = readdir (mDir))
    {
        memcpy (&pDir, sDir, sizeof(struct dirent));
        mDirInfo.insert(map<string, struct dirent>::value_type (sDir->d_name, pDir));
    }
    closedir (mDir);
}



void dirlib::PrintAll ()
{
    map <string, struct dirent>::iterator sIt;
    struct dirent pDir;

    for (sIt = mDirInfo.begin(); sIt != mDirInfo.end(); sIt++)
    {
         memcpy ((void*)&pDir, (void*)&sIt->second, sizeof(struct dirent));
        fprintf(stdout, "Name <%s>\n", pDir.d_name);
    }
}
