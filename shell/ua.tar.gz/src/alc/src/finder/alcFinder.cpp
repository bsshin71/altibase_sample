#include <common.h>
#include <commErr.h>
#include <string>
#include <map>
#include <iostream>



/*************************************************
 * STL 사용
*************************************************/
using namespace std;

/*************************************************
 * DIR Max
*************************************************/
#define MAX_THR  1024
#define MAX_SLEEP   3

/*************************************************
 * Thread Param
*************************************************/
typedef struct
{
    volatile int     mIndex;           // My Thread ID
    volatile int     mStatus;          // Status Status
    char             mDirName[1024];   // Thread Source Dir
} PARAM;

PARAM gParam [MAX_THR];

/*************************************************
 * Thread Concurrency
*************************************************/
pthread_mutex_t   gMutex = PTHREAD_MUTEX_INITIALIZER;
pthread_t         gTID [MAX_THR];
volatile int      gIndex = 0;



/****************************************************
 * Finder Thread
****************************************************/
void *Finder (void *aParam)
{
    DIR  *sDir;
    struct dirent *sDirInfo;
    struct stat sStat;
    char sFullName[1024];
    map<string, string> sFileList;
    map<string, string> sDirList;
    map<string, string>::iterator sIt;
    int  sInd;


    /***********************************************
     * My Thread ID
    ***********************************************/
    sInd = (int)(((PARAM*)aParam)->mIndex);

    /***********************************************
     * My Thread Status 
    ***********************************************/
    gParam [sInd].mStatus = 1;

    /***********************************************
     * Start working
    ***********************************************/
    while (gParam[sInd].mStatus == 1)
    {
        /***********************************************
         * Open Dir
        ***********************************************/
        sDir = opendir (gParam[sInd].mDirName);
        if (sDir == NULL)
        {
            printf("opendir fail rc=%d\n", errno);
            break;
        }

        /***********************************************
         * Read Dir
        ***********************************************/
        while (sDirInfo = readdir (sDir))
        {
            /***********************************************
             * No Adding
            ***********************************************/
            if (sDirInfo->d_name[0] == '.') 
            {
                continue;
            }

            /***********************************************
             * Make Full File Name
            ***********************************************/
            memset (&sStat, 0x00, sizeof(struct stat));
            sprintf(sFullName, "%s/%s", gParam[sInd].mDirName, sDirInfo->d_name);

            /***********************************************
             * Get File Stat struct
            ***********************************************/
            if (stat (sFullName, &sStat) != 0)
            {
                printf("stat fail rc=%d\n", errno);
                break;
            }
            /***********************************************
             * If File
            ***********************************************/
            if (S_ISREG (sStat.st_mode))
            {
                /*************************************************
                 * Check Duplicated file
                *************************************************/
                sIt = sFileList.find (sFullName);
                if (sIt == sFileList.end())
                {
                    /*************************************************
                     * Add new file
                    *************************************************/
                    printf("New File Adding...<%s>\n", sFullName);
                    sFileList.insert (map<string, string>::value_type (sFullName, sFullName));
                }
            } // FILE
            /***********************************************
             * If Dir, Create New Finder thread
            ***********************************************/
            else if (S_ISDIR (sStat.st_mode))
            {
                pthread_mutex_lock (&gMutex);
                /*************************************************
                 * Check Duplicated Thread
                *************************************************/
                sIt = sDirList.find (sFullName);
                if (sIt == sDirList.end())
                {
                    /*************************************************
                     * create new Thread
                    *************************************************/
                    printf("New Dir Adding...<%s>\n", sFullName);
                    gParam [gIndex].mStatus = 0;
                    gParam [gIndex].mIndex = gIndex;
                    strcpy (gParam[gIndex].mDirName, sFullName);
                    pthread_create (&gTID[gIndex], NULL, Finder, &gParam[gIndex]);
                    while (gParam[gIndex].mStatus == 0)
                    {
                        usleep(1000);
                    }
                    pthread_detach (gTID[gIndex]);

                    sDirList.insert (map<string, string>::value_type (sFullName, sFullName));
                    gIndex++;
                }
                pthread_mutex_unlock (&gMutex);
            } // DIR

        } // While Loop

        closedir (sDir);
        sleep (MAX_SLEEP);
    }

    printf("MyDir <%s> Finder terminated\n", gParam[sInd].mDirName);
    gParam[sInd].mStatus = -1;
    return NULL;
}



/**************************************************
 * Main
**************************************************/
int main(int argc, char *argv[])
{
    int         i;

    /**************************************************
     * Check parent working dir
    **************************************************/
    if (argc < 2)
    {
        printf("Usage] %s <dirName>\n", argv[0]);
        exit(-1);
    }

    memset (&gParam, 0x00, sizeof(gParam));
    gIndex = 0;

    /**************************************************
     * Create first finder thread
    **************************************************/
    gParam [0].mStatus = 0;
    gParam [0].mIndex = gIndex;
    strcpy (gParam[0].mDirName, argv[1]);
    gIndex++;
    pthread_create (&gTID[0], NULL, Finder, &gParam[0]);

    /**************************************************
     * Waiting until a thread is ready to work.
    **************************************************/
    while (gParam[0].mStatus == 0)
    {
        usleep(1000);
    }
    pthread_detach (gTID[0]);
    
    /**************************************************
     * Holding.
    **************************************************/
    while (1)
    {
        sleep (1);
    }

    exit (0);
}
