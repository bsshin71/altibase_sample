#include <dbmAPI.h>
#include <string>
#include <iostream>
#include <map>


using namespace std;

typedef struct
{
    int mUniqIndex;
    int mSeq;
    int mActSeq;
    char mVal[255];
} ActLog;


typedef struct
{
    char mVal[255];
    int  mHit;
} SUB_STAT;


typedef struct
{
    int mCount;
    SUB_STAT mInfo [32];
} STAT;


main()
{
    dbmHandle sHandle;
    ActLog sAct;
    STAT   sInfo [8];
    int    sCount=0;
    int sUniqIndex = 1;
    int sFind = -1;
    int i, j, k, sOut;
    int rc;
    double sum [8];


    if (getenv ("DBM_SHM_PREFIX") == NULL)
    {
        printf("Set DBM_SHM_PREFIX\n");
        exit(-1);
    }
 
    memset (&sInfo, 0x00, sizeof(sInfo));
 
    rc = dbmInitHandle (&sHandle, getenv ("DBM_SHM_PREFIX"));
    if (rc)
    {
        printf("Init Fail rc=%d\n", rc);
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, "user_log");
    if (rc)
    {
        printf("Prep user_log Fail rc=%d\n", rc);
        exit(-1);
    }

    while (1)
    {
        system("clear");
        printf("\n++ START ++\n");
        memset (&sAct, 0x00, sizeof(ActLog));
        sAct.mUniqIndex = 1;
        sAct.mSeq       = -1;
        sAct.mActSeq    = -1;

        while (1)
        {
            rc = dbmSelectRowGT (&sHandle, "user_log", &sAct);
            if (rc) break;

            sFind = -1;
            for (j=0; j<sInfo[sAct.mSeq].mCount; j++)
            {
                if (strncmp (sAct.mVal, sInfo[sAct.mSeq].mInfo[j].mVal, strlen(sAct.mVal)) == 0)
                {
                    sFind = 1;
                    break;
                }
            }
            if (sFind == -1)
            {
                strcpy (sInfo[sAct.mSeq].mInfo[sInfo[sAct.mSeq].mCount].mVal, sAct.mVal);
                sInfo[sAct.mSeq].mInfo[sInfo[sAct.mSeq].mCount].mHit = 1;
                sInfo[sAct.mSeq].mCount++;
            }
            else
            {
                sInfo[sAct.mSeq].mInfo[j].mHit++;
            }
        }

        for (i=0; i<4; i++)
        {
            sum [i]=0;
            for (j=0; j<sInfo[i].mCount; j++)
            {
                sum [i] = sum [i] + sInfo[i].mInfo[j].mHit;
            }

            for (j=0; j<sInfo[i].mCount; j++)
            {
                printf("<%s> Hit <%4d, (%6.2f%%)>", 
                           sInfo[i].mInfo[j].mVal
                         , sInfo[i].mInfo[j].mHit
                         , (double)(sInfo[i].mInfo[j].mHit / sum[i] * 100.0));

                sOut = 30 * (double)(sInfo[i].mInfo[j].mHit / sum[i]);
                for (k=0; k<30; k++)
                {
                    if (k < sOut) printf("■");
                    else printf(" ");
                }
                printf(">\n");
            }
            printf("TotalHit=%.0f\n", sum[i]);
            printf("------------------------------------------------\n");
        }

        memset (&sInfo, 0x00, sizeof(sInfo));
        sleep(10);
    }
}
