#include <common.h>
#include <commErr.h>
#include <string>
#include <map>
#include <iostream>



/*************************************************
 * STL 사용
*************************************************/
using namespace std;

/*************************************************
 * Max Read byte
*************************************************/
#define MAX_READ  4096

char gToken[255][1024];
int  gInd = 0;

/****************************************************
 * delete CR
****************************************************/
void deleteLR(char *aToken)
{
    int i;
    int sLen = strlen(aToken);

    for (i=sLen-1; i>=0; i--)
    {
        if (aToken[i] == '\n') aToken[i] = 0x00;
    }
}


/****************************************************
 * Source code
****************************************************/
int IsSource (char *aToken)
{
    int sLen = strlen(aToken);
    int i;

    for (i=0; i<sLen; i++)
    {
        if (strncmp (aToken + i, (char*)".cpp", 4) == 0 ||
            strncmp (aToken + i, (char*)".c", 2) == 0)
        {
            return 0;
        }
    }

 
    return -1;
}

/****************************************************
 * Number
****************************************************/
int IsNumber (char *aToken)
{
    int  sLen = strlen (aToken);
    int  sCnt = 0;
    int  i;
  
    for (i=0; i<sLen; i++)
    {
        if (isdigit (aToken[i]))
        {
            sCnt++;
        }
    }

    if (sCnt == sLen) return 0;
    return -1;
}


/****************************************************
 * Time 
****************************************************/
int IsTime (char *aToken)
{
    int  sLen = strlen (aToken);
    int  i;
    int  hh = 0, mm = 0, ss = 0;
    int  rc;
  

    for (i=0; i<sLen; i++)
    {
        if (isdigit (aToken[i]) && isdigit (aToken[i+1]))
        {
            if (hh == 0 && aToken[i+2] == ':')
            {
                hh = 1;
            }
            if (hh == 1 && mm == 0 && aToken[i+2] == ':')
            {
                mm = 1;
            }
            if (hh == 1 && mm == 1 && ss == 0)
            {
                ss = 1;
            }
        }
    }

    if (hh && mm && ss) return 0;
    else return -1;
}


/****************************************************
 * pattern
****************************************************/
void GetType (char *aToken)
{
    int     rc;
    int     sScore[10];
    int    (*mFunc[4])(char*);
    int     i, sMax, sPin;
    char    sType[4][20]={"Time", "Source", "Number", "String"};

    for (i=0; i<10; i++) sScore[i] = 0;

    mFunc[0] = IsTime;
    mFunc[1] = IsSource;
    mFunc[2] = IsNumber;

    sPin = 0;
    for (i=0; i<3; i++)
    {
        rc = (*mFunc[i]) (aToken);
        if (rc == 0)
        {
            //printf("<%s maybe!! %s>\n", aToken, sType[i]);
            sScore[i]++;
            sPin = 1;
        }
    }

#if 1
    sMax = 0;
    for (i=0; i<3; i++)
    {
        if (sScore[sMax] < sScore[i]) 
        {
            sMax = i;
        }
    }

    if (sPin == 0) sMax = 3;
    
    printf("<%s:%s> ", aToken, sType[sMax]);
#endif
}

/****************************************************
 * Token with space
****************************************************/
void SplitBySpace (char *aBuff)
{
    char*   sToken;
    int     i;

    gInd = 0;
    sToken = strtok (aBuff, " ");
    while (sToken != NULL)
    {
        strcpy (gToken[gInd], sToken);
        //GetType(sToken);
        sToken = strtok (NULL, " ");
        gInd++;
    }

    for (i=0; i<gInd; i++)
    {
        deleteLR (gToken[i]);
        GetType (gToken[i]);
    }
    printf("\n");
}

/****************************************************
 * Format function
****************************************************/
int Format (char *aFileName)
{
    FILE *sFile = NULL;
    char *sBuff;
    int   sReadCnt = 0;


    memset (gToken, 0x00, sizeof(gToken));
    gInd = 0;

    sBuff = (char*)malloc (MAX_READ);
    if (sBuff == NULL)
    {
        printf("malloc fail rc=%d\n", errno);
        return -1;
    }

    sFile = fopen (aFileName, "r");
    if (sFile == NULL)
    {
        printf("open <%s> fail rc=%d\n", errno);
        return -2;
    }

    while (!feof (sFile))
    {
        memset (sBuff, 0x00, sizeof(sBuff));
        if (!fgets (sBuff, MAX_READ-1, sFile))
        {
            break;
        }

        SplitBySpace (sBuff);
        sReadCnt++;
    }

    fclose (sFile);

    if (sReadCnt == 0)
    {
        return -3;
    }

    return 0;
}



/**************************************************
 * Main
**************************************************/
int main(int argc, char *argv[])
{
    int         i;

    /**************************************************
     * Check logfile
    **************************************************/
    if (argc < 2)
    {
        printf("Usage] %s <FileName>\n", argv[0]);
        exit(-1);
    }


    Format (argv[1]);

    exit (0);
}
