#include <common.h>
#include <commErr.h>
#include <dbmAPI.h>

#define __PNAME     "Definer"
#define MAX_READ    4096

#define DEL_SIZE        1
#define DEF_LINE_COUNT  1024
#define TABLE_NAME      (char*)"format_info"

/*
#define DELIMITER   -1
#define DIGIT       0
#define STRING      1
#define TIME        2
#define mSEC        3
#define uSEC        4
#define nSEC        5
#define DATE1       6
#define DATE2       7
#define WHITE_SPACE 8
#define SINGLE_DEL  9
#define COUPLE_DEL  10
#define DATE_DEL1   11
#define DATE_DEL2   12
#define TIME_DEL    13
#define POINT_DEL   14
*/

#define CFILE       (char*)"c"
#define CPPFILE     (char*)"cpp"
#define HFILE       (char*)"h"
#define HPPFILE     (char*)"hpp"
#define LOGFILE     (char*)"log"

#define CFILE_LEN   1
#define CPPFILE_LEN 3
#define HFILE_LEN   1
#define HPPFILE_LEN 3
#define LOGFILE_LEN 3

#define mSEC_LEN    3
#define uSEC_LEN    6
#define nSEC_LEN    9
#define TIME_LEN    6
#define DATE_LEN    6

#ifdef _DEBUG
#define __PRT(a,...)                 { printf( a, ##__VA_ARGS__); fflush(stdout); }
#else
#define __PRT(a,...)                 { }
#endif

enum token_type
{
    DIGIT   = 0
        , STRING
        , USTRING
        , FILENAME
        , TIME

        , mSEC          //5
        , uSEC
        , nSEC
        , DATE1
        , DATE2

        , LDATE1
        , LDATE2
        , WHITE_SPACE
        , POINT_DEL
        , SINGLE_DEL

        , COUPLE_DEL
        , DATE_DEL1
        , DATE_DEL2
        , TIME_DEL
};

typedef struct Token
{
    char    mStr[MAX_READ+1];
    int     mTokF[1024];
    int     mTokP[1024];
    int     mTokS[1024];
    int     mTokCnt;
} Token;

typedef struct format_info
{
    int     uniq_idx;
    int     seq;
    int     start;
    int     bytes;
} format_info;

void usage()
{
    printf("Usage] %s -f [file_name] {-l [line_count]}\n", __PNAME);
    printf(" The options are:\n");
    printf("  -f, --file        : specify file name\n");
    printf("  -l, --line        : specify line count for sampling\n");
    printf("  -h, --help        : produce this help message\n");
    return;
}

char* Flag2Str(int aFlag)
{
    switch(aFlag)
    {
        case DIGIT:
            return (char*)"NUM";
        case STRING:
            return (char*)"STR";
        case USTRING:
            return (char*)"UNDEF_STR";
        case FILENAME:
            return (char*)"FILENAME";
        case TIME:
            return (char*)"HH:MI:SS";
        case mSEC:
            return (char*)"mSEC";
        case uSEC:
            return (char*)"uSEC";
        case nSEC:
            return (char*)"nSEC";
        case DATE1:
            return (char*)"YY/MM/DD";
        case DATE2:
            return (char*)"YY-MM-DD";
        case LDATE1:
            return (char*)"YYYY/MM/DD";
        case LDATE2:
            return (char*)"YYYY-MM-DD";
        case WHITE_SPACE:
            return (char*)"WS";
        case POINT_DEL:
            return (char*)"pDEL";
        case SINGLE_DEL:
            return (char*)"sDEL";
        case COUPLE_DEL:
            return (char*)"cDEL";
        case DATE_DEL1:
            return (char*)"dDEL1";
        case DATE_DEL2:
            return (char*)"dDEL2";
        case TIME_DEL:
            return (char*)"tDEL";
        default:
            char* temp;
            temp = (char*)malloc(1+1);
            sprintf(temp, "%c", aFlag);
            return temp;
    }
}

int dbmInsert(Token* aTok)
{
    dbmHandle   sHandle;
    format_info sData;
    char*       sInstName   = NULL;
    int         i;
    int         sRet        = 0;

    sInstName = getenv("DBM_SHM_PREFIX");
    if(sInstName == NULL)
    {
        printf("At first, Set DBM_SHM_PREFIX\n");
        return -1;
    }

    sRet = dbmInitHandle(&sHandle, sInstName);
    if(sRet)
    {
        printf("핸들 초기화 실패[%d]\n",sRet);
        return -1;
    }

    sRet = dbmPrepareTable(&sHandle, TABLE_NAME);
    if(sRet)
    {
        printf("테이블 준비 실패[%d]\n",sRet);
        return -1;
    }

    sData.seq = 0;
    for(i=0;i<aTok->mTokCnt;i++)
    {
        if(aTok->mTokF[i]<WHITE_SPACE)
        {
            sData.uniq_idx = 1;
            sData.seq++;
            sData.start = aTok->mTokP[i];
            sData.bytes = aTok->mTokS[i];
            __PRT("[%d][%d][%d][%d]\n", sData.uniq_idx, sData.seq, sData.start, sData.bytes);
            sRet = dbmInsertRow(&sHandle, TABLE_NAME, &sData, sizeof(sData));
            if(sRet)
            {
                printf("삽입 실패[%d]\n",sRet);
                sRet = dbmRollback(&sHandle);
                return -1;
            }
        }
    }

    sRet = dbmCommit(&sHandle);
    if(sRet)
    {
        printf("커밋 실패[%d]\n",sRet);
        sRet = dbmRollback(&sHandle);
        return -1;
    }

    return 0;
}

int isFileName(char* aStr, int aTokLen, Token* aTok)
{
    if(aTok->mTokF[aTok->mTokCnt-1] == POINT_DEL
            && (aTok->mTokF[aTok->mTokCnt-2] == STRING
                || aTok->mTokF[aTok->mTokCnt-2] == DIGIT))
    {
        if(strncasecmp(aStr, CFILE, CFILE_LEN) == 0 && aTokLen == CFILE_LEN
                || strncasecmp(aStr, CPPFILE, CPPFILE_LEN) == 0 && aTokLen == CPPFILE_LEN
                || strncasecmp(aStr, HFILE, HFILE_LEN) == 0 && aTokLen == HFILE_LEN
                || strncasecmp(aStr, HPPFILE, HPPFILE_LEN) == 0 && aTokLen == HPPFILE_LEN
                || strncasecmp(aStr, LOGFILE, LOGFILE_LEN) == 0 && aTokLen == LOGFILE_LEN)
        {
            //파일이네
            aTok->mTokCnt -= 2;
            aTok->mTokF[aTok->mTokCnt] = FILENAME;
            aTok->mTokS[aTok->mTokCnt] += (DEL_SIZE + aTokLen);
            //aTok->mTokP[aTok->mTokCnt] = aPos;
            return FILENAME;
        }
        else
        {
            //파일이네
            aTok->mTokCnt -= 2;
            aTok->mTokF[aTok->mTokCnt] = STRING;
            aTok->mTokS[aTok->mTokCnt] += (DEL_SIZE + aTokLen);
            //aTok->mTokP[aTok->mTokCnt] = aPos;
            return STRING;
        }
    }

    return STRING;
}

int isDateTime(char* aStr, int aTokLen, Token* aTok)
{
    if(aTok->mTokF[aTok->mTokCnt-1] == POINT_DEL
            && aTok->mTokF[aTok->mTokCnt-2] == TIME)
    {
        if(aTokLen == mSEC_LEN)
        {
            __PRT("결과 : 밀리초다.(%s)\n", aStr);
            aTok->mTokF[aTok->mTokCnt] = mSEC;
            aTok->mTokS[aTok->mTokCnt] = mSEC_LEN;
            //aTok->mTokP[aTok->mTokCnt] = aPos;
            return mSEC;
        }
        else if( aTokLen == uSEC_LEN)
        {
            __PRT("결과 : 마이크로초다.(%s)\n", aStr);
            aTok->mTokF[aTok->mTokCnt] = uSEC;
            aTok->mTokS[aTok->mTokCnt] = uSEC_LEN;
            //aTok->mTokP[aTok->mTokCnt] = aPos;
            return uSEC;
        }
        else if( aTokLen == nSEC_LEN)
        {
            __PRT("결과 : 나노초다.(%s)\n", aStr);
            aTok->mTokF[aTok->mTokCnt] = nSEC;
            aTok->mTokS[aTok->mTokCnt] = nSEC_LEN;
            //aTok->mTokP[aTok->mTokCnt] = aPos;
            return nSEC;
        }
    }
    else if(aTok->mTokF[aTok->mTokCnt-1] == TIME_DEL
            && aTok->mTokF[aTok->mTokCnt-2] == DIGIT
            && aTok->mTokF[aTok->mTokCnt-3] == TIME_DEL
            && aTok->mTokF[aTok->mTokCnt-4] == DIGIT)
    {
        if( aTokLen == 2 && atoi(aStr) < 60
                && aTok->mTokS[aTok->mTokCnt-2] == 2
                && aTok->mTokS[aTok->mTokCnt-4] >= 2)
        {
            char* hh;
            char mm[2+1] = {0x00, };
            hh = (char*)malloc(aTok->mTokS[aTok->mTokCnt-4]+1);
            strncpy(hh, aTok->mStr+(aTok->mTokP[aTok->mTokCnt-4]), aTok->mTokS[aTok->mTokCnt-4]);
            strncpy(mm, aTok->mStr+(aTok->mTokP[aTok->mTokCnt-2]), 2);
            if( atoi(hh) < 24 && atoi(mm) < 60 )
            {
                __PRT("결과 : 시간이다.(%s:%s:%s)\n", hh, mm, aStr);
                aTok->mTokCnt-=4;
                aTok->mTokF[aTok->mTokCnt] = TIME;
                aTok->mTokS[aTok->mTokCnt] += TIME_LEN;
                //aTok->mTokP[aTok->mTokCnt] = aPos;
                return TIME;
            }
        }
    }
    else if(aTok->mTokF[aTok->mTokCnt-1] == DATE_DEL1
            && aTok->mTokF[aTok->mTokCnt-2] == DIGIT
            && aTok->mTokF[aTok->mTokCnt-3] == DATE_DEL1
            && aTok->mTokF[aTok->mTokCnt-4] == DIGIT)
    {
        if( aTokLen == 2 && atoi(aStr) < 32
                && aTok->mTokS[aTok->mTokCnt-2] == 2
                && aTok->mTokS[aTok->mTokCnt-4] >= 2)
        {
            char* yy;
            char mm[2+1] = {0x00, };
            yy = (char*)malloc(aTok->mTokS[aTok->mTokCnt-4]+1);
            strncpy(yy, aTok->mStr+(aTok->mTokP[aTok->mTokCnt-4]), aTok->mTokS[aTok->mTokCnt-4]);
            strncpy(mm, aTok->mStr+(aTok->mTokP[aTok->mTokCnt-2]), 2);
            if( atoi(yy) < 100 && atoi(mm) < 13 )
            {
                __PRT("결과 : 날짜1이다.\n");
                //TODO 날자에 대한 조건 확인
                aTok->mTokCnt-=4;
                aTok->mTokF[aTok->mTokCnt] = DATE1;
                aTok->mTokS[aTok->mTokCnt] += DATE_LEN;
                //aTok->mTokP[aTok->mTokCnt] = aPos;
                return DATE1;
            }
            else if( atoi(yy) > 1950 && atoi(yy) < 9999 && atoi(mm) < 13 )
            {
                __PRT("결과 : 날짜1이다.\n");
                //TODO 날자에 대한 조건 확인
                aTok->mTokCnt-=4;
                aTok->mTokF[aTok->mTokCnt] = LDATE1;
                aTok->mTokS[aTok->mTokCnt] += DATE_LEN;
                //aTok->mTokP[aTok->mTokCnt] = aPos;
                return LDATE1;
            }
        }
    }
    else if(aTok->mTokF[aTok->mTokCnt-1] == DATE_DEL2
            && aTok->mTokF[aTok->mTokCnt-2] == DIGIT
            && aTok->mTokF[aTok->mTokCnt-3] == DATE_DEL2
            && aTok->mTokF[aTok->mTokCnt-4] == DIGIT)
    {
        if( aTokLen == 2 && atoi(aStr) < 32
                && aTok->mTokS[aTok->mTokCnt-2] == 2
                && aTok->mTokS[aTok->mTokCnt-4] >= 2)
        {
            char* yy;
            char mm[2+1] = {0x00, };
            yy = (char*)malloc(aTok->mTokS[aTok->mTokCnt-4]+1);
            strncpy(yy, aTok->mStr+(aTok->mTokP[aTok->mTokCnt-4]), aTok->mTokS[aTok->mTokCnt-4]);
            strncpy(mm, aTok->mStr+(aTok->mTokP[aTok->mTokCnt-2]), 2);
            if( atoi(yy) < 100 && atoi(mm) < 13 )
            {
                __PRT("결과 : 날짜1이다.\n");
                //TODO 날자에 대한 조건 확인
                aTok->mTokCnt-=4;
                aTok->mTokF[aTok->mTokCnt] = DATE2;
                aTok->mTokS[aTok->mTokCnt] += DATE_LEN;
                //aTok->mTokP[aTok->mTokCnt] = aPos;
                return DATE2;
            }
            else if( atoi(yy) > 1950 && atoi(yy) < 9999 && atoi(mm) < 13 )
            {
                __PRT("결과 : 날짜1이다.\n");
                //TODO 날자에 대한 조건 확인
                aTok->mTokCnt-=4;
                aTok->mTokF[aTok->mTokCnt] = LDATE2;
                aTok->mTokS[aTok->mTokCnt] += DATE_LEN;
                //aTok->mTokP[aTok->mTokCnt] = aPos;
                return LDATE2;
            }
        }
    }

    return DIGIT;
}

int ConcatWS(char* aStr, int aTokLen, Token* aTok)
{
    int     i   = 0;

    __PRT("토큰 개수 = [%d]\n", aTok->mTokCnt);
    __PRT("[%s]", Flag2Str(aTok->mTokF[aTok->mTokCnt-1]));
    for(i=1;i<aTok->mTokCnt;i++) //mTokCnt-1회 반복해야함.
    {
        if(aTok->mTokF[aTok->mTokCnt-1-i] != WHITE_SPACE)
        {
            break;
        }
        __PRT("[%s]", Flag2Str(aTok->mTokF[aTok->mTokCnt-1-i]));
    }

    __PRT(" %d회 반복\n", i);
    if(i == aTok->mTokCnt)
    {
        //시작부터 공백으로 시작했다.
        //aTok->mTokF[aTok->mTokCnt-i] = STRING;
        aTok->mTokS[aTok->mTokCnt-i] = aTokLen+i;
        aTok->mTokCnt -= i;
        return i;
    }
    else if(i < aTok->mTokCnt && aTok->mTokF[aTok->mTokCnt-1-i] > POINT_DEL )
    {
        //공백(들) 전에 구분자가 있다.
        //공백을 이번 토큰과 합쳐야한다.
        __PRT("공백(들) 전에 구분자가 있다.\n");
        //aTok->mTokF[aTok->mTokCnt-i] = STRING;
        aTok->mTokS[aTok->mTokCnt-i] = aTokLen+i;
        aTok->mTokCnt -= i;
        return i;
    }
    else if(i < aTok->mTokCnt && aTok->mTokF[aTok->mTokCnt-1-i] <= POINT_DEL )
    {
        //공백(들) 전에 구분자가 없다.
        //공백(들) -1개가 토큰과 합쳐져야한다.
        i--;
        //aTok->mTokF[aTok->mTokCnt-i] = STRING;
        aTok->mTokS[aTok->mTokCnt-i] = aTokLen+i;
        aTok->mTokCnt -= i;
        return i;
    }
    else
    {
        //이런상황이 발생할 수 없다.
        abort();
    }

    //aTok->mTokF[aTok->mTokCnt] = STRING;
    aTok->mTokS[aTok->mTokCnt] = aTokLen;
    //aTok->mTokP[aTok->mTokCnt] = aPos;
    return i;
}

int Formatter(char* aStr, Token* aTok, int aPos)
{
    int sTokLen = 0;
    int i = 0;
    int sRet    = 0;

    aTok->mTokP[aTok->mTokCnt] = aPos;

    sTokLen = strlen(aStr);
    for(i=0;i<sTokLen;i++)
    {
        if(!isdigit(aStr[i]))
        {
            break;
        }
    }

    if(i == sTokLen)
    {
        __PRT("결과 : 숫자다.\n");
        if(aTok->mTokF[aTok->mTokCnt-1] == POINT_DEL
                || aTok->mTokF[aTok->mTokCnt-1] == TIME_DEL
                || aTok->mTokF[aTok->mTokCnt-1] == DATE_DEL1
                || aTok->mTokF[aTok->mTokCnt-1] == DATE_DEL2)
        {
            sRet = isDateTime(aStr, sTokLen, aTok);
            if(sRet == mSEC || sRet == uSEC || sRet == nSEC || sRet == TIME || sRet == DATE1 || sRet == DATE2 || sRet == LDATE1 || sRet == LDATE2)
            {
                return sRet;
            }
        }

        __PRT("결과 : 날짜나 시간이 아니다.\n");
        if(aTok->mTokF[aTok->mTokCnt-1] == WHITE_SPACE)
        {
            __PRT("직전이 공백이다.\n");
            sRet = ConcatWS(aStr, sTokLen, aTok);
        }
        else
        {
            aTok->mTokS[aTok->mTokCnt] = sTokLen;
        }
        aTok->mTokF[aTok->mTokCnt] = DIGIT;
        return DIGIT;
    }
    else
    {
        __PRT("결과 : 문자열이다.\n");
        if(aTok->mTokF[aTok->mTokCnt-1] == POINT_DEL)
        {
            __PRT("직전이 마침표이다.\n");
            sRet = isFileName(aStr, sTokLen, aTok);
            //if(sRet == FILENAME)
            //{
                return sRet;
            //}
        }

        if(aTok->mTokF[aTok->mTokCnt-1] == WHITE_SPACE)
        {
            __PRT("직전이 공백이다.\n");
            sRet = ConcatWS(aStr, sTokLen, aTok);
        }
        else
        {
            aTok->mTokS[aTok->mTokCnt] = sTokLen;
        }
        aTok->mTokF[aTok->mTokCnt] = STRING;
        return STRING;
    }

    printf("CRITICAL ERROR!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
    abort();
    return -2;
}

int DelFinder(char* aStr, int* aDel, int* aDelType)
{
    int sStrLen = 0;
    int i = 0;

    sStrLen = strlen(aStr);
    __PRT("STR=[(%d)%s]\n", sStrLen, aStr);
    for(i=0;i<sStrLen;i++)
    {
        switch(aStr[i])
        {
            case ' ':
                *aDel = ' ';
                *aDelType = WHITE_SPACE;
                return i;
                break;
            case '(':
                *aDel = ')';
                *aDelType = COUPLE_DEL;
                return i;
                break;
            case '{':
                *aDel = '}';
                *aDelType = COUPLE_DEL;
                return i;
                break;
            case '[':
                *aDel = ']';
                *aDelType = COUPLE_DEL;
                return i;
                break;
            case '\'':
                *aDel = '\'';
                *aDelType = COUPLE_DEL;
                return i;
                break;
            case '"':
                *aDel = '"';
                *aDelType = COUPLE_DEL;
                return i;
                break;
            case '|':
                *aDel = '|';
                *aDelType = SINGLE_DEL;
                return i;
                break;
            case ',':
                *aDel = ',';
                *aDelType = SINGLE_DEL;
                return i;
                break;
            case '/':
                *aDel = '/';
                *aDelType = DATE_DEL1;
                return i;
                break;
            case '-':
                *aDel = '-';
                *aDelType = DATE_DEL2;
                return i;
                break;
            case ':':
                *aDel = ':';
                *aDelType = TIME_DEL;
                return i;
                break;
            case '.':
                *aDel = '.';
                *aDelType = POINT_DEL;
                return i;
                break;
        }
    }
    return -1;
}

int DelFinder2(char* aStr, int aDel)
{
    int sStrLen = 0;
    int i = 0;

    sStrLen = strlen(aStr);
    __PRT("STR=[(%d)%s]\n", sStrLen, aStr);
    for(i=0;i<sStrLen;i++)
    {
        if(aStr[i] == aDel)
        {
            return i;
        }
    }
    return -1;
}

int Tokenizer(char* aStr, Token* aTok)
{
    char    sTok[1024];
    int     sTokLen = 0;
    int     sDelPos = 0;
    int     sDel    = 0;
    int     i       = 0;
    int     sRet    = 0;

    for(i=0;i<(int)strlen(aStr);i++)
    {
        sDelPos = DelFinder(aStr+i, &sDel, &aTok->mTokF[aTok->mTokCnt]);
        if(sDelPos < 0)
        {
            //TODO 구분자가 없다.
            __PRT("더이상 구분자가 없다.\n");
            strcpy(aTok->mStr+i, aStr+i);
            sRet = Formatter(aStr+i, aTok, i);
            //aTok->mTokP[aTok->mTokCnt] = i;
            aTok->mTokCnt++;
            break;
        }
        else if(sDelPos == 0)
        {
            //TODO 구분자로 시작한다.
            __PRT("구분자로 시작한다.\n");
            __PRT("FIND POSITION=[%d(%c)]\n", sDelPos, aStr[i]);
            aTok->mStr[i] = aStr[i];
            //aTok->mTokF[aTok->mTokCnt] = aStr[i];
            aTok->mTokP[aTok->mTokCnt] = i;
            aTok->mTokS[aTok->mTokCnt] = DEL_SIZE;
            aTok->mTokCnt++;
            if(aTok->mTokF[aTok->mTokCnt-1] == COUPLE_DEL)
            {
                __PRT("처음 대응 구분자 발견.\n");
                sTokLen = DelFinder2(aStr+i+1, sDel);
                if(sTokLen < 0)
                {
                    //대응하는 구분자를 못 찾았다.
                    __PRT("대응하는 구분자를 못 찾았다.\n");
                    continue;
                }
                else if(sTokLen == 0)
                {
                    //대응하는 구분자를 찾았지만 문자열이 비었다.
                    __PRT("대응하는 구분자를 찾았지만 문자열이 비었다.\n");
                    i++;
                    aTok->mStr[i] = aStr[i];
                    //aTok->mTokF[aTok->mTokCnt] = aStr[i];
                    aTok->mTokF[aTok->mTokCnt] = aTok->mTokF[aTok->mTokCnt-1];
                    aTok->mTokP[aTok->mTokCnt] = i;
                    aTok->mTokS[aTok->mTokCnt] = DEL_SIZE;
                    aTok->mTokCnt++;
                }
                else
                {
                    __PRT("대응하는 구분자를 찾았고 문자열이 있다.\n");
                    i++;
                    strncpy(sTok, aStr+i, sTokLen);
                    memset(sTok+sTokLen, 0x00, 1);
                    __PRT("TOKEN=[%s]\n", sTok);
                    //결과에 토큰과 대응 구분자를 함께 복사
                    strncpy(aTok->mStr+i, aStr+i, sTokLen+1);

                    //토큰에 의미를 부여해야한다.
                    sRet = Formatter(sTok, aTok, i);
                    //aTok->mTokP[aTok->mTokCnt] = i;
                    aTok->mTokCnt++;

                    i += sTokLen;
                    //aTok->mTokF[aTok->mTokCnt] = aStr[i];
                    aTok->mTokF[aTok->mTokCnt] = aTok->mTokF[aTok->mTokCnt-2];
                    aTok->mTokP[aTok->mTokCnt] = i;
                    aTok->mTokS[aTok->mTokCnt] = DEL_SIZE;
                    aTok->mTokCnt++;
                }
            }
            else
            {
                __PRT("단독 구분자 발견.\n");
            }
        }
        else
        {
            //TODO 구분자 전에 문자열이 있다.
            __PRT("구분자 전에 문자열이 있다.\n");
            strncpy(sTok, aStr+i, sDelPos);
            memset(sTok+sDelPos, 0x00, 1);
            __PRT("TOKEN=[%s]\n", sTok);
            strncpy(aTok->mStr+i, aStr+i, sDelPos);

            sRet = Formatter(sTok, aTok, i);
            //aTok->mTokP[aTok->mTokCnt] = i;
            aTok->mTokCnt++;
            i += sDelPos-1;
        }
    }

    for(i=0;i<aTok->mTokCnt;i++)
    {
        if(aTok->mTokF[i] == TIME)
        {
            break;
        }
    }

    if(i>=aTok->mTokCnt)
    {
        return -1;
    }

    return 0;
}

int Reader(char* aFileName, int aLimit)
{
    Token*  sToken[10240] = {0x00, };
    Token   sRes = {0x00, };
    FILE*   sFile       = NULL;
    char*   sBuff       = NULL;
    int     sLineCnt    = 0;
    int     sMatchCnt   = INT_MAX;
    int     i,j;
    int     sRet        = 0;

    sBuff = (char*)malloc(MAX_READ+1);

    printf("FILENAME = [%s]\n", aFileName);

    sFile = fopen(aFileName, "r");
    if(sFile == NULL)
    {
        __PRT("open <%s> fail rc=%d\n", aFileName, errno);
        return -2;
    }

    while(!feof(sFile))
    {
        if(sLineCnt >= aLimit)
        {
            break;
        }

        memset(sBuff, 0x00, MAX_READ+1);
        if(!fgets(sBuff, MAX_READ, sFile))
        {
            break;
        }

        sToken[sLineCnt] = (Token*)malloc(sizeof(Token));
        memset(sToken[sLineCnt], 0x00, sizeof(Token));
        if(sBuff[strlen(sBuff)-1] == '\n')
        {
            sBuff[strlen(sBuff)-1] = 0x00;
        }

        printf("%s\n", sBuff);

        sRet = Tokenizer(sBuff, sToken[sLineCnt]);
        if(sRet == 0)
        {
            sLineCnt++;
        }
        else
        {
            free(sToken[sLineCnt]);
        }
    }

#ifdef _DEBUG
    for(i=0;i<sLineCnt;i++)
    {
        printf("%s\n", sToken[i]->mStr);
        __PRT("결과=[%s]\n", sToken[i]->mStr);
        __PRT("토큰 개수=[%d]\n", sToken[i]->mTokCnt);

        //각 토큰 별 시작위치
        for(j=0;j<sToken[i]->mTokCnt;j++)
        {
            printf("[%d]", sToken[i]->mTokP[j]);
        }
        printf("\n");
        //각 토큰 별 크기
        for(j=0;j<sToken[i]->mTokCnt;j++)
        {
            printf("[%d]", sToken[i]->mTokS[j]);
        }
        printf("\n");
        //각 토큰 별 종류
        for(j=0;j<sToken[i]->mTokCnt;j++)
        {
            printf("[%s]", Flag2Str(sToken[i]->mTokF[j]));
        }
        printf("\n");
        /*
           printf("[  POS][ SIZE][      FLAG]\n");
           for(j=0;j<sToken[i]->mTokCnt;j++)
           {
           printf("[%5d]", sToken[i]->mTokP[j]);
           printf("[%5d]", sToken[i]->mTokS[j]);
           printf("[%10s]\n", Flag2Str(sToken[i]->mTokF[j]));
           }
         */
    }
#endif

    for(i=0;i<sLineCnt-1;i++)
    {
        // 검증해야함
        for(j=0;j<sToken[i]->mTokCnt||j<sToken[i+1]->mTokCnt;j++)
        {
            if(sToken[i]->mTokP[j] != sToken[i+1]->mTokP[j]
                    || sToken[i]->mTokS[j] != sToken[i+1]->mTokS[j]
                    || sToken[i]->mTokF[j] != sToken[i+1]->mTokF[j])
            {
                if(!((sToken[i]->mTokF[j] == STRING && sToken[i+1]->mTokF[j] == FILENAME)
                        || (sToken[i]->mTokF[j] == FILENAME && sToken[i+1]->mTokF[j] == STRING)))
                {
                    __PRT("[%d] 부터 다르다.\n", j);
                    //if(sMatchCnt == INT_MAX || sMatchCnt > j)
                    if(j != 0 && sMatchCnt > j)
                    {
                        sMatchCnt = j;
                    }
                    break;
                }
            }
        }
        if(j<sMatchCnt)
        {
            //토큰 개수만큼 비교했을때는 문제 없지만 토큰 개수가 최소 값보다 적은 수이다.
            sMatchCnt = j;
        }
    }
    __PRT("최소 [%d] 부터 다르다.\n", sMatchCnt);

    //정답 생성
    for(i=0;i<sMatchCnt;i++)
    {
        sRes.mTokP[i] = sToken[0]->mTokP[i];
        sRes.mTokS[i] = sToken[0]->mTokS[i];
        sRes.mTokF[i] = sToken[0]->mTokF[i];
    }
    sRes.mTokP[sMatchCnt] = sToken[0]->mTokP[sMatchCnt];
    sRes.mTokS[sMatchCnt] = -1;
    sRes.mTokF[sMatchCnt] = USTRING;
    sRes.mTokCnt = sMatchCnt+1;

    __PRT("토큰 개수=[%d]\n", sRes.mTokCnt);
    //각 토큰 별 시작위치
    for(j=0;j<sRes.mTokCnt;j++)
    {
        printf("[%d]", sRes.mTokP[j]);
    }
    printf("\n");
    //각 토큰 별 크기
    for(j=0;j<sRes.mTokCnt;j++)
    {
        printf("[%d]", sRes.mTokS[j]);
    }
    printf("\n");
    //각 토큰 별 종류
    for(j=0;j<sRes.mTokCnt;j++)
    {
        printf("[%s]", Flag2Str(sRes.mTokF[j]));
    }
    printf("\n");

    //dbm에 삽입
    sRet = dbmInsert(&sRes);
    if( sRet != 0 )
    {
        printf("dbm 삽입 실패\n");
    }

    //printf("[  POS][ SIZE][      FLAG]\n");
    //for(j=0;j<sRes.mTokCnt;j++)
    //{
    //    printf("[%5d]", sRes.mTokP[j]);
    //    printf("[%5d]", sRes.mTokS[j]);
    //    printf("[%10s]\n", Flag2Str(sRes.mTokF[j]));
    //}

    /*
    for(i=0;i<sLineCnt;i++)
    {
        //만들어진 포멧에 맞춰 USTR처리를 한다.
        //크기를 정확하게 기입할까...말까...
        sToken[i]->mTokS[sMatchCnt] = -1;
        sToken[i]->mTokF[sMatchCnt] = USTRING;
        sToken[i]->mTokCnt = sMatchCnt+1;
    }
    */

    /*
    for(i=0;i<sLineCnt;i++)
    {
        printf("%s\n", sToken[i]->mStr);
        __PRT("결과=[%s]\n", sToken[i]->mStr);
        __PRT("토큰 개수=[%d]\n", sToken[i]->mTokCnt);

        //각 토큰 별 시작위치
        for(j=0;j<sToken[i]->mTokCnt;j++)
        {
            printf("[%d]", sToken[i]->mTokP[j]);
        }
        printf("\n");
        //각 토큰 별 크기
        for(j=0;j<sToken[i]->mTokCnt;j++)
        {
            printf("[%d]", sToken[i]->mTokS[j]);
        }
        printf("\n");
        //각 토큰 별 종류
        for(j=0;j<sToken[i]->mTokCnt;j++)
        {
            printf("[%s]", Flag2Str(sToken[i]->mTokF[j]));
        }
        printf("\n");
        //printf("[  POS][ SIZE][      FLAG]\n");
        //for(j=0;j<sToken[i]->mTokCnt;j++)
        //{
        //    printf("[%5d]", sToken[i]->mTokP[j]);
        //    printf("[%5d]", sToken[i]->mTokS[j]);
        //    printf("[%10s]\n", Flag2Str(sToken[i]->mTokF[j]));
        //}
    }
    */

    return 0;
}

int main(int argc, char** argv)
{
    char*               sFileName   = NULL;
    const char* const   sSOpt       = "f:F:l:L:hH";
    const struct option sLOpt[]     =
    {
        {"file",  0, NULL, 'f'},
        {"line",  0, NULL, 'l'},
        {"help",  0, NULL, 'h'},
        {NULL,    0, NULL, 0}
    };
    int     sLimit  = DEF_LINE_COUNT;
    int     sOpt    = 0;

    if(argc < 3)
    {
        usage();
        return -1;
    }

    do{
        sOpt = getopt_long(argc, argv, sSOpt, sLOpt, NULL);
        switch(sOpt)
        {
            case 'f':
            case 'F':
                sFileName = strdup(optarg);
                break;
            case 'l':
            case 'L':
                sLimit = atoi(optarg);
                break;
            case 'h':
            case 'H':
                usage();
                return 0;
                break;
            case -1:
            default:
                break;
        }
    } while(sOpt != -1);

    if(sFileName == NULL)
    {
        usage();
        return -1;
    }
    Reader(sFileName, sLimit);

    return 0;
}
