#ifndef __CMN_DIR_H__
#define __CMN_DIR_H__

#include <common.h>
#include <iostream>
#include <map>
#include <string>


#define DIR_NAME_LEN 1024


using namespace std;

class dirlib
{
    private:
        char mDirName [DIR_NAME_LEN + 1];
        DIR  *mDir;
        map <string, struct dirent> mDirInfo;
    public:

        dirlib();
        ~dirlib();

        void SetDirName  (char *aDirName);
        char* GetDirName ();
        int  ReadDir     ();
        void PrintAll    ();
}; 

#endif

