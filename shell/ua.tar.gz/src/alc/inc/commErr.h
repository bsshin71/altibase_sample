#ifndef __O_ERROR_CODE__
#define __O_ERROR_CODE__


#define ERR_OPEN_DIR_FAIL    1001


#endif
