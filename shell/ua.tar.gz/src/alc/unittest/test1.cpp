#include <dirlib.h>


main()
{
    dirlib *sDir = new dirlib();

    sDir->SetDirName ((char*)"/home/lim272");
    sDir->ReadDir();
    sDir->PrintAll();
}
