/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   udp 를 이용하여 socket like 하게 구현.
 *
 *   Sender 측 :
 *      sciShmMulticastSocket
 *      sciShmMulticastSetSockOpt
 *      sciShmMulticastBind
 *      sciShmMulticastSendTo
 *   Receiver 측 :
 *      sciShmMulticastSocket
 *      sciShmMulticastSetSockOpt
 *      sciShmMulticastBind
 ******************************************************************************/
#include <sciCommon.h>

static void * sciRecvThrFunc( void * aArg );
static mvp_rc_t sciSetBlock( PH_SOCK_MULTI aSock, struct timeval * aTimeout );
static mvp_rc_t sciSetNonBlock( PH_SOCK_MULTI  aGenHandle );
mvp_rc_t sciSetMtuSize( PH_SOCK_MULTI        aSock,
                        struct sockaddr_in * aAddr );


/*******************************************************************************
 * Name : sciSockMulticastSocket
 *
 * Description :
 *   sock multicast socket 을 하나 생성한 후 이를 관리할 Handle 을 리턴한다.
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *
 * Return :
 *   ptr to H_SOCK_MULTI : 성공, NULL : 실패
 *
 * How To Use :
 ******************************************************************************/
PH_SOCK_MULTI sciSockMulticastSocket( PHSOCKET aGenHandle )
{
    mvp_rc_t       sRC   = 0;
    PH_SOCK_MULTI  sSock = NULL;
    SocketHandle * sGenHandle;

    _IF_RAISE( aGenHandle == NULL, INVALID_ARG );
    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_MULTI)malloc(sizeof(H_SOCK_MULTI));
    _IF_RAISE( sSock == NULL, LACK_OF_MEMORY );
    memset( sSock, 0x00, sizeof(H_SOCK_MULTI));

    _IF_RAISE( (sSock->mSockFd = socket( AF_INET,
                                              SOCK_DGRAM,
                                              0 ))
                    < 0, SOCK_CREAT_FAIL );

    sSock->mOption.mPollingType     = SCI_POLLING_DEFAULT;
    sSock->mOption.mSyncRecvF       = 0;
    sSock->mOption.mSyncRecvTimeout = -1;  /* infinite */
    sSock->mOption.mRecvPollCount   = 0;

    sSock->mClosed  = 0;
    sSock->mMtuSize = 4096;

    sSock->mGenHandle = sGenHandle;

    DEBUG(__f, "socket creation ok. fd[%d]", sSock->mSockFd);

    sRC = sciSetNonBlock( sSock );
    _IF_RAISE( sRC < 0, ETC_ERROR );

    sGenHandle->mSubHandle = sSock;

    return sSock;

    _EXCEPTION( INVALID_ARG )
    {
        DEBUG(__f, "invalid argument : aGenHandle[%d]", 0);
        errno = EINVAL;
    }
    _EXCEPTION( LACK_OF_MEMORY )
    {
        DEBUG(__f, "malloc fail : %s", strerror(errno));
        errno = ENOMEM;
    }
    _EXCEPTION( SOCK_CREAT_FAIL )
    {
        DEBUG(__f, "socket create fail : %s", strerror(errno));
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    if( sSock != NULL )
    {
        free( sSock );
    }

    return NULL;
}


/*******************************************************************************
 * Name : sciSockMulticastListen
 *
 * Description :
 *   Not Supported
 *
 * Argument :
 *   @aGenHandle  : general socket handle
 *   @aBackLog    : back log
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockMulticastListen( PHSOCKET      aGenHandle,
                                 mvp_sint32_t  aBackLog )
{
    errno = EOPNOTSUPP;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockMulticastAccept
 *
 * Description :
 *   Not Supported
 *
 * Argument :
 *   @aGenHandle : accept general socket handle
 *   @aAddr      : sockaddr 구조체 포인터
 *   @aAddrLen   : sizeof(sockaddr)
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
PH_SOCK_MULTI sciSockMulticastAccept( PHSOCKET    aGenListen,
                                      PHSOCKET    aGenAccept,
                                      struct sockaddr * aAddr,
                                      socklen_t * aLen )
{
    errno = EOPNOTSUPP;

    return NULL;
}


/*******************************************************************************
 * Name : sciSockMulticastConnect
 *
 * Description :
 *   Not Supported
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *   @aServAddr  : Server 주소
 *   @aAddrLen   : Server 주소 Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockMulticastConnect( PHSOCKET       aGenHandle,
                                  const struct sockaddr * aAddr,
                                  socklen_t      aLen )
{
    errno = EOPNOTSUPP;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockMulticastBind
 *
 * Description :
 *   Udp 에서의 bind 역할을 수행한다.
 *
 * Argument :
 *   @aGenHandle  : general socket handle
 *   @aAddr       : sockaddr 구조체 포인터
 *   @aAddrLen    : sizeof(sockaddr)
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockMulticastBind( PHSOCKET          aGenHandle,
                               struct sockaddr * aAddr,
                               socklen_t         aLen )
{
    mvp_rc_t            sRC   = 0;
    struct sockaddr_in  sAny;
    PH_SOCK_MULTI       sSock = NULL;
    SocketHandle      * sGenHandle;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );
    _IF_RAISE( aAddr == NULL || aLen <= 0, INVALID_ARG );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_MULTI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    memcpy( &sSock->mSrcAddrIn, aAddr, aLen );
    sSock->mMtuSize = 4096;

    /*
    if( sSock->mSrcAddrIn.sin_addr.s_addr == INADDR_ANY )
    {
        sSock->mMtuSize = 4096;
    }
    else
    {
        sRC = sciSetMtuSize( sSock, (struct sockaddr_in *)aAddr );
        _IF_RAISE( sRC != 0, SET_MTUSIZE_ERROR );
    }
    */

    if( ((struct sockaddr_in *)aAddr)->sin_port == 0 )
    {
        _IF_RAISE( (sRC = bind( sSock->mSockFd,
                                     (struct sockaddr *)aAddr,
                                     aLen ))
                        != 0, BIND_ERROR );
        DEBUG(__f, "bind ok. sockfd[%d] port[%d]",
                sSock->mSockFd, ntohs(((struct sockaddr_in *)aAddr)->sin_port));
    }
    else
    {
        memcpy( &sAny, aAddr, aLen );
        sAny.sin_addr.s_addr = htonl(INADDR_ANY);

        _IF_RAISE( (sRC = bind( sSock->mSockFd,
                                     (struct sockaddr *)&sAny,
                                     aLen ))
                        != 0, BIND_ERROR );

        /* sync recv mode 일 때는 recv thread 불필요 */
        if( sSock->mOption.mSyncRecvF == 0 )
        {
            _IF_RAISE( (sRC = pthread_create( &sSock->mRecvThr,
                                                   NULL,
                                                   sciRecvThrFunc,
                                                   (void *)sGenHandle ))
                            != 0, CREATE_RCVTHR_ERROR );
        }
        DEBUG(__f, "bind ok. sockfd[%d] port[%d]", sSock->mSockFd, ntohs(sAny.sin_port));
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    /*
    _EXCEPTION( SET_MTUSIZE_ERROR )
    {
        DEBUG(__f, "set mtu size fail : %s", strerror(errno));
    }
    */
    _EXCEPTION( BIND_ERROR )
    {
        DEBUG(__f, "bind fail : %s", strerror(errno));
    }
    _EXCEPTION( CREATE_RCVTHR_ERROR )
    {
        DEBUG(__f, "create recv thr fail : %s", strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockMulticastSend
 *
 * Description :
 *   Not Supported
 *
 * Argument :
 *   @aGenHandle  : sock multicast general handle
 *   @aBuf        : 보낼 Data Buffer
 *   @aLen        : 보낼 Data Length
 *   @aFlag       : 현재 미사용
 *
 * Return :
 *   Send Length : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockMulticastSend( PHSOCKET         aGenHandle,
                               const void     * aMsg,
                               mvp_size_t       aLen,
                               mvp_sint32_t     aFlags )
{
    errno = EOPNOTSUPP;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockMulticastSendTo
 *
 * Description :
 *   socket multicast(udp) socket handle 을 이용하여 Data 를 send 한다.
 *
 * Argument :
 *   @aCnxt    : sock multicast socket handle
 *   @aData    : 보낼 Data Buffer
 *   @aLength  : 보낼 Data Length
 *   @aFlag    : 현재 미사용
 *   @aTo      : 수신측 주소
 *   @aToLen   : 수신측 주소 길이
 *
 * Return :
 *   Send Length : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockMulticastSendTo( PHSOCKET       aGenHandle,
                                 const void   * aMsg,
                                 mvp_size_t     aLen,
                                 mvp_sint32_t   aFlags,
                                 const struct sockaddr * aTo,
                                 socklen_t      aToLen )
{
    mvp_size_t      sSendLen = 0;
    mvp_sint32_t    sRet     = 0;
    PH_SOCK_MULTI   sSock    = NULL;
    SocketHandle  * sGenHandle;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_MULTI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    _IF_RAISE( aTo == NULL || aToLen <= 0, INVALID_ARG );
    _IF_RAISE( aLen > (mvp_size_t)sSock->mMtuSize, TOO_BIG_MSGSIZE );


    while( 1 )
    {
        _IF_RAISE( (sRet = sendto( sSock->mSockFd,
                                        (mvp_char_t *)aMsg + sSendLen,
                                        aLen - sSendLen,
                                        0,
                                        (struct sockaddr *)aTo,
                                        aToLen ))
                        == 0, DISCONNECTED );

        if( sRet < 0 )
        {
            if( errno == EWOULDBLOCK )
            {
                continue;
            }
            else
            {
                _RAISE( DISCONNECTED );
            }
        }
        else
        {
            sSendLen += sRet;
            if( sSendLen == aLen )
            {
                /* SEND COMPLETE */
                break;
            }
        }
    }

    return aLen;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( TOO_BIG_MSGSIZE )
    {
        DEBUG(__f, "too big msgsize[%ld] > mtu[%d]", aLen, sSock->mMtuSize);
        errno = EMSGSIZE;
    }
    _EXCEPTION( DISCONNECTED )
    {
        DEBUG(__f, "disconnected. sockfd[%d]", sSock->mSockFd);
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockMulticastGetSockOpt
 *
 * Description :
 *   sock multicast 에서 getsockopt 역할 수행
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *   @aLevel     : Option Level
 *   @aOptName   : Option Name
 *   @aValue     : Option Value
 *   @aLength    : Option Value Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockMulticastGetSockOpt( PHSOCKET       aGenHandle,
                                     mvp_sint32_t   aLevel,
                                     mvp_sint32_t   aOptName,
                                     void         * aOptVal,
                                     socklen_t    * aOptLen )
{
    PH_SOCK_MULTI             sSock = NULL;
    SocketHandle            * sGenHandle;
    struct sciSocketOption  * sOptAll;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_MULTI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL || sSock->mSockFd <= 0, INVALID_HANDLE );

    switch( aLevel )
    {
        case SOL_COMMON :
            switch( aOptName )
            {
                case SO_RECV_CB :
                    *aOptLen = sizeof(sSock->mRecvCBFunc);
                    if( aOptVal != NULL )
                    {
                        *((sciRecvCallBack **)aOptVal) = sSock->mRecvCBFunc;
                    }
                    break;
                case SO_RECV_PARAM :
                    *aOptLen = sizeof(sSock->mRecvCBParam);
                    if( aOptVal != NULL )
                    {
                        *((void **)aOptVal) = sSock->mRecvCBParam;
                    }
                    break;
                case SO_EVENT_CB :
                    *aOptLen = sizeof(sSock->mEventCBFunc);
                    if( aOptVal != NULL )
                    {
                        *((sciEventCallBack **)aOptVal) = sSock->mEventCBFunc;
                    }
                    break;
                case SO_EVENT_PARAM :
                    *aOptLen = sizeof(sSock->mEventCBParam);
                    if( aOptVal != NULL )
                    {
                        *((void **)aOptVal) = sSock->mEventCBParam;
                    }
                    break;
                case SO_POLLING_TYPE :
                    *aOptLen = sizeof(sSock->mOption.mPollingType);
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mPollingType;
                    }
                    break;
                case SO_SYNC_RECV :
                    *aOptLen = sizeof(sSock->mOption.mSyncRecvF);
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mSyncRecvF;
                    }
                    break;
                case SO_RECV_POLL :
                    *aOptLen = sizeof(sSock->mOption.mRecvPollCount);
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mRecvPollCount;
                    }
                    break;
                case SO_OPT_ALL :
                    if( aOptVal != NULL )
                    {
                        sOptAll = (struct sciSocketOption *)aOptVal;

                        sOptAll->common.recv_callback_func   = sSock->mRecvCBFunc;
                        sOptAll->common.recv_callback_param  = sSock->mRecvCBParam;
                        sOptAll->common.event_callback_func  = sSock->mEventCBFunc;
                        sOptAll->common.event_callback_param = sSock->mEventCBParam;

                        sOptAll->common.polling_type = sSock->mOption.mPollingType;
                        sOptAll->common.sync_recv_f  = sSock->mOption.mSyncRecvF;
                        memcpy(&sOptAll->common.sync_recv_timeout, &sSock->mOption.mSyncRecvTimeout, sizeof(struct timeval));
                        sOptAll->common.recv_poll_count   = sSock->mOption.mRecvPollCount;
                    }
                    *aOptLen = sizeof(struct sciSocketOption);
                    break;
                default :
                    _RAISE( INVALID_ARG );
                    break;
            }
            break;
        case SOL_SOCK :
            _RAISE( INVALID_ARG );
            break;
        default :
            return getsockopt( sSock->mSockFd, aLevel, aOptName, aOptVal, aOptLen );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockMulticastSetSockOpt
 *
 * Description :
 *   Udp 에서 setsockopt 역할 수행
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *   @aLevel     : Option Level
 *   @aOptName   : Option Name
 *   @aValue     : Option Value
 *   @aLength    : Option Value Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockMulticastSetSockOpt( PHSOCKET       aGenHandle,
                                     mvp_sint32_t   aLevel,
                                     mvp_sint32_t   aOptName,
                                     const void   * aOptVal,
                                     socklen_t      aOptLen )
{
    PH_SOCK_MULTI             sSock = NULL;
    SocketHandle            * sGenHandle;
    struct sciSocketOption  * sOptAll;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_MULTI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL || sSock->mSockFd <= 0, INVALID_HANDLE );

    switch( aLevel )
    {
        case SOL_COMMON :
            switch( aOptName )
            {
                case SO_RECV_CB :
                    sSock->mRecvCBFunc = (sciRecvCallBack *)aOptVal;
                    break;
                case SO_RECV_PARAM :
                    sSock->mRecvCBParam = (void *)aOptVal;
                    break;
                case SO_EVENT_CB :
                    sSock->mEventCBFunc = (sciEventCallBack *)aOptVal;
                    break;
                case SO_EVENT_PARAM :
                    sSock->mEventCBParam = (void *)aOptVal;
                    break;
                case SO_POLLING_TYPE :
                    sSock->mOption.mPollingType = *(mvp_sint32_t *)aOptVal;
                    DEBUG(__f, "polling type[%d] fd[%d]", sSock->mOption.mPollingType, sSock->mSockFd);
                    break;
                case SO_SYNC_RECV :
                    /*
                     * sync recv mode 에서는 recv thread 가 별도로 떠있으면 안되므로
                     * 강제로 cancle 해버려야 함.
                     */
                    if( sSock->mRecvThr != (pthread_t)0 )
                    {
                        if( pthread_kill( sSock->mRecvThr, 0 ) == 0 )
                        {
                            pthread_cancel( sSock->mRecvThr );
                        }
                        pthread_join( sSock->mRecvThr, NULL );
                    }
                    sSock->mOption.mSyncRecvF = 1;
                    sSock->mOption.mSyncRecvTimeout = ((struct timeval *)aOptVal)->tv_sec;
                    DEBUG(__f, "set sync recv mode. sec[%d] fd[%d]", sSock->mOption.mSyncRecvTimeout, sSock->mSockFd);
                    break;
                case SO_RECV_POLL :
                    _IF_RAISE( aOptVal == NULL
                            || aOptLen != sizeof(mvp_sint32_t), INVALID_ARG );
                    sSock->mOption.mRecvPollCount = *((mvp_sint32_t *) aOptVal);
                    DEBUG(__f, "set recvpoll count[%d] fd[%d]", sSock->mOption.mRecvPollCount, sSock->mSockFd);
                    break;
                case SO_OPT_ALL :
                    sOptAll = (struct sciSocketOption *)aOptVal;

                    sSock->mRecvCBFunc  = sOptAll->common.recv_callback_func;
                    sSock->mRecvCBParam = sOptAll->common.recv_callback_param;

                    sSock->mEventCBFunc  = sOptAll->common.event_callback_func;
                    sSock->mEventCBParam = sOptAll->common.event_callback_param;

                    sSock->mOption.mPollingType = sOptAll->common.polling_type;

                    if( sOptAll->common.sync_recv_f == 1 && sSock->mOption.mSyncRecvF == 0 )
                    {
                        if( sSock->mRecvThr != (pthread_t)0 )
                        {
                            if( pthread_kill( sSock->mRecvThr, 0 ) == 0 )
                            {
                                pthread_cancel( sSock->mRecvThr );
                            }
                            pthread_join( sSock->mRecvThr, NULL );
                        }
                        sSock->mOption.mSyncRecvF = 1;
                        sSock->mOption.mSyncRecvTimeout = sOptAll->common.sync_recv_timeout.tv_sec;
                    }

                    sSock->mOption.mRecvPollCount = sOptAll->common.recv_poll_count; 
                    break;
                default :
                    _RAISE( INVALID_ARG );
                    break;
            }
            break;
        case SOL_SOCK :
            _RAISE( INVALID_ARG );
            break;
        default :
            return setsockopt( sSock->mSockFd, aLevel, aOptName, aOptVal, aOptLen );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockMulticastClose
 *
 * Description :
 *   Socket Close
 *
 * Argument :
 *   @aGenHandle    : general socket handle
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockMulticastClose( PHSOCKET   aGenHandle )
{
    PH_SOCK_MULTI   sSock = NULL;
    SocketHandle  * sGenHandle;
    mvp_rc_t        sRC   = 0;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_MULTI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    sSock->mClosed = 1;

    if( sSock->mRecvThr != (pthread_t)0 )
    {
        if( pthread_kill( sSock->mRecvThr, 0 ) == 0 )
        {
            pthread_cancel( sSock->mRecvThr );
        }
        pthread_join( sSock->mRecvThr, NULL );
    }

    if( sSock->mSockFd > 0 )
    {
        sRC = close( sSock->mSockFd );
        _IF_RAISE( sRC != 0, ETC_ERROR );
        DEBUG(__f, "socket close ok. fd[%d]", sSock->mSockFd);
    }

    if( sSock != NULL )
    {
        free( sSock );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockMulticastRecv
 *
 * Description :
 *   Not Supported
 *
 * Argument :
 *   @aGenHandle  : sock multicast general handle
 *   @aBuf        : 받을 Data Buffer
 *   @aLen        : 받을 Data Length
 *   @aFlag       : 현재 미사용
 *
 * Return :
 *   Recv Length : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockMulticastRecv( PHSOCKET         aGenHandle,
                               void           * aBuf,
                               mvp_size_t       aLen,
                               mvp_sint32_t     aFlags )
{
    mvp_rc_t        sRet      = 0;
    PH_SOCK_MULTI   sSock     = NULL;
    mvp_size_t      sRemain   = 0;
    struct sockaddr sFrom;
    socklen_t       sFromLen;
    mvp_sint64_t    sPoll      = 0;
    mvp_sint64_t    sRate      = 0;
    fd_set          sFdSet;
    sciSleep        sXS;
    struct timeval  sTimeout;
    SocketHandle  * sGenHandle;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_MULTI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    _IF_RAISE( sSock->mOption.mSyncRecvF == 0, NO_SYNC_RECV_MODE );

    if( sSock->mOption.mRecvPollCount > 1 )
    {
        sRate = 1000000 / sSock->mOption.mRecvPollCount;
    }
    else
    {
        sRate = 0;
    }

    sRemain = aLen;
    sFromLen = sizeof(sFrom);

RETRY:
    sRet = recvfrom( sSock->mSockFd, (mvp_char_t*)aBuf + (aLen-sRemain), sRemain, 0, &sFrom, &sFromLen );
    if( sRet == 0 )
    {
        _RAISE( DISCONNECTED );
    }
    else if( sRet < 0 )
    {
        if( errno == EWOULDBLOCK )
        {
            sPoll++;

            if( sSock->mOption.mRecvPollCount == -1 )
            {
                /* TODO
                 *   1 번 polling 이 대충 100 ns 정도라고 예상하고
                 *   사용자가 준 시간(초) * 3,000,000 를 곱해서
                 *   이 횟수가 넘으면 timeout 으로 간주한다.
                 *   socket 을 busy wait 으로 설정했을 때조차도 
                 *   사용자의 recv timeout 을 무시하지 않기위한 궁여지책.
                 */
                if( sPoll > (sSock->mOption.mSyncRecvTimeout * 3000000) )
                {
                    _RAISE( TIMEOUT );
                }
                else
                {
                    goto RETRY;
                }
            }

            /* spin wait */
            if( sPoll < sSock->mOption.mRecvPollCount )
            {
                if( sRate != 0 )
                {
                    sciSleepNano( &sXS, sRate );
                }
                else
                {
                }
                goto RETRY;
            }
            else
            {
                sPoll = 0;

                while(1)
                {
                    /*
                     * mRecvPollCount 만큼 빨리 polling 해보고 
                     * 없으면 사용자가 지정한 시간만큼 select 에서 대기한다.
                     * packet 이 계속 없으면 사용자가 지정한 timeout 으로 에러 리턴한다.
                     */
                    sTimeout.tv_sec  = sSock->mOption.mSyncRecvTimeout;
                    sTimeout.tv_usec = 0;

                    FD_ZERO( &sFdSet );
                    FD_SET( sSock->mSockFd, &sFdSet );

                    sRet = select( sSock->mSockFd+1, &sFdSet, NULL, NULL, &sTimeout );

                    _IF_RAISE( sRet < 0, SELECT_ERROR );
                    _IF_RAISE( sRet == 0, TIMEOUT );

                    if( sRet < 0 )
                    {
                        if( errno == EWOULDBLOCK )
                        {
                            continue;
                        }
                        else
                        {
                            _RAISE( DISCONNECTED );
                        }
                    }
                    else
                    {
                        /* 실제로 데이터가 도착했으므로 recv 로 */
                        goto RETRY;
                    }
                }
            }
        }
        else
        {
            _RAISE( DISCONNECTED );
        }
    }
    else
    {
        /* 일단 데이터를 받으면 polling cnt 초기화 */
        sPoll = 0;

        if( sRet == (mvp_sint32_t)sRemain )
        {
            goto DONE;
        }
        else
        {
            sRemain -= sRet;
            goto RETRY;
        }
    }

DONE:
    return aLen;

    _EXCEPTION( INVALID_HANDLE )
    {
        DEBUG(__f, "invalid socket handle[%d]", 0 );
        errno = EBADF;
    }
    _EXCEPTION( NO_SYNC_RECV_MODE )
    {
        DEBUG(__f, "socket is not syncrecv mode. SO_SYNC_RECV for sciRecv. fd[%d]", sSock->mSockFd );
        errno = EAGAIN;
    }
    _EXCEPTION( SELECT_ERROR )
    {
        DEBUG(__f, "select fail[%d] : %s", sSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( DISCONNECTED )
    {
        DEBUG(__f, "disconnected[%d]", sSock->mSockFd);
    }
    _EXCEPTION( TIMEOUT )
    {
        errno = EAGAIN;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


static mvp_rc_t sciSetBlock( PH_SOCK_MULTI    aSock,
                             struct timeval * aTimeout )
{
    mvp_rc_t      sRC   = 0;
    mvp_sint32_t  sFlag = 0;

    _IF_RAISE( aSock == NULL, INVALID_HANDLE );

    _IF_RAISE( (sFlag = fcntl( aSock->mSockFd,
                                    F_GETFL,
                                    0 ))
                    < 0, GET_FCNTL_ERROR );

    _IF_RAISE( (sRC = fcntl( aSock->mSockFd,
                                  F_SETFL,
                                  sFlag & ~O_NONBLOCK ))
                    < 0, SET_FCNTL_ERROR );

    _IF_RAISE( (sRC = setsockopt( aSock->mSockFd,
                                       SOL_SOCKET,
                                       SO_RCVTIMEO,
                                       (void*)aTimeout,
                                       sizeof(struct timeval)))
                    != 0, SET_SOCKOPT_FAIL );

    DEBUG(__f, "set block mode. fd[%d]", aSock->mSockFd);

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( GET_FCNTL_ERROR )
    {
        DEBUG(__f, "get fcntl fail[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( SET_FCNTL_ERROR )
    {
        DEBUG(__f, "set fcntl fail[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( SET_SOCKOPT_FAIL )
    {
        DEBUG(__f, "setsockopt fail. fd[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciSetMtuSize( PH_SOCK_MULTI        aSock,
                        struct sockaddr_in * aAddr )
{
    mvp_rc_t             sRC      = 0;
    mvp_sint32_t         sMaxCnt  = 256;
    mvp_sint32_t         sListCnt = 0;
    struct ifreq       * sIfRq    = NULL;
    struct ifconf        sIfCfg;
    struct sockaddr_in * sSin;
    mvp_sint32_t         i;

    _IF_RAISE( aSock == NULL, INVALID_HANDLE );

    memset( &sIfCfg, 0x00, sizeof(sIfCfg) );

    sIfCfg.ifc_len = sizeof(struct ifreq) * sMaxCnt;

    sIfCfg.ifc_buf = (mvp_char_t *)malloc(sIfCfg.ifc_len);
    _IF_RAISE( sIfCfg.ifc_buf == NULL, NO_MEMORY );

    sRC = ioctl( aSock->mSockFd, SIOCGIFCONF, &sIfCfg );
    _IF_RAISE( sRC != 0, ETC_ERROR );

    sListCnt = sIfCfg.ifc_len/sizeof(struct ifreq);

    for( i = 0; i < sListCnt; i++)
    {
        sIfRq = (struct ifreq *)sIfCfg.ifc_buf + i * (sizeof(struct ifreq));

        sRC = ioctl( aSock->mSockFd, SIOCGIFHWADDR, sIfRq );
        sRC = ioctl( aSock->mSockFd, SIOCGIFADDR, sIfRq );
        _IF_RAISE( sRC != 0, ETC_ERROR );

        sSin = (struct sockaddr_in *)&sIfRq->ifr_addr;

        if( memcmp( &aAddr->sin_addr, &sSin->sin_addr, sizeof(sSin->sin_addr)) == 0 )
        {
            sRC = ioctl( aSock->mSockFd, SIOCGIFMTU, sIfRq );
            _IF_RAISE( sRC != 0, ETC_ERROR );

            aSock->mMtuSize  = sIfRq->ifr_mtu;
            aSock->mMtuSize -= 20;  /* IP Header */
            break;
        }
    }

    _IF_RAISE( aSock->mMtuSize <= 0, ETC_ERROR );

    free(sIfCfg.ifc_buf);

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( NO_MEMORY )
    {
        errno = ENOMEM;
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciRecvThrFunc
 *
 * Description :
 *   Data 를 recv 하여 처리하는 함수
 *
 * Argument :
 *   @aArg  : thread argument
 *
 * Return :
 *   N/A
 *
 * How To Use :
 ******************************************************************************/
static void * sciRecvThrFunc( void * aArg )
{
    SocketHandle * sGenHandle = (SocketHandle *)aArg;
    mvp_rc_t       sRet     = 0;
    PH_SOCK_MULTI  sSock    = NULL;
    mvp_char_t   * sBuf     = NULL;
    fd_set         sFdSet;
    mvp_sint32_t   sSockFd;
    socklen_t      sAddrLen = 0;
    mvp_sint64_t   sRate    = 0;
    mvp_sint32_t   sPoll    = 0;
    sciSleep       sXS;
    struct timeval sTimeout;
    struct sockaddr_in sCliAddr;

    DEBUG(__f, "receive thread start. thrid[%ld]", pthread_self());

    _IF_RAISE( sGenHandle == NULL, INVALID_HANDLE );
    sSock = (PH_SOCK_MULTI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    sBuf = (mvp_char_t *)malloc(sSock->mMtuSize);
    _IF_RAISE( sBuf == NULL, LACK_OF_MEMORY );

    sSockFd = sSock->mSockFd;

    if( sSock->mOption.mRecvPollCount > 1 )
    {
        sRate = 1000000 / sSock->mOption.mRecvPollCount;
    }
    else
    {
        sRate = 0;
    }

    sPoll = 0;

    sAddrLen = sizeof(sCliAddr);

    while( sSock->mClosed == 0 )
    {
        sRet = recvfrom( sSock->mSockFd, sBuf, sSock->mMtuSize,
                         0, (struct sockaddr *)&sCliAddr, &sAddrLen);
        if( sRet == 0 )
        {
            _RAISE( DISCONNECTED );
        }
        else if( sRet < 0 )
        {
            if( errno == EWOULDBLOCK )
            {
                /* non blocking + busy wait 일 때는 계속 recv 만 call */
                if( sSock->mOption.mRecvPollCount == -1 )
                {
                    continue;
                }

                sPoll++;

                /* spin wait */
                if( sPoll < sSock->mOption.mRecvPollCount )
                {
                    if( sRate != 0 )
                    {
                        sciSleepNano( &sXS, sRate );
                        continue;
                    }
                    else
                    {
                    }
                }
                else
                {
                    sPoll = 0;

                    /* wait infinitely until data receives */
                    sTimeout.tv_sec  = 999999999;
                    sTimeout.tv_usec = 0;

                    FD_ZERO( &sFdSet );
                    FD_SET( sSock->mSockFd, &sFdSet );

                    sRet = select( sSock->mSockFd+1, &sFdSet, NULL, NULL, &sTimeout );

                    _IF_RAISE( sRet < 0, SELECT_ERROR );

                    if( sRet == 0 )
                    {
                        continue;
                    }
                    else if( sRet < 0 )
                    {
                        if( errno == EWOULDBLOCK )
                        {
                            continue;
                        }
                        else
                        {
                            _RAISE( DISCONNECTED );
                        }
                    }
                    else
                    {
                        /* 실제로 데이터가 도착했으므로 recv 로 */
                        continue;
                    }
                }
            }
            else
            {
                _RAISE( DISCONNECTED );
            }
        }
        else
        {
            sPoll = 0;

            if( sSock->mRecvCBFunc != NULL && sSock->mClosed != 1 )
            {
                // Call Recv Callback Function
                sSock->mRecvCBFunc( sBuf, sRet, sSock->mRecvCBParam );
            }
            continue;
        }
    }

    _IF_RAISE( sSock->mClosed == 1, CLOSED );

    if( sBuf != NULL )
    {
        free( sBuf );
    }

    return sSock;

    _EXCEPTION( INVALID_HANDLE )
    {
        DEBUG(__f, "invalid socket handle[%d]", 0 );
        errno = EBADF;
    }
    _EXCEPTION( LACK_OF_MEMORY )
    {
        errno = ENOMEM;
    }
    _EXCEPTION( SELECT_ERROR )
    {
        DEBUG(__f, "select fail[%d] : %s", sSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( DISCONNECTED )
    {
        DEBUG(__f, "disconnected[%d]", sSock->mSockFd);
        if( sSock != NULL && sSock->mClosed == 0 )
        {
            sciStartEventThread( sSock->mGenHandle, sSock->mEventCBFunc,
                                 sSock->mEventCBParam, SCI_EVENT_DISCONNECTED );
        }
    }
    _EXCEPTION( CLOSED )
    {
        DEBUG(__f, "socket closed[fd:%d]", sSockFd );
    }
    _EXCEPTION_END;

    if( sBuf != NULL )
    {
        free( sBuf );
    }

    return NULL;
}


static mvp_rc_t sciSetNonBlock( PH_SOCK_MULTI  aSock )
{
    mvp_rc_t      sRC   = 0;
    mvp_sint32_t  sFlag = 0;

    _IF_RAISE( aSock == NULL, INVALID_HANDLE );

    _IF_RAISE( (sFlag = fcntl( aSock->mSockFd,
                                    F_GETFL,
                                    0))
                    < 0, GET_FCNTL_ERROR );

    _IF_RAISE( (sRC = fcntl( aSock->mSockFd,
                                  F_SETFL,
                                  sFlag|O_NONBLOCK ))
                    < 0, SET_FCNTL_ERROR );

    DEBUG(__f, "set nonblock mode. fd[%d]", aSock->mSockFd);

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( GET_FCNTL_ERROR )
    {
        DEBUG(__f, "get fcntl fail[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( SET_FCNTL_ERROR )
    {
        DEBUG(__f, "set fcntl fail[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}
