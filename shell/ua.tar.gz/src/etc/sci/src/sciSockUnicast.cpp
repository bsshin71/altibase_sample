/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   tcp
 *
 *   Sender 측 :
 *      sciUnixUnicastSocket
 *      sciUnixUnicastSetSockOpt
 *      sciUnixUnicastBind
 *      sciUnixUnicastSend
 *   Receiver 측 :
 *      sciUnixUnicastSocket
 *      sciUnixUnicastBind
 *      sciUnixUnicastListen
 *      sciUnixUnicastAccept
 *      sciUnixUnicastSetSockOpt
 ******************************************************************************/
#include <sciCommon.h>

static void * sciRecvThrFunc( void * aArg );
static mvp_rc_t sciSetBlock( PH_SOCK_UNI aSock, struct timeval * aTimeout );
static mvp_rc_t sciSetNonBlock( PH_SOCK_UNI aGenHandle );
static mvp_size_t sciBlockSend( PH_SOCK_UNI aSock, const void * aBuf,
                                mvp_size_t aLen, mvp_sint32_t aFlag );


/*******************************************************************************
 * Name : sciSockUnicastSocket
 *
 * Description :
 *   Tcp Socket 을 하나 생성한 후 이를 관리할 Handle 을 리턴한다.
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *
 * Return :
 *   ptr to H_SOCK_UNI : 성공, NULL : 실패
 *
 * How To Use :
 ******************************************************************************/
PH_SOCK_UNI sciSockUnicastSocket( PHSOCKET aGenHandle )
{
    mvp_rc_t       sRC   = 0;
    mvp_sint32_t   sFlag = 1;
    PH_SOCK_UNI    sSock = NULL;
    SocketHandle * sGenHandle;

    _IF_RAISE( aGenHandle == NULL, INVALID_ARG );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_UNI)malloc(sizeof(H_SOCK_UNI));
    _IF_RAISE( sSock == NULL, LACK_OF_MEMORY );
    memset( sSock, 0x00, sizeof(H_SOCK_UNI) );

    sSock->mSockFd = socket( AF_INET, SOCK_STREAM, 0);
    _IF_RAISE( sSock->mSockFd < 0, SOCK_CREAT_FAIL );

    sSock->mOption.mMaxMsgSize      = 4096;
    sSock->mOption.mPollingType     = SCI_POLLING_DEFAULT;
    sSock->mOption.mSyncRecvF       = 0;
    sSock->mOption.mSyncRecvTimeout = -1;   /* infinite */
    sSock->mOption.mRecvPollCount   = 0;

    sSock->mGenHandle = sGenHandle;

    sRC = setsockopt( sSock->mSockFd, IPPROTO_TCP, TCP_NODELAY, &sFlag, sizeof(sFlag));
    _IF_RAISE( sRC != 0, SET_SOCKOPT_FAIL );

    sRC = setsockopt( sSock->mSockFd, SOL_SOCKET, SO_REUSEADDR, &sFlag, sizeof(sFlag));
    _IF_RAISE( sRC != 0, SET_SOCKOPT_FAIL );
    DEBUG(__f, "socket creation ok. fd[%d]", sSock->mSockFd);

    sGenHandle->mSubHandle = sSock;
    sSock->mClosed = 0;

    return sSock;

    _EXCEPTION( INVALID_ARG )
    {
        DEBUG(__f, "invalid argument : aGenHandle[%d]", 0);
        errno = EINVAL;
    }
    _EXCEPTION( LACK_OF_MEMORY )
    {
        DEBUG(__f, "malloc fail : %s", strerror(errno));
        errno = ENOMEM;
    }
    _EXCEPTION( SOCK_CREAT_FAIL )
    {
        DEBUG(__f, "socket create fail : %s", strerror(errno));
    }
    _EXCEPTION( SET_SOCKOPT_FAIL )
    {
        DEBUG(__f, "setsockopt fail : %s", strerror(errno));
    }
    _EXCEPTION_END;

    if( sSock != NULL )
    {
        free( sSock );
    }

    return NULL;
}


/*******************************************************************************
 * Name : sciSockUnicastListen
 *
 * Description :
 *   Tcp 에서의 listen 역할을 수행한다.
 *
 * Argument :
 *   @aGenHandle  : general socket handle
 *   @aBackLog    : back log
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockUnicastListen( PHSOCKET      aGenHandle,
                               mvp_sint32_t  aBackLog )
{
    PH_SOCK_UNI    sSock = NULL;
    SocketHandle * sGenHandle;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL || sSock->mSockFd <= 0, INVALID_HANDLE );

    _IF_RAISE( listen(sSock->mSockFd, aBackLog) != 0, LISTEN_SOCK_FAIL );
    DEBUG(__f, "socket listen ok. fd[%d]", sSock->mSockFd);

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( LISTEN_SOCK_FAIL )
    {
        DEBUG(__f, "listen socket fail. fd[%d]", sSock->mSockFd );
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockUnicastAccept
 *
 * Description :
 *   Tcp 에서의 accept 역할을 수행한다.
 *
 * Argument :
 *   @aGenHandle : accept general socket handle
 *   @aAddr      : sockaddr 구조체 포인터
 *   @aAddrLen   : sizeof(sockaddr)
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
PH_SOCK_UNI sciSockUnicastAccept( PHSOCKET    aGenListen,
                                  PHSOCKET    aGenAccept,
                                  struct sockaddr * aAddr,
                                  socklen_t * aLen )
{
    mvp_sint32_t        sRet;
    fd_set              sFdSet;
    mvp_sint32_t        sListenFd;
    mvp_char_t          sTmp[4];
    mvp_char_t          sCliStrAddr[16];
    struct timeval      sTimeout;
    PH_SOCK_UNI         sListen = NULL;
    PH_SOCK_UNI         sAccept = NULL;
    SocketHandle      * sGenListen;

    _IF_RAISE( aGenListen == NULL, INVALID_HANDLE );
    _IF_RAISE( aGenAccept == NULL, INVALID_HANDLE );

    sGenListen = (SocketHandle *)aGenListen;

    sListen = (PH_SOCK_UNI)sGenListen->mSubHandle;
    _IF_RAISE( sListen == NULL || sListen->mSockFd <= 0, INVALID_HANDLE );

    /*----------------------------------------------------
     * Accept Socket Handle 에 Listen Socket Handle 의
     * 모든 값들을 copy
     -----------------------------------------------------*/
    sAccept = (PH_SOCK_UNI)malloc(sizeof(H_SOCK_UNI));
    _IF_RAISE( sAccept == NULL, LACK_OF_MEMORY );
    memcpy( sAccept, sListen, sizeof(H_SOCK_UNI));

    sListenFd = sListen->mSockFd;

RETRY:
    _IF_RAISE( sListen->mClosed == 1, CLOSED );

    sTimeout.tv_sec = 1;
    sTimeout.tv_usec = 0;

    FD_ZERO(&sFdSet);
    FD_SET( sListen->mSockFd, &sFdSet );

    sRet = select( sListen->mSockFd+1, &sFdSet, NULL, NULL, &sTimeout );
    _IF_RAISE( sRet < 0, SELECT_ERROR );
    if( sRet == 0 )
    {
        goto RETRY;
    }

    if( FD_ISSET(sListen->mSockFd, &sFdSet) != 0 )
    {
        sRet = sciSetNonBlock( sListen );
        _IF_RAISE( sRet < 0, ETC_ERROR );

        sAccept->mSockFd = accept( sListen->mSockFd, (struct sockaddr *)aAddr, aLen );
        _IF_RAISE( sAccept->mSockFd < 0, ACCEPT_ERROR );

        memcpy( sTmp, &((struct sockaddr_in *)aAddr)->sin_addr.s_addr, sizeof(sTmp) );
        sprintf( sCliStrAddr, "%d.%d.%d.%d", (unsigned char)sTmp[0],
                                             (unsigned char)sTmp[1],
                                             (unsigned char)sTmp[2],
                                             (unsigned char)sTmp[3]);

        DEBUG(__f, "accept fd[%d] cli_addr[%s]", sAccept->mSockFd, sCliStrAddr );

        sRet = sciSetNonBlock( sAccept );
        _IF_RAISE( sRet < 0, ETC_ERROR );

        /* ACCEPTED */
    }
    else
    {
        goto RETRY;
    }

    /*------------------------------------------------
     * sync recv (sciRecv) 사용 시는 recv thr 불필요.
     * sciSend 한 thread 가 sciRecv 까지...
     ------------------------------------------------*/
    if( sAccept->mOption.mSyncRecvF == 0 )
    {
        sRet = pthread_create( &sAccept->mRecvThr, NULL, sciRecvThrFunc, (void *)aGenAccept );
        _IF_RAISE( sRet != 0, THREAD_CREAT_ERROR );
    }

    sAccept->mGenHandle    = aGenAccept;

    return sAccept;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( LACK_OF_MEMORY )
    {
        errno = ENOMEM;
    }
    _EXCEPTION( SELECT_ERROR )
    {
        DEBUG(__f, "select fail[%d] : %s", sListen->mSockFd, strerror(errno));
    }
    _EXCEPTION( ACCEPT_ERROR )
    {
        DEBUG(__f, "accept fail[%d] : %s", sListen->mSockFd, strerror(errno));
    }
    _EXCEPTION( THREAD_CREAT_ERROR )
    {
        DEBUG(__f, "create thread fail : %s", strerror(errno));
    }
    _EXCEPTION( CLOSED )
    {
        DEBUG(__f, "socket closed[fd:%d]", sListenFd);
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    if( sAccept != NULL )
    {
        free( sAccept );
    }

    return NULL;
}


/*******************************************************************************
 * Name : sciSockUnicastConnect
 *
 * Description :
 *   Tcp 에서 connect 역할 수행
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *   @aServAddr  : Server 주소
 *   @aAddrLen   : Server 주소 Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockUnicastConnect( PHSOCKET       aGenHandle,
                                const struct sockaddr * aAddr,
                                socklen_t      aLen )
{
    mvp_rc_t       sRet   = 0;
    PH_SOCK_UNI    sSock  = NULL;
    SocketHandle * sGenHandle;
    mvp_char_t     sAddr[4];
    struct sockaddr_in * sIn = (struct sockaddr_in *)aAddr;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock->mSockFd <= 0, INVALID_HANDLE );
    _IF_RAISE( aAddr == NULL, INVALID_ARG );
    _IF_RAISE( aLen <= 0, INVALID_ARG );

    memcpy( sAddr, &sIn->sin_addr.s_addr, sizeof(sAddr) );

    sRet = sprintf( sSock->mSvrAddr, "%d.%d.%d.%d", sAddr[0], sAddr[1], sAddr[2], sAddr[3]);
    _IF_RAISE( sRet < 0, ETC_ERROR );

    sRet = connect( sSock->mSockFd, aAddr, aLen );
    _IF_RAISE( sRet < 0, CONNECT_ERROR );
    DEBUG(__f, "connect ok. sockfd[%d] sync_recv_f[%d]", sSock->mSockFd, sSock->mOption.mSyncRecvF);

    sRet = sciSetNonBlock( sSock );
    _IF_RAISE( sRet < 0, SET_NONBLOCK_ERROR );

    if( sSock->mOption.mSyncRecvF == 0 )
    {
        sRet = pthread_create( &sSock->mRecvThr, NULL, sciRecvThrFunc, (void *)sGenHandle );
        _IF_RAISE( sRet != 0, THREAD_CREAT_ERROR );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( CONNECT_ERROR )
    {
        DEBUG(__f, "connect fail : %s", strerror(errno));
    }
    _EXCEPTION( THREAD_CREAT_ERROR )
    {
        DEBUG(__f, "create thread fail : %s", strerror(errno));
    }
    _EXCEPTION( SET_NONBLOCK_ERROR )
    {
        DEBUG(__f, "set nonblock mode fail : %s", strerror(errno));
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockUnicastBind
 *
 * Description :
 *   Tcp 에서의 bind 역할을 수행한다.
 *
 * Argument :
 *   @aGenHandle  : general socket handle
 *   @aAddr       : sockaddr 구조체 포인터
 *   @aAddrLen    : sizeof(sockaddr)
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockUnicastBind( PHSOCKET          aGenHandle,
                             struct sockaddr * aAddr,
                             socklen_t         aLen )
{
    mvp_rc_t              sRet  = 0;
    PH_SOCK_UNI           sSock = NULL;
    SocketHandle        * sGenHandle;
    struct sockaddr_in  * sIn   = NULL;
    mvp_char_t            sAddr[4];

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL || sSock->mSockFd <= 0, INVALID_HANDLE );
    _IF_RAISE( aAddr == NULL, INVALID_ARG );
    _IF_RAISE( aLen <= 0, INVALID_ARG );

    sIn = (struct sockaddr_in *)aAddr;
    memcpy( sAddr, &sIn->sin_addr.s_addr, sizeof(sAddr) );
    sprintf( sSock->mSrcAddr, "%d.%d.%d.%d", sAddr[0], sAddr[1], sAddr[2], sAddr[3]);

    sRet = bind( sSock->mSockFd, (struct sockaddr *)aAddr, aLen );
    _IF_RAISE( sRet != 0, BIND_ERROR );
    DEBUG(__f, "socket bind ok. fd[%d] addr[%s]", sSock->mSockFd, sSock->mSrcAddr );

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EINVAL;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( BIND_ERROR )
    {
        DEBUG(__f, "bind fail : %s", strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockUnicastSend
 *
 * Description :
 *   Tcp Socket 을 이용하여 Data 를 send 한다.
 *
 * Argument :
 *   @aGenHandle  : sock unicast general handle
 *   @aBuf        : 보낼 Data Buffer
 *   @aLen        : 보낼 Data Length
 *   @aFlag       : 현재 미사용
 *
 * Return :
 *   Send Length : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockUnicastSend( PHSOCKET         aGenHandle,
                             const void     * aMsg,
                             mvp_size_t       aLen,
                             mvp_sint32_t     aFlags )
{
    PH_SOCK_UNI    sSock = NULL;
    SocketHandle * sGenHandle;
    mvp_sint32_t   sRet  = 0;
    mvp_sint32_t   sFlag = aFlags;

    sFlag = 0; /* erase warning */

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL || sSock->mSockFd <= 0, INVALID_HANDLE );
    _IF_RAISE( aMsg == NULL, INVALID_ARG );
    _IF_RAISE( aLen > sSock->mOption.mMaxMsgSize, INVALID_ARG );

    /*
     * 맨앞의 4 byte 먼저 보냄 (Length)
     */
    sRet = sciBlockSend(sSock, (void *)&aLen, sizeof(mvp_sint32_t), 0);
    _IF_RAISE( sRet != (mvp_sint32_t)sizeof(mvp_sint32_t), SEND_ERROR );

    /*
     * Data Body Send
     */
    sRet = sciBlockSend(sSock, aMsg, aLen, 0);
    _IF_RAISE( sRet != (mvp_sint32_t)aLen, SEND_ERROR );

    return aLen;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( SEND_ERROR )
    {
        DEBUG(__f, "send fail[ret:%d] : %s", sRet, strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockUnicastSendTo
 *
 * Description :
 *   Tcp 에서는 지원되지 않는다.
 *
 * Argument :
 *
 * Return :
 *   무조건 RC_FAILURE
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockUnicastSendTo( PHSOCKET       aGenHandle,
                               const void   * aMsg,
                               mvp_size_t     aLen,
                               mvp_sint32_t   aFlags,
                               const struct sockaddr * aTo,
                               socklen_t      aToLen )
{
    errno = EOPNOTSUPP;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockUnicastGetSockOpt
 *
 * Description :
 *   Tcp 에서 getsockopt 역할 수행
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *   @aLevel     : Option Level
 *   @aOptName   : Option Name
 *   @aValue     : Option Value
 *   @aLength    : Option Value Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockUnicastGetSockOpt( PHSOCKET       aGenHandle,
                                   mvp_sint32_t   aLevel,
                                   mvp_sint32_t   aOptName,
                                   void         * aOptVal,
                                   socklen_t    * aOptLen )
{
    PH_SOCK_UNI               sSock = NULL;
    SocketHandle            * sGenHandle;
    struct sciSocketOption  * sOptAll;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL || sSock->mSockFd <= 0, INVALID_HANDLE );

    switch( aLevel )
    {
        case SOL_COMMON :
            switch( aOptName )
            {
                case SO_RECV_CB :
                    *aOptLen = sizeof(sSock->mRecvCBFunc);
                    if( aOptVal != NULL )
                    {
                        *((sciRecvCallBack **)aOptVal) = sSock->mRecvCBFunc;
                    }
                    break;
                case SO_RECV_PARAM :
                    *aOptLen = sizeof(sSock->mRecvCBParam);
                    if( aOptVal != NULL )
                    {
                        *((void **)aOptVal) = sSock->mRecvCBParam;
                    }
                    break;
                case SO_EVENT_CB :
                    *aOptLen = sizeof(sSock->mEventCBFunc);
                    if( aOptVal != NULL )
                    {
                        *((sciEventCallBack **)aOptVal) = sSock->mEventCBFunc;
                    }
                    break;
                case SO_EVENT_PARAM :
                    *aOptLen = sizeof(sSock->mEventCBParam);
                    if( aOptVal != NULL )
                    {
                        *((void **)aOptVal) = sSock->mEventCBParam;
                    }
                    break;
                case SO_POLLING_TYPE :
                    *aOptLen = sizeof(sSock->mOption.mPollingType);
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mPollingType;
                    }
                    break;
                case SO_SYNC_RECV :
                    *aOptLen = sizeof(sSock->mOption.mSyncRecvF);
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mSyncRecvF;
                    }
                    break;
                case SO_RECV_POLL :
                    *aOptLen = sizeof(sSock->mOption.mRecvPollCount);
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mRecvPollCount;
                    }
                    break;
                case SO_OPT_ALL :
                    if( aOptVal != NULL )
                    {
                        sOptAll = (struct sciSocketOption *)aOptVal;

                        sOptAll->common.recv_callback_func   = sSock->mRecvCBFunc;
                        sOptAll->common.recv_callback_param  = sSock->mRecvCBParam;
                        sOptAll->common.event_callback_func  = sSock->mEventCBFunc;
                        sOptAll->common.event_callback_param = sSock->mEventCBParam;

                        sOptAll->common.polling_type = sSock->mOption.mPollingType;
                        sOptAll->common.sync_recv_f  = sSock->mOption.mSyncRecvF;
                        memcpy(&sOptAll->common.sync_recv_timeout, &sSock->mOption.mSyncRecvTimeout, sizeof(struct timeval));
                        sOptAll->common.recv_poll_count   = sSock->mOption.mRecvPollCount;
                    }
                    *aOptLen = sizeof(struct sciSocketOption);
                    break;
                default :
                    _RAISE( INVALID_ARG );
                    break;
            }
            break;
        case SOL_SOCK :
            _RAISE( INVALID_ARG );
            break;
        default :
            return getsockopt( sSock->mSockFd, aLevel, aOptName, aOptVal, aOptLen );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockUnicastSetSockOpt
 *
 * Description :
 *   Tcp 에서 setsockopt 역할 수행
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *   @aLevel     : Option Level
 *   @aOptName   : Option Name
 *   @aValue     : Option Value
 *   @aLength    : Option Value Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockUnicastSetSockOpt( PHSOCKET       aGenHandle,
                                   mvp_sint32_t   aLevel,
                                   mvp_sint32_t   aOptName,
                                   const void   * aOptVal,
                                   socklen_t      aOptLen )
{
    PH_SOCK_UNI              sSock = NULL;
    SocketHandle           * sGenHandle;
    struct sciSocketOption * sOptAll;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SOCK_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL || sSock->mSockFd <= 0, INVALID_HANDLE );

    switch( aLevel )
    {
        case SOL_COMMON :
            switch( aOptName )
            {
                case SO_RECV_CB :
                    sSock->mRecvCBFunc = (sciRecvCallBack *)aOptVal;
                    break;
                case SO_RECV_PARAM :
                    sSock->mRecvCBParam = (void *)aOptVal;
                    break;
                case SO_EVENT_CB :
                    sSock->mEventCBFunc = (sciEventCallBack *)aOptVal;
                    break;
                case SO_EVENT_PARAM :
                    sSock->mEventCBParam = (void *)aOptVal;
                    break;
                case SO_POLLING_TYPE :
                    sSock->mOption.mPollingType = *(mvp_sint32_t *)aOptVal;
                    DEBUG(__f, "polling type[%d] fd[%d]", sSock->mOption.mPollingType, sSock->mSockFd);
                    break;
                case SO_SYNC_RECV :
                    /*
                     * sync recv mode 에서는 recv thread 가 별도로 떠있으면 안되므로
                     * 강제로 cancle 해버려야 함.
                     */
                    if( sSock->mRecvThr != (pthread_t)0 )
                    {
                        if( pthread_kill( sSock->mRecvThr, 0 ) == 0 )
                        {
                            pthread_cancel( sSock->mRecvThr );
                        }
                        pthread_join( sSock->mRecvThr, NULL );
                    }
                    sSock->mOption.mSyncRecvF = 1;
                    sSock->mOption.mSyncRecvTimeout = ((struct timeval *)aOptVal)->tv_sec;
                    DEBUG(__f, "set sync recv mode. sec[%d] fd[%d]", sSock->mOption.mSyncRecvTimeout, sSock->mSockFd);
                    break;
                case SO_RECV_POLL :
                    _IF_RAISE( aOptVal == NULL
                            || aOptLen != sizeof(mvp_sint32_t), INVALID_ARG );
                    sSock->mOption.mRecvPollCount = *((mvp_sint32_t *) aOptVal);
                    DEBUG(__f, "set recvpoll count[%d] fd[%d]", sSock->mOption.mRecvPollCount, sSock->mSockFd);
                    break;
                case SO_OPT_ALL :
                    sOptAll = (struct sciSocketOption *)aOptVal;

                    sSock->mRecvCBFunc  = sOptAll->common.recv_callback_func;
                    sSock->mRecvCBParam = sOptAll->common.recv_callback_param;

                    sSock->mEventCBFunc  = sOptAll->common.event_callback_func;
                    sSock->mEventCBParam = sOptAll->common.event_callback_param;

                    sSock->mOption.mPollingType = sOptAll->common.polling_type;

                    if( sOptAll->common.sync_recv_f == 1 && sSock->mOption.mSyncRecvF == 0 )
                    {
                        if( sSock->mRecvThr != (pthread_t)0 )
                        {
                            if( pthread_kill( sSock->mRecvThr, 0 ) == 0 )
                            {
                                pthread_cancel( sSock->mRecvThr );
                            }
                            pthread_join( sSock->mRecvThr, NULL );
                        }
                        sSock->mOption.mSyncRecvF = 1;
                        sSock->mOption.mSyncRecvTimeout = sOptAll->common.sync_recv_timeout.tv_sec;
                    }

                    sSock->mOption.mRecvPollCount = sOptAll->common.recv_poll_count; 
                    break;
                default :
                    _RAISE( INVALID_ARG );
                    break;
            }
            break;
        case SOL_SOCK :
            _RAISE( INVALID_ARG );
            break;
        default :
            return setsockopt( sSock->mSockFd, aLevel, aOptName, aOptVal, aOptLen );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockUnicastClose
 *
 * Description :
 *   Socket Close
 *
 * Argument :
 *   @aGenHandle    : general socket handle
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockUnicastClose( PHSOCKET   aGenHandle )
{
    PH_SOCK_UNI    sSock = NULL;
    SocketHandle * sGenHandle;
    mvp_rc_t       sRC   = 0;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;
    sSock = (PH_SOCK_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    sSock->mClosed = 1;


    if( sSock->mRecvThr != (pthread_t)0 )
    {
        if( pthread_kill( sSock->mRecvThr, 0 ) == 0 )
        {
            pthread_cancel( sSock->mRecvThr );
        }
        pthread_join( sSock->mRecvThr, NULL );
    }

    if( sSock->mSockFd > 0 )
    {
        sRC = close( sSock->mSockFd );
        _IF_RAISE( sRC != 0, ETC_ERROR );
        DEBUG(__f, "socket close ok. fd[%d]", sSock->mSockFd);
    }

    if( sSock != NULL )
    {
        free( sSock );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciSockUnicastRecv
 *
 * Description :
 *   aTimeout 만큼 기다리면서 data 를 socket 으로부터 recv 한다.
 *
 * Argument :
 *   @aGenHandle : Sock Unicast General Handle
 *   @aBuf       : 받을 Data Buffer
 *   @aLen       : 받을 Data Length
 *   @aFlag      : 현재 미사용
 *
 * Return :
 *   Send Length : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciSockUnicastRecv( PHSOCKET       aGenHandle,
                             void         * aBuf,
                             mvp_size_t     aLen,
                             mvp_sint32_t   aFlag )
{
    mvp_rc_t       sRet       = 0;
    PH_SOCK_UNI    sSock      = NULL;
    mvp_size_t     sSizeHead  = 0;
    mvp_size_t     sRemain    = 0;
    mvp_size_t     sOffset    = 0;
    mvp_sint64_t   sPoll      = 0;
    mvp_sint64_t   sRate      = 0;
    mvp_char_t     sLocalBuf[MTU_SIZE];
    fd_set         sFdSet;
    sciSleep       sXS;
    SocketHandle * sGenHandle;
    struct timeval sTimeout;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock    = (PH_SOCK_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    /*
     * mSyncRecvF 체크를 해주지 않으면 recv thread 가 
     * 떠있는지 아닌지 알 수 없다.
     * 즉, 사용자가 setsockopt 를 통해 sync recv mode 로 설정하지
     * 않은 상태에서 sciRecv 를 사용하면 recv thread 가 떠있는데도
     * 또 recv 를 하려고 하는 것이므로 맞지 않다.
     */
    _IF_RAISE( sSock->mOption.mSyncRecvF == 0, NO_SYNC_RECV_MODE );

    if( sSock->mOption.mRecvPollCount > 1 )
    {
        sRate = 1000000 / sSock->mOption.mRecvPollCount;
    }
    else
    {
        sRate = 0;
    }

    sSizeHead = sizeof(mvp_sint32_t);
    sRemain = aLen + sSizeHead;
    sOffset = 0;

RETRY:
    sRet = recv( sSock->mSockFd, sLocalBuf + sOffset, sRemain, 0 );
    if( sRet == 0 )
    {
        _RAISE( DISCONNECTED );
    }
    else if( sRet < 0 )
    {
        if( errno == EWOULDBLOCK )
        {
            sPoll++;

            if( sSock->mOption.mRecvPollCount == -1 )
            {
                /*
                 * 1 번 polling 이 대충 100 ns 정도라고 예상하고
                 * 사용자가 준 시간(초) * 3,000,000 를 곱해서
                 * 이 횟수가 넘으면 timeout 으로 간주한다.
                 * 사용자의 recv timeout 을 무시하지 않기위한 궁여지책.
                 */
                if( sPoll > (sSock->mOption.mSyncRecvTimeout * 3000000) )
                {
                    _RAISE( TIMEOUT );
                }
                else
                {
                    goto RETRY;
                }
            }

            /* spin wait */
            if( sPoll < sSock->mOption.mRecvPollCount )
            {
                if( sRate != 0 )
                {
                    sciSleepNano( &sXS, sRate );
                }
                else
                {
                }
                goto RETRY;
            }
            else
            {
                sPoll = 0;

                while(1)
                {
                    /*
                     * mRecvPollCount 만큼 빨리 polling 해보고 
                     * 없으면 사용자가 지정한 시간만큼 select 에서 대기한다.
                     * packet 이 계속 없으면 timeout 으로 에러 리턴한다.
                     */
                    sTimeout.tv_sec  = sSock->mOption.mSyncRecvTimeout;
                    sTimeout.tv_usec = 0;

                    FD_ZERO( &sFdSet );
                    FD_SET( sSock->mSockFd, &sFdSet );

                    sRet = select( sSock->mSockFd+1, &sFdSet, NULL, NULL, &sTimeout );

                    _IF_RAISE( sRet < 0, SELECT_ERROR );
                    _IF_RAISE( sRet == 0, TIMEOUT );

                    if( sRet < 0 )
                    {
                        if( errno == EWOULDBLOCK )
                        {
                            continue;
                        }
                        else
                        {
                            _RAISE( DISCONNECTED );
                        }
                    }
                    else
                    {
                        /* 실제로 데이터가 도착했으므로 recv 로 */
                        goto RETRY;
                    }
                }
            }
        }
        else
        {
            _RAISE( DISCONNECTED );
        }
    }
    else
    {
        /* 일단 데이터를 받으면 polling cnt 초기화 */
        sPoll = 0;

        sOffset += sRet;
        if( sRet == (mvp_sint32_t)sRemain )
        {
            memcpy( aBuf, sLocalBuf + sizeof(mvp_sint32_t), aLen );
            goto DONE;
        }
        else
        {
            sRemain -= sRet;

            goto RETRY;
        }
    }

DONE:

    return sOffset-sizeof(mvp_sint32_t);

    _EXCEPTION( INVALID_HANDLE )
    {
        DEBUG(__f, "invalid socket handle[%d]", 0 );
        errno = EBADF;
    }
    _EXCEPTION( NO_SYNC_RECV_MODE )
    {
        DEBUG(__f, "socket is not syncrecv mode. SO_SYNC_RECV for sciRecv. fd[%d]", sSock->mSockFd );
        errno = EAGAIN;
    }
    _EXCEPTION( SELECT_ERROR )
    {
        DEBUG(__f, "select fail[%d] : %s", sSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( DISCONNECTED )
    {
        DEBUG(__f, "recv disconnected[%d]", sSock->mSockFd);

        if( sSock != NULL && sSock->mClosed == 0 )
        {
            /* sync recv mode 가 아닐 때는 recv thread 가 처리 */
            if( sSock->mOption.mSyncRecvF == 1 && sSock->mEventCBFunc != NULL )
            {
                sSock->mEventCBFunc( SCI_EVENT_DISCONNECTED, sSock->mEventCBParam );
            }
        }
    }
    _EXCEPTION( TIMEOUT )
    {
        errno = EAGAIN;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


static mvp_rc_t sciSetBlock( PH_SOCK_UNI      aSock,
                             struct timeval * aTimeout )
{
    mvp_rc_t      sRC   = 0;
    mvp_sint32_t  sFlag = 0;

    _IF_RAISE( aSock == NULL, INVALID_HANDLE );

    sFlag = fcntl(aSock->mSockFd, F_GETFL, 0);
    _IF_RAISE( sFlag < 0, GET_FCNTL_ERROR );

    sRC = fcntl(aSock->mSockFd, F_SETFL, sFlag & ~O_NONBLOCK );
    _IF_RAISE( sRC < 0, SET_FCNTL_ERROR );

    sRC = setsockopt( aSock->mSockFd, SOL_SOCKET, SO_RCVTIMEO, (void*)aTimeout, sizeof(struct timeval));
    _IF_RAISE( sRC != 0, SET_SOCKOPT_FAIL );

    DEBUG(__f, "set block mode. fd[%d]", aSock->mSockFd);

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( GET_FCNTL_ERROR )
    {
        DEBUG(__f, "get fcntl fail[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( SET_FCNTL_ERROR )
    {
        DEBUG(__f, "set fcntl fail[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( SET_SOCKOPT_FAIL )
    {
        DEBUG(__f, "setsockopt fail. fd[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciBlockSend
 *
 * Description :
 *   요청한 data 를 모두 전송할 때까지 리턴하지 않는다.
 *
 * Argument :
 *   @aGenHandle : Sock Unicast General Handle
 *   @aBuf       : 보낼 Data Buffer
 *   @aLen       : 보낼 Data Length
 *   @aFlag      : 현재 미사용
 *
 * Return :
 *   Send Length : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
static mvp_size_t sciBlockSend( PH_SOCK_UNI       aSock,
                                const void      * aBuf,
                                mvp_size_t        aLen,
                                mvp_sint32_t      aFlag )
{
    mvp_sint32_t  sRet     = 0;
    mvp_sint32_t  sSendLen = 0;
    mvp_sint32_t  sFlag    = aFlag;

    sFlag = 0;

    _IF_RAISE( aSock == NULL || aSock->mSockFd <= 0, INVALID_HANDLE );
    _IF_RAISE( aBuf  == NULL || aLen <= 0, INVALID_ARG );

    while( ! aSock->mClosed )
    {
        sRet = send( aSock->mSockFd, (char *)aBuf + sSendLen, aLen - sSendLen, 0 );
        if( sRet == 0 )
        {
            _RAISE( DISCONNECTED );
        }
        else if( sRet < 0 )
        {
            if( errno == EWOULDBLOCK )
            {
                continue;
            }
            else
            {
                _RAISE( DISCONNECTED );
            }
        }
        else
        {
            sSendLen += sRet;
            if( sSendLen == (mvp_sint32_t)aLen )
            {
                /* SEND COMPLETE */
                break;
            }
        }
    }

    _IF_RAISE( sSendLen != (mvp_sint32_t)aLen, DISCONNECTED );

    return aLen;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( DISCONNECTED )
    {
        errno = EINVAL;
        DEBUG(__f, "send. disconnected[%d]", aSock->mSockFd);

        if( aSock != NULL && aSock->mClosed == 0 )
        {
            /* sync recv mode 가 아닐 때는 recv thread 가 처리 */
            if( aSock->mOption.mSyncRecvF == 1 && aSock->mEventCBFunc != NULL )
            {
                aSock->mEventCBFunc( SCI_EVENT_DISCONNECTED, aSock->mEventCBParam );
            }
        }
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciRecvThrFunc
 *
 * Description :
 *   Data 를 recv 하여 처리하는 함수
 *
 * Argument :
 *   @aArg  : thread argument
 *
 * Return :
 *   N/A
 *
 * How To Use :
 ******************************************************************************/
static void * sciRecvThrFunc( void * aArg )
{
    SocketHandle * sGenHandle = (SocketHandle *)aArg;
    mvp_rc_t       sRet     = 0;
    PH_SOCK_UNI    sSock    = NULL;
    mvp_char_t   * sBuf     = NULL;
    mvp_size_t     sRecvLen = 0;
    mvp_size_t     sBodyLen = 0;
    mvp_size_t     sNextLen = 0;
    mvp_sint32_t   sSockFd  = 0;
    mvp_sint64_t   sRate    = 0;
    mvp_sint32_t   sPoll    = 0;
    fd_set         sFdSet;
    sciSleep       sXS;
    struct timeval sTimeout;

    _IF_RAISE( sGenHandle == NULL, INVALID_HANDLE );

    DEBUG(__f, "receive thread start. thrid[%ld]", pthread_self());

    sSock    = (PH_SOCK_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    sBuf = (mvp_char_t *)malloc(sSock->mOption.mMaxMsgSize);
    _IF_RAISE( sBuf == NULL, LACK_OF_MEMORY );

    sSockFd = sSock->mSockFd;

    if( sSock->mOption.mRecvPollCount > 1 )
    {
        sRate = 1000000 / sSock->mOption.mRecvPollCount;
    }
    else
    {
        sRate = 0;
    }

    sPoll = 0;

    sRecvLen = 0;
    sBodyLen = 0;
    sNextLen = sizeof(mvp_sint32_t);

    while( sSock->mClosed == 0 )
    {
        sRet = recv( sSock->mSockFd, sBuf + sRecvLen, sNextLen - sRecvLen, 0 );
        if( sRet == 0 )
        {
            _RAISE( DISCONNECTED );
        }
        else if( sRet < 0 )
        {
            if( errno == EWOULDBLOCK )
            {
                /* non blocking + busy wait 일 때는 계속 recv 만 call */
                if( sSock->mOption.mRecvPollCount == -1 )
                {
                    continue;
                }

                sPoll++;

                /* spin wait */
                if( sPoll < sSock->mOption.mRecvPollCount )
                {
                    if( sRate != 0 )
                    {
                        sciSleepNano( &sXS, sRate );
                        continue;
                    }
                    else
                    {
                    }
                }
                else
                {
                    sPoll = 0;

                    /* wait infinitely until data receives */
                    sTimeout.tv_sec  = 999999999;
                    sTimeout.tv_usec = 0;

                    FD_ZERO( &sFdSet );
                    FD_SET( sSock->mSockFd, &sFdSet );

                    sRet = select( sSock->mSockFd+1, &sFdSet, NULL, NULL, &sTimeout );
                    _IF_RAISE( sRet < 0, SELECT_ERROR );

                    if( sRet == 0 )
                    {
                        continue;
                    }
                    else if( sRet < 0 )
                    {
                        if( errno == EWOULDBLOCK )
                        {
                            continue;
                        }
                        else
                        {
                            _RAISE( DISCONNECTED );
                        }
                    }
                    else
                    {
                        /* 실제로 데이터가 도착했으므로 recv 로 */
                        continue;
                    }
                }
            }
            else
            {
                _RAISE( DISCONNECTED );
            }
        }
        else
        {
            sPoll = 0;

            /* recv success */
            sRecvLen += sRet;
            if( sBodyLen == 0 && sRecvLen == sizeof(mvp_sint32_t))
            {
                memcpy( &sBodyLen, sBuf, sizeof(mvp_sint32_t));
                sNextLen += sBodyLen;
                continue;
            }
            else if( sBodyLen > 0 && sRecvLen == sNextLen )
            {
                /* Receive Done */
                if( sSock->mRecvCBFunc != NULL && sSock->mClosed != 1 )
                {
                    /* Call Recv Callback Function */
                    sSock->mRecvCBFunc( sBuf + sizeof(mvp_sint32_t),
                                          sRecvLen - sizeof(mvp_sint32_t),
                                          sSock->mRecvCBParam );
                }

                sRecvLen = 0;
                sBodyLen = 0;
                sNextLen = sizeof(mvp_sint32_t);

                continue;
            }
        }
    }

    _IF_RAISE( sSock->mClosed == 1, CLOSED );


    if( sBuf != NULL )
    {
        free( sBuf );
    }

    return sSock;

    _EXCEPTION( INVALID_HANDLE )
    {
        DEBUG(__f, "invalid socket handle[%d]", 0 );
        errno = EBADF;
    }
    _EXCEPTION( LACK_OF_MEMORY )
    {
        sSock->mRecvReady = -1;
        errno = ENOMEM;
    }
    _EXCEPTION( SELECT_ERROR )
    {
        DEBUG(__f, "select fail[%d] : %s", sSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( DISCONNECTED )
    {
        DEBUG(__f, "disconnected[%d]", sSock->mSockFd);
        if( sSock != NULL && sSock->mClosed == 0 )
        {
            sciStartEventThread( sSock->mGenHandle, sSock->mEventCBFunc,
                                 sSock->mEventCBParam, SCI_EVENT_DISCONNECTED );
        }
    }
    _EXCEPTION( CLOSED )
    {
        DEBUG(__f, "socket closed[fd:%d]", sSockFd );
    }
    _EXCEPTION_END;

    if( sBuf != NULL )
    {
        free( sBuf );
    }

    return NULL;
}


static mvp_rc_t sciSetNonBlock( PH_SOCK_UNI  aSock )
{
    mvp_rc_t      sRC   = 0;
    mvp_sint32_t  sFlag = 0;

    _IF_RAISE( aSock == NULL, INVALID_HANDLE );

    sFlag = fcntl(aSock->mSockFd, F_GETFL, 0);
    _IF_RAISE( sFlag < 0, GET_FCNTL_ERROR );

    sRC = fcntl(aSock->mSockFd, F_SETFL, sFlag|O_NONBLOCK );
    _IF_RAISE( sRC < 0, SET_FCNTL_ERROR );

    DEBUG(__f, "set nonblock mode. fd[%d]", aSock->mSockFd);

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( GET_FCNTL_ERROR )
    {
        DEBUG(__f, "get fcntl fail[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( SET_FCNTL_ERROR )
    {
        DEBUG(__f, "set fcntl fail[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}
