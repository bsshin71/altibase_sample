/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   Shm 을 이용하여 LDMA 를 Socket Like 하게 구현.
 *
 *   Sender 측 :
 *      sciShmUnicastSocket
 *      sciShmUnicastSetSockOpt
 *      sciShmUnicastConnect
 *      sciShmUnicastSend
 *   Receiver 측 :
 *      sciShmUnicastSocket
 *      sciShmUnicastSetSockOpt
 *      sciShmUnicastBind
 ******************************************************************************/
#include <sciShmUnicast.h>

/* PRESIG 는 XPM 따라해봤는데 잘 동작안하넹. */
//#define __PRESIG__

static mvp_rc_t sciInitLockEventType( PH_SHM_UNI   aSock);
static mvp_rc_t sciInitShmSegment( PH_SHM_UNI  aSock );
static mvp_rc_t sciInitializeLock( PH_SHM_UNI  aSock );
static mvp_rc_t sciSendEventFd( PH_SHM_UNI aSock, mvp_sint32_t aFdTo, mvp_sint32_t aFdToSend );
static void * sciSenderConnManager( void * aArg );
static void * sciReceiverConnManager( void * aArg );
static mvp_rc_t sciEventFdLock( PH_SHM_UNI aSock, mvp_sint32_t aEventFd );
static mvp_rc_t sciEventFdUnlock( PH_SHM_UNI aSock, mvp_sint32_t aEventFd );
static mvp_rc_t sciUdsConnect( PH_SHM_UNI aSock );
static mvp_rc_t sciRecvEventFd( PH_SHM_UNI    aSock,
                                mvp_sint32_t  aFdFrom,
                                mvp_size_t    (* aUserFunc)(mvp_sint32_t, const void *, mvp_size_t) );
static void * sciRecvThrFunc( void * aArg );
static mvp_rc_t sciEventWaitCondMutex( PH_SHM_UNI aSock );
static mvp_rc_t sciEventWaitEventFd( PH_SHM_UNI aSock );
static mvp_rc_t sciEventSignalCondMutex( PH_SHM_UNI aSock );
static mvp_rc_t sciEventSignalEventFd( PH_SHM_UNI aSock );
static mvp_rc_t sciEventWaitFutex( PH_SHM_UNI   aSock );
static mvp_rc_t sciEventSignalFutex( PH_SHM_UNI  aSock );


/*******************************************************************************
 * Name : sciShmUnicastSocket
 *
 * Description :
 *   Shm 을 이용한 socket-like handle 생성
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *
 * Return :
 *   ptr to H_SHM_UNI : 성공, NULL : 실패
 *
 * How To Use :
 ******************************************************************************/
PH_SHM_UNI sciShmUnicastSocket( PHSOCKET aGenHandle )
{
    PH_SHM_UNI     sSock;
    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sSock = (PH_SHM_UNI)malloc(sizeof(H_SHM_UNI));
    _IF_RAISE( sSock == NULL, LACK_OF_MEMORY );
    memset( sSock, 0x00, sizeof(H_SHM_UNI));

    memset( sSock, 0x0, sizeof(H_SHM_UNI));
    memset( &sSock->mShmInfo, 0x0, sizeof(sciShmInfo));

    sSock->mGenHandle = aGenHandle;

    sSock->mOption.mShmSize = MTU_SIZE * 500;
    sSock->mOption.mRecvPollCount = 0;

    sSock->mOption.mLockEventType   = SCI_LOCK_EVENT_DEFAULT;
    sSock->mOption.mPollingType     = SCI_POLLING_DEFAULT;
    sSock->mOption.mSyncRecvF       = 0;
    sSock->mOption.mSyncRecvTimeout = -1;   /* infinite */

    sSock->mEventFd = -1;
    sSock->mUdsSock = -1;

    sSock->mClosed  = 0;

    return sSock;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EINVAL;
    }
    _EXCEPTION( LACK_OF_MEMORY )
    {
        errno = ENOMEM;
    }
    _EXCEPTION_END;

    return NULL;
}


/*******************************************************************************
 * Name : sciShmUnicastConnect
 *
 * Description :
 *   LDMA Connect
 *   1. Data 전송을 위한 Shared Memory 를 생성
 *   2. event fd 생성
 *   3. Connection Manager for Sender 스레드 생성.
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *   @aServAddr  : Server Address
 *   @aAddrLen   : Server Address Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciShmUnicastConnect( PHSOCKET                aGenHandle,
                               const struct sockaddr * aServAddr,
                               socklen_t               aAddrLen )
{
    PH_SHM_UNI           sSock    = NULL;
    mvp_rc_t             sRC      = 0;
    mvp_sint32_t         sFirstF  = 0;
    mvp_sint32_t         sFlag    = 0;
    SocketHandle       * sGenHandle;
    struct sockaddr_un * sUnAddr  = NULL;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );
    _IF_RAISE( aServAddr == NULL || aAddrLen != sizeof(struct sockaddr_un),
                    INVALID_ARG );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SHM_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    sRC = sciInitLockEventType( sSock );
    _IF_RAISE( sRC != 0, INIT_LOCK_EVENT_ERROR );

    sUnAddr = (struct sockaddr_un *)aServAddr;

    strncpy( sSock->mShmInfo.mPath, sUnAddr->sun_path, sizeof(sSock->mShmInfo.mPath) );
    sSock->mShmInfo.mSize = sSock->mOption.mShmSize;

    sRC = sciShmAttach( &sSock->mShmInfo, &sFirstF );
    _IF_RAISE( sRC != RC_SUCCESS, SHM_CREATE_ERROR );
    DEBUG(__f, "shared memory attach ok. shmid[%d] size[%ld]",
                    sSock->mShmInfo.mShmId, sSock->mShmInfo.mSize);

    sSock->mShmSeg = (sciShmUnicastSegment *)sSock->mShmInfo.mData;

    if( sFirstF == 1 )
    {
        sRC = sciInitShmSegment( sSock );
        _IF_RAISE( sRC != RC_SUCCESS, ETC_ERROR );
        sSock->mShmSeg->mShmSize = sSock->mShmInfo.mSize;
        DEBUG(__f, "initialize shm segment ok. shmid[%d]", sSock->mShmInfo.mShmId );
    }
    else
    {
        _IF_RAISE( sSock->mShmSeg->mShmSize != sSock->mShmInfo.mSize, INVALID_ARG );
    }

    if( sSock->mOption.mLockEventType == SCI_LOCK_EVENT_EVENTFD )
    {
        sSock->mEventFd = eventfd(0,0);
        _IF_RAISE( sSock->mEventFd == -1, EVENTFD_CREATE_ERROR );

        /*------------------------------------------------------------------
         * non blocking fd 로 변경.
         * 그래야, event signal 을 상대에게 보낼 때 write 에서 blocking 될 일이 없다.
         * 만약 상대방에서 event wait 상태가 아니게 되면 event signal 의
         * write 에서 blocking 이 되어 있는데, 그러면 lock event type 으로 eventfd 를 사용할 때
         * hang 같은 현상을 겪을 수 있다.
         * non blocking 모드에서는 바로 return 하기 때문에 그럴 일이 없다.
         ------------------------------------------------------------------*/
        _IF_RAISE( (sFlag = fcntl( sSock->mEventFd,
                                        F_GETFL,
                                        0 ))
                        < 0, GET_FCNTL_ERROR );

        _IF_RAISE( (sRC = fcntl( sSock->mEventFd,
                                      F_SETFL,
                                      sFlag|O_NONBLOCK ))
                        < 0, SET_FCNTL_ERROR );
    }
    else
    {
        /* method : lock-cond */
    }

    _IF_RAISE( (sRC = pthread_create( &sSock->mEventThr,
                                           NULL,
                                           sciSenderConnManager,
                                           (void *)sSock ))
                    != 0, THREAD_CREATE_ERROR );

    sSock->mSender = 1;

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( INIT_LOCK_EVENT_ERROR )
    {
        DEBUG(__f, "init lock event fail : type[%d]", sSock->mOption.mLockEventType);
    }
    _EXCEPTION( SHM_CREATE_ERROR )
    {
        DEBUG(__f, "shm create fail : %s", strerror(errno));
    }
    _EXCEPTION( EVENTFD_CREATE_ERROR )
    {
        DEBUG(__f, "eventfd create fail : %s", strerror(errno));
    }
    _EXCEPTION( THREAD_CREATE_ERROR )
    {
        DEBUG(__f, "event thread for sender create fail : %s", strerror(errno));
    }
    _EXCEPTION( GET_FCNTL_ERROR )
    {
        DEBUG(__f, "get fcntl fail : %s", strerror(errno));
    }
    _EXCEPTION( SET_FCNTL_ERROR )
    {
        DEBUG(__f, "set nonblock fcntl fail : %s", strerror(errno));
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}



/*******************************************************************************
 * Name : sciShmUnicastBind
 *
 * Description :
 *   LDMA Bind
 *   1. Data 수신에 사용할 Shared Memory 생성.
 *      (같은 path 로 이미 생성되어 있다면 그것을 사용한다.)
 *      Sender 와 Receiver 가 같은 path 를 이용하여 Socket 과 Shm 을
 *      만들게 되므로 한쪽이 만들면 다른 한쪽은 그를 이용한다.
 *   2. EventThreadForReceiver 스레드를 생성한다.
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *   @aAddr      : Local Bind Address
 *   @aAddrLen   : Bind Address Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciShmUnicastBind( PHSOCKET          aGenHandle,
                            struct sockaddr * aAddr,
                            socklen_t         aAddrLen )
{
    PH_SHM_UNI            sSock    = NULL;
    mvp_rc_t              sRC      = 0;
    mvp_sint32_t          sFirstF  = 0;
    SocketHandle        * sGenHandle;
    struct sockaddr_un  * sUnAddr  = NULL;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );
    _IF_RAISE( aAddr == NULL || sizeof(struct sockaddr_un) != aAddrLen, INVALID_ARG );

    sGenHandle = (SocketHandle *)aGenHandle;
    _IF_RAISE( sGenHandle->mCommType != SCI_SHM_UNICAST, INVALID_HANDLE );

    sSock = (PH_SHM_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    sRC = sciInitLockEventType( sSock );
    _IF_RAISE( sRC != 0, INIT_LOCK_EVENT_ERROR );

    sUnAddr = (struct sockaddr_un *)aAddr;

    strncpy( sSock->mShmInfo.mPath, sUnAddr->sun_path, sizeof(sSock->mShmInfo.mPath) );
    sSock->mShmInfo.mSize = sSock->mOption.mShmSize;

    sRC = sciShmAttach( &sSock->mShmInfo, &sFirstF );
    _IF_RAISE( sRC != 0, SHM_CREATE_ERROR );
    DEBUG(__f, "shared memory attach ok. shmid[%d] size[%ld]",
                        sSock->mShmInfo.mShmId, sSock->mShmInfo.mSize);

    sSock->mShmSeg = (sciShmUnicastSegment *)sSock->mShmInfo.mData;

    if( sFirstF == 1 )
    {
        sRC = sciInitShmSegment( sSock );
        _IF_RAISE( sRC != 0, ETC_ERROR );
        sSock->mShmSeg->mShmSize = sSock->mShmInfo.mSize;
        DEBUG(__f, "initialize shm segment ok. shmid[%d]", sSock->mShmInfo.mShmId );
    }
    else
    {
        _IF_RAISE( sSock->mShmSeg->mShmSize != sSock->mShmInfo.mSize, INVALID_SIZE );
    }

    _IF_RAISE( (sRC = pthread_create( &sSock->mEventThr,
                                           NULL,
                                           sciReceiverConnManager,
                                           sSock ))
                    != 0, THREAD_CREATE_ERROR );

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( INVALID_SIZE )
    {
        errno = EINVAL;
    }
    _EXCEPTION( INIT_LOCK_EVENT_ERROR )
    {
        DEBUG(__f, "init lock event fail : type[%d]", sSock->mOption.mLockEventType);
    }
    _EXCEPTION( SHM_CREATE_ERROR )
    {
        DEBUG(__f, "shm create fail : %s", strerror(errno));
    }
    _EXCEPTION( THREAD_CREATE_ERROR )
    {
        DEBUG(__f, "event thread for receiver create fail : %s", strerror(errno));
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciShmUnicastClose
 *
 * Description :
 *   shm unicast socket close
 *
 * Argument :
 *   @aGenHandle  : general socket handle
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciShmUnicastClose( PHSOCKET   aGenHandle )
{
    PH_SHM_UNI     sSock = NULL;
    SocketHandle * sGenHandle;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SHM_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    sSock->mClosed = 1;

    if( sSock->mRecvThr != (pthread_t)0 )
    {
        if( sSock->mOption.mLockEventType == SCI_LOCK_EVENT_COND_MUTEX && sSock->mShmSeg != NULL )
        {
            if( sSock->mSender == 0 )
            {
                MVP_TEST( sciMutexLock( &sSock->mShmSeg->mMutex ) != 0 );
                MVP_TEST( sciCondSignal( &sSock->mShmSeg->mCond ) != 0 );
                MVP_TEST( sciMutexUnlock( &sSock->mShmSeg->mMutex ) != 0 );
            }
            else
            {
                MVP_TEST( sciCondDestroy( &sSock->mShmSeg->mCond ) != 0 );
                MVP_TEST( sciMutexDestroy( &sSock->mShmSeg->mMutex ) != 0 );
            }
        }
        else if( sSock->mOption.mLockEventType == SCI_LOCK_EVENT_EVENTFD && sSock->mShmSeg != NULL )
        {
            MVP_TEST( sciEventFdUnlock( sSock, sSock->mEventFd ) != 0 );
            if( errno == EBADF )
            {
                errno = 0;
            }
        }
        else if( sSock->mOption.mLockEventType == SCI_LOCK_EVENT_FUTEX && sSock->mShmSeg != NULL )
        {
            /* do nothing */
        }
        else
        {
            _RAISE( ETC_ERROR );
        }

        /*
         * recv thread 가 살아있는지 검사 후 cancel 을 보냄.
         */
        if( pthread_kill( sSock->mRecvThr, 0 ) == 0 )
        {
            pthread_cancel( sSock->mRecvThr );
        }
        pthread_join( sSock->mRecvThr, NULL );
    }

    if( sSock->mEventThr != (pthread_t)0 )
    {
        if( pthread_kill( sSock->mEventThr, 0 ) == 0 )
        {
            pthread_cancel( sSock->mEventThr );
        }
        pthread_join( sSock->mEventThr, NULL );
    }

    if( sSock->mEventFd != -1 )
    {
        MVP_TEST( close(sSock->mEventFd) != 0 );
        sSock->mEventFd = -1;
    }

    if( sSock->mUdsSock != -1 )
    {
        close( sSock->mUdsSock );
        sSock->mUdsSock = -1;
    }

    if( sSock->mShmInfo.mShmId > 0 )
    {
        MVP_TEST( sciShmDettach( &sSock->mShmInfo) != 0 );
        DEBUG(__f, "Shm Removed. ShmId(%d)", sSock->mShmInfo.mShmId);
    }

    if( sSock->mOption.mPollingType == SCI_POLLING_EPOLL )
    {
        close( sSock->mEpollFd );
    }

    free( sSock );

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciShmUnicastSetSockOpt
 *
 * Description :
 *   shm unicast setsockopt
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *   @aLevel     : Option Level
 *   @aOptName   : Option Name
 *   @aValue     : Option Value
 *   @aLength    : Option Value Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciShmUnicastSetSockOpt( PHSOCKET       aGenHandle,
                                  mvp_sint32_t   aLevel,
                                  mvp_sint32_t   aOptName,
                                  const void   * aOptVal,
                                  socklen_t      aOptLen )
{
    PH_SHM_UNI                sSock = NULL;
    SocketHandle            * sGenHandle;
    struct sciSocketOption  * sOptAll;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );
     
    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SHM_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    switch( aLevel )
    {
        case SOL_COMMON :
            switch( aOptName )
            {
                case SO_RECV_CB :
                    sSock->mRecvCBFunc = (sciRecvCallBack *)aOptVal;
                    break;
                case SO_RECV_PARAM :
                    sSock->mRecvCBParam = (void *)aOptVal;
                    break;
                case SO_EVENT_CB :
                    sSock->mEventCBFunc = (sciEventCallBack *)aOptVal;
                    break;
                case SO_EVENT_PARAM :
                    sSock->mEventCBParam = (void *)aOptVal;
                    break;
                case SO_POLLING_TYPE :
                    sSock->mOption.mPollingType = *(mvp_sint32_t *)aOptVal;
                    DEBUG(__f, "polling type[%d] path[%s]",
                                            sSock->mOption.mPollingType, sSock->mShmInfo.mPath);
                    break;
                case SO_SYNC_RECV :
                    /*
                     * sync recv mode 에서는 recv thread 가 별도로 떠있으면 안되므로
                     * 강제로 cancle 해버려야 함.
                     */
                    if( sSock->mRecvThr != (pthread_t)0 )
                    {
                        if( pthread_kill( sSock->mRecvThr, 0 ) == 0 )
                        {
                            pthread_cancel( sSock->mRecvThr );
                        }
                        pthread_join( sSock->mRecvThr, NULL );
                    }
                    sSock->mOption.mSyncRecvF = 1;
                    sSock->mOption.mSyncRecvTimeout = ((struct timeval *)aOptVal)->tv_sec;
                    DEBUG(__f, "set sync recv mode. sec[%d] path[%s]",
                                            sSock->mOption.mSyncRecvTimeout, sSock->mShmInfo.mPath);
                    break;
                case SO_RECV_POLL :
                    _IF_RAISE( aOptVal == NULL
                            || aOptLen != sizeof(mvp_sint32_t), INVALID_ARG );
                    sSock->mOption.mRecvPollCount = *((mvp_sint32_t *) aOptVal);
                    DEBUG(__f, "set recvpoll count[%d] path[%s]",
                                            sSock->mOption.mRecvPollCount, sSock->mShmInfo.mPath);
                    break;
                case SO_OPT_ALL :
                    sOptAll = (struct sciSocketOption *)aOptVal;

                    sSock->mRecvCBFunc  = sOptAll->common.recv_callback_func;
                    sSock->mRecvCBParam = sOptAll->common.recv_callback_param;

                    sSock->mEventCBFunc  = sOptAll->common.event_callback_func;
                    sSock->mEventCBParam = sOptAll->common.event_callback_param;

                    sSock->mOption.mPollingType = sOptAll->common.polling_type;

                    if( sOptAll->common.sync_recv_f == 1 && sSock->mOption.mSyncRecvF == 0 )
                    {
                        if( sSock->mRecvThr != (pthread_t)0 )
                        {
                            if( pthread_kill( sSock->mRecvThr, 0 ) == 0 )
                            {
                                pthread_cancel( sSock->mRecvThr );
                            }
                            pthread_join( sSock->mRecvThr, NULL );
                        }
                        sSock->mOption.mSyncRecvF = 1;
                        sSock->mOption.mSyncRecvTimeout = sOptAll->common.sync_recv_timeout.tv_sec;
                    }

                    sSock->mOption.mRecvPollCount = sOptAll->common.recv_poll_count; 

                    sSock->mOption.mShmSize       = sOptAll->ipc.shm_size; 
                    sSock->mOption.mLockEventType = sOptAll->ipc.lock_event_type; 
                    break;
                default :
                    _RAISE( INVALID_ARG );
                    break;
            }
            break;
        case SOL_IPC :
            switch( aOptName )
            {
                case SO_SHM_SIZE :
                    _IF_RAISE( aOptVal == NULL
                            || aOptLen != sizeof(sSock->mOption.mShmSize), INVALID_ARG );
                    sSock->mOption.mShmSize = *((mvp_uint64_t *) aOptVal);
                    break;
                case SO_LOCK_EVENT_TYPE :
                    _IF_RAISE( aOptVal == NULL
                            || aOptLen != sizeof(sSock->mOption.mLockEventType), INVALID_ARG );
                    sSock->mOption.mLockEventType = *((mvp_sint32_t *) aOptVal);
                    DEBUG(__f, "set lock_event type[%d] path[%s]",
                                            sSock->mOption.mLockEventType, sSock->mShmInfo.mPath);
                    break;
                default :
                    _RAISE( INVALID_ARG );
                    break;
            }
            break;
        default :
            _RAISE( INVALID_ARG );
            break;
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        DEBUG(__f, "setsockopt fail. [%d:%d]", aLevel, aOptName);
        errno = EINVAL;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}

/*******************************************************************************
 * Name : sciShmUnicastGetSockOpt
 *
 * Description :
 *   shm unicast getsockopt
 *
 * Argument :
 *   @aGenHandle : shm unicast socket handle
 *   @aLevel     : Option Level
 *   @aOptName   : Option Name
 *   @aValue     : Option Value
 *   @aLength    : Option Value Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciShmUnicastGetSockOpt( PHSOCKET       aGenHandle,
                                  mvp_sint32_t   aLevel,
                                  mvp_sint32_t   aOptName,
                                  void         * aOptVal,
                                  socklen_t    * aOptLen )
{
    PH_SHM_UNI                sSock = NULL;
    SocketHandle            * sGenHandle;
    struct sciSocketOption  * sOptAll;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SHM_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    switch( aLevel )
    {
        case SOL_COMMON :
            switch( aOptName )
            {
                case SO_RECV_CB :
                    *aOptLen = sizeof(sSock->mRecvCBFunc);
                    if( aOptVal != NULL )
                    {
                        *((sciRecvCallBack **)aOptVal) = sSock->mRecvCBFunc;
                    }
                    break;
                case SO_RECV_PARAM :
                    *aOptLen = sizeof(sSock->mRecvCBParam);
                    if( aOptVal != NULL )
                    {
                        *((void **)aOptVal) = sSock->mRecvCBParam;
                    }
                    break;
                case SO_EVENT_CB :
                    *aOptLen = sizeof(sSock->mEventCBFunc);
                    if( aOptVal != NULL )
                    {
                        *((sciEventCallBack **)aOptVal) = sSock->mEventCBFunc;
                    }
                    break;
                case SO_EVENT_PARAM :
                    *aOptLen = sizeof(sSock->mEventCBParam);
                    if( aOptVal != NULL )
                    {
                        *((void **)aOptVal) = sSock->mEventCBParam;
                    }
                    break;
                case SO_POLLING_TYPE :
                    *aOptLen = sizeof(sSock->mOption.mPollingType);
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mPollingType;
                    }
                    break;
                case SO_SYNC_RECV :
                    *aOptLen = sizeof(sSock->mOption.mSyncRecvF);
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mSyncRecvF;
                    }
                    break;
                case SO_RECV_POLL :
                    *aOptLen = sizeof(mvp_sint32_t);
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mRecvPollCount;
                    }
                    break;
                case SO_OPT_ALL :
                    if( aOptVal != NULL )
                    {
                        sOptAll = (struct sciSocketOption *)aOptVal;

                        sOptAll->common.recv_callback_func   = sSock->mRecvCBFunc;
                        sOptAll->common.recv_callback_param  = sSock->mRecvCBParam;
                        sOptAll->common.event_callback_func  = sSock->mEventCBFunc;
                        sOptAll->common.event_callback_param = sSock->mEventCBParam;

                        sOptAll->common.polling_type = sSock->mOption.mPollingType;
                        sOptAll->common.sync_recv_f  = sSock->mOption.mSyncRecvF;
                        memcpy(&sOptAll->common.sync_recv_timeout, &sSock->mOption.mSyncRecvTimeout, sizeof(struct timeval));
                        sOptAll->common.recv_poll_count   = sSock->mOption.mRecvPollCount;

                        sOptAll->ipc.shm_size        = sSock->mOption.mShmSize;
                        sOptAll->ipc.lock_event_type = sSock->mOption.mLockEventType;
                    }
                    *aOptLen = sizeof(struct sciSocketOption);
                    break;
                default :
                    _RAISE( INVALID_ARG );
                    break;
            }
            break;
        case SOL_IPC :
            switch( aOptName )
            {
                case SO_SHM_SIZE :
                    *aOptLen = sizeof( sSock->mOption.mShmSize );
                    if( aOptVal != NULL )
                    {
                        *((mvp_uint64_t *)aOptVal) = sSock->mOption.mShmSize;
                    }
                    break;
                case SO_LOCK_EVENT_TYPE :
                    *aOptLen = sizeof( sSock->mOption.mLockEventType );
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mLockEventType;
                    }
                    break;
                default :
                    _RAISE( INVALID_ARG );
                    break;
            }
            break;
        default :
            _RAISE( INVALID_ARG );
            break;
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        DEBUG(__f, "getsockopt fail. [%d:%d]", aLevel, aOptName);
        errno = EINVAL;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}

/*******************************************************************************
 * Name : sciShmUnicastSend
 *
 * Description :
 *   shm unicast socket 을 이용하여 Data 를 send 한다.
 *
 * Argument :
 *   @aGenHanel  : shm unicast socket handle
 *   @aBuf       : 보낼 Data Buffer
 *   @aLen       : 보낼 Data Length
 *   @aFlag      : 현재 미사용
 *
 * Return :
 *   Send Length : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciShmUnicastSend( PHSOCKET          aGenHandle,
                            const void      * aBuf,
                            mvp_size_t        aLen,
                            mvp_sint32_t      aFlag )
{
    mvp_sint32_t            sIndex;
    PH_SHM_UNI              sSock = NULL;
    SocketHandle          * sGenHandle;
    sciShmUnicastMsgBlock * sData = NULL;
    sciSleep                sSleep;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_SHM_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );
    _IF_RAISE( sSock->mShmSeg == NULL, INVALID_HANDLE );

    _IF_RAISE( aBuf == NULL || aLen <= 0, INVALID_ARG );
    _IF_RAISE( aLen >= MTU_SIZE, TOO_BIG_MSG_SIZE );
    _IF_RAISE( sSock->mSender != 1, NOT_SUPPORT );


    /*---------------------------------------------------------
     * 받는 쪽에서 느리면 Buffer Full 이 발생하므로 기다려줌.
     * 무한대기할 수 있는 맹점이 있음.
     ---------------------------------------------------------*/
/*
    while( sSock->mShmSeg->mWritePos - sSock->mShmSeg->mReadPos 
             == sSock->mShmSeg->mMsgBlockCnt && sSock->mClosed == 0 )
    {
        sciSleepNano( &sSleep, 1000 );
    }
*/

#ifdef SPEED
    sIndex = sSock->mShmSeg->mWritePos % sSock->mShmSeg->mMsgBlockCnt;
    sData = &sSock->mShmSeg->mMsgBlocks[sIndex];

    if( sData->mRead != sData->mWrite && sSock->mClosed == 0 )
    {
        DEBUG(__f, "Buff Full. WritePos : %ld, ReadPos : %ld",
                        sSock->mShmSeg->mWritePos, sSock->mShmSeg->mReadPos);
        _RAISE( BUFF_FULL );
    }
#else
    if( sSock->mShmSeg->mWritePos - sSock->mShmSeg->mReadPos 
             == sSock->mShmSeg->mMsgBlockCnt && sSock->mClosed == 0 )
    {
        DEBUG(__f, "Buff Full. WritePos : %ld, ReadPos : %ld",
                        sSock->mShmSeg->mWritePos, sSock->mShmSeg->mReadPos);
        _RAISE( BUFF_FULL );
    }

    sData = &sSock->mShmSeg->mMsgBlocks[
              sSock->mShmSeg->mWritePos % sSock->mShmSeg->mMsgBlockCnt];
#endif

#ifdef __PRESIG__
    if( sSock->mOption.mRecvPollCount == 0 )
    {
        sData->mMsgSize = -1;

        if( sSock->mConnected != 0 )
        {
            sSock->mEventSignal(sSock);
        }
    }
#endif

    sData->mMsgSize = aLen;
    memcpy( sData->mData, aBuf, aLen );

#ifdef SPEED
    sData->mWrite++;
#endif

    sSock->mShmSeg->mWritePos++;

#ifdef __PRESIG__
    if( sSock->mOption.mRecvPollCount != 0 )
#endif
    {
        if( sSock->mConnected != 0 )
        {
            /*
             * TODO
             * 받는 쪽에서 wait 상태일 때만 signal 보내려고 했으나,
             * 단방향 시험에서는 효과가 좋지만, 양방향에서는 
             * 오히려 역효과가 난다.
             */ 
            //if( sSock->mShmSeg->mWaitSigF == 1 )
            //{
                sSock->mEventSignal(sSock);
            //}
        }
    }

    return aLen;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( TOO_BIG_MSG_SIZE )
    {
        errno = EMSGSIZE;
    }
    _EXCEPTION( NOT_SUPPORT )
    {
        errno = EOPNOTSUPP;
    }
    _EXCEPTION( BUFF_FULL )
    {
        errno = EAGAIN;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*
 * Shared Memory 의 경우는 timeout 을 사용하려면
 * 반드시 cond timed wait 나 eventfd 를 사용해야 한다.
 * mutex 나 futex 를 사용하면 timeout 시간을 적용할 방법이
 * 마땅치 않다.
 * 현재는 sync recv mode 에서는 그냥 busy wait 이나 spin 은
 * 못쓰고 event 방식만 사용했다.
 */
mvp_rc_t sciShmUnicastRecv( PHSOCKET         aGenHandle,
                            void           * aBuf,
                            mvp_size_t       aLen,
                            mvp_sint32_t     aFlags )
{
    mvp_sint64_t            sRate = 0;
    mvp_sint32_t            sPoll = 0;
    sciShmUnicastMsgBlock * sData = NULL;
    PH_SHM_UNI              sSock;
    SocketHandle          * sGenHandle;
    sciSleep                sXS;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;
    _IF_RAISE( sGenHandle->mSubHandle == NULL, INVALID_HANDLE );
    _IF_RAISE( aLen >= MTU_SIZE, TOO_LONG_MESSAGE );

    sSock = (PH_SHM_UNI)sGenHandle->mSubHandle;

    _IF_RAISE( sSock->mShmSeg == NULL, INVALID_HANDLE );
    _IF_RAISE( sSock->mOption.mSyncRecvF == 0, NO_SYNC_RECV_MODE );


    if( sSock->mOption.mRecvPollCount > 1 )
    {
        sRate = 1000000 / sSock->mOption.mRecvPollCount;
    }
    else
    {
        sRate = 0;
    }

    sData = &sSock->mShmSeg->mMsgBlocks[sSock->mShmSeg->mReadPos % sSock->mShmSeg->mMsgBlockCnt];

    sPoll = 0;

    while( sSock->mShmSeg->mWritePos == sSock->mShmSeg->mReadPos && sSock->mClosed == 0 )
    {
        if( sSock->mConnected == 0 )
        {
            _RAISE( DISCONNECTED );
        }

        sPoll++;

        /* busy wait */
        if( sSock->mOption.mRecvPollCount == -1 )
        {
            /* TODO
             *   1 번 polling 이 대충 100 ns 정도라고 예상하고
             *   사용자가 준 시간(초) * 3,000,000 를 곱해서
             *   이 횟수가 넘으면 timeout 으로 간주한다.
             *   socket 을 busy wait 으로 설정했을 때조차도 
             *   사용자의 recv timeout 을 무시하지 않기위한 궁여지책.
             */
            if( sPoll > (sSock->mOption.mSyncRecvTimeout * 3000000) )
            {
                _RAISE( TIMEOUT );
            }
            else
            {
                continue;
            }
        }

        /* spin */
        if( sPoll < sSock->mOption.mRecvPollCount )
        {
            if( sRate != 0 )
            {
                sciSleepNano( &sXS, sRate );
            }
            else
            {
            }
        }
        else /* event */
        {
            /* TODO
             *   setsockopt 로 SO_SYNC_RECV 를 통해
             *   timeout 을 설정했을 때 이것이 적용될 수 있도록
             *   cond_timedwait 를 통한 구현도 필요.
             *   일단은 Shm 에서는 현재 sync recv mode 에서의 timeout 이 적용안됨.
             *   적용을 하더라도 아마 lock event type 이 SCI_LOCK_EVENT_COND_MUTEX 인
             *   경우에만 가능할 것이다.
             */
            MVP_TEST( sSock->mEventWait(sSock) != 0 );
        }
    }

    if( sSock->mClosed != 0 || sSock->mConnected == 0 )
    {
        _RAISE( DISCONNECTED );
    }

    memcpy( aBuf, (const mvp_char_t *)sData->mData, sData->mMsgSize );

    sSock->mShmSeg->mReadPos++;

    return sData->mMsgSize;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( TOO_LONG_MESSAGE )
    {
        errno = EMSGSIZE;
    }
    _EXCEPTION( DISCONNECTED )
    {
        errno = EINVAL;
    }
    _EXCEPTION( NO_SYNC_RECV_MODE )
    {
        DEBUG(__f, "socket is not syncrecv mode. SO_SYNC_RECV for sciRecv. blockmode[%d]",
                    sSock->mOption.mSyncRecvF );
        errno = EAGAIN;
    }
    _EXCEPTION( TIMEOUT )
    {
        errno = EAGAIN;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/* 사용할 수도 있어서 남겨둠.
static mvp_rc_t sciSetNonBlock( PH_SHM_UNI        aSock,
                                struct timeval  * aTimeout )
{
    mvp_rc_t   sRC;

    _IF_RAISE( aSock == NULL, INVALID_HANDLE );

    aSock->mOption.mSyncRecvF       = 0;
    aSock->mOption.mSyncRecvTimeout = aTimeout->tv_sec;

    if( &aSock->mRecvThr == (pthread_t)0)
    {
        _IF_RAISE( (sRC = pthread_create( &aSock->mRecvThr,
                                               NULL,
                                               sciRecvThrFunc,
                                               aSock ))
                        != 0, THREAD_CREATE_ERROR );

        DEBUG(__f, "receive thread start. thrid[%ld]", aSock->mRecvThr);
    }

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( THREAD_CREATE_ERROR )
    {
        errno = sRC;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}
*/

static mvp_rc_t sciInitLockEventType( PH_SHM_UNI   aSock )
{
    _IF_RAISE( aSock == NULL, INVALID_HANDLE );

    switch( aSock->mOption.mLockEventType )
    {
        case SCI_LOCK_EVENT_COND_MUTEX :
            aSock->mEventWait   = sciEventWaitCondMutex;
            aSock->mEventSignal = sciEventSignalCondMutex;
            break;

        case SCI_LOCK_EVENT_EVENTFD :
            aSock->mEventWait   = sciEventWaitEventFd;
            aSock->mEventSignal = sciEventSignalEventFd;
            break;

        case SCI_LOCK_EVENT_FUTEX :
            aSock->mEventWait   = sciEventWaitFutex;
            aSock->mEventSignal = sciEventSignalFutex;
            break;

        default :
            _RAISE( ETC_ERROR );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


static mvp_rc_t sciInitShmSegment( PH_SHM_UNI  aSock )
{
    _IF_RAISE( aSock == NULL, INVALID_HANDLE );
    _IF_RAISE( aSock->mShmSeg == NULL, ETC_ERROR );

    aSock->mShmSeg->mMsgBlockCnt = (aSock->mShmInfo.mSize - sizeof(sciShmUnicastSegment))
                             / ( sizeof( sciShmUnicastMsgBlock) );

    DEBUG(__f, "msg block cnt : %d", aSock->mShmSeg->mMsgBlockCnt);

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


#define CONTROLLEN  CMSG_LEN(sizeof(int))

static struct cmsghdr   *cmptr_s = NULL;
static struct cmsghdr   *cmptr_r = NULL;

static mvp_rc_t sciSendEventFd( PH_SHM_UNI        aSock,
                                mvp_sint32_t      aFdTo,
                                mvp_sint32_t      aFdToSend )
{
    struct iovec   sIOV[1];
    struct msghdr  sMsg;
    mvp_char_t     sBuf[2];

    _IF_RAISE( aSock == NULL, INVALID_HANDLE );

    sIOV[0].iov_base = sBuf;
    sIOV[0].iov_len  = 2;

    sMsg.msg_iov     = sIOV;
    sMsg.msg_iovlen  = 1;
    sMsg.msg_name    = NULL;
    sMsg.msg_namelen = 0;

    if( aFdToSend < 0 )
    {
        sMsg.msg_control    = NULL;
        sMsg.msg_controllen = 0;

        /* nonzero status means error */
        sBuf[1] = -aFdToSend;

        if( sBuf[1] == 0 )
        {
            sBuf[1] = 1;
        }
    }
    else
    {
        if( cmptr_s == 0x0 && (cmptr_s = (cmsghdr *)malloc(CONTROLLEN)) == NULL )
        {
            return RC_FAILURE;
        }

        cmptr_s->cmsg_level  = SOL_SOCKET;
        cmptr_s->cmsg_type   = SCM_RIGHTS;
        cmptr_s->cmsg_len    = CONTROLLEN;

        sMsg.msg_control    = cmptr_s;
        sMsg.msg_controllen = CONTROLLEN;

        memcpy(CMSG_DATA(cmptr_s), &aFdToSend, sizeof(mvp_sint32_t));
        sBuf[1] = 0;
    }

    sBuf[0] = 0;

    if( sendmsg( aFdTo, &sMsg, 0) != 2 )
    {
        _RAISE( SENDMSG_ERROR );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( SENDMSG_ERROR )
    {
        DEBUG(__f, "sendmsg fail : %s", strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*
 * Connect 관리를 위한 Uds Socket 으로부터
 * EventFd 를 수신한다.
 */
static mvp_rc_t sciRecvEventFd( PH_SHM_UNI    aSock,
                                mvp_sint32_t  aFdFrom,
                                mvp_size_t    (* aUserFunc)(mvp_sint32_t,
                                                            const void *,
                                                            mvp_size_t) )
{
    mvp_sint32_t    sNewFd = 0;
    mvp_sint32_t    sRead;
    mvp_sint32_t    sStatus;
    mvp_char_t      sBuf[2];
    mvp_char_t    * sPtr;
    struct iovec    sIOV[1];
    struct msghdr   sMsg;

    _IF_RAISE( aSock == NULL, INVALID_HANDLE );

    sStatus = -1;

    for( ;; )
    {
        sIOV[0].iov_base = sBuf;
        sIOV[0].iov_len  = sizeof(sBuf);

        sMsg.msg_iov     = sIOV;
        sMsg.msg_iovlen  = 1;
        sMsg.msg_name    = NULL;
        sMsg.msg_namelen = 0;

        if( cmptr_r == NULL && (cmptr_r = (struct cmsghdr *)malloc(CONTROLLEN)) == NULL )
        {
            return RC_FAILURE;
        }

        sMsg.msg_control    = cmptr_r;
        sMsg.msg_controllen = CONTROLLEN;

        if( (sRead = recvmsg( aFdFrom, &sMsg, 0 )) < 0 )
        {
            /* recvmsg error */
        }
        else if( sRead == 0 )
        {
            /* Connect Closed by Server */
        }

        for( sPtr = sBuf; sPtr < &sBuf[sRead]; )
        {
            if( *sPtr++ == 0 )
            {
                if( sPtr != &sBuf[sRead-1])
                {
                    /* message format error */
                    return RC_FAILURE;
                }

                sStatus = *sPtr & 0xFF;

                if( sStatus == 0 )
                {
                    if( sMsg.msg_controllen != CONTROLLEN )
                    {
                        /* status = 0 but no fd -> ignore this case */
                    }
                    memcpy( &sNewFd, CMSG_DATA(cmptr_r), sizeof(mvp_sint32_t));
                }
                else
                {
                    sNewFd = -sStatus;
                }

                sRead -= 2;
            }
        }

        if( sRead > 0 && (*aUserFunc)(STDERR_FILENO, sBuf, sRead) != (mvp_size_t)sRead )
        {
            return RC_FAILURE;
        }

        if( sStatus >= 0 ) /* final data has arrived */
        {
            DEBUG(__f, "newfd : %d, status : %d", sNewFd, sStatus );
            return sNewFd;
        }

    }

    return RC_FAILURE;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}



/*******************************************************************************
 * Name : sciSenderConnManager
 *
 * Description :
 *   1. Connection Check 를 위한 Unix Domain Socket 생성 (Listen FD).
 *   2. Lock Event Type(0,1,2,3) 별로 Lock Object 초기화.
 *   3. Listen FD 를 poll 하다가 상대로부터 connect 요청이 오면 accept 하여
 *      mConnected 상태를 1 로 변경하고, 상대방에게 sciShmUnicastConnect 시
 *      생성했던 event fd 전달.
 *      -> 이는 Lock Event Type 중 eventfd 를 이용한 Lock/Unlock 에 사용됨.
 *   4. 이후 지속적으로 Unix Domain Socket 을 감시하여 Connect 가 끊어지는지
 *      검사한다. (mConnected = 0)
 *
 * Argument :
 *   @aArg      : Thread Argument
 *
 * Return :
 *   N/A
 *
 * How To Use :
 ******************************************************************************/
static void * sciSenderConnManager( void * aArg )
{
    mvp_sint32_t          sListenFd     = 0;
    PH_SHM_UNI            sSock         = (PH_SHM_UNI)aArg;
    struct sockaddr_un    sServAddr;
    struct sockaddr_un    sCliAddr;
    socklen_t             sServLen      = 0;
    socklen_t             sCliLen       = 0;
    struct pollfd         sMyPollFd;
    struct pollfd         sListenPollFd;
    mvp_sint32_t          sRC           = 0;
    mvp_sint32_t          sRet          = 0;
    mvp_sint32_t          sMsTimeout    = 0;

    _IF_RAISE( sSock == NULL, BAD_FILE );

    DEBUG(__f, "sender connection manager start. thrid[%ld]", pthread_self());

    /* Unix Domain Socket 생성 */
    sListenFd = socket(AF_UNIX, SOCK_STREAM, 0);
    _IF_RAISE( sListenFd == -1, CREATE_UDS_ERROR );

    memset( &sServAddr, 0x0, sizeof(sServAddr) );
    sServAddr.sun_family = AF_UNIX;

    sprintf(sServAddr.sun_path, "%s-ux", sSock->mShmInfo.mPath );
    sServLen = sizeof(sServAddr);

    if( access( sServAddr.sun_path, R_OK) == 0 )
    {
        unlink( sServAddr.sun_path );
    }

    _IF_RAISE( (sRC = bind( sListenFd,
                                 (struct sockaddr *)&sServAddr,
                                 sServLen))
                    != 0, BIND_ERROR );

    _IF_RAISE( (sRC = listen( sListenFd, 5 )) != 0, LISTEN_ERROR );

    sCliLen = sizeof(sCliAddr);

    sRC = sciInitializeLock( sSock );
    _IF_RAISE( sRC != 0, INIT_LOCK_ERROR );

    sListenPollFd.fd      = sListenFd;
    sListenPollFd.events  = POLLIN;
    sListenPollFd.revents = 0;
    sMsTimeout            = 5000;

    while( ! sSock->mClosed )
    {
        /*
         * 상대방으로부터의 Unix Domain Socket Connect 를 기다린다.
         * 즉, 상대방이 나에게 connect 를 한다는 의미는  나 이제 받을 준비됐어와
         * 같은 의미
         */
        sRet = poll( &sListenPollFd, 1 , sMsTimeout );
        _IF_RAISE( sRet < 0, ETC_ERROR );

        if( sRet == 0 )
        {
            continue;
        }

        _IF_RAISE( (sSock->mUdsSock = accept( sListenFd,
                                                   (struct sockaddr *)&sCliAddr,
                                                   &sCliLen ))
                        == -1, ACCEPT_ERROR );

        DEBUG(__f, "unix domain socket accepted. fd[%d]", sSock->mUdsSock);

        sSock->mConnected = 1;
        if( sSock->mOption.mLockEventType == SCI_LOCK_EVENT_EVENTFD )
        {
            /*
             * Unix Domain Socket Connect 가 되면 이를 통해 eventfd 값을
             * 상대방에게 전달한다.
             */
            _IF_RAISE( (sRet = sciSendEventFd( sSock,
                                                    sSock->mUdsSock,
                                                    sSock->mEventFd ))
                            != 0, ETC_ERROR );
        }

        sMyPollFd.fd      = sSock->mUdsSock;
        sMyPollFd.events  = POLLIN;
        sMyPollFd.revents = 0;
        sMsTimeout = 5000;

        while( ! sSock->mClosed )
        {
            sRet = poll( &sMyPollFd, 1, sMsTimeout );
            _IF_RAISE( sRet < 0, ETC_ERROR );

            /* Disconnect -> 다시 accept 에서 기다림 */
            if( sRet > 0 )
            {
                DEBUG(__f, "unix domain socket disconnected. fd[%d]", sSock->mUdsSock);
                if( sSock != NULL && sSock->mClosed == 0 )
                {
                    sciStartEventThread( sSock->mGenHandle, sSock->mEventCBFunc,
                                         sSock->mEventCBParam, SCI_EVENT_DISCONNECTED );
                }

                sSock->mConnected = 0;

                close( sSock->mUdsSock );
                sSock->mUdsSock = -1;
                break;
            }
        }

        if( sSock->mOption.mLockEventType == SCI_LOCK_EVENT_COND_MUTEX )
        {
            sRC = sciCondDestroy( &sSock->mShmSeg->mCond );
            _IF_RAISE( sRC != 0, ETC_ERROR );

            sRC = sciMutexDestroy( &sSock->mShmSeg->mMutex );
            _IF_RAISE( sRC != 0, ETC_ERROR );
        }

        sRC = sciInitializeLock( sSock );
        _IF_RAISE( sRC != 0, ETC_ERROR );
    }

    if( sSock->mUdsSock != -1 )
    {
        close( sSock->mUdsSock );
        sSock->mUdsSock = -1;
    }

    if( sListenFd != -1 )
    {
        close( sListenFd );
    }

    if( access(sServAddr.sun_path, R_OK ) == 0 )
    {
        unlink( sServAddr.sun_path );
    }

    return NULL;

    _EXCEPTION( BAD_FILE )
    {
        errno = EBADF;
    }
    _EXCEPTION( BIND_ERROR )
    {
        DEBUG(__f, "bind fail : %s", strerror(errno));
    }
    _EXCEPTION( LISTEN_ERROR )
    {
        DEBUG(__f, "listen fail : %s", strerror(errno));
    }
    _EXCEPTION( INIT_LOCK_ERROR )
    {
        DEBUG(__f, "init lock fail : %s", strerror(errno));
    }
    _EXCEPTION( CREATE_UDS_ERROR )
    {
        DEBUG(__f, "create unix domain socket fail : %s", strerror(errno));
    }
    _EXCEPTION( ACCEPT_ERROR )
    {
        DEBUG(__f, "accept fail : %s", strerror(errno));
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    if( sSock != NULL && sSock->mUdsSock != -1 )
    {
        close( sSock->mUdsSock );
        sSock->mUdsSock = -1;
    }

    if( sListenFd != -1 )
    {
        close( sListenFd );
    }

    if( access( sServAddr.sun_path, R_OK ) == 0 )
    {
        unlink( sServAddr.sun_path );
    }

    return NULL;
}


/*
 */
/*******************************************************************************
 * Name : sciUdsConnect
 *
 * Description :
 *   상대방과의 LDMA Connection 을 체크하기 위한 소켓.
 *   Connect 가 되었다는 얘기는 통신 상대가 Unix Domain Socket 을
 *   만들고 listen->accept 를 했다는 의미.
 *   즉, Shm 으로는 Socket 의 Connection 개념을 두기가 힘들기 때문에
 *   Unix Domain Socket 을 이용하여 마치 TCP 처럼 Connection 개념을
 *   사용하기 위한 것이다.
 *   Unix Domain Socket Connection 이 성공하면 Sender 쪽에서 보내는
 *   Event Fd 를 수신한다.
 *
 * Argument :
 *   @aSock    : shm unicast socket handle
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
static mvp_rc_t sciUdsConnect( PH_SHM_UNI   aSock )
{
    struct sockaddr_un  sServAddr;
    mvp_sint32_t        sServLen;


    _IF_RAISE( aSock == NULL, INVALID_HANDLE );

    aSock->mUdsSock = socket( AF_UNIX, SOCK_STREAM, 0 );
    MVP_TEST( aSock->mUdsSock == -1 );

    memset( &sServAddr, 0, sizeof(sServAddr) );
    sServAddr.sun_family = AF_UNIX;

    sprintf(sServAddr.sun_path, "%s-ux", aSock->mShmInfo.mPath );
    sServLen = sizeof(sServAddr);

    _IF_RAISE( connect( aSock->mUdsSock,
                             (struct sockaddr *)&sServAddr,
                             sServLen )
                    != 0, CONNECT_FAIL );

    if( aSock->mOption.mLockEventType == SCI_LOCK_EVENT_EVENTFD )
    {
        aSock->mEventFd = sciRecvEventFd( aSock, aSock->mUdsSock, NULL );
        MVP_TEST( aSock->mEventFd == -1 );

        if( aSock->mOption.mPollingType == SCI_POLLING_EPOLL )
        {
            aSock->mEpollFd = 0;
        }
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( CONNECT_FAIL )
    {
        /*
         * server 가 없을 때 실제는 파일에러(ENOENT)가 나지만 
         * socket 처럼 ECONNREFUSED 로 처리
         */
        errno = ECONNREFUSED;
    }
    _EXCEPTION_END;

    if( aSock != NULL && aSock->mUdsSock != -1 )
    {
        close( aSock->mUdsSock );
        aSock->mUdsSock = -1;
    }

    return RC_FAILURE;
}

/*
static mvp_rc_t
sys_capget( cap_user_header_t header, cap_user_data_t data )
{
    return syscall( SYS_capget, header, data );
}

#define CAP_TO_MASK(x)  (1 << ((x) & 31))
static mvp_rc_t sciChgSched()
{
    mvp_sint32_t    sCapNice = 0;
    mvp_sint32_t    sPolicy  = SCHED_RR;  // SCHED_FIFO, SCHED_RR, SCHED_BATCH, SCHED_IDLE, SCHED_OTHER
    mvp_rc_t        sResult  = 0;
    mvp_sint32_t    sPriority = 4;
    mvp_slong_t     sAffinity = 4;
    struct __user_cap_header_struct sHeader = {_LINUX_CAPABILITY_VERSION_3, 0 };
    struct __user_cap_data_struct   sData = {0, };

    sResult = sys_capget( &sHeader, & sData );
    if( sResult == 0 )
    {
        sCapNice = ( ( sData.permitted & CAP_TO_MASK( CAP_SYS_NICE ) ) >> CAP_SYS_NICE ) |
                   ( ( sData.inheritable & CAP_TO_MASK( CAP_SYS_NICE ) ) >> CAP_SYS_NICE ) |
                   ( ( sData.effective & CAP_TO_MASK( CAP_SYS_NICE ) ) >> CAP_SYS_NICE );
    }

    {
        _IF_RAISE( sPolicy < 0, INVALID_POLICY );
        {
            mvp_sint32_t        sMin = 0, sMax = 0;
            struct sched_param  sParam = {0, };

            sMin = sched_get_priority_min( sPolicy );
            _IF_RAISE( sMin == -1, INVALID_POLICY );

            sMax = sched_get_priority_max( sPolicy );
            _IF_RAISE( sMax == -1, INVALID_POLICY );
            //DEBUG(__f, "priority min[%d] max[%d]\n", sMin, sMax);

            _IF_RAISE( sPriority < sMin && sPriority > sMax, INVALID_PRIORITY );

            sParam.sched_priority = sPriority;

            _IF_RAISE( sched_setscheduler( 0, sPolicy, &sParam ) == -1, FAIL_SCHED );

            if( sAffinity > 0 )
            {
                sched_setaffinity( 0, sizeof( sAffinity ), (cpu_set_t*) &sAffinity );
            }
            //DEBUG(__f,  "scheduler has been changed. scheduler=[%d],priority=[%d],affinity=[0x%x]",
            //    sPolicy, sPriority, sAffinity );
        }
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_POLICY )
    {
    }
    _EXCEPTION( INVALID_PRIORITY )
    {
    }
    _EXCEPTION( FAIL_SCHED )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}
*/

/*******************************************************************************
 * Name : sciRecvThrFunc
 *
 * Description :
 *   1. 읽을 것이 없으면 mOption.mRecvPollCount 만큼 돌면서 Write Position 과
 *      Read Position 값이 달라지는지 검사한다. 달라지면 읽을 것이 있는 것이다.
 *      mOption.mRecvPollCount 만큼 돌았는데도 계속 읽을 것이 없으면 
 *      EventWait 상태로 들어간다.
 *   2. 읽을 것이 생기면, 즉 sciShmUnicastSend 에서 Data 를 Write 한 후 EventSignal 을
 *      보내면 깨어나서 사용자가 SetSockOpt 를 통해 등록한 Recv CallBack 함수를
 *      호출한다.
 *   3. mReadPos 를 하나 증가시킨다.
 *
 * Argument :
 *   @aArg    : Thread Argument
 *
 * Return :
 *   N/A
 *
 * How To Use :
 ******************************************************************************/
static void * sciRecvThrFunc( void * aArg )
{
    mvp_sint64_t            sRate = 0;
    sciShmUnicastMsgBlock * sData = NULL;
    PH_SHM_UNI              sSock = (PH_SHM_UNI)aArg;
    mvp_sint32_t            sPoll = 0;
    mvp_sint32_t            sIndex;
    sciSleep                sXS;
#ifdef SPEED
    volatile mvp_sint64_t * sWrite;
    volatile mvp_sint64_t * sRead;
#endif

    _IF_RAISE( sSock == NULL, INVALID_HANDLE );
    _IF_RAISE( sSock->mShmSeg == NULL, INVALID_HANDLE );

    /* scechduling test */
    // mvp_rc_t   sRet  = 0;
    //sRet = sciChgSched();
    //_IF_RAISE( sRet != 0, CHANGE_SCHED_ERROR );

    if( sSock->mOption.mRecvPollCount > 1 )
    {
        sRate = 1000000 / sSock->mOption.mRecvPollCount;
    }
    else
    {
        sRate = 0;
    }

    while( ! sSock->mClosed )
    {
#ifdef SPEED
        sIndex = sSock->mShmSeg->mReadPos % sSock->mShmSeg->mMsgBlockCnt;

        sData  = &sSock->mShmSeg->mMsgBlocks[sIndex];
        sWrite = &sData->mWrite;
        sRead  = &sData->mRead;
#else
        sData = &sSock->mShmSeg->mMsgBlocks[sSock->mShmSeg->mReadPos % sSock->mShmSeg->mMsgBlockCnt];
#endif

        sPoll = 0;

#ifdef SPEED
        while( (*sRead == *sWrite) && sSock->mClosed == 0 )
#else
        while( sSock->mShmSeg->mWritePos == sSock->mShmSeg->mReadPos && sSock->mClosed == 0 )
#endif
        {
            if( sSock->mConnected == 0 )
            {
                /*
                 * Disconnect 시는 Recv Thread 정상종료.
                 * Connect 성공 시에 다시 생성한다.
                 */
                _RAISE( DISCONNECTED );
            }

            sPoll++;

            /* busy wait */
            if( sSock->mOption.mRecvPollCount == -1 )
            {
                continue;
            }

            /* spin wait */
            if( sPoll < sSock->mOption.mRecvPollCount )
            {
                if( sRate != 0 )
                {
                    sciSleepNano( &sXS, sRate );
                }
                else
                {
                }
            }
            else /* event wait */
            {
                /*
                 * 읽을 것이 없는 상황에서 mRecvPollCount 만큼 Loop 를
                 * sRate Nano second 만큼 쉬면서 돌다가 계속 없으면
                 * EventWait 상태로 들어간다.
                 * EventWait 상태가 아닌데 상대에서 이미 Send 를 한 상황이면
                 * mWritePos 와 mReadPos 가 차이가 날 것이므로 EventWait 
                 * 상태가 아니라도 while 을 빠져나와서 받은 데이터를 읽는다.
                 */
                //sSock->mShmSeg->mWaitSigF = 1;
                MVP_TEST( sSock->mEventWait(sSock) != 0 );
                //sSock->mShmSeg->mWaitSigF = 0;

#ifdef __PRESIG__
                static mvp_uint64_t  sCnt    = 0;
                static mvp_uint64_t  sCntPre = 0;
                while( sData->mMsgSize == -1 )
                {
                    sCnt++;
                }
                if( sCnt > sCntPre )
                {
                    printf("pre signal. [%ld:%ld]\n", sCnt, sCntPre );
                    sCntPre = sCnt;
                }
#endif
            }
        }

        if( sSock->mClosed != 0 )
        {
            _RAISE( DISCONNECTED );
        }

        if( sSock->mRecvCBFunc != NULL && sSock->mClosed == 0 )
        {
            sSock->mRecvCBFunc( sData->mData, sData->mMsgSize, sSock->mRecvCBParam );
        }
#ifdef SPEED
        sData->mRead++;
#endif

        sSock->mShmSeg->mReadPos++;
    }

DISCONNECTED:

    return sSock;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    /*
    _EXCEPTION( CHANGE_SCHED_ERROR )
    {
        DEBUG(__f, "change sched fail : %s\n", strerror(errno));
    }
    */
    _EXCEPTION_END;

    /*
    if( sSock != NULL && sSock->mClosed == 0 )
    {
        sciStartEventThread( sSock->mGenHandle, sSock->mEventCBFunc,
                             sSock->mEventCBParam, SCI_EVENT_ABNORMAL_END );
    }
    */

    return NULL;
}


/*******************************************************************************
 * Name : sciReceiverConnManager
 *
 * Description :
 *   1. Unix Domain Socket 을 통해 Connect 를 시도한다.
 *      실패 시는 이미 Write 한 Data 를 모두 읽어들인다.
 *   2. Recv Thread 생성
 *   3. Unix Domain Socket 이 끊기는지 감시
 *      (mIsConnect = 0)
 *
 * Argument :
 *   @aArg    : Thread Argument
 *
 * Return :
 *   N/A
 *
 * How To Use :
 ******************************************************************************/
static void * sciReceiverConnManager( void * aArg )
{
    mvp_rc_t           sRC   = 0;
    mvp_sint32_t       sRet  = 0;
    PH_SHM_UNI         sSock = (PH_SHM_UNI)aArg;
    struct pollfd      sMyPollFd;
    mvp_sint32_t       sMsTimeout;

    DEBUG(__f, "receiver connection manager start. thrid[%ld]", pthread_self());

    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

RECONNECT:

    while( sSock->mClosed == 0 )
    {
        if( sciUdsConnect( sSock ) == 0 )
        {
            break;
        }

        /*
         * 한번만 shm data 있는지 체크
         * 상대방과 Connection 이 안되었더라도 있는 데이터는 모두 읽는다.
         * 죽었다 떴을 때도 Connect 실패이면 이전에 받은 데이터는 모두 읽는다.
         */
        sciRecvThrFunc( sSock );

        usleep( 1000 * 700 );
    }

    _IF_RAISE( sSock->mClosed != 0, END );

    DEBUG(__f, "unix domain socket connected. fd[%d]", sSock->mUdsSock);
    sSock->mConnected = 1;

    /*
     * Unix Domain Socket 을 통해 상대와 Connect 가 되면
     * 이제 본격적으로 Data 를 읽어들일 Recv Thread 를 생성한다.
     * sync recv mode 일 때는 직접 main thread 가 sciRecv 를 통해
     * 데이터를 수신하므로 recv thread 가 필요없다.
     */
    if( sSock->mOption.mSyncRecvF == 0 )
    {
        _IF_RAISE( (sRC = pthread_create( &sSock->mRecvThr,
                                               NULL,
                                               sciRecvThrFunc,
                                               sSock ))
                        != 0, THREAD_CREATE_ERROR );

        DEBUG(__f, "receive thread start. thrid[%ld]", sSock->mRecvThr);
    }

    sMyPollFd.fd      = sSock->mUdsSock;
    sMyPollFd.events  = POLLIN;
    sMyPollFd.revents = 0;
    sMsTimeout        = 5000;

    /*
     * Socket Close 가 발생하면 Receiver Connection Manager 도
     * 종료한다.
     */
    while( ! sSock->mClosed )
    {
        /*
         * 0 : timeout, > 0 : event 발생한 경우
         */
        sRet = poll( &sMyPollFd, 1, sMsTimeout );
        MVP_TEST( sRet < 0 ); /* thread 비정상 종료 */

        if( sRet == 0 )
        {
            continue;
        }

        {
            /*
             * Uds Socket 이 끊어지면, 즉 Connection 상대가 죽거나
             * Socket 을 닫으면 Recv Thread 를 멈추고 다시 Connect 를 시도.
             * Socket 이 끊기면 Recv Thread 도 mIsConnect 값을 검사하고 있다가
             * 정상 종료하게 된다.
             */

            DEBUG(__f, "unix domain socket disconnected. fd[%d]", sSock->mUdsSock);
            if( sSock != NULL && sSock->mClosed == 0 )
            {
                sciStartEventThread( sSock->mGenHandle, sSock->mEventCBFunc,
                                     sSock->mEventCBParam, SCI_EVENT_DISCONNECTED );
            }

            sSock->mConnected = 0;

            sRC = sciMutexLock( &sSock->mShmSeg->mMutex );
            MVP_TEST(sRC != RC_SUCCESS );

            sRC = sciCondSignal( &sSock->mShmSeg->mCond );
            MVP_TEST(sRC != RC_SUCCESS );

            sRC = sciMutexUnlock( &sSock->mShmSeg->mMutex );
            MVP_TEST(sRC != RC_SUCCESS );

            pthread_join( sSock->mRecvThr, NULL );
            sSock->mRecvThr = 0;

            close( sSock->mUdsSock );
            sSock->mUdsSock = -1;

            goto RECONNECT;
        }
    }

END:

    return NULL;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( THREAD_CREATE_ERROR )
    {
        DEBUG(__f, "recv thread create fail : %s", strerror(errno));
    }
    _EXCEPTION_END;

    /*
     * Thread 가 비정상 종료될 때는 별도의 thread 를 생성하여
     * 등록된 Event CallBack 함수를 호출한 후 끝낸다.
     */
    if( sSock != NULL && sSock->mClosed == 0 )
    {
        sciStartEventThread( sSock->mGenHandle, sSock->mEventCBFunc,
                             sSock->mEventCBParam, SCI_EVENT_ABNORMAL_END );
    }

    return NULL;
}


static mvp_rc_t sciInitializeLock( PH_SHM_UNI  aSock )
{
    mvp_rc_t              sRC = 0;

    _IF_RAISE( aSock == NULL, INVALID_HANDLE );
    _IF_RAISE( aSock->mShmSeg == NULL, ETC_ERROR );

    switch( aSock->mOption.mLockEventType )
    {
        case SCI_LOCK_EVENT_COND_MUTEX :
            sRC = sciMutexInitWithAttr( &aSock->mShmSeg->mMutex );
            _IF_RAISE( sRC != 0, ETC_ERROR );

            sRC = sciCondInitWithAttr( &aSock->mShmSeg->mCond );
            _IF_RAISE( sRC != 0, ETC_ERROR );
            break;

        case SCI_LOCK_EVENT_EVENTFD :
        case SCI_LOCK_EVENT_FUTEX :
            break;

        default :
            _RAISE( ETC_ERROR );
    }

    aSock->mShmSeg->mWakeFlag = 0;
    aSock->mShmSeg->mWaitFlag = 0;

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciEventFdLock
 *
 * Description :
 *   eventfd 를 이용하여 Lock 을 구현하였다.
 *   sciEventFdLock 을 호출하면 poll 상태에서 상대방으로부터 event(8 byte 짜리 data)
 *   를 받기까지 대기하게 된다.
 *   즉, Lock 의 경우는 poll 에서 대기하고, Unlock 의 경우는 eventfd 를 통해서
 *   8 byte data 를 Write 하는 것이다.
 *   eventfd 는 상대방에게 event 를 알리고 싶을 때 마치 socket 처럼 이용할 수 있다. 
 *
 * Argument :
 *   @aSock     : shm unicast socket handle
 *   @aEventFd  : poll 할 event fd
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
static mvp_rc_t sciEventFdLock( PH_SHM_UNI     aSock,
                                mvp_sint32_t   aEventFd )
{
    struct pollfd      sMyPollFd;
    mvp_sint32_t       sRet;
    mvp_sint32_t       sMsTimeout;
    mvp_ssize_t        sRead;
    mvp_uint64_t       sU;
    struct epoll_event sEventPoll;
    struct epoll_event sEvent[10];


    _IF_RAISE( aSock == NULL, INVALID_HANDLE );
    _IF_RAISE( aEventFd == -1, INVALID_ARG );

    sMsTimeout = 1000;

    if( aSock->mOption.mPollingType == SCI_POLLING_EPOLL )
    {
        if( aSock->mEpollFd == 0 )
        {
            aSock->mEpollFd = epoll_create(1);

            sEventPoll.events  = EPOLLIN;
            sEventPoll.data.fd = aEventFd;

            epoll_ctl(aSock->mEpollFd, EPOLL_CTL_ADD, aEventFd, &sEventPoll );
        }

        while( ! aSock->mClosed )
        {
            sRet = epoll_wait( aSock->mEpollFd, sEvent, 1, sMsTimeout );
            if( sRet > 0 )
            {
                break;
            }
            else if( sRet == 0 || ( sRet == -1 && errno == 4 ) )
            {
                continue; /* timeout */
            }
            else
            {
                _RAISE( EPOLL_WAIT_ERROR );
            }

        }
    }
    else /* SCI_POLLING_SELECT / SCI_POLLING_POLL */
    {
        sMyPollFd.fd      = aEventFd;
        sMyPollFd.events  = POLLIN;
        sMyPollFd.revents = 0;

        while( ! aSock->mClosed )
        {
            sRet = poll( &sMyPollFd, 1, sMsTimeout );
            MVP_TEST( sRet < 0 );

            if( sRet > 0 )
            {
                break;
            }

            if( aSock->mConnected == 0 )
            {
                return RC_SUCCESS;
            }
        }
    }

    sRead = read( aEventFd, &sU, sizeof(mvp_uint64_t) );
    MVP_TEST( sRead != sizeof(mvp_uint64_t) );

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( EPOLL_WAIT_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciEventFdUnlock
 *
 * Description :
 *   eventfd 를 이용하여 Unlock 을 구현하였다.
 *   상대에게 8 byte data 를 eventfd 를 이용하여 write 함으로써
 *   Lock 상태(poll)에서 깨워준다.
 *
 * Argument :
 *   @aSock     : shm unicast socket handle
 *   @aEventFd  : poll 할 event fd
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
static mvp_rc_t sciEventFdUnlock( PH_SHM_UNI      aSock,
                                  mvp_sint32_t    aEventFd )
{
    mvp_ssize_t   sWrite;
    mvp_uint64_t  sU;

    _IF_RAISE( aSock == NULL, INVALID_HANDLE );
    _IF_RAISE( aEventFd == -1, INVALID_HANDLE );

    sWrite = write( aEventFd, &sU, sizeof(mvp_uint64_t) );
    MVP_TEST( sWrite != sizeof(mvp_uint64_t) );

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


static mvp_rc_t sciEventWaitCondMutex( PH_SHM_UNI  aSock )
{
    mvp_rc_t  sRC;

    sRC = sciMutexLock( &aSock->mShmSeg->mMutex );
    MVP_TEST( sRC != RC_SUCCESS );

    if( aSock->mShmSeg->mWakeFlag == 0 )
    {
        aSock->mShmSeg->mWaitFlag++;

        sRC = sciCondWait( &aSock->mShmSeg->mCond, &aSock->mShmSeg->mMutex );
        MVP_TEST( sRC != RC_SUCCESS );
    }
    else
    {
        aSock->mShmSeg->mWakeFlag--;
    }

    sRC = sciMutexUnlock( &aSock->mShmSeg->mMutex );
    MVP_TEST( sRC != RC_SUCCESS );

    return RC_SUCCESS;

    _EXCEPTION_END;

    sciMutexUnlock( &aSock->mShmSeg->mMutex );

    return RC_FAILURE;
}

static mvp_rc_t sciEventWaitEventFd( PH_SHM_UNI   aSock )
{
    mvp_rc_t   sRC;

    sRC = sciEventFdLock( aSock, aSock->mEventFd );
    MVP_TEST( sRC != RC_SUCCESS );

    return RC_SUCCESS;

    _EXCEPTION_END;

    return RC_FAILURE;
}


/*
 * 테스트를 위해 XPM 의 것을 그대로 따라해봄.
 */
#define futex_wait(P,V,T) syscall(SYS_futex, P, FUTEX_WAIT, V, T, NULL, 0)
#define futex_wake(P,V) syscall(SYS_futex, P, FUTEX_WAKE, V, NULL, NULL, 0)

static mvp_rc_t sciEventWaitFutex( PH_SHM_UNI   aSock )
{
    mvp_rc_t        sRC;
    struct timespec sTimeout;

    sTimeout.tv_sec  = 1;
    sTimeout.tv_nsec = 0;

    errno = 0;

    sRC = futex_wait( &aSock->mShmSeg->mFutex, 0, &sTimeout );
    if( sRC == -1 && errno == ETIMEDOUT )
    {
    }
    else
    {
        atomic_dec( &aSock->mShmSeg->mFutex );
        if( aSock->mShmSeg->mFutex < 0 )
        {
            aSock->mShmSeg->mFutex = 0;
        }
    }

    return RC_SUCCESS;
}


static mvp_rc_t sciEventSignalFutex( PH_SHM_UNI  aSock )
{
    atomic_inc( &aSock->mShmSeg->mFutex );
    futex_wake( &aSock->mShmSeg->mFutex, 0 );

    return RC_SUCCESS;
}


static mvp_rc_t sciEventSignalCondMutex( PH_SHM_UNI   aSock )
{
    mvp_rc_t   sRC;

    sRC = sciMutexLock( &aSock->mShmSeg->mMutex );
    MVP_TEST( sRC != RC_SUCCESS );

    if( aSock->mShmSeg->mWaitFlag == 0 )
    {
        if( aSock->mShmSeg->mWakeFlag == 0 )
        {
            aSock->mShmSeg->mWakeFlag++;
        }
    }
    else
    {
        sRC = sciCondSignal( &aSock->mShmSeg->mCond );
        MVP_TEST( sRC != RC_SUCCESS );

        aSock->mShmSeg->mWaitFlag--;
    }

    sRC = sciMutexUnlock( &aSock->mShmSeg->mMutex );
    MVP_TEST( sRC != RC_SUCCESS );

    return RC_SUCCESS;

    _EXCEPTION_END;

    return RC_FAILURE;
}


static mvp_rc_t sciEventSignalEventFd( PH_SHM_UNI   aSock )
{
    mvp_rc_t   sRC;

    sRC = sciEventFdUnlock( aSock, aSock->mEventFd );
    MVP_TEST( sRC != RC_SUCCESS );

    return RC_SUCCESS;

    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciShmUnicastListen( PHSOCKET        aGenHandle,
                              mvp_sint32_t    aBackLog )
{
    errno = EOPNOTSUPP;

    return RC_FAILURE;
}


PH_SHM_UNI sciShmUnicastAccept( PHSOCKET          aListenHandle,
                                PHSOCKET          aAcceptHandle,
                                struct sockaddr * aAddr,
                                socklen_t       * aAddrLen )
{
    errno = EOPNOTSUPP;

    return NULL;
}


mvp_rc_t sciShmUnicastSendTo( PHSOCKET          aGenHandle,
                              const void      * aData,
                              mvp_size_t        aLength,
                              mvp_sint32_t      aFlag,
                              const struct sockaddr * aTo,
                              socklen_t         aToLen )
{
    errno = EOPNOTSUPP;

    return RC_FAILURE;
}
