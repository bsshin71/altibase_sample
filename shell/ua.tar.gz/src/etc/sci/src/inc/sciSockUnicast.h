/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   TCP 를 이용한 Socket Unicast Communication Type 에 대한 구현.
 ******************************************************************************/

#ifndef __O_SCI_SOCK_UNICAST_H__
#define __O_SCI_SOCK_UNICAST_H__


#include <sciCommon.h>


MVP_EXTERN_C_BEGIN


typedef struct sciSockUnicastOption
{
    mvp_uint32_t        mMaxMsgSize;
    mvp_sint32_t        mPollingType;      /* sciPollingType */
    mvp_sint32_t        mSyncRecvF;        /* sciRecv 사용 */
    mvp_sint32_t        mSyncRecvTimeout;  /* sciRecv 시 기다릴 시간(초) */
    mvp_sint32_t        mRecvPollCount;
} SOCK_UNI_OPT;


typedef struct sciSockUnicastHandle
{
    PHSOCKET            mGenHandle;        /* general socket handle */
    mvp_sint32_t        mSockFd;           /* TCP(Sock Unicast) socket fd */
    SOCK_UNI_OPT        mOption;           /* socket option */
    mvp_sint32_t        mRecvReady;        /* recv thread create and ready to recv data */
    mvp_sint32_t        mClosed;           /* socket closed */
    pthread_t           mRecvThr;          /* thread for recving data */
    sciRecvCallBack   * mRecvCBFunc;       /* data recv 시 실행할 callback 함수 */
    void              * mRecvCBParam;      /* data recv 시 user 가 전달한 param */
    sciEventCallBack  * mEventCBFunc;      /* event recv 시 실행할 callback 함수 */
    void              * mEventCBParam;     /* event recv 시 user 가 전달한 param */
    mvp_char_t          mSvrAddr[16];      /* server address */
    mvp_char_t          mSrcAddr[16];      /* bind address */
} H_SOCK_UNI;

typedef H_SOCK_UNI     * PH_SOCK_UNI;


PH_SOCK_UNI sciSockUnicastSocket( PHSOCKET aGenHandle );
PH_SOCK_UNI sciSockUnicastAccept( PHSOCKET, PHSOCKET, struct sockaddr *, socklen_t * );
mvp_rc_t sciSockUnicastBind( PHSOCKET, struct sockaddr *, socklen_t );
mvp_rc_t sciSockUnicastListen( PHSOCKET, mvp_sint32_t);
mvp_rc_t sciSockUnicastConnect( PHSOCKET, const struct sockaddr *, socklen_t);
mvp_rc_t sciSockUnicastSend( PHSOCKET, const void *, mvp_size_t, mvp_sint32_t );
mvp_rc_t sciSockUnicastSendTo( PHSOCKET, const void *, mvp_size_t, mvp_sint32_t,
                               const struct sockaddr *, socklen_t);
mvp_rc_t sciSockUnicastGetSockOpt( PHSOCKET, mvp_sint32_t, mvp_sint32_t, void *, socklen_t * );
mvp_rc_t sciSockUnicastSetSockOpt( PHSOCKET, mvp_sint32_t, mvp_sint32_t, const void *, socklen_t );
mvp_rc_t sciSockUnicastClose( PHSOCKET );
mvp_rc_t sciSockUnicastRecv( PHSOCKET, void *, mvp_size_t, mvp_sint32_t );


MVP_EXTERN_C_END

#endif  /* __O_SCI_SOCK_UNICAST_H__ */
