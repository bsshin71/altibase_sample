/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   사용자용 Socket API Header.
 *   하단의 통신 방식이 Socket, LDMA, RDMA 과 같이 다양하더라도
 *   사용자는 Socket Like 하게 사용할 수 있도록 구현함.
 *
 *  TCP Unicast             : AF_INET + SOCK_STREAM
 *  UDP Multicast           : AF_INET + SOCK_DGRAM 
 *
 *  UNIX Domain Unicast(UDS): AF_UNIX + SOCK_STREAM
 *
 *  SHM Unicast(LDMA)       : AF_IPC  + SOCK_STREAM
 *  SHM Multicast(NDMA)     : AF_IPC  + SOCK_DGRAM
 *
 *  RDMA Unicast(RC)        : AF_RDMA + SOCK_STREAM
 *  RDMA Multicast(UD)      : AF_RDMA + SOCK_DGRAM
 ******************************************************************************/

#ifndef __O_SCI_H__
#define __O_SCI_H__

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


#define AF_RDMA    (AF_MAX + 1)
#define AF_IPC     (AF_MAX + 2)


#ifdef __cplusplus
extern "C"
{
#endif

/*--------------------------------------------------------
   Communication Type
 --------------------------------------------------------*/
enum sciCommType
{
    SCI_SOCK_UNICAST,    /* TCP Unicast             : AF_INET + SOCK_STREAM */
    SCI_SOCK_MULTICAST,  /* UDP Multicast           : AF_INET + SOCK_DGRAM  */

    SCI_UNIX_UNICAST,    /* UNIX Domain Unicast(UDS): AF_UNIX + SOCK_STREAM */

    SCI_SHM_UNICAST,     /* SHM Unicast(LDMA)       : AF_IPC  + SOCK_STREAM */
    SCI_SHM_MULTICAST,   /* SHM Multicast(NDMA)     : AF_IPC  + SOCK_DGRAM  */

    SCI_RDMA_UNICAST,    /* RDMA Unicast(RC)        : AF_RDMA + SOCK_STREAM */
    SCI_RDMA_MULTICAST,  /* RDMA Multicast(UD)      : AF_RDMA + SOCK_DGRAM  */
};


/*--------------------------------------------------------
 * Socket Handle
 * 기존 Socket 의 FD 와 같은 용도로 사용한다.
 *-------------------------------------------------------*/
typedef void *           PHSOCKET;

/*--------------------------------------------------------
 * User API
 *   - 각 function argument 의 성격은 native socket 함수와 같다.
 *-------------------------------------------------------*/
PHSOCKET sciSocket     ( int domain, int type, int protocol );
int      sciListen     ( PHSOCKET phsock, int backlog );
PHSOCKET sciAccept     ( PHSOCKET phsock, struct sockaddr * addr, socklen_t * addrlen );
int      sciConnect    ( PHSOCKET phsock, const struct sockaddr * serv_addr, socklen_t addrlen );
int      sciBind       ( PHSOCKET phsock, struct sockaddr * my_addr, socklen_t addrlen );
int      sciSend       ( PHSOCKET phsock, const void * msg, size_t len, int flags );
int      sciSendTo     ( PHSOCKET phsock, const void * msg, size_t len, int flags,
                         const struct sockaddr * to, socklen_t tolen );
int      sciGetSockOpt ( PHSOCKET phsock, int level, int optname, void * optval, socklen_t * optlen );
int      sciSetSockOpt ( PHSOCKET phsock, int level, int optname, const void * optval, socklen_t optlen );
int      sciClose      ( PHSOCKET phsock );
int      sciRecv       ( PHSOCKET phsock, void * buf, size_t len, int flags );


/*--------------------------------------------------------
 * Callback Function (사용자 구현영역)
 *  - Data Recv
 *  - Event Recv
 *-------------------------------------------------------*/
typedef void sciRecvCallBack( void * data, int len, void * userparam );
typedef void sciEventCallBack( int event, void * userparam );


/*--------------------------------------------------------
 * Socket Option 을 한번에 지정하기 위한 구조체.
 * 일반적으로 sciGetSockOpt 를 통해 현재값을 구조체로 받아온 후
 * 변경할 옵션 값을 수정한 뒤 해당 구조체를 이용하여
 * 모든 옵션을 설정한다.
 *-------------------------------------------------------*/
struct sciSocketOption
{
    /* common option - SOL_COMMON */
    struct
    {
        sciRecvCallBack    * recv_callback_func;
        void               * recv_callback_param;

        sciEventCallBack   * event_callback_func;
        void               * event_callback_param;

        int                  polling_type;

        int                  sync_recv_f;
        struct timeval       sync_recv_timeout;

        int                  recv_poll_count;
    } common;

    /* level 별 고유 option */
    union
    {
        struct
        {
            unsigned long long   shm_size;
            int                  lock_event_type;
        } ipc;
    };
};


/*--------------------------------------------------------
 * sciGetSockOpt / sciSetSockOpt 의 level 정의
 *-------------------------------------------------------*/
#define SOL_COMMON         0x0100    /* level for common         */
#define SOL_SOCK           0x0200    /* level for socket         */
#define SOL_UNIX           0x0400    /* level for unix domain    */
#define SOL_IPC            0x0800    /* level for shared mem     */
#define SOL_RDMA           0x1000    /* level for rdma           */


/*--------------------------------------------------------
 * sciGetSockOpt / sciSetSockOpt 의 optname 정의
 *-------------------------------------------------------*/
enum sciSolCommon
{
    SO_RECV_CB    = SOL_COMMON + 1,  /* recv callback function   */
    SO_RECV_PARAM,                   /* recv callback parameter  */

    SO_EVENT_CB,                     /* event callback function  */
    SO_EVENT_PARAM,                  /* event callback parameter */

    SO_POLLING_TYPE,                 /* select/poll/epoll        */

    SO_SYNC_RECV,                    /* recv in sync mode */

    SO_RECV_POLL,                    /* 1 mili sec 동안 polling 할 횟수
                                        for data recv thread     */
    SO_OPT_ALL                       /* 모든 option 을 sciSocketOption
                                        구조체에 담아 한꺼번에 설정*/
};

enum sciSolIpc
{
    SO_SHM_SIZE,                     /* shm segment size         */
    SO_LOCK_EVENT_TYPE               /* sciLockEventType         */
};


/*--------------------------------------------------------
 * Polling Type
 --------------------------------------------------------*/
#define SCI_POLLING_DEFAULT    0
enum sciPollingType
{
    SCI_POLLING_SELECT = SCI_POLLING_DEFAULT,
    SCI_POLLING_POLL,
    SCI_POLLING_EPOLL
};


/*--------------------------------------------------------
 * Wait 중인 Message Receiver 를 깨우기 위한  Event 방식
 * sciSetSockOpt 를 통해 변경 (SO_LOCK_EVENT_TYPE)
 *
 *   - cond_wait, cond_signal 이용
 *   - mutex_lock, mutex_unlock 이용
 *   - eventfd 이용
 *   - futex 이용
 --------------------------------------------------------*/
#define SCI_LOCK_EVENT_DEFAULT  0
enum sciLockEventType
{
    SCI_LOCK_EVENT_COND_MUTEX = SCI_LOCK_EVENT_DEFAULT,
    SCI_LOCK_EVENT_EVENTFD,
    SCI_LOCK_EVENT_FUTEX
};


/*--------------------------------------------------------
 * Event Type
 *-------------------------------------------------------*/
#define SCI_EVENT_DISCONNECTED    1
#define SCI_EVENT_CLOSED          2
#define SCI_EVENT_ABNORMAL_END    3


#ifdef __cplusplus
};
#endif

#endif  /* __O_SCI_H__ */
