/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   각종 공통 정보 include.
 *   외부에서는 SCI.h 하나만을 include 하고,
 *   내부 구현에서는 sciCommon.h 하나만 include 하기 위함.
 ******************************************************************************/

#ifndef __O_SCI_COMMON_H__
#define __O_SCI_COMMON_H__

/*--------------------------------------------------------
   system header files
 --------------------------------------------------------*/
#include <pthread.h>
#include <malloc.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/time.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/un.h>
#include <netinet/tcp.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/shm.h>
#include <sys/mman.h>
#include <sys/ipc.h>
#include <stdarg.h>
#include <signal.h>
#include <limits.h>
#include <sys/eventfd.h>
#include <sys/syscall.h>
#include <linux/futex.h>
#include <sched.h>
#include <poll.h>
#include <sys/epoll.h>
#include <sys/ioctl.h>
#include <linux/capability.h>
#include <net/if.h>

/*--------------------------------------------------------
   Definition
 --------------------------------------------------------*/
#define MTU_SIZE       4096

/*--------------------------------------------------------
   SCI header files
 --------------------------------------------------------*/
#include <mvp.h>
#include <sciUtil.h>
#include <sciLock.h>
#include <SCI.h>
#include <sciShmUnicast.h>
#include <sciSockUnicast.h>
#include <sciUnixUnicast.h>
#include <sciSockMulticast.h>

/*--------------------------------------------------------
   Socket Function Pointer
 --------------------------------------------------------*/
typedef int      (* sciPtrListen)( PHSOCKET, int );
typedef PHSOCKET (* sciPtrAccept)( PHSOCKET, PHSOCKET, struct sockaddr *, socklen_t * );
typedef int      (* sciPtrConnect)( PHSOCKET, const struct sockaddr *, socklen_t );
typedef int      (* sciPtrBind)( PHSOCKET, struct sockaddr *, socklen_t );
typedef int      (* sciPtrSend)( PHSOCKET, const void *, size_t, int );
typedef int      (* sciPtrSendTo)( PHSOCKET, const void *, size_t, int,
                                   const struct sockaddr *, socklen_t );
typedef int      (* sciPtrGetSockOpt)( PHSOCKET, int, int, void *, socklen_t * );
typedef int      (* sciPtrSetSockOpt)( PHSOCKET, int, int, const void *, socklen_t );
typedef int      (* sciPtrClose)( PHSOCKET );
typedef int      (* sciPtrRecv)( PHSOCKET, void *, size_t, int );

/*--------------------------------------------------------
   General Socket Handle
 --------------------------------------------------------*/
typedef struct sciSocketHandle
{
    int                 mCommType;         /* communication type */

    void              * mSubHandle;        /* sciCommType 에 따른 각 Handle Pointer */
    void              * mAcceptHandle;     /* accept 후에 리턴되는 Socket Handle->PH_SOCK_UNI */

    sciPtrListen        mFuncListen;
    sciPtrAccept        mFuncAccept;
    sciPtrConnect       mFuncConnect;
    sciPtrBind          mFuncBind;
    sciPtrSend          mFuncSend;
    sciPtrSendTo        mFuncSendTo;
    sciPtrGetSockOpt    mFuncGetSockOpt;
    sciPtrSetSockOpt    mFuncSetSockOpt;
    sciPtrClose         mFuncClose;
    sciPtrRecv          mFuncRecv;
} SocketHandle;

#endif  /* __O_SCI_COMMON_H__ */
