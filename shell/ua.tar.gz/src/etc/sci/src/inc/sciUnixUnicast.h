/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   Unix Domain Socket 을 이용한 Unix Unicast Communication Type 에 대한 구현.
 ******************************************************************************/

#ifndef __O_SCI_UNIX_UNICAST_H__
#define __O_SCI_UNIX_UNICAST_H__


#include <sciCommon.h>


MVP_EXTERN_C_BEGIN


typedef struct sciUnixUnicastOption
{
    mvp_uint32_t        mMaxMsgSize;
    mvp_sint32_t        mPollingType;      /* mPollingType */
    mvp_sint32_t        mSyncRecvF;        /* sciRecv 사용 */
    mvp_sint32_t        mSyncRecvTimeout;  /* sciRecv 시 기다릴 시간(초) */
    mvp_sint32_t        mRecvPollCount;
} UNIX_UNI_OPT;


typedef struct sciUnixUnicastHandle
{
    PHSOCKET            mGenHandle;        /* general socket handle */
    mvp_sint32_t        mSockFd;           /* TCP(Unix Unicast) socket fd */
    UNIX_UNI_OPT        mOption;           /* socket option */
    mvp_sint32_t        mRecvReady;        /* recv thread create and ready to recv data */
    mvp_sint32_t        mClosed;           /* socket closed */
    pthread_t           mRecvThr;          /* thread for recving data */
    sciRecvCallBack   * mRecvCBFunc;       /* data recv 시 실행할 callback 함수 */
    void              * mRecvCBParam;      /* data recv 시 user 가 전달한 param */
    sciEventCallBack  * mEventCBFunc;      /* event recv 시 실행할 callback 함수 */
    void              * mEventCBParam;     /* event recv 시 user 가 전달한 param */
    mvp_char_t          mSvrAddr[16];      /* server address */
    mvp_char_t          mSrcAddr[16];      /* bind address */
    mvp_sint32_t        mEpollFd;          /* recv epoll fd */
} H_UNIX_UNI;

typedef H_UNIX_UNI     * PH_UNIX_UNI;


PH_UNIX_UNI sciUnixUnicastSocket( PHSOCKET aGenHandle );
PH_UNIX_UNI sciUnixUnicastAccept( PHSOCKET, PHSOCKET, struct sockaddr *, socklen_t * );
mvp_rc_t sciUnixUnicastBind( PHSOCKET, struct sockaddr *, socklen_t );
mvp_rc_t sciUnixUnicastListen( PHSOCKET, mvp_sint32_t);
mvp_rc_t sciUnixUnicastConnect( PHSOCKET, const struct sockaddr *, socklen_t);
mvp_rc_t sciUnixUnicastSend( PHSOCKET, const void *, mvp_size_t, mvp_sint32_t );
mvp_rc_t sciUnixUnicastSendTo( PHSOCKET, const void *, mvp_size_t, mvp_sint32_t,
                               const struct sockaddr *, socklen_t);
mvp_rc_t sciUnixUnicastGetSockOpt( PHSOCKET, mvp_sint32_t, mvp_sint32_t, void *, socklen_t * );
mvp_rc_t sciUnixUnicastSetSockOpt( PHSOCKET, mvp_sint32_t, mvp_sint32_t, const void *, socklen_t );
mvp_rc_t sciUnixUnicastClose( PHSOCKET );
mvp_rc_t sciUnixUnicastRecv( PHSOCKET, void *, mvp_size_t, mvp_sint32_t );


MVP_EXTERN_C_END

#endif  /* __O_SCI_UNIX_UNICAST_H__ */
