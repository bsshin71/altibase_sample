/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   Lock Interface(Futex Mutex, Pthread Mutex, Event Fd(not yet), ...)
 ******************************************************************************/

#ifndef __O_SCI_LOCK_H__
#define __O_SCI_LOCK_H__

#include <sciCommon.h>

#define USE_POSIX_LOCK

MVP_EXTERN_C_BEGIN

/*
 * 현재는 define 을 통해 posix 및 futex 를 선택하도록 되어있지만,
 * 결국은 XPM 처럼 posix, futex, eventfd 방식을 socket level 에서
 * setsockopt 를 통해 변경하도록 구현하는 것이 좋겠다.
 */
#ifdef USE_POSIX_LOCK
/***********************************************************
 * Posix Thread Mutex 를 사용하는 경우
 ***********************************************************/

typedef pthread_mutex_t mutex_t;
typedef pthread_cond_t  cond_t;

mvp_rc_t sciPosixMutexInit( mutex_t * aMutex, pthread_mutexattr_t * aAttr );
mvp_rc_t sciPosixMutexDestroy( mutex_t * aMutex );
mvp_rc_t sciPosixMutexLock( mutex_t * aMutex );
mvp_rc_t sciPosixMutexTrylock( mutex_t * aMutex );
mvp_rc_t sciPosixMutexUnlock( mutex_t * aMutex );

mvp_rc_t sciPosixCondInit( cond_t * aCond, pthread_condattr_t * aAttr );
mvp_rc_t sciPosixCondDestroy( cond_t * aCond );
mvp_rc_t sciPosixCondWait( cond_t * aCond, mutex_t * aMutex );
mvp_rc_t sciPosixCondSignal( cond_t * aCond );
mvp_rc_t sciPosixCondBroadcast( cond_t * aCond );

mvp_rc_t sciMutexInitWithAttr( mutex_t * aMutex );
mvp_rc_t sciCondInitWithAttr( cond_t * aCond );

#define sciMutexInit(m,a)      sciPosixMutexInit((m),(a))
#define sciMutexDestroy(m)     sciPosixMutexDestroy((m))
#define sciMutexLock(m)        sciPosixMutexLock((m))
#define sciMutexTrylock(m)     sciPosixMutexTrylock((m))
#define sciMutexUnlock(m)      sciPosixMutexUnlock((m))

#define sciCondInit(c,a)       sciPosixCondInit((c),(a))
#define sciCondDestroy(c)      sciPosixCondDestroy((c))
#define sciCondWait(c,m)       sciPosixCondWait((c),(m))
#define sciCondSignal(c)       sciPosixCondSignal((c))
#define sciCondBroadcast(c)    sciPosixCondBroadcast((c))

#else
/***********************************************************
 * Posix Thread Mutex 를 사용하지 않을 경우는 
 * Futex 로 구현된 Lock 을 사용한다.
 ***********************************************************/

/*
 * mU32 에서 최하위 1 bit 는 locked/unlocked
 * 바로 위 1 byte 는 contended/uncontended
 */
union futex_mutex_t
{
    unsigned  mU32;
    struct
    {
        unsigned char mLocked;
        unsigned char mContended;
    }b;
};


struct futex_cond_t
{
    futex_mutex_t * mMutex;
    int             mSeq;
    int             mPShared;
};

typedef union futex_mutex_t mutex_t;
typedef struct futex_cond_t cond_t;

mvp_rc_t sciMutexInitWithAttr( mutex_t * aMutex );
mvp_rc_t sciCondInitWithAttr( cond_t * aCond );

mvp_rc_t sciMutexInit( mutex_t * aMutex, pthread_mutexattr_t * aAttr );
mvp_rc_t sciMutexDestroy( mutex_t * aMutex );
mvp_rc_t sciMutexLock( mutex_t * aMutex );
mvp_rc_t sciMutexTrylock( mutex_t * aMutex );
mvp_rc_t sciMutexUnlock( mutex_t * aMutex );

mvp_rc_t sciCondInit( cond_t * aCond, pthread_condattr_t * aAttr );
mvp_rc_t sciCondDestroy( cond_t * aCond );
mvp_rc_t sciCondWait( cond_t * aCond, mutex_t * aMutex );
mvp_rc_t sciCondSignal( cond_t * aCond );
mvp_rc_t sciCondBroadcast( cond_t * aCond );

#endif

#define atomic_xadd(P, V)      __sync_fetch_and_add((P), (V))
#define cmpxchg(P, O, N)       __sync_val_compare_and_swap((P), (O), (N))
#define atomic_inc(P)          __sync_add_and_fetch((P), 1)
#define atomic_dec(P)          __sync_sub_and_fetch((P), 1)
#define atomic_add(P, V)       __sync_add_and_fetch((P), (V))
#define atomic_sub(P, V)       __sync_sub_and_fetch((P), (V))
#define atomic_set_bit(P, V)   __sync_or_and_fetch((P), 1<<(V))
#define atomic_clear_bit(P, V) __sync_and_and_fetch((P), ~(1<<(V)))
#define cpu_relax() asm volatile("pause\n": : :"memory")
#define barrier()   asm volatile("": : :"memory")


MVP_EXTERN_C_END

#endif  /* __O_SCI_LOCK_H__ */
