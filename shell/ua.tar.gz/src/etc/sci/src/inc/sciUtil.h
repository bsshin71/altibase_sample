/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   Utility Function
 ******************************************************************************/

#ifndef __O_SCI_UTIL_H__
#define __O_SCI_UTIL_H__

#include <sciCommon.h>


MVP_EXTERN_C_BEGIN


/*
 * 임시적으로 사용할 debug log 용
 * low latency 에서 사용할 trace log library 는
 * 다시 만들어야 함.
 */
extern mvp_sint32_t   __f;
#define DEBUG(f,fmt, ...)                                      \
       do {                                                    \
            if(f)                                              \
                fprintf(stderr, "[%-20s:%5d:%-20s()] :: " fmt"\n", __FILE__, \
                    __LINE__, __func__, __VA_ARGS__);          \
          } while (0)

/*
#define DEBUG(flag,fmt, ...)                                    \
       do {                                                     \
          } while (0)
*/

typedef struct _sciSleep
{
    struct timespec   m_start;
    struct timespec   m_end;
    long              m_diff;
    long              m_loop;
} sciSleep;


#define MICROSEC (1000*1000)
#define NANOSEC  (1000*1000*1000)


#ifdef X86_ATOMIC
#define SCHED_YIELD(xs, nsleep)                        \
    /* cpu_relax가 5ns 정도 소비 함으로 /5 한다.*/     \
    (xs)->m_loop = (nsleep - (xs)->m_diff)/5;          \
    while( (xs)->m_loop-- > 0 )  cpu_relax();        
#else
#define SCHED_YIELD(xs, nsleep)                        \
    sched_yield();                             
#endif

#define diffTime( start, end )                         \
      (((end)->tv_sec - (start)->tv_sec)*MICROSEC)     \
    + ((end)->tv_usec - (start)->tv_usec)

#define diffNanoTime( start, end )                     \
      (((end)->tv_sec - (start)->tv_sec)*NANOSEC)      \
    + ((end)->tv_nsec - (start)->tv_nsec)

#define addNanoTime( start, diff )                     \
      (start)->tv_nsec += diff;                        \
      (start)->tv_sec += ((start)->tv_nsec / NANOSEC); \
      (start)->tv_nsec = ((start)->tv_nsec % NANOSEC);

/* nsleep 만큼 nano sleep한다.  */
#define sciSleepNano(xs, nsleep)                                    \
{                                                                   \
    MVP_TEST(clock_gettime( CLOCK_REALTIME, &(xs)->m_start )!=0);   \
    while( 1 )                                                      \
    {                                                               \
        MVP_TEST(clock_gettime( CLOCK_REALTIME, &(xs)->m_end )!=0); \
        (xs)->m_diff = diffNanoTime(&(xs)->m_start, &(xs)->m_end);  \
        if( (xs)->m_diff > nsleep )   break;                        \
        SCHED_YIELD(xs, nsleep)                                     \
    }                                                               \
}

typedef struct sciShmInfo
{
    mvp_sint32_t    mShmId;
    mvp_uint64_t    mSize;
    mvp_char_t      mPath[128];
    void          * mData;
} sciShmInfo;

typedef void sciEventCB( int event, void * userparam );
typedef struct sciEventStruct
{
    sciEventCB       * mCBFunc;
    void             * mCBParam;
    mvp_sint32_t       mEvent;
    pthread_t          mId;
} sciEventStruct;


mvp_rc_t sciSetFuncPtr( void         * aSockHandle,
                        mvp_sint32_t   aDomain,
                        mvp_sint32_t   aType );

mvp_rc_t sciSetNonBlock( mvp_sint32_t  aFd );

mvp_rc_t sciShmAttach( sciShmInfo       * aShm,
                       mvp_sint32_t     * aFirst );

mvp_rc_t sciShmDettach( sciShmInfo   * aShm );

mvp_rc_t sciSleepMicro(long usec);

mvp_rc_t sciStartEventThread( void         * aGenSocket,
                              sciEventCB   * aCBFunc,
                              void         * aUserData,
                              mvp_sint32_t   aEvent );

void * sciEventCallBackThread( void * aParam );

void Elapsed( mvp_char_t      * aFunc_name,
              struct timespec   aStart,
              struct timespec   aEnd,
              mvp_sint32_t      aTest_count );


MVP_EXTERN_C_END

#endif /* __O_SCI_UTIL_H__ */
