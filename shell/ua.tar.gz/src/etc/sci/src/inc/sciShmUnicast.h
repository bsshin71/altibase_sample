/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   Shared Memory 를 이용하여 Unicast Socket Like 하게 구현
 ******************************************************************************/

#ifndef __O_SCI_SHM_UNICAST_H__
#define __O_SCI_SHM_UNICAST_H__


#include <sciCommon.h>


MVP_EXTERN_C_BEGIN

/*
 * one side 최대 약 100 nano 정도가 더 느리네.
 * default 는 일단 OFF 로 하자.
 */
//#define SPEED


typedef struct sciShmUnicastOption
{
    mvp_uint64_t           mShmSize;          /* shm 의 총크기. 이 값과 MTU size 에
                                                 의해서 item 갯수 결정 */
    mvp_sint32_t           mRecvPollCount;    /* 1 mili sec 에 poll 하는 count */  
    mvp_sint32_t           mLockEventType;    /* Lock Event Type (sciLockEventType) */
    mvp_sint32_t           mPollingType;      /* mLockEventType 이 eventfd 일 경우에 사용.
                                                 epoll/select/poll (sciPollingType) */
    mvp_sint32_t           mSyncRecvF;        /* sciRecv 사용 */
    mvp_sint32_t           mSyncRecvTimeout;  /* sciRecv 시 기다릴 시간(초) */
} SHM_UNI_OPT;


/*
 * 하나의 주고받는 data 를 저장할 공간.
 */
typedef struct sciShmUnicastMsgBlock
{
    mvp_sint32_t           mMsgSize;        /* Send 한 data 크기. send 시에 기록.
                                            Recv Thread 는 이 Size 를 CallBack 
                                            함수의 Length 로 넘긴다. */
#ifdef SPEED
    volatile mvp_sint64_t  mWrite;
    volatile mvp_sint64_t  mRead;
#endif

    mvp_char_t             mData[MTU_SIZE]; /* 실제 send data 가 쓰여지는 공간 */
} sciShmMsgBlock;


/*
 * Shared Memory 에 매핑할 구조체
 */
typedef struct sciShmUnicastSegment
{
    mutex_t                mMutex;        /* SCI_LOCK_EVENT_COND_MUTEX, SCI_LOCK_EVENT_MUTEX 경우 */
    cond_t                 mCond;         /* SCI_LOCK_EVENT_COND_MUTEX 인 경우 사용 */
    volatile mvp_sint32_t  mFutex;        /* SCI_LOCK_EVENT_FUTEX 경우 */
    volatile mvp_sint32_t  mWaitFlag;     /* 이 값이 1 일 경우만 CondSignal 보냄 */
    volatile mvp_sint32_t  mWakeFlag;     /* CondSignal 을 통해 깨웠다 */
    mvp_sint32_t           mMsgBlockCnt;  /* shm msg block 갯수 */
    mvp_uint64_t           mShmSize;      /* 생성한 Shm 의 크기 */
#ifdef SPEED                              /* 자신의 register 변수값만 신경쓰면 되도록 */
    mvp_sint64_t           mWritePos;
    mvp_uint8_t            mCacheLine[64];
    mvp_sint64_t           mReadPos;
#else
    volatile mvp_sint64_t  mWritePos;     /* Sender 에서 마지막 Write 한 위치 */
    mvp_uint8_t            mCacheLine[64];  /* 이것으로 one side 40~50 ns 정도 이득봄 */
    volatile mvp_sint64_t  mReadPos;      /* Receiver 에서 마지막 Read 한 위치 */
#endif
    volatile mvp_sint32_t  mWaitSigF;     /* 수신측이 wait 할 때만 signal 을 보내도록 */
    sciShmMsgBlock         mMsgBlocks[0]; /* Msg Buffer Array 시작 지점(sciShmMsgBlock array) */
} sciShmUnicastSegment;


/*
 * Shm Unicast 용 Socket Handle 구조체
 */
typedef struct sciShmUnicastHandle  H_SHM_UNI;
typedef H_SHM_UNI *                 PH_SHM_UNI;

typedef mvp_sint32_t sciLockEventFunc( PH_SHM_UNI  aShmUnicastHandle );

struct sciShmUnicastHandle
{
    PHSOCKET                mGenHandle;   /* general socket handle */
    SHM_UNI_OPT             mOption;      /* setsockopt 용 socket option */
    mvp_sint32_t            mClosed;      /* socket close 시 1 로 설정 */ 
    mvp_sint32_t            mConnected;   /* Connection Check 를 위한 Unix Domain
                                             Socket 의 연결 시 1 로 설정 */
    struct sockaddr_in      mSrcAddrIn;   /* Local Bind Address */
    pthread_t               mRecvThr;     /* Data 를 Recv 하는 Thr */
    pthread_t               mEventThr;    /* connection manager thread */
    void                  * mRecvCBParam; /* Data Recv 시 넘겨줄 Param Pointer */
    sciRecvCallBack       * mRecvCBFunc;  /* Data Recv 시 CallBack 함수 */
    void                  * mEventCBParam;/* Event 발생 시 넘겨줄 Param Pointer */
    sciEventCallBack      * mEventCBFunc; /* Event 발생 시 CallBack 함수 */
    mvp_sint32_t            mEventFd;     /* LOCK_EVENT_EVENT_FD 일 경우 사용 */
    sciShmUnicastSegment  * mShmSeg;      /* pointer to sciShmUnicastSegment = mShmInfo.mData */
    sciShmInfo              mShmInfo;     /* 생성한 Shm 정보 */
    mvp_sint32_t            mSender;      /* sender 인지 여부 */
    sciLockEventFunc      * mEventWait;   /* Recv Thread 가 읽을 것이 없을 때 대기 */
    sciLockEventFunc      * mEventSignal; /* Sender 가 하나의 Data 를 Write 한 후
                                             대기하고 있는 Recv Thread 깨움 */
    mvp_sint32_t            mUdsSock;     /* Connection Check 를 위한 Unix Domain Socket Fd */
    mvp_sint32_t            mEpollFd;     /* epoll fd */
};


PH_SHM_UNI sciShmUnicastSocket( PHSOCKET aGenHandle );
PH_SHM_UNI sciShmUnicastAccept( PHSOCKET, PHSOCKET, struct sockaddr *, socklen_t * );
mvp_rc_t sciShmUnicastBind( PHSOCKET, struct sockaddr *, socklen_t );
mvp_rc_t sciShmUnicastListen( PHSOCKET, mvp_sint32_t);
mvp_rc_t sciShmUnicastConnect( PHSOCKET, const struct sockaddr *, socklen_t);
mvp_rc_t sciShmUnicastSend( PHSOCKET, const void *, mvp_size_t, mvp_sint32_t );
mvp_rc_t sciShmUnicastSendTo( PHSOCKET, const void *, mvp_size_t, mvp_sint32_t,
                               const struct sockaddr *, socklen_t);
mvp_rc_t sciShmUnicastGetSockOpt( PHSOCKET, mvp_sint32_t, mvp_sint32_t, void *, socklen_t * );
mvp_rc_t sciShmUnicastSetSockOpt( PHSOCKET, mvp_sint32_t, mvp_sint32_t, const void *, socklen_t );
mvp_rc_t sciShmUnicastClose( PHSOCKET );
mvp_rc_t sciShmUnicastRecv( PHSOCKET, void *, mvp_size_t, mvp_sint32_t );


MVP_EXTERN_C_END

#endif  /* __O_SCI_SHM_UNICAST_H__ */
