/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   Internet UDP 를 이용한 Socket Multicast Communication Type 에 대한 구현.
 ******************************************************************************/

#ifndef __O_SCI_SOCK_MULTICAST_H__
#define __O_SCI_SOCK_MULTICAST_H__


#include <sciCommon.h>


MVP_EXTERN_C_BEGIN


typedef struct sciSockMulticastOption
{
    mvp_uint32_t        mMaxMsgSize;
    mvp_sint32_t        mPollingType;      /* sciPollintType */
    mvp_sint32_t        mSyncRecvF;        /* sciRecv 사용 */
    mvp_sint32_t        mSyncRecvTimeout;  /* sciRecv 시 기다릴 시간(초) */
    mvp_sint32_t        mRecvPollCount;
} SOCK_MULTI_OPT;


typedef struct sciSockMulticastHandle
{
    PHSOCKET            mGenHandle;        /* general socket handle */
    mvp_sint32_t        mSockFd;           /* UDP(Sock Multicast) socket fd */
    SOCK_MULTI_OPT      mOption;           /* socket option */
    mvp_sint32_t        mRecvReady;        /* recv thread create and ready to recv data */
    mvp_sint32_t        mClosed;           /* socket closed */
    mvp_sint32_t        mMtuSize;          /* MTU size */
    pthread_t           mRecvThr;          /* thread for recving data */
    sciRecvCallBack   * mRecvCBFunc;       /* data recv 시 실행할 callback 함수 */
    void              * mRecvCBParam;      /* data recv 시 user 가 전달한 param */
    sciEventCallBack  * mEventCBFunc;      /* event recv 시 실행할 callback 함수 */
    void              * mEventCBParam;     /* event recv 시 user 가 전달한 param */
    struct sockaddr_in  mSvrAddrIn;        /* server address */
    struct sockaddr_in  mSrcAddrIn;        /* local address */
} H_SOCK_MULTI;

typedef H_SOCK_MULTI   * PH_SOCK_MULTI;


PH_SOCK_MULTI sciSockMulticastSocket( PHSOCKET aGenHandle );
PH_SOCK_MULTI sciSockMulticastAccept( PHSOCKET, PHSOCKET, struct sockaddr *, socklen_t * );
mvp_rc_t sciSockMulticastBind( PHSOCKET, struct sockaddr *, socklen_t );
mvp_rc_t sciSockMulticastListen( PHSOCKET, mvp_sint32_t);
mvp_rc_t sciSockMulticastConnect( PHSOCKET, const struct sockaddr *, socklen_t);
mvp_rc_t sciSockMulticastSend( PHSOCKET, const void *, mvp_size_t, mvp_sint32_t );
mvp_rc_t sciSockMulticastSendTo( PHSOCKET, const void *, mvp_size_t, mvp_sint32_t,
                               const struct sockaddr *, socklen_t);
mvp_rc_t sciSockMulticastGetSockOpt( PHSOCKET, mvp_sint32_t, mvp_sint32_t, void *, socklen_t * );
mvp_rc_t sciSockMulticastSetSockOpt( PHSOCKET, mvp_sint32_t, mvp_sint32_t, const void *, socklen_t );
mvp_rc_t sciSockMulticastClose( PHSOCKET );
mvp_rc_t sciSockMulticastRecv( PHSOCKET, void *, mvp_size_t, mvp_sint32_t );


MVP_EXTERN_C_END

#endif  /* __O_SCI_SOCK_MULTICAST_H__ */
