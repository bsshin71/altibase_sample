/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   unix domain socket
 *
 *   Sender 측 :
 *      sciUnixUnicastSocket
 *      sciUnixUnicastSetSockOpt
 *      sciUnixUnicastBind
 *      sciUnixUnicastSend
 *   Receiver 측 :
 *      sciUnixUnicastSocket
 *      sciUnixUnicastBind
 *      sciUnixUnicastListen
 *      sciUnixUnicastAccept
 *      sciUnixUnicastSetSockOpt
 ******************************************************************************/
#include <sciCommon.h>

static void * sciRecvThrFunc( void * aArg );
static mvp_rc_t sciSetBlock( PH_UNIX_UNI aSock, struct timeval * aTimeout );
static mvp_rc_t sciSetNonBlock( PH_UNIX_UNI aGenHandle );
static mvp_size_t sciBlockSend( PH_UNIX_UNI aSock, const void * aBuf,
                                mvp_size_t aLen, mvp_sint32_t aFlag );


/*******************************************************************************
 * Name : sciUnixUnicastSocket
 *
 * Description :
 *   Tcp Socket 을 하나 생성한 후 이를 관리할 Handle 을 리턴한다.
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *
 * Return :
 *   ptr to H_UNIX_UNI : 성공, NULL : 실패
 *
 * How To Use :
 ******************************************************************************/
PH_UNIX_UNI sciUnixUnicastSocket( PHSOCKET aGenHandle )
{
    //mvp_sint32_t   sFlag = 1;
    mvp_sint32_t   sRet  = 0;
    PH_UNIX_UNI    sSock = NULL;
    SocketHandle * sGenHandle;

    _IF_RAISE( aGenHandle == NULL, INVALID_ARG );
    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_UNIX_UNI)malloc(sizeof(H_UNIX_UNI));
    _IF_RAISE( sSock == NULL, LACK_OF_MEMORY );
    memset( sSock, 0x00, sizeof(H_UNIX_UNI));

    _IF_RAISE( (sSock->mSockFd = socket( AF_UNIX,
                                              SOCK_STREAM,
                                              0))
                    < 0, SOCK_CREAT_FAIL );

    sSock->mOption.mMaxMsgSize      = 4096;
    sSock->mOption.mPollingType     = SCI_POLLING_DEFAULT;
    sSock->mOption.mSyncRecvF       = 0;
    sSock->mOption.mSyncRecvTimeout = -1;   /* infinite */
    sSock->mOption.mRecvPollCount   = 0;

    sSock->mGenHandle = sGenHandle;
    sSock->mClosed = 0;

    DEBUG(__f, "socket creation ok. fd[%d]", sSock->mSockFd);

    sRet = sciSetNonBlock( sSock );
    _IF_RAISE( sRet < 0, SET_NONBLOCK_ERROR );

    sGenHandle->mSubHandle = sSock;

    return sSock;

    _EXCEPTION( INVALID_ARG )
    {
        DEBUG(__f, "invalid argument : aGenHandle[%d]", 0);
        errno = EINVAL;
    }
    _EXCEPTION( LACK_OF_MEMORY )
    {
        DEBUG(__f, "malloc fail : %s", strerror(errno));
        errno = ENOMEM;
    }
    _EXCEPTION( SOCK_CREAT_FAIL )
    {
        DEBUG(__f, "socket create fail : %s", strerror(errno));
    }
    _EXCEPTION( SET_NONBLOCK_ERROR )
    {
        DEBUG(__f, "set nonblock mode fail : %s", strerror(errno));
    }
    _EXCEPTION_END;

    if( sSock != NULL )
    {
        free( sSock );
    }

    return NULL;
}


/*******************************************************************************
 * Name : sciUnixUnicastListen
 *
 * Description :
 *   Tcp 에서의 listen 역할을 수행한다.
 *
 * Argument :
 *   @aGenHandle  : general socket handle
 *   @aBackLog    : back log
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciUnixUnicastListen( PHSOCKET      aGenHandle,
                               mvp_sint32_t  aBackLog )
{
    PH_UNIX_UNI   sSock = NULL;
    SocketHandle * sGenHandle;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_UNIX_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL || sSock->mSockFd <= 0, INVALID_HANDLE );

    _IF_RAISE( listen(sSock->mSockFd, aBackLog) != 0, LISTEN_UNIX_FAIL );
    DEBUG(__f, "socket listen ok. fd[%d]", sSock->mSockFd);

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( LISTEN_UNIX_FAIL )
    {
        DEBUG(__f, "listen socket fail. fd[%d]", sSock->mSockFd );
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciUnixUnicastAccept
 *
 * Description :
 *   Tcp 에서의 accept 역할을 수행한다.
 *
 * Argument :
 *   @aGenHandle : accept general socket handle
 *   @aAddr      : sockaddr 구조체 포인터
 *   @aAddrLen   : sizeof(sockaddr)
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
PH_UNIX_UNI sciUnixUnicastAccept( PHSOCKET    aGenListen,
                                  PHSOCKET    aGenAccept,
                                  struct sockaddr * aAddr,
                                  socklen_t * aLen )
{
    mvp_sint32_t         sRet;
    mvp_sint32_t         sListenFd;
    fd_set               sFdSet;
    struct timeval       sTimeout;
    PH_UNIX_UNI          sListen = NULL;
    PH_UNIX_UNI          sAccept = NULL;
    SocketHandle       * sGenListen;

    _IF_RAISE( aGenListen == NULL, INVALID_HANDLE );
    _IF_RAISE( aGenAccept == NULL, INVALID_HANDLE );

    sGenListen = (SocketHandle *)aGenListen;

    sListen = (PH_UNIX_UNI)sGenListen->mSubHandle;
    _IF_RAISE( sListen == NULL || sListen->mSockFd <= 0, INVALID_HANDLE );

    /*----------------------------------------------------
     * Accept Socket Handle 에 Listen Socket Handle 의
     * 모든 값들을 copy
     -----------------------------------------------------*/
    sAccept = (PH_UNIX_UNI)malloc(sizeof(H_UNIX_UNI));
    _IF_RAISE( sAccept == NULL, LACK_OF_MEMORY );
    memcpy( sAccept, sListen, sizeof(H_UNIX_UNI));

    sListenFd = sListen->mSockFd;

RETRY:
    _IF_RAISE( sListen->mClosed == 1, CLOSED );

    sTimeout.tv_sec = 1;
    sTimeout.tv_usec = 0;

    FD_ZERO(&sFdSet);
    FD_SET( sListen->mSockFd, &sFdSet );

    sRet = select( sListen->mSockFd+1, &sFdSet, NULL, NULL, &sTimeout );
    _IF_RAISE( sRet < 0, SELECT_ERROR );
    if( sRet == 0 )
    {
        goto RETRY;
    }

    if( FD_ISSET(sListen->mSockFd, &sFdSet) != 0 )
    {
        sRet = sciSetNonBlock( sListen );
        _IF_RAISE( sRet < 0, ETC_ERROR );

        _IF_RAISE( (sAccept->mSockFd = accept( sListen->mSockFd,
                                                    (struct sockaddr *)aAddr,
                                                    aLen ))
                        < 0, ACCEPT_ERROR );
        strcpy( sAccept->mSvrAddr, ((struct sockaddr_un *)aAddr)->sun_path);

        sRet = sciSetNonBlock( sAccept );
        _IF_RAISE( sRet < 0, ETC_ERROR );

        DEBUG(__f, "accept fd[%d]", sAccept->mSockFd );

        /* ACCEPTED */
    }
    else
    {
        goto RETRY;
    }

    /* sync recv mode 일 때는 recv thread 불필요 */
    if( sAccept->mOption.mSyncRecvF == 0 )
    {
        _IF_RAISE( (sRet = pthread_create( &sAccept->mRecvThr,
                                                NULL,
                                                sciRecvThrFunc,
                                                (void *)aGenAccept ))
                        != 0, THREAD_CREAT_ERROR );
    }

    sAccept->mGenHandle = aGenAccept;

    return sAccept;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( LACK_OF_MEMORY )
    {
        errno = ENOMEM;
    }
    _EXCEPTION( SELECT_ERROR )
    {
        DEBUG(__f, "select fail[%d] : %s", sListen->mSockFd, strerror(errno));
    }
    _EXCEPTION( ACCEPT_ERROR )
    {
        DEBUG(__f, "accept fail[%d] : %s", sListen->mSockFd, strerror(errno));
    }
    _EXCEPTION( THREAD_CREAT_ERROR )
    {
        DEBUG(__f, "create thread fail : %s", strerror(errno));
    }
    _EXCEPTION( CLOSED )
    {
        DEBUG(__f, "socket closed[fd:%d]", sListenFd);
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    if( sAccept != NULL )
    {
        free( sAccept );
    }

    return NULL;
}


/*******************************************************************************
 * Name : sciUnixUnicastConnect
 *
 * Description :
 *   Tcp 에서 connect 역할 수행
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *   @aServAddr  : Server 주소
 *   @aAddrLen   : Server 주소 Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciUnixUnicastConnect( PHSOCKET       aGenHandle,
                                const struct sockaddr * aAddr,
                                socklen_t      aLen )
{
    mvp_rc_t       sRet   = 0;
    PH_UNIX_UNI    sSock  = NULL;
    SocketHandle * sGenHandle;
    struct sockaddr_un * sIn = (struct sockaddr_un *)aAddr;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_UNIX_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock->mSockFd <= 0, INVALID_HANDLE );
    _IF_RAISE( aAddr == NULL, INVALID_ARG );
    _IF_RAISE( aLen <= 0, INVALID_ARG );

    sRet = sprintf( sSock->mSvrAddr, "%s", sIn->sun_path );
    _IF_RAISE( sRet < 0, ETC_ERROR );

    _IF_RAISE( (sRet = connect( sSock->mSockFd,
                                     aAddr,
                                     aLen ))
                    < 0, CONNECT_ERROR );
    DEBUG(__f, "connect ok. sockfd[%d]", sSock->mSockFd);

    if( sSock->mOption.mSyncRecvF == 0 )
    {
        _IF_RAISE( (sRet = pthread_create( &sSock->mRecvThr,
                                                NULL,
                                                sciRecvThrFunc,
                                                (void *)sGenHandle ))
                        != 0, THREAD_CREAT_ERROR );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( CONNECT_ERROR )
    {
        DEBUG(__f, "connect fail : %s", strerror(errno));
    }
    _EXCEPTION( THREAD_CREAT_ERROR )
    {
        DEBUG(__f, "create thread fail : %s", strerror(errno));
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciUnixUnicastBind
 *
 * Description :
 *   Tcp 에서의 bind 역할을 수행한다.
 *
 * Argument :
 *   @aGenHandle  : general socket handle
 *   @aAddr       : sockaddr 구조체 포인터
 *   @aAddrLen    : sizeof(sockaddr)
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciUnixUnicastBind( PHSOCKET          aGenHandle,
                             struct sockaddr * aAddr,
                             socklen_t         aLen )
{
    mvp_rc_t              sRet  = 0;
    PH_UNIX_UNI           sSock = NULL;
    SocketHandle        * sGenHandle;
    mvp_sint32_t          sSize = 10*1024*1024;
    struct sockaddr_un  * sIn   = NULL;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_UNIX_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL || sSock->mSockFd <= 0, INVALID_HANDLE );
    _IF_RAISE( aAddr == NULL, INVALID_ARG );
    _IF_RAISE( aLen <= 0, INVALID_ARG );

    sIn = (struct sockaddr_un *)aAddr;
    sprintf( sSock->mSrcAddr, "%s", sIn->sun_path );

    _IF_RAISE( (sRet = setsockopt( sSock->mSockFd,
                                        SOL_SOCKET,
                                        SO_RCVBUF,
                                        &sSize,
                                        sizeof(sSize)))
                    != 0, SET_SOCKOPT_FAIL );
    DEBUG(__f, "setsockopt so_rcvbuf ok. fd[%d] size[%d]", sSock->mSockFd, sSize);

    if( access(sIn->sun_path, R_OK) == 0 )
    {
        unlink( sIn->sun_path );
    }

    _IF_RAISE( (sRet = bind( sSock->mSockFd,
                                  (struct sockaddr *)aAddr,
                                  aLen ))
                    != 0, BIND_ERROR );
    DEBUG(__f, "socket bind ok. fd[%d] path[%s]", sSock->mSockFd, sIn->sun_path);

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EINVAL;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( SET_SOCKOPT_FAIL )
    {
        DEBUG(__f, "setsockopt fail : %s", strerror(errno));
    }
    _EXCEPTION( BIND_ERROR )
    {
        DEBUG(__f, "bind fail : %s", strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciUnixUnicastSend
 *
 * Description :
 *   Tcp Socket 을 이용하여 Data 를 send 한다.
 *
 * Argument :
 *   @aGenHandle  : sock unicast general handle
 *   @aBuf        : 보낼 Data Buffer
 *   @aLen        : 보낼 Data Length
 *   @aFlag       : 현재 미사용
 *
 * Return :
 *   Send Length : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciUnixUnicastSend( PHSOCKET         aGenHandle,
                             const void     * aMsg,
                             mvp_size_t       aLen,
                             mvp_sint32_t     aFlags )
{
    PH_UNIX_UNI    sSock = NULL;
    SocketHandle * sGenHandle;
    mvp_sint32_t   sRet  = 0;
    mvp_sint32_t   sFlag = aFlags;

    sFlag = 0; /* erase warning */

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_UNIX_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL || sSock->mSockFd <= 0, INVALID_HANDLE );
    _IF_RAISE( aMsg == NULL, INVALID_ARG );
    _IF_RAISE( aLen > sSock->mOption.mMaxMsgSize, INVALID_ARG );

    /*
     * 맨앞의 4 byte 먼저 보냄 (Length)
     */
    _IF_RAISE( (sRet = sciBlockSend(sSock,
                                         (void *)&aLen,
                                         sizeof(mvp_sint32_t),
                                         0))
                    != (mvp_sint32_t)sizeof(mvp_sint32_t), SEND_ERROR );

    /* Data Body Send */
    _IF_RAISE( (sRet = sciBlockSend( sSock,
                                          aMsg,
                                          aLen,
                                          0 ))
                    != (mvp_sint32_t)aLen, SEND_ERROR );

    return aLen;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( SEND_ERROR )
    {
        DEBUG(__f, "send fail[ret:%d] : %s", sRet, strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciUnixUnicastSendTo
 *
 * Description :
 *   Tcp 에서는 지원되지 않는다.
 *
 * Argument :
 *
 * Return :
 *   무조건 RC_FAILURE
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciUnixUnicastSendTo( PHSOCKET       aGenHandle,
                               const void   * aMsg,
                               mvp_size_t     aLen,
                               mvp_sint32_t   aFlags,
                               const struct sockaddr * aTo,
                               socklen_t      aToLen )
{
    errno = EOPNOTSUPP;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciUnixUnicastGetSockOpt
 *
 * Description :
 *   Tcp 에서 getsockopt 역할 수행
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *   @aLevel     : Option Level
 *   @aOptName   : Option Name
 *   @aValue     : Option Value
 *   @aLength    : Option Value Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciUnixUnicastGetSockOpt( PHSOCKET       aGenHandle,
                                   mvp_sint32_t   aLevel,
                                   mvp_sint32_t   aOptName,
                                   void         * aOptVal,
                                   socklen_t    * aOptLen )
{
    PH_UNIX_UNI               sSock = NULL;
    SocketHandle            * sGenHandle;
    struct sciSocketOption  * sOptAll;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_UNIX_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL || sSock->mSockFd <= 0, INVALID_HANDLE );

    switch( aLevel )
    {
        case SOL_COMMON :
            switch( aOptName )
            {
                case SO_RECV_CB :
                    *aOptLen = sizeof(sSock->mRecvCBFunc);
                    if( aOptVal != NULL )
                    {
                        *((sciRecvCallBack **)aOptVal) = sSock->mRecvCBFunc;
                    }
                    break;
                case SO_RECV_PARAM :
                    *aOptLen = sizeof(sSock->mRecvCBParam);
                    if( aOptVal != NULL )
                    {
                        *((void **)aOptVal) = sSock->mRecvCBParam;
                    }
                    break;
                case SO_EVENT_CB :
                    *aOptLen = sizeof(sSock->mEventCBFunc);
                    if( aOptVal != NULL )
                    {
                        *((sciEventCallBack **)aOptVal) = sSock->mEventCBFunc;
                    }
                    break;
                case SO_EVENT_PARAM :
                    *aOptLen = sizeof(sSock->mEventCBParam);
                    if( aOptVal != NULL )
                    {
                        *((void **)aOptVal) = sSock->mEventCBParam;
                    }
                    break;
                case SO_POLLING_TYPE :
                    *aOptLen = sizeof(sSock->mOption.mPollingType);
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mPollingType;
                    }
                    break;
                case SO_SYNC_RECV :
                    *aOptLen = sizeof(sSock->mOption.mSyncRecvF);
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mSyncRecvF;
                    }
                    break;
                case SO_RECV_POLL :
                    *aOptLen = sizeof(sSock->mOption.mRecvPollCount);
                    if( aOptVal != NULL )
                    {
                        *((mvp_sint32_t *)aOptVal) = sSock->mOption.mRecvPollCount;
                    }
                    break;
                case SO_OPT_ALL :
                    if( aOptVal != NULL )
                    {
                        sOptAll = (struct sciSocketOption *)aOptVal;

                        sOptAll->common.recv_callback_func   = sSock->mRecvCBFunc;
                        sOptAll->common.recv_callback_param  = sSock->mRecvCBParam;
                        sOptAll->common.event_callback_func  = sSock->mEventCBFunc;
                        sOptAll->common.event_callback_param = sSock->mEventCBParam;

                        sOptAll->common.polling_type = sSock->mOption.mPollingType;
                        sOptAll->common.sync_recv_f  = sSock->mOption.mSyncRecvF;
                        memcpy(&sOptAll->common.sync_recv_timeout, &sSock->mOption.mSyncRecvTimeout, sizeof(struct timeval));
                        sOptAll->common.recv_poll_count   = sSock->mOption.mRecvPollCount;
                    }
                    *aOptLen = sizeof(struct sciSocketOption);
                    break;
                default :
                    _RAISE( INVALID_ARG );
                    break;
            }
            break;
        case SOL_UNIX :
            _RAISE( INVALID_ARG );
            break;
        default :
            return getsockopt( sSock->mSockFd, aLevel, aOptName, aOptVal, aOptLen );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciUnixUnicastSetSockOpt
 *
 * Description :
 *   Tcp 에서 setsockopt 역할 수행
 *
 * Argument :
 *   @aGenHandle : general socket handle
 *   @aLevel     : Option Level
 *   @aOptName   : Option Name
 *   @aValue     : Option Value
 *   @aLength    : Option Value Length
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciUnixUnicastSetSockOpt( PHSOCKET       aGenHandle,
                                   mvp_sint32_t   aLevel,
                                   mvp_sint32_t   aOptName,
                                   const void   * aOptVal,
                                   socklen_t      aOptLen )
{
    PH_UNIX_UNI               sSock = NULL;
    SocketHandle            * sGenHandle;
    struct sciSocketOption  * sOptAll;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock = (PH_UNIX_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL || sSock->mSockFd <= 0, INVALID_HANDLE );

    switch( aLevel )
    {
        case SOL_COMMON :
            switch( aOptName )
            {
                case SO_RECV_CB :
                    sSock->mRecvCBFunc = (sciRecvCallBack *)aOptVal;
                    break;
                case SO_RECV_PARAM :
                    sSock->mRecvCBParam = (void *)aOptVal;
                    break;
                case SO_EVENT_CB :
                    sSock->mEventCBFunc = (sciEventCallBack *)aOptVal;
                    break;
                case SO_EVENT_PARAM :
                    sSock->mEventCBParam = (void *)aOptVal;
                    break;
                case SO_POLLING_TYPE :
                    sSock->mOption.mPollingType = *(mvp_sint32_t *)aOptVal;
                    DEBUG(__f, "polling type[%d] fd[%d]", sSock->mOption.mPollingType, sSock->mSockFd);
                    break;
                case SO_SYNC_RECV :
                    /*
                     * sync recv mode 에서는 recv thread 가 별도로 떠있으면 안되므로
                     * 강제로 cancle 해버려야 함.
                     */
                    if( sSock->mRecvThr != (pthread_t)0 )
                    {
                        if( pthread_kill( sSock->mRecvThr, 0 ) == 0 )
                        {
                            pthread_cancel( sSock->mRecvThr );
                        }
                        pthread_join( sSock->mRecvThr, NULL );
                    }
                    sSock->mOption.mSyncRecvF = 1;
                    sSock->mOption.mSyncRecvTimeout = ((struct timeval *)aOptVal)->tv_sec;
                    DEBUG(__f, "set sync recv mode. sec[%d] fd[%d]", sSock->mOption.mSyncRecvTimeout, sSock->mSockFd);
                    break;
                case SO_RECV_POLL :
                    _IF_RAISE( aOptVal == NULL
                            || aOptLen != sizeof(mvp_sint32_t), INVALID_ARG );
                    sSock->mOption.mRecvPollCount = *((mvp_sint32_t *) aOptVal);
                    DEBUG(__f, "set recvpoll count[%d] fd[%d]", sSock->mOption.mRecvPollCount, sSock->mSockFd);
                    break;
                case SO_OPT_ALL :
                    sOptAll = (struct sciSocketOption *)aOptVal;

                    sSock->mRecvCBFunc  = sOptAll->common.recv_callback_func;
                    sSock->mRecvCBParam = sOptAll->common.recv_callback_param;

                    sSock->mEventCBFunc  = sOptAll->common.event_callback_func;
                    sSock->mEventCBParam = sOptAll->common.event_callback_param;

                    sSock->mOption.mPollingType = sOptAll->common.polling_type;

                    if( sOptAll->common.sync_recv_f == 1 && sSock->mOption.mSyncRecvF == 0 )
                    {
                        if( sSock->mRecvThr != (pthread_t)0 )
                        {
                            if( pthread_kill( sSock->mRecvThr, 0 ) == 0 )
                            {
                                pthread_cancel( sSock->mRecvThr );
                            }
                            pthread_join( sSock->mRecvThr, NULL );
                        }
                        sSock->mOption.mSyncRecvF = 1;
                        sSock->mOption.mSyncRecvTimeout = sOptAll->common.sync_recv_timeout.tv_sec;
                    }

                    sSock->mOption.mRecvPollCount = sOptAll->common.recv_poll_count; 
                    break;
                default :
                    _RAISE( INVALID_ARG );
                    break;
            }
            break;
        case SOL_UNIX :
            _RAISE( INVALID_ARG );
            break;
        default :
            return setsockopt( sSock->mSockFd, aLevel, aOptName, aOptVal, aOptLen );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciUnixUnicastClose
 *
 * Description :
 *   Socket Close
 *
 * Argument :
 *   @aGenHandle    : general socket handle
 *
 * Return :
 *   0 : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciUnixUnicastClose( PHSOCKET   aGenHandle )
{
    PH_UNIX_UNI    sSock = NULL;
    SocketHandle * sGenHandle;
    mvp_rc_t       sRC   = 0;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;
    sSock = (PH_UNIX_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    sSock->mClosed = 1;

    if( sSock->mRecvThr != (pthread_t)0 )
    {
        if( pthread_kill( sSock->mRecvThr, 0 ) == 0 )
        {
            pthread_cancel( sSock->mRecvThr );
        }
        pthread_join( sSock->mRecvThr, NULL );
    }

    if( sSock->mSockFd > 0 )
    {
        sRC = close( sSock->mSockFd );
        _IF_RAISE( sRC != 0, ETC_ERROR );
        DEBUG(__f, "socket close ok. fd[%d]", sSock->mSockFd);
    }

    if( sSock->mOption.mPollingType == SCI_POLLING_EPOLL )
    {
        close( sSock->mEpollFd );
        sSock->mEpollFd = 0;
    }

    if( sSock != NULL )
    {
        free( sSock );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciUnixUnicastRecv
 *
 * Description :
 *   block mode 로 데이터를 수신하는 함수
 *
 * Argument :
 *   @aGenHandle  : sock multicast general handle
 *   @aBuf        : 받을 Data Buffer
 *   @aLen        : 받을 Data Length
 *   @aFlag       : 현재 미사용
 *
 * Return :
 *   Recv Length : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
mvp_rc_t sciUnixUnicastRecv( PHSOCKET         aGenHandle,
                             void           * aBuf,
                             mvp_size_t       aLen,
                             mvp_sint32_t     aFlags )
{
    mvp_rc_t       sRet      = 0;
    PH_UNIX_UNI    sSock     = NULL;
    mvp_size_t     sSizeHead = 0;
    mvp_size_t     sRemain   = 0;
    mvp_size_t     sOffset   = 0;
    mvp_char_t     sLocalBuf[MTU_SIZE];
    mvp_sint64_t   sPoll      = 0;
    mvp_sint64_t   sRate      = 0;
    fd_set         sFdSet;
    sciSleep       sXS;
    SocketHandle * sGenHandle;
    struct timeval sTimeout;

    _IF_RAISE( aGenHandle == NULL, INVALID_HANDLE );

    sGenHandle = (SocketHandle *)aGenHandle;

    sSock    = (PH_UNIX_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    _IF_RAISE( sSock->mOption.mSyncRecvF == 0, NO_SYNC_RECV_MODE );

    if( sSock->mOption.mRecvPollCount > 1 )
    {
        sRate = 1000000 / sSock->mOption.mRecvPollCount;
    }
    else
    {
        sRate = 0;
    }

    sSizeHead = sizeof(mvp_sint32_t);
    sRemain = aLen + sSizeHead;
    sOffset = 0;

RETRY:
    sRet = recv( sSock->mSockFd, sLocalBuf + sOffset, sRemain, 0 );
    if( sRet == 0 )
    {
        _RAISE( DISCONNECTED );
    }
    else if( sRet < 0 )
    {
        if( errno == EWOULDBLOCK )
        {
            sPoll++;

            if( sSock->mOption.mRecvPollCount == -1 )
            {
                /*
                 * 1 번 polling 이 대충 100 ns 정도라고 예상하고
                 * 사용자가 준 시간(초) * 3,000,000 를 곱해서
                 * 이 횟수가 넘으면 timeout 으로 간주한다.
                 * 사용자의 recv timeout 을 무시하지 않기위한 궁여지책.
                 */
                if( sPoll > (sSock->mOption.mSyncRecvTimeout * 3000000) )
                {
                    _RAISE( TIMEOUT );
                }
                else
                {
                    goto RETRY;
                }
            }

            /* spin wait */
            if( sPoll < sSock->mOption.mRecvPollCount )
            {
                if( sRate != 0 )
                {
                    sciSleepNano( &sXS, sRate );
                }
                else
                {
                }
                goto RETRY;
            }
            else
            {
                sPoll = 0;

                while(1)
                {
                    /*
                     * mRecvPollCount 만큼 빨리 polling 해보고 
                     * 없으면 사용자가 지정한 시간만큼 select 에서 대기한다.
                     * packet 이 계속 없으면 timeout 으로 에러 리턴한다.
                     */
                    sTimeout.tv_sec  = sSock->mOption.mSyncRecvTimeout;
                    sTimeout.tv_usec = 0;

                    FD_ZERO( &sFdSet );
                    FD_SET( sSock->mSockFd, &sFdSet );

                    sRet = select( sSock->mSockFd+1, &sFdSet, NULL, NULL, &sTimeout );

                    _IF_RAISE( sRet < 0, SELECT_ERROR );
                    _IF_RAISE( sRet == 0, TIMEOUT );

                    if( sRet < 0 )
                    {
                        if( errno == EWOULDBLOCK )
                        {
                            continue;
                        }
                        else
                        {
                            _RAISE( DISCONNECTED );
                        }
                    }
                    else
                    {
                        /* 실제로 데이터가 도착했으므로 recv 로 */
                        goto RETRY;
                    }
                }
            }
        }
        else
        {
            _RAISE( DISCONNECTED );
        }
    }
    else
    {
        /* 일단 데이터를 받으면 polling cnt 초기화 */
        sPoll = 0;

        sOffset += sRet;
        if( sRet == (mvp_sint32_t)sRemain )
        {
            memcpy( aBuf, sLocalBuf + sizeof(mvp_sint32_t), aLen );
            goto DONE;
        }
        else
        {
            sRemain -= sRet;

            goto RETRY;
        }
    }

DONE:

    return sOffset-sizeof(mvp_sint32_t);

    _EXCEPTION( INVALID_HANDLE )
    {
        DEBUG(__f, "invalid socket handle[%d]", 0 );
        errno = EBADF;
    }
    _EXCEPTION( NO_SYNC_RECV_MODE )
    {
        DEBUG(__f, "socket is not syncrecv mode. SO_SYNC_RECV for sciRecv. fd[%d]", sSock->mSockFd );
        errno = EAGAIN;
    }
    _EXCEPTION( SELECT_ERROR )
    {
        DEBUG(__f, "select fail[%d] : %s", sSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( DISCONNECTED )
    {
        DEBUG(__f, "recv disconnected[%d]", sSock->mSockFd);

        if( sSock != NULL && sSock->mClosed == 0 )
        {
            /* sync recv mode 가 아닐 때는 recv thread 가 처리 */
            if( sSock->mOption.mSyncRecvF == 1 && sSock->mEventCBFunc != NULL )
            {
                sSock->mEventCBFunc( SCI_EVENT_DISCONNECTED, sSock->mEventCBParam );
            }
        }
    }
    _EXCEPTION( TIMEOUT )
    {
        errno = EAGAIN;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


static mvp_rc_t sciSetBlock( PH_UNIX_UNI      aSock,
                             struct timeval * aTimeout )
{
    mvp_rc_t      sRC   = 0;
    mvp_sint32_t  sFlag = 0;

    _IF_RAISE( aSock == NULL, INVALID_HANDLE );

    _IF_RAISE( (sFlag = fcntl( aSock->mSockFd,
                                    F_GETFL,
                                    0 ))
                    < 0, GET_FCNTL_ERROR );

    _IF_RAISE( (sRC = fcntl( aSock->mSockFd,
                                  F_SETFL,
                                  sFlag & ~O_NONBLOCK ))
                    < 0, SET_FCNTL_ERROR );

    _IF_RAISE( (sRC = setsockopt( aSock->mSockFd,
                                       SOL_SOCKET,
                                       SO_RCVTIMEO,
                                       (void*)aTimeout,
                                       sizeof(struct timeval)))
                    != 0, SET_SOCKOPT_FAIL );

    DEBUG(__f, "set block mode. fd[%d]", aSock->mSockFd);

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( GET_FCNTL_ERROR )
    {
        DEBUG(__f, "get fcntl fail[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( SET_FCNTL_ERROR )
    {
        DEBUG(__f, "set fcntl fail[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( SET_SOCKOPT_FAIL )
    {
        DEBUG(__f, "setsockopt fail. fd[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciBlockSend
 *
 * Description :
 *   요청한 data 를 모두 전송할 때까지 리턴하지 않는다.
 *
 * Argument :
 *   @aGenHandle : Sock Unicast General Handle
 *   @aBuf       : 보낼 Data Buffer
 *   @aLen       : 보낼 Data Length
 *   @aFlag      : 현재 미사용
 *
 * Return :
 *   Send Length : 성공, -1 : 실패
 *
 * How To Use :
 ******************************************************************************/
static mvp_size_t sciBlockSend( PH_UNIX_UNI       aSock,
                                const void      * aBuf,
                                mvp_size_t        aLen,
                                mvp_sint32_t      aFlag )
{
    mvp_sint32_t  sRet     = 0;
    mvp_sint32_t  sSendLen = 0;
    mvp_sint32_t  sFlag    = aFlag;

    sFlag = 0;

    _IF_RAISE( aSock == NULL || aSock->mSockFd <= 0, INVALID_HANDLE );
    _IF_RAISE( aBuf  == NULL || aLen <= 0, INVALID_ARG );

    while( ! aSock->mClosed )
    {
        sRet = send( aSock->mSockFd, (char *)aBuf + sSendLen, aLen - sSendLen, 0 );
        if( sRet == 0 )
        {
            _RAISE( DISCONNECTED );
        }
        else if( sRet < 0 )
        {
            if( errno == EWOULDBLOCK )
            {
                continue;
            }
            else
            {
                _RAISE( DISCONNECTED );
            }
        }
        else
        {
            sSendLen += sRet;
            if( sSendLen == (mvp_sint32_t)aLen )
            {
                /* SEND COMPLETE */
                break;
            }
        }
    }

    _IF_RAISE( sSendLen != (mvp_sint32_t)aLen, DISCONNECTED );

    return aLen;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( DISCONNECTED )
    {
        errno = EINVAL;
        DEBUG(__f, "send. disconnected[%d]", aSock->mSockFd);

        if( aSock != NULL && aSock->mClosed == 0 )
        {
            /* sync recv mode 가 아닐 때는 recv thread 가 처리 */
            if( aSock->mOption.mSyncRecvF == 1 && aSock->mEventCBFunc != NULL )
            {
                aSock->mEventCBFunc( SCI_EVENT_DISCONNECTED, aSock->mEventCBParam );
            }
        }
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


/*******************************************************************************
 * Name : sciRecvThrFunc
 *
 * Description :
 *   Data 를 recv 하여 처리하는 함수
 *
 * Argument :
 *   @aArg  : thread argument
 *
 * Return :
 *   N/A
 *
 * How To Use :
 ******************************************************************************/
static void * sciRecvThrFunc( void * aArg )
{
    SocketHandle      * sGenHandle = (SocketHandle *)aArg;
    mvp_rc_t            sRet     = 0;
    PH_UNIX_UNI         sSock    = NULL;
    mvp_char_t        * sBuf     = NULL;
    mvp_size_t          sRecvLen = 0;
    mvp_size_t          sBodyLen = 0;
    mvp_size_t          sNextLen = 0;
    mvp_sint32_t        sSockFd  = 0;
    mvp_sint64_t        sPoll    = 0;
    fd_set              sFdSet;
    struct timeval      sTimeout;
    mvp_sint64_t        sRate    = 0;
    sciSleep            sXS;


    _IF_RAISE( sGenHandle == NULL, INVALID_HANDLE );

    DEBUG(__f, "receive thread start. thrid[%ld]", pthread_self());

    sSock    = (PH_UNIX_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    sBuf = (mvp_char_t *)malloc(sSock->mOption.mMaxMsgSize);
    _IF_RAISE( sBuf == NULL, LACK_OF_MEMORY );

    sSockFd = sSock->mSockFd;

    if( sSock->mOption.mRecvPollCount > 1 )
    {
        sRate = 1000000 / sSock->mOption.mRecvPollCount;
    }
    else
    {
        sRate = 0;
    }

    sPoll = 0;

    sRecvLen = 0;
    sBodyLen = 0;
    sNextLen = sizeof(mvp_sint32_t);

    while( sSock->mClosed == 0 )
    {
        sRet = recv( sSock->mSockFd, sBuf + sRecvLen, sNextLen - sRecvLen, 0 );
        if( sRet == 0 )
        {
            _RAISE( DISCONNECTED );
        }
        else if( sRet < 0 )
        {
            if( errno == EWOULDBLOCK )
            {
                sPoll++;

                /* non blocking + busy wait 일 때는 계속 recv 만 call */
                if( sSock->mOption.mRecvPollCount == -1 )
                {
                    continue;
                }

                /* spin wait */
                if( sPoll < sSock->mOption.mRecvPollCount )
                {
                    if( sRate != 0 )
                    {
                        sciSleepNano( &sXS, sRate );
                        continue;
                    }
                    else
                    {
                    }
                }
                else
                {
                    sPoll = 0;

                    /* wait infinitely until data receives */
                    sTimeout.tv_sec  = 999999999;
                    sTimeout.tv_usec = 0;

                    FD_ZERO( &sFdSet );
                    FD_SET( sSock->mSockFd, &sFdSet );

                    _IF_RAISE( (sRet = select( sSock->mSockFd+1,
                                                    &sFdSet,
                                                    NULL,
                                                    NULL,
                                                    &sTimeout ))
                                    < 0, SELECT_ERROR );

                    if( sRet == 0 )
                    {
                        continue;
                    }
                    else if( sRet < 0 )
                    {
                        if( errno == EWOULDBLOCK )
                        {
                            continue;
                        }
                        else
                        {
                            _RAISE( DISCONNECTED );
                        }
                    }
                    else
                    {
                        /* 실제로 데이터가 도착했으므로 recv 로 */
                        continue;
                    }
                }
            }
            else
            {
                _RAISE( DISCONNECTED );
            }
        }
        else
        {
            sPoll = 0;

            /* recv success */
            sRecvLen += sRet;
            if( sBodyLen == 0 && sRecvLen == sizeof(mvp_sint32_t))
            {
                memcpy( &sBodyLen, sBuf, sizeof(mvp_sint32_t));
                sNextLen += sBodyLen;
                continue;
            }
            else if( sBodyLen > 0 && sRecvLen == sNextLen )
            {
                /* Receive Done */
                if( sSock->mRecvCBFunc != NULL && sSock->mClosed != 1 )
                {
                    /* Call Recv Callback Function */
                    sSock->mRecvCBFunc( sBuf + sizeof(mvp_sint32_t),
                                        sRecvLen - sizeof(mvp_sint32_t),
                                        sSock->mRecvCBParam );
                }

                sRecvLen = 0;
                sBodyLen = 0;
                sNextLen = sizeof(mvp_sint32_t);

                continue;
            }
        }
    }

    _IF_RAISE( sSock->mClosed == 1, CLOSED );

    if( sBuf != NULL )
    {
        free( sBuf );
    }

    return sSock;

    _EXCEPTION( INVALID_HANDLE )
    {
        DEBUG(__f, "invalid socket handle[%d]", 0 );
        errno = EBADF;
    }
    _EXCEPTION( LACK_OF_MEMORY )
    {
        sSock->mRecvReady = -1;
        errno = ENOMEM;
    }
    _EXCEPTION( SELECT_ERROR )
    {
        DEBUG(__f, "select fail[%d] : %s", sSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( DISCONNECTED )
    {
        DEBUG(__f, "disconnected[%d]", sSock->mSockFd);
        if( sSock != NULL && sSock->mClosed == 0 )
        {
            sciStartEventThread( sSock->mGenHandle, sSock->mEventCBFunc,
                                 sSock->mEventCBParam, SCI_EVENT_DISCONNECTED );
        }
    }
    _EXCEPTION( CLOSED )
    {
        DEBUG(__f, "socket closed[fd:%d]", sSockFd );
    }
    _EXCEPTION( EPOLL_WAIT_ERROR )
    {
        DEBUG(__f, "epoll_wait failed[fd:%d]", sSockFd );
    }
    _EXCEPTION_END;

    if( sBuf != NULL )
    {
        free( sBuf );
    }

    return NULL;
}

/*
static void * sciRecvThrFunc( void * aArg )
{
    PHSOCKET            sGenHandle = (PHSOCKET)aArg;
    mvp_rc_t            sRet     = 0;
    PH_UNIX_UNI         sSock    = NULL;
    mvp_char_t        * sBuf     = NULL;
    mvp_size_t          sRecvLen = 0;
    mvp_size_t          sBodyLen = 0;
    mvp_size_t          sNextLen = 0;
    mvp_sint32_t        sSockFd  = 0;
    fd_set              sFdSet;
    mvp_sint32_t        sMsTimeout;
    struct timeval      sTimeout;
    struct epoll_event  sEventPoll;
    struct epoll_event  sEvent[10];


    _IF_RAISE( sGenHandle == NULL, INVALID_HANDLE );

    DEBUG(__f, "receive thread start. thrid[%ld]", pthread_self());

    sSock    = (PH_UNIX_UNI)sGenHandle->mSubHandle;
    _IF_RAISE( sSock == NULL, INVALID_HANDLE );

    sBuf = (mvp_char_t *)malloc(sSock->mOption.mMaxMsgSize);
    _IF_RAISE( sBuf == NULL, LACK_OF_MEMORY );

    sSockFd = sSock->mSockFd;

    sMsTimeout = 1000;

    sRecvLen = 0;
    sBodyLen = 0;
    sNextLen = sizeof(mvp_sint32_t);

    sSock->mEpollFd = 0;

RETRY :
    if( sSock->mOption.mPollingType == SCI_POLLING_EPOLL )
    {
        _IF_RAISE( sSock->mClosed == 1, CLOSED );

        if( sSock->mEpollFd == 0 )
        {
            sSock->mEpollFd = epoll_create(1);
        }

        sEventPoll.events  = EPOLLIN;
        sEventPoll.data.fd = sSock->mSockFd;

        epoll_ctl(sSock->mEpollFd, EPOLL_CTL_ADD, sSock->mSockFd, &sEventPoll );

        while( ! sSock->mClosed )
        {
            sRet = epoll_wait( sSock->mEpollFd, sEvent, 1, sMsTimeout );
            if( sRet > 0 )
            {
                break;
            }
            else if( sRet == 0 || ( sRet == -1 && errno == 4 ) )
            {
                continue; // timeout
            }
            else
            {
                _RAISE( EPOLL_WAIT_ERROR );
            }
        }

        epoll_ctl(sSock->mEpollFd, EPOLL_CTL_DEL, sSock->mSockFd, &sEventPoll );
    }
    else
    {
        _IF_RAISE( sSock->mClosed == 1, CLOSED );

        sTimeout.tv_sec = 0;
        sTimeout.tv_usec = 5000;

        FD_ZERO(&sFdSet);
        FD_SET( sSock->mSockFd, &sFdSet );

        sRet = select( sSock->mSockFd+1, &sFdSet, NULL, NULL, &sTimeout );
        _IF_RAISE( sRet < 0, SELECT_ERROR );
        if( sRet == 0 )
        {
            goto RETRY;
        }
    }

    sRet = recv( sSock->mSockFd, sBuf + sRecvLen, sNextLen - sRecvLen, 0 );
    if( sRet == 0 )
    {
        _RAISE( DISCONNECTED );
    }
    else if( sRet < 0 )
    {
        if( errno == EWOULDBLOCK )
        {
            goto RETRY;
        }
        else
        {
            _RAISE( DISCONNECTED );
        }
    }
    else
    {
        // recv success
        sRecvLen += sRet;
        if( sBodyLen == 0 && sRecvLen == sizeof(mvp_sint32_t))
        {
            memcpy( &sBodyLen, sBuf, sizeof(mvp_sint32_t));
            sNextLen += sBodyLen;
            goto RETRY;
        }
        else if( sBodyLen > 0 && sRecvLen == sNextLen )
        {
            // Receive Done
            if( sSock->mRecvCBFunc != NULL && sSock->mClosed != 1 )
            {
                // Call Recv Callback Function
                sSock->mRecvCBFunc( sBuf + sizeof(mvp_sint32_t),
                                      sRecvLen - sizeof(mvp_sint32_t),
                                      sSock->mRecvCBParam );
            }

            sRecvLen = 0;
            sBodyLen = 0;
            sNextLen = sizeof(mvp_sint32_t);

            goto RETRY;
        }
    }

    if( sBuf != NULL )
    {
        free( sBuf );
    }

    if( sSock != NULL )
    {
        sSock->mRecvThr = (pthread_t)0;
    }

    return sSock;

    _EXCEPTION( INVALID_HANDLE )
    {
        DEBUG(__f, "invalid socket handle[%d]", 0 );
        errno = EBADF;
    }
    _EXCEPTION( LACK_OF_MEMORY )
    {
        sSock->mRecvReady = -1;
        errno = ENOMEM;
    }
    _EXCEPTION( SELECT_ERROR )
    {
        DEBUG(__f, "select fail[%d] : %s", sSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( DISCONNECTED )
    {
        DEBUG(__f, "disconnected[%d]", sSock->mSockFd);
        if( sSock != NULL && sSock->mClosed == 0 )
        {
            sciStartEventThread( sSock->mGenHandle, sSock->mEventCBFunc,
                                 sSock->mEventCBParam, SCI_EVENT_DISCONNECTED );
        }
    }
    _EXCEPTION( CLOSED )
    {
        DEBUG(__f, "socket closed[fd:%d]", sSockFd );
    }
    _EXCEPTION( EPOLL_WAIT_ERROR )
    {
        DEBUG(__f, "epoll_wait failed[fd:%d]", sSockFd );
    }
    _EXCEPTION_END;

    if( sBuf != NULL )
    {
        free( sBuf );
    }

    if( sSock != NULL )
    {
        sSock->mRecvThr = (pthread_t)0;
    }

    return NULL;
}
*/

static mvp_rc_t sciSetNonBlock( PH_UNIX_UNI  aSock )
{
    mvp_rc_t      sRC   = 0;
    mvp_sint32_t  sFlag = 0;

    _IF_RAISE( aSock == NULL, INVALID_HANDLE );

    _IF_RAISE( (sFlag = fcntl( aSock->mSockFd,
                                    F_GETFL,
                                    0 ))
                    < 0, GET_FCNTL_ERROR );

    _IF_RAISE( (sRC = fcntl( aSock->mSockFd,
                                  F_SETFL,
                                  sFlag|O_NONBLOCK ))
                    < 0, SET_FCNTL_ERROR );

    DEBUG(__f, "set nonblock mode. fd[%d]", aSock->mSockFd);

    return RC_SUCCESS;

    _EXCEPTION( INVALID_HANDLE )
    {
        errno = EBADF;
    }
    _EXCEPTION( GET_FCNTL_ERROR )
    {
        DEBUG(__f, "get fcntl fail[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION( SET_FCNTL_ERROR )
    {
        DEBUG(__f, "set fcntl fail[%d] : %s", aSock->mSockFd, strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}
