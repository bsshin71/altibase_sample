/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   Utility Function
 ******************************************************************************/
#include <sciCommon.h>

/* temporary for demo debug */
mvp_sint32_t   __f = 1;


mvp_rc_t sciSleepMicro(long usec)
{
    struct timeval    sTimeout;

    sTimeout.tv_sec  = usec / 1000000L;
    sTimeout.tv_usec = usec % 1000000L;

    return select( 0, 0, 0, 0,(struct timeval *)&sTimeout);
}


mvp_rc_t sciSetNonBlock( mvp_sint32_t  aFd )
{
    mvp_rc_t      sRC   = 0;
    mvp_sint32_t  sFlag = 0;

    sFlag = fcntl(aFd, F_GETFL, 0);
    _IF_RAISE( sFlag < 0, GET_FCNTL_ERROR );

    sRC = fcntl(aFd, F_SETFL, sFlag|O_NONBLOCK );
    _IF_RAISE( sRC < 0, SET_FCNTL_ERROR );

    return RC_SUCCESS;

    _EXCEPTION( GET_FCNTL_ERROR )
    {
        DEBUG(__f, "get fcntl fail[%d] : %s", aFd, strerror(errno));
    }
    _EXCEPTION( SET_FCNTL_ERROR )
    {
        DEBUG(__f, "set fcntl fail[%d] : %s", aFd, strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciShmAttach( sciShmInfo       * aShm,
                       mvp_sint32_t     * aFirst )
{
    mvp_sint32_t  sMode = umask(0x00);
    mvp_key_t     sShmKey;
    mvp_char_t    sPath[128];

    _IF_RAISE( aShm == NULL, INVALID_ARG );

    aShm->mShmId = -1;
    aShm->mData = NULL;

    snprintf(sPath, sizeof(sPath), "%s", aShm->mPath );

    if( creat( sPath, O_CREAT | O_EXCL ) == -1 )
    {
        MVP_TEST( creat( sPath, O_CREAT ) != -1 );
    }

    sShmKey = ftok( sPath, 'M' );
    _IF_RAISE( sShmKey <= 0, ERROR );

    aShm->mShmId = shmget( sShmKey, aShm->mSize, 0666 | IPC_CREAT | IPC_EXCL );
    if( aShm->mShmId < 0 )
    {
        aShm->mShmId = shmget( sShmKey, aShm->mSize, 0666 | IPC_EXCL );
    }
    else
    {
        *aFirst = 1;
    }
    DEBUG(__f, "shmid[%d] size[%ld] path[%s]", aShm->mShmId, aShm->mSize, sPath);

    _IF_RAISE( aShm->mShmId <= 0, ERROR );
    aShm->mData = shmat( aShm->mShmId, NULL, 0 );
    _IF_RAISE( aShm->mData == (void *)-1, ERROR );

    (void) umask( sMode );

    return RC_SUCCESS;

    _EXCEPTION( INVALID_ARG );
    {
        errno = EINVAL;
    }
    _EXCEPTION( ERROR );
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciShmDettach( sciShmInfo    * aShm )
{
    mvp_sint32_t    sRet = 0;
    struct shmid_ds sStat;
    mvp_char_t      sPath[128];

    _IF_RAISE( aShm == NULL, INVALID_ARG );

    if( aShm->mData != NULL )
    {
        sRet = shmdt( aShm->mData );
        _IF_RAISE( sRet != 0, ERROR );
    }

    sRet = shmctl( aShm->mShmId, IPC_STAT, &sStat );
    _IF_RAISE( sRet != 0, ERROR );

    if( sStat.shm_nattch == 0 )
    {
        shmctl( aShm->mShmId, IPC_RMID, NULL );
    }

    snprintf(sPath, 128, "/tmp/%s_ft", aShm->mPath );
    sRet = unlink( sPath );
    if( sRet == -1 )
    {
        _IF_RAISE( errno == ENOENT, ERROR );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciStartEventThread( PHSOCKET           aGenSocket,
                              sciEventCallBack * aCBFunc,
                              void             * aUserData,
                              mvp_sint32_t       aEvent )
{
    mvp_sint32_t     sRC  = 0;
    pthread_attr_t   sThrAttr;
    sciEventStruct * sCBEvent = NULL;

    if( aCBFunc == NULL )
    {
        return RC_SUCCESS;
    }

    sCBEvent = (sciEventStruct *)malloc(sizeof(sciEventStruct));
    _IF_RAISE( sCBEvent == NULL, LACK_OF_MEMORY );

    sCBEvent->mCBFunc  = aCBFunc;
    sCBEvent->mCBParam = aUserData;
    sCBEvent->mEvent   = aEvent;

    //sRC = pthread_attr_setdetachstate(&sThrAttr, PTHREAD_CREATE_DETACHED);
    //_IF_RAISE( (errno = sRC) != 0, THREAD_SET_DETACH_ERROR );

    sRC = pthread_create( &sCBEvent->mId, NULL, sciEventCallBackThread, sCBEvent );
    _IF_RAISE( (errno = sRC) != 0, EVENT_THREAD_CREATE_ERROR );

    /*
     * 이상하게 detach attr 로 thread 를 생성하면 생성이 실패함.
     * 할 수 없이 joinable 로...
     */
    sRC = pthread_join( sCBEvent->mId, NULL );
    _IF_RAISE( (errno = sRC) != 0, EVENT_THREAD_JOIN_ERROR );

    return RC_SUCCESS;

    _EXCEPTION( LACK_OF_MEMORY )
    {
        errno = ENOMEM;
    }
    _EXCEPTION( THREAD_SET_DETACH_ERROR )
    {
        DEBUG(__f, "event thread detach fail : %s", strerror(errno));
    }
    _EXCEPTION( EVENT_THREAD_CREATE_ERROR )
    {
        DEBUG(__f, "event thread create fail : %s", strerror(errno));
    }
    _EXCEPTION( EVENT_THREAD_JOIN_ERROR )
    {
        DEBUG(__f, "event thread join fail : %s", strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


void * sciEventCallBackThread( void * aParam )
{
    sciEventStruct    sEventSt;
    sciEventStruct  * sCBEvent = &sEventSt;

    memcpy( &sEventSt, aParam, sizeof(sEventSt) );
    if( aParam != NULL )
    {
        free( aParam );
    }
    if( sCBEvent->mCBFunc != NULL )
    {
        sCBEvent->mCBFunc( sCBEvent->mEvent, sCBEvent->mCBParam );
    }
    return NULL;
}


void Elapsed( mvp_char_t      * aFunc_name,
              struct timespec   aStart,
              struct timespec   aEnd,
              mvp_sint32_t      aTest_count )
{
    mvp_sint64_t   sTotal;
    mvp_double_t   sOne;

    sTotal = (aEnd.tv_sec - aStart.tv_sec) * 1000000L * 1000 + (aEnd.tv_nsec - aStart.tv_nsec);
    sOne = sTotal / aTest_count;

    if( (aEnd.tv_sec - aStart.tv_sec) < 0 )
    {
        printf("invalid elapse time\n");
        printf("[%12s] total : %ld nano, avg : %.9f\n", aFunc_name, sTotal, sOne);
        return;
    }
    printf("[%12s] total : %ld nano, avg : %.9f\n", aFunc_name, sTotal, sOne);
}
