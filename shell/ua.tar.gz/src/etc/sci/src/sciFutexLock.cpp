/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   Futex 를 이용하여 Lock 구현
 ******************************************************************************/
#include <sciCommon.h>

#ifdef USE_POSIX_LOCK
/*
 * Posix Mutex 를 사용하는 경우는 별도파일로 구현.
 */
#else

/*
 * xchgl exchanges the values of its two operands,
 * while locking the memory bus to exclude other operations.
 */
static inline unsigned
xchg_32(void *ptr, unsigned x)
{
    __asm__ __volatile__("xchgl %0,%1"
            :"=r" ((unsigned) x)
            :"m" (*(volatile unsigned *)ptr), "0" (x)
            :"memory");

    return x;
}

static inline unsigned char
xchg_8(void *ptr, unsigned char x)
{
    __asm__ __volatile__("xchgb %0,%1"
            :"=r" ((unsigned char) x)
            :"m" (*(volatile unsigned char *)ptr), "0" (x)
            :"memory");

    return x;
}


mvp_rc_t sciSysFutex( void            * aAddr1,
                      mvp_sint32_t      aOP,
                      mvp_sint32_t      aVal1,
                      struct timespec * aTimeout,
                      void            * aAddr2,
                      mvp_sint32_t      aVal3 )
{
    return syscall( SYS_futex, aAddr1, aOP, aVal1, aTimeout, aAddr2, aVal3 );
}


mvp_rc_t sciMutexInitWithAttr( mutex_t    * aMutex )
{
    return RC_SUCCESS;
}


mvp_rc_t sciMutexInit( mutex_t             * aMutex,
                       pthread_mutexattr_t * aAttr )
{
    (void)aAttr;
    aMutex->mU32 = 0;

    return RC_SUCCESS;
}


mvp_rc_t sciMutexDestroy( mutex_t * aMutex )
{
    (void)aMutex;

    return RC_SUCCESS;
}


mvp_rc_t sciMutexLock( mutex_t * aMutex )
{
    mvp_sint32_t   i;

    /*
     * contended 가 아닌 상황에서는 1 byte(locked) 만을
     * 바꾸면 된다.
     */
    for( i = 0; i < 100; i++ )
    {
        /*
         * locked 가 0 이었다면 1 과 바꾼 후에는
         * 1 이 0 이 되었을 것이고, locked 는 1 이
         * 되었을 것이므로 lock 성공.
         */
        if( !xchg_8(&aMutex->b.mLocked, 1))
        {
            return RC_SUCCESS;
        }
        cpu_relax();
    }

    /*
     * 다른 놈이 lock 을 잡고 있으므로 여기부터 contended.
     *
     * 그래서, lock 을 잡고자할 때는 locked + contended 값을
     * 둘 다 표현할 수 있는 257 이라는 값으로 변경해야 한다.
     * 이는 구조체에서 unsigned int 형(mU32)을 사용해야 함을 의미한다.
     * 값을 변경할 때는 1 byte 를 넘어가므로 xchg_32 사용.
     */

    /*
     * 아래에서 257 을 사용하는 이유.
     * 최하위 1 byte 의 1 bit 는 locked, unlocked 를 나타내고,
     * 그 바로 위의 1 byte 는 contended, uncontended 를 나타낸다.
     * 따라서, 값에 따라 나타내는 상태는 다음과 같다.
     *
     * 0   unlocked + uncontended
     * 1   locked
     * 256 unlocked and contended
     * 257 locked and contended.
     */

    /*
     * mU32 값이 256 또는 0 이었다면 257 로 바뀐 후
     * 리턴값은 256 또는 0 이 되므로 lock 을 잡은 것이 되어 리턴한다.
     * 만약 mU32 값이 257 또는 1 이었다면, 즉 다른 놈이 잡은 상태라면
     * FUTEX_WAIT 상태로 기다린다. 이는 곧 lock wait 상태라는 말이다.
     * 0 또는 256 이었다면 257 즉 locked + contended 상태로 변경되고
     * 성공으로 리턴한다.
     */
    while( xchg_32(&aMutex->mU32,257) & 1 )
    {
        /* m->u 값이 계속 257 인지 검사한다. */
        sciSysFutex(&aMutex, FUTEX_WAIT, 257, NULL, NULL, 0);
    }

    return RC_SUCCESS;
}


mvp_rc_t sciMutexTrylock( mutex_t * aMutex )
{
    unsigned c = xchg_8(&aMutex->b.mLocked, 1);

    if( !c ) return RC_SUCCESS;

    return EBUSY;
}


mvp_rc_t sciMutexUnlock( mutex_t * aMutex )
{
    mvp_sint32_t   i;

    /*
     * cmpxchg(addr,x,y)
     *
     * addr 값이 x 와 같으면 addr 값을 y 값으로 바꾸고,
     * 같지 않으면 x 의 자리에 addr 값을 저장한다.
     * 일치하면 true 리턴.
     *
     * 즉, addr 값이 x 값과 다르면 원래 addr 값을 리턴한다.
     * 그리고, x 값과 같았다면 y 값으로 바꾸고 true 를 리턴한다.
     */

    /*
     * locked and not contended
     */
    if((aMutex->mU32 == 1) && (cmpxchg(&aMutex->mU32,1,0) == 1))
    {
        /*
         * contended 상태가 아니므로 
         * unlocked 로 바꾼 후 바로 리턴
         */
        return RC_SUCCESS;
    }

    /*
     * 값이 0, 256, 257 인 경우
     *   0.   unlocked and not contended
     *   256. unlocked and contended
     *   257. locked and contended
     */

    /* unlock */
    aMutex->b.mLocked = 0;
    barrier();

    /* spin and hope someone takes the lock */
    for( i = 0; i < 1; i++ )
    {
        if( aMutex->b.mLocked )
        {
            return RC_SUCCESS;
        }

        cpu_relax();
    }

    /*
     * FUTEX_WAIT 로 대기중인 프로세스를 
     * 깨우기 위해 메모리 값 변경
     */
    aMutex->b.mContended = 0;

    /*
     * arg1 주소에서 대기하고 있는 프로세스를 최대 arg3 
     * 만큼 깨워줌.
     */
    sciSysFutex(&aMutex, FUTEX_WAKE, 1, NULL, NULL, 0);

    return RC_SUCCESS;
}


mvp_rc_t sciCondInitWithAttr( cond_t   * aCond )
{
    return RC_SUCCESS;
}


mvp_rc_t sciCondInit( cond_t             * aCond,
                      pthread_condattr_t * aAttr )
{
    (void)aAttr;

    aCond->mMutex = NULL;
    aCond->mSeq = 0;

    return RC_SUCCESS;
}

mvp_rc_t sciCondDestroy( cond_t * aCond )
{
    (void)aCond;
    return RC_SUCCESS;
}


mvp_rc_t sciCondWait( cond_t  * aCond,
                      mutex_t * aMutex )
{
    mvp_rc_t    sRC;
    mutex_t   * sRet;

    mvp_sint32_t    sSeq = aCond->mSeq;

    if( aCond->mMutex != aMutex )
    {
        if( aCond->mMutex )
        {
            return EINVAL;
        }

        sRet = cmpxchg(&aCond->mMutex, NULL, aMutex);

        if( aCond->mMutex != aMutex )
        {
            return EINVAL;
        }
    }

    /*
     * pthread_cond_wait 의 경우처럼 wait 에 들어가기 전에
     * mutex 를 풀어준다.
     */
    sRC = sciMutexUnlock( aMutex );
    if( sRC != 0 )
    {
        return errno;
    }

    sciSysFutex( &aCond->mSeq, FUTEX_WAIT, sSeq, NULL, NULL, 0 );

    while( xchg_32(&aMutex->b.mLocked, 257) & 1 )
    {
        sciSysFutex(aMutex, FUTEX_WAIT, 257, NULL, NULL, 0);
    }

    return RC_SUCCESS;
}


mvp_rc_t sciCondSignal( cond_t * aCond )
{
    atomic_add(&aCond->mSeq, 1);

    sciSysFutex(&aCond->mSeq, FUTEX_WAKE, 1, NULL, NULL, 0);

    return RC_SUCCESS;
}


mvp_rc_t sciCondBroadcast( cond_t * aCond )
{
    mutex_t  * sMutex = aCond->mMutex;

    /* No mutex means that there are no waiters */
    if( ! sMutex )
    {
        return RC_SUCCESS;
    }

    /* We are waking everyone up */
    atomic_add(&aCond->mSeq, 1);

    sciSysFutex(&aCond->mSeq, FUTEX_REQUEUE, 1, (struct timespec *)INT_MAX, sMutex, 0);

    return RC_SUCCESS;
}

#endif
