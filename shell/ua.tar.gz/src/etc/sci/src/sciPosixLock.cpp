/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   Posix Mutex 를 이용한 Lock 구현
 ******************************************************************************/
#include <sciCommon.h>

#ifdef USE_POSIX_LOCK


mvp_rc_t sciMutexInitWithAttr( mutex_t    * aMutex )
{
    mvp_rc_t             sRet = 0;
    pthread_mutexattr_t  sMutexAttr;

    sRet = pthread_mutexattr_init(&sMutexAttr);
    _IF_RAISE( sRet != 0, MUTEXATTR_INIT_ERROR );

    sRet = pthread_mutexattr_setpshared(&sMutexAttr, PTHREAD_PROCESS_SHARED);
    _IF_RAISE( sRet != 0, ETC_ERROR );

    sRet = pthread_mutexattr_setrobust(&sMutexAttr, PTHREAD_MUTEX_ROBUST_NP);
    _IF_RAISE( sRet != 0, ETC_ERROR );

    sRet = pthread_mutexattr_settype(&sMutexAttr, PTHREAD_MUTEX_RECURSIVE_NP);
    _IF_RAISE( sRet != 0, ETC_ERROR );

    sRet = pthread_mutexattr_settype(&sMutexAttr, PTHREAD_MUTEX_ADAPTIVE_NP);
    _IF_RAISE( sRet != 0, ETC_ERROR );

    /*
     * PTHREAD_PRIO_INHERIT 가 정의되어 있지 않으면 
     * pthread_mutex_consistent_np 가 정상동작하지 않을 수 있다.
     */
    sRet = pthread_mutexattr_setprotocol(&sMutexAttr, PTHREAD_PRIO_INHERIT);
    _IF_RAISE( sRet != 0, MUTEX_INIT_ERROR );

    sRet = sciPosixMutexInit(aMutex, &sMutexAttr);
    _IF_RAISE( sRet != 0, MUTEX_INIT_ERROR );

    pthread_mutexattr_destroy(&sMutexAttr);

    return RC_SUCCESS;

    _EXCEPTION( MUTEXATTR_INIT_ERROR )
    {
        DEBUG(__f, "mutexattr init fail : %s", strerror(errno));
    }
    _EXCEPTION( MUTEX_INIT_ERROR )
    {
        DEBUG(__f, "mutex init fail : %s", strerror(errno));
    }
    _EXCEPTION( ETC_ERROR )
    {
        DEBUG(__f, "set mutexattr fail : %s", strerror(errno));
    }
    _EXCEPTION_END;

    return sRet;
}


mvp_rc_t sciPosixMutexInit( mutex_t             * aMutex,
                            pthread_mutexattr_t * aAttr )
{
    return pthread_mutex_init( aMutex, aAttr );
}


mvp_rc_t sciPosixMutexDestroy( mutex_t * aMutex )
{
    return pthread_mutex_destroy(aMutex);
}


mvp_rc_t sciPosixMutexLock( mutex_t * aMutex )
{
    mvp_sint32_t  sRet;

    sRet = pthread_mutex_lock(aMutex);
    switch( sRet )
    {
        case 0 : break;
        case EOWNERDEAD :
            sRet = pthread_mutex_consistent_np(aMutex);
            _IF_RAISE( sRet != 0, CONSISTENT_NP_ERROR );
            break;
        default :
            _RAISE( MUTEX_LOCK_ERROR );
    }

    return RC_SUCCESS;

    _EXCEPTION( CONSISTENT_NP_ERROR )
    {
        DEBUG(__f, "pthread_mutex_consistent_np fail : %s", strerror(errno));
    }
    _EXCEPTION( MUTEX_LOCK_ERROR )
    {
        DEBUG(__f, "mutex lock fail : %s", strerror(errno));
    }
    _EXCEPTION_END;

    return sRet;
}


mvp_rc_t sciPosixMutexTrylock( mutex_t * aMutex )
{
    mvp_sint32_t  sRet;

    sRet = pthread_mutex_trylock(aMutex);
    switch( sRet )
    {
        case 0 : break;
        case EOWNERDEAD :
            sRet = pthread_mutex_consistent_np(aMutex);
            _IF_RAISE( sRet != 0, CONSISTENT_NP_ERROR );
            break;
        default :
            _RAISE( MUTEX_TRYLOCK_ERROR );
    }

    return RC_SUCCESS;

    _EXCEPTION( CONSISTENT_NP_ERROR )
    {
        DEBUG(__f, "pthread_mutex_consistent_np fail : %s", strerror(errno));
    }
    _EXCEPTION( MUTEX_TRYLOCK_ERROR )
    {
        DEBUG(__f, "mutex lock fail : %s", strerror(errno));
    }
    _EXCEPTION_END;

    return sRet;
}


mvp_rc_t sciPosixMutexUnlock( mutex_t * aMutex )
{
    return pthread_mutex_unlock(aMutex);
}


mvp_rc_t sciCondInitWithAttr( cond_t   * aCond )
{
    mvp_sint32_t       sRet;
    pthread_condattr_t sCondAttr;

    sRet = pthread_condattr_init(&sCondAttr);
    _IF_RAISE( sRet != 0, ETC_ERROR );

    sRet = pthread_condattr_setpshared(&sCondAttr, PTHREAD_PROCESS_SHARED);
    _IF_RAISE( sRet != 0, ETC_ERROR );

    sRet = sciPosixCondInit(aCond, &sCondAttr);
    _IF_RAISE( sRet != 0, COND_INIT_ERROR );

    pthread_condattr_destroy(&sCondAttr);

    return RC_SUCCESS;

    _EXCEPTION( COND_INIT_ERROR )
    {
        DEBUG(__f, "cond init fail : %s", strerror(errno));
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return sRet;
}


mvp_rc_t sciPosixCondInit( cond_t             * aCond,
                           pthread_condattr_t * aAttr )
{
    return pthread_cond_init( aCond, aAttr );
}


mvp_rc_t sciPosixCondDestroy( cond_t * aCond )
{
    return pthread_cond_destroy(aCond);
}


mvp_rc_t sciPosixCondWait( cond_t  * aCond,
                           mutex_t * aMutex )
{
    return pthread_cond_wait(aCond, aMutex);
}


mvp_rc_t sciPosixCondSignal( cond_t * aCond )
{
    return pthread_cond_signal(aCond);
}


mvp_rc_t sciPosixCondBroadcast( cond_t * aCond )
{
    return pthread_cond_broadcast(aCond);
}

#endif
