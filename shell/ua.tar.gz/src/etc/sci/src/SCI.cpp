/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   General Socket API 구현
 ******************************************************************************/
#include <sciCommon.h>


mvp_rc_t sciSetFuncPtr( PHSOCKET     aGenHandle,
                        mvp_sint32_t aDomain,
                        mvp_sint32_t aType );

PHSOCKET sciSocket( mvp_sint32_t   aDomain,
                    mvp_sint32_t   aType,
                    mvp_sint32_t   aProtocol )
{
    mvp_rc_t  sRC         = 0;
    PHSOCKET  sSockHandle = NULL;

    sSockHandle = (PHSOCKET)malloc(sizeof(SocketHandle));
    _IF_RAISE( sSockHandle == NULL, LACK_OF_MEMORY );
    memset( sSockHandle, 0x0, sizeof(SocketHandle));

    sRC = sciSetFuncPtr( sSockHandle, aDomain, aType );
    _IF_RAISE( sRC != 0, ETC_ERROR );

    return sSockHandle;

    _EXCEPTION( LACK_OF_MEMORY )
    {
        errno = ENOMEM;
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    if( sSockHandle == NULL )
    {
        free( sSockHandle );
    }

    return NULL;
}


mvp_rc_t sciListen( PHSOCKET       aSock,
                    mvp_sint32_t   aBacklog )
{
    _IF_RAISE( aSock == NULL, INVALID_ARG );

    return ((SocketHandle *)aSock)->mFuncListen( aSock, aBacklog );

    _EXCEPTION( INVALID_ARG )
    {
        errno = EBADF;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


PHSOCKET sciAccept( PHSOCKET          aSock,
                    struct sockaddr * aAddr,
                    socklen_t       * aAddrLen )
{
    PHSOCKET   sAccept = NULL;

    _IF_RAISE( aSock == NULL, INVALID_ARG );

    sAccept = (PHSOCKET)malloc(sizeof(SocketHandle));
    _IF_RAISE( sAccept == NULL, LACK_OF_MEMORY );
    memcpy( sAccept, aSock, sizeof(SocketHandle) );

    ((SocketHandle *)sAccept)->mSubHandle
            = ((SocketHandle *)aSock)->mFuncAccept( aSock, sAccept, aAddr, aAddrLen );
    _IF_RAISE( ((SocketHandle *)sAccept)->mSubHandle == NULL, ETC_ERROR );

    ((SocketHandle *)aSock)->mAcceptHandle = sAccept;

    return sAccept;

    _EXCEPTION( INVALID_ARG )
    {
        errno = EBADF;
    }
    _EXCEPTION( LACK_OF_MEMORY )
    {
        errno = ENOMEM;
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    if( sAccept != NULL )
    {
        free( sAccept );
    }

    return NULL;
}

mvp_rc_t sciConnect( PHSOCKET       aSock,
                     const struct sockaddr * aServAddr,
                     socklen_t      aAddrLen )
{
    _IF_RAISE( aSock == NULL, INVALID_ARG );

    return ((SocketHandle *)aSock)->mFuncConnect( aSock, aServAddr, aAddrLen );

    _EXCEPTION( INVALID_ARG )
    {
        errno = EBADF;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciBind( PHSOCKET       aSock,
                  struct sockaddr * aMyAddr,
                  socklen_t      aAddrLen )
{
    _IF_RAISE( aSock == NULL, INVALID_ARG );

    return ((SocketHandle *)aSock)->mFuncBind( aSock, aMyAddr, aAddrLen );

    _EXCEPTION( INVALID_ARG )
    {
        errno = EBADF;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciSend( PHSOCKET        aSock,
                  const void    * aMsg,
                  mvp_size_t      aLen,
                  mvp_sint32_t    aFlags )
{
    _IF_RAISE( aSock == NULL, INVALID_ARG );

    return ((SocketHandle *)aSock)->mFuncSend( aSock, aMsg, aLen, aFlags );

    _EXCEPTION( INVALID_ARG )
    {
        errno = EBADF;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciSendTo( PHSOCKET        aSock,
                    const void    * aMsg,
                    mvp_size_t      aLen,
                    mvp_sint32_t    aFlags,
                    const struct sockaddr * aTo,
                    socklen_t       aToLen )
{
    _IF_RAISE( aSock == NULL, INVALID_ARG );

    return ((SocketHandle *)aSock)->mFuncSendTo( aSock, aMsg, aLen, aFlags, aTo, aToLen );

    _EXCEPTION( INVALID_ARG )
    {
        errno = EBADF;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciGetSockOpt( PHSOCKET       aSock,
                        mvp_sint32_t   aLevel,
                        mvp_sint32_t   aOptName,
                        void         * aOptVal,
                        socklen_t    * aOptLen )
{
    _IF_RAISE( aSock == NULL, INVALID_ARG );

    return ((SocketHandle *)aSock)->mFuncGetSockOpt( aSock, aLevel, aOptName, aOptVal, aOptLen );

    _EXCEPTION( INVALID_ARG )
    {
        errno = EBADF;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciSetSockOpt( PHSOCKET       aSock,
                        mvp_sint32_t   aLevel,
                        mvp_sint32_t   aOptName,
                        const void   * aOptVal,
                        socklen_t      aOptLen )
{
    _IF_RAISE( aSock == NULL, INVALID_ARG );

    return ((SocketHandle *)aSock)->mFuncSetSockOpt( aSock, aLevel, aOptName, aOptVal, aOptLen );

    _EXCEPTION( INVALID_ARG )
    {
        errno = EBADF;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciClose( PHSOCKET   aSock )
{
    _IF_RAISE( aSock == NULL, INVALID_ARG );

    return ((SocketHandle *)aSock)->mFuncClose( aSock );

    _EXCEPTION( INVALID_ARG )
    {
        errno = EBADF;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciRecv( PHSOCKET       aSock,
                  void         * aBuf,
                  mvp_size_t     aLen,
                  mvp_sint32_t   aFlag )
{
    _IF_RAISE( aSock == NULL, INVALID_ARG );

    return ((SocketHandle *)aSock)->mFuncRecv( aSock, aBuf, aLen, aFlag );

    _EXCEPTION( INVALID_ARG )
    {
        errno = EBADF;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}


mvp_rc_t sciSetFuncPtr( PHSOCKET     aGenHandle,
                        mvp_sint32_t aDomain,
                        mvp_sint32_t aType )
{
    SocketHandle * sGenHandle;

    _IF_RAISE( aGenHandle == NULL, INVALID_ARG );

    sGenHandle = (SocketHandle *)aGenHandle;

    switch( aDomain )
    {
    case AF_INET :
        switch( aType )
        {
        case SOCK_STREAM :
            sGenHandle->mCommType = SCI_SOCK_UNICAST;
            sGenHandle->mSubHandle = (PH_SOCK_UNI)sciSockUnicastSocket( sGenHandle );
            _IF_RAISE( sGenHandle->mSubHandle == NULL, ETC_ERROR );

            sGenHandle->mFuncAccept  = (sciPtrAccept)sciSockUnicastAccept;
            sGenHandle->mFuncBind    = (sciPtrBind)sciSockUnicastBind;
            sGenHandle->mFuncListen  = (sciPtrListen)sciSockUnicastListen;
            sGenHandle->mFuncConnect = (sciPtrConnect)sciSockUnicastConnect;
            sGenHandle->mFuncSend    = (sciPtrSend)sciSockUnicastSend;
            sGenHandle->mFuncSendTo  = (sciPtrSendTo)sciSockUnicastSendTo;
            sGenHandle->mFuncGetSockOpt = (sciPtrGetSockOpt)sciSockUnicastGetSockOpt;
            sGenHandle->mFuncSetSockOpt = (sciPtrSetSockOpt)sciSockUnicastSetSockOpt;
            sGenHandle->mFuncClose   = (sciPtrClose)sciSockUnicastClose;
            sGenHandle->mFuncRecv    = (sciPtrRecv)sciSockUnicastRecv;
            break;
        case SOCK_DGRAM :
            sGenHandle->mCommType = SCI_SOCK_MULTICAST;
            sGenHandle->mSubHandle = (PH_SOCK_MULTI)sciSockMulticastSocket( sGenHandle );
            _IF_RAISE( sGenHandle->mSubHandle == NULL, ETC_ERROR );

            sGenHandle->mFuncAccept  = (sciPtrAccept)sciSockMulticastAccept;
            sGenHandle->mFuncBind    = (sciPtrBind)sciSockMulticastBind;
            sGenHandle->mFuncListen  = (sciPtrListen)sciSockMulticastListen;
            sGenHandle->mFuncConnect = (sciPtrConnect)sciSockMulticastConnect;
            sGenHandle->mFuncSend    = (sciPtrSend)sciSockMulticastSend;
            sGenHandle->mFuncSendTo  = (sciPtrSendTo)sciSockMulticastSendTo;
            sGenHandle->mFuncGetSockOpt = (sciPtrGetSockOpt)sciSockMulticastGetSockOpt;
            sGenHandle->mFuncSetSockOpt = (sciPtrSetSockOpt)sciSockMulticastSetSockOpt;
            sGenHandle->mFuncClose   = (sciPtrClose)sciSockMulticastClose;
            sGenHandle->mFuncRecv    = (sciPtrRecv)sciSockMulticastRecv;
            break;
        default :
            _RAISE( INVALID_ARG );
            break;
        }
        break;
    case AF_UNIX :
        switch( aType )
        {
        case SOCK_STREAM :
            sGenHandle->mCommType = SCI_UNIX_UNICAST;
            sGenHandle->mSubHandle = (PH_UNIX_UNI)sciUnixUnicastSocket( sGenHandle );
            _IF_RAISE( sGenHandle->mSubHandle == NULL, ETC_ERROR );

            sGenHandle->mFuncAccept  = (sciPtrAccept)sciUnixUnicastAccept;
            sGenHandle->mFuncBind    = (sciPtrBind)sciUnixUnicastBind;
            sGenHandle->mFuncListen  = (sciPtrListen)sciUnixUnicastListen;
            sGenHandle->mFuncConnect = (sciPtrConnect)sciUnixUnicastConnect;
            sGenHandle->mFuncSend    = (sciPtrSend)sciUnixUnicastSend;
            sGenHandle->mFuncSendTo  = (sciPtrSendTo)sciUnixUnicastSendTo;
            sGenHandle->mFuncGetSockOpt = (sciPtrGetSockOpt)sciUnixUnicastGetSockOpt;
            sGenHandle->mFuncSetSockOpt = (sciPtrSetSockOpt)sciUnixUnicastSetSockOpt;
            sGenHandle->mFuncClose   = (sciPtrClose)sciUnixUnicastClose;
            sGenHandle->mFuncRecv    = (sciPtrRecv)sciUnixUnicastRecv;
            break;
        case SOCK_DGRAM :
        default :
            _RAISE( INVALID_ARG );
            break;
        }
        break;
    case AF_IPC :
        switch( aType )
        {
        case SOCK_STREAM :
            sGenHandle->mCommType = SCI_SHM_UNICAST;
            sGenHandle->mSubHandle = (PH_SHM_UNI)sciShmUnicastSocket( sGenHandle );
            _IF_RAISE( sGenHandle->mSubHandle == NULL, ETC_ERROR );

            sGenHandle->mFuncAccept  = (sciPtrAccept)sciShmUnicastAccept;
            sGenHandle->mFuncBind    = (sciPtrBind)sciShmUnicastBind;
            sGenHandle->mFuncListen  = (sciPtrListen)sciShmUnicastListen;
            sGenHandle->mFuncConnect = (sciPtrConnect)sciShmUnicastConnect;
            sGenHandle->mFuncSend    = (sciPtrSend)sciShmUnicastSend;
            sGenHandle->mFuncSendTo  = (sciPtrSendTo)sciShmUnicastSendTo;
            sGenHandle->mFuncGetSockOpt = (sciPtrGetSockOpt)sciShmUnicastGetSockOpt;
            sGenHandle->mFuncSetSockOpt = (sciPtrSetSockOpt)sciShmUnicastSetSockOpt;
            sGenHandle->mFuncClose   = (sciPtrClose)sciShmUnicastClose;
            sGenHandle->mFuncRecv    = (sciPtrRecv)sciShmUnicastRecv;
            break;
        case SOCK_DGRAM :
        default :
            _RAISE( INVALID_ARG );
            break;
        }
        break;
    case AF_RDMA :
        break;
    default :
        _RAISE( INVALID_ARG );
        break;
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_ARG )
    {
        errno = EINVAL;
    }
    _EXCEPTION( ETC_ERROR )
    {
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}
