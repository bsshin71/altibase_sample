#include <SCI.h>
#include <demo_env.h>

int    exit_thr = 0;

struct timespec start;
struct timespec end;


void event_callback( int     event_type,
                     void  * param )
{
    /* do nothing */
}


void recv_callback(void * data, int len, void * param)
{
    int       ret;
    char      buf[MSG_SIZE];
    PHSOCKET  sender = (PHSOCKET)param;

    /*------------------------------------------------
     * send back to client
     ------------------------------------------------*/
    memcpy( buf, data, len );

    ret = sciSend( sender, buf, len, 0 );
    if( ret != len )
    {
        printf("send fail : %s\n", strerror(errno));
    }
}


int main()
{
    int           rc;
    int           ret;
    PHSOCKET      sender;
    PHSOCKET      receiver;

    int           polling_type  = 0;           /* 0 : select, 1 : poll, 2 : epoll */
    size_t        shm_size = 1 * 1024 * 1024;  /* 10 M */
    struct sockaddr_un     bind;
    struct sciSocketOption sock_opt;

    /*------------------------------------------------
     * get environment values for demo
     ------------------------------------------------*/
    _IF_RAISE( get_env() < 0, ERROR );

    /* send socket */
    {
        /*------------------------------------------------
         * socket creation - handle
         ------------------------------------------------*/
        _IF_RAISE( (sender = sciSocket( AF_IPC,
                                             SOCK_STREAM,
                                             0))
                        == NULL, ERROR );

        memset(&sock_opt, 0x00, sizeof(struct sciSocketOption));

        sock_opt.common.event_callback_func  = event_callback;
        sock_opt.common.event_callback_param = sender;
        sock_opt.common.polling_type         = polling_type;
        sock_opt.ipc.shm_size             = shm_size;
        sock_opt.ipc.lock_event_type      = de.lock_type;

        _IF_RAISE( (rc = sciSetSockOpt( sender,
                                             SOL_COMMON,
                                             SO_OPT_ALL,
                                             (void*)&sock_opt,
                                             sizeof(sock_opt)))
                        != 0, ERROR );

        /*------------------------------------------------
         * socket bind
         ------------------------------------------------*/
        strcpy( bind.sun_path, "/tmp/shm_unicast_a" );

        _IF_RAISE( (ret = sciConnect( sender,
                                           (struct sockaddr *)&bind,
                                           sizeof(bind)))
                        != 0, ERROR );
    }
    /* receive socket */
    {
        /*------------------------------------------------
         * socket creation - handle
         ------------------------------------------------*/
        _IF_RAISE( (receiver = sciSocket( AF_IPC,
                                               SOCK_STREAM,
                                               0))
                        == NULL, ERROR );

        /*------------------------------------------------
         * set socket option
         ------------------------------------------------*/
        memset(&sock_opt, 0x00, sizeof(struct sciSocketOption));

        sock_opt.common.recv_callback_func   = recv_callback;
        sock_opt.common.recv_callback_param  = sender;
        sock_opt.common.event_callback_func  = event_callback;
        sock_opt.common.event_callback_param = receiver;
        sock_opt.common.polling_type         = polling_type;
        sock_opt.common.recv_poll_count      = de.polling_cnt;
        sock_opt.ipc.shm_size             = shm_size;
        sock_opt.ipc.lock_event_type      = de.lock_type;

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_OPT_ALL,
                                             (void*)&sock_opt,
                                             sizeof(sock_opt)))
                        != 0, ERROR );

        /*------------------------------------------------
         * socket bind
         ------------------------------------------------*/
        strcpy( bind.sun_path, "/tmp/shm_unicast_b" );

        _IF_RAISE( (rc = sciBind( receiver,
                                       (struct sockaddr *)&bind,
                                       sizeof(bind)))
                        != 0, ERROR );
    }

    while( exit_thr == 0 )
    {
        sleep(1);
    }

    ret = sciClose( sender );
    ret = sciClose( receiver );

    return 0;

    _EXCEPTION( ERROR )
    {
        printf("Error : %s\n", strerror(errno));
    }
    _EXCEPTION_END;

    return -1;
}
