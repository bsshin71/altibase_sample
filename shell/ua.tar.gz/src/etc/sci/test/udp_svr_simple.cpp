#include <SCI.h>
#include <demo_env.h>


int done = 0;

void recv_callback( const void * data,
                    int          len,
                    void       * param )
{
    PHSOCKET   sock = (PHSOCKET)param;

    printf("\n%s\n\n", (char *)data);
    done = 1;
}


int main( int argc, char * argv[] )
{
    int           ret     = 0;
    PHSOCKET      phsock  = NULL;
    struct sockaddr_in   myaddr;

    if( argc < 2 )
    {
        printf("\nUsage : %s [my port]\n", argv[0]);
        exit(1);
    }

    set_log();

    phsock = sciSocket( AF_INET, SOCK_DGRAM, 0);
    if( phsock == NULL ) goto error;

    ret = sciSetSockOpt( phsock, SOL_COMMON, SO_RECV_CB, (void*)recv_callback, sizeof(&recv_callback));
    if( ret != 0 ) goto error;

    ret = sciSetSockOpt( phsock, SOL_COMMON, SO_RECV_PARAM, (void*)phsock, sizeof(phsock));
    if( ret != 0 ) goto error;

    myaddr.sin_family = AF_INET;
    myaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    myaddr.sin_port = htons(atoi(argv[1]));

    ret = sciBind( phsock, (struct sockaddr *)&myaddr, sizeof(myaddr));
    if( ret != 0 ) goto error;

    // do something for main thread
    while( done == 0 )
    {
        sleep(1);
    }

    sciClose( phsock );

    return 0;

error:
    printf("error : %s\n", strerror(errno));
    return -1;
}
