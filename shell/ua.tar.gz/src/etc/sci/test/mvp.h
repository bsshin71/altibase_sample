/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/
#ifndef __MVP_H__
#define __MVP_H__ 1


/****************************************************
 * EXTERN
****************************************************/
#if defined (_cplusplus)
#define MVP_EXTERN_C       extern "C"
#define MVP_EXTERN_C_BEGIN extern "C" {
#define MVP_EXTERN_C_END   }
#else
#define MVP_EXTERN_C       extern
#define MVP_EXTERN_C_BEGIN
#define MVP_EXTERN_C_END
#endif

#define _INLINE  static __inline__

/****************************************************
 * Return Value
****************************************************/
#define RC_SUCCESS               0
#define RC_FAILURE              -1
#define MVP_RC_GET_OS_ERROR()    errno


/****************************************************
 * Type redefinition
****************************************************/
typedef short          mvp_sint16_t;
typedef char           mvp_char_t;
typedef unsigned char  mvp_uint8_t;
typedef int            mvp_sint32_t;
typedef int            mvp_rc_t;
typedef long           mvp_sint64_t;
typedef float          mvp_float_t;
typedef double         mvp_double_t;
typedef unsigned long  mvp_uint64_t;
typedef mvp_uint64_t   mvp_size_t;
typedef unsigned int   mvp_uint32_t;
typedef mvp_sint64_t   mvp_ssize_t;
typedef mvp_sint32_t   mvp_key_t;


/****************************************************
 * Exception Handling
****************************************************/
#define _EXCEPTION_END    \
    MVP_EXCEPTION_END_LABEL: \
    do                       \
    {                        \
    } while(0)

#define _EXCEPTION(aLabel)     \
    goto MVP_EXCEPTION_END_LABEL; \
    aLabel:

#define MVP_TEST(aExpr)                         \
    do                                          \
    {                                           \
        if(aExpr)                               \
        {                                       \
            goto MVP_EXCEPTION_END_LABEL;       \
        }                                       \
        else                                    \
        {                                       \
        }                                       \
    } while(0)

#define _RAISE(aLabel)                       \
    do                                          \
    {                                           \
        goto aLabel;                            \
    } while(0)

#define _IF_RAISE(aExpr, aLabel)  \
    do                                 \
    {                                  \
        if ( unlikely( aExpr )         \
        {                              \
            goto aLabel;               \
        }                              \
    } while(0)

/****************************************************
 * Atomic Operation
****************************************************/
_INLINE mvp_sint32_t mvpAtomicCas32(volatile void         *aAddr,
                                       volatile mvp_sint32_t  aWith,
                                       volatile mvp_sint32_t  aCmp)
{
    mvp_sint32_t sPrev;

    __asm__ __volatile__ ("lock; cmpxchgl %1,%2"
                          : "=a"(sPrev)
                          : "r"(aWith),
                            "m"(*(volatile mvp_sint32_t *)aAddr),
                            "0"(aCmp)
                          : "memory");
    return sPrev;
}


_INLINE mvp_sint32_t mvpAtomicSet32(volatile void         *aAddr,
                                       volatile mvp_sint32_t  aVal)
{
    __asm__ __volatile__ ("xchgl %0,%1"
                          : "=r"(aVal)
                          : "m"(*(volatile mvp_sint32_t *)aAddr), "0"(aVal)
                          : "memory");
    return aVal;
}



_INLINE mvp_sint32_t mvpAtomicAdd32(volatile void         *aAddr,
                                       volatile mvp_sint32_t  aVal)
{
    mvp_sint32_t sTemp = aVal;

    __asm__ __volatile__ ("lock; xaddl %0,%1"
                          : "+r"(sTemp), "+m"(*(volatile mvp_sint32_t *)aAddr)
                          :
                          : "memory");
    return sTemp + aVal;
}



_INLINE mvp_sint64_t mvpAtomicCas64(volatile void         *aAddr,
                                       volatile mvp_sint64_t  aWith,
                                       volatile mvp_sint64_t  aCmp)
{
    mvp_sint64_t sPrev;

    __asm__ __volatile__ ("lock; cmpxchgq %1,%2"
                          : "=a"(sPrev)
                          : "r"(aWith),
                            "m"(*(volatile mvp_sint64_t *)aAddr),
                            "0"(aCmp)
                          : "memory");
    return sPrev;
}


_INLINE mvp_sint64_t mvpAtomicGet64(volatile void *aAddr)
{
    return *(volatile mvp_sint64_t *)aAddr;
}

_INLINE mvp_sint64_t mvpAtomicSet64(volatile void         *aAddr,
                                       volatile mvp_sint64_t  aVal)
{
    __asm__ __volatile__ ("xchgq %0,%1"
                          : "=r"(aVal)
                          : "m"(*(volatile mvp_sint64_t *)aAddr), "0"(aVal)
                          : "memory");
    return aVal;
}

_INLINE mvp_sint64_t mvpAtomicAdd64(volatile void         *aAddr,
                                       volatile mvp_sint64_t  aVal)
{
    mvp_sint64_t sPrev = aVal;

    __asm__ __volatile__ ("lock; xaddq %0,%1"
                          : "+r"(sPrev), "+m"(*(volatile mvp_sint64_t *)aAddr)
                          :
                          : "memory");
    return sPrev + aVal;
}



_INLINE mvp_sint32_t mvpAtomicGet32(volatile void *aAddr)
{
    return mvpAtomicCas32(aAddr, 0, 0);
}



_INLINE mvp_sint32_t mvpAtomicInc32(volatile void *aAddr)
{
    return mvpAtomicAdd32(aAddr, 1);
}

_INLINE mvp_sint32_t mvpAtomicDec32(volatile void *aAddr)
{
    return mvpAtomicAdd32(aAddr, -1);
}



_INLINE mvp_sint64_t mvpAtomicInc64(volatile void *aAddr)
{
    return mvpAtomicAdd64(aAddr, 1);
}

_INLINE mvp_sint64_t mvpAtomicDec64(volatile void *aAddr)
{
    return mvpAtomicAdd64(aAddr, -1);
}


#endif /* __MVP_H__ */
