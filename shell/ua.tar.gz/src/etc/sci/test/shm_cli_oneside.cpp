#include <SCI.h>
#include <demo_env.h>

int       iter     = 0;
int       exit_thr = 0;

typedef struct msg
{
    struct timespec  start;
    int              cnt;
} MSG;

MSG     * msg;


void event_callback( int     event_type,
                     void  * param )
{
}


int main( int argc, char * argv[] )
{
    int            i, rc;
    int            ret;
    int            opt;
    PHSOCKET       sender;
    PHSOCKET       receiver;

    int            polling_type    = 0;          /* 0 : select, 1 : poll, 2 : epoll */

    char         * buf = NULL;
    size_t         shm_size = 1 * 1024 * 1024;   /* 1 M */
    struct sockaddr_un   bind;

    if( argc < 2 )
    {
        printf("Usage : %s [iteration count]\n", argv[0]);
        exit(1);
    }

    iter = atoi(argv[1]);


    /*------------------------------------------------
     * get environment values for demo
     ------------------------------------------------*/
    _IF_RAISE( get_env() < 0, ERROR );

    /* send socket */
    {
        /*------------------------------------------------
         * socket creation - handle
         ------------------------------------------------*/
        _IF_RAISE( (sender = sciSocket( AF_IPC,
                                             SOCK_STREAM,
                                             0))
                        == NULL, ERROR );

        /*------------------------------------------------
         * set socket option
         ------------------------------------------------*/
        _IF_RAISE( (rc = sciSetSockOpt( sender,
                                             SOL_COMMON,
                                             SO_EVENT_CB,
                                             (void *)event_callback,
                                             sizeof(&event_callback)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( sender,
                                             SOL_COMMON,
                                             SO_EVENT_PARAM,
                                             (void *)sender,
                                             sizeof(sender)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( sender,
                                             SOL_COMMON,
                                             SO_POLLING_TYPE,
                                             (void *)&polling_type,
                                             sizeof(polling_type)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( sender,
                                             SOL_IPC,
                                             SO_SHM_SIZE,
                                             (void*)&shm_size,
                                             sizeof(shm_size)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( sender,
                                             SOL_IPC,
                                             SO_LOCK_EVENT_TYPE,
                                             (void*)&de.lock_type,
                                             sizeof(de.lock_type)))
                        != 0, ERROR );

        /*------------------------------------------------
         * socket bind
         ------------------------------------------------*/
        strcpy( bind.sun_path, "/tmp/shm_unicast_b" );

        _IF_RAISE( (ret = sciConnect( sender,
                                           (struct sockaddr *)&bind,
                                           sizeof(bind)))
                        != 0, ERROR );
    }

    sleep(1);

    buf = (char *)malloc(MSG_SIZE);
    memset( buf, 0x00, MSG_SIZE );


    for( i = 0; i < iter; i ++ )
    {
        memset( buf, 'A', MSG_SIZE );
        msg = (MSG *)buf;

        clock_gettime(CLOCK_REALTIME, &msg->start);
        msg->cnt = i;

        _IF_RAISE( (ret = sciSend( sender,
                                        buf,
                                        MSG_SIZE,
                                        0 ))
                        != MSG_SIZE, ERROR );

        if( i % de.p_count == 0 )
        {
            printf("[Send OK Count] ............... %d\n", i);
        }
    }


    while( 1 )
    {
        usleep(5000);
    }

    ret = sciClose( sender );
    ret = sciClose( receiver );

    return RC_SUCCESS;

    _EXCEPTION( ERROR )
    {
        printf("error : %s\n", strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}
