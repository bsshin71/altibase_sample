#include <SCI.h>
#include <demo_env.h>

int      cnt      = 0;
int      iter     = 0;
int      exit_thr = 0;
int      stat_f   = 1;
PHTIMER  timer;


void event_callback( int     event_type,
                     void  * param )
{
    exit_thr = 1;
    cnt = 0;
}


void recv_callback( void     * data,
                    int        data_len,
                    void     * param )
{
    PHSOCKET  phsock = (PHSOCKET)param;
    int       ret;
    char      buf[MSG_SIZE];

    if( stat_f ) ret = end_timer( timer );

    ret = *(int *)data;

    if( cnt != ret )
    {
        printf("invalid return value. [%d:%d\n", cnt, ret);
        exit_thr = 1;

        return;
    }

    if( ++cnt % de.p_count == 0 )
    {
        printf("[Round Trip Count] ............... %d\n", cnt );
    }

    if( cnt >= iter )
    {
        /*------------------------------------------------
         * time statistics
         ------------------------------------------------*/
        if( stat_f ) ret = elapse_timer( timer, iter );

        cnt = 0;
        exit_thr = 1;
        return;
    }

    if( de.inter_sleep > 0 )
    {
        sleep_micro( de.inter_sleep ); 
    }

    /*------------------------------------------------
     * resend packet to server
     ------------------------------------------------*/
    if( stat_f ) ret = start_timer( timer );

    memcpy(buf, data, data_len);
    memcpy(buf, &cnt, sizeof(cnt));

    ret = sciSend( phsock, buf, data_len, 0);

    if( ret != data_len )
    {
        printf("send fail : %d\n", ret );
        exit(1);
    }
}


int main( int argc, char * argv[] )
{
    int                  i;
    int                  ret;
    int                  opt;
    PHSOCKET             phsock;
    struct sockaddr_in   addr;
    struct sockaddr_in   serv;
    char                 buf[MSG_SIZE];

    if( argc < 4 )
    {
        printf("\nUsage : %s [server ip] [server port] [iteration count]\n", argv[0]);
        exit(1);
    }

    while( (opt = getopt(argc, argv, "n")) != EOF )
    {
        switch( opt )
        {
            case 'n' : stat_f = 0; break;
            default  : break;
        }
    }

    iter = atoi(argv[3]);

    /*------------------------------------------------
     * get environment values for demo
     ------------------------------------------------*/
    _IF_RAISE( get_env() < 0, ERROR );

    /*------------------------------------------------
     * socket creation - handle
     ------------------------------------------------*/
    _IF_RAISE( (phsock = sciSocket( AF_INET,
                                         SOCK_STREAM,
                                         0))
                    == NULL, SOCK_CREATE_FAIL );

    /*------------------------------------------------
     * set socket option
     ------------------------------------------------*/
    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_RECV_CB,
                                          (void*)recv_callback,
                                          sizeof(&recv_callback)))
                    != 0, SET_SOCKOPT_FAIL );

    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_RECV_PARAM,
                                          (void*)phsock,
                                          sizeof(phsock)))
                    != 0, SET_SOCKOPT_FAIL );

    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_EVENT_CB,
                                          (void*)event_callback,
                                          sizeof(&event_callback)))
                    != 0, SET_SOCKOPT_FAIL );

    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_EVENT_PARAM,
                                          (void*)phsock,
                                          sizeof(phsock)))
                    != 0, SET_SOCKOPT_FAIL );

    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_RECV_POLL,
                                          (void*)&de.polling_cnt,
                                          sizeof(de.polling_cnt)))
                     != 0, SET_SOCKOPT_FAIL );

    /*------------------------------------------------
     * socket bind
     ------------------------------------------------*/
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);

    _IF_RAISE( (ret = sciBind( phsock,
                                    (struct sockaddr *)&addr,
                                    sizeof(struct sockaddr_in)))
                    != 0, BIND_FAIL );

    /*------------------------------------------------
     * socket connect
     ------------------------------------------------*/
    serv.sin_family = AF_INET;
    serv.sin_addr.s_addr = inet_addr(argv[1]);
    serv.sin_port = htons(atoi(argv[2]));

    _IF_RAISE( (ret = sciConnect( phsock,
                                       (struct sockaddr *)&serv,
                                       sizeof(serv)))
                    != 0, CONNECT_FAIL );

    sleep(1);

    i = 0;

    /*------------------------------------------------
     * init & start timer
     ------------------------------------------------*/
    if( stat_f )
    {
        timer = init_timer( de.t_unit, de.t_start, de.t_interval, 20 );
        _IF_RAISE( timer == NULL, ERROR );

        ret = start_timer( timer );
    }

    /*------------------------------------------------
     * send first packet
     ------------------------------------------------*/
    memset(buf, 'A', sizeof(buf));
    memcpy(buf, &i, sizeof(i));

    sleep(100);

    _IF_RAISE( (ret = sciSend( phsock,
                                    buf,
                                    sizeof(buf),
                                    0))
                    != sizeof(buf), SEND_FAIL );

    while( exit_thr == 0 )
    {
        sleep(1);
    }

    sciClose( phsock );

    return 0;

    _EXCEPTION( SOCK_CREATE_FAIL )
    {
        printf("socket creation fail : %s\n", strerror(errno));
    }
    _EXCEPTION( BIND_FAIL )
    {
        printf("bind fail : %s\n", strerror(errno));
    }
    _EXCEPTION( CONNECT_FAIL )
    {
        printf("connect fail : %s\n", strerror(errno));
    }
    _EXCEPTION( SET_SOCKOPT_FAIL )
    {
        printf("setsockopt fail : %s\n", strerror(errno));
    }
    _EXCEPTION( SEND_FAIL )
    {
        printf("send fail : %s\n", strerror(errno));
    }
    _EXCEPTION( ERROR )
    {
    }
    _EXCEPTION_END;

    return -1;
}
