#ifndef __O_DEMO_ENV_H__
#define __O_DEMO_ENV_H__

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>
#include <sched.h>
#include <errno.h>
#include <string.h>
#include <sys/un.h>

#include <mvp.h>
#include <timer_stat.h>

#define MSG_SIZE   1300

typedef struct demoEnv
{
    int     print_debug;   /* flag for detail debug message */

    int     t_unit;        /* 0 : micro, 1 : sec, 2 : mili, 3 : nano */
    int     t_start;       /* starting point of stat time interval */
    int     t_interval;    /* stat time interval */

    int     p_count;       /* print round trip count (몇건마다 건수를 찍을거냐..)  */

    int     polling_cnt;   /* -1 : busy wait, 0 : event, num : spin */
    int     inter_sleep;   /* sleep time for perf test. microseconds */
    int     lock_type;     /* lock event type. (0:cond_wait, 1:eventfd, 2:futex) */
} DEMO_ENV;


extern DEMO_ENV   de;

int get_env( void );
int set_log( void );


#endif /* __O_DEMO_ENV_H__ */
