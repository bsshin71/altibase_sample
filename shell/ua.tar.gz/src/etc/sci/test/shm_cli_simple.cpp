#include <SCI.h>
#include <demo_env.h>

int main( int argc, char * argv[] )
{
    int              ret;
    PHSOCKET         phsock;
    char             buf[200];
    struct sockaddr_un   serv;

    set_log();

    phsock = sciSocket( AF_IPC, SOCK_STREAM, 0);
    if( phsock == NULL ) goto error;

    memset(&serv, 0x0, sizeof(serv));
    strcpy( serv.sun_path, "/tmp/shm_unicast_serv" );

    ret = sciConnect( phsock, (struct sockaddr *)&serv, sizeof(serv));
    if( ret != 0 ) goto error;

//    sleep(1);

    memset(buf, 0x00, sizeof(buf));
    strcpy(buf, "THIS IS A STRING FOR DEMONSTRATION. GOOD LUCK !!!");

    ret = sciSend( phsock, buf, sizeof(buf), 0 );
    if( ret != sizeof(buf) ) goto error;

    sciClose( phsock );

    return 0;

error:
    printf("error : %s\n", strerror(errno));
    return -1;
}
