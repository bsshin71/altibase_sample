#include <SCI.h>
#include <demo_env.h>


int  exit_thr = 0;

void event_callback( int     event_type,
                     void  * param )
{
    /* disconnect event */
}

void recv_callback( const void * data,
                    int          len,
                    void       * param )
{
    int         ret;
    char        buf[MSG_SIZE];
    PHSOCKET    phsock = (PHSOCKET)param;

    /*------------------------------------------------
     * one memcpy and send message back to client
     ------------------------------------------------*/
    memcpy( buf, data, len );

    ret = sciSend( phsock, data, len, 0);
    if( ret != len )
    {
        printf("send fail : %s\n", strerror(errno));
        sciClose( phsock );
    }
}


int main( int argc, char * argv[] )
{
    int                  ret       = 0;
    PHSOCKET             phsock    = NULL;
    PHSOCKET             phaccept  = NULL;
    struct sockaddr_in   serv;
    struct sockaddr_in   cli;
    int                  cli_len;

    if( argc < 2 )
    {
        printf("\nUsage : %s [server port]\n", argv[0]);
        exit(1);
    }

    /*------------------------------------------------
     * get environment values for demo
     ------------------------------------------------*/
    _IF_RAISE( get_env() < 0, ERROR );


    /*------------------------------------------------
     * socket creation - listen socket handle
     ------------------------------------------------*/
    _IF_RAISE( (phsock = sciSocket( AF_INET,
                                         SOCK_STREAM,
                                         0))
                    == NULL, SOCK_CREATE_FAIL );


    /*------------------------------------------------
     * socket bind
     ------------------------------------------------*/
    serv.sin_family = AF_INET;
    serv.sin_addr.s_addr = htonl(INADDR_ANY);
    serv.sin_port = htons(atoi(argv[1]));

    _IF_RAISE( (ret = sciBind( phsock,
                                    (struct sockaddr *)&serv,
                                    sizeof(struct sockaddr_in)))
                    != 0, BIND_FAIL );


    /*------------------------------------------------
     * listen
     ------------------------------------------------*/
    _IF_RAISE( (ret = sciListen( phsock, 0 )) != 0, LISTEN_FAIL );


    while( exit_thr == 0 )
    {
        cli_len = sizeof(cli);

        /*------------------------------------------------
         * accept - alloc accept handle
         ------------------------------------------------*/
        _IF_RAISE( (phaccept = sciAccept( phsock,
                                               (struct sockaddr *)&cli,
                                               (socklen_t*)&cli_len ) )
                        == NULL, ACCEPT_FAIL );

        _IF_RAISE( (ret = sciSetSockOpt( phaccept,
                                              SOL_COMMON,
                                              SO_RECV_CB,
                                              (void*)recv_callback,
                                              sizeof(&recv_callback)))
                        != 0, SET_SOCKOPT_FAIL );

        _IF_RAISE( (ret = sciSetSockOpt( phaccept,
                                              SOL_COMMON,
                                              SO_RECV_PARAM,
                                              (void*)phaccept,
                                              sizeof(phaccept)))
                        != 0, SET_SOCKOPT_FAIL );

        _IF_RAISE( (ret = sciSetSockOpt( phaccept,
                                              SOL_COMMON,
                                              SO_EVENT_CB,
                                              (void*)event_callback,
                                              sizeof(&event_callback)))
                        != 0, SET_SOCKOPT_FAIL );

        _IF_RAISE( (ret = sciSetSockOpt( phaccept,
                                              SOL_COMMON,
                                              SO_EVENT_PARAM,
                                              (void*)phaccept,
                                              sizeof(phaccept)))
                        != 0, SET_SOCKOPT_FAIL );

        _IF_RAISE( (ret = sciSetSockOpt( phaccept,
                                              SOL_COMMON,
                                              SO_RECV_POLL,
                                              (void*)&de.polling_cnt,
                                              sizeof(de.polling_cnt)))
                         != 0, SET_SOCKOPT_FAIL );
    }

    /*------------------------------------------------
     * close listen/accept socket
     ------------------------------------------------*/
    sciClose( phsock );
    sciClose( phaccept );

    return 0;

    _EXCEPTION( SOCK_CREATE_FAIL )
    {
        printf("socket creation fail : %s\n", strerror(errno));
    }
    _EXCEPTION( BIND_FAIL )
    {
        printf("bind fail : %s\n", strerror(errno));
    }
    _EXCEPTION( LISTEN_FAIL )
    {
        printf("listen fail : %s\n", strerror(errno));
    }
    _EXCEPTION( ACCEPT_FAIL )
    {
        printf("accept fail : %s\n", strerror(errno));
    }
    _EXCEPTION( SET_SOCKOPT_FAIL )
    {
        printf("setsockopt fail : %s\n", strerror(errno));
    }
    _EXCEPTION( ERROR )
    {
    }
    _EXCEPTION_END;

    return -1;
}
