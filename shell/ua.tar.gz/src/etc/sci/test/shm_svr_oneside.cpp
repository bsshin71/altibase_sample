#include <SCI.h>
#include <demo_env.h>

int      exit_thr = 0;
int      iter     = 0;
struct   timespec  tot_start;
struct   timespec  tot_end;
PHTIMER  timer;

typedef struct msg
{
    struct timespec  start;
    int              cnt;
} MSG;

MSG     * msg;


void event_callback( int     event_type,
                     void  * param )
{
    /* do nothing */
}


void recv_callback(const void * data, int len, void * param)
{
    double   temp;
    MSG    * msg = (MSG *)data;

    start_timer2( timer, &msg->start );
    end_timer( timer );

    if( msg->cnt == 0 )
    {
        clock_gettime(CLOCK_REALTIME, &tot_start);
    }

    if( msg->cnt % de.p_count == 0 )
    {
        printf("[Recv OK Count] ............... %d\n", msg->cnt);
    }

    if( msg->cnt >= (iter-1) )
    {
        elapse_timer(timer, iter);

        clock_gettime(CLOCK_REALTIME, &tot_end);

        temp = ((tot_end.tv_sec + tot_end.tv_nsec/1000000000.0)
              - (tot_start.tv_sec + tot_start.tv_nsec/1000000000.0));
        printf("==> %.9f\n", temp);

        exit_thr = 1;
    }
}


int main( int argc, char * argv[] )
{
    int           rc;
    int           ret;
    PHSOCKET      receiver;

    int           polling_type = 0;                /* 0 : select, 1 : poll, 2 : epoll */
    size_t        shm_size     = 1 * 1024 * 1024;  /* 1 M */
    struct sockaddr_un   bind;

    if( argc < 2 )
    {
        printf("Usage : %s [iteration count]\n", argv[0]);
        exit(1);
    }

    iter = atoi(argv[1]);

    /*------------------------------------------------
     * get environment values for demo
     ------------------------------------------------*/
    _IF_RAISE( get_env() < 0, ERROR );

    timer = init_timer( de.t_unit, de.t_start, de.t_interval, 20 );

    /* receive socket */
    {
        /*------------------------------------------------
         * socket creation - handle
         ------------------------------------------------*/
        _IF_RAISE( (receiver = sciSocket( AF_IPC,
                                               SOCK_STREAM,
                                               0))
                        == NULL, ERROR );

        /*------------------------------------------------
         * set socket option
         ------------------------------------------------*/
        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_RECV_CB,
                                             (void *)recv_callback,
                                             sizeof(&recv_callback)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_RECV_PARAM,
                                             (void *)receiver,
                                             sizeof(receiver)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_EVENT_CB,
                                             (void *)event_callback,
                                             sizeof(&event_callback)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_EVENT_PARAM,
                                             (void *)receiver,
                                             sizeof(receiver)))
                        != 0, ERROR );


        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_POLLING_TYPE,
                                             (void *)&polling_type,
                                             sizeof(polling_type)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_RECV_POLL,
                                             (void*)&de.polling_cnt,
                                             sizeof(de.polling_cnt)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_IPC,
                                             SO_SHM_SIZE,
                                             (void*)&shm_size,
                                             sizeof(shm_size)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_IPC,
                                             SO_LOCK_EVENT_TYPE,
                                             (void*)&de.lock_type,
                                             sizeof(de.lock_type)))
                        != 0, ERROR );

        /*------------------------------------------------
         * socket bind
         ------------------------------------------------*/
        strcpy( bind.sun_path, "/tmp/shm_unicast_b" );

        _IF_RAISE( (rc = sciBind( receiver,
                                       (struct sockaddr *)&bind,
                                       sizeof(bind)))
                        != 0, ERROR );
    }

    while( exit_thr == 0 )
    {
        sleep(1);
    }

    ret = sciClose( receiver );

    return 0;

    _EXCEPTION( ERROR )
    {
        printf("Error : %s\n", strerror(errno));
    }
    _EXCEPTION_END;

    return -1;
}
