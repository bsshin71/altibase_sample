#include <SCI.h>
#include <demo_env.h>


int main( int argc, char * argv[] )
{
    int              ret;
    PHSOCKET         phsock;
    char             buf[200];
    struct sockaddr_in   serv;

    if( argc < 3 )
    {
        printf("\nUsage : %s [server ip] [server port]\n", argv[0]);
        exit(1);
    }

    set_log();

    phsock = sciSocket( AF_INET, SOCK_DGRAM, 0);
    if( phsock == NULL ) goto error;

    memset(&serv, 0x0, sizeof(serv));
    serv.sin_family = AF_INET;
    serv.sin_addr.s_addr = inet_addr(argv[1]);
    serv.sin_port = htons(atoi(argv[2]));

    memset(buf, 0x00, sizeof(buf));
    strcpy(buf, "THIS IS A STRING FOR DEMONSTRATION. GOOD LUCK !!!");

    ret = sciSendTo( phsock, buf, sizeof(buf), 0, (struct sockaddr *)&serv, sizeof(serv));
    if( ret != sizeof(buf) ) goto error;

    sciClose( phsock );

    return 0;

error:
    printf("error : %s\n", strerror(errno));
    return -1;
}
