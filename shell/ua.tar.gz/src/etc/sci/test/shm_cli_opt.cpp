#include <SCI.h>
#include <demo_env.h>

int       cnt      = 0;
int       iter     = 0;
int       exit_thr = 0;
int       stat_f   = 1;
PHTIMER   timer;

long      affinity = 4;


void event_callback( int     event_type,
                     void  * param )
{
    cnt = 0;
}


void recv_callback( void * data, int len, void * param)
{
    int         ret;
    PHSOCKET    sender = (PHSOCKET)param;
    char        buf[MSG_SIZE];

    if( stat_f ) ret = end_timer( timer );

    ret = *(int *)data;

    if( cnt != ret )
    {
        printf("invalid return value. [%d:%d]\n", cnt, ret);
        exit(1);
    }

    if( ++cnt % de.p_count == 0 )
    {
        printf("[Round Trip Count] ............... %d\n", cnt);
    }

    if( cnt >= iter )
    {
        if( stat_f ) ret = elapse_timer( timer, iter );

        cnt = 0;
        exit_thr = 1;

        return;
    }

    if( de.inter_sleep > 0 )
    {
        sleep_micro( de.inter_sleep ); 
    }

    if( stat_f ) ret = start_timer( timer );

    memcpy( buf, data, len );
    memcpy( buf, &cnt, sizeof(cnt));

    ret = sciSend( sender, buf, len, 0 );
    if( ret != len )
    {
        printf("send fail : %s\n", strerror(errno));
        return;
    }
}

int main( int argc, char * argv[] )
{
    int            i, rc;
    int            ret;
    int            opt;
    PHSOCKET       sender;
    PHSOCKET       receiver;

    int            polling_type    = 0;          /* 0 : select, 1 : poll, 2 : epoll */

    char         * buf = NULL;
    size_t         shm_size = 1 * 1024 * 1024;   /* 10 M */
    struct sockaddr_un     bind;
    struct sciSocketOption sock_opt;

    if( argc < 2 )
    {
        printf("Usage : %s [iteration count]\n", argv[0]);
        exit(1);
    }

    iter = atoi(argv[1]);

    while( (opt = getopt(argc, argv, "n")) != EOF )
    {
        switch( opt )
        {
            case 'n' : stat_f = 0; break;
            default  : break;
        }
    }

    /*------------------------------------------------
     * get environment values for demo
     ------------------------------------------------*/
    _IF_RAISE( get_env() < 0, ERROR );

    /* send socket */
    {
        /*------------------------------------------------
         * socket creation - handle
         ------------------------------------------------*/
        _IF_RAISE( (sender = sciSocket( AF_IPC,
                                             SOCK_STREAM,
                                             0))
                        == NULL, ERROR );

        /*------------------------------------------------
         * set socket option
         ------------------------------------------------*/
        memset(&sock_opt, 0x00, sizeof(struct sciSocketOption));

        sock_opt.common.event_callback_func  = event_callback;
        sock_opt.common.event_callback_param = sender;
        sock_opt.common.polling_type         = polling_type;
        sock_opt.ipc.shm_size                = shm_size;
        sock_opt.ipc.lock_event_type         = de.lock_type;

        _IF_RAISE( (ret = sciSetSockOpt( sender,
                                              SOL_COMMON,
                                              SO_OPT_ALL,
                                              (void*)&sock_opt,
                                              sizeof(sock_opt)))
                        != 0, ERROR );

        /*------------------------------------------------
         * socket bind
         ------------------------------------------------*/
        strcpy( bind.sun_path, "/tmp/shm_unicast_b" );

        _IF_RAISE( (ret = sciConnect( sender,
                                           (struct sockaddr *)&bind,
                                           sizeof(bind)))
                        != 0, ERROR );
    }
    /* receive socket */
    {
        /*------------------------------------------------
         * socket creation - handle
         ------------------------------------------------*/
        _IF_RAISE( (receiver = sciSocket( AF_IPC,
                                               SOCK_STREAM,
                                               0))
                        == NULL, ERROR );

        /*------------------------------------------------
         * set socket option
         ------------------------------------------------*/
        memset(&sock_opt, 0x00, sizeof(struct sciSocketOption));

        sock_opt.common.recv_callback_func   = recv_callback;
        sock_opt.common.recv_callback_param  = sender;
        sock_opt.common.event_callback_func  = event_callback;
        sock_opt.common.event_callback_param = receiver;
        sock_opt.common.polling_type         = polling_type;
        sock_opt.common.recv_poll_count      = de.polling_cnt;
        sock_opt.ipc.shm_size             = shm_size;
        sock_opt.ipc.lock_event_type      = de.lock_type;

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_OPT_ALL,
                                             (void*)&sock_opt,
                                             sizeof(sock_opt)))
                        != 0, ERROR );

        /*------------------------------------------------
         * socket bind
         ------------------------------------------------*/
        strcpy( bind.sun_path, "/tmp/shm_unicast_a" );

        _IF_RAISE( (rc = sciBind( receiver,
                                       (struct sockaddr *)&bind,
                                       sizeof(bind)))
                        != 0, ERROR );
    }

    sleep(1);

    buf = (char *)malloc(MSG_SIZE);
    memset( buf, 0x00, MSG_SIZE );

    if( stat_f )
    {
        timer = init_timer( de.t_unit, de.t_start, de.t_interval, 20);
        _IF_RAISE( timer == NULL, ERROR );

        rc = start_timer( timer );
    }

    i = 0;

    /*------------------------------------------------
     * send first packet
     ------------------------------------------------*/
    memset( buf, 'A', MSG_SIZE );
    memcpy( buf, &i, sizeof(i));

    _IF_RAISE( (ret = sciSend( sender,
                                    buf,
                                    MSG_SIZE,
                                    0 ))
                    != MSG_SIZE, ERROR );

    while( exit_thr == 0 )
    {
        usleep(5000);
    }

    ret = sciClose( sender );
    ret = sciClose( receiver );

    return RC_SUCCESS;

    _EXCEPTION( ERROR )
    {
        printf("error : %s\n", strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}
