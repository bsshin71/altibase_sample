#include <SCI.h>
#include <demo_env.h>

int main( int argc, char * argv[] )
{
    int            ret       = 0;
    PHSOCKET       phsock    = NULL;
    char           buf[200];
    struct sockaddr_in   myaddr;
    struct timeval timeout;

    if( argc < 2 )
    {
        printf("\nUsage : %s [my port]\n", argv[0]);
        exit(1);
    }

    set_log();

    phsock = sciSocket( AF_INET, SOCK_DGRAM, 0);
    if( phsock == NULL ) goto error;

    timeout.tv_sec   = 5;
    timeout.tv_usec  = 0;

    ret = sciSetSockOpt( phsock, SOL_COMMON, SO_SYNC_RECV, (void*)&timeout, sizeof(timeout));
    if( ret != 0 ) goto error;

    myaddr.sin_family = AF_INET;
    myaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    myaddr.sin_port = htons(atoi(argv[1]));

    ret = sciBind( phsock, (struct sockaddr *)&myaddr, sizeof(myaddr));
    if( ret != 0 ) goto error;

    printf("waiting data....\n");

    ret = sciRecv( phsock, buf, sizeof(buf), 0);
    if( ret != sizeof(buf)) goto error;

    printf("\n%s\n\n", buf);

    sciClose( phsock );

    return 0;

error:
    printf("error : %s\n", strerror(errno));
    return -1;
}

//for busy wait
//int            recv_poll = -1;
//ret = sciSetSockOpt( phsock, SOL_COMMON, SO_RECV_POLL, (void*)&recv_poll, sizeof(recv_poll));
//if( ret != 0 ) goto error;

