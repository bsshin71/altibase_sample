#include <SCI.h>
#include <demo_env.h>

int    exit_thr = 0;

char   peer_addr[32];
char   my_port[32];  /* peer port = my port + 1 */

struct sockaddr_in   my;
struct sockaddr_in   peer;

void event_callback( int     event_type,
                     void  * param )
{
    /* do nothing */
}

void recv_callback( const void * data,
                    int          len,
                    void       * param )
{
    int         ret;
    char        buf[MSG_SIZE];
    PHSOCKET    phsock = (PHSOCKET)param;

    /*------------------------------------------------
     * send back to client
     ------------------------------------------------*/
    memcpy( buf, data, len );

    ret = sciSendTo( phsock, buf, len, 0, (struct sockaddr *)&peer, sizeof(peer));
    if( ret != len )
    {
        printf("send fail : %s\n", strerror(errno));
        sciClose( phsock );
        exit_thr = 1;
    }
}


int main( int argc, char * argv[] )
{
    int                  ret       = 0;
    PHSOCKET             phsock    = NULL;

    if( argc < 3 )
    {
        printf("\nUsage : %s [peer addr] [my port]\n", argv[0]);
        exit(1);
    }

    /*------------------------------------------------
     * get environment values for demo
     ------------------------------------------------*/
    _IF_RAISE( get_env() < 0, ERROR );

    strcpy( peer_addr, argv[1] );
    strcpy( my_port, argv[2] );

    memset(&peer, 0x0, sizeof(peer));
    peer.sin_family = AF_INET;
    peer.sin_addr.s_addr = inet_addr(peer_addr);
    peer.sin_port = htons(atoi(my_port)+1);

    /*------------------------------------------------
     * socket creation - listen socket handle
     ------------------------------------------------*/
    _IF_RAISE( (phsock = sciSocket( AF_INET,
                                         SOCK_DGRAM,
                                         0))
                    == NULL, SOCK_CREATE_FAIL );

    /*------------------------------------------------
     * set socket option
     ------------------------------------------------*/
    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_RECV_CB,
                                          (void*)recv_callback,
                                          sizeof(&recv_callback)))
                    != 0, SET_SOCKOPT_FAIL );

    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_RECV_PARAM,
                                          (void*)phsock,
                                          sizeof(phsock)))
                    != 0, SET_SOCKOPT_FAIL );

    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_EVENT_CB,
                                          (void*)event_callback,
                                          sizeof(&recv_callback)))
                    != 0, SET_SOCKOPT_FAIL );

    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_EVENT_PARAM,
                                          (void*)phsock,
                                          sizeof(phsock)))
                    != 0, SET_SOCKOPT_FAIL );

    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_RECV_POLL,
                                          (void*)&de.polling_cnt,
                                          sizeof(de.polling_cnt)))
                     != 0, SET_SOCKOPT_FAIL );

    /*------------------------------------------------
     * socket bind
     ------------------------------------------------*/
    my.sin_family = AF_INET;
    my.sin_addr.s_addr = htonl(INADDR_ANY);
    my.sin_port = htons(atoi(my_port));

    _IF_RAISE( (ret = sciBind( phsock,
                                    (struct sockaddr *)&my,
                                    sizeof(my) ))
                    != 0, BIND_FAIL );

    while( exit_thr == 0 )
    {
        sleep(1);
    }

    sciClose( phsock );

    return 0;

    _EXCEPTION( SOCK_CREATE_FAIL )
    {
        printf("socket creation fail : %s\n", strerror(errno));
    }
    _EXCEPTION( BIND_FAIL )
    {
        printf("bind fail : %s\n", strerror(errno));
    }
    _EXCEPTION( SET_SOCKOPT_FAIL )
    {
        printf("setsockopt fail : %s\n", strerror(errno));
    }
    _EXCEPTION( ERROR )
    {
    }
    _EXCEPTION_END;

    return -1;
}
