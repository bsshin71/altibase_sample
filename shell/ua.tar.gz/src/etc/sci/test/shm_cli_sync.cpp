#include <SCI.h>
#include <demo_env.h>

int       cnt      = 0;
int       iter     = 0;
int       exit_thr = 0;
int       stat_f   = 1;
PHTIMER   timer;


void event_callback( int     event_type,
                     void  * param )
{
    cnt = 0;
}


int main( int argc, char * argv[] )
{
    int            i, rc;
    int            ret;
    int            opt;
    PHSOCKET       sender;
    PHSOCKET       receiver;

    int            polling_type  = 0;          /* 0 : select, 1 : poll, 2 : epoll */
    size_t         shm_size = 1 * 1024 * 1024; /* 10 M */

    char           sendbuf[MSG_SIZE];
    char           recvbuf[MSG_SIZE];

    struct timeval       timeout;
    struct sockaddr_un   bind;

    if( argc < 2 )
    {
        printf("Usage : %s [iteration count]\n", argv[0]);
        exit(1);
    }

    while( (opt = getopt(argc, argv, "n")) != EOF )
    {
        switch( opt )
        {
            case 'n' : stat_f = 0; break;
            default  : break;
        }
    }

    iter = atoi(argv[1]);

    /*------------------------------------------------
     * get environment values for demo
     ------------------------------------------------*/
    _IF_RAISE( get_env() < 0, ERROR );


    /* send socket */
    {
        /*------------------------------------------------
         * socket creation - handle
         ------------------------------------------------*/
        _IF_RAISE( (sender = sciSocket( AF_IPC,
                                             SOCK_STREAM,
                                             0))
                        == NULL, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( sender,
                                             SOL_COMMON,
                                             SO_EVENT_CB,
                                             (void *)event_callback,
                                             sizeof(&event_callback)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( sender,
                                             SOL_COMMON,
                                             SO_EVENT_PARAM,
                                             (void *)sender,
                                             sizeof(sender)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( sender,
                                             SOL_COMMON,
                                             SO_POLLING_TYPE,
                                             (void *)&polling_type,
                                             sizeof(polling_type)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( sender,
                                             SOL_IPC,
                                             SO_SHM_SIZE,
                                             (void*)&shm_size,
                                             sizeof(shm_size)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( sender,
                                             SOL_IPC,
                                             SO_LOCK_EVENT_TYPE,
                                             (void*)&de.lock_type,
                                             sizeof(de.lock_type)))
                        != 0, ERROR );

        /*------------------------------------------------
         * socket bind
         ------------------------------------------------*/
        strcpy( bind.sun_path, "/tmp/shm_unicast_b" );

        _IF_RAISE( (ret = sciConnect( sender,
                                           (struct sockaddr *)&bind,
                                           sizeof(bind)))
                        != 0, ERROR );
    }
    /* receive socket */
    {
        /*------------------------------------------------
         * socket creation - handle
         ------------------------------------------------*/
        _IF_RAISE( (receiver = sciSocket( AF_IPC,
                                               SOCK_STREAM,
                                               0))
                        == NULL, ERROR );

        /*------------------------------------------------
         * set socket option
         ------------------------------------------------*/
        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_EVENT_CB,
                                             (void *)event_callback,
                                             sizeof(&event_callback)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_EVENT_PARAM,
                                             (void *)receiver,
                                             sizeof(receiver)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_RECV_POLL,
                                             (void*)&de.polling_cnt,
                                             sizeof(de.polling_cnt)) )
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_RECV_POLL,
                                             (void*)&de.polling_cnt,
                                             sizeof(de.polling_cnt)))
                        != 0, ERROR );

        /* set socket to block mode */
        timeout.tv_sec  = 3;
        timeout.tv_usec = 0;

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_COMMON,
                                             SO_SYNC_RECV,
                                             (void*)&timeout,
                                             sizeof(timeout)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_IPC,
                                             SO_SHM_SIZE,
                                             (void*)&shm_size,
                                             sizeof(shm_size)))
                        != 0, ERROR );

        _IF_RAISE( (rc = sciSetSockOpt( receiver,
                                             SOL_IPC,
                                             SO_LOCK_EVENT_TYPE,
                                             (void*)&de.lock_type,
                                             sizeof(de.lock_type)))
                        != 0, ERROR );


        /*------------------------------------------------
         * socket bind
         ------------------------------------------------*/
        strcpy( bind.sun_path, "/tmp/shm_unicast_a" );

        _IF_RAISE( (rc = sciBind( receiver,
                                       (struct sockaddr *)&bind,
                                       sizeof(bind)))
                        != 0, ERROR );
    }

    sleep(1);

    if( stat_f )
    {
        timer = init_timer( de.t_unit, de.t_start, de.t_interval, 20);
        _IF_RAISE( timer == NULL, ERROR );
    }

    for( i = 0; i < iter; i++ )
    {
        if( stat_f ) rc = start_timer( timer );

        /*------------------------------------------------
         * send first packet
         ------------------------------------------------*/
        memset( sendbuf, 'A', sizeof(sendbuf) );
        memcpy( sendbuf, &i, sizeof(i));

        _IF_RAISE( (ret = sciSend( sender,
                                        sendbuf,
                                        sizeof(sendbuf),
                                        0 ))
                        != sizeof(sendbuf), SEND_ERROR );

        /*------------------------------------------------
         * recv packet
         ------------------------------------------------*/
        _IF_RAISE( (ret = sciRecv( receiver,
                                        recvbuf,
                                        sizeof(recvbuf),
                                        0 ))
                        != sizeof(recvbuf), RECV_ERROR );

        if( stat_f ) rc = end_timer( timer );

        ret = *(int *)recvbuf;

        if( ret != i )
        {
            printf("invalid return value. [%d:%d]\n", i, ret );
            _RAISE( ERROR );
        }

        if( i % de.p_count == 0 )
        {
            printf("[Round Trip Count] ............... %d\n", i);
        }

        if( de.inter_sleep > 0 )
        {
            sleep_micro( de.inter_sleep ); 
        }
    }

    if( stat_f ) rc = elapse_timer( timer, iter );

    ret = sciClose( sender );
    ret = sciClose( receiver );

    return RC_SUCCESS;

    _EXCEPTION( ERROR )
    {
        printf("error : %s\n", strerror(errno));
    }
    _EXCEPTION( SEND_ERROR )
    {
        printf("send error : %s\n", strerror(errno));
    }
    _EXCEPTION( RECV_ERROR )
    {
        printf("recv error : %s\n", strerror(errno));
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}
