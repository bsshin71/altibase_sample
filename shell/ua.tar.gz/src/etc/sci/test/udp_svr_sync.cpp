#include <SCI.h>
#include <demo_env.h>

int    exit_thr = 0;
char   peer_addr[32];
char   my_port[32];  /* peer port = my port + 1 */
int    stat_f = 1;

struct sockaddr_in   my;
struct sockaddr_in   peer;

void event_callback( int     event_type,
                     void  * param )
{
    exit_thr = 1;
}


int main( int argc, char * argv[] )
{
    int              opt       = 0;
    int              ret       = 0;
    PHSOCKET         phsock    = NULL;
    struct timeval   timeout;
    char             sendbuf[MSG_SIZE];
    char             recvbuf[MSG_SIZE];

    if( argc < 3 )
    {
        printf("\nUsage : %s [peer addr] [my port]\n", argv[0]);
        exit(1);
    }

    while( (opt = getopt(argc, argv, "n")) != EOF )
    {
        switch( opt )
        {
            case 'n' : stat_f = 0; break;
            default  : break;
        }
    }

    /*------------------------------------------------
     * get environment values for demo
     ------------------------------------------------*/
    _IF_RAISE( get_env() < 0, ERROR );

    strcpy( peer_addr, argv[1] );
    strcpy( my_port, argv[2] );

    memset(&peer, 0x0, sizeof(peer));
    peer.sin_family = AF_INET;
    peer.sin_addr.s_addr = inet_addr(peer_addr);
    peer.sin_port = htons(atoi(my_port)+1);

    /*------------------------------------------------
     * socket creation - listen socket handle
     ------------------------------------------------*/
    _IF_RAISE( (phsock = sciSocket( AF_INET,
                                         SOCK_DGRAM,
                                         0))
                    == NULL, SOCK_CREATE_FAIL );

    /*------------------------------------------------
     * set socket option
     ------------------------------------------------*/
    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_EVENT_CB,
                                          (void*)event_callback,
                                          sizeof(&event_callback)))
                    != 0, SET_SOCKOPT_FAIL );

    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_EVENT_PARAM,
                                          (void*)phsock,
                                          sizeof(phsock)))
                    != 0, SET_SOCKOPT_FAIL );

    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_RECV_POLL,
                                          (void*)&de.polling_cnt,
                                          sizeof(de.polling_cnt)) )
                    != 0, SET_SOCKOPT_FAIL );

    timeout.tv_sec  = 100;
    timeout.tv_usec = 0;

    _IF_RAISE( (ret = sciSetSockOpt( phsock,
                                          SOL_COMMON,
                                          SO_SYNC_RECV,
                                          (void*)&timeout,
                                          sizeof(&timeout)))
                    != 0, SET_SOCKOPT_FAIL );

    /*------------------------------------------------
     * socket bind
     ------------------------------------------------*/
    my.sin_family = AF_INET;
    my.sin_addr.s_addr = htonl(INADDR_ANY);
    my.sin_port = htons(atoi(my_port));

    _IF_RAISE( (ret = sciBind( phsock,
                                    (struct sockaddr *)&my,
                                    sizeof(my) ))
                    != 0, BIND_FAIL );

    while( exit_thr == 0 )
    {
        /*------------------------------------------------
         * recv packet 
         ------------------------------------------------*/
        _IF_RAISE( (ret = sciRecv( phsock,
                                        recvbuf,
                                        sizeof(recvbuf),
                                        0))
                        != sizeof(recvbuf), RECV_FAIL );

        memcpy(sendbuf, recvbuf, sizeof(recvbuf));

        /*------------------------------------------------
         * send packet back to client
         ------------------------------------------------*/
        _IF_RAISE( (ret = sciSendTo( phsock,
                                          sendbuf,
                                          sizeof(sendbuf),
                                          0,
                                          (struct sockaddr *)&peer,
                                          sizeof(peer)))
                        != sizeof(sendbuf), SEND_FAIL );
    }

    sciClose( phsock );

    return 0;

    _EXCEPTION( SOCK_CREATE_FAIL )
    {
        printf("socket creation fail : %s\n", strerror(errno));
    }
    _EXCEPTION( BIND_FAIL )
    {
        printf("bind fail : %s\n", strerror(errno));
    }
    _EXCEPTION( SET_SOCKOPT_FAIL )
    {
        printf("setsockopt fail : %s\n", strerror(errno));
    }
    _EXCEPTION( RECV_FAIL )
    {
        printf("recv fail : %s\n", strerror(errno));
    }
    _EXCEPTION( SEND_FAIL )
    {
        printf("send fail : %s\n", strerror(errno));
    }
    _EXCEPTION( ERROR )
    {
    }
    _EXCEPTION_END;

    return -1;
}
