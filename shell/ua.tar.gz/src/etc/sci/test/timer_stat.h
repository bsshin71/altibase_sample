/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   Timer Statistics Library
 ******************************************************************************/
#ifndef __O_TIMER_STAT_H__
#define __O_TIMER_STAT_H__

#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

#ifdef __cplusplus
extern "C"
{
#endif


#define MIN_SECTION_COUNT   1
#define MAX_SECTION_COUNT   20


#define UNIT_DEFAULT     0    
enum unit_type
{
    UNIT_MICRO    = UNIT_DEFAULT,
    UNIT_SEC,
    UNIT_MILI,
    UNIT_NANO
};

struct timer_stat
{
    int             mUnitType;     /* 단위 (SEC, MILI, MICRO, NANO) */
    double          mSum;          /* 전체 시간 합계 - 단위에 따른 시간 */

    int             mBegin;        /* 통계를 보여줄 시간구간의 시작 값 */
    int             mInterval;     /* 통계를 보여줄 시간구간의 간격 */
    int             mSectionCount; /* 몇 개의 시간구간으로 보여줄 것인가 */

    struct timespec mStartTimer;
    struct timespec mEndTimer;

    char          * mTime;
};

typedef struct timer_stat   HTIMER;
typedef HTIMER *              PHTIMER;


PHTIMER init_timer( int, int, int, int );
int start_timer( PHTIMER );
int start_timer2( PHTIMER aTimer, struct timespec * aStart );
int end_timer( PHTIMER );
int elapse_timer( PHTIMER, int );
int final_timer( PHTIMER timer );
int sleep_micro(long usec);


#ifdef __cplusplus
};
#endif


#endif  /* __O_TIMER_STAT_H__ */
