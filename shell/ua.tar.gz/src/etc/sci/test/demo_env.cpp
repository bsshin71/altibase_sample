#include <demo_env.h>

DEMO_ENV   de;

void show_env()
{
    printf("\n");
    printf("--------------------------------------------------------\n");
    printf("   데모 환경 변수 설정                \n");
    printf("--------------------------------------------------------\n");
    printf(" DEMO_PRINT_DEBUG   : 디버그로그 print        : %d\n", de.print_debug);
    printf("                                                  \n");
    printf(" DEMO_TIME_UNIT     : 통계시간 단위           : %d (0:micro, 1:sec, 2:mili, 3:nano)\n", de.t_unit);
    printf(" DEMO_TIME_START    : 시작 통계시간           : %d\n", de.t_start);
    printf(" DEMO_TIME_INTERVAL : 통계시간 간격           : %d\n", de.t_interval);
    printf(" DEMO_PRINT_COUNT   : print round trip count  : %d\n", de.p_count);
    printf("                                                  \n");
    printf(" DEMO_POLL_CNT      : mili 초당 polling 횟수  : %d (0:event wait, -1:busy wait, value:spin wait)\n", de.polling_cnt);
    printf(" DEMO_INTER_SLEEP   : sleep micro seconds     : %d\n", de.inter_sleep);
    printf(" DEMO_LOCK_TYPE     : lock event type (shm)   : %d (0:cond_wait, 1:eventfd, 2:futex))\n", de.lock_type);
    printf("--------------------------------------------------------\n");
    printf("\n");
}

int get_env( void )
{
    char   * item;
    char   * value;


    item = (char *)"DEMO_PRINT_DEBUG";
    if((value = getenv(item)) == NULL)
    {
        de.print_debug = 1;
    }
    else
    {
        de.print_debug = atoi(value);
    }

    /*
    if( de.print_debug ) __f = 1;
    */

    item = (char *)"DEMO_TIME_UNIT";
    if( (value = getenv(item)) == NULL )
    {
        /* default : micro sec */
        de.t_unit = 0;
    }
    else
    {
        de.t_unit = atoi(value);
    }

    item = (char *)"DEMO_TIME_START";
    if( (value = getenv(item)) == NULL )
    {
        /* default : time start for stat */
        de.t_start = 5;
    }
    else
    {
        de.t_start = atoi(value);
    }

    item = (char *)"DEMO_TIME_INTERVAL";
    if( (value = getenv(item))== NULL )
    {
        /* default : time interval for stat */
        de.t_interval = 5;
    }
    else
    {
        de.t_interval = atoi(value);
    }

    item = (char *)"DEMO_PRINT_COUNT";
    if( (value = getenv(item))== NULL )
    {
        /* default : print test count */
        de.p_count = 10000;
    }
    else
    {
        de.p_count = atoi(value);
    }

    item = (char *)"DEMO_POLL_CNT";
    if( (value = getenv(item)) == NULL )
    {
        /* default : busy wait */
        de.polling_cnt = -1;
    }
    else
    {
        de.polling_cnt = atoi(value);
    }

    item = (char *)"DEMO_INTER_SLEEP";
    if( (value = getenv(item)) == NULL )
    {
        /* default : no sleep */
        de.inter_sleep = 0;
    }
    else
    {
        de.inter_sleep = atoi(value);
    }

    item = (char *)"DEMO_LOCK_TYPE";
    if( (value = getenv(item)) == NULL )
    {
        /* default : cond_wait */
        de.lock_type = 0;
    }
    else
    {
        de.lock_type = atoi(value);
    }

    show_env();

    return RC_SUCCESS;
}

int set_log()
{
    /*
    __f = 1;
    */
    return 0;
}
