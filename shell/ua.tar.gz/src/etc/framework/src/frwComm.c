/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/
#include <mvp.h>
#include <frwCommon.h>


/******************************************************************************
 * Name : frwConnectVSG
 *
 * Description
 *     VSG에 연결하기 위한 접속시도만 처리한다.
 *
 * Argument
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
mvp_sint32_t frwConnectVSG()
{
    return RC_SUCCESS;
}


/******************************************************************************
 * Name : frwDisConnectVSG
 *
 * Description
 *     VSG에 단절하기 위한 시도만 처리한다.
 *
 * Argument
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
mvp_sint32_t frwDisConnectVSG()
{
    return RC_SUCCESS;
}


/******************************************************************************
 * Name : frwCheckStatVSG
 *
 * Description
 *     VSG와의 연결상태가 정상인지만 체크하는 용도로 쓴다.
 *
 * Argument
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
mvp_sint32_t frwCheckStatVSG()
{
    return RC_SUCCESS;
}



/******************************************************************************
 * Name : frwSyncSendMsgVSG
 *
 * Description
 *     VSG에게 어떤 데이터를 던질 때 사용한다.
 *     단, VSG에게 메시지를 던진 후 Ack를 받아야 할 경우에만 이걸 쓴다.
 *
 * Argument
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
mvp_sint32_t frwSyncSendMsgVSG()
{
    return RC_SUCCESS;
}


/******************************************************************************
 * Name : frwAsyncSendMsgVSG
 *
 * Description
 *     VSG에게 어떤 데이터를 던질 때 사용한다.
 *     단, VSG에게 메시지를 던진 후 Tcp success만 체크하면 될 경우에만 이걸 쓴다.
 *
 * Argument
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
mvp_sint32_t frwAsyncSendMsgVSG()
{
    return RC_SUCCESS;
}



/******************************************************************************
 * Name : frwAsyncRecvMsgVSG
 *
 * Description
 *     VSG로부터 어떤 데이터를 수신할  때 사용한다.
 *     단, VSG에게 메시지를 수신한 후 Ack를 주지 않아도 될 경우에만 이걸 쓴다.
 *
 * Argument
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
mvp_sint32_t frwAsyncRecvMsgVSG()
{
    return RC_SUCCESS;
}



/******************************************************************************
 * Name : frwSyncRecvMsgVSG
 *
 * Description
 *     VSG로부터 어떤 데이터를 수신할  때 사용한다.
 *     단, VSG에게 메시지를 수신한 후 Ack를 줘야할 경우에만 이걸 쓴다.
 *
 * Argument
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
mvp_sint32_t frwSyncRecvMsgVSG()
{
    return RC_SUCCESS;
}

