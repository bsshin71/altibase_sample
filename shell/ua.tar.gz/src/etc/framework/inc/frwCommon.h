/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
*******************************************************************************/
#include <cmnMessage.h>

#ifndef __O_FRW_COMMON_H__
#define __O_FRW_COMMON_H__


#ifdef __cplusplus
extern "C"
{
#endif

/*--------------------------------------------------------
 * definition
 --------------------------------------------------------*/
#define FRW_DUMMY_LEN   32

/*--------------------------------------------------------
 * structure
 --------------------------------------------------------*/
typedef struct frwEvent
{
    char  msg [MAX_TOPIC_NAME_LEN];
    void  *userFunc;
} frwEvent;

typedef struct frwEnv
{
    char  vmgHost [FRW_DUMMY_LEN];
    int   vmgPort;
} frwEnv;



#ifdef __cplusplus
};
#endif

#endif  /* __O_FRW_COMMON_H__ */
