/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   utility functions
 ******************************************************************************/
#include "cmnUtil.h"
#include "cmnHeader.h"

mvp_pid_t _cmn_pid = -1;
__thread mvp_pid_t _cmn_tid = -1;
__thread pthread_t _cmn_thrid = 0;


/******************************************************************************
 * 공통 util (일반)
******************************************************************************/
// 입력값에 가장 가까운 큰 2의 제곱근 구함
long long cmnGetBuddy (long long aInput)
{
    int     i = 0 ;
    long long tmp = aInput;

    while ( 1 )
    {
        tmp = tmp / 2 ;
        if ( tmp == 0 )
        {
            break;
        }

        i++;
    }

    if ( cmnGetSquare(i) == aInput )
    {
        return cmnGetSquare(i);
    }
    else
    {
        return cmnGetSquare(i+1);
    }
}


long long cmnGetSquare ( int i )
{
    if ( i == 0 )
    {
        return 1;
    }
    else
    {
        return cmnGetSquare(i-1) * 2 ;
    }
}


int g_signal_fd = -1;

/*
 * 2015.02.27 -okt-
 * GCC 4.8.2 환경에서 컴파일 워닝 제거를 위해 (void) 추가를 했으나 효과가 없어서.
 * makefile 에서 CFLAGS += -Wno-unused-result 추가함.
 */
#define SIG_PRT(a)              { char buf[] = a; (void)write ( g_signal_fd, buf, sizeof(buf)-1 ); }
#define SIG_PRT2(buf,len)       { (void)write ( g_signal_fd, buf, len ); }
#define SIG_ECHO(buf,len)       { (void)write ( 2, buf, len ); SIG_PRT2(buf,len); }
#define SIG_STRCPY(dst,src,pos) { char buf[] = src; memcpy ( dst, buf, sizeof(buf)-1 ); pos += sizeof(buf)-1; }

/*
 * Call Stack 을 찍어주는 함수.
 * 빌드 시 -rdynamic 옵션을 주어야 함.
 * signal-safe 하지않은 api가 있으므로, 수행중 다시 시그널 발생하여 루핑돌 수 있다.
 */
#ifdef __linux__
_VOID cmnCallStack ( int sig )
{
    void*   sStack[128];
    int     sStackSize;
    char**  sStackSymbol = NULL;
    char    sBuf[4096];
    char*   pBuf = NULL;
    int     sPos = 0;
    int     i, j;

    _TRY
    {

        if ( g_signal_fd == -1 )
        {
            if ( cmnLogManager::m_ulogFd > 0 )
                g_signal_fd = cmnLogManager::m_ulogFd;
            else
                g_signal_fd = 1; // stdout
        }
        else
        {
            // 중복진입
            _RETURN;
        }

        int sPID = getpid_s();
        int sTID = gettid_s();

        // 1. 최소한 시그널 번호는 안전하게 기록한다.
        sPos = 0;
        SIG_STRCPY ( sBuf, "\n(E) Signal handler Start.. ( sig=", sPos );
        sBuf[sPos++] = sig / 10 + '0';
        sBuf[sPos++] = sig % 10 + '0';
        SIG_STRCPY ( sBuf + sPos, ", pid=", sPos );
        sBuf[sPos++] = sPID / 10000 + '0'; sPID = sPID % 10000;
        sBuf[sPos++] = sPID / 1000  + '0'; sPID = sPID % 1000;
        sBuf[sPos++] = sPID / 100   + '0'; sPID = sPID % 100;
        sBuf[sPos++] = sPID / 10    + '0'; sPID = sPID % 100;
        sBuf[sPos++] = sPID % 10    + '0';
        SIG_STRCPY ( sBuf + sPos, ", tid=", sPos );
        sBuf[sPos++] = sTID / 10000 + '0'; sTID = sTID % 10000;
        sBuf[sPos++] = sTID / 1000  + '0'; sTID = sTID % 1000;
        sBuf[sPos++] = sTID / 100   + '0'; sTID = sTID % 100;
        sBuf[sPos++] = sTID / 10    + '0'; sTID = sTID % 100;
        sBuf[sPos++] = sTID % 10    + '0';
        SIG_STRCPY ( sBuf + sPos, " )\n", sPos );
        SIG_PRT2( sBuf, sPos );

        sStackSize = backtrace ( sStack, 128 );
        sStackSymbol = backtrace_symbols ( sStack, sStackSize );

        sPos = 0;
        pBuf = sBuf;
        for ( i = 2; i < sStackSize; ++i )
        {
            sPos += sprintf ( pBuf + sPos, "%s\n", sStackSymbol[i] );
        }

        SIG_PRT ( "======= Backtrace: =========\n" );
        SIG_ECHO( sBuf, sPos );


        // /proc/<pid>/maps 남겨 소스라인 획득. ( *.so 의 경우. 런타임에 코드영역 주소가 달라짐 )
        {
            int     sMapFd = -1;
            int     sReadLen = 0;
            char    sRBuf[4096];
            char    sLineBuf[1024];
            int     sLinePos = 0;

            SIG_PRT ( "======= Memory map: ========\n" );
            snprintf ( sLineBuf, sizeof(sLineBuf), "/proc/%d/maps", getpid() );
            sMapFd = open ( sLineBuf, O_RDONLY );
            if ( sMapFd < 0 )
            {
                SIG_PRT ( "(W) proc map file open fail.\n" );
                _RETURN;
            }

            pBuf = sBuf;
            while (1)
            {
                sPos = 0;

                sReadLen = read ( sMapFd, sRBuf, sizeof(sRBuf) - 1 );
                if ( sReadLen == 0 )
                {
                    _RETURN;
                }

                sLinePos = 0;
                for ( i = 0; i < sReadLen; i++ )
                {
                    sLineBuf[sLinePos++] = sRBuf[i];
                    if ( sRBuf[i] == (unsigned char)'\n' )
                    {
                        for ( j = 0; j < sLinePos - 3; j++ )
                        {
#if 0
// 00400000-00419000 r-xp 00000000 fd:02 2890168                            /home/paul/workspace/trunk.svn/src/goldilocks/unitTest/SegmentManager/testSegmentManager
// 3fda600000-3fda78b000 r-xp 00000000 fd:00 1835470                        /lib64/libc-2.12.so
// 7f9d54301000-7f9d55c2f000 rw-s 00000000 00:10 1465781                    /dev/shm/paul/TEST_000
#endif
                            if ( *(int*)( sLineBuf + j ) == *(int*)"r-xp"
#if 0 //def _DEBUG
                                    // 디버그에서는 유효하지 않은 주소값이 어떤 SHM에 해당되는지 보기 위해서 로깅.
                                    || *(int*)( sLineBuf + j ) == *(int*)"rw-s"
#endif
                                    )
                            {
                                memcpy ( pBuf + sPos, sLineBuf, sLinePos );
                                sPos += sLinePos;
                                break;
                            }
                        }
                        sLinePos = 0;
                    }
                } /* for */

                SIG_PRT2 ( pBuf, sPos );
            } /* while */
        } /* maps */

    }
    _CATCH
    {
        // 죽는 상황에선 어쩔수 없다.
    }
    _FINALLY
    {
        free ( sStackSymbol );
    }
    _END
}
#else
_VOID cmnCallStack ( int sig )
{
    //assert( 0 && "[WIN32] not yet supported" );
	_PRT( "(%s:%d) [WIN32] not yet supported\n", __FUNCTION__, __LINE__ );
    return 0;
}
#endif

// 성공시 '1'만 리턴하도록 수정.
_BOOL isalpha_s ( int c )
{
    return ( isalpha ( c ) == FALSE ? FALSE : TRUE );
}

/**
 * cmnIsDigit
 *
 * @brief
 *      문자열이 0-9 로만 구성되었는지 검사한다.
 *
 * @param aStr      검사대상 문자열
 * @return
 *      TRUE (1)    : 성공
 *      FALSE(0)    : 실패
 */
_BOOL cmnIsDigit ( char* aStr )
{
    int     sLen;
    int     i;

    _TRY
    {
        if ( aStr == NULL )
        {
            return FALSE;
        }

        sLen = strlen_s ( aStr );
        for ( i = 0; i < sLen; i++ )
        {
            //if ( isdigit ( aStr[i] ) != TRUE ) // 주의) 이코드는 안됨. 1외의 값이 리턴됨.
            if ( isdigit ( aStr[i] ) == 0 )
            {
                return FALSE;
            }
        }
    }
    _CATCH
    _FINALLY
    _ENDBOOL
}


/******************************************************************************
 * 공통 util (시간)
******************************************************************************/
__thread char* _cmn_Time2Str = NULL;
static char* cmnTime2StrLib ( int aFmtLen, char* pDst, int flag, struct timeval* input_time, bool bNTS )
{
    struct timeval tv;
    struct tm now;
    int sNeedLen = 0;
    int ix = 0;

    _TRY
    {
        if ( pDst == NULL )
        {
            if ( _cmn_Time2Str == NULL )
                _cmn_Time2Str = (char*)malloc_s ( 32 );
            pDst = _cmn_Time2Str;
        }
        // 길이 검증
        {
            if ( flag == TIME_FMT_ANY )
            {
                int x = 0;
                if ( bNTS )
                    x = 1;

                if ( likely( aFmtLen == x + 8 ) ) flag = TIME_FMT_DO;
                else if ( unlikely ( aFmtLen == x + 10 ) ) flag = TIME_FMT_DO_DELI    ;
                else if ( unlikely ( aFmtLen == x + 14 ) ) flag = TIME_FMT_DT_F0      ;
                else if ( unlikely ( aFmtLen == x + 19 ) ) flag = TIME_FMT_DT_F0_DELI ;
                else if ( unlikely ( aFmtLen == x + 17 ) ) flag = TIME_FMT_DT_F3      ;
                else if ( unlikely ( aFmtLen == x + 23 ) ) flag = TIME_FMT_DT_F3_DELI ;
                else if ( unlikely ( aFmtLen == x + 20 ) ) flag = TIME_FMT_DT_F6      ;
                else if (   likely ( aFmtLen == x + 26 ) ) flag = TIME_FMT_DT_F6_DELI ; // 로그출력용 포맷
                else if ( unlikely ( aFmtLen == x +  6 ) ) flag = TIME_FMT_TM_F0      ;
//              else if ( unlikely ( len == x +  8 ) ) flag = TIME_FMT_TM_F0_DELI ; // 중복으로 사용할수없다.
                else if ( unlikely ( aFmtLen == x +  9 ) ) flag = TIME_FMT_TM_F3      ;
                else if ( unlikely ( aFmtLen == x + 11 ) ) flag = TIME_FMT_TM_F3_DELI ;
                else if ( unlikely ( aFmtLen == x + 12 ) ) flag = TIME_FMT_TM_F6      ;
                else if ( unlikely ( aFmtLen == x + 15 ) ) flag = TIME_FMT_TM_F6_DELI ;
            }
            else
            {
                // 도달하지 않음. 의도는 내부함수를 직접 접근한 경우 길이 검사.
                switch ( flag )
                {
                    // 하드코딩 - 더 좋은 방법 없나?
                    case TIME_FMT_DO         : sNeedLen =  8; break;
                    case TIME_FMT_DO_DELI    : sNeedLen = 10; break;
                    case TIME_FMT_DT_F0      : sNeedLen = 14; break;
                    case TIME_FMT_DT_F0_DELI : sNeedLen = 19; break;
                    case TIME_FMT_DT_F3      : sNeedLen = 17; break;
                    case TIME_FMT_DT_F3_DELI : sNeedLen = 23; break;
                    case TIME_FMT_DT_F6      : sNeedLen = 20; break;
                    case TIME_FMT_DT_F6_DELI : sNeedLen = 26; break;
                    case TIME_FMT_TM_F0      : sNeedLen =  6; break;
                    case TIME_FMT_TM_F0_DELI : sNeedLen =  8; break;
                    case TIME_FMT_TM_F3      : sNeedLen =  9; break;
                    case TIME_FMT_TM_F3_DELI : sNeedLen = 11; break;
                    case TIME_FMT_TM_F6      : sNeedLen = 12; break;
                    case TIME_FMT_TM_F6_DELI : sNeedLen = 15; break;
                    default:
                        _THROW( -1 );
                        break;
                }
                if ( bNTS ) sNeedLen++;
                if ( aFmtLen < sNeedLen ) _THROW ( -1 );
            }
        }

        if ( input_time == NULL )
        {
            _CALL ( gettimeofday ( &tv, 0 ) );
        }
        else
        {
            tv.tv_sec = input_time->tv_sec;
            tv.tv_usec = input_time->tv_usec;
        }

        // [WIN64] cannot convert 'long int*' to 'const time_t* {aka const long long int*}' for argument '1' to 'tm* localtime(const time_t*)'
        if ( localtime_r_s ( &tv.tv_sec, &now ) == NULL )
        //if ( localtime_r_s ( (const time_t*)&tv.tv_sec, &now ) == NULL )
        {
            _THROW( -1 );
        }

        ix = 0;
        // flag 가 TIME_FMT_TM_F0 보다 작은 경우에만 '날짜' 추출이 필요
        if ( flag < TIME_FMT_TM_F0 )
        {
            int Y4 = ( now.tm_year + 1900 ) / 1000;
            int Y3 = ( now.tm_year + 1900 - Y4 * 1000 ) / 100;
            int Y2 = ( now.tm_year + 1900 - Y4 * 1000 - Y3 * 100 ) / 10;
            int Y1 = ( now.tm_year + 1900 - Y4 * 1000 - Y3 * 100 - Y2 * 10 );
            int M2 = ( now.tm_mon + 1 ) / 10;
            int D2 = ( now.tm_mday ) / 10;

            pDst[ix++] = '0' + Y4;
            pDst[ix++] = '0' + Y3;
            pDst[ix++] = '0' + Y2;
            pDst[ix++] = '0' + Y1;

            // [note] 홀수 값이 xx_DELI 구분자 있는 형태임.
            if ( flag % 2 == 1 ) pDst[ix++] = '/';
            pDst[ix++] = '0' + M2;
            pDst[ix++] = '0' + ( now.tm_mon + 1 - ( M2 * 10 ) );
            if ( flag % 2 == 1 ) pDst[ix++] = '/';
            pDst[ix++] = '0' + D2;
            pDst[ix++] = '0' + ( now.tm_mday - ( D2 * 10 ) );

            // date only 포맷의 경우 여기서 종료
            if ( flag == TIME_FMT_DO || flag == TIME_FMT_DO_DELI ) _RETURN;

            if ( flag % 2 == 1 ) pDst[ix++] = ' ';
        }

        int h2 = now.tm_hour / 10;
        int m2 = now.tm_min / 10;
        int s2 = now.tm_sec / 10;

        pDst[ix++] = '0' + h2;
        pDst[ix++] = '0' + ( now.tm_hour - ( h2 * 10 ) );
        if ( flag % 2 == 1 ) pDst[ix++] = ':';
        pDst[ix++] = '0' + m2;
        pDst[ix++] = '0' + ( now.tm_min - ( m2 * 10 ) );
        if ( flag % 2 == 1 ) pDst[ix++] = ':';
        pDst[ix++] = '0' + s2;
        pDst[ix++] = '0' + ( now.tm_sec - ( s2 * 10 ) );

        switch ( flag )
        {
            case TIME_FMT_DO         :
            case TIME_FMT_DO_DELI    :
            case TIME_FMT_DT_F0      :
            case TIME_FMT_DT_F0_DELI :
            case TIME_FMT_TM_F0      :
            case TIME_FMT_TM_F0_DELI :
                return pDst;
                break;
        }

        switch ( flag )
        {
            case TIME_FMT_DT_F3      :
            case TIME_FMT_DT_F3_DELI :
            case TIME_FMT_DT_F6      :
            case TIME_FMT_DT_F6_DELI :
            case TIME_FMT_TM_F3      :
            case TIME_FMT_TM_F3_DELI :
            case TIME_FMT_TM_F6      :
            case TIME_FMT_TM_F6_DELI :
            {
                int us = tv.tv_usec / 1000;
                int n6 = us / 100;
                int xx = us - ( n6 * 100 );
                int n5 = ( xx ) / 10;
                int n4 = ( xx - n5 * 10 );

                if ( flag % 2 == 1 ) pDst[ix++] = '.';
                pDst[ix++] = '0' + n6;
                pDst[ix++] = '0' + n5;
                pDst[ix++] = '0' + n4;

                if ( flag == TIME_FMT_DT_F3 || flag == TIME_FMT_DT_F3_DELI
                     || flag == TIME_FMT_TM_F3 || flag == TIME_FMT_TM_F3_DELI )
                {
                    return pDst;
                }
            }
                break;
        }

        switch ( flag )
        {
            case TIME_FMT_DT_F6      :
            case TIME_FMT_DT_F6_DELI :
            case TIME_FMT_TM_F6      :
            case TIME_FMT_TM_F6_DELI :
            {
                int us = tv.tv_usec - ( tv.tv_usec / 1000 ) * 1000;
                int n3 = us / 100;
                int xx = us - ( n3 * 100 );
                int n2 = ( xx ) / 10;
                int n1 = ( xx - n2 * 10 );
                if ( ix < aFmtLen )
                    pDst[ix++] = '0' + n3;
                if ( ix < aFmtLen )
                    pDst[ix++] = '0' + n2;
                if ( ix < aFmtLen )
                    pDst[ix++] = '0' + n1;
            }
                break;
        }

        // 성공이고 bNTS flag가 있으면
        if ( bNTS )
        {
            pDst[ix++] = 0x00;
        }
        return pDst;
    }
    _CATCH
    {
        DBM_ERR ( "error flag=%d, len=%d,%d, rc=%d (err=%d)", flag, aFmtLen, sNeedLen, _rc, errno );
        _DASSERT( 0 );
    }
    _FINALLY
    _ENDNULL
}

char* cmnTime2Str ( int aFmtLen, char* pDst, int flag, struct timeval* input_time )
{
    return cmnTime2StrLib ( aFmtLen, pDst, flag, input_time, true );
}

// [note] 혼동의 여기가 있지만. 통상 NTS가 자주사용된다고 보고, '<함수명>N' 인 형태를 Non-NTS 의미로 사용
char* cmnTime2StrN ( int aFmtLen, char* pDst, int flag, struct timeval* input_time )
{
    return cmnTime2StrLib ( aFmtLen, pDst, flag, input_time, false );
}


void cmnUSleep ( long long uSec )
{
    struct timespec start, end;
    long long nSec = uSec * 1000;
    long long sDiff = 0;

    _TRY
    {
        _DASSERT( uSec >= 0 );

        _CALL ( clock_gettime_s ( CLOCK_REALTIME, &start ) );

        if ( nSec > CMN_YSLEEP_DEGREE )
        {
            pthread_yield_s ( );
        }
        _CALL( clock_gettime_s ( CLOCK_REALTIME, &end ) );

        while ( ( sDiff = ( end.tv_sec - start.tv_sec ) * 1000000000 + ( end.tv_nsec - start.tv_nsec ) ) < nSec )
        {
            if ( nSec > CMN_USLEEP_DEGREE + sDiff )
            {
                // 나누기 연산.
                usleep ( CMN_USLEEP_DEGREE / 1000 );
            }
            else if ( nSec > CMN_YSLEEP_DEGREE + sDiff )
            {
            	pthread_yield_s ( );
            }
            else if ( nSec > CMN_NSLEEP_DEGREE + sDiff )
            {
                cpu_relax ( );
            }
            else
            {
                _RETURN;
            }

            _CALL( clock_gettime_s ( CLOCK_REALTIME, &end ) );
        }
    }
    _CATCH
    {
        _CATCH_TRC;
    }
    _FINALLY
    _ENDVOID
}

void cmnNanoSleep ( long long nSec )
{
    _TRY
    {
        if ( nSec > CMN_YSLEEP_DEGREE * 2 )
        {
            cmnUSleep ( (long long) ( nSec / 1000 ) );
            return; // 의도적
        }
        else
        {
            struct timespec start, end;
            long long sDiff = 0;

            _CALL ( clock_gettime_s ( CLOCK_REALTIME, &start ) );

            if ( nSec > CMN_NSLEEP_DEGREE )
            {
                cpu_relax ( );
            }
            _CALL( clock_gettime_s ( CLOCK_REALTIME, &end ) );

            while ( ( sDiff = ( end.tv_sec - start.tv_sec ) * 1000000000 + ( end.tv_nsec - start.tv_nsec ) ) < nSec )
            {
                if ( nSec > CMN_NSLEEP_DEGREE + sDiff )
                {
                    cpu_relax ( );
                }
                else
                {
                    _RETURN;
                }

                _CALL( clock_gettime_s ( CLOCK_REALTIME, &end ) );
            }
        }
    }
    _CATCH
    {
        _CATCH_TRC;
    }
    _FINALLY
    _ENDVOID
}

/******************************************************************************
 * 시스템 콜 래퍼
******************************************************************************/

mvp_pid_t getpid_s ( )
{
    if ( _cmn_pid == -1 )
    {
        _cmn_pid = getpid();
    }
    return _cmn_pid;
}

mvp_pid_t gettid_s ( )
{
    if ( _cmn_tid == -1 )
    {
#ifdef __linux__
        _cmn_tid = syscall (SYS_gettid);
#else
        _cmn_tid = getpid();
#endif /* __linux__ */

    }
    return _cmn_tid;
}

pthread_t pthread_self_s ( )
{
    if ( _cmn_thrid <= 0 )
    {
        _cmn_thrid = pthread_self();
    }
    return _cmn_thrid;
}


#ifdef __linux__	//TODO: [OKT]  윈도포팅

/*
 * dlopen - dlsym
 *
 * thread 동시성이 없으므로 락을 잡는다.
 */
pthread_mutex_t g_cmnDlopen_mtx  = PTHREAD_MUTEX_INITIALIZER;

_VOID cmnDlopen ( const char* aLibName, void** ppHandle )
{
    int     sErrno = 0;
    int     sLockF = 0;

    _TRY
    {
        _CALL ( cmnLockMutex ( &g_cmnDlopen_mtx ) );
        sLockF = 1;

#if !defined(__linux__) && !defined(RTLD_NOW)
#define RTLD_NOW	0
#endif
        *ppHandle = dlopen ( aLibName,  RTLD_NOW );
//      *ppHandle = dlopen ( aLibName,  RTLD_LAZY );

        if ( *ppHandle == NULL )
        {
            sErrno = errno;
            DBM_ERR ( "dlopen fail. name=%s (%s) (err=%d,tid=%d)", aLibName, dlerror(), sErrno, gettid_s() );
            _THROW ( -1 );
        }
    }
    _CATCH
    _FINALLY
    {
        if ( sLockF == 1 )
            cmnUnlockMutex ( &g_cmnDlopen_mtx );
    }
    _END
}

_VOID cmnDlsym ( void* aHandle, const char* aFuncName, void** ppFunc )
{
    int     sErrno = 0;
    int     sLockF = 0;

    _TRY
    {
        _CALL ( cmnLockMutex ( &g_cmnDlopen_mtx ) );
        sLockF = 1;

        *ppFunc = (void*) dlsym ( aHandle, (char*) aFuncName );

        if ( *ppFunc == NULL )
        {
            sErrno = errno;
            DBM_ERR ( "dlsym fail. name=%s (%s) (err=%d,tid=%d)", aFuncName, dlerror(), sErrno, gettid_s() );
            _THROW( -1 );
        }
    }
    _CATCH
    _FINALLY
    {
        if ( sLockF == 1 )
            cmnUnlockMutex ( &g_cmnDlopen_mtx );
    }
    _END
}

_VOID cmnDlclose ( void* aHandle )
{
    int     sErrno = 0;
    int     sLockF = 0;

    _TRY
    {
        _CALL ( cmnLockMutex ( &g_cmnDlopen_mtx ) );
        sLockF = 1;

        _rc = dlclose ( aHandle );

        if ( _rc != 0 )
        {
            sErrno = errno;
            DBM_ERR ( "dlclose fail. rc=%s (%s) (err=%d,tid=%d)", _rc, dlerror(), sErrno, gettid_s() );
            _THROW( -1 );
        }
    }
    _CATCH
    _FINALLY
    {
        if ( sLockF == 1 )
            cmnUnlockMutex ( &g_cmnDlopen_mtx );
    }
    _END
}

#endif /* __linux__ */

/*
 * etc
 */
_VOID cmnAccess ( char* pathname, int mode )
{
    int     sLen;
    int     sFd;
    int     sErrno = errno;

    _TRY
    {
        // directory check
        sLen = strnlen ( pathname, DBM_FILE_NAME_LEN );
        if ( pathname[sLen - 1] == '/')
            pathname[sLen - 1] = 0;

        errno = 0;

#ifdef __linux__
        //TODO: [윈도포팅] O_DIRECTORY 지원안됨.
        sFd = open ( pathname, O_DIRECTORY  );
        if ( sFd < 0 )
        {
            if ( errno != ENOENT )  // ENOENT = 2
            {
                DBM_DBG ( "open fail, %s (err=%d)", pathname, errno );
            }
            _THROW ( -1 );
        }
        close_s ( sFd );
#endif /* __linux__ */

        // [note] 디렉토리가 아닌 파일일 수도 있음. (알려진 버그)
        _CALL ( access ( pathname, mode ) );
    }
    _CATCH
    _FINALLY
    {
        // 백업한 errno를 다시 복구해줌. ( 사용자 모듈에서 실수 코딩에도 약간 대응하기위해 )
        if ( errno == ENOENT )
            errno = sErrno;
    }
    _END
}

// strncpy 의 경우 맨뒤의 NULL 이 보장되지 않음
#ifndef _OKT_TRC_CALLER
char* cmnStrCpy ( char *dest , const char *src , size_t len )
{
    size_t sLen = strnlen ( src, len );
    if ( sLen >= len )
        sLen = len - 1;

    memcpy_s ( dest, src, sLen );
    ( (char*)dest )[sLen] = 0x00;
    return dest;
}
#endif


/******************************************************************************
 * 시스템 콜 래퍼 ( 성능 )
******************************************************************************/

#ifdef _DEBUG
struct PerfCount g_cnt_perf = { 0, 0, 0,   0, 0, 0, 0, 0,   0, 0, 0, 0, 0,   0, 0, 0, 0, 0 };
#endif /* _DEBUG */


#ifdef _OKT_TRC_CALLER

#include <string>
#include <map>
//using namespace std;

typedef struct PerfMap
{
    std::map<std::string,long long> tkill;
    std::map<std::string,long long> pthread_yield;
    std::map<std::string,long long> pthread_yield_d;     // 실제 pthread_yield 호출없이 retry 횟수 측정.

    std::map<std::string,long long> memset;
    std::map<std::string,long long> malloc;
    std::map<std::string,long long> memcpy;
    std::map<std::string,long long> memcmp;
    std::map<std::string,long long> memmove;

    std::map<std::string,long long> strlen;
    std::map<std::string,long long> strcmp;
    std::map<std::string,long long> strncmp;
    std::map<std::string,long long> strcpy;
    std::map<std::string,long long> strncpy;
} PerfMap;

typedef struct PerfMapLock
{
    volatile int tkill;
    volatile int pthread_yield;
    volatile int pthread_yield_d;

    volatile int memset;
    volatile int malloc;
    volatile int memcpy;
    volatile int memcmp;
    volatile int memmove;

    volatile int strlen;
    volatile int strcmp;
    volatile int strncmp;
    volatile int strcpy;
    volatile int strncpy;
} PerfMapLock;

PerfMap g_map_perf;
PerfMapLock g_map_lock = { -1, -1, -1,   -1, -1, -1, -1, -1,   -1, -1, -1, -1, -1 };


int tkill_s_ ( mvp_pid_t tid, int sig, const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;
    int     rc;

    atomic_inc_s ( & g_cnt_perf.tkill );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.tkill.find (zTmp);

    if ( unlikely ( iter == g_map_perf.tkill.end () ) )
    {
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.tkill, sLockTid, -1 ) )
        {
            pthread_yield_s();
            goto J1;
        }

        g_map_perf.tkill[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.tkill, -1, sLockTid );
    }
    else
    {
        g_map_perf.tkill[zTmp]++;
    }

    rc = syscall ( SYS_tkill, tid, sig );

    return rc;
}


int pthread_yield_s_ ( const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;

    atomic_inc_s ( & g_cnt_perf.pthread_yield );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.pthread_yield.find (zTmp);

    if ( unlikely ( iter == g_map_perf.pthread_yield.end () ) )
    {
        sLockTid = gettid_s ( );
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.pthread_yield, sLockTid, -1 ) )
        {
            // [윈도포팅] 사실 sched_yield 로 통일해도 차이가 없을 것임.
#ifdef __linux__
            pthread_yield();
#else
            sched_yield();
#endif /* __linux__ */
            goto J1;
        }

        g_map_perf.pthread_yield[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.pthread_yield, -1, sLockTid );
    }
    else
    {
        g_map_perf.pthread_yield[zTmp]++;
    }

#ifdef __linux__
    return pthread_yield();
#else
    return sched_yield();
#endif /* __linux__ */
}


int pthread_yield_d_ ( const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;

    atomic_inc_s ( & g_cnt_perf.pthread_yield_d );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.pthread_yield_d.find (zTmp);

    if ( unlikely ( iter == g_map_perf.pthread_yield_d.end () ) )
    {
        sLockTid = gettid_s ( );
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.pthread_yield, sLockTid, -1 ) )
        {
            pthread_yield_s();
            goto J1;
        }

        g_map_perf.pthread_yield_d[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.pthread_yield_d, -1, sLockTid );
    }
    else
    {
        g_map_perf.pthread_yield_d[zTmp]++;
    }

    return 0;
}


void* memset_s_ ( void *dest , int cSrc , size_t len, const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;

    atomic_inc_s ( & g_cnt_perf.memset );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.memset.find (zTmp);

    if ( unlikely ( iter == g_map_perf.memset.end () ) )
    {
        sLockTid = gettid_s ( );
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.memset, sLockTid, -1 ) )
        {
            pthread_yield_s();
            goto J1;
        }

        g_map_perf.memset[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.memset, -1, sLockTid );
    }
    else
    {
        g_map_perf.memset[zTmp]++;
    }

    return memset ( dest, cSrc, len );
}


void* memmove_s_ ( void *dest , const void *src , size_t len, const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;

    atomic_inc_s ( & g_cnt_perf.memmove );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.memmove.find (zTmp);

    if ( unlikely ( iter == g_map_perf.memmove.end () ) )
    {
        sLockTid = gettid_s ( );
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.memmove, sLockTid, -1 ) )
        {
            pthread_yield_s();
            goto J1;
        }

        g_map_perf.memmove[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.memmove, -1, sLockTid );
    }
    else
    {
        g_map_perf.memmove[zTmp]++;
    }

    return memmove ( dest, src, len );
}


void* memcpy_s_ ( void *dest , const void *src , size_t len, const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;

    atomic_inc_s ( & g_cnt_perf.memcpy );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.memcpy.find (zTmp);

    if ( unlikely ( iter == g_map_perf.memcpy.end () ) )
    {
        sLockTid = gettid_s ( );
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.memcpy, sLockTid, -1 ) )
        {
            pthread_yield_s();
            goto J1;
        }

        g_map_perf.memcpy[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.memcpy, -1, sLockTid );
    }
    else
    {
        g_map_perf.memcpy[zTmp]++;
    }

    return memcpy ( dest, src, len );
}


int memcmp_s_ ( void *dest , const void *src , size_t len, const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;

    atomic_inc_s ( & g_cnt_perf.memcmp );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.memcmp.find (zTmp);

    if ( unlikely ( iter == g_map_perf.memcmp.end () ) )
    {
        sLockTid = gettid_s ( );
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.memcmp, sLockTid, -1 ) )
        {
            pthread_yield_s();
            goto J1;
        }

        g_map_perf.memcmp[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.memcmp, -1, sLockTid );
    }
    else
    {
        g_map_perf.memcmp[zTmp]++;
    }

    return memcmp ( dest, src, len );
}


void* malloc_s_ ( size_t size, const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;

    atomic_inc_s ( & g_cnt_perf.malloc );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.malloc.find (zTmp);

    if ( unlikely ( iter == g_map_perf.malloc.end () ) )
    {
        sLockTid = gettid_s ( );
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.malloc, sLockTid, -1 ) )
        {
            pthread_yield_s();
            goto J1;
        }

        g_map_perf.malloc[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.malloc, -1, sLockTid );
    }
    else
    {
        g_map_perf.malloc[zTmp]++;
    }

    return malloc ( size );
}


size_t strlen_s_ ( const char *s, const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;

    atomic_inc_s ( & g_cnt_perf.strlen );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.strlen.find (zTmp);

    if ( unlikely ( iter == g_map_perf.strlen.end () ) )
    {
        sLockTid = gettid_s ( );
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.strlen, sLockTid, -1 ) )
        {
            pthread_yield_s();
            goto J1;
        }

        g_map_perf.strlen[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.strlen, -1, sLockTid );
    }
    else
    {
        g_map_perf.strlen[zTmp]++;
    }

    return strlen ( s );
}


int strcmp_s_ ( const char *s1 , const char *s2, const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;

    atomic_inc_s ( & g_cnt_perf.strcmp );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.strcmp.find (zTmp);

    if ( unlikely ( iter == g_map_perf.strcmp.end () ) )
    {
        sLockTid = gettid_s ( );
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.strcmp, sLockTid, -1 ) )
        {
            pthread_yield_s();
            goto J1;
        }

        g_map_perf.strcmp[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.strcmp, -1, sLockTid );
    }
    else
    {
        g_map_perf.strcmp[zTmp]++;
    }

    return strcmp ( s1, s2 );
}


int strncmp_s_ ( const char *s1 , const char *s2, size_t n, const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;

    atomic_inc_s ( & g_cnt_perf.strncmp );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.strncmp.find (zTmp);

    if ( unlikely ( iter == g_map_perf.strncmp.end () ) )
    {
        sLockTid = gettid_s ( );
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.strncmp, sLockTid, -1 ) )
        {
            pthread_yield_s();
            goto J1;
        }

        g_map_perf.strncmp[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.strncmp, -1, sLockTid );
    }
    else
    {
        g_map_perf.strncmp[zTmp]++;
    }

    return strncmp ( s1, s2, n );
}


char* strcpy_s_ ( char *s1 , const char *s2, const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;

    atomic_inc_s ( & g_cnt_perf.strcpy );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.strcpy.find (zTmp);

    if ( unlikely ( iter == g_map_perf.strcpy.end () ) )
    {
        sLockTid = gettid_s ( );
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.strcpy, sLockTid, -1 ) )
        {
            pthread_yield_s();
            goto J1;
        }

        g_map_perf.strcpy[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.strcpy, -1, sLockTid );
    }
    else
    {
        g_map_perf.strcpy[zTmp]++;
    }

    return strcpy ( s1, s2 );
}


char* strncpy_s_ ( char *s1 , const char *s2, size_t n, const char* file, const char* func, int line )
{
    char    zTmp[256] = { 0, };
    int     sLockTid = 0;

    atomic_inc_s ( & g_cnt_perf.strncpy );

    sprintf ( zTmp, "%s %s %d %d", file, func, line, gettid_s() );

J1:
    std::map<std::string,long long>::iterator iter = g_map_perf.strncpy.find (zTmp);

    if ( unlikely ( iter == g_map_perf.strncpy.end () ) )
    {
        sLockTid = gettid_s ( );
        if ( sLockTid != mvpAtomicCas32 ( &g_map_lock.strncpy, sLockTid, -1 ) )
        {
            pthread_yield_s();
            goto J1;
        }

        g_map_perf.strncpy[zTmp] = 1;

        mvpAtomicCas32 ( &g_map_lock.strncpy, -1, sLockTid );
    }
    else
    {
        g_map_perf.strncpy[zTmp]++;
    }

    return strncpy ( s1, s2, n );
}


/*
 * (gdb) call print_map_perf ( &g_map_perf.memcpy )
  ["TCPERF001A.cpp_test_dml_197_19763"] = 1249999,
  ["dbmCommit.cpp_dbmCommit_49_19764"] = 1249999,
  ["dbmErrorInterface.cpp_mErrorInitialize_192_19764"] = 179,
  ["dbmIndexManager.cpp_mInsertKeyLib_179_19761"] = 1249999,
 */
void print_map_perf ( void* pMap )
{
    int     i;

    if ( pMap == NULL
            || ( ((char*)pMap)[0] == 'A' && ((char*)pMap)[1] == 'L' && ((char*)pMap)[2] == 'L' )
            )
    {
        // (gdb) p g_cnt_perf
        // (gdb) call print_map_perf ( &g_map_perf.memset )
        // (gdb) call print_map_perf ("ALL" )
        _PRT ( "\n\t== \"%s\" ==\n", "g_map_perf.tkill" );
        print_map_perf( &g_map_perf.memset );


        _PRT ( "\n\t== \"%s\" ==\n", "g_map_perf.memset" );
        print_map_perf( &g_map_perf.memset );

        _PRT ( "\n\t== \"%s\" ==\n", "g_map_perf.malloc" );
        print_map_perf( &g_map_perf.memset );

        _PRT ( "\n\t== \"%s\" ==\n", "g_map_perf.memcpy" );
        print_map_perf( &g_map_perf.memset );

        _PRT ( "\n\t== \"%s\" ==\n", "g_map_perf.memcmp" );
        print_map_perf( &g_map_perf.memset );

        _PRT ( "\n\t== \"%s\" ==\n", "g_map_perf.memmove" );
        print_map_perf( &g_map_perf.memset );


        _PRT ( "\n\t== \"%s\" ==\n", "g_map_perf.strlen" );
        print_map_perf( &g_map_perf.memset );

        _PRT ( "\n\t== \"%s\" ==\n", "g_map_perf.strcmp" );
        print_map_perf( &g_map_perf.memset );

        _PRT ( "\n\t== \"%s\" ==\n", "g_map_perf.strncmp" );
        print_map_perf( &g_map_perf.memset );

        _PRT ( "\n\t== \"%s\" ==\n", "g_map_perf.strcpy" );
        print_map_perf( &g_map_perf.memset );

        _PRT ( "\n\t== \"%s\" ==\n", "g_map_perf.strncpy" );
        print_map_perf( &g_map_perf.memset );
    }
    else
    {
        std::map<std::string,long long>* m;

        m = (std::map<std::string,long long>*)pMap;
        for ( std::map<std::string, long long>::iterator iter = m->begin ( ); iter != m->end ( ); iter++ )
        {
            if ( ( *iter ).second < 1000 )
            {
                ( *iter ).second = 0;               // 한번 조회하면 초기화 하도록 한다.
                continue;
            }

            _PRT ( "\n\t[\"%s\"] = %ld", ( *iter ).first.c_str ( ), ( *iter ).second );
            ( *iter ).second = 0;
        }
        printf ( "\n" );
    }
}

#endif  /* _OKT_TRC_CALLER */


/******************************************************************************
 * POSIX 시스템 콜 래퍼 ( for MinGW )
 * 2015.02.12 -okt- 윈도우 포팅
******************************************************************************/
#ifndef __linux__

int32_t gethostid_s_( )
{
	DWORD dwVolumeSerialNumber = -1;
	LPCTSTR lpRootPathName = "C:\\";

	GetVolumeInformation( lpRootPathName, 0, 0, &dwVolumeSerialNumber, 0, 0, 0, 0 );

	return (int32_t)dwVolumeSerialNumber;
}


//TODO: [REF] https://gitorious.org/dova/dova-core/commit/e8f3917f76d61c5c50123ea9afebe51de130ac88
/* total seconds since epoch until start of unix time (january 1, 1970 00:00 UTC) */
#define _DOVA_UNIX_SECONDS 11644473600

struct timespect
{
	time_t tv_sec;
	long long tv_nsec;
};

//int clock_gettime_s_( int clk_id, struct timespec* tp )
int clock_gettime_s_( int clk_id, void *tp_ )
{
	struct timespec* tp = (struct timespec*)tp_;
	FILETIME ft;
	ULARGE_INTEGER t64;

	GetSystemTimeAsFileTime(&ft);

	t64.LowPart = ft.dwLowDateTime;
	t64.HighPart = ft.dwHighDateTime;
	tp->tv_sec = t64.QuadPart / 10000000 - _DOVA_UNIX_SECONDS;
	tp->tv_nsec = t64.QuadPart % 10000000 * 100;

	return 0;
}

/*
 * http://cvsweb.netbsd.org/bsdweb.cgi/src/lib/libc/time/strptime.c?rev=HEAD
 */
char* strptime_s_( const char* buf, const char* fmt, struct tm* tm )
{
    _ASSERT( 0 ); // 미구현
    return NULL;
}

char* basename_s_( char* path )
{
    return path;
}

struct tm* localtime_s_( const long* timep )
{
    time_t tv_sec;

    tv_sec = *timep;

    return localtime( &tv_sec );
}

struct tm* localtime_r_s_( const long* timep, struct tm* result )
{
    time_t tv_sec;

    tv_sec = *timep;

    return localtime_r( &tv_sec, result );
}

char* strtok_r_s_( char* str, const char* delim, char** saveptr )
{
    char*   sToken = NULL;
    char*   sTokenPos = NULL;
    int     sLenPre = 0;

    if ( str == NULL )
    {
        //TODO: [OKT] [BUGBUG] 이건 몰라서 이렇게 했음.
        //return strtok_r ( str, delim, saveptr );
        return strtok_r_s_ ( *saveptr, delim, saveptr );
    }

    sLenPre = strlen_s( str );

    sToken = strtok_r( str, delim, &sTokenPos );

    if ( sToken != NULL )
    {
        if ( sLenPre > strlen_s( str ) )
        {
            *saveptr = sTokenPos + strlen(sToken) + 1;
        }
        else
        {
            *saveptr = sTokenPos + strlen(sToken) + 0;
        }
    }
    else
    {
        //TODO: [OKT] [BUGBUG] 이건 원칙에 안맞는 것 같다. str이 NULL 이 아니면 도달안할 것 같은데..
//        DBM_ERR( "[NEVER] %p", sToken );
//        _DASSERT( 0 );
        *saveptr = NULL;
    }

    return sToken;
}


#endif

