/******************************************************************************
* Copyright 2012, OnmirSoft Corporation or its subsidiaries.
* All rights reserved.
******************************************************************************/

/******************************************************************************
* $Id$ *
* Description :
*   common unix domain socket library
******************************************************************************/
#include "cmnHeader.h"

#ifdef __linux__	//TODO: [OKT]  윈도포팅

/******************************************************************************
* Name : cmnUdsServerOpen
*
* Description
*   (SOCK_STREAM)Unix Domain Server Socket 을 생성한 후 listen 한다
*
* Argument
*   aSockFd     : output : 생성한 Socket file descriptor
*   aPath       : input  : Socket 의 sun_path 에 사용할 file key path
*   aNonBlockF  : input  : Socket의 Non Blocking 모드
*                          default : -1 (Blocking)
*   aBufSize    : input  : Socket 의 Send/Recv Buf Size 를 지정
*                          0 보다 작거나 같을 경우 Default 값 이용
*
******************************************************************************/
_VOID cmnUdsServerOpen ( int* aSockFd , char* aPath , int aNonBlockF , int aBufSize )
{
    struct sockaddr_un sUnSock;
    int     sSock;
    int     sOptVal;
    int     sFlag;

    _TRY
    {
        memset_s( (char*)&sUnSock, 0x00, sizeof(struct sockaddr_un) );

        // socket 생성
        sSock = socket( PF_UNIX, SOCK_STREAM, 0 );
        if ( unlikely( sSock < 0 ) ) //, CREATE_SOCK_FAIL );
        {
            DBM_ERR( "cmnUdsServerOpen fail [%d] (err=%d,tid=%d)", sSock, errno, gettid_s() );
            _THROW( -1 );
        }

        sUnSock.sun_family = PF_UNIX;
        strcpy_s( sUnSock.sun_path, aPath );

        // listen port binding
        _CALL( bind( sSock, (struct sockaddr*)&sUnSock, sizeof(sUnSock) ) );

#if 0
        // TIME_WAIT 상태의 socket 주소와 Port 를 재사용할 수 있도록 함.
        sOptVal = 1;
        _CALL( setsockopt( sSock, SOL_SOCKET, SO_REUSEADDR, (char*)&sOptVal, sizeof(sOptVal) ) );

        /*-------------------------------------------------------------
         * nagle 알고리즘 적용 여부.
         *   1(TRUE)  : nagle 을 적용하지 않아서 작게 작게 끊어보낸다. (for low latency )
         *   2(FALSE) : nagle 을 적용하여 한번에 많이 보낸다.
        -------------------------------------------------------------*/
        sOptVal = 1;
        _CALL( setsockopt( sSock, IPPROTO_TCP, TCP_NODELAY, (char*)&sOptVal, sizeof(sOptVal) ) );
#endif

        //TODO:fhan: buffer 크기에 따른 성능 측정 필요
        // TCP Layer 의 socket buffer 를 사용자가 지정한 값으로 설정
        if ( aBufSize > 0 )
        {
            sOptVal = aBufSize;
            _CALL( setsockopt( sSock, SOL_SOCKET, SO_SNDBUF, (char*)&sOptVal, sizeof(sOptVal) ) );
            _CALL( setsockopt( sSock, SOL_SOCKET, SO_RCVBUF, (char*)&sOptVal, sizeof(sOptVal) ) );
        }

        // Socket 을 non blocking mode 로 변경
        if ( aNonBlockF == 1 )
        {
            sFlag = fcntl( sSock, F_GETFL, 0 );
            _CALL( fcntl( sSock, F_SETFL, sFlag | O_NDELAY ) );
        }

        _CALL(  listen( sSock, 5 ) );
        *aSockFd = sSock;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* cmnUdsServerOpen */


/******************************************************************************
* Name : cmnUdsConnect
*
* Description
*   (SOCK_STREAM)unix domain client socket 생성 후 server로 접속을 시도한다
*
* Argument
*   aSockFd     : output : unix domain socket file descriptor
*   aPath       : input  : Socket 의 sun_path 에 사용할 file key path
*   aNonBlockF  : input  : Socket의 Non Blocking 모드
*                          default : -1 (Blocking )
*   aBufSize    : input  : Socket 의 Send/Recv Buf Size 를 지정
*                          0 보다 작거나 같을 경우 Default 값 이용
*
******************************************************************************/
_VOID cmnUdsConnect ( int* aSockFd , char* aPath , int aNonBlockF , int aBufSize )
{
    struct sockaddr_un sServAddr;
    int     sSock;
    int     sOptVal;
    int     sFlag;

    _TRY
    {
        memset_s( (char*)&sServAddr, 0x00, sizeof(struct sockaddr_un) );

        // socket 생성
        sSock = socket( PF_UNIX, SOCK_STREAM, 0 );
        if ( unlikely( sSock < 0 ) ) //, CREATE_SOCK_FAIL );
        {
            DBM_ERR( "cmnUdsConnect fail [%d] (err=%d,tid=%d)", sSock, errno, gettid_s() );
            _THROW( -1 );
        }

        sServAddr.sun_family = PF_UNIX;
        strcpy_s( sServAddr.sun_path, aPath );

#if 0
        /*-------------------------------------------------------------
         * nagle 알고리즘 적용 여부.
         *   1(TRUE)  : nagle 을 적용하지 않아서 작게 작게 끊어보낸다. (for low latency )
         *   2(FALSE) : nagle 을 적용하여 한번에 많이 보낸다.
        -------------------------------------------------------------*/
        sOptVal = 1;
        _CALL( setsockopt( sSock, IPPROTO_TCP, TCP_NODELAY, (char*)&sOptVal, sizeof(sOptVal) ) );
#endif

        // TCP Layer 의 socket buffer 를 사용자가 지정한 값으로 설정
        if ( aBufSize > 0 )
        {
            sOptVal = aBufSize;
            _CALL( setsockopt( sSock, SOL_SOCKET, SO_SNDBUF, (char*)&sOptVal, sizeof(sOptVal) ) );
            _CALL( setsockopt( sSock, SOL_SOCKET, SO_RCVBUF, (char*)&sOptVal, sizeof(sOptVal) ) );
        }

        // Socket 을 non blocking mode 로 변경
        if ( aNonBlockF == 1 )
        {
            sFlag = fcntl( sSock, F_GETFL, 0 );
            _CALL( fcntl( sSock, F_SETFL, sFlag | O_NDELAY ) );
        }

        // connect to server
        //sRet = connect( sSock, (struct sockaddr*)&sServAddr, sizeof(struct sockaddr_un) );
        _CALL( connect( sSock, (struct sockaddr*)&sServAddr, sizeof(sServAddr) ) );
        *aSockFd = sSock;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* cmnUdsConnect */


/******************************************************************************
* Name : cmnUdsAccept
*
* Description
*   (SOCK_STREAM)UDS Server가 client로부터 connect 요청 된 Socket 을 Accept 한다
*
* Argument
*   aListenSockFd : input  : server 의 UDS FD
*   aNewSockFd    : output : accept 를 통해 신규로 생성된 FD
*   aNonBlockF    : input  : Socket 의 Non Blocking 모드
*
******************************************************************************/
_VOID cmnUdsAccept ( int aListenSockFd , int* aNewSockFd , int aNonBlockF )
{
    struct sockaddr_un sCliAddr;
    int     sAddrLen;
    int     sSock;
    int     sFlag;

    _TRY
    {
        memset_s( (char*)&sCliAddr, 0x00, sizeof(struct sockaddr_un) );

        sAddrLen = sizeof(struct sockaddr_un );

        sSock = accept( aListenSockFd, (struct sockaddr*)&sCliAddr, (socklen_t*)&sAddrLen );
        if ( unlikely( sSock < 0 ) ) //, ACCEPT_FAIL );
        {
            DBM_ERR( "cmnUdsAccept fail [%d] (err=%d,tid=%d)", sSock, errno, gettid_s() );
            _THROW( -1 );
        }

        if ( aNonBlockF == 1 )
        {
            sFlag = fcntl( sSock, F_GETFL, 0 );
            _CALL( fcntl( sSock, F_SETFL, sFlag | O_NDELAY ) );
        }

        *aNewSockFd = sSock;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* cmnUdsAccept */


/******************************************************************************
* Name : cmnUdsOpen
*
* Description
*   (SOCK_DGRAM)Unix Domain Socket을 생성한다
*
* Argument
*   aSockFd      : output : 생성한 Socket file descriptor
*   aFileKeyPath : input  : Socket 의 sun_path 에 사용할 file key path
*   aNonBlockF   : input  : Socket의 Non Blocking 모드
*                           default : -1 (Blocking )
*   aBufSize     : input  : Socket 의 Send/Recv Buf Size 를 지정
*                           0 보다 작거나 같을 경우 Default 값 이용
*
******************************************************************************/
_VOID cmnUdsOpen ( int* aSockFd , char* aFileKeyPath , int aNonBlockF , int aBufSize )
{
    struct sockaddr_un sUnSock;
    int     sSock;
    int     sOptVal;
    int     sFlag;

    _TRY
    {
        memset_s( (char*)&sUnSock, 0x00, sizeof(struct sockaddr_un) );

        /*-------------------------------------------------------------
        * socket 생성
        -------------------------------------------------------------*/
        sSock = socket( PF_UNIX, SOCK_DGRAM, 0 );
        if ( unlikely( sSock < 0 ) ) //, CREATE_SOCK_FAIL );
        {
            DBM_ERR( "cmnUdsOpen fail [%d] (err=%d,tid=%d)", sSock, errno, gettid_s() );
            _THROW( -1 );
        }

        sUnSock.sun_family = PF_UNIX;
        strcpy_s( sUnSock.sun_path, aFileKeyPath );

        // listen port binding
        _CALL( bind( sSock, (struct sockaddr*)&sUnSock, sizeof(sUnSock) ) );

#if 0
        // TIME_WAIT 상태의 socket 주소와 Port 를 재사용할 수 있도록 함.
        sOptVal = 1;
        _CALL( setsockopt( sSock, SOL_SOCKET, SO_REUSEADDR, (char*)&sOptVal, sizeof(sOptVal) ) );

        /*-------------------------------------------------------------
         * nagle 알고리즘 적용 여부.
         *   1(TRUE)  : nagle 을 적용하지 않아서 작게 작게 끊어보낸다. (for low latency )
         *   2(FALSE) : nagle 을 적용하여 한번에 많이 보낸다.
        -------------------------------------------------------------*/
        sOptVal = 1;
        _CALL( setsockopt( sSock, IPPROTO_TCP, TCP_NODELAY, (char*)&sOptVal, sizeof(sOptVal) ) );
#endif

        //TODO:fhan: buffer 크기에 따른 성능 측정 필요
        // TCP Layer 의 socket buffer 를 사용자가 지정한 값으로 설정
        if ( aBufSize > 0 )
        {
            sOptVal = aBufSize;
            _CALL( setsockopt( sSock, SOL_SOCKET, SO_SNDBUF, (char*)&sOptVal, sizeof(sOptVal) ) );
            _CALL( setsockopt( sSock, SOL_SOCKET, SO_RCVBUF, (char*)&sOptVal, sizeof(sOptVal) ) );
        }

        // Socket 을 non blocking mode 로 변경
        if ( aNonBlockF == 1 )
        {
            sFlag = fcntl( sSock, F_GETFL, 0 );
            _CALL( fcntl( sSock, F_SETFL, sFlag | O_NDELAY ) );
        }

        //_CALL( listen( sSock, 5 ) );
        *aSockFd = sSock;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* cmnUdsOpen */

/******************************************************************************
* Name : cmnUdsSend
*
* Description
*   (SOCK_STREAM)unix domain socket 을 통해 packet 을 전송한다
*
* Argument
*   aSockFd     : input  : unix domain socket file descriptor
*   aBuf        : input  : 전송할 Data 버퍼 포인터
*   aSize       : input  : 전송할 Data 의 목표 크기
*   aSentSize   : output : 실제 전송 성공한 Data 크기
*
******************************************************************************/
_VOID cmnUdsSend ( int aSockFd , char* aBuf , int aSize , int* aSentSize )
{
    char*   sSendPtr;
    int     sSendLen;
    int     sSize   = aSize;
    int     sRemain;

    _TRY
    {
        //TODO: 2014.10.20 -okt- 왜 사이즈를 먼저전송하는가? 확인요
        /* size 를 나타태는 4 byte 먼저 전송 */
        // 2015.08.17:fhan tcp 모듈 변경에 맞춰 사이즈 계산 부분 제거
        /*
        sRemain  = sizeof(int);
        sSendPtr = (char*)&sSize;

        do
        {
            sSendLen = send ( aSockFd, sSendPtr, sizeof(int), 0 );
            if ( sSendLen > 0 )
            {
                sRemain  -= sSendLen;
                sSendPtr += sSendLen;
            }
            else if ( sSendLen == 0 )
            {
                continue;
            }
            else
            {
                if ( ( errno == EWOULDBLOCK )
#if ( EAGAIN != EWOULDBLOCK )
                        || ( errno == EAGAIN )
#endif
                        || ( errno == EINTR ) )
                {
                    continue;
                }
                else
                {
                    //_RAISE( SEND_FAIL );
                    *aSentSize = aSize - sRemain;
                    return( -1 );
                }
            }
        } while( sRemain > 0 );
        */

        /* 데이터 전송
         * 데이터의 앞 4byte는 메시지 전체길이에 대한 정보가 담겨있어야 한다.
         */
        sRemain  = aSize;
        sSendPtr = aBuf;

        do
        {
            sSendLen = send ( aSockFd, sSendPtr, sRemain, 0 );
            if ( sSendLen > 0 )
            {
                sRemain  -= sSendLen;
                sSendPtr += sSendLen;
            }
            else if ( sSendLen == 0 )
            {
                continue;
            }
            else
            {
                if ( ( errno == EWOULDBLOCK )
#if ( EAGAIN != EWOULDBLOCK )
                        || ( errno == EAGAIN )
#endif
                        || ( errno == EINTR ) )
                {
                    continue;
                }
                else
                {
                    _THROW ( ERR_SYSCALL_SEND );
                }
            }
        } while ( sRemain > 0 );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        *aSentSize = aSize - sRemain;
    }
    _END
} /* cmnUdsSend */


/******************************************************************************
* Name : cmnUdsSendTo
*
* Description
*   (SOCK_DGRAM)unix domain socket 을 통해 packet 을 전송한다
*
* Argument
*   aSockFd     : input  : unix domain socket file descriptor
*   aServerPath : input  : 데이터를 수신할 target 측의 key file path
*   aBuf        : input  : 전송할 Data 버퍼 포인터
*   aSize       : input  : 전송할 Data 의 목표 크기
*   aSentSize   : output : 실제 전송 성공한 Data 크기
*
******************************************************************************/
_VOID cmnUdsSendTo ( int aSockFd , char* aServerPath , char* aBuf , int aSize , int* aSentSize )
{
    struct sockaddr_un sUnSock;
    int     sSendLen;

    memset_s( (char*)&sUnSock, 0x00, sizeof(struct sockaddr_un) );

    /*
    sSock = socket( PF_UNIX, SOCK_DGRAM, 0 );
    _IF_RAISE( sSock < 0, CREATE_SOCK_FAIL );
    */
    sUnSock.sun_family = PF_UNIX;
    strcpy_s ( sUnSock.sun_path, aServerPath );

    sSendLen = sendto ( aSockFd, aBuf, aSize, 0, (struct sockaddr*) &sUnSock, sizeof( sUnSock ) );
    if ( sSendLen != aSize )
    {
        //_RAISE( SEND_FAIL );
        *aSentSize = sSendLen;
        return ( -1 );
    }

    *aSentSize = sSendLen;

    return RC_SUCCESS;
} /* cmnUdsSendTo */


/******************************************************************************
* Name : cmnUdsRecv
*
* Description
*   UDS를 통해 packet 을 수신한다
*
* Argument
*   aSockFd     : input  : unix domain socket file descriptor
*   aBuf        : output : 수신 Data 를 저장할 버퍼 포인터
*   aRecvedSize : output : 실제 최종적으로 수신 성공한 Data 크기
*
******************************************************************************/
_VOID cmnUdsRecv ( int aSockFd , char* aBuf , int* aRecvedSize )
{
    char    sLenBuf[5];
    int     sInd  = 0;
    int     sLen  = 0;
    int     sRecv = 0;

    _TRY
    {
        memset_s( sLenBuf, 0x00, sizeof(sLenBuf) );

        /*-------------------------------------------------------------
        * 어떤 형태로 메시지를 보내건 먼저 보낸 4 byte 는 무조건
        * Length 이어야 한다.
        -------------------------------------------------------------*/
        while ( sInd < (int) ( sizeof(int) ) )
        {
            /*-------------------------------------------------------------
            * Step1: 4byte lenth Read
            -------------------------------------------------------------*/
            sRecv = recv( aSockFd, (sLenBuf + sInd), (sizeof(int) - sInd), 0 );
            DBM_TRC( "[DEBUG-1-6-1] cmnUdsRecv [%d]", sRecv );
            if ( sRecv == 0 ) //, RECV_ZERO );
            {
                _THROW( -3 );
            }

            if ( sRecv < 0 )
            {
                switch ( errno )
                {
#if ( EAGAIN != EWOULDBLOCK )
                    case EAGAIN:
#endif
                    case EWOULDBLOCK:
                        continue;
                        break;
                    case ECONNRESET:
                    case ECONNREFUSED:
                        //_RAISE( RECV_CONN_RESET ) ;
                        _THROW( -4 );
                        break;
                    default:
                        //_RAISE( RECV_ETC_FAIL ) ;
                        _THROW( -5 );
                        break;
                }
            }

            sInd = sInd + sRecv;
        }

        memcpy_s( &sLen, sLenBuf, 4 );

        /**************************************
        * Step2: Read Data
        **************************************/
        sInd = 4;
        memcpy (aBuf, &sLen, sizeof(int));

        while( sInd < sLen )
        {

            sRecv = recv( aSockFd, ( aBuf + sInd), (sLen - sInd), 0 );
            DBM_TRC( "[DEBUG-1-6-2] cmnUdsRecv [%d]", sRecv );
            if ( sRecv == 0 ) //, RECV_ZERO );
            {
                _THROW( -3 );
            }

            if ( sRecv < 0 )
            {
                switch ( errno )
                {
#if ( EAGAIN != EWOULDBLOCK )
                    case EAGAIN:
#endif
                    case EWOULDBLOCK:
                        continue;
                        break;
                    case ECONNRESET:
                    case ECONNREFUSED:
                        //_RAISE( RECV_CONN_RESET ) ;
                        _THROW( -4 );
                        break;
                    default:
                        //_RAISE( RECV_ETC_FAIL ) ;
                        _THROW( -5 );
                        break;
                }
            }

            sInd = sInd + sRecv;
        }

        //*aRecvedSize = sInd;
    }
    _CATCH
    {
        _CATCH_DBG;
    }
    _FINALLY
    {
        *aRecvedSize = sInd;
    }
    _END
} /* cmnUdsRecv */


/******************************************************************************
* Name : cmnUdsRecvFrom
*
* Description
*   UDS를 통해 packet 을 수신한다
*
* Argument
*   aSockFd     : input  : unix domain socket file descriptor
*   aClientPath : input  : 데이터를 송신할 target 측의 key file path
*   aBuf        : output : 수신 Data 를 저장할 버퍼 포인터
*   aSize       : input  : 수신할 Data 의 목표 크기
*   aRecvedSize : output : 실제 최종적으로 수신 성공한 Data 크기
*
******************************************************************************/
_VOID cmnUdsRecvFrom ( int aSockFd , char* aClientPath , char* aBuf , int aSize , int* aRecvedSize )
{
    struct sockaddr_un sUnSock;
    int     sRecv = 0;
    int     sUnSockLen;

    _TRY
    {
        memset_s( (char*)&sUnSock, 0x00, sizeof(struct sockaddr_un) );
        sUnSockLen = sizeof( sUnSock );

        sUnSock.sun_family = PF_UNIX;
        strcpy_s( sUnSock.sun_path, aClientPath );

        sRecv = recvfrom( aSockFd, aBuf, aSize, 0, (struct sockaddr*)&sUnSock, (socklen_t*)&sUnSockLen );
        DBM_TRC( "[DEBUG-1-7-1] cmnUdsRecvFrom [%d]", sRecv );
        if ( sRecv != aSize ) //, RECV_FAIL );
        {
            _THROW( -1 );
        }

        //*aRecvedSize = sRecv;
    }
    _CATCH
    {
        _CATCH_DBG;
    }
    _FINALLY
    {
        *aRecvedSize = sRecv;
    }
    _END
} /* cmnUdsRecvFrom */


/******************************************************************************
* Name : cmnUUdpClose
*
* Description
*   unix domain socket 을 close 한다
*
* Argument
*   aSockFd     : input  : unix domain socket file descriptor
*
******************************************************************************/
_VOID cmnUdsClose ( int aSockFd )
{
    close_s( aSockFd );
    return RC_SUCCESS;
}

#else
    // TODO: [OKT]  윈도포팅
#endif /* __linux__ */
