/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   common posix shared memory library
 ******************************************************************************/
#include "cmnHeader.h"

#ifdef __linux__  //TODO: [OKT] 윈도포팅

#ifdef _DEBUG

/*
 * TODO: 2015.01.25 -okt- 추후 LD_PRELOAD 로 후킹을 하기위한 코드
 *       shm_open@@GLIBC_2.2.5 이런식으로 심볼이 잡혀서 후킹이 안된다.
 *       예) 후킹 so에서는 dlsym(RTLD_NEXT,"shm_open") 이런 옵션으로 호출
 */
#include <dlfcn.h>  //TODO: [OKT] [윈도포팅] dlfcn.h 없음

int ( *__shm_open ) ( const char* name, int oflag, mode_t mode ) = NULL;

int shm_open_s_ ( const char* name, int oflag, mode_t mode )
{
    int     sRC;

    errno = 0;
    if ( !__shm_open )
    {
        sRC = cmnDlsym ( RTLD_DEFAULT, "shm_open", (void**)&__shm_open );
        assert ( sRC == 0 && "dlsym Fail (shm_open)" );
    }

    return ( *__shm_open ) ( name, oflag, mode );
}

#endif

#endif /* __linux__ */


static int cmnPShmMkdir ( const char* pathname, mode_t mode )
{
    char    sTmp[256];
    char*   p = NULL;
    size_t  sLen;

    snprintf ( sTmp, sizeof( sTmp ), "%s", pathname );
    sLen = strlen ( sTmp );

    if ( sTmp[sLen - 1] == '/' )
    {
        sTmp[sLen - 1] = 0;
    }

    for ( p = sTmp + 1; *p; p++ )
    {
        if ( *p == '/' )
        {
            *p = 0;
            mkdir_s ( sTmp, mode );
            *p = '/';
        }
    }

    return mkdir_s ( sTmp, mode );
}

#ifdef __linux__    //TODO: [OKT] 윈도포팅

/******************************************************************************
 * Name : cmnPShmCreate
 *
 * Description
 *
 * Argument
 *   aKeyFilePath  : input  : shm file 생성에 필요한 file path
 *   aSize         : input  : 생성할 shm size (64bit변수 )
 *
 ******************************************************************************/
_VOID cmnPShmCreate ( const char* aKeyFilePath, long long aSize, void** aAttachAddr )
{
    char    sFileName[256] = { 0, };
    int     sMode = -1;
    int     sFd = -1;
    long long sSize = 0;
    int     sErrno = 0;
    int     sRC = 0;

    _TRY
    {
        _IF_THROW ( aKeyFilePath == NULL, ERR_CMN_INVALID_ARG );
        if ( aSize <= 0
#ifdef _DEBUG
                // _cmn_sys_physmemsize 은 _dbm_main (libdbm.so)에서 초기화 된다. 때문에. libcmn.so 만 물고 들어오면, 0이다.
                || ( _cmn_sys_physmemsize > 0 && (unsigned long long)aSize > (unsigned long long)( _cmn_sys_physmemsize >> 1 ) )
                || (unsigned long long) aSize > (unsigned long long) ( 1 << 31 )    // 2G 보다 큰거 한번에 잡으면 죽는다.
#endif
           )
        {
            DBM_ERR( "shm create error, size error. size=%ld (%s) (err=%d,tid=%d)", aSize, aKeyFilePath, errno, gettid_s() );
            DBM_DBG( "system memory info. phys=%ld, avphys=%ld", _cmn_sys_physmemsize, _cmn_sys_avphysmemsize );

            _DASSERT( 0 );
            _THROW ( ERR_CMN_INVALID_ARG );
        }

        sMode = umask(0x00);        // 777 모드로 오픈하기 위해 umask 필요.

        // 통상적으로 상위단에서 PATH를 만들때 '/' 로 시작하도록 만들어서 호출하기로 한다. ( 2014/07/22 )
        if ( unlikely( aKeyFilePath[0] != '/' ) )
        {
            snprintf ( sFileName, sizeof(sFileName), "/%s", aKeyFilePath );
        }
        else
        {
            snprintf ( sFileName, sizeof(sFileName), "%s", aKeyFilePath );
        }

        sFd = shm_open_s ( sFileName, O_CREAT | O_RDWR | O_EXCL, _cmn_file_mode );

        /*
         * 디렉토리를 생성하고 한번더 시도해본다.
         */
        if ( sFd < 0 && errno == ENOENT )
        {
            char    sDirName[256] = { 0, };
            snprintf ( sDirName, sizeof(sDirName), "/dev/shm/%s", &sFileName[1] );
            for ( int i = strlen_s(sDirName); i > 0; i-- )
            {
                if ( sDirName[i] == '/' )
                {
                    sDirName[i] = 0x00;

                    sRC = cmnPShmMkdir ( sDirName, 0777 );
                    // 동시성으로 EEXIST 발생할수 있다. 무시한다.
                    if ( errno == EEXIST )
                    {
                        errno = 0;  // EXIST를 제거
                    }
                    else if ( sRC < 0 )
                    {
                        _THROW ( ERR_CMN_SHM_OPEN );
                    }

                    break;
                }
            }

            sFd = shm_open_s ( sFileName, O_CREAT | O_RDWR | O_EXCL, _cmn_file_mode );
        }

        //_IF_THROW ( sFd < 0, ERR_CMN_SHM_OPEN );
        if ( sFd < 0 )
        {
            if ( errno == EEXIST )
            {
                _THROW( ERR_CMN_SHM_DUP_ERROR );
            }
            else
            {
                _THROW( ERR_CMN_SHM_OPEN );
            }
        }

        // 2015.02.22 -okt- 릴리즈에서는 파일 크기만 잡아두고 memset하지 않는다. 런타임에 memset을 큰 블럭을 하면, 성능 지터 문제가 있다.
        // 일단 크기 먼저 잡아준다.
        _CALL( ftruncate ( sFd, aSize ) );

#ifdef _DEBUG
        /*
         * TODO: 원래 골디1의 코드는 아래와 같다.
         *       아래와 같은 경우는 만일 /dev/shm 에 공간이 잡힌 후에 /dev/shm 아닌 일반 메모리 사용으로 /dev/shm에 실제
         *       할당이 불가능할때 SIGBUG 같은 추적곤란한 오류가 나는 것을 막을 수 있는 장점이 있다.
         *       이에 대한 선택은 정책적인 판단으로, hidden property 로 만들어 둘 필요가 있다.
         */
        char    tmp[8192];  // 굳이 memset 할거면, 변수가 너무 크다. __thread 혹은 일반 전역변수 처리 필요.
        ssize_t sLen;
        memset_s ( tmp, 0x00, sizeof( tmp ) );
        /* 실제 해당 파일을 끝까지 쓴다 */
        while ( sSize < aSize )
        {
            sLen = write ( sFd, tmp, sizeof( tmp ) );
            _IF_THROW( sLen != sizeof( tmp ), ERR_CMN_SHM_OPEN );
            sSize = sSize + sLen;
        }
#endif

        if ( aAttachAddr != NULL )
        {
            *aAttachAddr = (char*)mmap( NULL, aSize, PROT_READ | PROT_WRITE, MAP_SHARED, sFd, 0 );
            _IF_THROW ( *aAttachAddr == (void *)MAP_FAILED, ERR_CMN_MMAP );
        }
    }
    _CATCH
    {
        _CATCH_INFO2(aKeyFilePath);

        // 상위단에서 shm_open_s 실패시 EEXIST 로 errno를 검사하는 부분이 있다. 때문에, 이를 넘겨줌.
        sErrno = errno;
    }
    _FINALLY
    {
        close_s ( sFd );
        if ( sMode != -1 )
        {
            (void) umask ( sMode );     // 기존 umask 설정으로 원복.
        }

        errno = sErrno;
    }
    _END
} /* cmnPShmCreate */


/******************************************************************************
 * Name : cmnPShmAttach
 *
 * Description
 *   생성한 shm 에 attach 하여 포인터를 리턴한다.
 *
 * Argument
 *   aKeyFilePath  : input  : shm key 생성에 필요한 file path
 *   aSize         : input  : 사용자가 Attach할만큼의 크기.
 *   aAttachAddr   : output : shm segment 의 시작주소를 가리키는 포인터
 *
 ******************************************************************************/
_VOID cmnPShmAttach ( const char* aKeyFilePath , long long aSize , void** aAttachAddr )
{
    int     sRC;
    int     sFd = -1;

    struct stat  sFileStat ;

    _TRY
    {
        _ASSERT ( aKeyFilePath != NULL );
        _ASSERT ( aSize > 0 );

        if ( unlikely( aKeyFilePath[0] != '/' ) )
        {
            char    sFileName[256] = { 0, };
            snprintf ( sFileName, sizeof(sFileName), "/%s", aKeyFilePath );
            sFd = shm_open_s ( sFileName, O_RDWR, _cmn_file_mode );
        }
        else
        {
            sFd = shm_open_s ( aKeyFilePath, O_RDWR, _cmn_file_mode );
        }

        _IF_THROW( sFd < 0, ERR_CMN_SHM_OPEN );

        _CALL( fstat ( sFd, &sFileStat ) );
        if ( sFileStat.st_size < aSize )
        {
            DBM_ERR ( "fstat error [st_size,%ld,aSize,%ld] (err=%d,tid=%d)",
                      sFileStat.st_size, aSize, errno, gettid_s() );
            _THROW ( ERR_CMN_MMAP );
        }

        *aAttachAddr = (char*) mmap ( NULL, aSize, PROT_READ | PROT_WRITE, MAP_SHARED, sFd, 0 );
        _IF_THROW( *aAttachAddr == (void * )-1, ERR_CMN_MMAP );
    }
    _CATCH
    {
        _CATCH_INFO2( aKeyFilePath );
    }
    _FINALLY
    {
        // 반드시 fd를 닫아준다. mmap을 하면 필요없다.
        close_s (sFd) ;
    }
    _END
} /* cmnPShmAttach */


/******************************************************************************
 * Name : cmnPShmDetach
 *
 * Description
 *   attach 한 shm 에서 detach 한다.
 *
 * Argument
 *   aAttachAddr   : input  : shm segment 의 시작주소를 가리키는 포인터
 *
 ******************************************************************************/
_VOID cmnPShmDetach ( void** ppAddr , long long aSize )
{
    _TRY
    {
        if ( *ppAddr == NULL )
            _RETURN;

        _rc = munmap ( *ppAddr, aSize );
        _IF_THROW( _rc < 0, ERR_CMN_MUNMAP );
        *ppAddr = NULL;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/******************************************************************************
 * Name : cmnPShmDrop
 *
 * Description
 *   shm segment 를 삭제한다.
 *
 * Argument
 *   aKeyFilePath  : input  : shm key 생성에 필요한 file path
 *
 ******************************************************************************/
_VOID cmnPShmDrop( const char* aKeyFilePath )
{
    int     sRC;

    _TRY
    {
        _IF_THROW( aKeyFilePath == NULL, ERR_CMN_INVALID_ARG );

        if ( unlikely( aKeyFilePath[0] != '/' ) )
        {
            char    sFileName[256] = { 0, };
            snprintf ( sFileName, sizeof(sFileName), "/%s", aKeyFilePath );
            _CALL( shm_unlink( sFileName ) );
        }
        else
        {
            _CALL( shm_unlink( aKeyFilePath ) ); // 원래는 ERR_CMN_SHM_UNLINK 리턴.
        }

        DBM_TRC( "shm_unlink ok. (%s) (err=%d,tid=%d)", aKeyFilePath, errno, gettid_s() );
    }
    _CATCH
    {
        if ( errno != ENOENT )  /* = 2 */
        {
            // SegMgr에서 파일이 없다는 것을 확인하기 위해 한번도 호출하는 사용예가 있음. 때문에 INFO로 출력.
            _CATCH_INFO;
        }
        else
        {
            _rc = ERR_CMN_SHM_UNLINK;
        }
    }
    _FINALLY
    _END
}


_VOID cmnPShmGetStat ( const char* aKeyFilePath , struct stat* pStat )
{
    static int sLastCallTid = -1;
    char    sFileName[256] = { 0, };

    _TRY
    {
        _IF_THROW( aKeyFilePath == NULL, ERR_CMN_INVALID_ARG );

        if ( unlikely( aKeyFilePath[0] != '/' ) )
        {
            sprintf ( sFileName, "/dev/shm/%s", aKeyFilePath );
        }
        else
        {
            sprintf ( sFileName, "/dev/shm/%s", &aKeyFilePath[1] );
        }

        _rc = lstat_s ( sFileName, pStat );
        _IF_THROW( _rc, ERR_CMN_LSTAT );

        DBM_TRC( "%s: st_ino(%d) st_nlink(%d) st_uid(%d) st_gid(%d) st_size(%d) st_blksize(%d)",
                 sFileName, pStat->st_ino, pStat->st_nlink, pStat->st_uid, pStat->st_gid, pStat->st_size, pStat->st_blksize );
    }
    _CATCH
    {

        if ( errno == ENOENT )
        {
            /*
             * 상위단에서 일시적인 오류 (TRUNCATE)인지 중복호출된다.
             * 중복로그를 줄이기위한 용도이므로, 동시성 구멍이 있어도 무방하다.
             */
            if ( sLastCallTid != gettid_s() )
            {
                _CATCH_DBG2(sFileName);
            }
        }
        else
        {
            _CATCH_INFO2(sFileName);
        }

        sLastCallTid = gettid_s();
    }
    _FINALLY
    {
        if ( _rc == 0 )
        {
            sLastCallTid = -1;
        }
    }
    _END
}

/******************************************************************************
 * Name : cmnPShmGetAttachNum
 *
 * Description
 *   shm file 에 link 된 Process/Thread수를 리턴한다.
 *
 * Argument
 *   aKeyFilePath  : input  : shm key 생성에 필요한 file path
 *   aAttachNum    : output : shm file 에 link 된 process개수
 *
 ******************************************************************************/
_VOID cmnPShmGetAttachNum ( const char* aKeyFilePath , int* aAttachNum )
{
    char        sFileName[256] = { 0, };
    struct stat sStat;

    _TRY
    {
        _IF_THROW( aKeyFilePath == NULL, ERR_CMN_INVALID_ARG );

        if ( unlikely( aKeyFilePath[0] != '/' ) )
        {
            sprintf ( sFileName, "/dev/shm/%s", aKeyFilePath );
        }
        else
        {
            sprintf ( sFileName, "/dev/shm/%s", &aKeyFilePath[1] );
        }

        _rc = lstat_s ( sFileName, &sStat );
        _IF_THROW( _rc, ERR_CMN_LSTAT );

        *aAttachNum = sStat.st_nlink;

//        DBM_TRC( "%s: st_ino(%d) st_nlink(%d) st_uid(%d) st_gid(%d) st_size(%d) st_blksize(%d)",
//                 sFileName, sStat.st_ino, sStat.st_nlink, sStat.st_uid, sStat.st_gid, sStat.st_size, sStat.st_blksize );
    }
    _CATCH
    {
        _CATCH_WARN2(sFileName);
    }
    _FINALLY
    _END
}


#else

#define _USE_MAP_FILE

_VOID cmnPShmCreate ( const char* aKeyFilePath, long long aSize, void** aAttachAddr )
{
    HANDLE hFile = NULL;                    // the file handle
    HANDLE hMemoryMap = NULL;
    LPBYTE pMemoryMap = NULL;

    _TRY
    {
        /*
         * [주의] 관련 옵션들을 웹에서 믿고 긁어면 몇시간 삽질한다. 삽질하는 듯하면 MSDN을 믿자!!
         */
#ifdef _USE_MAP_FILE
        hFile = CreateFile(
                aKeyFilePath,
                GENERIC_READ | GENERIC_WRITE,
                //0,
                FILE_SHARE_READ | FILE_SHARE_WRITE,
                NULL,
#if 1
                /*
                 * TODO: [OKT] 윈도포팅, MS Windows에서 열려있는 파일을 unlink 혹은 rename이라도 할 수 있는 방법을 찾지 못함.
                 */
                CREATE_ALWAYS,              // [NOTE] overwrite any existing file
#else
                CREATE_NEW,
#endif
                FILE_ATTRIBUTE_TEMPORARY,
                //FILE_ATTRIBUTE_NORMAL,
                NULL
               );

        if ( hFile == INVALID_HANDLE_VALUE )
        {
            DBM_ERR( "CreateFile Fail. (err=%d)", GetLastError() );
            _THROW( -1 );
        }

        hMemoryMap = CreateFileMapping(
                hFile,                      // 파일 맵의 핸들, 초기에 INVALID_HANDLE_VALUE 를 설정한다.
                NULL,                       // 보안 속성
                PAGE_READWRITE,             // 읽고/쓰기 속성
                0,                          // 64비트 어드레스를 사용한다. 상위 32비트 - 메모리의 크기
                aSize,                      // 하위 32비트 - 여기선LPBYTE 타입.
                NULL                        // 공유 파일맵의 이름 - Uique 해야한다.
                );
#else
        hMemoryMap = CreateFileMapping(
                INVALID_HANDLE_VALUE,       // 파일 맵의 핸들, 초기에 INVALID_HANDLE_VALUE 를 설정한다.
                NULL,                       // 보안 속성
                PAGE_READWRITE,             // 읽고/쓰기 속성
                0,                          // 64비트 어드레스를 사용한다. 상위 32비트 - 메모리의 크기
                aSize,                      // 하위 32비트 - 여기선LPBYTE 타입.
                aKeyFilePath                // 공유 파일맵의 이름 - Uique 해야한다.
                );
#endif
        if ( hMemoryMap == NULL )
        {
            DBM_ERR( "CreateFileMapping Fail. (err=%d)", GetLastError() );
            _THROW( -1 );
        }

        //if ( aAttachAddr != NULL )
        {
            pMemoryMap = (BYTE*)MapViewOfFile(
                    hMemoryMap,                 // 파일맵의 핸들
//                  FILE_MAP_ALL_ACCESS,        // 액세스 모드 - 현재는 쓰기
                    FILE_MAP_WRITE,             // 액세스 모드 - 현재는 쓰기
//                  PAGE_READWRITE,             // 이렇게 하면 쓰기가 안된다.
                    0,                          // 메모리 시작번지부터의 이격된 상위 32비트
                    0,                          // 메모리 시작번지부터의 이격된 하위 32비트
                    aSize                       // 사용할 메모리 블록의 크기 - 0이면 설정한 전체 메모리
            );

            if ( pMemoryMap == NULL )
            {
                DBM_ERR( "MapViewOfFile Fail. (err=%d)", GetLastError() );

                CloseHandle(hMemoryMap);
                _THROW( -1 );
            }

            if ( aAttachAddr != NULL )
            *aAttachAddr = pMemoryMap;
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
#ifndef _USE_MAP_FILE
        //TODO: [OKT] 윈도포팅, 이렇게 하면 파일이 없으지나? "Global\\my_shm_key" 이런식으로 생성할때는 없어짐
        CloseHandle( hFile );
        CloseHandle( hMemoryMap );
#endif
    }
    _END
} /* cmnPShmCreate */

_VOID cmnPShmAttach ( const char* aKeyFilePath , long long aSize , void** aAttachAddr )
{
    HANDLE hFile = NULL;                    // the file handle
    HANDLE hMemoryMap = NULL;
    LPBYTE pMemoryMap = NULL;

    _TRY
    {
#ifdef _USE_MAP_FILE

//        HFILE hFile2;
//        OFSTRUCT tOfStr;
//        tOfStr.cBytes = sizeof tOfStr;
//
////        HANDLE inputFile = (HANDLE)OpenFile(inputFileName, &tOfStr, OF_READ);
////        HANDLE fileMap = CreateFileMapping(inputFile, NULL, PAGE_READONLY, 0, 0, input);
//
//
//        // 파일을 만들어서 mmap 해서, lstat_s 처럼 사용할려고 했는데, 안된다.
//        hFile2 = (HANDLE)OpenFile(
//                aKeyFilePath,
//                &tOfStr,
//                OF_READ | OF_WRITE
//               );

        // 파일을 만들어서 mmap 해서, lstat_s 처럼 사용할려고 했는데, 안된다.
        hFile = CreateFile(
                aKeyFilePath,
                GENERIC_READ | GENERIC_WRITE,
                FILE_SHARE_READ | FILE_SHARE_WRITE,
                NULL,
                OPEN_EXISTING,
                FILE_ATTRIBUTE_TEMPORARY,
                //FILE_ATTRIBUTE_NORMAL,
                NULL
               );

        if ( hFile == INVALID_HANDLE_VALUE )
        {
            DBM_ERR( "CreateFile Fail. (err=%d)", GetLastError() );
            _THROW( -1 );
        }

        hMemoryMap = CreateFileMapping(
                hFile,                      // 파일 맵의 핸들, 초기에 INVALID_HANDLE_VALUE 를 설정한다.
                NULL,                       // 보안 속성
                PAGE_READWRITE,             // 읽고/쓰기 속성
                0,                          // 64비트 어드레스를 사용한다. 상위 32비트 - 메모리의 크기
                aSize,                      // 하위 32비트 - 여기선LPBYTE 타입.
                NULL                        // 공유 파일맵의 이름 - Uique 해야한다.
                );

        if ( hMemoryMap == NULL )
        {
            DBM_ERR( "OpenFileMapping Fail. (err=%d)", GetLastError() );
            _THROW( -1 );
        }

        pMemoryMap = (BYTE*)MapViewOfFile(
                hMemoryMap,                 // 파일맵의 핸들
//              FILE_MAP_ALL_ACCESS,        // 액세스 모드 - 현재는 쓰기
                FILE_MAP_WRITE,             // 액세스 모드 - 현재는 쓰기
//              PAGE_READWRITE,             // 액세스 모드 - 현재는 쓰기
                0,                          // 메모리 시작번지부터의 이격된 상위 32비트
                0,                          // 메모리 시작번지부터의 이격된 하위 32비트
                aSize                       // 사용할 메모리 블록의 크기 - 0이면 설정한 전체 메모리
        );

        if ( pMemoryMap == NULL )
        {
            DBM_ERR( "MapViewOfFile Fail. (err=%d)", GetLastError() );

            CloseHandle(hMemoryMap);
            _THROW( -1 );
        }
#else
        hMemoryMap = OpenFileMapping(
//              FILE_MAP_ALL_ACCESS,
                FILE_MAP_WRITE,             // 액세스 모드 - 현재는 쓰기
//              PAGE_READWRITE,
                FALSE,                      // 항상 FALSE인듯
                aKeyFilePath
               );

        if ( hMemoryMap == NULL )
        {
            DBM_ERR( "OpenFileMapping Fail. (err=%d)", GetLastError() );
            _THROW( -1 );
        }

        pMemoryMap = (BYTE*)MapViewOfFile(
                hMemoryMap,                 // 파일맵의 핸들
//              FILE_MAP_ALL_ACCESS,        // 액세스 모드 - 현재는 쓰기
                FILE_MAP_WRITE,             // 액세스 모드 - 현재는 쓰기
//              PAGE_READWRITE,             // 액세스 모드 - 현재는 쓰기
                0,                          // 메모리 시작번지부터의 이격된 상위 32비트
                0,                          // 메모리 시작번지부터의 이격된 하위 32비트
                aSize                       // 사용할 메모리 블록의 크기 - 0이면 설정한 전체 메모리
        );

        if ( pMemoryMap == NULL )
        {
            DBM_ERR( "MapViewOfFile Fail. (err=%d)", GetLastError() );

            CloseHandle(hMemoryMap);
            _THROW( -1 );
        }

#endif
        *aAttachAddr = pMemoryMap;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
#ifndef _USE_MAP_FILE
        //TODO: [OKT] 윈도포팅, 이렇게 하면 파일이 없으지나? "Global\\my_shm_key" 이런식으로 생성할때는 없어짐
        CloseHandle( hFile );
        CloseHandle( hMemoryMap );
#endif
    }
    _END
} /* cmnPShmAttach */

_VOID cmnPShmDetach ( void** ppAddr , long long aSize )
{
    _BOOL   sRC;

    _TRY
    {
        if ( *ppAddr == NULL )
            _RETURN;

        sRC = UnmapViewOfFile( *ppAddr );
        _IF_THROW( sRC == 0, ERR_CMN_MUNMAP );
        *ppAddr = NULL;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

_VOID cmnPShmDrop( const char* aKeyFilePath )
{
    char    sFileName[256] = { 0, };
    int     sRC;

    _TRY
    {
#ifdef _USE_MAP_FILE

        _IF_THROW( aKeyFilePath == NULL, ERR_CMN_INVALID_ARG );

//        if ( unlikely( aKeyFilePath[0] != '/' ) )
//        {
//            snprintf ( sFileName, sizeof(sFileName), "/%s", aKeyFilePath );
//            _BCALL( DeleteFile( sFileName ) );
//        }
//        else
        {
            snprintf ( sFileName, sizeof(sFileName), "%s.DODEL", aKeyFilePath );
            sRC = unlink( aKeyFilePath );
#if 0
            // TODO: [OKT] 윈도포팅, MS Windows에서 열려있는 파일을 unlink 혹은 rename이라도 할 수 있는 방법을 찾지 못함.
            if ( sRC != 0 && errno == EACCES )
            {
                _CALL( rename( aKeyFilePath, sFileName ) ); // 원래는 ERR_CMN_SHM_UNLINK 리턴.
            }
#endif
        }

        DBM_TRC( "DeleteFile ok. (%s) (err=%d,tid=%d)", aKeyFilePath, errno, gettid_s() );
#else
        //TODO: [OKT] 윈도포팅, 파일이 없는 매핑일때 shm_unlink 가 필요할까?
#endif
    }
    _CATCH
    {
        if ( errno != ENOENT )  /* = 2 */
        {
            // SegMgr에서 파일이 없다는 것을 확인하기 위해 한번도 호출하는 사용예가 있음. 때문에 INFO로 출력.
            _CATCH_INFO;
        }
        else
        {
            _rc = ERR_CMN_SHM_UNLINK;
        }
    }
    _FINALLY
    _END
}

_VOID cmnPShmGetStat ( const char* aKeyFilePath , struct stat* pStat )
{
    static int sLastCallTid = -1;
    char    sFileName[256] = { 0, };

    _TRY
    {
        _IF_THROW( aKeyFilePath == NULL, ERR_CMN_INVALID_ARG );

        /*
         * "c:\\my_shm_key"
         * "Global\\my_shm_key"
         */
        if ( aKeyFilePath[1] != ':' )
        {
            sprintf ( sFileName, "%s\\dic\\%s", getenv( ENV_DBM_HOME ), aKeyFilePath );
            //sprintf ( sFileName, "%s/dic/%s", getenv( ENV_DBM_HOME ), aKeyFilePath );
        }
        else
        {
            sprintf ( sFileName, "%s", aKeyFilePath );
        }

        _rc = lstat_s ( sFileName, pStat );
        _IF_THROW( _rc, ERR_CMN_LSTAT );

#if 0
        // cmnPosixShm.cpp:788:114: error: 'struct stat' has no member named 'st_blksize'
        DBM_TRC( "%s: st_ino(%d) st_nlink(%d) st_uid(%d) st_gid(%d) st_size(%d) st_blksize(%d)",
                 sFileName, pStat->st_ino, pStat->st_nlink, pStat->st_uid, pStat->st_gid, pStat->st_size, pStat->st_blksize );
#endif
    }
    _CATCH
    {

        if ( errno == ENOENT )
        {
            /*
             * 상위단에서 일시적인 오류 (TRUNCATE)인지 중복호출된다.
             * 중복로그를 줄이기위한 용도이므로, 동시성 구멍이 있어도 무방하다.
             */
            if ( sLastCallTid != gettid_s() )
            {
                _CATCH_DBG2(sFileName);
            }
        }
        else
        {
            _CATCH_INFO2(sFileName);
        }

        sLastCallTid = gettid_s();
    }
    _FINALLY
    {
        if ( _rc == 0 )
        {
            sLastCallTid = -1;
        }
    }
    _END
}

// 2015.02.22 -okt- 현재 테스트 샘플 외에 사용되는 곳 없음, 윈도포팅 제외
_VOID cmnPShmGetAttachNum ( const char* aKeyFilePath , int* aAttachNum )
{
    _DASSERT(0);
    return -1;
}

#endif /* __linux__ */
