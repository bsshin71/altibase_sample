/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/
#include "cmnLock.h"
#include "cmnUtil.h"

//2015.03.24 -okt- #680 futex_wait 에서 EAGAIN 감소 방식을 QUEUE에도 적용
#define FUTEX_NEW

/******************************************************************************
 * Name : cmnInitRWMutex
 *
 * Description
 *     Mutex객체를 Process Shared하게 설정한다.
 *
 * Argument
 *     aMutex   : 대상Mutex의 주소값을 입력한다.
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnInitRWMutex ( pthread_rwlock_t* aMutex )
{
    pthread_rwlockattr_t  sMutex_attr;
    int                  sRet;

    errno = 0;
    sRet = pthread_rwlockattr_init( &sMutex_attr );
    _IF_RAISE( sRet != 0, ATTR_INIT_ERROR );


    /*******************************************************
     * Process Shared로 만들고 초기화 시킨다.
    *******************************************************/
    sRet = pthread_rwlockattr_setpshared( &sMutex_attr, PTHREAD_PROCESS_SHARED );
    _IF_RAISE( sRet != 0, MUTEX_INIT_ERROR );

    sRet = pthread_rwlock_init( aMutex, &sMutex_attr );
    _IF_RAISE( sRet != 0, MUTEX_INIT_ERROR );

    pthread_rwlockattr_destroy( &sMutex_attr );

    return RC_SUCCESS;

    _EXCEPTION(ATTR_INIT_ERROR )
    {
        sRet = ERR_SYSCALL_PTHREAD_ATTR_INIT;
    }

    _EXCEPTION( MUTEX_INIT_ERROR )
    {
        sRet = ERR_SYSCALL_PTHREAD_MUTEX_INIT;
    }

    _EXCEPTION_END;
    return sRet;
}


/******************************************************************************
 * Name : cmnInitMutex
 *
 * Description
 *     Mutex객체를 Process Shared하게 설정한다.
 *
 * Argument
 *     aMutex   : 대상Mutex의 주소값을 입력한다.
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnInitMutex ( pthread_mutex_t* aMutex )
{
    pthread_mutexattr_t  sMutex_attr;
    int                  sRet;

    errno = 0;
    sRet = pthread_mutexattr_init( &sMutex_attr );
    _IF_RAISE( sRet != 0, ATTR_INIT_ERROR );

    /*******************************************************
     * Process Shared로 만들고 초기화 시킨다.
    *******************************************************/
#ifdef _DEBUG
    // [note] X 제품에서 사용된 설정. 기본으로 넣어야할까?
    sRet = pthread_mutexattr_setprotocol( &sMutex_attr, PTHREAD_MUTEX_ERRORCHECK );
    _IF_RAISE( sRet != 0, MUTEX_INIT_ERROR );
#endif

#ifdef __USE_UNIX98
    sRet = pthread_mutexattr_setprotocol( &sMutex_attr, PTHREAD_PRIO_INHERIT );         // -D__USE_UNIX98
    _IF_RAISE( sRet != 0, MUTEX_INIT_ERROR );
#else
    // 거짓 컴파일 오류 ( eclipse ) 때문에 추가한 것으로 여기에 진입하지 않는다.
    _DASSERT ( 0 );
#endif

    //TODO: 2014.11.20. -okt- gcc 4.4.3 에서 pthread_getname_np 미지원.
#ifdef EHWPOISON
    sRet = pthread_mutexattr_setrobust( &sMutex_attr, PTHREAD_MUTEX_ROBUST_NP );        // -D__USE_XOPEN2K
    _IF_RAISE( sRet != 0, MUTEX_INIT_ERROR );
#endif

    sRet = pthread_mutexattr_setpshared( &sMutex_attr, PTHREAD_PROCESS_SHARED );
    _IF_RAISE( sRet != 0, MUTEX_INIT_ERROR );

    /*******************************************************
     * Process Shared로 여러번 lock이 호출되도 한번만 풀리도록.
    *******************************************************/
    sRet = pthread_mutexattr_settype( &sMutex_attr, PTHREAD_MUTEX_RECURSIVE_NP );
    _IF_RAISE( sRet != 0, MUTEX_INIT_ERROR );

    /*******************************************************
     * Process Shared로 성능에 좋다는데 효과없음.
    *******************************************************/
    sRet = pthread_mutexattr_settype( &sMutex_attr, PTHREAD_MUTEX_ADAPTIVE_NP );
    _IF_RAISE( sRet != 0, MUTEX_INIT_ERROR );

    sRet = pthread_mutex_init( aMutex, &sMutex_attr );
    _IF_RAISE( sRet != 0, MUTEX_INIT_ERROR );

    pthread_mutexattr_destroy(&sMutex_attr );

    return RC_SUCCESS;

    _EXCEPTION(ATTR_INIT_ERROR )
    {
        sRet = ERR_SYSCALL_PTHREAD_ATTR_INIT;
    }

    _EXCEPTION( MUTEX_INIT_ERROR )
    {
        sRet = ERR_SYSCALL_PTHREAD_MUTEXATTR_SETTYPE;
    }

    _EXCEPTION_END;
    return sRet;
} /* cmnInitMutex */


/******************************************************************************
 * Name : cmnInitCond
 *
 * Description
 8    pthread-Cond변수를 process shared하게 설정한다.
 *
 * Argument
 *    aCond : pthread-cond변수
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnInitCond ( pthread_cond_t* aCond )
{
    int          sRet;
    pthread_condattr_t sCond_attr;


    errno = 0;
    sRet = pthread_condattr_init( &sCond_attr );
    _IF_RAISE( sRet != 0, COND_INIT_ERROR );

    /*******************************************************
     * Process Shared로 만들고 초기화 시킨다.
    *******************************************************/
    sRet = pthread_condattr_setpshared( &sCond_attr, PTHREAD_PROCESS_SHARED );
    _IF_RAISE( sRet != 0, COND_INIT_ERROR );

    sRet = pthread_cond_init( aCond, &sCond_attr );
    _IF_RAISE( sRet != 0, COND_INIT_ERROR );

    pthread_condattr_destroy(&sCond_attr );

    return RC_SUCCESS;

    _EXCEPTION( COND_INIT_ERROR )
    {
        sRet = ERR_SYSCALL_PTHREAD_COND_INIT;
    }

    _EXCEPTION_END;
    return sRet;
}


/******************************************************************************
 * Name : cmnLockMutex
 *
 * Description
 *     mutex lock을 잡는다.
 *
 * Argument
 *     aMutex     : pthread_mutex변수 (cmnInitMutex가 된놈 )
 *     aSpinCount : spinCount만큼 시도한다.
 *
******************************************************************************/
_VOID cmnLockMutex ( pthread_mutex_t* aMutex , int aSpinCount )
{
    int     sRC;
    int     sTry = 0;

    _TRY
    {
        while ( 1 )
        {
            /*************************************************
             * SpinCount가 0이면 무한대기로 Lock을 잡고
             * 그렇지 않으면 tryLock으로 시행한다.
             *************************************************/
            // errno = 0;   // [주의] 막아야함, 상위단에서 errno를 검사하는 코드가 있음.
            if ( aSpinCount == 0 )
            {
                sRC = pthread_mutex_lock ( aMutex );
            }
            else
            {
                sRC = pthread_mutex_trylock ( aMutex );
            }

            /**********************************************
             * EBUSY면 다른놈이 락을 잡은 상태고
             *  SpinCount만큼 재시도한다.
             * 그외 에러는 리턴한다.
             **********************************************/
            switch ( sRC )
            {
                case 0:
                    return sRC;
                case EBUSY:
                    if ( aSpinCount <= 0 )
                    {
                        return sRC;
                    }
                    else if ( sTry++ >= aSpinCount )
                    {
                        return EBUSY;
                    }
                    break;
                default:
                    return sRC;
            }
        } /* while */
    }
    _CATCH
    _FINALLY
    _END
}


/******************************************************************************
 * Name : cmnUnlockMutex
 *
 * Description
 *     mutex lock을 해제한다.
 *
 * Argument
 *     aMutex     : pthread_mutex변수 (cmnInitMutex가 된놈 )
 *
******************************************************************************/
_VOID cmnUnlockMutex ( pthread_mutex_t* aMutex )
{
    _TRY
    {
        // errno = 0;   // [주의] 막아야함, 상위단에서 errno를 검사하는 코드가 있음.
        _IF_THROW( pthread_mutex_unlock( aMutex ), ERR_SYSCALL_PTHREAD_MUTEX_UNLOCK );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


/******************************************************************************
 * Name : cmnCondWait
 *
 * Description
 *     condition변수를 지정된 시간만큼 재운다.
 *
 * Argument
 *     aCond      : pthread_cond변수 (cmnInitCond가 된놈)
 *     aMutex     : pthread_mutex변수 (cmnInitMutex가 된놈)
 *     aUntilTime : Microsecond (0이면 무한대기다.)
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
_VOID cmnCondWait ( pthread_cond_t* aCond , pthread_mutex_t* aMutex , int aUntilTime )
{
    struct timespec sTimer;
    int             sTimeout_us = aUntilTime;

    _TRY
    {
        clock_gettime_s( CLOCK_REALTIME, &sTimer );
        /*******************************************************************
         * 1초보다 크면 무조건 1초로
         * 1초이내인데 nsec연산이 1초를 넘어가면 조정
        *******************************************************************/
        if ( sTimeout_us >= 1000000 )
        {
            sTimer.tv_sec  = sTimer.tv_sec + (sTimeout_us / 1000000 );
            sTimeout_us = sTimeout_us - (sTimeout_us / 1000000) * 1000000;
            if ( sTimeout_us < 0) sTimeout_us = 0;
        }

        if ( ( sTimer.tv_nsec  + (sTimeout_us * 1000) ) >= 1000000000L )
        {
            sTimer.tv_sec  = sTimer.tv_sec + 1;
            sTimer.tv_nsec = 1000000000L - sTimer.tv_nsec;
        }
        else
        {
            sTimer.tv_nsec = sTimer.tv_nsec + (sTimeout_us * 1000 );
        }


        /****************************************
         * 대기시간이 0이면 무한정 대기모드로
         * 그외에는 Timeout만큼 대기하도록 한다.
        ****************************************/
        switch ( aUntilTime )
        {
            case 0:
                _rc = pthread_cond_wait( aCond, aMutex );
                break;
            default:
                _rc = pthread_cond_timedwait( aCond, aMutex, &sTimer );
                break;
        }

        if ( _rc != 0 )
        {
            DBM_TRC( "pthread_cond_wait error, rc=%d (err=%d)", _rc, errno );
            if ( aUntilTime == 0 )
            {
                _THROW( ERR_SYSCALL_PTHREAD_COND_WAIT );
            }
            else
            {
                _THROW( ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT );
            }
        }
    }
    _CATCH
    {
        if ( _rc != ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT )
        {
            _CATCH_INFO;
        }
    }
    _FINALLY
    _END
}



/******************************************************************************
 * Name : cmnCondBroadCast
 *
 * Description
 *    cond변수에 대기중인 모든 Session들을 깨운다.
 *
 * Argument
 *    aCond : pthread-cond 변수 (initcond된것 )
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnCondBroadCast ( pthread_cond_t* aCond )
{
    int          sRet;

    errno = 0;
    sRet = pthread_cond_broadcast( aCond );
    _IF_RAISE( sRet !=0, COND_SIG_ERROR );

    return RC_SUCCESS;

    _EXCEPTION( COND_SIG_ERROR )
    {
        sRet = ERR_SYSCALL_PTHREAD_COND_BROADCAST;
    }

    _EXCEPTION_END;
    return sRet;
}



/******************************************************************************
 * Name : cmnCondSignal
 *
 * Description
 *     aCond변수에 대기중인 하나의 Session을 깨운다. 누가 일어날지는 알수없음.
 *
 * Argument
 *     aCond : pthread-cond 변수 (initCond된 것 )
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnCondSignal ( pthread_cond_t* aCond )
{
    int          sRet;

    errno = 0;
    sRet = pthread_cond_signal( aCond );
    _IF_RAISE( sRet !=0, COND_SIG_ERROR );

    return RC_SUCCESS;

    _EXCEPTION( COND_SIG_ERROR )
    {
        sRet = ERR_SYSCALL_PTHREAD_COND_SIGNAL;
    }

    _EXCEPTION_END;
    return sRet;
}



/******************************************************************************
 * Name : cmnLockFutex
 *
 * Description
 *    CAS로 SpinLock을 시도한다. Lock을 잡지 않는 이상 빠져나오지 않음.
 *
 * Argument
 *    aLock      : lock대상 변수의 포인터
 *    aCond      : cond대상 변수의 포인터
 *    aValue     : aLock에 설정하려는 값
 *    aSpinCount : tryLock횟수
 *    aUntilTime : sleep 시간
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnLockFutex ( int*     aLock,
                   int      aValue,
                   int      aSpinCount )
{
    int               sOldValue;
    int               sSpin = 0;


    while ( 1 )
    {
        /***********************************************
         * Lock을 잡으려고 시도한다.
        ***********************************************/
        sOldValue = mvpAtomicCas32( aLock, aValue, -1 );
        if ( sOldValue == -1 || sOldValue == aValue )
        {
            break;
        }

        /***********************************************
         * try횟수가 리턴해버린다.
        ***********************************************/
        if ( aSpinCount > 0 && sSpin++ >= aSpinCount )
        {
            return sOldValue;
        }
    }

    return RC_SUCCESS;
}



/******************************************************************************
 * Name : cmnUnlockFutex
 *
 * Description
 *    Lock을 해제한다.
 *
 * Argument
 *    aLock     : Lock대상 포인터
 *    aCond     : 깨울놈의 변수포인터
 *    aValue    : Lock을 잡아놓은 변수의 값
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnUnlockFutex ( int* aLock , int aValue )
{
    int             sOldValue;


    /******************************************
     * 자기가 잡은거만 풀 수 있음.
     * AtomicSet해버리면 동시성 깨짐.
    ******************************************/
    sOldValue = mvpAtomicCas32( aLock, -1, aValue );
    if ( sOldValue != aValue )
    {
        return sOldValue;
    }

    return RC_SUCCESS;
}




/******************************************************************************
 * Name : cmnWaitFutex
 *
 * Description
 *     지정된 시간만큼 대기한다. ( aTimeout = microsecond )
 *
 * Argument
 *     aCond    : cond변수로 쓸 포인터
 *     aTimeout : Timeout값
 *
******************************************************************************/
_VOID cmnWaitFutex( volatile int* aCond, int aTimeout )
{
    struct timespec sTimeout;
    int             sRC;

    /***************************************
     * Timeout입력이 us단위라고 보고 계산.
    ***************************************/
    if ( aTimeout == 0 ) // 음수면 거의 하루 대기로 봅시다. (OKT) 0초 대기는 어떻게 하는가?
    {
        sTimeout.tv_sec  = 999999;
        sTimeout.tv_nsec = 0;
    }
    else if ( aTimeout < 1000000 )
    {
        // 나누기 비용 아깝다.
        sTimeout.tv_sec  = 0;
        sTimeout.tv_nsec = aTimeout * 1000;
    }
    else
    {
        sTimeout.tv_sec  = aTimeout / 1000000;
        sTimeout.tv_nsec = aTimeout % 1000000 * 1000;
    }

    errno = 0; // 아래서 "sRC == -1" 검사를 함께 하기때문에 굳이 필요는 없다.
    /***************************************
     * 일단 Timeout만큼 쉬고 깬다.
     * 물론 그전에 이벤트가 나오면 바로 꺤다.
    ***************************************/
#ifndef FUTEX_NEW
    sRC = futex_wait( aCond, 0, &sTimeout );        // 2014.11.24. 기존 (2.1.0)
#else
    sRC = futex_wait( aCond, *aCond, &sTimeout );
#endif
    if ( sRC == -1 && errno == ETIMEDOUT )
    {
        return ETIMEDOUT;
    }
    else
    {
        // 2014.11.14. -okt- 이걸 없애볼려고 시도를 하면 큐 테스트가 성능 떨어지고, 1027발생하고 망가진다.
        atomic_dec( aCond );
        if ( *aCond < 0 )
        {
            *aCond = 0;
        }
    }

#ifdef _DEBUG
    if ( sRC == -1 )
    {
        static long long sECnt = 0;
        static long long sECntAagin = 0;
        static long long sECntInval = 0;

        // 2014.11.14 -okt- 어떤 실패 경우가 있는지 확인하는 용도. 여기서 죽는 경우가 있으면 추가한다.
        if ( errno != EAGAIN && errno != EINVAL )
        {
            _ASSERT( 0 );
        }
        else
        {
            sECnt ++;
            if ( sECnt < 10 )
            {
                DBM_INFO( "futex_wait error count monitor, [%ld,A,%ld,I,%ld] (err=%d,tid=%d)", sECnt, sECntAagin, sECntInval, errno, gettid_s() );
            }
            else
            {
                if ( BITMOD( sECnt, 8192 ) == 0 )
                {
                    DBM_INFO( "futex_wait error count monitor, [%ld,A,%ld,I,%ld] (err=%d,tid=%d)", sECnt, sECntAagin, sECntInval, errno, gettid_s() );
                }
            }

            if ( errno == EAGAIN )
            {
                atomic_inc( &sECntAagin );
            }
            else if ( errno == EINVAL )
            {
                atomic_inc( &sECntInval );
            }
        }
    }
#endif

    return RC_SUCCESS;
} /* cmnWaitFutex */


// 2014.11.14. -okt- SpinLock에서 사용을 위한 좀더 가벼운 버전.
#define FUTEX_WAIT_TIME_NS             100000000  // 0.1초 /* TODO: -okt- 위치이동요. dbmDefine.h */
_VOID cmnWaitFutex2( volatile int* aCond )
{
    struct timespec sTimeout = { 0, FUTEX_WAIT_TIME_NS };  // 나누기 비용 아깝다.
    int             sRC;

    errno = 0; // 아래서 "sRC == -1" 검사를 함께 하기때문에 굳이 필요는 없다.
    /***************************************
     * 일단 Timeout만큼 쉬고 깬다.
     * 물론 그전에 이벤트가 나오면 바로 꺤다.
    ***************************************/
    // 2014.11.25 -okt- 깨울때 값과, 대기할때 값 *aCond를 같게 사용하지 않으면 EAGAIN 빨썡
    //sRC = futex_wait( aCond, 0, &sTimeout ); // 기존 (2.1.0)
    sRC = futex_wait( aCond, *aCond, &sTimeout );
    if ( sRC == -1 && errno == ETIMEDOUT )
    {
        return ETIMEDOUT;
    }

#ifdef _DEBUG
    if ( sRC == -1 )
    {
        static long long sECnt = 0;
        static long long sECntAagin = 0;
        static long long sECntInval = 0;

        // 2014.11.14 -okt- 어떤 실패 경우가 있는지 확인하는 용도. 여기서 죽는 경우가 있으면 추가한다.
        if ( errno != EAGAIN && errno != EINVAL )
        {
            _ASSERT( 0 );
        }
        else
        {
            sECnt ++;
            if ( sECnt < 10 )
            {
                DBM_INFO( "futex_wait error count monitor, [%ld,A,%ld,I,%ld] (err=%d,tid=%d)", sECnt, sECntAagin, sECntInval, errno, gettid_s() );
            }
            else
            {
                if ( BITMOD( sECnt, 8192 ) == 0 )
                {
                    DBM_INFO( "futex_wait error count monitor, [%ld,A,%ld,I,%ld] (err=%d,tid=%d)", sECnt, sECntAagin, sECntInval, errno, gettid_s() );
                }
            }

            if ( errno == EAGAIN )
            {
                atomic_inc( &sECntAagin );
            }
            else if ( errno == EINVAL )
            {
                atomic_inc( &sECntInval );
            }
        }
    }
#endif

    return RC_SUCCESS;
} /* cmnWaitFutex2 */


/******************************************************************************
 * Name : cmnSignalFutex
 *
 * Description
 *    cond에 대기중인 Session을 1개 깨운다.
 *
 * Argument
 *    aCond : Condition변수로 쓸 변수의 포인터
 *
******************************************************************************/
void cmnSignalFutex ( volatile int* aCond )
{
    /************************************
     * Futex를 통해 깨운다.
    ************************************/
#ifndef FUTEX_NEW
    atomic_inc( aCond );
    futex_wake( aCond, 0 );
#else
    futex_wake( aCond, *aCond );
#endif
}


// _DEBUG 모드가 아니면 매크로로 futex_wake를 바로 진입한다.
void cmnSignalFutex2_( volatile int* aCond )
{
    /************************************
     * Futex를 통해 깨운다.
    ************************************/
    // 2014.11.25 -okt- 깨울때 값과, 대기할때 값 *aCond를 같게 사용하지 않으면 EAGAIN 빨썡
    futex_wake( aCond, *aCond );
}

