/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/
#include "cmnHeader.h"

//TODO: [OKT] 윈도포팅, 사용하지 않는 소스 막음.
#ifdef __linux__

#define   STDOUT  1
/*******************************************************************************
 *
 * Log Handle 의 메모리 맵은 다음과 같다.
 *
 *
 * cmnLogHandle +  cmnLogHeader* 로그 갯수 +
 *                  cmnLogHandle.mLogLineLength * 로그갯수
 ******************************************************************************/




/*******************************************************************************
 * Name : cmnOpenLog
 *
 * Description
 *     Logging 할 파일을 열고 ,  Logging 버퍼를 준비한다. 순서는 다음과 같다.
 *
 *     1.  파일이 있는지 확인하고, 없으면 새롭게 생성한다.
 *     2.  메모리를 할당 받고, 초기화한다.
 *     3.  Sync Thread 를 생성한다.
 *     4.  사용자에게 리턴한다.
 *
 * Argument
 *      aLogFile  : 로깅할 로그 파일 위치 ( 절대 경로 )
 *      aLogLevel : _cmnLogLevel 타입에 맞는 로깅 대상 수집용.
 *      aLogBufferLength : Log 한 줄의 크기 0 일경우 기본값 (1024 )
 *      aLogBufferCount  : Shared memory 에 저장할 Log 의 총갯수 0일 경우
 *                         기본값 ( 1024 )
 *      aHandle  : Logging 핸들임.
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/


int cmnOpenLog ( char*          aLogFile,
                 char           aLogLevel,
                 int            aLogBufferLength,
                 int            aLogBufferCount ,
                 cmnLogHandle** aHandle )
{

    int             sSize;
    cmnLogHandle*   sLogHandle;

    /* 사용자 인자가 아무 것도 없다면, 기본값으로 세팅 */
    if ( aLogBufferLength == 0 )
    {
        aLogBufferLength = 1024;
    }

    /*-------------------------------------------------------------
     * LogBufferCount가 0일 경우 파일에 바로 쓰기 구현
    if ( aLogBufferCount == 0 )
    {
        //aLogBufferCount = 1024 ;
    }
     -------------------------------------------------------------*/

    /* 로깅 할 사이즈를 계산해놓는다. */
    sSize = ( aLogBufferLength  * aLogBufferCount ) + sizeof( cmnLogHandle ) + sizeof( cmnLogHeader ) * aLogBufferCount;

    /* 메모리를 할당해놓는다. */
    sLogHandle = ( cmnLogHandle* ) malloc_s ( sSize ) ;
    _IF_RAISE ( sLogHandle == NULL, MEM_ALLOC_ERROR );


    /* 메모리 초기화 */
    memset_s ( sLogHandle, 0x00, sSize );

    sLogHandle->mLogLevel = ( _cmnLogLevel )aLogLevel;
    sLogHandle->mLogBufCount = aLogBufferCount;
    sLogHandle->mLogLineLength = aLogBufferLength ;
    /*-------------------------------------------------------------
     * 최초 쓰기 기 0번에 쓰기 위한 초기값 설정
     -------------------------------------------------------------*/
    sLogHandle->mWriteIndicator = -1;
    sLogHandle->mSyncIndicator = -1;


    if ( aLogFile == NULL )
    {
        sLogHandle->mFD = STDOUT;
    }
    else
    {
    	// 앞에 한바이트만 검사. 중복코드
    	if ( aLogFile[0] == '?' && aLogFile[1] == '/' )
    	{
            snprintf ( sLogHandle->mLogFileName, MAX_FILE_NAME_LENGTH, "%s/%s", getenv( ENV_DBM_HOME ), aLogFile+2 ) ;
    	}
    	else if ( aLogFile[0] == '~' && aLogFile[1] == '/' )
    	{
    	    snprintf ( sLogHandle->mLogFileName, MAX_FILE_NAME_LENGTH, "%s/%s", getenv("HOME"), aLogFile+2 ) ;
		}
    	else
    	{
            strncpy_s ( sLogHandle->mLogFileName, aLogFile, MAX_FILE_NAME_LENGTH ) ;
    	}

        /* 파일을 열겠다. */
        sLogHandle->mFD = open ( sLogHandle->mLogFileName, O_WRONLY | O_CREAT | O_APPEND , _cmn_file_mode ) ;
        _IF_RAISE ( sLogHandle->mFD < 2 , CAN_NOT_OPEN_LOG ) ;
    }

    /* Synchor Thread 를 생성한다. */
    _IF_RAISE ( cmnCreateLogThread ( sLogHandle ), THREAD_CREATION_FAILED );

    * aHandle = sLogHandle;

    return RC_SUCCESS ;


    _EXCEPTION( CAN_NOT_OPEN_LOG )
    {
        return -3 ;
    }
    _EXCEPTION( MEM_ALLOC_ERROR )
    {
        return -3 ;
    }
    _EXCEPTION( THREAD_CREATION_FAILED )
    {
        return -4;
    }
    _EXCEPTION_END;

    return -99;
}

void     cmnWriteLogFile    ( cmnLogHandle* aLogHandle, cmnLogHeader* aLogHeader, char* aLogMsg)
{
    char            sMsg[MAX_SIZE_PER_LOG], sTime2[16];
    char            sLogLevelString[2];
    struct  tm      sTime;

    switch ( (_cmnLogLevel )aLogHeader->mLogLevel )
    {
        case C :
            strcpy_s ( sLogLevelString, "C" );
            break;
        case E :
            strcpy_s ( sLogLevelString, "E" );
            break;
        case W :
            strcpy_s ( sLogLevelString, "W" );
            break;
        case D :
            strcpy_s ( sLogLevelString, "D" );
            break;
        case I :
            strcpy_s ( sLogLevelString, "I" );
            break;
        default :
            strcpy_s ( sLogLevelString, "A" );
            break;
    }

    localtime_r_s( &aLogHeader->mTime.tv_sec, &sTime );
    sprintf ( sTime2, "%06ld", aLogHeader->mTime.tv_usec );

    sprintf ( sMsg ,
            "%02d:%02d:%02d.%6.6s-%.1s-[%-15.15s:%4d] %s",
            sTime.tm_hour,
            sTime.tm_min,
            sTime.tm_sec,
            sTime2,
            sLogLevelString,
            aLogHeader->mFunctionName,
            aLogHeader->mLine,
            aLogMsg );

    write( aLogHandle->mFD, sMsg, strlen_s( sMsg ) );
}

/******************************************************************************
 * Name : cmnLogImp
 *
 * Description
 *     사용자가 Logging 할 내용에 대해서 실제 Shared memory 공간으로 Copy 한다.
 *     인자가 많아 사용자가 쓰기 불편하기 때문에 cmnLog 라는 이름으로 Macro
 *     해서 정의한다.
 *
 *
 * Argument
 *
 *      aLogHandle    : Heap Memory 의 첫번째 주소를 가르키는 인자.
 *      aLogLevel     : Logging 시 남길 로그 레벨
 *      aFunctionName : Function 명
 *      aLineNumber   : 로그 라인
 *      aFormat       : 포멧
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/

int cmnLogImp     ( cmnLogHandle*   aLogHandle,
                    int             aLogLevel ,
                    const char*     aFunctionName,
                    int             aLineNumber,
                    const char*     aFormat ,
                    ... )
{

    va_list         sArgs;
    cmnLogHeader    sLogHeader;
    long long       sWriteInd;
    int             sLogLength;
    char            sLogMsg [MAX_SIZE_PER_LOG] ;
    char*           sDestAddr = NULL;
    char*           sDestHeaderAddr = NULL;

    /** Shared Memory 에 존재하는 Logging Level 과 주어진 Logging Level 간의
     * AND 연산을 통해서 로깅 여부를 판단한다. **/
    if (aLogHandle == NULL)
    {
        return RC_SUCCESS;
    }

    if ( ( aLogHandle->mLogLevel & aLogLevel )  == 0 )
    {
        /* 이경우는 남길 필요가 없다고 보겠다. */
        return RC_SUCCESS;
    }

    memset_s ( sLogMsg , 0x00, MAX_SIZE_PER_LOG ) ;


    /* 가변 길이 문자열을 조사하여 포멧을 변환 */
    va_start ( sArgs , aFormat ) ;
    sLogLength = vsprintf( sLogMsg, aFormat, sArgs );
    va_end ( sArgs );

    /* sLogLength 는 버퍼의 크기가 남기는데 이게 로컬 배열 크기보다 크다면 위험하니까
     * 넘어가는지 판단해서 에러처리 */


    /* 로그 헤더를 기록한다. */
    memset_s( &sLogHeader, 0x00, sizeof( sLogHeader ) );
    strncpy ( sLogHeader.mFunctionName, aFunctionName, FUNCTION_NAME_LENGTH );
    sLogHeader.mLogLevel = aLogLevel;
    sLogHeader.mLine = aLineNumber;
    sLogHeader.mSz = sLogLength;
    gettimeofday( &sLogHeader.mTime, NULL );
    /*-------------------------------------------------------------
     * 쓰여진 로그로 표시하기 위해 1로 변경
     -------------------------------------------------------------*/
    sLogHeader.mWriteCommitFlag = 1;


    /*-------------------------------------------------------------
     * LogBufferCount가 0일 경우 파일에 바로 쓰기 구현
     -------------------------------------------------------------*/
    if( aLogHandle->mLogBufCount > 0 )
    {
        goto BUFFERED;
    }
    else
    {
        goto DIRECT;
    }

DIRECT:
    /*-------------------------------------------------------------
     * 파일에 바로 쓰기 구현
     -------------------------------------------------------------*/
    cmnWriteLogFile( aLogHandle, (cmnLogHeader *)&sLogHeader, sLogMsg );
    goto end;

BUFFERED:

    while( aLogHandle->mWriteIndicator - aLogHandle->mSyncIndicator > aLogHandle->mLogBufCount - 1 )
    {
        usleep( 100 );
    }

    /** Shared memory 에 내가 Copy 할 위치를 찾아낸다. 동시에 여러 Process 가
     * 올 수 있기 때문에 Atomic 으로 진행 */
    //sWriteInd = ( mvpAtomicInc64 ( &aLogHandle->mWriteIndicator ) % aLogHandle->mLogBufCount ) - 1;
    sWriteInd = mvpAtomicInc64 ( &aLogHandle->mWriteIndicator ) % aLogHandle->mLogBufCount;
    //sWriteInd = aLogHandle->mWriteIndicator % aLogHandle->mLogBufCount;


    /** 내가 쓸 위치를 알았기 떄문에  복사할 메모리 주소를 얻는다. */
    sDestAddr = ( char* ) aLogHandle + sizeof(cmnLogHandle) +
                 sizeof(cmnLogHeader) * aLogHandle->mLogBufCount  +
                 sWriteInd * aLogHandle->mLogLineLength ;

    sDestHeaderAddr = ( char* ) aLogHandle + sizeof(cmnLogHandle) +
                      sizeof(cmnLogHeader) * sWriteInd;

    /** 복사 고고 */
    memcpy_s ( sDestHeaderAddr , &sLogHeader, sizeof(cmnLogHeader) );
    strncpy ( sDestAddr , sLogMsg , sLogLength > aLogHandle->mLogLineLength ? aLogHandle->mLogLineLength : sLogLength );

    //mvpAtomicInc64 ( &aLogHandle->mWriteIndicator );

    /* 복사를 했으므로 Condition Variable 을 통해 깨워준다. */

    pthread_mutex_lock ( &aLogHandle-> mCondMutex ) ;
    pthread_cond_signal ( &aLogHandle-> mCond ) ;
    pthread_mutex_unlock ( &aLogHandle-> mCondMutex );

    goto end;

end:
    return RC_SUCCESS ;
}



/******************************************************************************
 * Name : cmnSyncLogFile
 *
 * Description
 *     Thread Function 에 인자로 전달되는 함수로써, Thread Function 이다.
 *     Condition Variable 을 검사하고 있다가 깨워지면, 로그를 Write 한다.
 *
 *     실제 파일에 fsync 까지 수행할지는 미정임.
 *
 *
 * Argument
 *
 *      aThreadParam    : Thread Function 으로 넘어온 인자.
 *
 * Return
 *      This Function never Returns
 *
******************************************************************************/

void*    cmnSyncLogFile     ( void* aLogHandle )
{

    int             sRC;
    cmnLogHeader*   sLogHeader;
    long long       sSyncInd;

    cmnLogHandle*   sLogHandle;

    char            sMsg[MAX_SIZE_PER_LOG], sTime2[16];

    struct  tm*     sTime;

    char*           sLogMsgStartAddr;
    int             sHeaderLength;

    char            sLogLevelString[2];

    struct  timespec    sWaitTime;


    /** 주기적으로 깨어날 시간을 세팅 **/

    sLogHandle = (cmnLogHandle*) aLogHandle ;
    /* 로그의 첫번째 시작 위치를 얻어낸다 */
    sLogMsgStartAddr = (char*)(aLogHandle) + sizeof(cmnLogHandle) +
                       sizeof(cmnLogHeader) * sLogHandle->mLogBufCount ;


    /* 로그 헤더의 위치를 세팅 */

    sLogHeader =  (cmnLogHeader*)( (char*)aLogHandle + sizeof(cmnLogHandle) );

    /* 변수 초기화 */
    memset_s ( sMsg, 0x00, MAX_SIZE_PER_LOG );

    /* 한번에 내려 쓰기 위한 Vector 선언 */
    struct  iovec   sVector [2];


    /*  Shared memory 로 부터 내가 써야할 것이 있는지 계속 체크를 수행한 후
     *  Log File 로 남길 것이 존재한다면 해당 Log file 을  쓴다. */
    while ( 1 )
    {

        /* 지금 써야할 것이 존재하는지 파악 */
        if ( mvpAtomicGet64 ( &sLogHandle->mWriteIndicator ) >
            mvpAtomicGet64 ( &sLogHandle->mSyncIndicator ) )
        {
            /*-------------------------------------------------------------
             * 초기값 -1 설정에 의한 조치
             -------------------------------------------------------------*/
            //sSyncInd = sLogHandle->mSyncIndicator % sLogHandle->mLogBufCount ;
            sSyncInd = ( sLogHandle->mSyncIndicator + 1 ) % sLogHandle->mLogBufCount ;

            /*-------------------------------------------------------------
             * 버퍼에 정상적으로 적재되었는지 확인
             -------------------------------------------------------------*/
            if( sLogHeader[sSyncInd].mWriteCommitFlag == 0 )
            {
                usleep(100);
                continue;
            }

            switch ( (_cmnLogLevel )sLogHeader [sSyncInd].mLogLevel )
            {
                case C :
                    strcpy_s ( sLogLevelString, "C" );
                    break;
                case E :
                    strcpy_s ( sLogLevelString, "E" );
                    break;
                case W :
                    strcpy_s ( sLogLevelString, "W" );
                    break;
                case D :
                    strcpy_s ( sLogLevelString, "D" );
                    break;
                case I :
                    strcpy_s ( sLogLevelString, "I" );
                    break;
                default :
                    strcpy_s ( sLogLevelString, "A" );
                break;
            }


            sTime = localtime_s ( & sLogHeader[sSyncInd].mTime.tv_sec );
            sprintf ( sTime2, "%06ld", sLogHeader[sSyncInd].mTime.tv_usec );

            sHeaderLength = sprintf ( sMsg ,
                                      "%02d:%02d:%02d.%6.6s-%.1s-[%-15.15s:%4d] ",
                                      sTime->tm_hour,
                                      sTime->tm_min,
                                      sTime->tm_sec,
                                      sTime2,
                                      sLogLevelString,
                                      sLogHeader[sSyncInd].mFunctionName,
                                      sLogHeader[sSyncInd].mLine );

            /**** 한번에 Msg 를 모아서 모아 쓰겠다. *****/

            sVector [0].iov_base = sMsg;
            sVector [0].iov_len = sHeaderLength ;
            sVector [1].iov_base = sLogMsgStartAddr  + ( sSyncInd * sLogHandle->mLogLineLength) ;
            sVector [1].iov_len = sLogHeader[sSyncInd].mSz;



            sRC = writev ( sLogHandle->mFD, sVector, 2 );

            /*-------------------------------------------------------------
             * 로그를 정상적으로 썼기에 표식을 다시 0으로
             -------------------------------------------------------------*/
            sLogHeader[sSyncInd].mWriteCommitFlag = 0;
            mvpAtomicInc64 ( & sLogHandle->mSyncIndicator ) ;
        }
        /* 할게 없다. 만약 프로그램 정상 종료인 상태에서는 리턴해줘야함.  */
        else
        {

            /** BUGFIX : 여기서 버그가 있었따. 사용자가 걍  Create 를 수행하고 Close 를 바로 수행하면 ,
             *  깨어나야할 시점을 놓쳐서 영원히 잠들게 된다. 이를 해결하기 위해서  pthread_cond_timedwait
             *  을 사용하고,  time을 다 써서 깨어나면 Continue 하게 해야한다 */

            if ( sLogHandle->mIsStop  )
            {
                // [OKT] 이건 먼가?
                // cmnLog.cpp:474: error: lvalue required as left operand of assignment
//                free_s(0);

                /** 열어놓은 파일을 닫아놓는다 */
                close_s ( sLogHandle->mFD );

                return 0 ;
            }

            /* 잔다. */
            pthread_mutex_lock ( & sLogHandle->mCondMutex ) ;
            clock_gettime_s(CLOCK_REALTIME, &sWaitTime);
            sWaitTime.tv_nsec = sWaitTime.tv_nsec + 100000 ;
            sRC = pthread_cond_timedwait ( &sLogHandle->mCond, &sLogHandle->mCondMutex , &sWaitTime);
            if ( sRC == ETIMEDOUT )
            {
                pthread_mutex_unlock ( & sLogHandle->mCondMutex ) ;
                continue;
            }
            else
            {
                pthread_mutex_unlock ( & sLogHandle->mCondMutex ) ;
            }


        }
    }

    /** 여기까지 올일은 없지만 Compiler Warining 을 막기 위해
     * Dummy 로 Retrun 코드를 넣어준다 */
    return 0;
}


/******************************************************************************
 * Name : cmnOpenFileForLogging
 *
 * Description
 *     로깅을 수행하기 위하여 파일을 열고 해당 FD 를 얻어낸다.
 *     해당 FD 는 Thread function 의 인자로 넘겨야 하므로 Return 값을 받는다.
 *
 * Argument
 *      aLogHandle  : Shared memory 의 로깅 정보 주소
 *      aFD         : 리턴된 FD ( File Descripto )
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/

int cmnOpenFileForLogging ( cmnLogHandle* aLogHandle, int* aFD )
{
    int     sFD;

    sFD = open ( aLogHandle->mLogFileName, O_CREAT | O_APPEND, _cmn_file_mode ) ;

    _IF_RAISE ( sFD < 2 , CAN_NOT_OPEN_FILE ) ;

    *aFD = sFD;

    return RC_SUCCESS ;

    _EXCEPTION( CAN_NOT_OPEN_FILE )
    {
        return -1;
    }

    _EXCEPTION_END;

    return -99;
}



/******************************************************************************
 * Name : cmnCreateLogThread
 *
 * Description
 *     로깅을 수행하기 위하여 Synchor Thread 를 생성한다.
 *     Synchor Thread 에서 내가 현재 내려써야할 것이 있는지 없는지에 대해서
 *     판단하기 위하여 condition value를 사용하므로 이를 세팅해야한다.
 *
 *
 * Argument
 *      aLogHandle  : Heap 에 생성한 LogHandle Address
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
_VOID cmnCreateLogThread ( cmnLogHandle* aLogHandle )
{
    _TRY
    {
        _CALL( pthread_mutex_init ( &aLogHandle->mCondMutex , NULL ) );
        _CALL( pthread_cond_init ( &aLogHandle->mCond , NULL ) );

        _CALL( pthread_create ( &aLogHandle->mSynchorThread,
                              NULL ,
                              cmnSyncLogFile,
                              aLogHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/******************************************************************************
 * Name : cmnCloseLog
 *
 * Description
 *     로그 객체를 삭제한다. 다음과 같은 기준으로 처리
 *
 *     1. cmnLogHandle 에 isStop 을 세팅
 *     2. pthread_join 으로 기다림.
 *     3. 모두 종료 되었다면,  Memory 를 해제해준다.
 *
 * Argument
 *      aLogHandle  : Heap 에 생성한 LogHandle Address
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnCloseLog( cmnLogHandle** aLogHandle )
{
    int             sRC ;

    _IF_RAISE ( (*aLogHandle) == NULL, INVALID_HANDLE) ;

    /* cmnLogHandle 에 isStop 을 세팅한다. */
    (*aLogHandle)->mIsStop = 1;


    /* pthread_join 으로 기다린다. */
    sRC = pthread_join ( (*aLogHandle)->mSynchorThread, NULL ) ;
    _IF_RAISE ( sRC , PTHREAD_JOIN_ERROR ) ;

    free_s ( *aLogHandle ) ;


    return RC_SUCCESS ;


    _EXCEPTION( INVALID_HANDLE )
    {
        return -2;
    }
    _EXCEPTION( PTHREAD_JOIN_ERROR )
    {
        return -1;
    }
    _EXCEPTION_END ;

    return RC_FAILURE;
}

#endif /* __linux__ */
