/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *
 *  결과는 아래와 같이 나오게 되는데,
 *  아래 결과에서 시간의 단위(Unit)는 Micro Second 이고,
 *  모든 횟수에 대한 전체 평균은 54.877998829 Micro Second 이고,
 *  첫 통계구간의 값은 [00] 라인의 10 Micro Second 를 나타내고,
 *  각 통계구간의 간격은 10 Micro Second 이며,
 *  통계 구간의 갯수(Section Count)는 10 개([00] ~ [09]) 이다.
 *
 *  =========================================================
 *  [Unit : Micro Second]
 *  Total = [5487799.882888794] ,  Avg = [54.877998829]
 *  Count = [100000]
 *  =========================================================
 *   Cnt Time Interval    Percent     Count
 *  =========================================================
 *  [00] 0 <  time < 10 :  0.002   :  2
 *  [01] 10 <= time < 20 :  0.009   :  9
 *  [02] 20 <= time < 30 :  0.004   :  4
 *  [03] 30 <= time < 40 :  0.005   :  5
 *  [04] 40 <= time < 50 :  0.003   :  3
 *  [05] 50 <= time < 60 :  99.546   :  99546
 *  [06] 60 <= time < 70 :  0.065   :  65
 *  [07] 70 <= time < 80 :  0.140   :  140
 *  [08] 80 <= time < 90 :  0.132   :  132
 *  [09] 90 <= time < @ :  0.094   :  94
 *  =========================================================
 ******************************************************************************/

#include "cmnHeader.h"

#include <vector>
#include <algorithm>

/*
 * 2015.03.04 -okt-
 * #878 환경변수에 따라서, 시간통계 결과 로그 출력 대상을 정함.
 * 나중에 이와 같은 사용예가 다른 위치에서도 생기면, 변수 선언 위치를 cmnUtil.cpp 정도로 옮기자. 지금은 이곳에.
 *
 *  0 : 화면에만
 *  1 : ulog 파일에만 ( dbm trc 로그 위치 )
 *  2 : 화면과 ulog 파일에
 *  X : 파일경로로 인식
 */
#define ENV_DBM_MONLOG_NAME_TYPE        "_DBM_MONLOG_NAME_TYPE"

#define DBM_MON(a,...) \
    do { \
        if ( _cmn_monlog_name_type == 0 ) { \
            DBM_PRT( a, ##__VA_ARGS__); \
        } else if ( _cmn_monlog_name_type == 1 ) { \
            DBM_PRT2( a, ##__VA_ARGS__); \
        } else if ( _cmn_monlog_name_type == 2 ) { \
            DBM_ECHO2( a, ##__VA_ARGS__); \
        } else { \
            fprintf( _cmn_monlog, a, ##__VA_ARGS__); fflush(_cmn_monlog); \
        } \
    } while(0)

FILE*   _cmn_monlog = NULL;
int     _cmn_monlog_name_type = -1;

pthread_mutex_t __gTimerStatMutex = PTHREAD_MUTEX_INITIALIZER;

/******************************************************************************
 * Name : cmnInitTimer
 *
 * Description
 *   Timer Handle 에 Timer 통계 자료구조를 위한 메모리를 할당한다.
 *
 * Argument
 *   aTimerHandle    : output : Timer 자료구조 Handle
 *   aUnit           : input  : 통계를 보여줄 단위 (Second, Milisecond, Microsecond, Nanosecond )
 *   aBegin          : input  : 첫 통계구간의 값
 *   aInterval       : input  : 각 통계구간의 간격
 *   aSecCount       : input  : 통계구간을 몇 개까지 보여줄 것인가.
 *
 ******************************************************************************/
_VOID cmnInitTimer ( PHTIMER* aTimerHandle , int aUnit , int aBegin , int aInterval , int aSecCount )
{
    cmnTimerStat*   sTimer;

    _TRY
    {
        _IF_THROW( aSecCount < MIN_SECTION_COUNT || aSecCount > MAX_SECTION_COUNT, -1 ); //INVALID_SEC_COUNT );

        /*
         * 2015.03.04 -okt-
         * #878 환경변수에 따라서, 시간통계 결과 로그 출력 대상을 정함.
         */
        if ( unlikely( _cmn_monlog_name_type == -1 ) )
        {
            char* pChar = getenv( ENV_DBM_MONLOG_NAME_TYPE );
            if ( pChar == NULL )
            {
                _cmn_monlog_name_type = 0;
            }
            else
            {
                if ( pChar[0] == '0' )
                {
                    _cmn_monlog_name_type = 0;
                }
                else if ( pChar[0] == '1' )
                {
                    _cmn_monlog_name_type = 1;
                }
                else if ( pChar[0] == '2' )
                {
                    _cmn_monlog_name_type = 2;
                }
                else
                {
                    _cmn_monlog_name_type = 9;

                    _cmn_monlog = fopen( pChar, "a+" );
                    _TEST_THROW ( _cmn_monlog != NULL, -1 );
                }
            }
        }

        sTimer = (cmnTimerStat*)malloc_s(sizeof(cmnTimerStat) );
        _IF_THROW( sTimer == NULL, -2 ); //MALLOC_FAIL );

        memset_s( sTimer, 0x00, sizeof(cmnTimerStat) );

        sTimer->mTime = (char*)malloc_s( aSecCount * sizeof(int) );
        _IF_THROW( sTimer->mTime == NULL, -2 ); //MALLOC_FAIL );

        memset_s( sTimer->mTime, 0x00, aSecCount * sizeof(int) );

        sTimer->mSum      = 0;
        sTimer->mUnitType = aUnit;
        sTimer->mBegin    = aBegin;
        sTimer->mInterval = aInterval;
        sTimer->mSectionCount  = aSecCount;

        sTimer->mElapsedContainer = new std::vector <double> () ;

        sTimer->mSumCnt   = 0;              // 테스트한 쓰레드 수를 의미하고 초기값 0은 쓰레드 방식 사용 아님을 의미
        sTimer->mTestStartTimer.tv_sec = 0;
        sTimer->mTestStartTimer.tv_nsec = 0;
        sTimer->mTestEndTimer.tv_sec = 0;
        sTimer->mTestEndTimer.tv_nsec = 0;

        *aTimerHandle = ( PHTIMER )sTimer;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* cmnInitTimer */


/******************************************************************************
 * Name : cmnStartTimer
 *
 * Description
 *   시간을 재기 시작하는 시점에 call 한다.
 *
 * Argument
 *   aTimerHandle    : input : Timer 자료구조 Handle
 *
 ******************************************************************************/
_VOID cmnStartTimer( PHTIMER aTimerHandle )
{
    cmnTimerStat*   sTimer;

    _TRY
    {
        /* 2015.03.27 -shw- dbmSelectRowGT Start case handle null와서 죽어서 막음 */
        //_DASSERT( aTimerHandle != NULL );
        _IF_THROW( aTimerHandle == NULL, -1 ); //INVALID_TIMER );

        sTimer = (cmnTimerStat*)aTimerHandle;

        _CALL( clock_gettime_s( CLOCK_REALTIME, &sTimer->mStartTimer ) );

        if ( sTimer->mSum == 0 )
        {
            sTimer->mTestStartTimer = sTimer->mStartTimer;
        }
    }
    _CATCH
    {
        _CATCH_DBG;
    }
    _FINALLY
    _END
}


/*
 * 이미 측정한 시작 시간값을 저장해둔다.
 */
_VOID cmnStartTimer2 ( PHTIMER aTimerHandle , struct timespec* aStartTime )
{
    cmnTimerStat*   sTimer;

    _TRY
    {
        /* 2015.03.27 -shw- dbmSelectRowGT Start case handle null와서 죽어서 막음 */
        //_DASSERT( aTimerHandle != NULL );
        _IF_THROW( aTimerHandle == NULL, -1 ); //INVALID_TIMER );

        sTimer = (cmnTimerStat*)aTimerHandle;

        sTimer->mStartTimer = *aStartTime;
        if ( sTimer->mSum == 0 )
        {
            sTimer->mTestStartTimer = sTimer->mStartTimer;
        }
    }
    _CATCH
    _FINALLY
    _END
}


/******************************************************************************
 * Name : cmnEndTimer
 *
 * Description
 *   시간 측정의 끝부분에서 call 한다.
 *   start_timer 에서 측정했던 시간과의 차이를 통해 간격을 구한다.
 *
 * Argument
 *   aTimerHandle    : input : Timer 자료구조 Handle
 *
 ******************************************************************************/
_VOID cmnEndTimer( PHTIMER aTimerHandle )
{
    std::vector<double>* sQueue;
    cmnTimerStat*   sTimer;
    int             sMultiplyVal;
    int*            sTimeCount;
    double          sTemp;
    int             sRC;
    int             i;

    _TRY
    {
        /* 2015.03.27 -shw- dbmSelectRowGT Start case handle null와서 죽어서 막음 */
        //_DASSERT( aTimerHandle != NULL );
        _IF_THROW( aTimerHandle == NULL, -1 ); //INVALID_TIMER );
        _IF_THROW( ( (cmnTimerStat*)aTimerHandle)->mTime == NULL, -1 ); //INVALID_TIMER );

        sTimer = (cmnTimerStat*)aTimerHandle;
        sQueue = (std::vector<double>*) sTimer->mElapsedContainer;

        sRC = clock_gettime_s( CLOCK_REALTIME, &sTimer->mEndTimer );
        _IF_THROW( sRC != 0, -2 ); //CLOCK_GETTIMER_FAIL );

        // 테스트 시작, 종료 시간을 위해 약간 부하를 감수하고, 값을 복사.
        sTimer->mTestEndTimer = sTimer->mEndTimer;

        switch( sTimer->mUnitType )
        {
            case UNIT_SEC   :  sMultiplyVal = 1;          break;
            case UNIT_MILI  :  sMultiplyVal = 1000;       break;
            case UNIT_MICRO :  sMultiplyVal = 1000000;    break;
            case UNIT_NANO  :  sMultiplyVal = 1000000000; break;
            default :
                _THROW( -3 ); //INVALID_UNIT_TYPE );
                break;
        }

        /* 각 시간 단위로 값을 구한다. */
        sTemp = ( (sTimer->mEndTimer.tv_sec + sTimer->mEndTimer.tv_nsec/1000000000.0 )
               - (sTimer->mStartTimer.tv_sec + sTimer->mStartTimer.tv_nsec/1000000000.0) )
               * sMultiplyVal;

        _IF_THROW( sTemp < 0, -4 ); //INVALID_TIMER_VALUE );

        sQueue->push_back ( sTemp ) ;

        /* sTemp 값을 검사하여 맞는 section 구간의 count 값을 증가시킨다. */
        for ( i = 0; i < sTimer->mSectionCount; i++ )
        {
            sTimeCount = (int*)sTimer->mTime + i;

            if ( i == 0 )
            {

                if ( sTemp < sTimer->mBegin )
                {
                    *sTimeCount += 1;
                    break;
                }
                else
                {
                    continue;
                }
            }
            else if ( i > 0 && i < (sTimer->mSectionCount - 1) )
            {
                if ( sTemp >= (sTimer->mBegin + ( (i - 1) * sTimer->mInterval ) )
                 && sTemp < (sTimer->mBegin + (i * sTimer->mInterval )) )
                {
                    *sTimeCount += 1;
                    break;
                }
                else
                {
                    continue;
                }
            }
            else
            {
                *sTimeCount += 1;
            }
        }

        sTimer->mSum += sTemp;
    }
    _CATCH
    {
        _CATCH_DBG;
    }
    _FINALLY
    _END
} /* cmnEndTimer */

/******************************************************************************
 * Name : cmnSumTimer
 *
 * Description
 *   시간 측정의 Timer 구한 값을 sum(queue) 한다.
 *   start_timer 에서 측정했던 시간과의 차이를 통해 간격을 구한다.
 *
 * Argument
 *   aTimerHandle    : input : Timer 자료구조 Handle
 *   aTiemrHandle    : input : sum 처리 할 Timer 자료구조 Handle
 *
 ******************************************************************************/
_VOID cmnSumTimer ( PHTIMER aTimerHandle , PHTIMER aTimerSumHandle )
{

    std::vector<double>* sQueue;
    std::vector<double>* sElaspedTime;
    cmnTimerStat*   sTimer;
    cmnTimerStat*   sTimerSum;
    int             sMultiplyVal;
    int*            sTimeCount;
    double          sTemp;
    int             sRC;
    int             i;

    _TRY
    {
        _IF_THROW( aTimerHandle == NULL, -1 ); //INVALID_TIMER );
        _IF_THROW( ( (cmnTimerStat*)aTimerHandle)->mTime == NULL, -1 ); //INVALID_TIMER );
        _IF_THROW( aTimerSumHandle == NULL, -1 ); //INVALID_TIMER );
        _IF_THROW( ( (cmnTimerStat*)aTimerSumHandle)->mTime == NULL, -1 ); //INVALID_TIMER );


        sTimer = (cmnTimerStat*)aTimerHandle;
        sTimerSum = (cmnTimerStat*)aTimerSumHandle;

        sQueue = (std::vector<double>*) sTimer->mElapsedContainer;
        sElaspedTime = (std::vector<double> *) sTimerSum->mElapsedContainer;

        /* 개별 queue push 처리 */
        std::vector<double>::iterator sPos;
        for( sPos = sElaspedTime->begin(); sPos != sElaspedTime->end(); ++sPos )
        {
            sTemp = *sPos;
            sQueue->push_back ( sTemp ) ;

            /* Count 값을 증가 시킨다 */
            for( i = 0; i < sTimerSum->mSectionCount; i++ )
            {
                /* 구간변 값의 int(byte) pointer 값을 넘긴다 */
                sTimeCount = (int*)sTimer->mTime + i;

                if ( i == 0 )
                {
                    if ( sTemp < sTimer->mBegin )
                    {
                        *sTimeCount = *sTimeCount + 1;
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
                else if ( i > 0 && i < (sTimer->mSectionCount - 1) )
                {
                    if ( sTemp >= (sTimer->mBegin + ( (i - 1) * sTimer->mInterval ) )
                     && sTemp < (sTimer->mBegin + (i * sTimer->mInterval )) )
                    {
                        *sTimeCount = *sTimeCount + 1;
                        break;
                    }
                    else
                    {
                        continue;
                    }
                }
                else
                {
                    *sTimeCount = *sTimeCount + 1;
                }
            }
        } /* for */

        sTimer->mSum += sTimerSum->mSum;    // 전체 sum copy 해준다
        sTimer->mSumCnt++;                  // [가정] N개 쓰레드 테스트를 했으면, cmnSumTimer() 을 N번 호출했어야한다

        if ( sTimer->mTestStartTimer.tv_sec == 0 )
        {
            sTimer->mTestStartTimer = sTimerSum->mTestStartTimer;
            sTimer->mTestEndTimer = sTimerSum->mTestEndTimer;
        }

        // cmnTimeDiff(s,e)
        if ( cmnTimeDiff( sTimer->mTestStartTimer, sTimerSum->mTestStartTimer ) < 0 )
        {
            sTimer->mTestStartTimer = sTimerSum->mTestStartTimer;
        }
        if ( cmnTimeDiff( sTimer->mTestEndTimer, sTimerSum->mTestEndTimer ) > 0 )
        {
            sTimer->mTestEndTimer = sTimerSum->mTestEndTimer;
        }

    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* cmnSumTimer */


/******************************************************************************
 * Name : cmnWaitTimer
 *
 * Description
 *   성능 테스트를 정확히 측정 하기 위하여 입력 받은 시간만큼 계산하여 sleep
 *   처리한다.
 *
 * Argument
 *   aTimerHandle    : input : Timer 자료구조 Handle
 *
 ******************************************************************************/
_VOID cmnWaitTimer( PHTIMER aTimerHandle )
{
    cmnTimerStat* sTimer;
    static int  sEcnt = 0;
    double      sDiff;
    int         sRC;

    _TRY
    {
        _IF_THROW( aTimerHandle == NULL, -1 );
        _IF_THROW( ( (cmnTimerStat*)aTimerHandle)->mTime == NULL, -1 );

        sTimer = (cmnTimerStat*)aTimerHandle;

        /* sleep 에서는 mSum 값을 처음 체크 값으로 처리 한다 */
        if( sTimer->mSum != 0 )
        {
            sRC = clock_gettime_s( CLOCK_REALTIME, &sTimer->mEndTimer );

            switch( sTimer->mUnitType )
            {
                case UNIT_SEC :
                    sDiff = ( (sTimer->mEndTimer.tv_sec + sTimer->mEndTimer.tv_nsec/1000000000.0 )
                        - (sTimer->mStartTimer.tv_sec + sTimer->mStartTimer.tv_nsec/1000000000.0) )
                        * 1;
                    sleep ( ( sTimer->mInterval - sDiff ) );

                    break;

                case UNIT_MILI :
                    sDiff = ( (sTimer->mEndTimer.tv_sec + sTimer->mEndTimer.tv_nsec/1000000000.0 )
                        - (sTimer->mStartTimer.tv_sec + sTimer->mStartTimer.tv_nsec/1000000000.0) )
                        * 1000;

                    cmnUSleep ( ( sTimer->mInterval -  sDiff ) * 1000 );

                    break;

                case UNIT_MICRO :

                    sDiff = ( (sTimer->mEndTimer.tv_sec + sTimer->mEndTimer.tv_nsec/1000000000.0 )
                        - (sTimer->mStartTimer.tv_sec + sTimer->mStartTimer.tv_nsec/1000000000.0) )
                        * 1000000;

                    if ( ( sTimer->mInterval - sDiff ) > 0 )
                    {
                        cmnUSleep ( ( sTimer->mInterval - sDiff ) );
                    }
                    else
                    {
                        sEcnt++;
                        if ( sEcnt < 128 )
                        {
                            DBM_WARN( "cmnWaitTimer Ignored. Caller's working time is longer than wanted interval, [%d < %.0lf] (%d)", sTimer->mInterval, sDiff, sEcnt );
                        }
                        else
                        {
                            if ( BITMOD( sEcnt, 1024 ) == 0 )
                            {
                                DBM_DBG( "cmnWaitTimer Ignored. Caller's working time is longer than wanted interval, [%d < %.0lf] (%d)", sTimer->mInterval, sDiff, sEcnt );
                            }
                        }
                    }

                    break;

                default :
                    _THROW( -3 ); //INVALID_UNIT_TYPE );
                    break;
            }

            sRC = clock_gettime_s( CLOCK_REALTIME, &sTimer->mStartTimer );
            _IF_THROW( sRC != 0, -2 ); //CLOCK_GETTIMER_FAIL );
        }
        else
        {
            sRC = clock_gettime_s( CLOCK_REALTIME, &sTimer->mStartTimer );
            _IF_THROW( sRC != 0, -2 ); //CLOCK_GETTIMER_FAIL );
            sTimer->mSum = 1;
        }

    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* cmnWaitTimer */

/******************************************************************************
 * Name : cmnElapseTimer
 *
 * Description
 *   누적된 측정 정보들을 화면에 보여준다.
 *
 * Argument
 *   aTimerHandle    : input : Timer 자료구조 Handle
 *   aIterCount      : input : 시험을 수행한 iteration count
 *                         0 : vector size만큼 수행
 *                         -1: total,avg,tps 만출력
 *
 ******************************************************************************/
_VOID cmnElapseTimer ( PHTIMER aTimerHandle , int aIterCount , const char* aTestName )
{
    char            sUnitType[128];
    int*            sTimeCount;
    cmnTimerStat*   sTimer;
    std::vector<double>* sElaspedTime;
    int             sSize;

    double          sPercentSum = 0.0;
    double          s99Percentile = 0.0;
    double          s50Percentile = 0.0;
    double          sPercentile[11] = { 0.0, };
    char            sTmp[1024];
    struct timeval  sTV;

    double          sAvg;
    double          sTPS;
    double          sTPS2;
    long long       sTimeDiff;
    int             sIdx = 0 ;
    int             sTempCount;
    int             sCheck = 0;
    int             sRC;
    int             i;

    _TRY
    {
        _IF_THROW( aTimerHandle == NULL, -1 ); //INVALID_TIMER );
        _IF_THROW( ( (cmnTimerStat*)aTimerHandle)->mTime == NULL, -1 ); //INVALID_TIMER );

        // 초기화
        for ( i = 0; i < 11; i++ )
        {
            sPercentile[i] = 0.0;
        }

        sTimer = (cmnTimerStat*)aTimerHandle;
        sElaspedTime =  (std::vector<double> *) sTimer->mElapsedContainer;
        sSize = (int)sElaspedTime->size();

        if ( sSize == 0 ) // cmnStartTimer 를 한번도 호출하지 않고, cmnElapseTimer를 호출하는 경우 대응.
            _RETURN;

        sTimeDiff = cmnTimeDiff( sTimer->mTestStartTimer, sTimer->mTestEndTimer ) ;
        if ( sTimeDiff <= 0 )
        {
            // 뭔가 잘못되었다.
            DBM_WARN( "[%s] cmnElapseTimer Fail. (%lld)", aTestName, sTimeDiff );
            _RETURN;
        }

        sRC = cmnGetUnitTypeStr( sTimer->mUnitType, sUnitType );
        _IF_THROW( sRC != 0, -2 ); //INVALID_UNIT_TYPE );

        // 2015.02.10 -shw- alterCount 0일 때는 map size count만큼으로 avg 구하도록 수정
        if ( aIterCount == 0 )
        {
            aIterCount = sSize;
            sCheck = 1;
        }
        else if ( aIterCount == -1 )
        {
            aIterCount = sSize;
            sCheck = 2;
        }

        // 퍼센타일을 구한다
        {
            /* 99 % 를 구하기 위해서 sort 수행 */
            std::sort ( sElaspedTime->begin () , sElaspedTime->end () ) ;

            /*
             * 0, 10, 20, .. , 50, .. , 90, 100 퍼센타일
             */
            for ( i = 0; i < 10; i++ )
            {
                sIdx = sSize - ( sSize * ( 100 - i * 10 ) / 100 );

                // sIdx < 0 는 불필요하지만 넣어둔다.
                if ( sIdx < 0 || sIdx >= sSize )
                {
                    sIdx = sSize - 1;
                }
                sPercentile[i] = sElaspedTime->at(sIdx);
            }
            sPercentile[10] = sElaspedTime->at(sSize - 1);

            /* 99% 의 인덱스를 가서 99% latency 를 가지고 온다 */
            sIdx = sSize - ( sSize * 0.01 ) ;
            if ( sIdx < 0 || sIdx >= sSize )
            {
                sIdx = sSize - 1;
            }
            s99Percentile = sElaspedTime->at(sIdx);

            sIdx = sSize - ( sSize * 0.50 ) ;
            if ( sIdx < 0 || sIdx >= sSize )
            {
                sIdx = sSize - 1;
            }
            s50Percentile = sElaspedTime->at(sIdx);

            /* TPS 를 구한다 */

            /*
             * 2015.03.17 -okt- 동기 테스트일때는 "건수 / 시간의 합"이 TPS가 맞지만. 비동기 테스트는 그렇게 구하면 안된다.
             *  1) Sync Mode  : sTPS = aIterCount / sTimer->mSum ;
             *  2) ASync Mode : 처리건수 / <구간시간>
             */

            //sTPS = ( 1.0 / ( sTimer->mSum / aIterCount ) ) * 1000000;
            sTPS = (double)aIterCount / sTimer->mSum ;
            sTPS2 = (double)aIterCount / ( sTimeDiff / (double) DBM_NSEC ) ;
            switch ( sTimer->mUnitType )
            {
                case UNIT_NANO:
                    sTPS = sTPS * DBM_NSEC;
                    break;
                case UNIT_MICRO:
                    sTPS = sTPS * DBM_USEC;
                    break;
                case UNIT_MILI:
                    sTPS = sTPS * DBM_MSEC;
                    break;
                case UNIT_SEC:
                    sTPS = sTPS * 1;
                    break;
            };
        }

        sAvg = (double)( sTimer->mSum / aIterCount );

        /* thread 간에 서로 얽혀서 print 하지 않도록 */
        pthread_mutex_lock( &__gTimerStatMutex );

        /* 2015.02.16 -shw- printf 처리 분리 */
        if( sCheck != 2 )
        {
            DBM_MON( "\n=========================================================\n" );
            DBM_MON( "[Test Name : %s]\n", aTestName );
            if ( sTimer->mUnitType != UNIT_MICRO )
            {
                // usec를 기본으로 하고 아닌 경우만 출력하자.
                DBM_MON( "[Unit : %s]\n", sUnitType );
            }

            DBM_MON( "    Avg = [%11.0f]\tCount = [%11d]\n", sAvg, aIterCount );
            DBM_MON( "99 %%ile = [%11.0f]\t  50%% = [%11.0f]\n", s99Percentile, s50Percentile );
            DBM_MON( "    TPS = [%11.0f]\tTPS.A = [%11.0f] \n", sTPS, sTPS2 ) ;

            DBM_MON( "=========================================================\n" );
            DBM_MON( " Cnt       Time Interval     Percent            Count\n" );
            DBM_MON( "=========================================================\n" );
        }
        else
        {
            DBM_MON( "[Test Name : %s][Total:Avg:TPS] - ", aTestName );
            DBM_MON( "[%.0f][%.0f][%.0f]\n", sTimer->mSum, sAvg, sTPS );
        }

        sTimer->mSum = 0;
        for ( i = 0; i < sTimer->mSectionCount; i++ )
        {
            sTimeCount = (int*)sTimer->mTime + i;
            sTimer->mSum += *sTimeCount;
        }


        /* 2015.02.16 -shw- printf 처리 분리 */
        if( sCheck != 2 )
        {
            for ( i = 0; i < sTimer->mSectionCount; i++ )
            {
                sTimeCount = (int*)sTimer->mTime + i;

                if ( sCheck == 1 )
                {
                    if ( *sTimeCount <= 0 )
                        continue;
                }

                sPercentSum += (double)(*sTimeCount/sTimer->mSum)*100.0;
                if ( i == 0 )
                {
                    DBM_MON( "[%02d] %6d <  time < %6d :  %5.2f %6.2f :  %9d\n",
                            0, i, sTimer->mBegin, (double)(*sTimeCount/sTimer->mSum)*100.0,
                            sPercentSum, *sTimeCount );
                }
                else if ( i == (sTimer->mSectionCount - 1) )
                {
                    DBM_MON( "[%02d] %6d <= time < %6s :  %5.2f %6.2f :  %9d\n",
                            i, sTimer->mBegin + (i - 1) * sTimer->mInterval, "@",
                            (double)(*sTimeCount/sTimer->mSum)*100.0,
                            sPercentSum ,
                            *sTimeCount );
                }
                else
                {
                    DBM_MON( "[%02d] %6d <= time < %6d :  %5.2f %6.2f :  %9d\n",
                            i, sTimer->mBegin + ( (i -1) * sTimer->mInterval ),
                            sTimer->mBegin + (i * sTimer->mInterval ),
                            (double)(*sTimeCount/sTimer->mSum)*100.0,
                            sPercentSum, *sTimeCount );
                }
            }
            DBM_MON( "=========================================================\n" );
        }

        /*
         * TODO: 2015.03.17 -okt- 한줄 SUMMARY를 출력하여, 나중에 이를 GREP만하면, 결과를 취합할 수 있게한다.
         */
        if ( 0x01 )
        {
            sIdx = 0;
            // %ile
            sIdx += sprintf( sTmp + sIdx, "P[" );
            sIdx += sprintf ( sTmp + sIdx, "N,%d,T,%.1f,T99,%.1f,TPS,%.0f,%.0f,THR,%d] ",
                              aIterCount, sAvg, s99Percentile, sTPS, sTPS2, sTimer->mSumCnt );

            // %ile
            sIdx += sprintf( sTmp + sIdx, "%%ile[" );
            for ( i = 0; i < 11; i++ )
            {
                sIdx += sprintf( sTmp + sIdx, ",%.0f", sPercentile[i] );
            }
            sIdx += sprintf( sTmp + sIdx, "] " );

            // during 'T'ime
            {
                sIdx += sprintf ( sTmp + sIdx, "T[%.0lf,", ( sTimeDiff / (double) DBM_NSEC ) * 60 ); // 초단위 수행 소요시간

                cmnTimeCpy( sTV, sTimer->mTestStartTimer );
                sIdx += sprintf( sTmp + sIdx, "%s ~ ", cmnTime2Str ( sizeof("hh:mi:ss.ssssss"), NULL, TIME_FMT_ANY, &sTV ) );

                cmnTimeCpy( sTV, sTimer->mTestEndTimer );
                sIdx += sprintf( sTmp + sIdx, "%s] ", cmnTime2Str ( sizeof("hh:mi:ss.ssssss"), NULL, TIME_FMT_ANY, &sTV ) );
            }

            if ( _cmn_monlog_name_type == 0 )
            {
                DBM_FORCE( "[MON] [%s] %s", aTestName, sTmp );
            }
            DBM_MON( "[MON] [%s] %s", aTestName, sTmp );
        }

        pthread_mutex_unlock( &__gTimerStatMutex );

        if ( 0x01 )
        {
            /*
             * 초기화 처리 : 2015.03.02 -shw
             * elapseTimer 호출한것은 마지막을 호출한 것이다. 만약 다 처리 후 initTimer
             * 호출하지 않으면 해당 sTimer 값은 계속 유지 되기 때문에 동일 쓰레드에서
             * 계속 사용 하려면 초기화를 해주는 것이 맞을것 같다.
             */
            memset_s( sTimer->mTime, 0x00, sTimer->mSectionCount * sizeof(int) );
            sElaspedTime->clear();
            sTimer->mSum = 0;
            sTimer->mSumCnt = 0; // 테스트한 쓰레드 수를 의미하고 초기값 0은 쓰레드 방식 사용 아님을 의미

            sTimer->mTestStartTimer.tv_sec = 0;
            sTimer->mTestStartTimer.tv_nsec = 0;
            sTimer->mTestEndTimer.tv_sec = 0;
            sTimer->mTestEndTimer.tv_nsec = 0;
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* cmnElapseTimer */


/******************************************************************************
 * Name : cmnStartTimer
 *
 * Description
 *   Timer Handle 에 할당된 메모리를 해제한다.
 *
 * Argument
 *   aTimerHandle    : input : Timer 자료구조 Handle
 *
 ******************************************************************************/
_VOID cmnFinalTimer( PHTIMER* aTimerHandle )
{
    cmnTimerStat*   sTimer;

    sTimer = (cmnTimerStat*)( *aTimerHandle );

    if ( sTimer != NULL )
    {
        if ( sTimer->mTime != NULL )
        {
            free_s( sTimer->mTime );
            delete (std::vector<double>*)sTimer->mElapsedContainer;
            sTimer->mElapsedContainer = NULL;
        }

        free_s( sTimer );
        *aTimerHandle = NULL;
    }

    return RC_SUCCESS;
}


_VOID cmnGetUnitTypeStr ( int aUnitType , char* aUnitTypeStr )
{
    switch( aUnitType )
    {
        case UNIT_SEC   : strcpy_s( aUnitTypeStr, "Second");       break;
        case UNIT_MILI  : strcpy_s( aUnitTypeStr, "Mili Second");  break;
        case UNIT_MICRO : strcpy_s( aUnitTypeStr, "Micro Second"); break;
        case UNIT_NANO  : strcpy_s( aUnitTypeStr, "Nano Second");  break;
        default : return -1;
    }

    return RC_SUCCESS;
}
