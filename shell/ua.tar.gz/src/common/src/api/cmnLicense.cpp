/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/
#include "cmnHeader.h"


/******************************************************************************
 * Name : cmnReadLicense
 *
 * Description
 *   지정된 경로에서 License를 읽어들임.
 *
 * Argument
 *   aFileName :  라이센스가 담긴 파일 (경로포함 )
 *   aLicense  :  읽어들인 License가 담길 Buffer Pointer
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnReadLicense ( char* aFileName,
                     char* aLicense )
{
    char             *sBuffer = NULL;
    int              i, j;
    int              sRC = -1;
    int              sFileHandle;
    long long        sFileSz = 0;
    int              sRead   = 0;
    int              sStart  = 0;
    int              sLoop   = 0;


    /******************************************
     * open file
    *******************************************/
    // 2015.01.27 -okt- group이 같은 다른 계정에서도 metaManager 가능하도록
    // O_RDWR 모드로 열면, dbm.license 파일 내용이 아니고, 접근을 못해서 다른 계정은 안된다.
    //sFileHandle = open( aFileName, O_RDWR );
    sFileHandle = open( aFileName, O_RDONLY );
    _IF_RAISE( sFileHandle < 0, FILE_OPEN_ERROR );

    /******************************************
     * get file size
    *******************************************/
    sFileSz = lseek( sFileHandle, 0L, SEEK_END );
    _IF_RAISE( sFileSz <=0, FILE_SIZE_ERROR );
    _DASSERT( sFileSz < INT_MAX );

    /******************************************
     * Malloc
    *******************************************/
    sBuffer = (char*) malloc_s(sFileSz);
    _IF_RAISE(sBuffer == NULL, MALLOC_FAIL);

    memset_s(sBuffer, 0x00, sFileSz);

    /******************************************
     * read file at once
     * move at first, and read file
    *******************************************/
    lseek ( sFileHandle, 0L, SEEK_SET );
    //sRead = read( sFileHandle, aLicense, sFileSz );
    sRead = read( sFileHandle, sBuffer, sFileSz );
    _IF_RAISE( sRead == 0, FILE_READ_ERROR );

    close( sFileHandle );

    for ( i=0;i<( int)strlen_s( sBuffer); i++ )
    {
        if ( sBuffer[i] == '#')     // 주석은 무시하기 위해
        {
            for (j=i; j<(int)strlen_s(sBuffer); j++)
            {
                if (sBuffer[j] == '\n') break;
            }
            i = j;
            sStart = j + 1;
            continue;
        }

        if ( sBuffer[i] == '\n' )
        {
            memcpy_s ( aLicense + sLoop, sBuffer + sStart, ( i - sStart ) );
#ifdef _DEBUG
            aLicense[strlen_s ( aLicense )] = 0x00;
            DBM_TRC( "LicenseKey=[%s] (start=%d, i=%d)\n", aLicense + sLoop, sStart, i );
#endif
            sLoop += i - sStart;
            sStart = i + 1;
            //break;
        }
    }
    aLicense[strlen_s(aLicense)] = 0x00;

    free_s( sBuffer );
    return RC_SUCCESS;

    _EXCEPTION (MALLOC_FAIL)
    {
        sRC = ERR_SYSCALL_MALLOC;
    }

    _EXCEPTION( FILE_OPEN_ERROR )
    {
        sRC = ERR_SYSCALL_OPEN;
    }

    _EXCEPTION( FILE_SIZE_ERROR )
    {
        sRC = ERR_SYSCALL_LSEEK;
    }

    _EXCEPTION( FILE_READ_ERROR )
    {
        sRC = ERR_SYSCALL_READ;
    }

    _EXCEPTION_END;
    if (sBuffer != NULL)
    {
        free(sBuffer);
    }
    return sRC;
}



/******************************************************************************
 * Name : cmnCheckLicense2
 *
 * Description
 *   License 를 기간만 가지고 체크한다.
 *
 * Argument
 *   aLicense : License를 입력한다.
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnCheckLicense2( char* aLicense )
{
    char            sKey[9] = {'O', 'N', 'M', 'I', 'R', 'S', 'O', 'F', 'T'};
    int             i, j, k;
    int             sLen;
    int             sSum1;
    int             sSum2;
    char            sDiff[5];
    char            sHost[100];
    char            sBuffer[100];
    char            sDate[20];
    struct tm*      ptm;
    time_t          cur;
    int             sStart = 0;
    int             sEnd   = strlen_s( aLicense );
    int             sCheck = 0;

    while ( sStart < sEnd )
    {
        sprintf ( sHost, "%08x", (unsigned int)0 );

        cur = time(NULL );
        ptm = localtime( &cur );

        memset_s( sBuffer, 0x00, sizeof(sBuffer) );
        sprintf ( sDate, "%04d%02d%02d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday );
        k = 0;
        for ( i=sStart; i<(sStart+32); i=i+4 )
        {
            memset_s( sDiff, 0x00, sizeof(sDiff) );
            memcpy_s( sDiff, aLicense + i, 4 );
            j = atoi(sDiff) ^ sKey[k/4];
            sBuffer[k/4] = j;
            k = k + 4;
        }
        k = 0;

        for ( i=0; i<(int)strlen_s( sBuffer); i++ )
        {
            if ( sBuffer[i] < '0' || sBuffer[i] > '9' )
            {
                sStart = sStart + 64;
                continue;
            }
        }

        /**********************************************
         * 기간 체크가 정상이어야 한다.
        **********************************************/
        if ( memcmp( sDate, sBuffer, 8) > 0 )
        {
            sStart = sStart + 64;
            continue;
        }

        /**********************************************
         * 복호화 후에 ONMIR_TERM이면 기간체크하지 않음.
        **********************************************/
        if ( memcmp( aLicense+sStart+32, "ONMIR_TERM", 10) == 0 )
        {
            return RC_SUCCESS;
        }

        memset_s( sBuffer, 0x00, sizeof(sBuffer) );

        sLen  = strlen_s( sHost );
        sSum1 = 0;
        sSum2 = 0;
        k     = 0;
        for ( i=0;i<sLen; i++ )
        {
            sSum1 = sSum1 + sHost[i];
            sSum2 = sSum2 + (sHost[i] ^ ( int)sKey[k] );
            if (k++ >= 9) k = 0;
        }

        sprintf( sBuffer, "%d-%s-%d", sSum2, sHost, sSum1 );
        sLen = strlen_s( sBuffer );
        for ( i=0;i<sLen; i++ )
        {
            for (j=0; j<9; j++ )
            {
                sBuffer[i] = sBuffer[i] ^ sKey[j];
            }
        }

        j = ( sStart + 32 );
        for ( i=0;i<sLen; i=i+1 )
        {
            sprintf( sDiff, "%2x", sBuffer[i] );
            if ( memcmp( ( aLicense+j), sDiff, 2) != 0 )
            {
                //DBM_INFO ("Invalid License ( Pos=%d, Len=%d)", sStart, sEnd );
                sCheck = 1;
                break;
            }
            j = j + 2;
        }

        if ( sCheck == 1 )
        {
            sCheck = 0;
            sStart = sStart + 64;
            continue;
        }

        return RC_SUCCESS;
    }

    return RC_FAILURE;
}

/******************************************************************************
 * Name : cmnCheckLicense
 *
 * Description
 *   License가 올바른지 체크해본다.
 *
 * Argument
 *   aLicense : License를 입력한다.
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnCheckLicense( char* aLicense )
{
    char            sKey[9] = {'O', 'N', 'M', 'I', 'R', 'S', 'O', 'F', 'T'};
    int             i, j, k;
    int             sLen;
    int             sSum1;
    int             sSum2;
    char            sDiff[5];
    char            sHost[100];
    char            sBuffer[100];
    char            sDate[20];
    struct tm*      ptm;
    time_t          cur;
    int             sStart = 0;
    int             sEnd   = strlen_s( aLicense );
    int             sCheck = 0;

    while ( sStart < sEnd )
    {
        sprintf ( sHost, "%08x", (unsigned int)gethostid_s() );

        cur = time(NULL );
        ptm = localtime( &cur );

        memset_s( sBuffer, 0x00, sizeof(sBuffer) );
        sprintf ( sDate, "%04d%02d%02d", ptm->tm_year+1900, ptm->tm_mon+1, ptm->tm_mday );
        k = 0;
        for ( i=sStart; i<(sStart+32); i=i+4 )
        {
            memset_s( sDiff, 0x00, sizeof(sDiff) );
            memcpy_s( sDiff, aLicense + i, 4 );
            j = atoi(sDiff) ^ sKey[k/4];
            sBuffer[k/4] = j;
            k = k + 4;
        }
        k = 0;

        for ( i=0; i<(int)strlen_s( sBuffer); i++ )
        {
            if ( sBuffer[i] < '0' || sBuffer[i] > '9' )
            {
                sStart = sStart + 64;
                continue;
            }
        }

        /**********************************************
         * 기간 체크가 정상이어야 한다.
        **********************************************/
        if ( memcmp( sDate, sBuffer, 8) > 0 )
        {
            sStart = sStart + 64;
            continue;
        }

        /**********************************************
         * 복호화 후에 ONMIR_TERM이면 기간체크하지 않음.
        **********************************************/
        if ( memcmp( aLicense+sStart+32, "ONMIR_TERM", 10) == 0 )
        {
            return RC_SUCCESS;
        }

        memset_s( sBuffer, 0x00, sizeof(sBuffer) );

        sLen  = strlen_s( sHost );
        sSum1 = 0;
        sSum2 = 0;
        k     = 0;
        for ( i=0;i<sLen; i++ )
        {
            sSum1 = sSum1 + sHost[i];
            sSum2 = sSum2 + (sHost[i] ^ ( int)sKey[k] );
            if (k++ >= 9) k = 0;
        }

        sprintf( sBuffer, "%d-%s-%d", sSum2, sHost, sSum1 );
        sLen = strlen_s( sBuffer );
        for ( i=0;i<sLen; i++ )
        {
            for (j=0; j<9; j++ )
            {
                sBuffer[i] = sBuffer[i] ^ sKey[j];
            }
        }

        j = ( sStart + 32 );
        for ( i=0;i<sLen; i=i+1 )
        {
            sprintf( sDiff, "%2x", sBuffer[i] );
            if ( memcmp( ( aLicense+j), sDiff, 2) != 0 )
            {
                //DBM_INFO ("Invalid License ( Pos=%d, Len=%d)", sStart, sEnd );
                sCheck = 1;
                break;
            }
            j = j + 2;
        }

        if ( sCheck == 1 )
        {
            sCheck = 0;
            sStart = sStart + 64;
            continue;
        }

        return RC_SUCCESS;
    }

    return RC_FAILURE;
}
