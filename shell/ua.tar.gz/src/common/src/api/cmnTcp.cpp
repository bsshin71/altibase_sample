/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   common tcp socket library
 ******************************************************************************/
#include "cmnHeader.h"


/******************************************************************************
 * Name : setNonBlockSock
 *
 * Description
 *   Tcp Socket 의 Non Blocking 세팅을 한다.
 *
 * Argument
 *   aSockFd    : output : 생성한 Socket FD
 *   aNonBlockF : input  : Socket 을 Non Blocking 모드로 변경할 것인지 여부
 *                         default : -1 (blocking )
 ******************************************************************************/
_VOID setNonBlockSock(int *aSock, int aNonBlockF)
{
    int     sFlag;
    int     sSock = *aSock;
    u_long opt  = 0;

    _TRY
	{
#if defined(__MINGW32__) || defined(__MINGW64__)
        if ( aNonBlockF == 1 )
        {
            opt = 1;
        }
        else
        {
            opt = 0;
    	}
        sFlag = ioctlsocket( sSock, FIONBIO, &opt );
        if(sFlag != NO_ERROR)
        {
        	_THROW(1);
        }
#else
        sFlag = fcntl( sSock, F_GETFL, 0 );
        if ( aNonBlockF == 1 )
        {
            _CALL( fcntl ( sSock, F_SETFL, sFlag | O_NDELAY ) );
        }
        else
        {
            _CALL( fcntl(sSock, F_SETFL, sFlag & ~O_NDELAY ) );
    	}
#endif
   }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/******************************************************************************
 * Name : cmnTcpServerOpen
 *
 * Description
 *   Tcp Server Listen Socket 을 준비한다.
 *
 * Argument
 *   aSockFd    : output : 생성한 Socket FD
 *   aPortNo    : input  : Listen Port 번호
 *   aNonBlockF : input  : Socket 을 Non Blocking 모드로 변경할 것인지 여부
 *                         default : -1 (blocking )
 *   aBufSize   : input  : Socket Buffer 크기 지정
 *                         default : val <= 0
 *
 ******************************************************************************/
_VOID cmnTcpServerOpen ( int* aSockFd , int aPortNo , int aNonBlockF , int aBufSize )
{
    struct sockaddr_in sInSock;
    int     sSock = -1;
    int     sOptVal;
    int     sFlag;
    int     sRC;

    _TRY
    {
        memset_s( (char*)&sInSock, 0x00, sizeof(struct sockaddr_in) );

        /*-------------------------------------------------------------
         * socket 생성
         -------------------------------------------------------------*/
        sSock = socket( PF_INET, SOCK_STREAM, IPPROTO_TCP );
        if ( sSock < 0 )
            _THROW ( ERR_SYSCALL_SOCKET );

        sInSock.sin_family = AF_INET;
        sInSock.sin_addr.s_addr = htonl( INADDR_ANY );
        sInSock.sin_port = htons( aPortNo );

        /*
         * TODO: 2014.11.17 -okt- SO_REUSEADDR 설정 위치를 bind 이후에 하는 것이 맞을 것 같음.
         *       EADDRINUSE ( 98 ) 발생하여, 찾다가 발견했는데. 수정이후에도. 빈도 차이지 발생은 함.
         */
//        /*-------------------------------------------------------------
//         * listen port binding
//         -------------------------------------------------------------*/
//        sRC = bind( sSock,(struct sockaddr*)&sInSock, sizeof(sInSock) );
//        if ( sRC < 0 )
//        {
//            // 2014.10.20 -okt- EADDRINUSE 오류 경우가 있다. 어쩔까?
//            DBM_ERR( "tcp server socket bind fail. rc=%d (err=%d,tid=%d)", sRC, errno, gettid_s() );
//            _THROW ( ERR_SYSCALL_BIND );
//        }

        /*-------------------------------------------------------------
         * TIME_WAIT 상태의 socket 주소와 Port 를 재사용할 수 있도록 함.
         -------------------------------------------------------------*/
        sOptVal = 1;
        _CALL( setsockopt ( sSock, SOL_SOCKET, SO_REUSEADDR, (char*) &sOptVal, sizeof(sOptVal) ) );

        /*-------------------------------------------------------------
         * nagle 알고리즘 적용 여부.
         *   1(TRUE)  : nagle 을 적용하지 않아서 작게 작게 끊어보낸다. (for low latency )
         *   2(FALSE) : nagle 을 적용하여 한번에 많이 보낸다.
         -------------------------------------------------------------*/
        sOptVal = 1;
        _CALL( setsockopt ( sSock, IPPROTO_TCP, TCP_NODELAY, (char*) &sOptVal, sizeof(sOptVal) ) );

        /*-------------------------------------------------------------
         * TCP Layer 의 socket buffer 를 사용자가 지정한 값으로 설정
         -------------------------------------------------------------*/
        if ( aBufSize > 0 )
        {
            sOptVal = aBufSize;
        }
        else
        {
            sOptVal = CMN_TCP_BUFFER_SIZE;
        }
        _CALL( setsockopt ( sSock, SOL_SOCKET, SO_SNDBUF, (char*) &sOptVal, sizeof( sOptVal ) ) );
        _CALL( setsockopt ( sSock, SOL_SOCKET, SO_RCVBUF, (char*) &sOptVal, sizeof( sOptVal ) ) );

        /*-------------------------------------------------------------
         * listen port binding
         -------------------------------------------------------------*/
        sRC = bind( sSock,(struct sockaddr*)&sInSock, sizeof(sInSock) );
        if ( sRC < 0 )
        {
            // 2014.10.20 -okt- EADDRINUSE 오류 경우가 있다. 어쩔까?
            DBM_ERR( "tcp server socket bind fail. rc=%d (err=%d,tid=%d)", sRC, errno, gettid_s() );
            _THROW ( ERR_SYSCALL_BIND );
        }

        /*-------------------------------------------------------------
         * Socket 을 non blocking mode 로 변경
         -------------------------------------------------------------*/
        _CALL( setNonBlockSock(&sSock, aNonBlockF) );

        _CALL( listen( sSock, 5 ) );
        *aSockFd = sSock;
    }
    _CATCH
    {
        // 여기 오면 오류이다. 그럼 자원 정리
        close_s ( sSock );
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/******************************************************************************
 * Name : cmnTcpConnect
 *
 * Description
 *   Tcp client socket 을 생성하고 server 로 connect 를 시도한다.
 *
 * Argument
 *   aSockFd    : output : 생성한 Socket FD
 *   aHost      : input  : connect 대상 server host info
 *   aPortNo    : input  : Listen Port 번호
 *   aNonBlockF : input  : Socket 을 Non Blocking 모드로 변경할 것인지 여부
 *                         default : -1 (blocking )
 *   aBufSize   : input  : Socket Buffer 크기 지정
 *                         default : val <= 0
 *   aTimeout   : input  : connection timeout (second)
 *
 ******************************************************************************/
_VOID cmnTcpConnect ( int* aSockFd , char* aHost , int aPortNo , int aNonBlockF , int aTimeout , int aBufSize )
{
    struct sockaddr_in sServAddr;
    int     sSock;
    int     sOptVal;
    int     sFlag;
    int     sRC;
    int     sCount = 0;

    _TRY
    {
        memset_s( (char*)&sServAddr, 0x00, sizeof(struct sockaddr_in) );

        /*-------------------------------------------------------------
         * socket 생성
         -------------------------------------------------------------*/
        sSock = socket( PF_INET, SOCK_STREAM, IPPROTO_TCP );
        if ( sSock < 0)
            _THROW ( ERR_SYSCALL_SOCKET );

        sServAddr.sin_family = AF_INET;
        sServAddr.sin_addr.s_addr = inet_addr( aHost );
        sServAddr.sin_port = htons( aPortNo );

        /*-------------------------------------------------------------
         * nagle 알고리즘 적용 여부.
         *   1(TRUE)  : nagle 을 적용하지 않아서 작게 작게 끊어보낸다. (for low latency )
         *   2(FALSE) : nagle 을 적용하여 한번에 많이 보낸다.
         -------------------------------------------------------------*/
        sOptVal = 1;
        _CALL( setsockopt ( sSock, IPPROTO_TCP, TCP_NODELAY, (char*) &sOptVal, sizeof( sOptVal ) ) );

        /*-------------------------------------------------------------
         * TCP Layer 의 socket buffer 를 사용자가 지정한 값으로 설정
         -------------------------------------------------------------*/
        if ( aBufSize > 0 )
        {
            sOptVal = aBufSize;
        }
        else
        {
            sOptVal = CMN_TCP_BUFFER_SIZE;
        }
        _CALL( setsockopt ( sSock, SOL_SOCKET, SO_SNDBUF, (char*) &sOptVal, sizeof( sOptVal ) ) );
        _CALL( setsockopt ( sSock, SOL_SOCKET, SO_RCVBUF, (char*) &sOptVal, sizeof( sOptVal ) ) );

        /*-------------------------------------------------------------
         * Socket 을 non blocking mode 로 변경
         -------------------------------------------------------------*/
        _CALL( setNonBlockSock(&sSock, aNonBlockF) );

        /*-------------------------------------------------------------
         * connect to server
         -------------------------------------------------------------*/
retry:
        sRC = connect( sSock, (struct sockaddr *)&sServAddr, sizeof(struct sockaddr_in) );
        if ( sRC < 0 )
        {
            if( aNonBlockF == 0 )
            {
                /*-------------------------------------------------------------
                 * blocking 모드일 때는 aTimeout 횟수만큼 재시도를 한다.
                 * aTimeout 이 0 일 때는 무한대로 connect 시도.
                 -------------------------------------------------------------*/
                if( aTimeout == 0 )
                {
                    sleep(1);
                    goto retry;
                }

                if( sCount >= aTimeout )
                {
                    _THROW ( ERR_SYSCALL_CONNECT );
                }

                sleep(1);
                sCount++;
                goto retry;
            }
            else
            {
                /*-------------------------------------------------------------
                 * non-blocking 모드일 때는 aTimeout 에 상관없이 바로 실패 리턴.
                 -------------------------------------------------------------*/
                _THROW ( ERR_SYSCALL_CONNECT );
            }
        }

        *aSockFd = sSock;
    }
    _CATCH
    {
        close_s ( sSock );
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/******************************************************************************
 * Name : cmnTcpAccept
 *
 * Description
 *   Tcp client 로부터의 connect 요청을 accept 한 후 신규 data socket 리턴.
 *
 * Argument
 *   aListenSockFd : input  : cmnTcpServerOpen 에서 생성한 Listen Socket FD
 *   aNewSockFd    : output : accept 를 통해 신규로 생성된 data socket FD
 *   aNonBlockF    : input  : Socket 을 Non Blocking 모드로 변경할 것인지 여부
 *                         default : -1 (blocking )
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( < 0 )
 *
 ******************************************************************************/
_VOID cmnTcpAccept( int   aListenSockFd,
                    int*  aNewSockFd,
                    int   aNonBlockF )
{
    struct sockaddr_in sCliAddr;
    int                sAddrLen;
    int                sNewSock;
    int                sFlag;
    int                sRet;

    _TRY
    {
        memset_s( (char*)&sCliAddr, 0x00, sizeof(struct sockaddr_in) );

        sAddrLen = sizeof(struct sockaddr_in );

        sNewSock = accept( aListenSockFd, (struct sockaddr *)&sCliAddr, (socklen_t*)&sAddrLen );
        if ( sNewSock < 0 )
            _THROW ( ERR_SYSCALL_ACCEPT );

        /*-------------------------------------------------------------
         * New Socket 을 non blocking mode 로 변경
         -------------------------------------------------------------*/
        _CALL( setNonBlockSock(&sNewSock, aNonBlockF) );

        *aNewSockFd = sNewSock;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/******************************************************************************
 * Name : cmnTcpAcceptGetCliIP
 *
 * Description
 *   Tcp client 로부터의 connect 요청을 accept 한 후 신규 data socket 리턴.
 *
 * Argument
 *   aListenSockFd : input  : cmnTcpServerOpen 에서 생성한 Listen Socket FD
 *   aNewSockFd    : output : accept 를 통해 신규로 생성된 data socket FD
 *   aNonBlockF    : input  : Socket 을 Non Blocking 모드로 변경할 것인지 여부
 *                         default : 0 (blocking )
 *   aCliIP        : output : 접속을 해온 Client 의 IP 주소
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( < 0 )
 *
 ******************************************************************************/
_VOID cmnTcpAcceptGetCliIP( int   aListenSockFd,
                            int*  aNewSockFd,
                            int   aNonBlockF,
                            char* aCliIP )
{
    struct sockaddr_in sCliAddr;
    int                sAddrLen;
    int                sNewSock;
    int                sFlag;
    int                sRet;

    _TRY
    {
        memset_s( (char*)&sCliAddr, 0x00, sizeof(struct sockaddr_in) );

        sAddrLen = sizeof(struct sockaddr_in );

        sNewSock = accept( aListenSockFd, (struct sockaddr *)&sCliAddr, (socklen_t*)&sAddrLen );
        if ( sNewSock < 0 )
            _THROW ( ERR_SYSCALL_ACCEPT );

        strcpy(aCliIP, inet_ntoa(sCliAddr.sin_addr));

        /*-------------------------------------------------------------
         * New Socket 을 non blocking mode 로 변경
         -------------------------------------------------------------*/
        _CALL( setNonBlockSock(&sNewSock, aNonBlockF) );

        *aNewSockFd = sNewSock;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/******************************************************************************
 * Name : cmnTcpSend
 *
 * Description
 *   Tcp Socket 을 통해 Data 를 전송.
 *   Data 를 전송할 때는 반드시 aData 맨앞의 4 byte 는 전송하는 길이를 저장한다.
 *   맨앞 4 byte 에 size 를 저장하는 것은 사용자의 몫이다.
 *
 * Argument
 *   aSockFd    : input  : Socket FD
 *   aData      : input  : 전송할 data buffer 포인터
 *   aSentSize  : output : 실제로 전송성공한 data 크기
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( < 0 )
 *
 ******************************************************************************/
_VOID cmnTcpSend( int     aSockFd,
                  char*   aData,
                  int     aSize,
                  int*    aSentSize )
{
    int     sSendLen = 0;
    int     sSize = aSize;
    char*   sSendPtr = NULL;
    int     sRemain = 0;

    _TRY
    {
/*
 *  궂이 보낼때는 4byte를 짤라보내는 건 할 이유가 없다.
 *  말하자믄 aData가 이미 4byte를 length로 쓰기로 우리가 약속한 상태
 *  이게 아마 범용성때문에 이렇게 짠모양이다. 
        sRemain  = sizeof(int);
        sSendPtr = (char*)&sSize;
        do
        {
            sSendLen = send( aSockFd, sSendPtr, sizeof(int), 0 );
            if ( sSendLen > 0 )
            {
                sRemain -= sSendLen;
                sSendPtr += sSendLen;
            }
            else if ( sSendLen == 0 )
            {
                continue;
            }
            else
            {
                if ( ( errno == EWOULDBLOCK )
#if ( EAGAIN != EWOULDBLOCK )
                        || ( errno == EAGAIN )
#endif
                        || ( errno == EINTR ) )
                {
                    continue;
                }
                else
                {
                    _THROW ( ERR_SYSCALL_SEND );
                }
            }
        } while( sRemain > 0 );
*/

        /* size 를 나타태는 4 byte 먼저 전송 */
        sRemain  = aSize;
        sSendPtr = aData;
        do
        {
            sSendLen = send( aSockFd, sSendPtr, sRemain, 0 );
            if ( sSendLen > 0 )
            {
                sRemain  -= sSendLen;
                sSendPtr += sSendLen;
            }
            else if ( sSendLen == 0 )
            {
                continue;
            }
            else
            {
                if ( ( errno == EWOULDBLOCK )
#if ( EAGAIN != EWOULDBLOCK )
                        || ( errno == EAGAIN )
#endif
                        || ( errno == EINTR ) )
                {
                    continue;
                }
                else
                {
                    _THROW ( ERR_SYSCALL_SEND );
                }
            }
        } while( sRemain > 0 );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        * aSentSize = aSize - sRemain;
    }
    _END
}


/******************************************************************************
 * Name : cmnTcpRecv
 *
 * Description
 *   Tcp Socket 을 통해 Data 를 수신.
 *   맨앞 4 byte 는 무조건 길이라고 생각하고 수신한다.
 *   맨앞 4 byte 는 library 단에서만 송수신 시 사용하는 것으
 *   aRecvedSize 에 포함되지 않는다.
 *
 * Argument
 *   aSockFd    : input  : Socket FD
 *   aData      : input  : 수신한 data를 저장할 buffer 포인터
 *   aTimeout   : input  : data 를 읽을 때까지 기다려주는 시간
 *   aRecvedSize: output : 실제로 수신 성공한 data 크기
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( < 0 )
 *
 ******************************************************************************/
_VOID cmnTcpRecv( int     aSockFd,
                  char*   aData,
                  int     aTimeout,
                  int*    aRecvedSize )
{
    int            sInd  = 0;
    int            sLen  = 0;
    int            sRecv = 0;
    int            sRet;
    int            sRC;
    char           sLenBuf[8];
    fd_set         sRset;
    struct timeval tv;

    _TRY
    {
        memset_s( sLenBuf, 0x00, sizeof(sLenBuf) );

        /*-------------------------------------------------------------
         * 어떤 형태로 메시지를 보내건 맨 앞의 4 byte 는 무조건
         * Length 이어야 한다.
         -------------------------------------------------------------*/
        while ( sInd < (int)(sizeof(int)) )
        {
            FD_ZERO( &sRset );
            FD_SET( aSockFd, &sRset );

            tv.tv_sec = aTimeout / 1000000;
            tv.tv_usec = aTimeout % 1000000;

            // 2014.12.14. -okt- [BUGBUG] 코드에서 select 사용금지, fd개수가 아니고 번호만 1024 되어도 죽음. FD_SET에서 스택깨고 죽어서 헤매었음.
            if ( aTimeout != 0 )
            {
                sRet = select( aSockFd + 1, &sRset, NULL, NULL, &tv );
                if ( sRet == 0 )
                    _THROW ( ERR_CMN_TIMEOUT );
            }
            else
            {
                sRet = select( aSockFd + 1, &sRset, NULL, NULL, NULL );
            }

            if ( sRet != EINTR && sRet < 0 )
                _THROW ( ERR_SYSCALL_SELECT );

            /*-------------------------------------------------------------
             * Step1: 4byte lenth Read
             -------------------------------------------------------------*/
            sRecv = recv( aSockFd, (sLenBuf + sInd), (sizeof(int) - sInd), 0 );
            if ( sRecv == 0 )
            {
                // 2014.10.22 -okt- recv() 함수가 0 으로 리턴된 것은. PEERDOWN을 의미
                //_THROW ( ERR_SYSCALL_RECV );
                _THROW ( ERR_DBM_SOCK_PEERDOWN );
            }

            if ( sRecv < 0 )
            {
                switch (errno )
                {
#if ( EAGAIN != EWOULDBLOCK )
                    case EAGAIN:
#endif
                    case EWOULDBLOCK:
                        continue;
                    case ECONNRESET:
                    case ECONNREFUSED:
                        _THROW ( ERR_SYSCALL_RECV );
                        break;
                    default:
                        _THROW ( ERR_SYSCALL_RECV );
                        break;
                }
            }

            sInd = sInd + sRecv;
        }

        memcpy_s(&sLen, sLenBuf, 4 );

        /**************************************
         * Step2: Read Data
        **************************************/
        /*********************************************************
         * 의도는 이렇다. 4byte를 받고 그걸 그대로 length로
         * 인식해서 데이터를 계속 수신하는게 의도엿다.
         * 근데 아래에서 데이터를 4byte뒤부터 받아야 끝까지 받는다.
         * 즉, 앞의 4byte는 내가 받을 전체데이터의 길이파트다.
        *********************************************************/
        sInd = 4;
        memcpy (aData, &sLen, sizeof(int));

        while ( sInd < sLen )
        {
            sRecv = recv( aSockFd, ( aData + sInd), (sLen - sInd), 0 );
            if ( sRecv == 0 )
            {
                // 2014.10.22 -okt- recv() 함수가 0 으로 리턴된 것은. PEERDOWN을 의미
                //_THROW ( ERR_SYSCALL_RECV );
                _THROW ( ERR_DBM_SOCK_PEERDOWN );
            }

            if ( sRecv < 0 )
            {
                switch ( errno )
                {
#if ( EAGAIN != EWOULDBLOCK )
                    case EAGAIN:
#endif
                    case EWOULDBLOCK:
                        continue;
                        break;
                    case ECONNRESET:
                    case ECONNREFUSED:
                        _THROW ( ERR_SYSCALL_RECV );
                        break;
                    default:
                        _THROW ( ERR_SYSCALL_RECV );
                        break;
                }
            }

            sInd = sInd + sRecv;
        }
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_SOCK_PEERDOWN )
        {
            _CATCH_INFO;
        }
        else
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    {
        *aRecvedSize = sInd;
    }
    _END
}

/******************************************************************************
 * Name : cmnTcpClose
 *
 * Description
 *   Tcp Socket 을 close 한다.
 *
 * Argument
 *   aSockFd    : input  : Socket FD
 *
 ******************************************************************************/
void cmnTcpClose( int aSockFd )
{
    close_s( aSockFd );
}
