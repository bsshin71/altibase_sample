/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   common shared memory library
 ******************************************************************************/
#ifdef __linux__	//TODO: [OKT]  윈도포팅

#include "cmnHeader.h"


/******************************************************************************
 * Name : getKey
 *
 * Description
 *   shm segment의 고유ID를 Random하게 생성한다.
 *
 * Argument
 *   aKeyFilePath  : input
 *
 * Return
******************************************************************************/
int cmnGetKey( char* aKeyString )
{
    int          sI;
    int          sN;
    int          sKey;


    sN = strlen_s( aKeyString );
    sKey = 5381;

    /************************************************
     * 완전Hash가 아니라서 언제가는 쫑날 수 있음.
    ************************************************/
    for (sI=0; sI < sN; sI++ )
    {
        sKey = ( (sKey << 5) + sKey) + aKeyString[sI];
    }

    return ( abs(sKey) );
}



/******************************************************************************
 * Name : cmnShmCreate
 *
 * Description
 *   shm segment 를 생성하고 ID 를 반납한다.
 *   이미 같은 key 로 생성이 되어 있으면 해당 segment 에 대한 ID 를 반납한다.
 *
 * Argument
 *   aKeyFilePath  : input  : shm key 생성에 필요한 file path
 *                            (실제 존재하는 file 의 fullpath 를 주어야 함.
 *                             file 의 uniqueness 를 이용하여 ftok 을 통해
 *                             shm key 를 생성하게 됨 )
 *   aSize         : input  : 생성할 shm size (64bit변수 )
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( < 0 )
 *
 ******************************************************************************/
int cmnShmCreate( char* aKeyFilePath, long long aSize )
{
    int             sShmID;
    int             sFtok;
    int             sRC;

    errno = 0;
/*
    sFD = open( aKeyFilePath, O_RDWR, 0777 );
    _IF_RAISE( sFD > 0, DUP_KEY_FILE_FAIL );

    sFD = open( aKeyFilePath, O_CREAT|O_RDWR, 0777 );
    _IF_RAISE( sFD <= 0, CREATE_KEY_FILE_FAIL );

    close( sFD );
    sFtok = ftok( aKeyFilePath,0 );
*/
    sFtok = cmnGetKey ( aKeyFilePath );
    _IF_RAISE( sFtok < 0, FTOK_FAIL );

    sShmID = shmget( sFtok, 0, 0777 );
    _IF_RAISE( sShmID != -1, DUP_ERROR );

    sShmID = shmget( sFtok, aSize, IPC_CREAT | 0777 );
    _IF_RAISE ( sShmID == -1, SHMGET_FAIL );

    return RC_SUCCESS;

    _EXCEPTION( FTOK_FAIL )
    {
        sRC = ERR_CMN_SHM_KEY_ERROR;
    }
    _EXCEPTION( DUP_ERROR )
    {
        sRC = ERR_CMN_SHM_DUP_ERROR;
    }
    _EXCEPTION( SHMGET_FAIL )
    {
        sRC = ERR_SYSCALL_SHMGET;
    }
    _EXCEPTION_END;

    return sRC;
}

/******************************************************************************
 * Name : cmnShmAttach
 *
 * Description
 *   생성한 shm 에 attach 하여 포인터를 리턴한다.
 *
 * Argument
 *   aKeyFilePath  : input  : shm key 생성에 필요한 file path
 *   aSize         : input  : 사용자가 Attach할만큼의 크기.
 *   aAttachAddr   : output : shm segment 의 시작주소를 가리키는 포인터
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( < 0 )
 *
 ******************************************************************************/
int cmnShmAttach( char* aKeyFilePath, long long aSize, char** aAttachAddr )
{
    int            sFtok;
    int            sShmID;
    int            sRC;

    /* sFtok = ftok( aKeyFilePath, 0 ); */
    sFtok = cmnGetKey ( aKeyFilePath );
    _IF_RAISE( sFtok < 0, FTOK_FAIL );

    sShmID = shmget( sFtok, aSize,  0777 );
    _IF_RAISE ( sShmID == -1, SHMGET_FAIL );

    * aAttachAddr = (char*)shmat( sShmID, 0, SHM_R|SHM_W );
    _IF_RAISE( * aAttachAddr == (char*)-1, SHMAT_FAIL );

    return RC_SUCCESS;

    _EXCEPTION( FTOK_FAIL )
    {
        sRC = ERR_CMN_SHM_KEY_ERROR;
    }
    _EXCEPTION( SHMGET_FAIL )
    {
        sRC = ERR_SYSCALL_SHMGET;
    }
    _EXCEPTION( SHMAT_FAIL )
    {
        sRC = ERR_SYSCALL_SHMAT;
    }
    _EXCEPTION_END;
    return sRC;
}

/******************************************************************************
 * Name : cmnShmDetach
 *
 * Description
 *   attach 한 shm 에서 detach 한다.
 *
 * Argument
 *   aAttachAddr   : input  : shm segment 의 시작주소를 가리키는 포인터
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( < 0 )
 *
 ******************************************************************************/
int cmnShmDetach( char** ppAddr )
{
    int           sRet;
    int           sRC;

    sRet = shmdt( (const void*)*ppAddr );
    _IF_RAISE( sRet == -1, SHMDT_FAIL );

    *ppAddr = NULL;

    return RC_SUCCESS;

    _EXCEPTION( SHMDT_FAIL )
    {
        sRC = ERR_SYSCALL_SHMDT;
    }
    _EXCEPTION_END;
    return sRC;
}

/******************************************************************************
 * Name : cmnShmDrop
 *
 * Description
 *   shm segment 를 삭제한다.
 *
 * Argument
 *   aKeyFilePath  : input  : shm key 생성에 필요한 file path
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( < 0 )
 *
 ******************************************************************************/
int cmnShmDrop( char* aKeyFilePath )
{
    int           sShmID;
    int           sFtok;
    int           sRet;
    int           sRC;

    /* sFtok = ftok( aKeyFilePath, 0 ); */
    sFtok = cmnGetKey ( aKeyFilePath );
    _IF_RAISE( sFtok < 0, FTOK_FAIL );

    sShmID = shmget( sFtok, 0,  0777 );
    _IF_RAISE ( sShmID == -1, SHMGET_FAIL );

    sRet = shmctl( sShmID, IPC_RMID, (struct shmid_ds *)0 );
    _IF_RAISE( sRet == -1, SHM_REMOVE_FAIL );

    unlink( aKeyFilePath );

    return RC_SUCCESS;

    _EXCEPTION( FTOK_FAIL )
    {
        sRC = ERR_CMN_SHM_KEY_ERROR;
    }
    _EXCEPTION( SHMGET_FAIL )
    {
        unlink ( aKeyFilePath );
        sRC = ERR_SYSCALL_SHMGET;
    }
    _EXCEPTION( SHM_REMOVE_FAIL )
    {
        sRC = ERR_SYSCALL_SHMCTL;
    }
    _EXCEPTION_END;
    return sRC;
}


/******************************************************************************
 * Name : cmnShmGetID
 *
 * Description
 *   shm ID를 리턴한다.
 *
 * Argument
 *   aKeyFilePath  : input  : shm key 생성에 필요한 file path
 *   aShmID        : output : shm ID를 리턴받을 변수
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( < 0 )
 *
 ******************************************************************************/
int cmnShmGetID( char*  aKeyFilePath,
                 int*   aShmID )
{
    int           sFtok;
    int           sRC;

    /* sFtok = ftok( aKeyFilePath, 0 ); */
    sFtok = cmnGetKey ( aKeyFilePath );
    _IF_RAISE( sFtok < 0, FTOK_FAIL );

    * aShmID = shmget( sFtok, 0,  0777 );
    _IF_RAISE ( * aShmID == -1, SHMGET_FAIL );

    return RC_SUCCESS;


    _EXCEPTION( FTOK_FAIL )
    {
        sRC = ERR_CMN_SHM_KEY_ERROR;
    }
    _EXCEPTION( SHMGET_FAIL )
    {
        sRC = ERR_SYSCALL_SHMGET;
    }

    _EXCEPTION_END;
    return sRC;
}


/******************************************************************************
 * Name : cmnShmGetAttachNum
 *
 * Description
 *   shm 에 Attach된 Process/Thread수를 리턴한다.
 *
 * Argument
 *   aKeyFilePath  : input  : shm key 생성에 필요한 file path
 *   aAttachNum    : output : shm attach된 process개수
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( < 0 )
 *
 ******************************************************************************/
int cmnShmGetAttachNum ( char*  aKeyFilePath,
                         int*   aAttachNum )
{
    int           sFtok;
    int           sRC;
    int           sShmID;
    struct  shmid_ds sShmInfo;

    /* sFtok = ftok( aKeyFilePath, 0 ); */
    sFtok = cmnGetKey ( aKeyFilePath );
    _IF_RAISE( sFtok < 0, FTOK_FAIL );

    sShmID = shmget( sFtok, 0,  0777 );
    _IF_RAISE ( sShmID == -1, SHMGET_FAIL );

    sRC = shmctl(sShmID, IPC_STAT, &sShmInfo );
    _IF_RAISE ( sRC, SHMCTL_FAIL );
    * aAttachNum = sShmInfo.shm_nattch;

    return RC_SUCCESS;


    _EXCEPTION( FTOK_FAIL )
    {
        sRC = ERR_CMN_SHM_KEY_ERROR;
    }
    _EXCEPTION( SHMGET_FAIL )
    {
        sRC = ERR_SYSCALL_SHMGET;
    }
    _EXCEPTION( SHMCTL_FAIL )
    {
        sRC = ERR_SYSCALL_SHMCTL;
    }

    _EXCEPTION_END;
    return sRC;
}


/******************************************************************************
 * Name : cmnShmIsDest
 *
 * Description
 *   shm의 상태가 혹시 DEST상태인지 체크해본다.
 *
 * Argument
 *   aKeyFilePath  : input  : shm key 생성에 필요한 file path
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( < 0 )
 *
 ******************************************************************************/
int cmnShmIsDest ( char* aKeyFilePath )
{
    int           sFtok;
    int           sRC;
    int           sShmID;
    struct  shmid_ds sShmInfo;

    /* sFtok = ftok( aKeyFilePath, 0 ); */
    sFtok = cmnGetKey ( aKeyFilePath );
    _IF_RAISE( sFtok < 0, FTOK_FAIL );

    sShmID = shmget( sFtok, 0,  0777 );
    _IF_RAISE ( sShmID == -1, SHMGET_FAIL );

    sRC = shmctl(sShmID, IPC_STAT, &sShmInfo );
    _IF_RAISE ( sRC == -1 || sShmInfo.shm_perm.mode == (0777 | SHM_DEST ), SHMCTL_FAIL );

    return RC_SUCCESS;

    _EXCEPTION( FTOK_FAIL )
    {
        sRC = ERR_CMN_SHM_KEY_ERROR;
    }
    _EXCEPTION( SHMGET_FAIL )
    {
        sRC = ERR_SYSCALL_SHMGET;
    }
    _EXCEPTION( SHMCTL_FAIL )
    {
        if ( sRC == -1 )
        {
            sRC = ERR_SYSCALL_SHMCTL;
        }
        else
        {
            sRC = ERR_CMN_SHM_DEST_STAT;
        }
    }

    _EXCEPTION_END;
    return sRC;
}

#endif /* __linux__ */
