/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   common posix thread library
 ******************************************************************************/
#include "cmnPThread.h"

/******************************************************************************
 * Name : cmnCreateThread
 *
 * Description
 *   Posix Thread 를 생성한다.
 *
 * Argument
 *   aThread    : input  : pthread 변수 포인터
 *   aCpuSet    : input  : 생성한 thread 에 할당할 cpu 번호.
 *                         -1 이면 default 로 시스템에서 자체 할당.
 *   aAttr      : input  : posix thread attribute - 사용하지 않으면 NULL 로 입력
 *   aFunc      : input  : 생성한 thread 가 수행할 function 포인터
 *   aInfo      : input  : thread 생성 시 parameter 로 넘겨줄 인자
 *
 ******************************************************************************/
_VOID cmnCreateThread ( pthread_t* aThread , short aCpuSet , pthread_attr_t* aAttr , cmnThreadFunc aFunc , void* aInfo )
{
    int           sRet;
    int           sRC;

    _IF_RAISE( aFunc == NULL, INVALID_ARG );

    sRet = pthread_create( aThread, aAttr, aFunc, aInfo );
    _IF_RAISE( sRet != 0, CREATE_THREAD_FAIL );

    if ( aCpuSet >= 0 )
    {
        sRet = cmnSetThrAffinity( aThread, aCpuSet );
        _IF_RAISE( sRet != 0, SET_AFFINITY_FAIL );
    }

    return RC_SUCCESS;

    _EXCEPTION( INVALID_ARG )
    {
        sRC = -1;
    }
    _EXCEPTION( CREATE_THREAD_FAIL )
    {
        sRC = -2;
    }
    _EXCEPTION( SET_AFFINITY_FAIL )
    {
        sRC = -2;
    }
    _EXCEPTION_END;

    return sRC;
}

//TODO: [OKT] 윈도포팅. cpu_set_t 미지원
#ifdef __linux__

/******************************************************************************
 * Name : cmnSetThrAffinity
 *
 * Description
 *   생성한 posix thread 에 대해 cpu affinity 를 설정한다.
 *
 * Argument
 *   aThread    : input  : pthread 변수 포인터
 *   aCpuSet    : input  : 생성한 thread 에 할당할 cpu 번호.
 *
 ******************************************************************************/
_VOID cmnSetThrAffinity ( pthread_t* aThread , short aCpuSet )
{
    cpu_set_t     sCpuSet;
    int           sRet;
    int           sRC;

    if ( aCpuSet >= 0 )
    {
        CPU_ZERO( &sCpuSet );
        CPU_SET( aCpuSet, &sCpuSet );

        sRet = pthread_setaffinity_np( *aThread, sizeof(cpu_set_t), &sCpuSet );
        _IF_RAISE( sRet != 0, SET_AFFINITY_FAIL );
    }

    return RC_SUCCESS;

    _EXCEPTION( SET_AFFINITY_FAIL )
    {
        sRC = -1;
    }
    _EXCEPTION_END;

    return sRC;
}

_VOID cmnSetCpuAffinity ( pthread_t aThread, void* aCpuSet )
{
    cpu_set_t*  sCpuSet = (cpu_set_t*)aCpuSet;

    _TRY
    {
        _CALL( pthread_setaffinity_np ( aThread, sizeof( cpu_set_t ), sCpuSet ) );
    }
    _CATCH
    {
#ifdef _DEBUG
        // 로그 출력을 할수 없는 위치일 수 있다.
        _CATCH_PRT;
#endif
    }
    _FINALLY
    _END
} /* cmnSetCpuAffinity */

#endif /* __linux__ */
