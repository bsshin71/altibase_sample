/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   RTW (Recovery Test Framework)
 *
 *   사용방법
 *    1. common library 를 make rtf 로 compile 한다.
 *    2. example/cmnRTF 에서처럼 사용한다. (make rtf 로 compile)
 ******************************************************************************/
#include "cmnHeader.h"

#ifdef _RTF_TEST

cmnRTFInfo  gTestCaseMap[MAX_RTF_HASH];

// 미사용 막기 - 2014/04/23
//void cmnRTFInit()
//{
//    memset_s( gTestCaseMap, 0x00, sizeof(cmnRTFInfo) * MAX_RTF_HASH );
//}

static int cmnRTFGetHashVal ( const char* aTestString , int aStrLen )
{
    int                 i;
    unsigned int        sKey   = 0;
    char                sStrT[128];
    unsigned int*       sPtr = (unsigned int *)sStrT;

    memset_s ( sStrT, 0x00, sizeof( sStrT ) );
    strncpy ( sStrT, aTestString, aStrLen );

    for ( i = 0; i < aStrLen; i++ )
    {
        sKey += *( sPtr++ );
    }

    return sKey % ( MAX_RTF_HASH - 1 );
}

/*
 * gTestCaseMap
 *   ---       ---       ---
 *  |   |  -> |   |  -> |   |
 *  | 0 |      ---       ---
 *  |---|      ---       ---
 *  |   |  -> |   |  -> |   |
 *  | 1 |      ---       ---
 *  |---|      ---
 *  |   |  -> |   |
 *  | 2 |      ---
 *  |---|
 *  |   |
 */
void cmnRTFEnable( char*  aTestCaseName,
                   int    aTargetCount,
                   int    aRTFType,
                   int    aPrintOutF )
{
    int         sHashVal;
    cmnRTFInfo* sCurRTF = NULL;
    cmnRTFInfo* sNewRTF = NULL;
    cmnRTFInfo* sLastRTF = NULL;

    sHashVal = cmnRTFGetHashVal( (const char *)aTestCaseName, strlen_s(aTestCaseName) );

    if( gTestCaseMap[sHashVal].mEnable == 1 )
    {
        if( gTestCaseMap[sHashVal].mNext == NULL )
        {
            sNewRTF = (cmnRTFInfo *)malloc_s(sizeof(cmnRTFInfo));
            memset_s( sNewRTF, 0x00, sizeof(cmnRTFInfo));
            gTestCaseMap[sHashVal].mNext = sNewRTF;
        }
        else
        {
            sCurRTF = gTestCaseMap[sHashVal].mNext;

            while( sCurRTF != NULL )
            {
                if( sCurRTF->mNext == NULL )
                {
                    sLastRTF = sCurRTF;
                }

                sCurRTF = sCurRTF->mNext;
            }

            sNewRTF = (cmnRTFInfo *)malloc_s(sizeof(cmnRTFInfo));
            memset_s( sNewRTF, 0x00, sizeof(cmnRTFInfo));
            sLastRTF->mNext = sNewRTF;
        }

        sNewRTF->mEnable = 1;
        strcpy_s( sNewRTF->mName, aTestCaseName );
        sNewRTF->mRTFType = aRTFType;
        sNewRTF->mPrintOutF = aPrintOutF;
        sNewRTF->mTargetCount = aTargetCount;

        if( aPrintOutF )
        {
            printf("Enable RTF( %s, %d )\n", sNewRTF->mName, aTargetCount);
        }
    }
    else
    {
        gTestCaseMap[sHashVal].mEnable  = 1;
        strcpy_s( gTestCaseMap[sHashVal].mName, aTestCaseName );
        gTestCaseMap[sHashVal].mRTFType = aRTFType;
        gTestCaseMap[sHashVal].mPrintOutF = aPrintOutF;
        gTestCaseMap[sHashVal].mTargetCount = aTargetCount;

        if( aPrintOutF )
        {
            printf("Enable RTF( %s, %d )\n", gTestCaseMap[sHashVal].mName, aTargetCount);
        }
    }
}

static cmnRTFInfo* cmnFindRTFInfo ( int aHashVal , const char* aTestCaseName )
{
    cmnRTFInfo* sCurRTF = NULL;

    if ( ! strcmp_s ( gTestCaseMap[aHashVal].mName, aTestCaseName ) )
    {
        return &gTestCaseMap[aHashVal];
    }

    sCurRTF = gTestCaseMap[aHashVal].mNext;

    while ( sCurRTF != NULL )
    {
        if ( ! strcmp_s ( sCurRTF->mName, aTestCaseName ) )
        {
            return sCurRTF;
        }

        sCurRTF = sCurRTF->mNext;
    }

    return NULL;
}

_VOID cmnRTFPoint ( const char* aTestCaseName )
{
    int         sHashVal;
    cmnRTFInfo* sFind = NULL;

    _TRY
    {
        if ( _cmn_use_rtf == 0 )
            _RETURN;

        sHashVal = cmnRTFGetHashVal( aTestCaseName, strlen_s(aTestCaseName) );

        sFind = cmnFindRTFInfo( sHashVal, aTestCaseName );
        if( sFind == NULL )
        {
            /*
             * 각 cmnRTFPoint 마다 Hash / Find 해보고
             * 없으면 그냥 리턴할거다.
             */
            _RETURN;
        }

        if( sFind->mEnable == 1 )
        {
            sFind->mCurrCount++;

            if( sFind->mCurrCount == sFind->mTargetCount )
            {
                switch( sFind->mRTFType )
                {
                    case CMN_RTF_ABORT:
                        if( sFind->mPrintOutF )
                        {
                            printf("ABORT( %s, %d )\n", sFind->mName, sFind->mTargetCount);
                        }
                        exit(1); /* abort message 를 없앨 수가 없어서 그냥 exit 로 */
                        break;

                    case CMN_RTF_DEFER_ABORT:
                        usleep ( 100 * 1000 );
                        exit(1);
                        break;

                    default:
                        break;
                }
            }
        }

    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

#endif /* _RTF_TEST */
