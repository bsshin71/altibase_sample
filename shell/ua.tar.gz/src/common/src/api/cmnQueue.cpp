/******************************************************************************
* Copyright 2012, OnmirSoft Corporation or its subsidiaries.
* All rights reserved.
******************************************************************************/

/******************************************************************************
* $Id$ *
* Description :
*   common system message queue library
******************************************************************************/
#ifdef __linux__	//TODO: [OKT]  윈도포팅

#include "cmnHeader.h"

/******************************************************************************
* Name : cmnQueueOpen
*
* Description
*   신규로 message queue 를 생성한다
*
* Argument
*   aQueueId     : output : msgget 으로 Q 생성 후 리턴되는 msgq의 고유 ID
*   aKeyFilePath : input  : 고유한 msgq 생성을 위해 Key 로 사용할 file path
*                           ftok 의 인자로 사용함
*
* Return
*   RC_SUCCESS(0) / Fail Value ( < 0 )
*
******************************************************************************/
int cmnQueueOpen( int* aQueueId, char* aKeyFilePath )
{
    key_t         sKey;
    int           sQueueId;
    int           sRC;

    sKey = ftok( aKeyFilePath, 'm' );

    sQueueId = msgget( sKey, IPC_CREAT|0666 );
    _IF_RAISE( sQueueId < 0, CREATE_QUEUE_FAIL );

    * aQueueId = sQueueId;

    return RC_SUCCESS;

    _EXCEPTION( CREATE_QUEUE_FAIL )
    {
            sRC = -1;
    }
    _EXCEPTION_END;

    return sRC;
}

/******************************************************************************
* Name : cmnQueueRecv
*
* Description
*   생성한 queue 로부터 message 를 읽는다
*
* Argument
*   aQueueId     : input  : message queue id
*   aMsgType     : input  : msg 들의 구분을 위해 사용자가 부여하는 type
*                           aMsgType 의 메시지들만 queue 에서 읽어들임
*   aMsgRcvFlag  : input  : msgrcv 의 모드
*                           (IPC_NOWAIT, MSG_NOERROR 등 )
*   aData        : output : 읽은 데이터를 저장할 Buffer
*   aSize        : input  : 수신할 Data 의 목표 크기
*   aRecvedSize  : output : 성공적으로 읽은 data 의 크기
*
* Return
*   RC_SUCCESS(0) / Fail Value ( < 0 )
*
******************************************************************************/
int cmnQueueRecv( int       aQueueId,
                  long long aMsgType,
                  int       aMsgRcvFlag,
                  char*     aData,
                  int       aSize,
                  int*      aRecvedSize )
{
    int            sRecv = 0;
    int            sRC;

    sRecv = msgrcv( aQueueId, aData, aSize, aMsgType, aMsgRcvFlag );
    DBM_DBG( "[DEBUG:cmnQueueRecv] %d", sRecv );
    DBM_DBG( "[DEBUG:cmnQueueRecv] %s", ( (cmnQData *)aData)->qData );
    _IF_RAISE( sRecv == 0, RECV_ZERO );
    if(sRecv < 0 )
    {
        DBM_DBG( "[DEBUG:cmnQueueRecv] [%d]%s",errno, strerror(errno) );
        _RAISE(RECV_FAIL );
    }

    * aRecvedSize = sRecv;

    return RC_SUCCESS;

    _EXCEPTION( RECV_FAIL )
    {
        sRC = -1;
    }
    _EXCEPTION( RECV_ZERO )
    {
        sRC = -2;
    }
    _EXCEPTION_END;

    * aRecvedSize = sRecv;

    return sRC;
}


/******************************************************************************
* Name : cmnQueueSend
*
* Description
*   생성한 queue 에 message 를 기록한다
*
* Argument
*   aQueueId     : input  : message queue id
*   aMsgType     : input  : msg 들의 구분을 위해 사용자가 부여하는 type
*   aData        : input  : 전송할 data 가 저장된 buffer
*   aSize        : input  : 전송할 data 의 목표 크기
*
* Return
*   RC_SUCCESS(0) / Fail Value ( < 0 )
*
******************************************************************************/
int cmnQueueSend( int       aQueueId,
                  long long aMsgType,
                  char*     aData,
                  int       aSize )
{
    int                sSendLen;
    int                sRC;

    ( (cmnQData *)aData)->qType = aMsgType;

    sSendLen = msgsnd( aQueueId, aData, aSize, 0 );
    _IF_RAISE( sSendLen != 0, SEND_FAIL );

    /*
    if ( sSendLen != 0 )
    {
        // fail TODO
        _RAISE( SEND_FAIL );
    }
    */

    return RC_SUCCESS;

    _EXCEPTION(SEND_FAIL )
    {
        sRC = -1;
    }
    _EXCEPTION_END;

    return sRC;
}


/******************************************************************************
* Name : cmnQueueClose
*
* Description
*   생성한 queue 를 삭제한다
*
* Argument
*   aQueueId     : input  : message queue id
*
* Return
*   RC_SUCCESS(0) / Fail Value ( < 0 )
*
******************************************************************************/
int cmnQueueClose( int aQueueId )
{
    int            sRet;
    int            sRC;

    sRet = msgctl( aQueueId, IPC_RMID, 0 );
    _IF_RAISE( sRet != 0, CLOSE_FAIL );

    return RC_SUCCESS;

    _EXCEPTION( CLOSE_FAIL )
    {
        sRC = -1;
    }
    _EXCEPTION_END;

    return sRC;
}


/******************************************************************************
* Name : cmnQueueState
*
* Description
*   queue 의 상태를 조회한다
*
* Argument
*   aQueueId         : input  : message queue id
*   aMaxQBytes       : output : Queue 의 최대 전체 저장가능 msg byte 크기
*   aCurrentMsgBytes : output : Queue 에 현재 저장되어 있는 전체 msg 의 크기
*   aCurrentMsgCount : output : Queue 에 현재 저장되어 있는 전체 msg 의 갯수
*
* Return
*   RC_SUCCESS(0) / Fail Value ( < 0 )
*
******************************************************************************/
int cmnQueueState( int aQueueId, long long* aMaxQBytes, long long* aCurrentMsgBytes, long long* aCurrentMsgCount )
{
    struct msqid_ds sStat;
    int             sRet;
    int             sRC;

    memset_s( (char*)&sStat, 0x00, sizeof(struct msqid_ds) );

    sRet = msgctl( aQueueId, IPC_STAT, &sStat );
    _IF_RAISE( sRet != 0, STAT_FAIL );

    * aMaxQBytes       = sStat.msg_qbytes;
    * aCurrentMsgBytes = sStat.msg_cbytes;
    * aCurrentMsgCount = sStat.msg_qnum;

    return RC_SUCCESS;

    _EXCEPTION( STAT_FAIL )
    {
        sRC = -1;
    }
    _EXCEPTION_END;

    return sRC;
}

#endif /* __linux__ */
