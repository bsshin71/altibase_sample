/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/
#include "cmnHeader.h"


/****************************************************************
 * Name : cmnOpenConfigFile
 *
 * Description
 *   설정파일을 여는 함수, 사용자가 호출해야 함.
 *
 * Argument
 *   aFileName : 설정파일의 절대경로를 포함한 full-name
 *   aFD       : 리턴받을 파일Descriptor 포인터
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( != 0 )
 *
****************************************************************/
_VOID cmnOpenConfig ( const char* aFileName, int* aFD )
{
    _TRY
    {
        // fileName은 첫번째 바이트가 공백이거나 Null이면 에러
        if ( aFileName[0] == ' ' || aFileName[0] == 0x00 )
            _THROW ( ERR_CMN_INVALID_FILE_NAME );

        *aFD = open( aFileName, O_RDONLY );
        if ( *aFD <= 0 )
            _THROW ( ERR_SYSCALL_OPEN );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}



/****************************************************************
 * Name : cmnCloseConfigFile
 *
 * Description
 *   설정파일을 닫는 함수, 사용자가 호출해야 함.
 *
 * Argument
 *   aFD       : 사용중인 파일Descriptor
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( != 0 )
 *
****************************************************************/
_VOID cmnCloseConfig ( int* aFD )
{
    _TRY
    {
        if ( *aFD <= 0 )
            _THROW ( ERR_CMN_INVALID_FILE_FD );

        close_s ( *aFD );
    }
    _CATCH
    _FINALLY
    _END
}



/****************************************************************
 * Name : cmnFindBrace
 *
 * Description
 *   내부용도이다. 읽어들인 Buff내의 Brace찾기.
 *
 * Argument
 *   aBuff   : 이 함수를 호출한쪽의 파일내용이 담긴 버퍼.
 *   aPos    : Section이 시작되는 위치.
 *   aMax    : aBuff의 크기를 의미한다.
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( != 0 )
 *
****************************************************************/
static _VOID cmnFindBrace ( char* aBuff, int aPos, int aMax )
{
    int          i;
    int          sFind = 0;

    _TRY
    {
        /**********************************************************
         * aSection 단어 앞으로 탐색하면서 "[" 문자를 찾아낸다.
        **********************************************************/
        for ( i=aPos-1; i>=0 ; i-- )
        {
            /**********************************************************
             * 탐색과정에서 CR, #이 오면 해당 라인은 무효임으로 에러처리.
            **********************************************************/
            if ( aBuff[i] == '\n' || aBuff[i] == '#' )
            {
                return RC_FAILURE;
            }
            if ( aBuff[i] == '[' )
            {
                sFind = 1;
                break;
            }
        }
        if ( sFind == 0 )
        {
            return RC_FAILURE;
        }

        /**********************************************************
         * aSection 단어 뒤로 탐색하면서 "]" 문자를 찾아낸다.
        **********************************************************/
        for ( i=aPos+1; i<aMax ; i++ )
        {
            /**********************************************************
             * 탐색과정에서 CR, #이 오면 해당 라인은 무효임으로 에러처리.
            **********************************************************/
            if ( aBuff[i] == '\n' || aBuff[i] == '#' )
            {
                return RC_FAILURE;
            }
            if ( aBuff[i] == ']' )
            {
                sFind = 2;
                return RC_SUCCESS;
            }
        }

        /**********************************************************
         * 여기까지 왔다면 실패이다.
        **********************************************************/
        return RC_FAILURE;
    }
    _CATCH
    _FINALLY
    _END
}





/****************************************************************
 * Name : cmnMoveSection
 *
 * Description
 *   내부용도이다. 읽어들인 파일내의 특정 Section을 찾기.
 *
 * Argument
 *   aFD      : 사용자가 열어놓은 FD를 입력한다.
 *   aSection : 찾고자 하는 하나의 Block의 AliasName을 입력한다.
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( != 0 )
 *
****************************************************************/
int cmnMoveSection ( int aFD, const char* aSection )
{
    char*   sBuff = NULL;
    long long sFileSize = 0L, i;
    int     sDiffLen = 0;
    int     sRC;

    /**********************************************************
     * FD가 유효하지 않을 수 있다. 체크.
    **********************************************************/
    if ( aFD <= 0 )
    {
        return RC_FAILURE;
    }

    /**********************************************************
     * FD의 전체 크기를 알아낸다.
    **********************************************************/
    sFileSize = lseek( aFD, 0L, SEEK_END );
    if ( sFileSize < 0 )
    {
        //fprintf(stdout, "sFileSize = %ld (aFD=%d), errno=%d, thr=%ld\n", sFileSize, aFD, errno, pthread_self());
        return errno;
    }

    /**********************************************************
     * FD의 전체 크기만큼 Malloc을 해놓는다.
    **********************************************************/
    sBuff = (char*)malloc_s(sFileSize );
    if (!sBuff )
    {
        return errno;
    }

    /**********************************************************
     * FD의 처음 위치로 이동.
    **********************************************************/
    if (lseek( aFD, 0L, SEEK_SET ) < 0 )
    {
        free( sBuff );
        return errno;
    }

    /**********************************************************
     * 전체를 읽는다. 실패시 에러처리.
     * 나중에 아마 nbyte만큼 읽게 바꿔야 할지 모름.
     * 한방에 읽을 수 있는 크기가 웬지 OS에 의해 제한될듯.
    **********************************************************/
    if (read( aFD, sBuff, sFileSize) != sFileSize )
    {
        //fprintf(stdout, "read fail in moveSection\n");
        free( sBuff );
        return errno;
    }

    sDiffLen = strlen_s( aSection );
    /**********************************************************
     * 처음부터 aSection단어를 비교해본다.
    **********************************************************/
    for ( i=0; i<(sFileSize - sDiffLen); i++ )
    {
        // 2014.12.14. -okt- dbmInitHandle 단계에서 무지막지하게 호출된다. 나중에 보자.
        if ( strncmp_s(sBuff + i, aSection, sDiffLen) == 0 )
        {
            /**********************************************************
             * 찾았으나 aSection 바로 뒷문자가 공백도, 구문자도 아니라면
             * 이 단어는 잘못표기된 단어로 판단해야 함.
            **********************************************************/
            if ( sBuff[i + sDiffLen] != ']' && sBuff [i + sDiffLen] != ' ' )
            {
                continue;
            }
            /**********************************************************
             * aSection을 찾았다면 앞뒤로 괄호가 있는지 체크해본다.
            **********************************************************/
            sRC = cmnFindBrace( sBuff, i, sFileSize );

            /**********************************************************
             * 괄호가 없다면 이 단어는 무효이다.
            **********************************************************/
            if ( sRC )
            {
                continue;
            }
            /**********************************************************
             * 괄호가 없다면 이 단어는 무효이다.
            **********************************************************/
            lseek( aFD, i, SEEK_SET );
            free( sBuff );
            return RC_SUCCESS;
        }
    }

    /**********************************************************
     * 여기까지 왔다면 못찾은것. 실패리턴.
    **********************************************************/
    free( sBuff );
    return RC_FAILURE;
}





/****************************************************************
 * Name : cmnFindEqualAndValue
 *
 * Description
 *   내부용도이다. Tag/Value를 찾아내기
 *
 * Argument
 *   aBuff    : 이미 읽어낸 파일내용이다.
 *   aPos     : aElement가 시작되는 위치이다.
 *   aMax     : aBuff의 크기를 의미한다.
 *   aValue   : Element에 해당하는 Value를 담아서 리턴해준다.
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( != 0 )
 *
****************************************************************/
int cmnFindEqualAndValue ( char*    aBuff,
                           int      aPos,
                           int      aMax,
                           char*    aValue )
{
    int          i, j;
    int          sFind = 0;

    /**********************************************************
     * 앞쪽으로 먼저 탐색해서 주석인지 체크해봐야 한다.
    **********************************************************/
    for ( i=aPos; i>=0 ;i-- )
    {
        if ( aBuff[i] == '#' )
        {
            return RC_FAILURE;
        }
        if ( aBuff[i] == '\n' )
        {
            break;
        }
    }

    /**********************************************************
     * Equal value를 찾아본다. 이때 주석이나 CR이 오면 에러다.
    **********************************************************/
    for ( i=aPos; i<aMax; i++ )
    {
        if ( aBuff[i] == '\n' || aBuff[i] == '#' )
        {
            return RC_FAILURE;
        }
        if ( aBuff[i] == '=' )
        {
            sFind = i;
            break;
        }
    }

    if ( sFind == 0 )
    {
        return RC_FAILURE;
    }

    /**********************************************************
     * 찾았다면 여기서부터는 값을 담기 시작한다.
    **********************************************************/
    j = 0;
    for ( i=sFind+1; i<aMax; i++ )
    {
        /**********************************************************
         * 값을 담고 있는데 공백, CR, #등이 오면 거기까지만 유효함.
        **********************************************************/
        if (j != 0 && ( aBuff[i] == '\n' || aBuff[i] == '#') )
        {
            break;
        }
        /**********************************************************
         * 공백이 아니라면 값을 담는다.
        **********************************************************/
        if ( aBuff[i] != ' ' )
        {
            aValue[j] = aBuff[i];
            j++;
            aValue[j] = 0x00;
        }
    }


    /********************************************************
     * 끝에서부터만 Trim시켜서 공백을 제거해버린다.
    ********************************************************/
    for ( i=j-1; i>=0 ;i-- )
    {
        if ( aValue[i] != ' ') break;
        if ( aValue[i] == ' ') aValue[i] = 0x00;
    }

    return RC_SUCCESS;
}




/****************************************************************
 * Name : cmnReadElement
 *
 * Description
 *   Tag/Value를 찾아내기
 *
 * Argument
 *   aFD      : File Descriptor
 *   aSection : Section의 이름을 의미한다.
 *   aElement : Element의 이름을 의미한다.
 *   aValue   : Element에 해당하는 Value를 담아서 리턴해준다.
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( != 0 )
 *
****************************************************************/
_VOID cmnReadElement ( int    aFD,
                     const char*  aSection,
                     char*  aElement,
                     char*  aValue,
                     int*   aPosition )
{
    int     pSeq = 0;
    char*   sBuff = NULL;
    int     sBuffLen = 0;
    long long sFileSize = 0L;
    long long sOrgPos = 0L;
    int     i, j;
    int     sDiffLen = 0;
    int     sRC;
    long long sRC2;

    _TRY
    {
        // FD 유효성 체크한다.
        _ASSERT ( aFD > 0 );

        aValue[0] = 0x00;

        // Section을 찾아서 이동시킨다.
        _CALL( cmnMoveSection ( aFD, aSection ) );

        // Section을 찾았다면 딱 그위치에 FD가 멈춘상태임.
        sOrgPos = lseek_s ( aFD, 0L, SEEK_CUR );
        _IF_THROW( sOrgPos < 0, ERR_SYSCALL_LSEEK );

        // 끝까지 그냥 읽어낸다.
        sFileSize = lseek_s ( aFD, 0L, SEEK_END );
        _IF_THROW( sFileSize < 0, ERR_SYSCALL_LSEEK );

        // 끝까지 읽어낸 내용을 담을 버퍼를 할당한다.
        sBuff = (char*) malloc_s ( sFileSize - sOrgPos );

        // Section위치부터 끝까지 내용을 읽어들인다.
        sRC2 = lseek_s ( aFD, sOrgPos, SEEK_SET );
        _IF_THROW( sRC2 < 0, ERR_SYSCALL_LSEEK );

        sBuffLen = read_s ( aFD, sBuff, ( sFileSize - sOrgPos ) );
        _IF_THROW( sBuffLen != ( sFileSize - sOrgPos ), ERR_SYSCALL_READ );
//        DBM_DBG ( "=========> read (%-90.90s)", sBuff);

        /**********************************************************
         * Section위치부터 Element의 단어를 비교해간다.
         **********************************************************/
        aValue[0] = 0x00;
        sDiffLen = strlen_s ( aElement );

        // [valgrind] Invalid read of size 1 [PID: 7072]
//      for ( i = 0; i < ( sFileSize - sDiffLen ); i++ )
        for ( i = 0; i < sBuffLen; i++ )
        {
            if ( sBuff[i] == '[' )
                break;
            if ( sBuff[i] == '#' )
            {
                for ( j = i; j < sBuffLen; j++ )
                {
                    if ( sBuff[j] == '\n' )
                        break;
                }
                i = j;
                continue;
            }

            // 2014.12.14. -okt- dbmInitHandle 단계에서 무지막지하게 호출된다. 성능구간 아니다.
            if ( strncmp_s ( sBuff + i, aElement, sDiffLen ) == 0 )
            {
//                DBM_DBG ( "=========> find tag [%-40.40s]", sBuff + i);
                /**********************************************************
                 * 찾았으나 aSection 바로 뒷문자가 공백도, 구문자도 아니라면
                 * 이 단어는 잘못표기된 단어로 판단해야 함.
                 **********************************************************/
                if ( sBuff[i + sDiffLen] != '=' && sBuff[i + sDiffLen] != ' ' )
                {
                    continue;
                }
                if ( ( aPosition == NULL && pSeq == 0 ) || pSeq == ( *aPosition ) )
                {
                    /**********************************************************
                     * Element를 찾으면 Value을 알아낸다.
                     **********************************************************/
                    sRC = cmnFindEqualAndValue ( sBuff, i, (int)( sFileSize - sOrgPos ), aValue );
                    if ( sRC == RC_SUCCESS )
                    {
                        if ( aPosition != NULL )
                        {
                            *aPosition = ( *aPosition ) + 1;
                        }

                        _RETURN; // 성공
                    }
                }

                pSeq = pSeq + 1;
            }
        } /* for */

        /**********************************************************
         * 여기까지 왔다면 없다는 의미임.
        **********************************************************/
        _THROW ( RC_FAILURE );
    }
    _CATCH
    {
        if ( _rc != RC_FAILURE )
        {
            _CATCH_TRC;
        }
    }
    _FINALLY
    {
        free_s ( sBuff );
    }
    _END
}


/****************************************************************
 * Name : cmnParseFetch
 *
 * Description
 *   하나의 Value내에서 다시 parsing하고자 할때
 *
 * Argument
 *   aBuff      : 전체 String이 담긴 버퍼
 *   aDelimeter : 구분자를 의미한다. 한byte이상이믄 된다.
 *   aValue     : 구분자로 분리된 값을 리턴받을 포인터다.
 *   aRestart   : 구분자로 여러개 나열된 경우 처음부터 혹은 next형태로 하지 여부.
 *              1: 처음부터 찾아서 리턴, 그외값은 Next형태.
 * (ex )
 *   aBuff = node1,node2,node3 인 경우.
 *   이 함수를 aRestart= 1로 호출하면 node1을 처음 리턴한다.
 *   이 함수를 aRestart= 0으로 호출하면 node2, node3을 차례로 리턴해준다.
 *   더 이상 읽을 게 없으면 -1을 리턴하게 된다.
 *
 * Return
 *   RC_SUCCESS(0) / Fail Value ( != 0 )
 *
****************************************************************/
int cmnParseFetch ( char*   aBuff,
                    char*   aDelimeter,
                    char*   aValue,
                    int*    aPosition )
{
    int     i;
    int     sLen = 0;
    int     sDiffLen = 0;
    int     pSeq;
    int     sPos;

    /**********************************************************
     * 각 종 indicator변수들을 모두 초기화시킨다.
    **********************************************************/
    pSeq = sPos = 0 ;
    aValue[0] = 0x00;
    sLen = strlen_s( aBuff );
    sDiffLen = strlen_s( aDelimeter );

    /**********************************************************
     * aBuff길이만큼 Loop을 돌면서 delimeter를 이용해서 분리한다.
    **********************************************************/
    for ( i=0; i<sLen; i++ )
    {
        /**********************************************************
         * CR, #문자열은 끝났다는 의미니까 종료한다.
         * 실제 이 값이 담겨져서 올리는 아마도 없을듯 하지만.
        **********************************************************/
        if ( aBuff[i] == '\n' || aBuff[i] == '#' )
        {
            /**********************************************************
             * 혹시라도 왔는데 Sequence가 갔더라 그럼 리턴해준다.
            **********************************************************/
            if ( pSeq == (* aPosition) )
            {
                * aPosition = (* aPosition) + 1;
                return RC_SUCCESS;
            }
            break;
        }

        /**********************************************************
         * 공백은 모두 무시한다.
        **********************************************************/
        if ( aBuff[i] == ' ' )
        {
            continue;
        }

        /**********************************************************
         * 구분자를 비교해본다.
        **********************************************************/
        if ( strncmp_s( aBuff + i, aDelimeter, sDiffLen) == 0 )
        {
            /**********************************************************
             * 저장된 sSeq와 현재 구분해서 본 sequence가 매칭되면 맞음.
            **********************************************************/
            if ( ( aPosition == NULL && pSeq == 0) || pSeq == (* aPosition) )
            {
                if ( aPosition != NULL )
                {
                    * aPosition = (* aPosition) + 1;
                }
                return RC_SUCCESS;
            }
            /**********************************************************
             * 다음 구분자까지 또 가봐야 한다.
            **********************************************************/
            pSeq = pSeq + 1;
            sPos = 0;
            aValue[sPos] = 0x00;
            continue;
        }

        /**********************************************************
         * 리턴해줄 값을 여기서 저장해둔다.
        **********************************************************/
        aValue[sPos] = aBuff[i];
        sPos = sPos + 1;
        aValue[sPos] = 0x00;
    }

    /**********************************************************
     * 마지막 읽은 값이 있고 Sequence가 맞다면 리턴해준다.
    **********************************************************/
    if ( pSeq == (* aPosition) && sPos > 0 )
    {
        if ( aPosition != NULL )
        {
            * aPosition = (* aPosition) + 1;
        }
        return RC_SUCCESS;
    }

    /**********************************************************
     * 여기까지 왔다면 오류임으로 에러로 리턴해준다.
    **********************************************************/
    aValue[0] = 0x00;
    return RC_FAILURE;
}
