/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/
#ifdef __linux__	//TODO: [OKT]  윈도포팅

#include "cmnSem.h"


/******************************************************************************
 * Name : cmnSemInit
 *
 * Description
 *     sem_t객체를 Process Shared하게 설정한다.
 *
 * Argument
 *     aSem   : 대상Sem_t변수의 주소값을 입력한다.
 *     aShared: 공유할지 말지 (0이면 공유한다. )
 *     aValue : 초기값.
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnSemInit ( sem_t* aSem,
                 int    aShared,
                 int    aValue )
{
    int             sRC;

    errno = 0;
    /********************************************
     * aValue의 쓰임새가 있을지 모르겠음.
    ********************************************/
    sRC = sem_init( aSem, aShared, aValue );
    _IF_RAISE ( sRC, SEM_INIT_FAIL );

    return RC_SUCCESS;

    _EXCEPTION(SEM_INIT_FAIL )
    {
        sRC = ERR_SYSCALL_SEM_INIT;
    }
    _EXCEPTION_END;
    return sRC;
}


/******************************************************************************
 * Name : cmnSemDrop
 *
 * Description
 *    sem_t 변수를 없앤다.
 *
 * Argument
 *    aSem : Sem_t 변수포인터
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnSemDrop( sem_t* aSem )
{
    int             sRC;

    errno = 0;
    sRC = sem_destroy( aSem );
    _IF_RAISE ( sRC, SEM_DESTROY_FAIL );

    _EXCEPTION( SEM_DESTROY_FAIL )
    {
        sRC = ERR_SYSCALL_SEM_DESTROY;
    }

    _EXCEPTION_END;
    return sRC;
}



/******************************************************************************
 * Name : cmnSemWait
 *
 * Description
 *     sem_t를 기다린다.
 *
 * Argument
 *     aSem       : sem_t 포인터
 *     aSpinCount : tryCount
 *     aTimeout   : Timeout값 0이면 무한정대기
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnSemWait( sem_t*  aSem,
                int     aTryCount,
                int     aTimeout )
{
    struct timespec sTimer;
    int             sRC;
    int             sTry = 0, sTimeout = aTimeout;


    while ( 1 )
    {
        /***********************************************************
         * 재시도, timeout모두 0이면 무한대기
         * tryCount가 있으면 try형태로 (timeout이 무시됨 )
         * timeout이 있으면 timeout모드로. (tryCount가 무시됨 )
        ***********************************************************/
        if ( aTryCount == 0 && aTimeout == 0 )
        {
            sRC = sem_wait( aSem );
        }
        else if ( aTimeout > 0 )
        {
            clock_gettime_s(CLOCK_REALTIME, &sTimer );
            if ( sTimeout >= 1000000 )
            {
                sTimer.tv_sec  = sTimer.tv_sec + sTimeout / 1000000;
                sTimeout = sTimeout - (sTimeout / 1000000) * 1000000;
                if ( sTimeout < 0) sTimeout = 0;
            }

            if ( (sTimer.tv_nsec  + (sTimeout * 1000)) >= 1000000000L )
            {
                sTimer.tv_sec  = sTimer.tv_sec + 1;
                sTimer.tv_nsec = 1000000000L - sTimer.tv_nsec;
            }
            else
            {
                sTimer.tv_nsec = sTimer.tv_nsec + (sTimeout * 1000);
            }

            sRC = sem_timedwait( aSem, &sTimer );
        }
        else if ( aTryCount > 0 )
        {
            sRC = sem_trywait( aSem );
        }

        switch (sRC )
        {
            case 0:
                return sRC;
            case -1:
                /* Timeout이 있으면 바로 리턴 */
                if ( aTimeout > 0 )
                {
                    return errno;
                }
                /* TryCount가 있으면 재시도 */
                if ( aTryCount <= 0 )
                {
                    return errno;
                }
                else if ( sTry++ >= aTryCount )
                {
                    return errno;
                }
                break;
            default:
                return sRC;
        }
    }
}


/******************************************************************************
 * Name : cmnSemPost
 *
 * Description
 *     sem_t를 해제한다.
 *
 * Argument
 *     aSem   : sem_t 변수포인터
 *
 * Return
 *     SUCCESS / FAIL
 *
******************************************************************************/
int cmnSemPost( sem_t* aSem )
{
    int             sRC;

    sRC = sem_post( aSem );
    _IF_RAISE ( sRC, SEM_POST_FAIL );

    _EXCEPTION(SEM_POST_FAIL )
    {
        sRC = ERR_SYSCALL_SEM_POST;
    }
    _EXCEPTION_END;
    return sRC;
}

#endif /* __linux__ */
