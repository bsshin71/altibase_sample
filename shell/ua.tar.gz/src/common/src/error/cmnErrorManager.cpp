/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *     Error Message Management Class
 *******************************************************************************/
#include "cmnHeader.h"
#include "cmnErrorManager.h"

/********************************************************************
 * Static Variable
 ********************************************************************/
std::map<int, std::string>* cmnErrorManager::mErrMap = NULL;


/********************************************************************
 * class member function
 ********************************************************************/
// 생성자
cmnErrorManager::cmnErrorManager( )
{
    //mErrCode     = 0;
}

cmnErrorManager::~cmnErrorManager( )
{
}


_VOID cmnErrorManager::init ( )
{
    char    sFileName[1024];
    char    sDefine[1024];
    int     sErrCode;
    char    sBuffer[4096];
    char    sErrFormat [4096];
    int     sStart;
    int     sEnd;
    int     sLen;
    FILE*   fp = NULL;
    int     i;

    _TRY
    {
        _TEST_THROW( mErrMap == NULL, -1 );
        mErrMap = new std::map<int, std::string>;

        /************************************************
         * 에러파일 연다.
         ************************************************/
//      sprintf (sFileName, "%s/%s/%s", getenv( ENV_DBM_HOME ), DBM_CONFIG_FILE_PATH, DBM_ERROR_FILE_NAME);
        sprintf ( sFileName, "%s/%s/%s", getenv ( ENV_DBM_HOME ), "conf", "dbm.error" );
        fp = fopen ( sFileName, "r" );
        if ( fp == NULL )
        {
            _PRT( "Error File not exist. [%s] (err=%d)\n", sFileName, errno );
            _THROW( -1 );
        }

        /************************************************
         * 한줄씩 꺼내서 등록해놓는다.
         ************************************************/
        while ( !feof ( fp ) )
        {
            memset_s ( sBuffer, 0x00, sizeof( sBuffer ) );

            if ( fgets ( sBuffer, sizeof( sBuffer ) - 1, fp ) == NULL )
                break;

            if ( (char) sBuffer[0] == (char) '#' || (char) sBuffer[0] == (char) 0x00 || (char) sBuffer[0] == (char) '\n' )
            {
                continue;   // 맨앞에 # 이나 아무내용없으면 다음줄로.
            }

            /************************************************
             * 앞에 2개.
             ************************************************/
            sscanf ( sBuffer, "%s %d %s", sDefine, &sErrCode, sErrFormat );

            /************************************************
             * 마지막 String은 짤라내야 하니까.
             * 구분자를 쌍따옴표로 하고 있음.
             ************************************************/
            sLen = strlen_s ( sBuffer );
            sStart = sEnd = -1;
            for ( i = 0; i < sLen; i++ )
            {
                if ( sBuffer[i] == '\"' && sStart == -1 )
                {
                    sStart = i + 1;
                    continue;
                }
                if ( sBuffer[i] == '\"' && sEnd == -1 )
                {
                    sEnd = i - 1;
                    break;
                }
            }

            // 짤라내고 보니 이상타.
            if ( sStart == -1 || sEnd == -1 )
            {
                _PRT( "Format not found\n" );
                _THROW( -1 );
            }

            // 별 이상없으면 Format으로 사용
            memset_s ( sErrFormat, 0x00, sizeof( sErrFormat ) );
            memcpy_s ( sErrFormat, sBuffer + sStart, ( sEnd - sStart ) + 1 );

            // Map에 코드와 함께 저장한다. (둘다 동일)
            //mErrMap->insert ( std::map<int, std::string>::value_type ( sErrCode, sErrFormat ) );
            (*mErrMap)[sErrCode] = sErrFormat;
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        fclose_s ( fp );
    }
    _END
}


//void cmnErrorManager::mGetMessage ( char *aErrMsg )
//{
//    cmnErrorManager::mErrorGetMessage ( aErrMsg, mErrCode );
//}


int cmnErrorManager::mErrorGetFormat ( char* aFormat , int aUserErrorCode )
{
    std::map<int, std::string>::iterator sError;

    _TRY
    {
        /************************************************
         * 탐색 후 결과 리턴한다.
         ************************************************/
        sError = mErrMap->find ( aUserErrorCode );
        if ( sError == mErrMap->end ( ) )
        {
            aFormat[0] = 0x00;
            return RC_FAILURE;
        }

        memcpy_s ( aFormat, sError->second.c_str ( ), sError->second.length ( ) );
        /************************************************
         * 일단은 여기서 Null-terminating한다.
         ************************************************/
        aFormat[sError->second.length ( )] = 0x00;
    }
    _CATCH
    {
        _CATCH_PRT;
    }
    _FINALLY
    _END
}

__thread char* t_errmap_fmt = NULL;
void cmnErrorManager::mErrorGetMessage ( char* aErrMsg , int aUserErrorCode )
{
    if ( t_errmap_fmt == NULL )
    {
        t_errmap_fmt = (char*)malloc ( _cmn_sys_pagesize );
    }
    cmnErrorManager::mErrorGetFormat ( t_errmap_fmt, aUserErrorCode );

    // warning: format not a string literal, argument types not checked [-Wformat-nonliteral]
    sprintf ( aErrMsg, (const char*)t_errmap_fmt, aUserErrorCode );
}


/********************************************************************
 * Static Variable
 ********************************************************************/
__thread char* _cmn_errmsg = NULL;

/********************************************************************
 * C API Wapper Function
 ********************************************************************/
/**
 * @brief   cmnGetError
 *
 * @param aCode     [IN] error code
 * @param aMsg      [OUT] error string
 * @return          aMsg ( 사용편의를 위해 OUT 결과 문자열의 주소를 반환
 *
 * @note            오류코드 관련 처리를 한군데서 하므로, common 모듈이지만, dbmXX 접두어를 부여.
 */
char* cmnGetError ( int aCode, char* aMsg )
{
    _TRY
    {
        if ( aMsg == NULL )
        {
            if ( unlikely( _cmn_errmsg == NULL ) )
            {
                _cmn_errmsg = (char*) memalign_s ( _cmn_sys_pagesize );
            }

            aMsg = _cmn_errmsg;
        }

        cmnErrorManager::mErrorGetMessage ( aMsg, aCode );
        return aMsg;
    }
    _CATCH
    {
        _DASSERT( 0 );      // 도달할수없다.
    }
    _FINALLY
    _ENDNULL
}

/*
 * 기존 define 매크로에서 함수로 변경
 *      1. 오류를 gdb 로 추적시에 매크로는 break 가 안됨
 *      2. 오류 발생이므로 매크로를 사용할 정도로 성능 구간이 아님.
 *      3. 함수 Body가 짧아서 아마 inline 최적화 될거임.
 */
static void cmnCatchErrLib ( const char* file , const char* func , int line ,
                             int loglevel , int aRc , int aLine , const char* aData = NULL )
{

    if ( aData == NULL || aData[0] == 0x00 )
    {
        if ( aRc > DBM_ERROR_BASE )
        {
            cmnLogSend ( file, func, line, loglevel, "ERR-%d] %s (err=%d,tid=%d,l=%d)",
                         aRc, (char*)cmnGetError( aRc ) + sizeof("ERR-0000]"), errno, gettid_s( ), aLine );
        }
        else
        {
            cmnLogSend ( file, func, line, loglevel, "catch error rc=%d (err=%d,tid=%d,l=%d)",
                         aRc, errno, gettid_s( ), aLine );
        }
    }
    else
    {
        if ( aRc > DBM_ERROR_BASE )
        {
            cmnLogSend ( file, func, line, loglevel, "ERR-%d] %s (%s) (err=%d,tid=%d,l=%d)",
                         aRc, (char*)cmnGetError( aRc ) + sizeof("ERR-0000]"), aData, errno, gettid_s(), aLine );
        }
        else
        {
            cmnLogSend ( file, func, line, loglevel, "catch error rc=%d (%s) (err=%d,tid=%d,l=%d)",
                         aRc, aData, errno, gettid_s(), aLine );
        }
    }
}

void cmnCatchErr ( const char* file, const char* func, int line, int aRc, int aLine, const char* aData )
{
    cmnCatchErrLib ( file, func, line, LL_E, aRc, aLine, aData );
}

void cmnCatchWarn ( const char* file, const char* func, int line, int aRc, int aLine, const char* aData )
{
    cmnCatchErrLib ( file, func, line, LL_W, aRc, aLine, aData );
}

void cmnCatchInfo ( const char* file, const char* func, int line, int aRc, int aLine, const char* aData )
{
    cmnCatchErrLib ( file, func, line, LL_I, aRc, aLine, aData );
}

void cmnCatchDbg ( const char* file, const char* func, int line, int aRc, int aLine, const char* aData )
{
    cmnCatchErrLib ( file, func, line, LL_D, aRc, aLine, aData );
}

/*
 * 2014.09.30 -okt- 추가할려고 했는데. 기존에 인자를 가진 _CATCH_DBG2 매크로랑 이름이 충돌난다.
 */
//void cmnCatchDbg2( const char* file, const char* func, int line, int aRc, int aLine, const char* aData )
//{
//    cmnCatchErrLib ( file, func, line, LL_T, aRc, aLine, aData );
//}

void cmnCatchTrc ( const char* file, const char* func, int line, int aRc, int aLine, const char* aData )
{
    cmnCatchErrLib ( file, func, line, LL_T, aRc, aLine, aData );
}

void cmnCatchPrt ( const char* file, const char* func, int line, int aRc, int aLine, const char* aData )
{
    cmnCatchErrLib ( file, func, line, LF_PRT, aRc, aLine, aData );
}


