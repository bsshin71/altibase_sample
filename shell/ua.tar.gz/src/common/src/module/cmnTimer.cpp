/*
 * cmnTimer.cpp
 *
 *  Created on: Mar 9, 2014
 *      Author: paul
 */

#include "cmnHeader.h"
#include "cmnTimer.h"


////////////////////////////////////////////////////////////////////////////////
// class static 변수 초기화
////////////////////////////////////////////////////////////////////////////////
cmnTimerManager*    cmnTimerManager::instance = NULL;
cmnTimerManager*    cmnTimerManager::user_instance = NULL;
pthread_mutex_t     cmnTimerManager::m_TimerLock = PTHREAD_MUTEX_INITIALIZER;
cmnTimerSt*         cmnTimerManager::m_pTimerInfo = NULL;
int                 cmnTimerManager::m_nTimerIdMax = -1;
int                 cmnTimerManager::m_nTimeUnit_ms = 100;
cmnEvtQue*          cmnTimerManager::m_pTimerQue = NULL;


////////////////////////////////////////////////////////////////////////////////
// class body
////////////////////////////////////////////////////////////////////////////////
cmnTimerManager::cmnTimerManager ( )
{
    m_pTimerQue = new cmnEvtQue ( );
    m_pEvtQue = m_pTimerQue;            // 부모의 큐 핸들에 연결
}


// 초기화 함수
_VOID cmnTimerManager::init ( )
{
    _TRY
    {
        _ASSERT ( instance == NULL );

        instance = new cmnTimerManager ( );

        m_pTimerInfo = (cmnTimerSt*) malloc_s ( sizeof(cmnTimerSt) * CMN_TIMER_CNT_MAX );
        memset_s ( m_pTimerInfo, 0, sizeof(cmnTimerSt) * CMN_TIMER_CNT_MAX );

        _CALL( instance->create ( ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


//TODO: ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT vs ERR_CMN_TIMEOUT
_VOID cmnTimerManager::thread_main ( )
{
    static int      sChkCnt = 0;
    cmnMsgHandle*   pCmd = NULL;
    void*           pData = NULL;
    int             sRC;
    int             sInterval_us = 100 * 1000; // 100 ms
    cmnTime         start;
    cmnTime         end;
    double          diff;
    int             sRuntimePerInterval;
    int             sRemainInterval;

    _TRY
    {
        _CALL( sig_send ( ) );

        m_bRunning = 1;
        sRemainInterval = sInterval_us;
        while ( m_bRunning )
        {
            // 100 ms timer
            sRC = m_pTimerQue->sig_wait ( (void**) &pData, sRemainInterval );

            if ( sRC != 0 && sRC != ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT )
            {
                _THROW ( sRC );
            }

            // 1. 쓰레드 큐에 데이타가 NULL은 타이머 데이타를 의미
            // 2. 데이타가 있으면, timeout 이전에 CMD 등이 발생.
            if ( pData == NULL )
            {
                sChkCnt++;
                if ( sChkCnt < 10 )
                {
                    DBM_DBG ( "[TIMER] Wake-Up. rc=%d (err=%d,tid=%d)", sRC, errno, gettid_s() );
                }
                else
                {
                    DBM_TRC ( "[TIMER] Wake-Up. rc=%d (err=%d,tid=%d)", sRC, errno, gettid_s() );
                }

                if ( sRC == ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT && m_bRunning != 0 )
                {
                    cmnTimeGet( &start );

                    // 여기에 100ms 이상. 시간이 소요되면 간격이 밀려버린다.
                    onTimeout ();   // 타이머 발동함수
                    //_CALL_TM( onTimeout () );

                    cmnTimeGet( &end );
                    sRuntimePerInterval = cmnTimeDiff(start,end) / ( DBM_TIME_SCALE / DBM_USEC  );
                    if ( sRuntimePerInterval > sInterval_us - 1000 )
                    {
                        // 1000 us 이상은 쉬어준다. 타입이 밀리더라도.
                        sRemainInterval = 1000;
                    }
                    else
                    {
                        // 시간 보정
                        sRemainInterval = sInterval_us - sRuntimePerInterval;
                    }
                }
                continue;
            }

            pCmd = (cmnMsgHandle*)( (char*)pData - sizeof(cmnMsgHandle) );
            switch ( pCmd->mDataCode )
            {
                case DBM_CMD_START:
                    if ( m_bRunning != 1 )
                    {
                        (void)__sync_lock_test_and_set ( &m_bRunning, 1 );
                        _CALL ( sig_send () );
                    }
                    break;
                case DBM_CMD_STOP:
                    if ( m_bRunning != 0 )
                    {
                        (void)__sync_lock_test_and_set ( &m_bRunning, 0 );
                        _CALL ( sig_send () );
                    }
                    break;
                default:
#ifdef _DBM_USE_TRACE_CALLER
                    DBM_ERR ( "unknown msg code. (%d) [%s:%d]", pCmd->mDataCode, pCmd->mWhere.func, pCmd->mWhere.line );
#else
                    DBM_ERR ( "unknown msg code. (%d)", pCmd->mDataCode );
#endif
                    _DASSERT ( 0 );
                    break;
            }

            _CALL ( cmnMemFreeSlot ( (void**)&pData ) );
        } /* while ( m_bRunning ) */
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
} /* thread_main */


_VOID cmnTimerManager::onTimeout ( )
{
    int     i;
    cmnTimerSt* pInfo;

    _TRY
    {
        for ( i = 0; i < m_nTimerIdMax + 1; i++ )
        {
            pInfo = &m_pTimerInfo[i];
            if ( pInfo->m_nUse == 0 )
                continue;

            pInfo->m_nRemainTime -= m_nTimeUnit_ms ;
            if ( pInfo->m_nRemainTime > 0 )
                continue;

            _CALL ( cmnLockMutex ( &m_TimerLock ) );

            // 그 사이에 타이머가 해제될 수 있다.
            if ( pInfo->m_nUse == 0 )
            {
                _CALL ( cmnUnlockMutex ( &m_TimerLock ) );
                continue;
            }

            pInfo->m_nRemainTime = pInfo->m_nInterval;

            /**
             * 2014.12.14. -okt- timer 쓰레드 2가지 요건
             *  1) 정각타이머: 현재 처럼 timer 데몬쓰레드에서 직접 업무등록 함수를 호출하는 경우
             *  2) 지연타이머: 업무쓰레드에 콜백을 수행하라고 통지하는 경우. (미구현, 포기)
             */
            _rc = ( pInfo->m_cbFunc ) ( NULL );
            //_CALL_TM( ( pInfo->m_cbFunc ) ( NULL ) );
            _DASSERT ( _rc == 0 );                  // 업무 콜백호출 오류시 죽어야하나?

            _CALL ( cmnUnlockMutex ( &m_TimerLock ) );
        } // for
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


// 초기화 함수
_VOID cmnTimerManager::create ( )
{
    _TRY
    {
        _CALL( m_pTimerQue->init (  ) );

        _CALL( startThread () );

        _CALL( sendCmd ( DBM_CMD_START ) );

        // 2014.12.14. -okt- cmnTimerManager 여기를 풀면 깨어나질 못함. (미구현 코드임. cmnTimerManager 자체를 제거해도됨)
//#ifdef _DEBUG
//        _CALL( sig_wait ( 10 * 10 ) );
//#else
//        _CALL( sig_wait ( 10 ) );
//#endif
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


// 종료 함수
_VOID cmnTimerManager::destroy ( )
{
    _TRY
    {
        if ( instance != NULL )
        {
            _CALL( cmnTimerManager::instance->sendCmd ( DBM_CMD_STOP ) );
            _CALL( cmnTimerManager::instance->sig_wait ( 60 ) );

            _CALL( cmnTimerManager::instance->stopThread ( ) );
            _CALL( m_pTimerQue->destroy ( ) );

            _CALL( pthread_mutex_destroy ( &m_TimerLock ) );

            delete instance;
            instance = NULL;
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID cmnTimerManager::start ( )
{
    _TRY
    {
    	//TODO: [WIN64] cast from 'cmnTimerManager*' to 'long int' loses precision [-fpermissive]
        //__sync_lock_test_and_set ( (long*) &user_instance, (long) instance );
        __sync_lock_test_and_set ( (long long*) &user_instance, instance );

    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID cmnTimerManager::stop ( )
{
    _TRY
    {
        __sync_lock_test_and_set ( (long long*)&user_instance, (long long) NULL );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID cmnTimerManager::addTimer ( int msec , cmnCbFunc* cbFunc , int* pTimerId )
{
    int     ix;

    _TRY
    {
        _ASSERT ( cbFunc != NULL );
        _ASSERT ( msec >= 1 );

        _CALL ( cmnLockMutex ( &m_TimerLock ) );

        for ( ix = 0; ix< CMN_TIMER_CNT_MAX; ix ++ )
        {
            if ( m_pTimerInfo[ix].m_nUse == 0 )
                break;
        }

        if ( ix != CMN_TIMER_CNT_MAX )
        {
            *pTimerId = ix;
            if ( m_nTimerIdMax < ix )
                m_nTimerIdMax = ix;

            m_pTimerInfo[ix].m_nUse         = 1;
            m_pTimerInfo[ix].m_cbFunc       = cbFunc;
            m_pTimerInfo[ix].m_nInterval    = msec;
            m_pTimerInfo[ix].m_nRemainTime  = msec;
        }
        else
        {
            *pTimerId = -1;

            DBM_WARN ( "no empty timer slot" );
            _CALL ( cmnUnlockMutex ( &m_TimerLock ) );
            _THROW ( -1 );
        }

        _CALL ( cmnUnlockMutex ( &m_TimerLock ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID cmnTimerManager::delTimer ( int timerid )
{
    _TRY
    {
        if ( m_pTimerInfo[timerid].m_nUse == 1 )
        {
            DBM_WARN ( "not found target Timer[%d]", timerid );
            _RETURN;
        }

        _CALL ( cmnLockMutex ( &m_TimerLock ) );

        m_pTimerInfo[timerid].m_nUse = 0;
        m_pTimerInfo[timerid].m_cbFunc = NULL;
        m_pTimerInfo[timerid].m_nInterval = 0;
        m_pTimerInfo[timerid].m_nRemainTime = 0;

        _CALL ( cmnUnlockMutex ( &m_TimerLock ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


////////////////////////////////////////////////////////////////////////////////
// C TYPE Wrapper
////////////////////////////////////////////////////////////////////////////////

_VOID cmnTimerAdd ( int msec , cmnCbFunc* cbFunc , int* pTimerId )
{
    return cmnTimerManager::addTimer ( msec, cbFunc, pTimerId );
}

_VOID cmnTimerDel ( int timerid )
{
    return cmnTimerManager::delTimer ( timerid );
}

