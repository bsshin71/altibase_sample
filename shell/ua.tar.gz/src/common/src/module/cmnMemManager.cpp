/*
 * cmnMemManager.cpp
 *
 *  Created on: Mar 10, 2014
 *      Author: paul
 */

#include "cmnHeader.h"
#include "cmnMemManager.h"

#ifndef __linux__	//TODO: [OKT] 윈도포팅

#define mmap(...)              		(NULL)
#define mprotect(...)              	(-1)

#endif /* __linux__ */


#define CMN_MAGICVAL32          (85858585)      // 32bit magic value

////////////////////////////////////////////////////////////////////////////////
// class static 변수 초기화
////////////////////////////////////////////////////////////////////////////////

cmnMemManager* cmnMemManager::instance  = NULL;
int     cmnMemManager::bUseMemMgr       = 1;
int     cmnMemManager::mSlotMaxSize     = 4096;     // OS PageSize

int     cmnMemManager::mSlotCountMax    = 10240;    // 40M  (RES)
int     cmnMemManager::mSegmentCountMax = 4;        // 160M (VSZ)

////////////////////////////////////////////////////////////////////////////////
// class body
////////////////////////////////////////////////////////////////////////////////

cmnMemManager::cmnMemManager()
{
    mSlotMaxSize        = _cmn_sys_pagesize;   // 다시한번 OS memory pagesize를 설정한다.

    mLock               = -1;                   // Extend 시점에 모두 대기다.
    mFreeLock           = -1;                   // Free 를 줄세운다.
    mHead               = 0;                    //[BUGBUG] 신기한데 union 인데, 밑에 2개만 초기화해서는 다른 값이 보임

    mRemainSlotCount    = 0;
    mAllocatedSlotCount = 0;
    mSegmentCount       = 0;
    mSegmentSize        = 0;
    mStackAddress       = NULL;
    mStartAddress       = NULL;
}

// 싱글톤이어서 사실 호출되지 않는다
cmnMemManager::~cmnMemManager()
{
    mDestroy();
}

_VOID cmnMemManager::init ( )
{
    _TRY
    {
        if ( unlikely ( instance == NULL ) )
        {
            instance = new cmnMemManager ( );

            _CALL ( instance->mCreate() );
//          atexit ( (void (*)())mDestroy );                 // 굳이 해제할 필요없다. (로그쓰레드와 해제순서를 맞추기 어려움)
        }
    }
    _CATCH
    {
        _CATCH_ABRT;
    }
    _FINALLY
    _END
}

cmnMemManager* cmnMemManager::getInstance ( )
{
    _TRY
    {
        _CALL ( init() );
        return instance;
    }
    _CATCH
    _FINALLY
    _ENDNULL
}

// 2014.12.14. -okt- 사용자가 직접 크기,개수 옵션을 지정할 수 있게 확장. (나중에)
_VOID cmnMemManager::mCreate ()
{
    _TRY
    {
        // mprotect 사용시 page align 필요하다.
        mSegmentSize = ( (size_t)( ( mSlotMaxSize * mSlotCountMax  - 1 ) / _cmn_sys_pagesize ) + 1 ) * _cmn_sys_pagesize;

        // memory manager 가 사용할 주소 공간을 MAP_ANON 옵션으로 예약한다..
        mStartAddress = mmap ( NULL, mSegmentSize * mSegmentCountMax, PROT_NONE, MAP_PRIVATE | MAP_ANON, -1, 0 );
        _TEST_THROW ( mStartAddress != NULL, ERR_SYSCALL_MALLOC )

        // 스택을 제어할 주소영역을 최대크기로 할당한다.
        mStackAddress = (long long**)memalign_s ( sizeof(long long*) * mSlotCountMax * mSegmentCountMax );
        memset_s ( mStackAddress, 0, sizeof(long long*) * mSlotCountMax * mSegmentCountMax );

        // 초기 영역 생성
        _CALL ( mExtendSegment ( ) );
    }
    _CATCH
    {
        _CATCH_ABRT;
    }
    _FINALLY
    _END
}

_VOID cmnMemManager::mDestroy ()
{
    _TRY
    {
        if ( bUseMemMgr == 0 )
            _RETURN;

        delete instance; instance = NULL;
    }
    _CATCH
    _FINALLY
    _END
}

_VOID cmnMemManager::mExtendSegment ( )
{
    void*   pNewAddr = NULL;
    int     sSegmentCount;
    int     sOldPID;
    int     sRC;
    int     tid;
    int     i;
    static int fCnt = 0;


    fCnt++;
    _TRY
    {
        // 최대로 이미 확장된 상태
        _IF_THROW( mSegmentCount == mSegmentCountMax , ERR_SYSCALL_MALLOC );

        tid = gettid_s() ;
        sSegmentCount = mvpAtomicGet32( &mSegmentCount );

        while ( 1 )
        {
            sOldPID = mvpAtomicCas32 ( &mLock, tid, -1 );
            if( sOldPID  == -1 || sOldPID == tid )
            {
                break;          // 락 획득 성공.
            }

            if ( tkill_s ( sOldPID, 0 ) && errno == ESRCH )
            {
                sRC = mvpAtomicCas32 ( &mLock, tid, sOldPID );
                if ( sRC == sOldPID )
                {
                    break;      // 락 획득 성공.
                }
            }

            usleep( 100 );
        }

        if ( sSegmentCount != mvpAtomicGet32( &mSegmentCount ) )
        {
            // 이미 다른 놈이 늘려둔 상태이다. 성공.
            _RETURN;
        }

        // 새로 할당할 영역의 시작 주소를 구한다.
       pNewAddr = (char*)mStartAddress + ( mSegmentSize * mSegmentCount );

        // 메모리 영역을 실제로 할당한다.
        _CALL( mprotect ( pNewAddr, mSegmentSize, PROT_READ | PROT_WRITE ) );
        _ASSERT( pNewAddr != NULL );

        // 2014.12.14. -okt- 테스트만하면됨 - 직접기록 로그 함수 필요.
        //DBM_INFO_F ( "MemManager Extend Segment OK." );

        // buffer를 초기화한다.
        char*   pSlotAddr = (char*)pNewAddr;
        int     sStackPos = mSlotCountMax * mSegmentCount;
        for ( i = 0; i < mSlotCountMax; i++ )
        {
            // 제어스택에 주소만 넣어두고.
            mStackAddress[ sStackPos + i ] = (long long*)pSlotAddr;

            // Slot 초기화를 하고
            ((cmnMsgHandle*)pSlotAddr)->mMark = CMN_MAGICVAL32;
            ((cmnMsgHandle*)pSlotAddr)->mLock = -1;

            // 다음 block을 가리키게 한다.
            pSlotAddr = (char*)pSlotAddr + mSlotMaxSize;
        }

        mSegmentCount++;
        mvpAtomicAdd32 ( &mRemainSlotCount, mSlotCountMax );        // 사용가능 SLOT양을 늘린다.
        mvpAtomicAdd32 ( &mAllocatedSlotCount, mSlotCountMax );     // 사용가능 최대 SLOT양을 늘린다.

        if ( _cmn_log_echo != 0 && mSegmentCount > 1 )
        {
            // MemMgr 내부에서는 로그를 싱크로만 기록할수 있다.
            DBM_INFO_F ( "[MemMgr] Extend ok. No=%d, RemainCnt=%d, TotalCnt=%ld (err=%d,tid=%d)\n"
                    , mSegmentCount, mRemainSlotCount, mAllocatedSlotCount, errno, gettid_s() );
        }

        mvpAtomicCas32 ( &mLock, -1, tid );
    }
    _CATCH
    {
        _CATCH_PRT;
        _ASSERT(0);
    }
    _FINALLY
    {
        // 위에서 락을 잡고 나왔을지 모르므로 한번더 풀어준다.
        mvpAtomicCas32 ( &mLock, -1, tid );
    }
    _END
}

_VOID cmnMemManager::mAllocSlot ( void** ppRetSlot, size_t aSize )
{
    cmnMsgHandle*   pSlot = NULL;
    cmnMsgHandle*   pSlot2 = NULL;
    void*           pRet = NULL;
    long long       sHead;
    int             sSlotNo;
    int             sMyTid = gettid_s();

    _TRY
    {
        int retryCnt = 0;
        int loopCnt = 0;
        while ( 1 )
        {
            retryCnt++;
            loopCnt++;
            sHead   = mvpAtomicGet64( &mHead );     //<-- #423 무한루필 (1개쓰레드)

            if ( unlikely ( mLock != -1 ) )
            {
                // 누군가가 확장중이다. 충분히 쉬자.
                cmnUSleep ( 100 );
                continue;
            }

            if ( retryCnt > _cmn_sys_ncpu )
            {
                pthread_yield_s();
                retryCnt = 0;
            }

            // 확장이 필요한지 확인한다.
            if ( mRemainSlotCount <= 1 && mSegmentCount < mSegmentCountMax )
            {
                if ( mLock == -1 )                          // 안에서 방어하고 있지만. 여기서 중복으로.
                {
                    // empty 상태이다, 확장한다.
                    _CALL ( mExtendSegment ( ) );
                }

                // 확장이 마칠수도 있고, 다른 쓰레드가 반납했을수도 있다.
                pthread_yield_s();
                continue;
            }

            // 최대 확장이 된 상태이고 FULL 이 났다. Free가 돌때까지 쉬자.
            if ( unlikely ( sHead == mAllocatedSlotCount -1 ) )
            {
                if ( loopCnt % 1000 == 0 )
                {
                    DBM_WARN_F( "[MemMgr] no more free slot. sleep.. loop=%d (err=%d,tid=%d)", loopCnt, errno, gettid_s() );

                    // 2014.12.14. -okt- 업무가 대기하고 있는 상황이다. 리턴하고, Sync모드 로깅으로 변경해야한다.
                    //             이상하게 60초가 아니네.. 나중에.
                    // 60초동안 해결이 안되면 죽자.
                    if ( loopCnt > 1000 * 60 )
                    {
                        DBM_ERR_F( "[MemMgr] [FATAL] no more free slot. abort. loop=%d (err=%d,tid=%d)", loopCnt, errno, gettid_s() );
                        _DASSERT( 0 );
                    }
                }

                cmnUSleep ( 1000 );
                continue;
            }

            pSlot2 = (cmnMsgHandle*)mStackAddress[sHead];
            if ( pSlot2 == NULL )
            {
                // sHead 값은 증가/감소를 하는 값이다. 때문에 검사다시.
                pthread_yield_s();
                continue;
            }

            {
                int             sOldPID;

                sOldPID = mvpAtomicCas32 ( &pSlot2->mLock, sMyTid, -1 );
                if ( sOldPID == -1 || sOldPID == sMyTid )
                {
                    // 성공.
                }
                else
                {
                    if ( sOldPID == 0 || ( tkill_s ( sOldPID, 0 ) && errno == ESRCH ) )
                    {
                        // 죽은 놈이니 그냥 갈아치자.
                        mvpAtomicCas32 ( &pSlot2->mLock, sMyTid, sOldPID );
                    }
                    else
                    {
                        // 2014.12.14. -okt- 코드 실수로 보인다. 잘돌면 지워도됨.
                        if ( loopCnt > 10000 && loopCnt % 10000 == 0 )
                        {
                            // 여기에 진입했다면 이미 이상한거다.
                            DBM_WARN_F( "Trace Log 기록을 위한 메모리 할당 실패, LockTid=%d, loop=%d (err=%d,tid=%d)\n",
                                  pSlot2->mLock, loopCnt, errno, sMyTid );
                            if ( loopCnt > 10000 * 10 )
                            {
                                DBM_ERR_F( "Trace Log 기록을 위한 메모리 할당 실패, LockTid=%d, loop=%d (err=%d,tid=%d)\n",
                                      pSlot2->mLock, loopCnt, errno, sMyTid );
                                usleep( 1000 * 1000 );
#ifdef _DEBUG
                                assert ( 0 && "Trace Log 기록을 위한 메모리 할당 실패" );
                                _DASSERT( 0 );
#endif
                            }
                        }

                        pthread_yield_s();
                        continue;
                    }

                }

            }

            //--> 여기에 도달하면, pSlot2->mLock 에 대해 락을 획득한거다. 밑에서 재시작할떼는 락을 풀어야함.

            if ( sHead == mvpAtomicCas32 ( &mHead, sHead + 1, sHead ) )
            {
                if ( mStackAddress[sHead] == NULL )
                {
                    // 여기 진입했다는 것은 CAS가 실패하고 다른 쪽이 갱신을 했다는 의미이다. ( A - B - A )
                    pSlot2->mLock = -1;                         // [필수] 락해제.
                    continue;
                }

                pSlot = (cmnMsgHandle*)mStackAddress[sHead];
                _DASSERT ( pSlot != NULL );
                _DASSERT ( pSlot->mMark == CMN_MAGICVAL32 );

                // 성공
                mStackAddress[sHead] = NULL;                // 가저간 주소를 제어스택에서 빼준다.

                pSlot->mLock = sMyTid;                        // taskid 를 넣어서 락 획득 표시한다.

                pSlot->mDataSize = aSize;                   // 0이면 무제한, 체크 없다.
                mvpAtomicAdd32 ( &mRemainSlotCount, -1 );

                // 64Byte 헤더는 숨기고 전달한다. 업무는 데이타를 그냥쓰면 되고 헤더를 참조할때는 구조를 알고 있는 우리만 사용한다.
                pRet = (char*)pSlot + sizeof(cmnMsgHandle);

                _RETURN;
            }
            else
            {
                // 실패 언넘이 끼어들어따
                pSlot2->mLock = -1;                         // [필수] 락해제.
                continue;
            }
        } /* while */
    }
    _CATCH
    _FINALLY
    {
        *ppRetSlot = pRet;
    }
    _END
}

#define _ONLYONEFREE                                        // 2014.12.14. -okt- 현재는 로그관리자 한놈만 Free한다. 옥섭코드인데 세는 구멍이 하도 많아 땜방했음.
_VOID cmnMemManager::mFreeSlot ( void** ppAddr )
{
    cmnMsgHandle*   pSlot = NULL;
    long long       sHead;

    _TRY
    {
        if ( *ppAddr == NULL )
        {
            // ERR_DBM_DOUBLE_FREE_SLOT 를 반납할 수도 있다.
            // #define ERR_DBM_DOUBLE_FREE_SLOT                1119
            _THROW( 1119 );
        }

        pSlot = (cmnMsgHandle*) ( (char*)*ppAddr - sizeof(cmnMsgHandle) );

        // 사용자가 쌩뚱맞은 주소를 넘겨서 Free 할수 있다.
        if ( pSlot->mMark != CMN_MAGICVAL32 )
        {
            DBM_ERR_F( "[MemMgr] magic value mismatch. maybe this value is not my block address" );
            _DASSERT ( pSlot->mMark == CMN_MAGICVAL32 );
            _THROW( -1 );
        }

        int retryCnt = 0;
        while ( 1 )
        {
            mFreeLock = -1;
            //mFreeLock = gettid_s();
            sHead   = mvpAtomicGet64( &mHead );

            if ( mLock != -1 )
            {
                pthread_yield_s();
                continue;
            }

            // 여기서 순환을 시켜줘야한다. 정상적인 경우에는 스택이므로 결코 진입하지 않는다.
            if ( unlikely ( sHead == 0 ) )
            {
                assert ( 0 && "sHead == 0" );
                // 오류처리가 필요없다. 실패든 성공이든 무조건 처음부터이다.
                mvpAtomicCas64 ( &mHead, mAllocatedSlotCount - 1, sHead );
                continue;
            }

#ifndef _ONLYONEFREE
            if ( -1 != mvpAtomicCas32 ( &mFreeLock, gettid_s(), -1 ) )
            {
                continue;
            }
#endif

            if ( sHead == mvpAtomicCas32 ( &mHead, sHead - 1, sHead ) )
            {
                // 누군가가 alloc 중인데, 아직 주소 갱신전이다
                while ( mStackAddress[sHead-1] != NULL )
                {
                    pthread_yield_s();

                    // 2014.12.14. -okt- tkill 사용해서 비정상 종료 처리 추가 필요할지도..
                }

                mStackAddress[sHead-1] = (long long*)pSlot;          // 반환된 주소를 제어 스택에 넣어준다.
#ifndef _ONLYONEFREE
                mvpAtomicCas32 ( &mFreeLock, -1, gettid_s() ) ;
#endif
                pSlot->mLock = -1;                              // taskid 를 넣어서 락 획득 표시한다.
                mvpAtomicAdd32 ( &mRemainSlotCount, 1 );

                mFreeLock = -1;
                _RETURN;
            }
            else
            {
                // 실패 언넘이 끼어들어따
#ifndef _ONLYONEFREE
                mvpAtomicCas32 ( &mFreeLock, -1, gettid_s() ) ;
#endif
                continue;
            }
        } /* while */
    }
    _CATCH
    _FINALLY
    {
        if ( _rc != 1119 ) // ERR_DBM_DOUBLE_FREE_SLOT
        {
            // 사용자가 2번 해제 못하도록
            *ppAddr = NULL;
        }
    }
    _END
}
