/*
 * cmnEvtBase.cpp
 *
 *  Created on: Mar 9, 2014
 *      Author: paul
 */

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#include <pthread.h>            // pthread_setaffinity_np ( np = non-portable ) 함수를 사용하기 위해서. 다른 헤더보다 먼저 위치해야함. _GNU_SOURCE
#endif

#include "cmnHeader.h"
#include "cmnEvtBase.h"

////////////////////////////////////////////////////////////////////////////////
// class body
////////////////////////////////////////////////////////////////////////////////

// 초기화 함수
cmnEvtBase::cmnEvtBase ( )
{
    _TRY
    {
        m_tid = 0;
        m_bRunning = 0;
        m_pEvtQue = NULL;

        _CALL( pthread_mutex_init ( &m_mtx, NULL ) );
        _CALL( pthread_cond_init ( &m_cond, NULL ) );
    }
    _CATCH
    {
        _PRT( "common thread create fail. rc=%d (err=%d,line=%d)\n", _rc, errno, _line );
        _ASSERT( 0 );
    }
    _FINALLY
    //_ENDVOID
}

cmnEvtBase::~cmnEvtBase ()
{
    if ( m_tid != 0 )
    {
        pthread_cancel ( m_tid );
        pthread_join ( m_tid, NULL );
    }

    pthread_mutex_destroy ( &m_mtx );
    pthread_cond_destroy ( &m_cond );
}

void* cmnEvtBase::thread_routine ( void *arg )
{
    cmnEvtBase *pInfo = (cmnEvtBase*) arg;

    _TRY
    {
        mvpAtomicSet32 ( &pInfo->m_bRunning, 1 );
        _CALL( pInfo->thread_main ( ) );
        //정상종료
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
}

_VOID cmnEvtBase::startThread ( )
{
    int cpulist[1] = { 0 };

    _TRY
    {
        _CALL( pthread_create ( &m_tid, NULL, thread_routine, this ) );
//        _CALL( sig_wait ( 10 ) );

#if 0 //def _DEBUG
        // 2014.12.14. -okt- 커널버전 체크 추가해야함, 2.6.32-431 이상에서만 동작. /proc/self/comm 을 읽는 개념인데, 신규임.
        _rc = pthread_setname_np ( m_tid, "LogManager" );
        if ( _rc != 0 )
        {
            if ( _rc != ENOENT )
                _THROW( -1 );
        }
#endif

        // 2014.12.14. -okt- [성능] 0번 CPU에 Trace Log Thread를 배치.
        //                   2014/07/09 현웅님 vbox 오류발생.
#if 0 //def _DEBUG
        _rc = cmnSetCpuAffinity2 ( m_tid, cpulist, sizeof(cpulist) / sizeof(int) );
        if ( _rc != 0 )
        {
            _PRT( "cmnSetCpuAffinity error. but ignore. rc=%d, (err=%d,tid=%d)", _rc, errno, gettid_s() );
            _RETURN;        // 이코드가 없으면, 결국 오류가 리턴된다.
        }
#endif
    }
    _CATCH
    {
        if ( _rc != ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT )
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
}

_VOID cmnEvtBase::stopThread ()
{
    _TRY
    {
        if ( m_bRunning )
        {
            _rc = sendCmd ( DBM_CMD_STOP ) ;
            if ( _rc )
            {
                _PRT ( "error rc=%d (err=%d)\n", _rc, errno );
            }

            _rc =  sig_wait ( 60 );
            if ( _rc != 0 )
            {
                _PRT ( "thread stop timedout\n" );
                _rc = pthread_cancel ( m_tid );
                if ( _rc != 0 )
                {
                    _PRT ( "thread cancel error\n" );
                }
                pthread_join ( m_tid, NULL );
            }
        }

        m_tid = 0;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

//TODO: Google Performance Tools - TCmalloc (Thread-Caching memory allocation) - 쓰레드간 데이타 전달에선 별 의미 없을듯.
#ifdef _DBM_USE_TRACE_CALLER
    _VOID cmnEvtBase::sendCmd ( int cmd, const char* file, const char* func, int line )
#else
    _VOID cmnEvtBase::sendCmd ( int cmd )
#endif
{
    void*   pData = NULL;
    cmnMsgHandle* pCmd = NULL;

    _TRY
    {
        _CALL( cmnMemAllocSlot ( (void**)&pData, 100 ) );
        pCmd = (cmnMsgHandle*)( (char*)pData - sizeof(cmnMsgHandle) );

        pCmd->mDataCode = cmd;
#ifdef _DBM_USE_TRACE_CALLER
        pCmd->mWhere.file = file;
        pCmd->mWhere.func = func;
        pCmd->mWhere.line = line;
#endif

        _CALL( m_pEvtQue->push ( pData ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

_VOID cmnEvtBase::sig_send ()
{
    _TRY
    {
        _CALL( cmnLockMutex ( &m_mtx ) );
        _CALL( cmnCondSignal ( &m_cond ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        cmnUnlockMutex ( &m_mtx );
    }
    _END
}

_VOID cmnEvtBase::sig_wait ( int sec )
{
    _TRY
    {
        _CALL( cmnLockMutex ( &m_mtx ) );
        _CALL( cmnCondWait ( &m_cond, &m_mtx, sec * 1000000 ) );
    }
    _CATCH
    {
        if ( _rc != ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT )
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    {
        cmnUnlockMutex ( &m_mtx );
    }
    _END
}
