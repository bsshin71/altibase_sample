/*
 * cmnMonitor.cpp
 *
 *  Created on: Mar 12, 2014
 *      Author: paul
 */

/**
 *  2014.12.14. -okt- cmnMonitor 작업중 (미구현)
 *
 * (1) Functor 를 사용한 것은. 일단. 좀 빠르다는데 처음이니깐 경험상.
 *     여기에서는 굳이 필요가 없다. C로 가능한 것은 C로만 구현한다. 다시 바꿀예정..
 *
 * (참고) http://www.cprogramming.com/tutorial/functors-function-objects-in-c++.html
 *
 * (2) _percpu : [성능] 이런것도 있단다.. 일단 메모만.
 *
 */
#include "cmnMonitor.h"

////////////////////////////////////////////////////////////////////////////////
// class static 변수 초기화
////////////////////////////////////////////////////////////////////////////////
cmnMonitor  _dbm_monitor_functor;                    // Functor 전역변수
cmnMonitor* cmnMonitor::instance = NULL;

////////////////////////////////////////////////////////////////////////////////
// class body
////////////////////////////////////////////////////////////////////////////////

// 2014.12.14. -okt- src/goldilocks/src/dbmUserAPI/dbmPerf.cpp 의 모니터 구조체를 이용가능할지. (미구현, 포기)
_VOID cmnMonitor::operator( ) ( void* arg )
{
    _TRY
    {
        if ( arg != NULL )
        {
            _DASSERT(0);  // dummy for no-build-warning
        }

        if ( instance == NULL )
        {
            // 1. 여기서 초기화
            m_MonInfo = (void*)0x02;
        }

        // 2. 타이머로 주기적 호출됨.
        static int sCallCnt = 0;
        DBM_DBG ( "[cmnMonitor] timer callback Start (%d) (%p)", ++sCallCnt, m_MonInfo );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

////////////////////////////////////////////////////////////////////////////////
// C TYPE Wrapper
////////////////////////////////////////////////////////////////////////////////
_VOID _dbm_monitor_cb ( void* arg )
{
    return _dbm_monitor_functor ( arg );
}


#if 0

/**
 *
함수자
operator() 연산자를 중복하고 있는 클래스의 객체를 함수 객체( function object) 혹은 함수자(functor)라 합니다.
그래서 함수자는 함수처럼 사용할 수 있습니다.
아래는 간단한 세가지 함수류(함수, 함수 포인터, 함수자)를 사용한 예제 코드입니다.
 *
 */

int Plus ( int a , int b )
{
    return a + b;
}

struct CPlus
{
    int operator( ) ( int a , int b )
    {
        return a + b;
    }
};

CPlus oPlus;
//    result = oPlus ( 10, 20 ); // 3. 함수자로 호출


/*
 위 예제를 보면 함수, 함수 포인터, 함수자의 인터페이스는 모두 같다는 것을 알 수 있습니다.
함수자를 사용하면 아래와 같은 장점이 있습니다.

1. 컴파일 시에 함수자를 알고리즘의 인자로 전달할 수 있다.
2. 함수 호출을 인라인(inline)화해서 효율성을 향상시킬 수 있다.
3. 함수자의 정보를 캡슐화하여 지역화(locally)할 수 있다.
*/

#endif

