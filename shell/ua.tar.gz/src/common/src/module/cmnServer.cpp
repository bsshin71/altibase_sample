/*
 * cmnServer.cpp
 */

/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/
#include "cmnHeader.h"
#include "cmnServer.h"


////////////////////////////////////////////////////////////////////////////////
// 내부 함수: 자동으로 호출되며 사용자가 직접 호출할 수 없음.
////////////////////////////////////////////////////////////////////////////////

unsigned long long _cmn_sys_pagesize = 4096;
unsigned long long _cmn_sys_physmemsize = 0;
unsigned long long _cmn_sys_avphysmemsize = 0;

char            _cmn_cmd_name[32] = { 0, };
int             _cmn_sys_ncpu = 4;
int             _cmn_log_echo = 0;
int             _cmn_use_rtf = 0;               // 환경변수로 RTF테스트를 Enable ( ON시에 성능 이슈 )
int             _cmn_file_mode = DBM_FILE_MODE;
char*           _cmn_shm_prefix = NULL;

//cmnErrorInfo*   _cmn_errmap = NULL;
