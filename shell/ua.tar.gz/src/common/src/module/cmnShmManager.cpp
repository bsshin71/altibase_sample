/*
 * cmnShmManager.cpp
 */

#include "cmnShmManager.h"
#include "cmnHeader.h"


#if 1
#define CMN_SHM_REFCOUNT_INIT       1
#else
#define CMN_SHM_REFCOUNT_INIT       2               // Detach 발생하지 않게.
#endif

volatile int _cmn_signo = 0;
__thread int _cmn_signo_r = 0;
int _cmn_errno = 0;

////////////////////////////////////////////////////////////////////////////////
// class static 변수 초기화
////////////////////////////////////////////////////////////////////////////////
cmnShmManager* cmnShmManager::instance  = NULL;
std::map<std::string, cmnShmSt*> cmnShmManager::mShmKeyMap;

pthread_mutex_t cmnShmManager::m_mtx  = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  cmnShmManager::m_cond = PTHREAD_COND_INITIALIZER;

////////////////////////////////////////////////////////////////////////////////
// class body
////////////////////////////////////////////////////////////////////////////////
cmnShmManager::cmnShmManager()
{
    // getInstance 에서수행.
}

// 싱글톤이어서 사실 호출되지 않는다
cmnShmManager::~cmnShmManager()
{
    mDestroy();
}

cmnShmManager* cmnShmManager::getInstance ( )
{
    _TRY
    {
        _CALL ( mInit() );
        return instance;
    }
    _CATCH
    _FINALLY
    _ENDNULL
}

_VOID cmnShmManager::mInit ( )
{
    _TRY
    {
        if ( unlikely ( instance == NULL ) )
        {
            instance = new cmnShmManager ( );

            _CALL( pthread_mutex_init ( &m_mtx, NULL ) );
            _CALL( pthread_cond_init ( &m_cond, NULL ) );
//          atexit ( (void (*)())mDestroy );                 // 미사용
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID cmnShmManager::mDestroy ()
{
    _TRY
    {
        _CALL( pthread_mutex_destroy ( &m_mtx ) );
        _CALL( pthread_cond_destroy ( &m_cond ) );
    }
    _CATCH
    _FINALLY
    _END
}


/**
 * @brief posix shm을 생성한다.
 *        shm key 관리용 map에 할당된 주소를 등록한다.
 */
_VOID cmnShmManager::mCreate ( const char* aName, long long aSize, void** ppAddr, int aFlag )
{
    cmnShmSt*   pInfo = NULL;
    int         sLockF = 0;
    struct stat sStat;

    _TRY
    {
        _DASSERT( aName != NULL );

        if ( aFlag == 0 ) // mAttach에서 이미 락을 잡았다.
        {
#ifdef __linux__	//TODO: [OKT] 윈도포팅
            _DASSERT( m_mtx.__data.__owner != gettid_s() ); // [NP] LINUX Only
#endif /* __linux__ */
            _CALL ( cmnLockMutex ( &m_mtx ) );
            sLockF = 1;

            // 중복 생성하는 경우는 아래에서 오류가 날것이다.
            _CALL( cmnPShmCreate ( aName, aSize, ppAddr ) );
        }
        // aFlag == 1 이므로 mAttach에서 호출한거다.
        else
        {
            _DASSERT( ppAddr != NULL );
            _rc = cmnPShmAttach ( aName, aSize, ppAddr );
            if ( _rc != 0 )
            {
                // 없다. 생성한다.
                _CALL( cmnPShmCreate ( aName, aSize, ppAddr ) );
            }
        }

        if ( ppAddr != NULL )
        {
            _CALL( cmnPShmGetStat( aName, &sStat ) );

            pInfo = (cmnShmSt*) malloc_s( sizeof(cmnShmSt) );
            pInfo->mAddr = *ppAddr;
            pInfo->mSize = aSize;
            pInfo->mInode = sStat.st_ino;

            /*
             * 만일 VSZ 증가를 테스트 할려면.
             * 초기값을 2로 부여하는 Fake를 통하여, Detach에서, 건수만 조작되고, 동작하지 않게 한다.
             */
            pInfo->mRefCount = CMN_SHM_REFCOUNT_INIT;
            mShmKeyMap[aName] = pInfo;
        }
    }
    _CATCH
    {
        if ( _rc != ERR_CMN_SHM_DUP_ERROR )
            _CATCH_WARN2(aName);
    }
    _FINALLY
    {
        DBM_TRC( "[mShmCreateLib] rc=%d, name=%s, addr=%p", _rc, aName, ppAddr==NULL?NULL:*ppAddr );
        if ( sLockF == 1 )
            cmnUnlockMutex ( &m_mtx );
    }
    _END
} /* mCreate */


_VOID cmnShmManager::mDrop ( const char* aName )
{
    std::map<std::string, cmnShmSt*>::iterator iter;
    cmnShmSt*   pInfo = NULL;
    int         sLockF = 0;

    _TRY
    {
        _DASSERT( aName != NULL );

        _CALL ( cmnLockMutex ( &m_mtx ) );
        sLockF = 1;

        // mDetach를 수행한다.
        iter = mShmKeyMap.find (aName);
        if ( iter == mShmKeyMap.end() )
        {
            //_RETURN; // 없어도 물리적 drop은 해야함.
        }
        else
        {
            pInfo = (cmnShmSt*)(*iter).second;
            mDetach( &pInfo->mAddr, pInfo->mSize, 1 );
        }

        _CALL( cmnPShmDrop ( aName ) );
    }
    _CATCH
    {
        if ( _rc == ERR_CMN_SHM_UNLINK )
        {
            _CATCH_DBG2(aName);

        }
        else
        {
            _CATCH_ERR2(aName);
        }
    }
    _FINALLY
    {
        DBM_TRC( "[mPShmDropLib] rc=%d, name=%s", _rc, aName );
        if ( sLockF == 1 )
            cmnUnlockMutex ( &m_mtx );
    }
    _END
} /* mDrop */


_VOID cmnShmManager::mDetach ( void** ppAddr, long long aSize, int aFlag )
{
    std::map<std::string, cmnShmSt*>::iterator iter;
    cmnShmSt*   pInfo = NULL;
    char        sName[MAX_FILE_NAME_LENGTH] = { 0, };
    int         sCnt = 0;
    int         sLockF = 0;

    _TRY
    {
        if ( *ppAddr == NULL )
            _RETURN;

        if ( aFlag == 0 ) // mDrop에서 이미 락을 잡았다.
        {
#ifdef __linux__	//TODO: [OKT] 윈도포팅,
        	// cmnShmManager.cpp:220:29:
        	// error: request for member '__data' in 'cmnShmManager::m_mtx', which is of non-class type 'pthread_mutex_t {aka void*}'
            _DASSERT( m_mtx.__data.__owner != gettid_s() ); // [NP] LINUX Only
#endif /* __linux__ */
            _CALL ( cmnLockMutex ( &m_mtx ) );
            sLockF = 1;
        }

        for ( iter = mShmKeyMap.begin ( ); iter != mShmKeyMap.end ( ); iter++ )
        {
            if ( ((cmnShmSt*)((*iter).second))->mAddr == *ppAddr )
            {
                pInfo = (cmnShmSt*)(*iter).second;
                cmnStrCpy( sName, (*iter).first.c_str(), sizeof(sName) );
                break;
            }
        }

        if ( pInfo == NULL )
        {
            _RETURN;                // ( *aDic )->mCheck(); 문제됨
//            _THROW( -1 );
        }

        // 2014.10.22 -okt- #663 다른세션에서 사용중일 수 있으므로 drop table에서도 unmap하면 안된다.
        /*
         * TODO: 2014.10.22 -okt- #663 난제다.
         * 위의 주석처럼 고치면 될것으로 생각했는데. VSZ가 증가한다. 왜냐하면. 기존 SegMgr에서 VSZ 증가해결할때. 사상이
         * 1) 동일이름 주소에 대해서는 mmap을 중복해서 열지말자.
         * 2) 필요한 경우에 Attach를 하고 Detach는 하지 말자 ( 요게 문제됨 )
         * 였는데.. 기존에 문제가 없었던 것은. drop table 에서, 참조하고 있는 것 무시하고 깨끗이 날렸기 때문에 VSZ가 크게 늘지않았다. ㅠㅠ
         */
        if ( aFlag == 1 || pInfo->mRefCount == 1 )
        //if ( pInfo->mRefCount == 1 )
        {
            mShmKeyMap.erase( sName );

            // 1. 헤더크기만큼 붙이고 다시 붙이는 경우.
            // 2. mRefCount 초기값을 2로 부여하면 '1' 이외에는 없음.
            _CALL( cmnPShmDetach ( ppAddr, aSize ) );
        }
        else
        {
            pInfo->mRefCount--;
        }
    }
    _CATCH
    _FINALLY
    {
        DBM_TRC( "--> (detach) rc=%d, ref=%d, addr=%p, sz=%d (%s)",
                  _rc, pInfo==0?0:pInfo->mRefCount, *ppAddr, aSize, sName );
        if ( sLockF == 1 )
            cmnUnlockMutex ( &m_mtx );
    }
    _END
} /* mDetach */


/*
 * 2014.12.14. -okt- (성능) 서칭을 할때, 앞부분이 같아서.. 성능저하가 있을 것 같음.
 *
(gdb) p cmnShmManager::mShmKeyMap
$1 = std::map with 27 elements = {
  ["/paul/$idx_sys_column_0_000"] = 0x7f6e64009e80,
..
  ["/paul/demo/demo_000"] = 0x7f6e6400a1a0,
  ["/paul/demo/ix_t1_000"] = 0x7f6e64096390,
  ["/paul/demo/t1_000"] = 0x7f6e64094e50,
  ["/paul/demo2/demo2_000"] = 0x7f6e6400f450,
  ["/paul/demo2/ix_t1_000"] = 0x7f6e64033e60,
  ["/paul/demo2/t1_000"] = 0x7f6e64071ac0
}
 *
 */
_VOID cmnShmManager::mAttach ( const char* aName, long long aSize, void** ppAddr )
{
    std::map<std::string, cmnShmSt*>::iterator iter;
    cmnShmSt*   pInfo = NULL;
    int         sLockF = 0;
    int         sRefCountPre = -1;      // 작은사이즈를 해제하고 다시 붙이는 경우.
    long long     sSize;
    struct stat sStat;

    _TRY
    {
        _DASSERT( aName != NULL );

        int sRetryCnt = 0;

retry:
        _CALL ( cmnLockMutex ( &m_mtx ) );
        sLockF = 1;

        sSize = aSize;

        iter = mShmKeyMap.find (aName);
        if ( iter == mShmKeyMap.end() )
        {
retry2:
            _rc = cmnPShmGetStat( aName, &sStat );
            if ( _rc == 0 )
            {
                if ( sSize > sStat.st_size )
                {
                    _DASSERT( 0 );
                }
                else
                {
                    sSize = sStat.st_size;  // 작은 사이즈가 와도 무조건 크게 붙인다.
                }
            }
            else
            {
                sRetryCnt++;
                if ( sRetryCnt < _cmn_sys_ncpu * 2 )
                {
                    /*
                     * 2014.12.14. -okt- 2014/07/06, 락 잡는 구간이 매우길고 stl 에서 mvcc12가 죽는 경우가 있다.
                     *             어짜피 동일하므로 retry에서 락을 다시 잡지 않는 식으로 .. 바꾸고 빈도를 본다.
                     */
                    pthread_yield_s();
                    //goto retry;
                    goto retry2;
                }
                else
                {
                    _THROW( ERR_CMN_SHM_OPEN );
                }
            }

            _CALL( cmnPShmAttach ( aName, sSize, ppAddr ) );

            // 성공했다는 것은 다른 프로세스가 만들어 두었다는 의미임.
            pInfo = (cmnShmSt*) malloc_s( sizeof(cmnShmSt) );
            pInfo->mAddr = *ppAddr;
            pInfo->mSize = sSize;
            pInfo->mInode = sStat.st_ino;

            if ( sRefCountPre != -1 )
            {
                pInfo->mRefCount = CMN_SHM_REFCOUNT_INIT;
            }
            else
            {
#ifdef _DEBUG
                // 2014.10.22 -okt- 디버그 추적시 /paul/$sys_xx를 걸러내기위한 하드코딩
                if ( aName[sizeof( "/paul/" )] == 't' )
                //if ( aName[ sizeof("/paul/") ] != '$' )
                {
                    pInfo->mRefCount = sRefCountPre + 1;
                }
                else
#endif
                {
                    pInfo->mRefCount = sRefCountPre + 1;
                }
            }

            mShmKeyMap[aName] = pInfo;
        }
        else
        {
            pInfo = (cmnShmSt*)(*iter).second;

            bool bInodeChangedF;
            _rc = cmnPShmGetStat( aName, &sStat );
            if ( _rc == 0 )
            {
                bInodeChangedF = ( pInfo->mInode != sStat.st_ino );
            }
            else
            {
                // 2014.12.14. -okt- 여기에 진입한것은 다른 누군가가 drop 하고 다시 만들고 있는 중이다. 혹은 drop 했다.
                // 오류처리를 해도 되겠지만. truncate 동시 테스트에서 안된다. 그래서 최대한 기존 동작과 동일하게 한다.
                bInodeChangedF = false;
            }

            // 처음에 작게 붙여서, 헤더만 확인하고, 사이즈를 얻어서 크게 붙이는 경우가 있다.
            // truncate 처럼 재생성되는 경우는 inode 체크 필요
            if ( pInfo->mSize < sSize || bInodeChangedF )
            {
                sRefCountPre = pInfo->mRefCount;
                _CALL( mDetach (  &pInfo->mAddr, pInfo->mSize, 1 ) );

                if ( sLockF == 1 )
                    cmnUnlockMutex ( &m_mtx );
                goto retry;
            }

            *ppAddr = pInfo->mAddr;
#ifdef _DEBUG
            // 2014.10.22 -okt- 디버그 추적시 /paul/$sys_xx를 걸러내기위한 하드코딩
            if ( aName[ sizeof("/paul/") ] == 't' )
            //if ( aName[ sizeof("/paul/") ] != '$' )
            {
                pInfo->mRefCount++;
            }
            else
#endif
            {
                pInfo->mRefCount++;
            }
        }
    }
    _CATCH
    {
        _CATCH_DBG2( aName );
    }
    _FINALLY
    {
        DBM_TRC( "<-- (attach) rc=%d, ref=%d, addr=%p, sz=%d (%s)",
                  _rc, pInfo==0?0:pInfo->mRefCount, *ppAddr, sSize, aName );
        if ( sLockF == 1 )
            cmnUnlockMutex ( &m_mtx );
    }
    _END
} /* mAttach */


////////////////////////////////////////////////////////////////////////////////
// C TYPE Wrapper
////////////////////////////////////////////////////////////////////////////////
_VOID cmnShmCreate_s ( const char* aName, long long aSize, void** ppAddr )
{
    return cmnShmManager::mCreate( aName, aSize, ppAddr );
}

_VOID cmnShmDrop_s ( const char* aName )
{
    return cmnShmManager::mDrop( aName );
}

_VOID cmnShmDetach_s ( void** ppAddr, long long aSize )
{
    return cmnShmManager::mDetach( ppAddr, aSize );
}

_VOID cmnShmAttach_s ( const char* aName, long long aSize, void** aAddr )
{
    return cmnShmManager::mAttach( aName, aSize, aAddr );
}
