/*
 * cmnEvtQue.cpp
 *
 *  Created on: Mar 10, 2014
 *      Author: paul
 */

#include "cmnHeader.h"
#include "cmnEvtQue.h"


////////////////////////////////////////////////////////////////////////////////
// class body
////////////////////////////////////////////////////////////////////////////////

cmnEvtQue::cmnEvtQue ( )
{
    m_nSize = 0;
}

cmnEvtQue::~cmnEvtQue ()
{
}

_VOID cmnEvtQue::init ( )
{
    _TRY
    {
        _CALL( pthread_mutex_init ( &m_mtx, NULL ) );
        _CALL( pthread_cond_init ( &m_cond, NULL ) );
    }
    _CATCH
    {
        _CATCH_WARN2( "pthread_mutext error" );
    }
    _FINALLY
    _END
}

_VOID cmnEvtQue::destroy()
{
    _TRY
    {
        _CALL( pthread_mutex_destroy ( &m_mtx ) );
        _CALL( pthread_cond_destroy ( &m_cond ) );
    }
    _CATCH
    _FINALLY
    _END
}

_VOID cmnEvtQue::clear ()
{
    _TRY
    {
        _CALL ( cmnLockMutex ( &m_mtx ) );
        while ( !m_queue.empty ( ) )
        {
            m_queue.pop ( );
        }
        _CALL ( cmnUnlockMutex ( &m_mtx ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

_VOID cmnEvtQue::pushLib ( const void* pMsg, int flag )
{
    _TRY
    {
        _CALL ( cmnLockMutex (&m_mtx) );

        if ( flag == 0 )
            m_queue.push ( (void*) pMsg );
        else
            m_queue.push ( (void*) pMsg );        //TODO: 맨앞에 넣어야 하는데. 미구현

        m_nSize = m_queue.size ( );

        _CALL ( cmnCondSignal ( &m_cond ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        cmnUnlockMutex ( &m_mtx );
    }
    _END
}

_VOID cmnEvtQue::push ( const void* pMsg )
{
    return pushLib ( pMsg, 0 );
}

_VOID cmnEvtQue::push_front ( const void* pMsg )
{
    return pushLib ( pMsg, 1 );
}

_VOID cmnEvtQue::pop(void** ppOut)
{
    void* pData = NULL;
    _TRY
    {
        _CALL ( cmnLockMutex (&m_mtx) );

        if ( m_queue.size ( ) )
        {
            pData = m_queue.front ( );
            m_queue.pop ( );
        }
        else
            pData = NULL;
        m_nSize = m_queue.size ( );

        _CALL ( cmnUnlockMutex ( &m_mtx ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        *ppOut = pData;
    }
    _END
}

_VOID cmnEvtQue::sig_wait ( void** ppOut , int usec )
{
    int     sRC;
    void*   pData = NULL;

    _TRY
    {
        _CALL ( cmnLockMutex ( &m_mtx ) );

        // 시그널이 이미 지나갔을수 있다. 대기가 필요할때만 대기한다.
        if ( m_queue.size ( ) == 0 )
        {
            sRC = cmnCondWait ( &m_cond, &m_mtx, usec );
            if ( usec != 0 && sRC == ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT )
            {
                _THROW ( ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT );
            }
        }

        pData = m_queue.front ( );
        m_queue.pop ( );
        m_nSize = m_queue.size ( );
    }
    _CATCH
    {
        if ( _rc != ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    {
        *ppOut = pData;
        cmnUnlockMutex ( &m_mtx );
    }
    _END
}

#ifdef _DBM_USE_TRACE_CALLER
_VOID cmnEvtQue::sig_send ( const char* file, const char* func, int line )
#else
_VOID cmnEvtQue::sig_send ()
#endif
{
    _TRY
    {
        _CALL ( cmnLockMutex ( &m_mtx ) );

#ifdef _DBM_USE_TRACE_CALLER
        _PRT ( ">> [%s:%s:%d] sig_send (%d)", file, func, line, ++fCnt );
#endif
        _CALL ( cmnCondSignal ( &m_cond ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        cmnUnlockMutex ( &m_mtx );
    }
    _END
}


