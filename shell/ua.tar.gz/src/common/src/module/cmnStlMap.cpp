/*
 * cmnStlMap.cpp
 */

#include "cmnStlMap.h"
#include "cmnHeader.h"

#include <string>
#include <map>

#define CMN_MAP_MAX         (1000000)                       // SLOTID 중복체크를 할때, 100만 이상 범위는 체크불가.

cmnStlMap::cmnStlMap ( )
{
    mType = 1;              // std::map<std::string, void*>
    mMap = NULL;
    mSub = NULL;

    mInit();
}

cmnStlMap::cmnStlMap ( int aType )
{
    mType = aType;
    mMap = NULL;
    mSub = NULL;

    mInit();
}

cmnStlMap::~cmnStlMap()
{
    mDestroy();
}

_VOID cmnStlMap::mInit()
{
    _TRY
    {
        mLockF = 0;
        _CALL( pthread_mutex_init ( &m_mtx, NULL ) );
//      _CALL( pthread_cond_init ( &m_cond, NULL ) );

        if ( mType == 100 )
        {
            mMap = new std::map<std::string, void*>;
        }
        else if ( mType == 1 )
        {
            mMap = new std::map<std::string, void*>;
        }
        else if ( mType == 20 )
        {
            mMap = malloc( 64 * CMN_MAP_MAX );
            memset_s ( mMap, 0x00, 64 * CMN_MAP_MAX );
        }
        else if ( mType == 2 )
        {
            mMap = new std::map<long long, std::string>;
        }
        else
        {
            _ASSERT( 0 );
        }

        _DASSERT( mMap != NULL );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

_VOID cmnStlMap::mDestroy ()
{
    _TRY
    {
        _CALL ( cmnLockMutex ( &m_mtx ) );
        // 락을 잡은 상태에서 pthread_mutex_destroy 호출하면 EBUSY 발생.
        mLockF = -1;
        _CALL ( cmnUnlockMutex ( &m_mtx ) );

        if ( mType == 100 )
        {
            mMap100->clear ( );
        }
        else if ( mType == 1 )
        {
            mMap1->clear ( );
        }
        else if ( mType == 20 )
        {
            delete_s( mMap20 );
        }
        else if ( mType == 2 )
        {
            mMap2->clear ( );
        }
        else
        {
            _ASSERT( 0 );
        }

        _CALL( pthread_mutex_destroy ( &m_mtx ) );
//      _CALL( pthread_cond_destroy ( &m_cond ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

_VOID cmnStlMap::mInsert ( void* aKey, void* aVal )
{
    _TRY
    {
        _TEST_THROW( aKey != NULL, -1 );
        _CALL ( mLock ( ) );

        if ( mType == 1 )
        {
            (*mMap1)[(char*)aKey] = aVal;
        }
        else if ( mType == 20 )
        {
            int ix = (int)*(long long*)aKey;
            if ( ix >= CMN_MAP_MAX )
            {
                _RETURN;
            }
            cmnStrCpy( ( mMap20 + 64 * ix ), (char*)aVal, 64 );
        }
        else if ( mType == 2 )
        {
            (*mMap2)[*(long long*)aKey] = std::string( (char*)aVal );
        }
        else
        {
            _ASSERT( 0 );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        mUnlock ( );
    }
    _END
}

_VOID cmnStlMap::mInsert ( void* aGrp, void* aKey, void* aVal )
{
    _TRY
    {
        _TEST_THROW( aKey != NULL, -1 );
        _CALL ( mLock ( ) );

        if ( mType == 100 )
        {
            std::map<std::string, void*>::iterator iter;

            iter = mMap100->find ( (char*)aGrp );
            if ( iter == mMap100->end() )
            {
                cmnStlMap* sSubMap = new cmnStlMap( 20 );
                _CALL( sSubMap->mInsert( aKey, aVal ) );
                (*mMap100)[(char*)aGrp] = sSubMap;
            }
            else
            {
                _CALL( ((cmnStlMap*)(*iter).second)->mInsert( aKey, aVal ) );
            }
        }
        else
        {
            _ASSERT( 0 );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        mUnlock ( );
    }
    _END
}

_VOID cmnStlMap::mErase ( void* aKey )
{
    _TRY
    {
        _TEST_THROW( aKey != NULL, -1 );
        _CALL ( mLock ( ) );

        if ( mType == 1 )
        {
            mMap1->erase( (char*)aKey );
        }
        else if ( mType == 20 )
        {
            int ix = (int)*(long long*)aKey;
            if ( ix >= CMN_MAP_MAX )
            {
                _RETURN;
            }
//            ( mMap20 + 64 * ix )[0] = 0x00;
            ( mMap20 + 64 * ix )[0] = 'X';
        }
        else if ( mType == 2 )
        {
            mMap2->erase( *(long long*)aKey );
        }
        else
        {
            _ASSERT( 0 );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        mUnlock ( );
    }
    _END
}


_VOID cmnStlMap::mErase ( void* aGrp, void* aKey )
{
    _TRY
    {
        _TEST_THROW( aKey != NULL, -1 );
        _CALL ( mLock ( ) );

        if ( mType == 100 )
        {
            std::map<std::string, void*>::iterator iter;

            iter = mMap100->find ( (char*)aGrp );
            if ( iter == mMap100->end() )
            {
                // do nothing
            }
            else
            {
                _CALL( ((cmnStlMap*)(*iter).second)->mErase( aKey ) );
                // 상위단 aGrp의 경우는 한번 등록되면 삭제하지 않는다.
            }
        }
        else
        {
            _ASSERT( 0 );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        mUnlock ( );
    }
    _END
}

_VOID cmnStlMap::mClear ( )
{
    _TRY
    {
        _CALL ( mLock ( ) );

        if ( mType == 100 )
        {
            std::map <std::string, void*>::iterator iter;
            for ( iter = mMap100->begin ( ); iter != mMap100->end ( ); iter++ )
            {
                ((cmnStlMap*)(*iter).second)->mClear();
            }

            mMap100->clear ( );
        }
        else if ( mType == 1 )
        {
            mMap1->clear ( );
        }
        else if ( mType == 20 )
        {
            int ix;
            for ( ix = 0; ix < CMN_MAP_MAX; ix++ )
            {
                ( mMap20 + 64 * ix )[0] = 0x00;
            }
        }
        else if ( mType == 2 )
        {
            mMap2->clear ( );
        }
        else
        {
            _ASSERT( 0 );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        mUnlock ( );
    }
    _END
}

int cmnStlMap::mSize ( )
{
    int         sRet = -1;

    _TRY
    {
        _CALL ( mLock ( ) );

        if ( mType == 100 )
        {
            // 하위단의 개수의 합이 아니다.
            sRet = mMap100->size();
        }
        else if ( mType == 1 )
        {
            sRet = mMap1->size();
        }
        else if ( mType == 20 )
        {
            int ix;
            sRet = 0;
            for ( ix = 0; ix < CMN_MAP_MAX; ix++ )
            {
                if ( ( mMap20 + 64 * ix )[0] != 0x00 )
                {
                    sRet++;
                }
            }
        }
        else if ( mType == 2 )
        {
            sRet = mMap2->size();
        }
        else
        {
            _ASSERT( 0 );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        mUnlock ( );
    }
    return sRet;
}


void* cmnStlMap::mFind ( void* aKey, void** ppVal )
{
    void*       sRet = NULL;

    _TRY
    {
        _TEST_THROW( aKey != NULL, -1 );
        _CALL ( mLock ( ) );

        if ( mType == 1 )
        {
            std::map<std::string, void*>::iterator iter;

            iter = mMap1->find ( (char*)aKey );
            if ( iter == mMap1->end() )
            {
                sRet = NULL;
                if ( ppVal != NULL )
                    *ppVal = sRet;

                _RETURN;                // NOT FOUND 도 성공
            }

            sRet = (*iter).second;
            if ( ppVal != NULL )
                *ppVal = sRet;
        }
        else if ( mType == 20 )
        {
            int ix = (int)*(long long*)aKey ;
            if ( ix >= CMN_MAP_MAX )
            {
                _RETURN;
            }

            if ( ( mMap20 + 64 * ix )[0] == 0x00 || ( mMap20 + 64 * ix )[0] == 'X' )
            {
                sRet = NULL;
                if ( ppVal != NULL )
                    *ppVal = sRet;

                _RETURN;                // NOT FOUND 도 성공
            }

            sRet = (void*)( mMap20 + 64 * ix );
            if ( ppVal != NULL )
                *ppVal = sRet;
        }
        else if ( mType == 20 )
        {
            std::map<long long, std::string>::iterator iter;

            iter = mMap2->find ( *(long long*)aKey );
            if ( iter == mMap2->end() )
            {
                sRet = NULL;
                if ( ppVal != NULL )
                    *ppVal = sRet;

                _RETURN;                // NOT FOUND 도 성공
            }

            sRet = (void*)(*iter).second.c_str();
            if ( ppVal != NULL )
                *ppVal = sRet;
        }
        else
        {
            _ASSERT( 0 );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        mUnlock ( );
    }
    return sRet;
} /* mFind */

void* cmnStlMap::mFind ( void* aGrp, void* aKey, void** ppVal )
{
    void*       sRet = NULL;

    _TRY
    {
        _TEST_THROW( aKey != NULL, -1 );
        _CALL ( mLock ( ) );

        if ( mType == 100 )
        {
            std::map<std::string, void*>::iterator iter;

            iter = mMap100->find ( (char*)aGrp );
            if ( iter == mMap100->end() )
            {
                sRet = NULL;
                if ( ppVal != NULL )
                    *ppVal = sRet;

                _RETURN;                // NOT FOUND 도 성공
            }
            else
            {
                sRet = ((cmnStlMap*)(*iter).second)->mFind( aKey, ppVal );
            }
        }
        else
        {
            _ASSERT( 0 );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        mUnlock ( );
    }
    return sRet;
} /* mFind */


//_VOID cmnStlMap::mPrint ( int aKey )
_VOID cmnStlMap::mPrint ( )
{
    _TRY
    {
//        _CALL ( mLock ( ) );
        DBM_ECHO( "## MAP INFO (%p,%d) ##\n", this, gettid_s() );

        if ( mType == 100 )
        {
            std::map <std::string, void*>::iterator iter;
            for ( iter = mMap100->begin ( ); iter != mMap100->end ( ); iter++ )
            {
                DBM_DBG( "## %s\n", (*iter).first.c_str() );
                ((cmnStlMap*)(*iter).second)->mPrint();
            }

        }
//        else if ( mType == 1 )
//        {
//            mMap1->clear ( );
//        }
        else if ( mType == 20 )
        {
            int ix;
            int cnt = 0;
            for ( ix = 0; ix < CMN_MAP_MAX; ix++ )
            {
                if ( ( mMap20 + 64 * ix )[0] != 0x00 )
                {
//                    if ( aKey < 0 )
                    {
                        DBM_DBG( "%8d = %s\n", ix, ( mMap20 + 64 * ix ) );
                        cnt++;
                    }
//                    else
//                    {
//                        if ( ix > aKey - 100 && ix < aKey + 100 )
//                        {
//                            _PRT( "%8d = %s\n", ix, ( mMap20 + 64 * ix ) );
//                            cnt++;
//                        }
//                    }
                }
            }
            DBM_ECHO( "## total = %d\n", cnt );
        }
//        else if ( mType == 2 )
//        {
//            mMap2->clear ( );
//        }
        else
        {
            _ASSERT( 0 );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
//        mUnlock ( );
    }
    _END
}


/*
 * iter.begin() ~ end() 형태로 접근하는 용도를 위해 외부 노출
 */
_VOID cmnStlMap::mLock ( )
{
    _TRY
    {
        if ( mLockF == -1 )
        {
            DBM_ERR( "[FATAL] mutex already destroyed" );
            _DASSERT( 0 );
        }

        _CALL ( cmnLockMutex ( &m_mtx ) );
        mLockF = 1;
    }
    _CATCH
    _FINALLY
    _END
}

_VOID cmnStlMap::mUnlock ( )
{
    _TRY
    {
        if ( mLockF == 1 )
        {
            mLockF = 0;
            _CALL ( cmnUnlockMutex ( &m_mtx ) );
        }
    }
    _CATCH
    _FINALLY
    _END
}

