/*
 * cmnLogManager.cpp
 *
 *  Created on: Mar 4, 2014
 *      Author: paul
 */

/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/
#include "cmnHeader.h"
#include "cmnLogManager.h"

////////////////////////////////////////////////////////////////////////////////
// 전역 변수
////////////////////////////////////////////////////////////////////////////////

unsigned long long _dbm_nLogCnt = 0;
unsigned long long _dbm_nLogCntErr = 0;
unsigned long long _dbm_nLogCntWarn = 0;

////////////////////////////////////////////////////////////////////////////////
// class static 변수 초기화
////////////////////////////////////////////////////////////////////////////////

cmnLogManager* cmnLogManager::instance = NULL;
cmnLogManager* cmnLogManager::user_instance = NULL;

#ifdef _DEBUG
int             cmnLogManager::m_nLogLevel = LL_5;      // LOGLEVEL_5 ( DEBUG까지 )
#else
int             cmnLogManager::m_nLogLevel = LL_2;      // LOGLEVEL_2 ( WARN까지 )
#endif

int             cmnLogManager::m_nLogPidType = 0;
int             cmnLogManager::m_nLogSyncFlag = 1;      // 디폴트변경, fork를 사용하는 경우 대응안된다. 2014/09/10
FILE*           cmnLogManager::m_ulog = NULL;
FILE*           cmnLogManager::m_slog = NULL;
int             cmnLogManager::m_ulogFd = -1;
int             cmnLogManager::m_slogFd = -1;

char            cmnLogManager::m_ulog_file [DBM_FILE_NAME_LEN] = { 0, };
char            cmnLogManager::m_slog_file [DBM_FILE_NAME_LEN] = { 0, };

char            cmnLogManager::service_name [DBM_SERVICE_NAME_LEN] = { 0, };
mvp_pid_t       cmnLogManager::m_nProcessId = 0;
char            cmnLogManager::m_zProcessId [5 + 1] = { 0, };
char            cmnLogManager::m_zHostName [DBM_HOST_NAME_LEN] = { 0, };

int             cmnLogManager::m_nLogMaxSize = DBM_MAX_LOG_LEN;
int             cmnLogManager::m_nLogHeaderSize = -1;           // 계산으로 얻어진다. (62)
int             cmnLogManager::m_nLogHeaderPidOffset = 19;

__thread char*  g_cmn_log_buf = NULL;

////////////////////////////////////////////////////////////////////////////////
// class body
////////////////////////////////////////////////////////////////////////////////

cmnLogManager::cmnLogManager ( )
{
    char*   pChar = NULL;

    _TRY
    {
        pChar = getenv ( ENV_DBM_TRCLOG_ASYNC_ENABLE );
        if ( pChar != NULL )
        {
            if ( atoi( pChar ) != 0 )
            {
                m_nLogSyncFlag = 0;
            }
        }

        pChar = getenv ( ENV_DBM_TRCLOG_PID_TYPE );
        if ( pChar != NULL )
        {
            m_nLogPidType = atoi ( pChar );
        }

        m_nProcessId = getpid_s ();
        _DASSERT ( m_nProcessId < 100000 );

        snprintf ( m_zProcessId, sizeof(m_zProcessId), "%05d", m_nProcessId );

        //TODO: [WIN64] -lwsock32
        //      undefined reference to `__imp_gethostname'
        {
        	char    zTmp[128] = "Windows";
        	int     sRC;

        	//TODO: [OKT] 윈도포팅. gethostname이 -1 이 리턴되고 errno 설정되지 않는다.
            //_CALL( gethostname ( zTmp, sizeof(zTmp) ) );
            sRC = gethostname ( zTmp, sizeof(zTmp) );

            cmnStrCpy ( m_zHostName, zTmp, sizeof(m_zHostName) );
        }

        // 부모 이벤트큐에 로그큐를 연결한다.
        m_pEvtQue = &m_LogQue;
    }
    _CATCH
    {
        _CATCH_PRT;
        _ASSERT ( 0 );
    }
    _FINALLY
}

cmnLogManager::~cmnLogManager ( )
{
}

_VOID cmnLogManager::init ( const char* name )
{
    const char* sName = NULL;
    char*       pChar;

    _TRY
    {
        // 두번호출 확인
        _ASSERT( instance == NULL );
        instance = new cmnLogManager ( );

        if ( name != NULL )
        {
            cmnStrCpy ( service_name, name, sizeof(service_name) );
        }
        else
        {
#ifdef __linux__	//TODO: [OKT]  윈도포팅
            pChar = getenv ( "_" );
            if ( pChar != NULL )
            {
                sName = basename ( pChar );
            }
            else
            {
                sName = getenv ( "USER" );
            }
#else
            //TODO: [OKT]  윈도포팅, 로그파일이름 수정요 - basename 구현요
            sName = getenv ( "USERNAME" );
#endif /* __linux__ */

            cmnStrCpy ( service_name, sName, sizeof(service_name) );
        }

        _CALL( openFile ( ) );

        // 비동기 로그 쓰레드 생성
        if( m_nLogSyncFlag == 0 )
        {
            _CALL( instance->create ( ) );
            cmnLogManager::user_instance = cmnLogManager::instance;

            // _dbm_exit 에서 한꺼번에 호출한다. (순서관리상)
            //atexit ( (void (*) ( ))destroy );             // Sync를 해주어야한다.
        }

        // 로그 레벨 설정
        pChar = getenv( ENV_DBM_TRCLOG_LEVEL );
        if ( pChar != NULL )
        {
            _CALL( cmnLogSetLevel( pChar ) );
        }
        else
        {
#if 1
            //초기값이 릴리즈에서는 '2', 디버거에서는 '5'이다.
            //_CALL( cmnLogSetLevel( pChar ) );
#else
            char    sConfFile[1024];
            char    sVal[1024];
            int     sConf = 0;

            if ( getenv( ENV_DBM_HOME ) != NULL )
            {
                memset_s( sConfFile, 0x00, sizeof(sConfFile) );
                snprintf( sConfFile, sizeof(sConfFile), "%s/conf/dbm.cfg", getenv( ENV_DBM_HOME ) );
                _CALL( cmnOpenConfig ( sConfFile, &sConf ) );
                //TODO: 2014.12.14. -okt- 아직 instance name이 정해지지 않았으므로 COMMON 외의 다른쪽 설정을 얻을 수 없다.
                _CALL( cmnReadElement ( sConf, (char *) "COMMON", (char *) "TRACE_LOG_LEVEL", sVal, NULL ) );
                _CALL( cmnLogSetLevel ( sVal ) );
            }
#endif
        }

        if ( g_cmn_log_buf != NULL && g_cmn_log_buf[0] != 0x00 )
        {
            // _dbm_main을 통해 진입한 것이 아니다. 이때는 로그 출력 중복을 막기위해 그냥 나간다.
            _RETURN;
        }

        if ( cmnLogGetAppType( service_name ) > 0 )
        {
            // 논리상 위치가 안맞지만 둘데가 없다.
            DBM_LINE_F(1);
            DBM_SYS_F ( "************** '%d' process start ( %s ) *******************", getpid_s(), cmnLogManager::service_name );
        }
    }
    _CATCH
    {
        _CATCH_PRT;
    }
    _FINALLY
    _END
}

_VOID cmnLogManager::thread_main()
{
    cmnMsgHandle*   pCmd    = NULL;
    void*           pData   = NULL;

    _TRY
    {
        for ( int i = 0; i < _cmn_sys_ncpu; i++ )
        {
            pthread_yield_s();  // 메인쓰레드에서 wait에 진입할 시간을 준다.
        }

        // 로그 쓰레드 구동을 알린다.
        _CALL( sig_send ( ) );

        while ( m_bRunning )
        {
            _CALL( m_LogQue.sig_wait ( (void**) &pData ) );
            if ( pData == NULL )
            {
                _DASSERT ( 0 );
                continue;
            }

#ifdef _DEBUG
            static int sDataCodePre = -1;
            if ( pCmd != NULL )
            {
                sDataCodePre = pCmd->mDataCode; // 추기구동시 시그널 세는걸 추적하기위함.
            }
#endif
            pCmd = (cmnMsgHandle*)( (char*)pData - sizeof(cmnMsgHandle) );

            switch ( pCmd->mDataCode )
            {
                case DBM_CMD_DATA:          /* 1 */
                    _CALL( write2File ( pData, pCmd->mDataSize, pCmd->mDataType ) );
                    break;
                case DBM_CMD_QUE_FLUSH:
                {
                    _CALL( flush2File () );
                    _CALL( cmnMemFreeSlot ( (void**) &pData ) );
                    _CALL( sig_send () );
                    continue;
                }
                    break;
                case DBM_CMD_START:         /* 2 */
                    _CALL( sig_send ( ) );
                    break;
                case DBM_CMD_STOP:
                    //TODO: 2014.12.14. -okt- [미구현] 정상종료시 비동기로그를 기록해야한다. 추가기록을 못하게 하는 사용자측면 변수 추가요.
                    mvpAtomicSet32 ( &m_bRunning, 0 );
                    _CALL( sig_send ( ) );
                    break;
                default:
#ifdef _DBM_USE_TRACE_CALLER
                    _PRT ( "unknown msg code. (%d) [%s:%d]\n", pCmd->mDataCode, pCmd->mWhere.func, pCmd->mWhere.line );
#else
                    _PRT ( "unknown msg code. (%d)\n", pCmd->mDataCode );
#endif
                    // TODO: 이상한 데이타임. 일단 안죽고 넘김. BUGBUG
                    _DASSERT ( 0 );
                    break;
            }

            _CALL( cmnMemFreeSlot ( (void**) &pData ) );
        } /* while */
    }
    _CATCH
    {
        _CATCH_PRT;
    }
    _FINALLY
    {
        flush ( );
    }
    _END
}

_VOID cmnLogManager::flush()
{
    _TRY
    {
        fflush ( stdout );
        fflush ( stderr );

        if ( instance == NULL || cmnLogManager::m_nLogSyncFlag == 1 )
            _RETURN;

        _CALL( instance->sendCmd ( DBM_CMD_QUE_FLUSH ) );
        _rc =  instance->sig_wait ( 60 );
        if ( _rc != 0 )
        {
            _PRT ( "(W) Log Flush timedout. rc=%d (err=%d,thr=%d)\n", _rc, errno, gettid_s() );
        }
    }
    _CATCH
    {
        _CATCH_PRT;
    }
    _FINALLY
    _END
}

_VOID cmnLogManager::flush2File()
{
    _TRY
    {
        fflush ( stdout );
        fflush ( stderr );

        if ( instance == NULL || m_ulog == NULL )
            _RETURN;

        _CALL( fflush ( m_slog ) );
        _CALL( fflush ( m_ulog ) );

#ifdef __linux__	//TODO: [OKT]  윈도포팅
        // 명시적 Sync요청인 경우 fdatasync 대신에 Sync를 사용.
        _CALL( fsync ( m_slogFd ) );
        _CALL( fsync ( m_ulogFd ) );
#endif /* __linux__ */
    }
    _CATCH
    {
        _CATCH_PRT;
    }
    _FINALLY
    _END
}

_VOID cmnLogManager::openFile ( )
{
    int     sErrno = errno;
    char    slogfile [DBM_FILE_NAME_LEN] = { 0, };
    char    ulogfile [DBM_FILE_NAME_LEN] = { 0, };
    char    sDir [DBM_FILE_NAME_LEN];
    char    sTime [32];
    char*   pChar;
    int     sMode = -1;

    _TRY
    {
        _ASSERT ( service_name != NULL );
        sMode = umask(0x00);        // 777 모드로 오픈하기 위해 umask 필요.

        errno = 0;
        cmnTime2Str ( sizeof( "yyyymmdd" ), sTime );

        pChar = getenv ( ENV_DBM_TRCLOG_NAME_TYPE );
        if ( pChar != NULL )
        {
            if ( pChar[0] == '2' )
            {
                snprintf ( ulogfile, sizeof(ulogfile), "%.8s_%s.log", sTime, service_name );
            }
            // 그럴일 없을 것 같지만, 나중에 타입이 추가되면 필요하므로 조건을 한번더 검사.
            else if ( pChar[0] == '3' )
            {
                snprintf ( ulogfile, sizeof(ulogfile), "%.8s_%s_%d.log", sTime, service_name, m_nProcessId );
            }
            else
            {
                //do nothing
            }
        }

        // 디폴트
        snprintf ( slogfile, sizeof(slogfile), "alert_%s.log", m_zHostName );
        if ( ulogfile[0] == 0x00 )
        {
            if ( getenv ( ENV_DBM_INSTANCE ) != NULL )
            {
                char        sTraceFile [256];
                time_t      sCurr;
                struct tm   ptm;

                sCurr = time ( NULL );
                localtime_r ( &sCurr, &ptm );

                snprintf ( ulogfile, sizeof(ulogfile), "dbm.%s.%02d%02d.log", getenv ( ENV_DBM_INSTANCE ), ptm.tm_mon+1, ptm.tm_mday );
            }
            else
            {
                snprintf ( ulogfile, sizeof(ulogfile), "%.8s_%s.log", sTime, service_name );
            }
        }

        snprintf ( sDir, sizeof(sDir), "%s/trc", getenv ( ENV_DBM_HOME ) );

        if (  ( cmnAccess ( sDir, R_OK|X_OK|W_OK ) != 0 ) )
        {
            DBM_PRT ( "cann't access trace log directory '%s' (err=%d)", sDir, errno );
            // 오류면 현재 디렉토리을 사용
            if ( getcwd ( sDir, DBM_FILE_NAME_LEN ) != NULL )
            {
                if ( cmnAccess ( sDir, R_OK|X_OK|W_OK ) != 0 )
                {
                    _THROW ( -1 );
                }
            }
        }

        snprintf ( m_ulog_file, DBM_FILE_NAME_LEN , "%s/%s", sDir, ulogfile );
        snprintf ( m_slog_file, DBM_FILE_NAME_LEN , "%s/%s", sDir, slogfile );

        {
            // FILE MODE 설정을 위해 잠깐 열었다. 닫는다.
            m_ulogFd = open ( m_ulog_file, O_CREAT | O_APPEND, _cmn_file_mode ) ;
            close_s( m_ulogFd );

            m_ulog = fopen ( m_ulog_file, "a+" );
            _TEST_THROW ( m_ulog != NULL, -1 );
            m_ulogFd = fileno ( m_ulog );
        }

        if ( cmnLogManager::m_nLogSyncFlag == 0 )
        {
            m_slogFd = open ( m_slog_file, O_CREAT | O_APPEND, _cmn_file_mode ) ;
            close_s( m_slogFd );

            m_slog = fopen ( m_slog_file, "a+" );
            _TEST_THROW ( m_slog != NULL, -1 );
            m_slogFd = fileno ( m_slog );
        }
    }
    _CATCH
    {
        _CATCH_PRT;
        _ASSERT ( 0 );
    }
    _FINALLY
    {
        if ( sMode != -1 )
        {
            (void) umask ( sMode );     // 기존 umask 설정으로 원복.
        }

        errno = sErrno;
    }
    _END
} /* openFile */

_VOID cmnLogManager::closeFile ( )
{
    _TRY
    {
        if ( m_ulog != NULL )
        {
            fclose_s ( m_ulog );
            m_ulog = NULL;
            m_ulogFd = -1;
        }
        if ( m_slog != NULL )
        {
            fclose_s ( m_slog );
            m_slog = NULL;
            m_slogFd = -1;
        }
    }
    _CATCH
    _FINALLY
    _END
}

_VOID cmnLogManager::create()
{
    _TRY
    {
        _CALL( m_LogQue.init ( ) );
        _CALL( startThread ( ) );

        (void) instance->sig_wait ( 3 );
        //usleep ( 1000 ); // 쓰레드가 시작할 시간을 준다.

        _CALL( instance->sendCmd ( DBM_CMD_START ) );
        _rc = instance->sig_wait ( 3 );
        if ( _rc == ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT )    // = 66
        {
            _CALL( instance->sendCmd ( DBM_CMD_START ) );
            _rc = instance->sig_wait ( 3 );
            if ( _rc == ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT )
            {
                if ( _cmn_log_echo != 0 )
                {
                    _PRT ( "[%s:%s:%d] catch error rc=%d (err=%d,l=%d)\n", _WHERE, _rc, errno, _line );
                }

#ifdef _DEBUG
                // TOOD (OKT): 죽여서 디버깅하자.
                {
                    //_DASSERT( 0 );    // 여기서는 사용안된다. 로그쓰레드가 정상이 아니다.
                    assert( 0 && "async log thread startup fail." );
                }
#endif
                // 쓰레드 구동이 Timeout 발생하면 한번만 더 시도 해본다.
                _CALL( instance->sendCmd ( DBM_CMD_START ) );
                _CALL( instance->sig_wait ( 3 ) );
            }
            else if ( _rc != 0 )
            {
                _THROW( _rc );
            }
        }
        else if ( _rc != 0 )
        {
            _THROW( _rc );
        }
    }
    _CATCH
    {
        _CATCH_PRT;
    }
    _FINALLY
    _END
}

_VOID cmnLogManager::destroy()
{
    _TRY
    {
#if 0
        // static이 아니어서 여기서 호출할수 없다.
        _CALL( stopThread ( ) );
        _CALL( m_LogQue.destroy ( ) );
#endif
        cmnLogManager::user_instance = NULL;
        _CALL( cmnLogFlush ( ) );
    }
    _CATCH
    {
        _CATCH_PRT;
    }
    _FINALLY
    _END
}

_VOID cmnLogManager::write2ULog ( const void* buf, const int len, const int flag )
{
    int     sLen = 0;

    _TRY
    {
        // 일부 Byte만 기록될 수도 있음
        sLen = fwrite ( buf, 1, len, m_ulog );
        if ( sLen < len )
        {
            if ( errno == ENOSPC || errno == EFBIG )
            {
                // 디스크풀은 무시한다.
                _RETURN;
            }
            else
            {
                DBM_PRT ( "log write error. len=%d,%d (err=%d,tid=%d)", sLen, len, errno, gettid_s() );
                _THROW ( -1 );
            }
        }
        fflush ( m_ulog );      // 요기까지하면 OS가 죽지않으면 보통은 기록된다.

#ifndef _DEBUG
        if ( cmnLogManager::instance->m_LogQue.size () < 2 )
        {
            // 데이타가 밀려있지 않은 경우만 Sync한다.
            // 2014.12.14. -okt- trace log fsync - 사내 장비 성능이 나쁘므로 일단 막음.
            // fdatasync ( m_ulogFd );
        }
#endif
    }
    _CATCH
    _FINALLY
    _END
}

_VOID cmnLogManager::write2SLog ( const void* buf, const int len, const int flag )
{
    int     sLen = 0;
    int     i;

    _TRY
    {
        // alert_xx.log에 대한 기록은 ASync 모드에서만 사용한다. (성능)
        if ( m_slog == NULL )
            _RETURN;

        // if len = 1 then DBM_LINE(1)
        if ( ( (char*) buf )[0] == '(' || len == 1 )
        {
            switch ( ( (char*) buf )[1] )
            {
                case 'C' :
                case 'E' :
                //case 'W' :
                    NULL;
                    break;
                default :
                    // alert log 대상이 아니다.
                    _RETURN;
                    break;
            }
        }

        if( m_nLogPidType == 1 )
        {
            // alert log의 경우는 taskid 가 아닌 pid를 기록
            memcpy_s( (char*)buf + m_nLogHeaderPidOffset, m_zProcessId, sizeof( m_zProcessId ) - 1 );
        }

        // 일부 Byte만 기록될 수도 있음
        sLen = fwrite ( buf, 1, len, m_slog );
        if ( sLen < len )
        {
            if ( errno == ENOSPC || errno == EFBIG )
            {
                // 디스크풀은 무시한다.
                _RETURN;
            }
            else
            {
                DBM_PRT ( "log write error. len=%d,%d (err=%d,tid=%d)", sLen, len, errno, gettid_s() );
                _THROW ( -1 );
            }
        }
        fflush ( m_slog );      // 요기까지하면 OS가 죽지않으면 보통은 기록된다.

#ifndef _DEBUG
        if ( instance->m_LogQue.size () < 2 )
        {
            // 데이타가 밀려있지 않은 경우만 Sync한다.
            // 2014.12.14. -okt- trace log fsync - 사내 장비 성능이 나쁘므로 일단 막음.
            //fdatasync ( m_slogFd );
        }
#endif
    }
    _CATCH
    _FINALLY
    _END
}

_VOID cmnLogManager::write2File ( const void* buf, int len, int flag )
{
    int     sErrnoPre = errno;

    _TRY
    {
        errno = 0;

        if ( m_ulog == NULL )
        {
            /*
             * 2015.02.22 -okt-
             * 여기에 진입했다는 것은, _dbm_main() 을 호출하지 않고 (즉 libdbm.so를 호출하지 않고) DBM_INFO 등을 사용한 것이다.
             * 쓰레드 동시성을 잡아야 한다. 그렇지 않으면 assert 방어코드로 죽는다.
             */
            _CALL( cmnLogManager::init ( ) );
        }

        if ( buf == NULL )
        {
            _RETURN;
        }

        // ulog 파일
        _CALL( write2ULog ( buf, len, flag ) );
        // alert_xx.log에 대한 기록은 ASync 모드에서만 사용한다. (성능)
        if ( unlikely( cmnLogManager::m_nLogSyncFlag == 0 ) )
        {
            _CALL( write2SLog ( buf, len, flag ) );
        }
    }
    _CATCH
    {
#ifdef _DEBUG
        // stdout 으로 로그를 출력하는 경우 PMS가 기록을 하게됨, 운영모드에서는 화면 출력 없음 ( 2013. 08. 07. )
        printf ( "%s:%d Log Write Error _rc=%d (err=%d) msg=[%s]\n", __FILE__, __LINE__, _rc, errno, (char*)buf ); fflush ( stdout );
#endif
    }
    _FINALLY
    {
        errno = sErrnoPre;
    }
    _END
}

_VOID cmnLogManager::makeHeader ( const char* file, const char* func, int line, int loglevel, char* buf )
{
    char*   pChar = NULL;
    int     ix = 0;
    int     sLen;
    int     sLogLevel = loglevel & LL_F;    // LF_SYNC 같은것이 함께 들어온다.

    _TRY
    {
        buf[ix] = '('; ix++;

        //switch ( loglevel )
        switch ( *(short*)&sLogLevel )
        {
            case LL_C:
                buf[ix] = 'C';
                _dbm_nLogCntErr++;
                break;
            case LL_E:
                buf[ix] = 'E';
                _dbm_nLogCntErr++;
                break;
            case LL_W:
                buf[ix] = 'W';
                _dbm_nLogCntWarn++;
                break;
            case LL_I:
                buf[ix] = 'I';
                break;
            case LL_D:
                buf[ix] = 'D';
                break;
            case LL_T:
                buf[ix] = 'T';
                break;
            default:
                buf[ix] = 'U';
                break;
        }

        _dbm_nLogCnt ++;
        ix++;

        buf[ix] = ')'; ix++;

//        static int sTmLen = strlen ( "yyyy/mm/dd hh:mi:ss.ssssss" );
        static int sTmLen = sizeof( "hh:mi:ss.ssssss" ) - 1; // 2014.11.18. -okt- strlen 대신에 sizeof를 사용하면 compile 시점에 결정
        cmnTime2Str ( sTmLen + 1, &buf[ix] );
        ix += sTmLen;

#ifdef __linux__	//TODO: [OKT]  윈도포팅
        if( m_nLogPidType == 1 )
        {
            sLen = ix + sprintf ( &buf[ix], " %05d %15.15s %15.15s%5d ", gettid_s(), basename ( file ), func, line );
        }
        else
        {
            sLen = ix + sprintf ( &buf[ix], " %05d %15.15s %15.15s%5d ", getpid_s(), basename ( file ), func, line );
        }

#else
        if( m_nLogPidType == 1 )
        {
            sLen = ix + sprintf ( &buf[ix], " %05d %15.15s %15.15s%5d ", gettid_s(), ( file ), func, line );
        }
        else
        {
            sLen = ix + sprintf ( &buf[ix], " %05d %15.15s %15.15s%5d ", getpid_s(), ( file ), func, line );
        }
#endif /* __linux__ */

        if ( unlikely ( m_nLogHeaderSize == -1 ) )
        {
            m_nLogHeaderSize = sLen;
            m_nLogHeaderPidOffset = ix + 1;
        }

    }
    _CATCH
    _FINALLY
    _END
}

_VOID cmnLogSend ( const char* file, const char* func, int line, int loglevel, const char* aFormat, ... )
{
    cmnMsgHandle* pCmd = NULL;
    char*   pData = NULL;
    int     sSize = 0;

    int     sSyncFlag   = 0;
    int     sPrtFlag    = 0;
    int     sNoHFlag    = 0;
    int     sEchoFlag   = 0;
    int     sErrno      = errno;        // [필수] DIC에서 EEXIST를 검사하는 용도로 errno를 사용한다. (2014/06/14)

    _TRY
    {
        sSyncFlag = BITAND( loglevel, LF_SYNC );
        sPrtFlag = BITCHK( loglevel, LF_PRT );          // BITAND 를 사용하면 안됨, LF_PRT는 LF_SYNC와의 조합이므로.
        if ( sPrtFlag == 0 )
        {
            /*
             * user_instance 는 사용자가 사용해도 되는 상태를 의미
             * instance 는 내부 싱글톤 생성 여부
             */
            if ( sSyncFlag == 0 && cmnLogManager::m_nLogSyncFlag == 0 )
            {
                if ( cmnLogManager::user_instance == NULL )
                    _RETURN;
            }

            if ( BITAND(cmnLogManager::m_nLogLevel, loglevel) == 0 )
            {
                _RETURN;
            }
        }

        sNoHFlag = BITAND( loglevel, LF_NOH );          // 0,1, 아니고 양수를 고려해야함.
        sEchoFlag = BITAND( loglevel, LF_ECHO );

        if ( cmnLogManager::m_nLogSyncFlag == 1 )
        {
            /*
             * 2014.12.14. -okt- [패키징] 2014/07/13, 릴리즈에서 SYNC 모드를 기본으로.
             *             1. DBM_TRCLOG_ASYNC_ENABLE=1 환경변수 설정된 경우는 Async Mode
             */
            sSyncFlag = 1;
        }


        // 로그전달에 사용할 버퍼 활당.
//        if ( cmnLogManager::m_nLogSyncFlag == 0 && sSyncFlag == 0 )
        if ( sSyncFlag == 0 )
        {
            _CALL( cmnMemAllocSlot ( (void**) &pData ) );
            _ASSERT( pData != NULL );
            pCmd = (cmnMsgHandle*) ( (char*) pData - sizeof(cmnMsgHandle) );
        }
        else
        {
            if ( likely( g_cmn_log_buf == NULL ) )
            {
                g_cmn_log_buf = (char*) malloc_s ( MAX_SIZE_PER_LOG + 1 );
                // _dbm_main을 통해 진입한 것이 아니다. 이때는 로그 출력 중복을 막기위해 구분하는 용도
                g_cmn_log_buf[0] = 0x00;
            }
            pData = g_cmn_log_buf;
        }


        // 로그 헤더 생성
        if ( likely( sNoHFlag == 0 ) )
            _CALL( cmnLogManager::makeHeader ( file, func, line, loglevel, pData ) );

        // 로그 내용 조립
        // 성능느림(불가피), - 가변인자를 다른 함수로 전달할 수 있는 방법이 어려움.
        sSize = 0;
        va_list args;
        va_start( args, aFormat );
        if ( likely( sNoHFlag == 0 ) )
        {
            sSize = cmnLogManager::m_nLogHeaderSize + vsnprintf ( pData + cmnLogManager::m_nLogHeaderSize, DBM_MAX_LOG_LEN - cmnLogManager::m_nLogHeaderSize, aFormat, args );
        }
        else
        {
            sSize = vsnprintf( pData, DBM_MAX_LOG_LEN, aFormat, args );
        }
        va_end( args );

        if ( sSize > MAX_SIZE_PER_LOG )
        {
            sSize = MAX_SIZE_PER_LOG;
        }

        if ( sSize > 2 )    // DBM_LINE(1) 예외처리
        {
            if ( pData[sSize-1] == '\n' && pData[sSize-2] == '\n' )
            {
                pData[sSize-1] = 0;
                sSize--;
            }
            else if ( pData[sSize-1] != '\n' )
            {
                pData[sSize] = '\n';
                sSize++;
                pData[sSize] = 0;
            }
        }

        if ( unlikely ( sEchoFlag != 0 || sPrtFlag != 0 || _cmn_log_echo == 1 ) )
        {
            // 1 과 같다고 비교하면 안됨
//          if ( sPrtFlag == 1 || sNoHFlag == 1 )
            if ( sPrtFlag != 0 || sNoHFlag != 0 )
            {
                printf( "%s", pData );
            }
            else
            {
                // LF_PRT 가 아닌 경우는 헤더를 제거하고 출력.
                printf( "%s", pData + cmnLogManager::m_nLogHeaderSize );
            }
            fflush ( stdout );

            if ( sPrtFlag != 0 )
                _RETURN;
        }

        if( sSyncFlag == 0 )
        {
            pCmd->mDataCode = DBM_CMD_DATA;
            pCmd->mDataType = loglevel;
            pCmd->mDataSize = sSize;
#ifdef _DBM_USE_TRACE_CALLER
            pCmd->mWhere.file = file;
            pCmd->mWhere.func = func;
            pCmd->mWhere.line = line;
#endif

            _CALL( cmnLogManager::instance->m_LogQue.push ( pData ) );
        }
        else
        {
            _CALL( cmnLogManager::write2File ( pData, sSize, loglevel ) );
        }
    }
    _CATCH
    {
#ifdef _DEBUG
        _CATCH_PRT;
        usleep ( 1000 );         // 로그 도배를 막는다.
#endif
    }
    _FINALLY
    {
        errno = sErrno;
    }
    _END
} /* cmnLogSend */

_VOID cmnLogFlush ()
{
    _TRY
    {
        _CALL( cmnLogManager::flush () );
    }
    _CATCH
    _FINALLY
    _END
}

// 예를들면 'E,W,H' 이런 조합으로도 가능하다.
static _VOID cmnLogSetLevelLib ( const char* aLevel )
{
    int     i;
    int     sLevel = 0;          // 초기값 0 이 필수.

    _TRY
    {
        for ( i=0; ; i++ )
        {
            if ( aLevel[i] == ',' ) continue;
            if ( aLevel[i] == 0x00 ) break;
            switch ( toupper(aLevel[i]) )
            {
            case 'E':
                sLevel |= LL_E;
                break;
            case 'W':
                sLevel |= LL_W;
                break;
            case 'I':
                sLevel |= LL_I;
                break;
            case 'H':
                sLevel |= LL_H;
                break;
            case 'D':
                sLevel |= LL_D;
                break;
            case 'T':
                sLevel |= LL_T;
                break;
            default:
                DBM_DBG ( "unknown LOGLEVEL '%c' (%s)", aLevel[i], aLevel );
                _THROW(-1);
                break;
            }
        }
        // 무조건 출력
        sLevel |= LL_C;

        DBM_FORCE ( "Set LogLevel 0x%04x -> 0x%04x, aLevel='%s'", cmnLogManager::m_nLogLevel, sLevel, aLevel );
        cmnLogManager::m_nLogLevel = sLevel;
    }
    _CATCH
    _FINALLY
    _END
}

_VOID cmnLogSetLevel ( const char* aLevel )
{
    int  sLevel = 0;

    _TRY
    {
        switch ( aLevel[0] )
        {
        case '0':
            sLevel = LL_0;
            break;
        case '1':
            sLevel = LL_1;
            break;
        case '2':
            sLevel = LL_2;
            break;
        case '3':
            sLevel = LL_3;
            break;
        case '4':
            sLevel = LL_4;
            break;
        case '5':
            sLevel = LL_5;
            break;
        case '6':
        case '9':               // 추가되면 위치 이동 필요 '9' 는 전체 출력 의미함.
            sLevel = LL_6;
            break;
        default:
            _CALL( cmnLogSetLevelLib ( aLevel ) );
            _RETURN;
            break;
        }

        // metaManager 등의 로그 출력 줄임.
        if ( cmnLogGetAppType( cmnLogManager::service_name ) == 2 )
        {
            //DBM_FORCE ( "Set LogLevel 0x%04x -> 0x%04x, aLevel='%s'", cmnLogManager::m_nLogLevel, sLevel, aLevel );
        }

        cmnLogManager::m_nLogLevel = sLevel;
    }
    _CATCH
    _FINALLY
    _END
}

/**
 * 내부 유틸리티를 실행할때마다, 불필요하게 dbm.xx.log가 도배되는 것을 방지용도.
 */
int cmnLogGetAppType( const char* aName )
{
    if ( !strncmp ( aName, "dbmExp", strlen(aName) )
            || !strncmp ( aName, "metaManager", strlen ( aName ) )
            || !strncmp ( aName, "dbmImp", strlen ( aName ) )
            )
    {
        return 1;   // 제한된 로그.
    }
    if ( !strncmp ( aName, "odiff", strlen ( aName ) )
//            || !strncmp ( aName, "metaManager", strlen ( aName ) )
            || !strncmp ( aName, "merr", strlen ( aName ) ) )
    {
        return 0;   // 더 제한된 로그
    }

    return 2;       // 일반.
}
