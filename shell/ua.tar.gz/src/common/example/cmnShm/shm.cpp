#include "cmnApi.h"

typedef struct testStruct
{
    long long  mKey;
    char     mVal[20];
}testStruct;

int main()
{
    int         i;
    char*       sKeyFile = (char *)"my_shm_key";
    int         sShmSize = 10 * sizeof( testStruct );
    char*       sShmPtr;
    int         sRet;
    testStruct* sPtr;
    int         sShmID, sAttachNum;

    /*---------------------------------------------------------
     * sKeyFile 를 이용하여 Shm Key 를 생성
     *   ( sKeyFile 는 실제 존재하는 File 이름을 주어야 한다.)
     *-------------------------------------------------------*/
    sRet = cmnShmCreate( sKeyFile,
                         sShmSize );
    if ( sRet != 0 )
    {
        /*---------------------------------------------------------
         * sRet 값에 따라 cmnShmCreate 의 어느 단계에서 에러가
         * 발생했는지 파악할 수 있다.
         * 좀더 정확한 error message 는 errno 의 string 을 찍어보면 된다.
         *-------------------------------------------------------*/
        DBM_INFO( "cmnShmCreate Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }
    DBM_INFO( "cmnShmCreate OK. key_path[%s] shm_size[%d]", sKeyFile, sShmSize );

    /*---------------------------------------------------------
     * attach to created shm segment
     *-------------------------------------------------------*/
    sRet = cmnShmAttach( sKeyFile, sShmSize, &sShmPtr );
    if ( sRet != 0 )
    {
        DBM_INFO( "cmnShmAttach Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }
    DBM_INFO( "cmnShmAttach OK" );

    memset( sShmPtr, 0x00, sShmSize );

    /*---------------------------------------------------------
     * save some information in shm segment
     *-------------------------------------------------------*/
    sPtr = ( testStruct *)sShmPtr;

    for( i = 0; i < 10; i++ )
    {
        sPtr->mKey = (long long)i;
        sprintf( sPtr->mVal, "%20d", i );

        sPtr++;
    }

    /*---------------------------------------------------------
     * detach from shm segment
     *-------------------------------------------------------*/
    sRet = cmnShmDetach( &sShmPtr );
    if ( sRet != 0 )
    {
        DBM_INFO( "cmnShmDetach Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }
    DBM_INFO( "cmnShmDetach OK" );

    /*---------------------------------------------------------
     * attach to shm segment again
     *-------------------------------------------------------*/
    sRet = cmnShmAttach( sKeyFile, sShmSize, &sShmPtr );
    if ( sRet != 0 )
    {
        DBM_INFO( "cmnShmAttach Again Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }
    DBM_INFO( "cmnShmAttach Again OK" );

    /*---------------------------------------------------------
     * show saved information in shm segment
     *-------------------------------------------------------*/
    sPtr = (testStruct*)sShmPtr;

    for( i = 0; i < 10; i++ )
    {
        DBM_INFO( "\tkey[%ld] val[%s]", sPtr->mKey, sPtr->mVal);

        sPtr++;
    }


    /*---------------------------------------------------------
     * Display shmID
     *-------------------------------------------------------*/
     sRet = cmnShmGetID ( sKeyFile, &sShmID );
     DBM_INFO( "ShmID = %d", sShmID );

    /*---------------------------------------------------------
     * Display Attach#
     *-------------------------------------------------------*/
     sRet = cmnShmGetAttachNum ( sKeyFile, &sAttachNum );
     DBM_INFO( "#Attach = %d", sAttachNum );

    /*---------------------------------------------------------
     * Display shmStat
     *-------------------------------------------------------*/
     sRet = cmnShmIsDest ( sKeyFile );
     DBM_INFO( "IsDest = %d", sRet );


    /*---------------------------------------------------------
     * drop(remove) shm segment
     *-------------------------------------------------------*/
    sRet = cmnShmDrop( sKeyFile );
    if ( sRet != 0 )
    {
        DBM_INFO( "cmnShmDrop Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }
    DBM_INFO( "cmnShmDrop OK" );

    /*---------------------------------------------------------
     * Display shmStat
    *-------------------------------------------------------*/
    sRet = cmnShmIsDest ( sKeyFile );
    DBM_INFO( "IsDest = %d", sRet );


    return 0;
}
