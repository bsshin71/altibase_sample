#include "cmnApi.h"


pthread_mutex_t  mutex;
pthread_cond_t   condp;

void* thr( void* );

void* thr( void* param )
{
    int rc;

    rc = cmnLockMutex( &mutex, 0 );
    DBM_INFO( "Thread Lock Mutex rc = %d", rc );

    DBM_INFO( "Thread CondWaiting" );
    rc = cmnCondWait( &condp, &mutex, 0 );
    DBM_INFO( "Thread CondWait rc=%d", rc );

    rc = cmnUnlockMutex( &mutex );
    DBM_INFO( "Thread Unlock mutex rc=%d", rc );

    return NULL;
}




int main()
{
    struct timespec start, end;
    pthread_t tid[3];
    int lock, cond;
    int rc;
    int i;
    PHTIMER sTimer;


    /*******************************************
     * Mutex 초기화
    *******************************************/
    rc = cmnInitMutex( &mutex );
    DBM_INFO( "initMutex rc = %d", rc );

    rc = cmnInitCond( &condp);
    DBM_INFO( "initCond rc = %d", rc );

    /*******************************************
     * 간단한 Mutex Lock/Unlock
    *******************************************/
    rc = cmnLockMutex( &mutex, 10 );
    DBM_INFO( "LockMutex rc = %d", rc );

    rc = cmnUnlockMutex( &mutex );
    DBM_INFO( "UnlockMutex rc = %d", rc );

    /*******************************************
     * 간단한 Mutex Lock & condWait해보기
    *******************************************/
    pthread_create( &tid[0], NULL, thr, NULL );

    DBM_INFO( "mainThread sleeping 5 second." );
    /*******************************************
     * 5초 후에 깨워본다.
    *******************************************/
    sleep( 5 );
    rc = cmnCondBroadCast( &condp);
    DBM_INFO( "BroadCast rc = %d", rc );
    pthread_join( tid[0], NULL );

    rc = cmnLockMutex( &mutex, 10 );
    DBM_INFO( "LockMutex rc = %d", rc );

    /*******************************************
     * CondWait의 Timeout이 잘되나 체크.
    *******************************************/
    clock_gettime_s(CLOCK_REALTIME, &start );
    rc = cmnCondWait( &condp, &mutex, 100000 );
    clock_gettime_s(CLOCK_REALTIME, &end );
    DBM_INFO( "CondWait rc (0.1second) = %d (elapTime=%.2f)", rc,
                                        (double)((end.tv_sec+end.tv_nsec/1000000000.0 ) - ( start.tv_sec+start.tv_nsec/1000000000.0 ) ) );

    clock_gettime_s(CLOCK_REALTIME, &start );
    rc = cmnCondWait( &condp, &mutex, 10000000 );
    clock_gettime_s(CLOCK_REALTIME, &end );
    DBM_INFO( "CondWait rc (10second) = %d (elapTime=%.2f)", rc,
                                        (double)((end.tv_sec+end.tv_nsec/1000000000.0 ) - ( start.tv_sec+start.tv_nsec/1000000000.0 ) ) );

    rc = cmnUnlockMutex( &mutex );
    DBM_INFO( "UnlockMutex rc = %d", rc );


    lock = -1;
    cond = 0;

    /* Lock을 1로 바꾸는데 100번동안 해보고 */
    rc = cmnLockFutex( &lock, 1, 100 );
    DBM_INFO( "LockFutex rc = %d", rc );

    /* Lock을 1로 바꾸는데 10번동안 해보고 */
    rc = cmnLockFutex( &lock, 2, 10 );
    DBM_INFO( "LockFutex rc = %d (by acquired)", rc );

    /* Lock을 푸는데 자기께 아닌 경우는 오류 */
    rc = cmnUnlockFutex( &lock, 2 );
    DBM_INFO( "UnlockFutex (invalid) rc = %d (by acquired)", rc );

    /* Lock을 푸는데 자기꺼일때는 정상 */
    rc = cmnUnlockFutex( &lock, 1 );
    DBM_INFO( "UnlockFutex ( valid) rc = %d", rc );

    (void) cmnSignalFutex( &cond );
    //DBM_INFO( "signalFutex rc = %d", rc );

    /***********************************************
     * Futex timeout이 잘 먹나 체크해본다.
    ***********************************************/
    rc = cmnWaitFutex( &cond, 1000000 );
    DBM_INFO( "waitFutex rc = %d", rc );

    clock_gettime_s(CLOCK_REALTIME, &start );
    rc = cmnWaitFutex( &cond, 100000 );
    clock_gettime_s(CLOCK_REALTIME, &end );
    DBM_INFO( "waitFutex rc (0.1second) = %d (elapTime=%.2f)", rc,
                                        (double)((end.tv_sec+end.tv_nsec/1000000000.0 ) - ( start.tv_sec+start.tv_nsec/1000000000.0 ) ) );

    clock_gettime_s(CLOCK_REALTIME, &start );
    rc = cmnWaitFutex( &cond, 1000000 );
    clock_gettime_s(CLOCK_REALTIME, &end );
    DBM_INFO( "waitFutex rc (1second) = %d (elapTime=%.2f)", rc,
                                        (double)((end.tv_sec+end.tv_nsec/1000000000.0 ) - ( start.tv_sec+start.tv_nsec/1000000000.0 ) ) );

    DBM_INFO( "Mutex..." );
    cmnInitTimer( &sTimer, UNIT_NANO, 10, 30, 20 );
    for ( i=0; i<100000; i++ )
    {
        cmnStartTimer( sTimer );
        cmnLockMutex( &mutex, 0 );
        cmnUnlockMutex( &mutex );
        cmnEndTimer( sTimer );
    }

    cmnElapseTimer( sTimer, 100000, (char *)"Lock Test" );

    DBM_INFO( "Futex..." );
    cmnInitTimer( &sTimer, UNIT_NANO, 10, 30, 20 );
    for ( i=0; i<100000; i++ )
    {
        cmnStartTimer( sTimer );
        cmnLockFutex( &lock, 1, 0 );
        cmnUnlockFutex( &lock, 1 );
        cmnEndTimer( sTimer );
    }

    cmnElapseTimer( sTimer, 100000, (char *)"Lock Test" );
    return 0;
}
