#include <pthread.h>

#include "../header/cmnLog.h"


#define TEST_FILE_NAME  "TEST123.log"
//#define TEST_COUNT 1000
#define TEST_COUNT 10

int main()
{

    int             sRC = 0, i;
    cmnLogHandle*   sLogHandle;


    /*-------------------------------------------------------------
     * TEST001 : 버퍼가 다 찬 후의 동작을 테스트
     -------------------------------------------------------------*/
    sRC = cmnOpenLog ( (char *)TEST_FILE_NAME,
                       E,
                       1024,
                       2,
                       &sLogHandle );


    printf ( "cmnOpenLog sRC : [%d]\n", sRC ) ;


    for ( i = 0; i < TEST_COUNT; i++ )
    {
        sRC = cmnLog( sLogHandle, E, "LogBuffer-full] This is a sample Log.... [%d] \n", i );
    }



    sRC = cmnCloseLog ( &sLogHandle ) ;

    /*-------------------------------------------------------------
     * TEST002 : 버퍼를 사용하지 않는 테스트
     -------------------------------------------------------------*/
    sRC = cmnOpenLog ( (char *)TEST_FILE_NAME,
                       E,
                       1024,
                       0,
                       &sLogHandle );


    printf ( "cmnOpenLog sRC : [%d]\n", sRC ) ;


    for ( i = 0; i < TEST_COUNT; i++ )
    {
        sRC = cmnLog( sLogHandle, E, "Direct-logging] This is a sample Log.... [%d] \n", i );
    }



    sRC = cmnCloseLog ( &sLogHandle ) ;

    printf ( "cmnCloseLog for sRC : [%d]\n", sRC ) ;

}
