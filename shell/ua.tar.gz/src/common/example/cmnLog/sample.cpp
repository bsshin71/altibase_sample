#include <pthread.h>

#include "../header/cmnLog.h"


#define TEST_FILE_NAME  "/tmp/TEST123.log"
#define TEST_COUNT 100
int main()
{

    int             sRC = 0, i;
    cmnLogHandle*   sLogHandle;



    sRC = cmnOpenLog ( (char *)TEST_FILE_NAME,
                       E,
                       1024,
                       1024,
                       &sLogHandle );


    printf ( "cmnOpenLog sRC : [%d]\n", sRC ) ;


    for ( i = 0 ; i < TEST_COUNT ; i ++ )
    {
         sRC = cmnLogImp ( sLogHandle,
                           E,
                           __func__,
                           __LINE__,
                           "This is a sample Log.... [%d] \n",
                           i );
    }

    for ( i = 0 ; i < TEST_COUNT ; i ++ )
    {
         sRC = cmnLog ( sLogHandle,
                           E,
                           "This is a sample Log.... [%d] \n",
                           i );
    }



    sRC = cmnCloseLog ( &sLogHandle ) ;

    printf ( "cmnCloseLog for sRC : [%d]\n", sRC ) ;


    sRC = cmnOpenLog ( NULL,
                       E,
                       1024,
                       1024,
                       &sLogHandle );


    printf ( "cmnOpenLog sRC : [%d]\n", sRC ) ;


    for ( i = 0 ; i < TEST_COUNT ; i ++ )
    {
         sRC = cmnLogImp ( sLogHandle,
                           E,
                           __func__,
                           __LINE__,
                           "This is a sample Log.... [%d] \n",
                           i );
    }

    for ( i = 0 ; i < TEST_COUNT ; i ++ )
    {
         sRC = cmnLog ( sLogHandle,
                           E,
                           "This is a sample Log.... [%d] \n",
                           i );
    }



    sRC = cmnCloseLog ( &sLogHandle ) ;

    printf ( "cmnCloseLog for sRC : [%d]\n", sRC ) ;

    /*** BUG TEST ***/
    sRC = cmnOpenLog ( NULL,
                       E,
                       1024,
                       1024,
                       &sLogHandle );


    sRC = cmnCloseLog ( &sLogHandle ) ;

}
