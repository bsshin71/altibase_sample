#include "cmnApi.h"

#define TEST_COUNT 10000

int main()
{
    int      i;
    int      sRet;
    PHTIMER  sTimer;

    /*---------------------------------------------------------
     * Timer Handle 할당 및 초기화
     *-------------------------------------------------------*/
    sRet = cmnInitTimer( &sTimer, UNIT_MICRO, 5, 5, 20 );
    if ( sRet < 0 )
    {
        printf( "cmnInitTimer Fail [%d]\n", sRet );
        return 1;
    }

    for( i=0; i<TEST_COUNT; i++ )
    {
        /*---------------------------------------------------------
         * 시간 측정 시작
         *-------------------------------------------------------*/
        sRet = cmnStartTimer( sTimer );
        if ( sRet < 0 )
        {
            printf( "cmnStartTimer Fail [%d]\n", sRet );
            cmnFinalTimer( &sTimer );
            return 1;
        }

        usleep( 1 );

        /*---------------------------------------------------------
         * 시간 측정 끝
         *-------------------------------------------------------*/
        sRet = cmnEndTimer( sTimer );
        if ( sRet < 0 )
        {
            printf( "cmnEndTimer Fail [%d]\n", sRet );
            cmnFinalTimer( &sTimer );
            return 1;
        }

        if ( i % (TEST_COUNT/10 ) == 0 )
        {
            printf( "count : %d\n", i );
        }
    }

    /*---------------------------------------------------------
     * 통계 결과 print
     *-------------------------------------------------------*/
    sRet = cmnElapseTimer( sTimer, TEST_COUNT, (char *)"TimerStat Example1 - usleep(1)" );
    if ( sRet < 0 )
    {
        printf( "cmnElapseTimer Fail [%d]\n", sRet );
        cmnFinalTimer( &sTimer );
        return 1;
    }

    /*---------------------------------------------------------
     * cmnFinalTimer 를 호출안했다면 메모리 해제가 안되었을 것이다.
     * 하지만, 같은 Handle 을 이용하여 cmnInitHandle 을 호출하면
     * 이전에 해제안된 메모리가 자동으로 해제되고, 다시 할당되어
     * 초기화까지 정상적으로 수행한다.
     *-------------------------------------------------------*/
    printf( "\nReuse Timer ( UNIT_MICRO ) ****\n" );

    if ( 0x01 )
    {

        /*---------------------------------------------------------
         * Timer Handle 할당 및 초기화
         *-------------------------------------------------------*/
        sRet = cmnInitTimer( &sTimer, UNIT_MICRO, 10, 10, 10 );
        if ( sRet < 0 )
        {
            printf( "cmnInitTimer Fail [%d]\n", sRet );
            return 1;
        }

        for( i=0; i<TEST_COUNT; i++ )
        {
            /*---------------------------------------------------------
             * 시간 측정 시작
             *-------------------------------------------------------*/
            sRet = cmnStartTimer( sTimer );
            if ( sRet < 0 )
            {
                printf( "cmnStartTimer Fail [%d]\n", sRet );
                cmnFinalTimer( &sTimer );
                return 1;
            }

            usleep( 10 );

            /*---------------------------------------------------------
             * 시간 측정 끝
             *-------------------------------------------------------*/
            sRet = cmnEndTimer( sTimer );
            if ( sRet < 0 )
            {
                printf( "cmnEndTimer Fail [%d]\n", sRet );
                cmnFinalTimer( &sTimer );
                return 1;
            }

            if ( i % (TEST_COUNT/10 ) == 0 )
            {
                printf( "count : %d\n", i );
            }

            //usleep ( 100 );
        }

        /*---------------------------------------------------------
         * 통계 결과 print
         *-------------------------------------------------------*/
        sRet = cmnElapseTimer( sTimer, TEST_COUNT, (char *)"TimerStat Example2 - usleep(10)" );
        if ( sRet < 0 )
        {
            printf( "cmnElapseTimer Fail [%d]\n", sRet );
            cmnFinalTimer( &sTimer );
            return 1;
        }
    }

    printf( "\nReuse Timer ( UNIT_MICRO ) (2) ****\n" );
    //sleep ( 2 );
    if ( 0x01 )
    {
        // Timer Handle 할당 및 초기화 (X)

        for( i=0; i<TEST_COUNT; i++ )
        {
            /*---------------------------------------------------------
             * 시간 측정 시작
             *-------------------------------------------------------*/
            sRet = cmnStartTimer( sTimer );
            if ( sRet < 0 )
            {
                printf( "cmnStartTimer Fail [%d]\n", sRet );
                cmnFinalTimer( &sTimer );
                return 1;
            }

            //usleep(1 );
            cmnUSleep( 10 );

            /*---------------------------------------------------------
             * 시간 측정 끝
             *-------------------------------------------------------*/
            sRet = cmnEndTimer( sTimer );
            if ( sRet < 0 )
            {
                printf( "cmnEndTimer Fail [%d]\n", sRet );
                cmnFinalTimer( &sTimer );
                return 1;
            }

            if ( i % (TEST_COUNT/10 ) == 0 )
            {
                printf( "count : %d\n", i );
            }

            //usleep ( 100 );
        }

        /*---------------------------------------------------------
         * 통계 결과 print
         *-------------------------------------------------------*/
        sRet = cmnElapseTimer( sTimer, TEST_COUNT, (char *)"TimerStat Example2 - cmnUSleep(10)" );
        if ( sRet < 0 )
        {
            printf( "cmnElapseTimer Fail [%d]\n", sRet );
            cmnFinalTimer( &sTimer );
            return 1;
        }
    }

// 적은 건수 테스트
#define TEST_COUNT_MIN      3
    printf( "\nReuse Timer ( UNIT_MICRO ) (3) ****\n" );
    //sleep ( 2 );
    if ( 0x01 )
    {
        // Timer Handle 할당 및 초기화 (X)

        for( i=0; i<TEST_COUNT_MIN; i++ )
        {
            /*---------------------------------------------------------
             * 시간 측정 시작
             *-------------------------------------------------------*/
            sRet = cmnStartTimer( sTimer );
            if ( sRet < 0 )
            {
                printf( "cmnStartTimer Fail [%d]\n", sRet );
                cmnFinalTimer( &sTimer );
                return 1;
            }

            //usleep(1 );
            cmnUSleep( 10 );

            /*---------------------------------------------------------
             * 시간 측정 끝
             *-------------------------------------------------------*/
            sRet = cmnEndTimer( sTimer );
            if ( sRet < 0 )
            {
                printf( "cmnEndTimer Fail [%d]\n", sRet );
                cmnFinalTimer( &sTimer );
                return 1;
            }

            //if ( i % (TEST_COUNT_MIN/10 ) == 0 )
            {
                printf( "count : %d\n", i );
            }

            //usleep ( 100 );
        }

        /*---------------------------------------------------------
         * 통계 결과 print
         *-------------------------------------------------------*/
        sRet = cmnElapseTimer( sTimer, TEST_COUNT_MIN, (char *)"TimerStat Example2 - cmnUSleep(10)" );
        if ( sRet < 0 )
        {
            printf( "cmnElapseTimer Fail [%d]\n", sRet );
            cmnFinalTimer( &sTimer );
            return 1;
        }
    }

    // 단위가 달라질때, TPS 등의 계산이 잘되는지.
    printf( "\nReuse Timer ( UNIT_NANO ) ****\n" );

    if ( 0x01 )
    {

        /*---------------------------------------------------------
         * Timer Handle 할당 및 초기화
         *-------------------------------------------------------*/
        sRet = cmnInitTimer( &sTimer, UNIT_NANO, 10, 10, 10 );
        if ( sRet < 0 )
        {
            printf( "cmnInitTimer Fail [%d]\n", sRet );
            return 1;
        }

        for( i=0; i<TEST_COUNT; i++ )
        {
            /*---------------------------------------------------------
             * 시간 측정 시작
             *-------------------------------------------------------*/
            sRet = cmnStartTimer( sTimer );
            if ( sRet < 0 )
            {
                printf( "cmnStartTimer Fail [%d]\n", sRet );
                cmnFinalTimer( &sTimer );
                return 1;
            }

            //usleep(1 );
            pthread_yield();

            /*---------------------------------------------------------
             * 시간 측정 끝
             *-------------------------------------------------------*/
            sRet = cmnEndTimer( sTimer );
            if ( sRet < 0 )
            {
                printf( "cmnEndTimer Fail [%d]\n", sRet );
                cmnFinalTimer( &sTimer );
                return 1;
            }

            if ( i % (TEST_COUNT/10 ) == 0 )
            {
                printf( "count : %d\n", i );
            }
        }

        /*---------------------------------------------------------
         * 통계 결과 print
         *-------------------------------------------------------*/
        sRet = cmnElapseTimer( sTimer, TEST_COUNT, (char *)"TimerStat Example4 - pthread_yield" );
        if ( sRet < 0 )
        {
            printf( "cmnElapseTimer Fail [%d]\n", sRet );
            cmnFinalTimer( &sTimer );
            return 1;
        }
    }

    /*---------------------------------------------------------
     * Timer Handle 메모리 해제
     *  - 여러번 해제해도 문제없음.
     *-------------------------------------------------------*/
    cmnFinalTimer( &sTimer );
    cmnFinalTimer( &sTimer );
    cmnFinalTimer( &sTimer );

    return 0;
}
