#include "cmnApi.h"


int main()
{
    int rc, i, j, pos = 0;
    int aFD;
    char v1[1024], v2[1024], v3[1024];

    /**************************************************
     * 사용자가 읽고자 하는 설정파일을 연다.
    **************************************************/
    rc = cmnOpenConfig( "config.sample", &aFD );
    DBM_INFO( "openConfig rc=%d", rc );

    /**************************************************
     * 특정Section의 특정Tag를 읽어들일때 사용한다.
    **************************************************/
    rc = cmnReadElement( aFD, (char *)"COMMON", (char *)"path", v1, NULL );
    DBM_INFO( "readElement rc=%d, v=[%s]", rc, v1 );

    rc = cmnReadElement( aFD, (char *)"lim273", (char *)"node", v1, NULL );
    DBM_INFO( "readElement rc=%d, v=[%s]", rc, v1 );

    /**************************************************
     * 특정 Tag의 Value에서 구분자로 여러개가 나열될때..
    **************************************************/
    pos = 0;
    rc = cmnParseFetch( v1, (char *)",", v2, &pos );
    DBM_INFO( "parseWith rc=%d, v=[%s] pos=%d", rc, v2, pos );

    rc = cmnParseFetch( v1, (char *)",", v2, &pos );
    DBM_INFO( "parseWith rc=%d, v=[%s] pos=%d", rc, v2, pos );

    rc = cmnParseFetch( v1, (char *)",", v2, &pos );
    DBM_INFO( "parseWith rc=%d, v=[%s] pos=%d", rc, v2, pos );

    rc = cmnParseFetch( v1, (char *)",", v2, &pos );
    DBM_INFO( "parseWith rc=%d, v=[%s] pos=%d", rc, v2, pos );

    pos = 0;
    rc = cmnParseFetch( v1, (char *)",", v2, &pos );
    DBM_INFO( "repeat: parseWith rc=%d, v=[%s]", rc, v2 );

    /**************************************************
     * 다읽었으면 닫는다.
    **************************************************/
    rc = cmnCloseConfig( &aFD );
    DBM_INFO( "closeConfig rc=%d", rc );


    rc = cmnOpenConfig( (char *)"config.sample", &aFD );
    DBM_INFO( "openConfig rc=%d", rc );

    pos = 0;
    rc = cmnReadElement( aFD, (char *)"topic1", (char *)"post", v1, &pos );
    DBM_INFO( "readElement rc=%d, v=[%s]", rc, v1 );

    pos = 0;
    rc = cmnParseFetch( v1, (char *)":", v2, &pos );
    DBM_INFO( "repeat: parseWith rc=%d, v=[%s]", rc, v2 );

    rc = cmnParseFetch( v1, (char *)":", v2, &pos );
    DBM_INFO( "repeat: parseWith rc=%d, v=[%s]", rc, v2 );

    pos = 0;
    rc = cmnReadElement( aFD, (char *)"topic1", (char *)"type", v1, &pos );
    DBM_INFO( "readElement rc=%d, v=[%s]", rc, v1 );

    pos = 0;
    rc = cmnReadElement( aFD, (char *)"topic1", (char *)"act", v1, &pos );
    DBM_INFO( "readElement rc=%d, v=[%s]", rc, v1 );

    pos = 0;
    rc = cmnParseFetch( v1, (char *)",", v2, &pos );
    DBM_INFO( "repeat: parseWith rc=%d, v=[%s]", rc, v2 );

    rc = cmnParseFetch( v1, (char *)",", v2, &pos );
    DBM_INFO( "repeat: parseWith rc=%d, v=[%s]", rc, v2 );

    pos = 0;
    rc = cmnReadElement( aFD, (char *)"topic1", (char *)"fulltext", v3, &pos );
    DBM_INFO( "readElement rc=%d, v=[%s]", rc, v3 );

    rc = cmnCloseConfig( &aFD );
    DBM_INFO( "closeConfig rc=%d", rc );

    rc = cmnOpenConfig( v3, &aFD );
    DBM_INFO( "openConfig rc=%d", rc );

    j = 0;
    while ( 1 )
    {
        /***********************************************
         * 같은 tag로 있을때 순서대로 읽어들일 수있다.
         * ex) TAG1 = xxx
         *     TAG1 = yyy
         *     위와 같이 TAG1이란 이름으로 여러개일때
         *     0번째는 xxx이고 1번째는 yyy로 리턴된다.
        ***********************************************/
        rc = cmnReadElement( aFD, (char *)"topic1", (char *)"element", v1, &j );
        if ( rc ) break;
        DBM_INFO( "readElement rc=%d, v=[%s]", rc, v1 );

        i = 0;
        /***********************************************
         * value내의 구분자를 다시 순서대로 읽어들일 수있다.
         * ex) TAG1 = a, b, c 라고 설정되었다면
               0번째는 a, 1번째는 b, 2번째는 c가 리턴된다.
        ***********************************************/
        while ( 1 )
        {
            rc = cmnParseFetch( v1, (char *)",", v2, &i );
            if ( rc ) break;
            DBM_INFO( "repeat: parseWith rc=%d, v=[%s]", rc, v2 );
        }
    }

    rc = cmnCloseConfig( &aFD );
    DBM_INFO( "closeConfig rc=%d", rc );


    return 0;
}
