#include "cmnApi.h"

#ifndef SIGUSR1
#define SIGUSR1     10  //윈도포팅
#endif

int bb()
{
    cmnCallStack( SIGUSR1 );

    return 0;
}

void aa()
{
    bb();
}

int main()
{
    long long  i;

    for(i=0; i<512; i++)
    {
        printf("i:[%lld], buddy:[%lld]\n", i, cmnGetBuddy(i));
    }

    printf("\n");
    printf("==> Call Stack\n");
    aa();

    return 0;
}
