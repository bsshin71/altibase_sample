#include "cmnApi.h"


int main()
{
    char sFile[1024];
    char sLicense[1024];
    int  sRC;

    /* invalid file */
    sprintf( sFile, "aadbm.license" );
    memset( sLicense, 0x00, sizeof(sLicense ) );

    sRC = cmnReadLicense( sFile, sLicense );
    DBM_INFO( "read License (invalid) = %d", sRC );

    /* invalid */
    sprintf( sFile, "dbm.license1" );
    memset( sLicense, 0x00, sizeof(sLicense ) );

    sRC = cmnReadLicense( sFile, sLicense );
    sRC = cmnCheckLicense( sLicense );

    DBM_INFO( "Check License (invalid) = %d", sRC );


    /* valid */
    sprintf( sFile, "dbm.license" );
    memset( sLicense, 0x00, sizeof(sLicense ) );

    sRC = cmnReadLicense( sFile, sLicense );
    sRC = cmnCheckLicense( sLicense );

    DBM_INFO( "Check License ( valid) = %d", sRC );
}
