#include "cmnApi.h"

#define TEST_COUNT  100000

int main( int argc, char*argv[] )
{
    int      sRet;
    int      sQueueId = -1;
    char     sPath[2048];
    cmnQData sData;
    int      sLen;
    int      sMsgType;
    int      sRecvedSize;
    int      sSentSize;
    int      sCount = 1;
    long long  sMaxQBytes;
    long long  sCurrentMsgBytes;
    long long  sCurrentMsgCount;

    if ( argc < 3 )
    {
        DBM_INFO( "Usage : %s file_path msg_type",argv[0] );
        return 1;
    }

    memset( sPath, 0x00, sizeof(sPath) );
    strcpy( sPath, argv[1] );
    sMsgType = atoi( argv[2] );

    /*---------------------------------------------------------
    * 메시지큐가 존재한다면 식별자를 받고 존재하지 않으면 생성
    *--------------------------------------------------------*/
    sRet = cmnQueueOpen( &sQueueId, sPath );
    if ( sRet != 0 )
    {
        DBM_INFO( "cmnQueueOpen Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }
    DBM_INFO( "cmnQueueOpen OK. QueueId[%d]", sQueueId );

    /*---------------------------------------------------------
    * Client 로부터의 data 수신
    *--------------------------------------------------------*/
    while ( 1 )
    {
        /*
        cmnQueueState( sQueueId, (long long*)&sMaxQBytes, (long long*)&sCurrentMsgBytes, (long long*)&sCurrentMsgCount );
        if ( sCurrentMsgCount < 1)
        {
            usleep(40 );
            continue;
        }
        DBM_INFO( "[DEBUG-smqsvr] QStatus = QID:%d, MaxQSize:%ld, CurQSize:%ld, CurQCount:%ld", sQueueId, sMaxQBytes, sCurrentMsgBytes, sCurrentMsgCount );
        */
        memset( &sData, 0x00, sizeof(sData) );

        sLen = sizeof(sData.qData );
        switch( sRet = cmnQueueRecv( sQueueId, sMsgType, 0, (char*)&sData, sLen, &sRecvedSize ) )
        {
            /*---------------------------------------------------------
             * data 수신 성공
             *--------------------------------------------------------*/
            case 0:
                if ( sCount == 1)
                {
                    DBM_INFO( "cmnQueueRecv OK. size : [%d:%d], body : (%s)", sLen, sRecvedSize, sData.qData );
                }
                /*---------------------------------------------------------
                 * echo server 이기 때문에 수신한 data 를 그대로
                 * client 에게 전송한다.
                 *--------------------------------------------------------*/
                sRet = cmnQueueSend( sQueueId, sMsgType, (char*)&sData, sLen );
                if ( sRet != 0 )
                {
                    DBM_INFO( "cmnQueueSend Fail. [%d] [%s]", sRet, strerror(errno) );
                    cmnQueueClose( sQueueId );
                    sQueueId = -1;
                }

                /*---------------------------------------------------------
                 * 첫번째 echo 만 좀 찍어보자.
                 *--------------------------------------------------------*/
                if ( sCount == 1)
                {
                    DBM_INFO( "cmnQueueSend OK. size : [%d], body : (%s)", sLen, sData.qData );
                }

                /*---------------------------------------------------------
                 * 천건마다 건수 print
                 *--------------------------------------------------------*/
                if ( sCount % 1000 == 0 ) DBM_INFO( "sCount : %d", sCount );

                if (++sCount > TEST_COUNT)
                {
                    goto end;
                }

                break;

                /*---------------------------------------------------------
                 * data 수신 실패
                 *   - queue 를 닫아서 client 가 다시 접속하도록 유도한다.
                 *--------------------------------------------------------*/
            default:
                DBM_INFO( "cmnQueueRecv Fail. [%d] [%s]", sRet, strerror(errno) );
                cmnQueueClose( sQueueId );
                sQueueId = -1;
                break;
        }
    }

end:
    return 0;
}
