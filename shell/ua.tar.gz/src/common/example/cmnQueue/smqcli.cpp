#include "cmnApi.h"

#define TEST_COUNT  10000

int main( int argc, char*argv[] )
{
    int        sRet;
    int        sQueueId;
    char       sPath[2048];
    cmnQData   sData;
    int        sLen;
    int        sMsgType;
    int        sSentSize   = 0;
    int        sRecvedSize = 0;
    const char* sTestStr    = "this is test string";
    int        sCount      = 1;

    if ( argc < 3 )
    {
        DBM_INFO( "Usage : %s file_path msg_type", argv[0] );
        return 1;
    }

    memset( sPath, 0x00, sizeof(sPath) );
    strcpy( sPath, argv[1] );
    sMsgType = atoi( argv[2] );

    /*---------------------------------------------------------
    * socket 을 생성한 후 server 로 connect 를 시도한다.
    *--------------------------------------------------------*/
CONNECT:
    sRet = cmnQueueOpen( &sQueueId, sPath );
    if ( sRet != 0 )
    {
        DBM_INFO( "cmnQueueOpen Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }
    DBM_INFO( "cmnQueueOpen OK. sock[%d]", sQueueId );

    /*---------------------------------------------------------
    * server 와 연결이 되면 곧바로 첫 packet 을 전송해본다.
    *--------------------------------------------------------*/
    memset( &sData, 0x00, sizeof(sData) );

    sLen = sizeof(sData.qData );
    strcpy( sData.qData, sTestStr );

    sRet = cmnQueueSend( sQueueId, sMsgType, (char*)&sData, sLen );
    if ( sRet < 0 )
    {
        DBM_INFO( "cmnQueueSend Fail. [%d] [%s]", sRet, strerror(errno) );
        /*---------------------------------------------------------
        * Socket 을 끊고 프로그램을 끝낼 것인지 다시 connect 부터
        * 시도할 것인지는 개인의 자유
        *--------------------------------------------------------*/
        sQueueId = -1;
        goto CONNECT;
    }
    DBM_INFO( "cmnQueueSend OK. size : [%d], body : (%s)", sLen, sData.qData );

    /*---------------------------------------------------------
    * Server 로부터의 data 수신
    *--------------------------------------------------------*/
    while ( 1 )
    {
        memset( &sData, 0x00, sizeof(sData) );

        switch( sRet = cmnQueueRecv( sQueueId, sMsgType, 0, (char*)&sData, sLen, &sRecvedSize ) )
        {
            /*---------------------------------------------------------
             * data 수신 성공
             *--------------------------------------------------------*/
            case 0:
                /*---------------------------------------------------------
                 * 첫번째 echo 만 좀 찍어보자.
                 *--------------------------------------------------------*/
                if ( sCount == 1)
                {
                    DBM_INFO( "cmnQueueRecv OK. size : [%d:%d], body : (%s)", sLen, sRecvedSize, sData.qData );
                }

                /*---------------------------------------------------------
                 * 천건마다 건수 print
                 *--------------------------------------------------------*/
                if ( sCount % 1000 == 0 ) DBM_INFO( "sCount : %d", sCount );

                if ( ++sCount > TEST_COUNT )
                {
                    goto end;
                }

                sRet = cmnQueueSend( sQueueId, sMsgType, (char*)&sData, sLen );
                if ( sRet != 0 )
                {
                    DBM_INFO( "cmnQueueSend Fail. [%d] [%s]", sRet, strerror(errno) );
                    cmnQueueClose( sQueueId );
                    sQueueId = -1;
                    exit(1 );
                }
                /*
                   DBM_INFO( "cmnQueueSend OK. size : [%d] body : (%s)", sLen, sData.qData );
                 */

                break;
                /*---------------------------------------------------------
                 * data 수신 실패
                 *--------------------------------------------------------*/
            default:
                DBM_INFO( "cmnQueueRecv Fail. [%d] [%s]", sRet, strerror(errno) );
                cmnQueueClose( sQueueId );
                sQueueId = -1;
                break;
        }
    }

end:
    return 0;
}
