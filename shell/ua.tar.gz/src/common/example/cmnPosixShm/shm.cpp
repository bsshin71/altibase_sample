#include "cmnApi.h"

typedef struct testStruct
{
    long long   mKey;
    char        mVal[20];
}testStruct;

int main()
{
    int         i;
#ifdef __linux__
    char*       sKeyFile = (char *)"my_shm_key";
#else
    char*       sKeyFile = (char *)"my_shm_key";
//  char*       sKeyFile = (char *)"c:\\my_shm_key";
//  char*       sKeyFile = (char *)"Global\\my_shm_key";
#endif
    int         sShmSize = 10 * sizeof( testStruct );
    void*       sShmPtr = NULL;
    int         sRet;
    testStruct* sPtr;
    int         sShmID, sAttachNum;
    int         sLinkCount = -1;

    /*---------------------------------------------------------
     * sKeyFile 를 이용하여 Shm Key 를 생성
     *   ( sKeyFile 는 실제 존재하는 File 이름을 주어야 한다.)
     *-------------------------------------------------------*/
    sRet = cmnPShmCreate ( sKeyFile, sShmSize );
    if ( sRet != 0 )
    {
        /*---------------------------------------------------------
         * sRet 값에 따라 cmnPShmCreate 의 어느 단계에서 에러가
         * 발생했는지 파악할 수 있다.
         * 좀더 정확한 error message 는 errno 의 string 을 찍어보면 된다.
         *-------------------------------------------------------*/
        DBM_INFO( "cmnPShmCreate Fail [%d] (err=%d)", sRet, errno );
        return 1;
    }
    DBM_INFO( "cmnPShmCreate OK. key_path[%s] shm_size[%d]", sKeyFile, sShmSize );

    /*---------------------------------------------------------
     * attach to created shm segment
     *-------------------------------------------------------*/
    sRet = cmnPShmAttach( sKeyFile, sShmSize, &sShmPtr );
    if ( sRet != 0 )
    {
        DBM_INFO( "cmnPShmAttach Fail [%d] (err=%d)", sRet, errno );
        return 1;
    }
    DBM_INFO( "cmnPShmAttach OK" );

    memset( sShmPtr, 0x00, sShmSize );

    /*---------------------------------------------------------
     * save some information in shm segment
     *-------------------------------------------------------*/
    sPtr = ( testStruct *)sShmPtr;

    for( i = 0; i < 10; i++ )
    {
        sPtr->mKey = (long long)i;
        sprintf( sPtr->mVal, "%20d", i );

        sPtr++;
    }

#ifdef __linux__    //TODO: [OKT] 윈도포팅
    /*---------------------------------------------------------
     * get attach num to shm
     *-------------------------------------------------------*/
    sRet = cmnPShmGetAttachNum(sKeyFile, &sLinkCount);
    if( sRet != 0 )
    {
        DBM_INFO( "cmnPShmGetAttachNum Fail [%d] (err=%d)", sRet, errno );
        return 1;
    }
    DBM_INFO( "cmnPShmGetAttachNum OK [%d]", sLinkCount );
#endif /* __linux__ */

    /*---------------------------------------------------------
     * detach from shm segment
     *-------------------------------------------------------*/
    sRet = cmnPShmDetach( &sShmPtr, sShmSize );
    if ( sRet != 0 )
    {
        DBM_INFO( "cmnPShmDetach Fail [%d] (err=%d)", sRet, errno );
        return 1;
    }
    DBM_INFO( "cmnPShmDetach OK" );

    /*---------------------------------------------------------
     * attach to shm segment again
     *-------------------------------------------------------*/
    sRet = cmnPShmAttach( sKeyFile, sShmSize, &sShmPtr );
    if ( sRet != 0 )
    {
        DBM_INFO( "cmnPShmAttach Again Fail [%d] (err=%d)", sRet, errno );
        return 1;
    }
    DBM_INFO( "cmnPShmAttach Again OK" );

    /*---------------------------------------------------------
     * show saved information in shm segment
     *-------------------------------------------------------*/
    sPtr = (testStruct*)sShmPtr;

    for( i = 0; i < 10; i++ )
    {
        DBM_INFO( "    key[%ld] val[%s]", sPtr->mKey, sPtr->mVal);

        sPtr++;
    }

    /*---------------------------------------------------------
     * drop(remove) shm segment
     *-------------------------------------------------------*/
    sRet = cmnPShmDrop( sKeyFile );
    if ( sRet != 0 )
    {
        DBM_INFO( "cmnPShmDrop Fail [%d] (err=%d)", sRet, errno );
        return 1;
    }
    DBM_INFO( "cmnPShmDrop OK" );

    return 0;
}
