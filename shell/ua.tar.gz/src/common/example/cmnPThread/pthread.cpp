#include "cmnApi.h"

void* thr_func( void* aArg )
{
    short   sCpu = *(short*)aArg;

    DBM_INFO( "thr[%ld] : cpu[%d]", pthread_self(), sCpu);

    /*---------------------------------------------------------
     * htop 을 통해 각 thread 가 실제로 1 번과 2 번 cpu 를
     * 100 % 사용하는지 확인한다.
     *-------------------------------------------------------*/
    while( 1 )
    {
    }

    return NULL;
}

int main()
{
    int        sRet;
    short      sFirstCpu;
    int        sSecondCpu;
    pthread_t  sFirstThread;
    pthread_t  sSecondThread;

    /*---------------------------------------------------------
     * 첫번째 thread 를 생성하면서 곧바로 cpu 1 번에 할당
     *-------------------------------------------------------*/
    sFirstCpu = 1;
    sRet = cmnCreateThread( &sFirstThread,
                            sFirstCpu,
                            NULL,
                            thr_func,
                            (void*)&sFirstCpu );
    if ( sRet < 0 )
    {
        DBM_INFO( "First cmnCreateThread Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }
    DBM_INFO( "First cmnCreateThread OK." );

    /*---------------------------------------------------------
     * 두번째 thread 생성
     *-------------------------------------------------------*/
    sSecondCpu = -1;
    sRet = cmnCreateThread( &sSecondThread,
                            sSecondCpu,
                            NULL,
                            thr_func,
                            (void*)&sSecondCpu );
    if ( sRet < 0 )
    {
        DBM_INFO( "Second cmnCreateThread Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }
    DBM_INFO( "Second cmnCreateThread OK." );

    /*---------------------------------------------------------
     * 생성한 두번째 thread 를 2 번 cpu 에 할당
     *-------------------------------------------------------*/
    sSecondCpu = 2;
    sRet = cmnSetThrAffinity( &sSecondThread,
                              sSecondCpu );
    if ( sRet < 0 )
    {
        DBM_INFO( "Second cmnSetThrAffinity Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }

    sleep( 5 );

    return 0;
}
