#include <pthread.h>

#include "cmnApi.h"

sem_t  sem;

void* thr1( void* param )
{
    int rc;

    DBM_INFO( "thr-%ld: wait.............", pthread_self() );
    /*rc = cmnSemWait( &sem, 0, 0 );*/
    rc = cmnSemWait( &sem, 0, 10000000 );
    DBM_INFO( "thr-%ld: semwait rc = %d", pthread_self(), rc );

    return NULL;
}




int main()
{
    PHTIMER sTimer;
    pthread_t tid[2];
    int rc, i;


    rc = cmnSemInit( &sem, 0, 0 );
    DBM_INFO( "SemInit rc = %d", rc );

    pthread_create( &tid[0], NULL, thr1, NULL );
    pthread_create( &tid[1], NULL, thr1, NULL );

    DBM_INFO( "2thread wait posting. after 5second, call sempost from main-thread." );
    sleep( 5 );
    rc = sem_post( &sem );
    DBM_INFO( "semPost rc = %d", rc );

    pthread_join( tid[1], NULL );
    pthread_join( tid[0], NULL );

    cmnInitTimer( &sTimer, UNIT_NANO, 10, 30, 20 );

    for ( i=0; i<100000; i++ )
    {
        cmnStartTimer( sTimer );
        rc = cmnSemPost( &sem );
        rc = cmnSemWait( &sem, 0, 1000000 );
        cmnEndTimer( sTimer );
    }

    cmnElapseTimer( sTimer, 100000, (char *)"Semaphore Test" );

    rc = cmnSemDrop( &sem );
    DBM_INFO( "SemDrop rc = %d", rc );

    return 0;
}
