#include "cmnApi.h"

#define TEST_COUNT  10000

int main( int argc, char*argv[] )
{
    int             sRet;
    int             sSockFd = -1;
    char            sRecvPath[2048];
    char            sSendPath[2048];
    char            sBuf[2048];
    fd_set          sFD;
    int             sLen;
    int             sNonBlockF  = 1;
    int             sSentSize   = 0;
    int             sRecvedSize = 0;
    const char*     sTestStr = "this is test string";
    struct timeval  sTimeout;
    int             sCount = 1;

    if ( argc < 3 )
    {
        DBM_PRT( "Usage : %s recv_file_path send_file_path", argv[0] );
        return 1;
    }

    memset( sRecvPath, 0x00, sizeof(sRecvPath) );
    strcpy( sRecvPath, argv[1] );
    memset( sSendPath, 0x00, sizeof(sSendPath) );
    strcpy( sSendPath, argv[2] );

    if ( access( sRecvPath, F_OK) == 0 )
    {
        unlink( sRecvPath );
    }

CONNECT:
    /*---------------------------------------------------------
    * socket 을 생성한 후 server 로 connect 를 시도한다.
    sRet = cmnUdsConnect( &sSockFd, sPath, 1, -1 );
    *--------------------------------------------------------*/
    sRet = cmnUdsOpen( &sSockFd, sRecvPath, 1, -1 );
    /*
    sSockFd = socket(PF_UNIX, SOCK_DGRAM, 0 );
    struct sockaddr_un sUnSock;
    memset((char*)&sUnSock, 0x00, sizeof(struct sockaddr_un) );
    sUnSock.sun_family = PF_UNIX;
    strcpy( sUnSock.sun_path, sPath );
    */
    if ( sRet != 0 )
    {
        DBM_PRT( "cmnUdsOpen Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }
    DBM_PRT( "cmnUdsOpen OK. sock[%d]", sSockFd );

    /*---------------------------------------------------------
    * server 와 연결이 되면 곧바로 첫 packet 을 전송해본다.
    * 반드시 맨앞 4 byte 는 전송할 data 길이
    *--------------------------------------------------------*/
    memset( &sBuf, 0x00, sizeof(sBuf) );

    sLen = sizeof(sBuf);
    memcpy( sBuf, &sLen, sizeof(int) );
    strcpy( sBuf + sizeof(int), sTestStr );

    sRet = cmnUdsSendTo( sSockFd, sSendPath, (char*)&sBuf, sizeof(sBuf), &sSentSize );
    if ( sRet != 0 )
    {
        DBM_PRT( "cmnUdsSendTo Fail. [%d] sentsize[%d] [%s]", sRet, sSentSize, strerror(errno) );
        /*---------------------------------------------------------
        * Socket 을 끊고 프로그램을 끝낼 것인지 다시 connect 부터
        * 시도할 것인지는 개인의 자유
        *--------------------------------------------------------*/
        cmnUdsClose( sSockFd );
        sSockFd = -1;
        goto CONNECT;
    }
    DBM_PRT( "cmnUdsSendTo OK. size : [%d:%d] body : (%s)", *((int*)sBuf), sSentSize, sBuf + sizeof(int) );

    /*---------------------------------------------------------
    * Server 로부터의 data 수신
    *--------------------------------------------------------*/
    while ( 1 )
    {
        sTimeout.tv_sec  = 1;
        sTimeout.tv_usec = 0;

        memset( &sBuf, 0x00, sizeof(sBuf) );

        FD_ZERO( &sFD );
        if ( sSockFd > 0 )
        {
            FD_SET( sSockFd, &sFD );
        }
        DBM_DBG( "[DEBUG-1-1] [%d] sSockFd",sSockFd );
        /*---------------------------------------------------------
        * 등록한 socket 에 대해 event 대기
        *--------------------------------------------------------*/
        if (( sRet = select( FD_SETSIZE, &sFD, NULL, NULL, &sTimeout) ) <= 0 )
        {
            continue;
        }

        /*---------------------------------------------------------
        * Server 로부터의 data 수신 처리
        if ( sSockFd > 0 )
        *--------------------------------------------------------*/
        if ( sSockFd > 0 && FD_ISSET( sSockFd, &sFD ) )
        {
            switch( sRet = cmnUdsRecvFrom( sSockFd, sRecvPath, (char*)&sBuf, sizeof(sBuf), &sRecvedSize ) )
            {
                /*---------------------------------------------------------
                 * data 수신 성공
                 *-------------------------------------------------------*/
                case 0:
                    /*---------------------------------------------------------
                     * 첫번째 echo 만 좀 찍어보자.
                     *-------------------------------------------------------*/
                    if ( sCount == 1)
                    {
                        DBM_PRT( "cmnUdsRecvFrom OK. size : [%d:%d], body : (%s)", *((int*)sBuf), sRecvedSize, sBuf + sizeof(int) );
                    }

                    /*---------------------------------------------------------
                     * 천건마다 건수 print
                     *-------------------------------------------------------*/
                    if ( sCount % 1000 == 0 ) DBM_PRT( "sCount : %d", sCount );

                    if (++sCount > TEST_COUNT)
                    {
                        goto end;
                    }

                    sRet = cmnUdsSendTo( sSockFd, sSendPath, (char*)&sBuf, sizeof(sBuf), &sSentSize );
                    if ( sRet != 0 )
                    {
                        DBM_PRT( "cmnUdsSendTo Fail. [%d] [%s]", sRet, strerror(errno) );
                        cmnUdsClose( sSockFd );
                        sSockFd = -1;
                        exit(1 );
                    }
                    /*
                    DBM_PRT( "cmnUdsSend OK. size : [%d:%d] body : (%s)", *(int*)sBuf, sSentSize, sBuf + sizeof(int) );
                    */

                    break;
                /*---------------------------------------------------------
                 * data 수신 실패
                 *-------------------------------------------------------*/
                default:
                    DBM_PRT( "cmnUdsRecvFrom Fail. [%d] [%s]", sRet, strerror(errno) );
                    DBM_DBG( "[DEBUG-1-2] [%d] %s",sRet, strerror(errno) );
                    cmnUdsClose( sSockFd );
                    sSockFd = -1;
                    break;
            }
        }
    }

end:
    unlink( sRecvPath );
    return 0;
}
