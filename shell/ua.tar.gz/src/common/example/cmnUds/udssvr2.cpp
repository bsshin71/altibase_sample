#include "cmnApi.h"

#define TEST_COUNT  30000

int main( int argc, char*argv[] )
{
    int            sRet;
    int            sSockFd = -1;
    char           sRecvPath[2048];
    char           sSendPath[2048];
    char           sBuf[2048];
    fd_set         sFD;
    int            sNonBlockF  = 1;
    int            sSentSize   = 0;
    int            sRecvedSize = 0;
    struct timeval sTimeout;
    int            sCount = 1;

    if ( argc < 3 )
    {
        DBM_PRT( "Usage : %s recv_file_path send_file_path", argv[0] );
        return 1;
    }

    memset( sRecvPath, 0x00, sizeof(sRecvPath) );
    strcpy( sRecvPath, argv[1] );
    memset( sSendPath, 0x00, sizeof(sSendPath) );
    strcpy( sSendPath, argv[2] );

    if ( access( sRecvPath, F_OK ) == 0 )
    {
        unlink( sRecvPath );
    }

    /*---------------------------------------------------------
    * Listen Socket 을 생성한다.
    *--------------------------------------------------------*/
    sRet = cmnUdsOpen( &sSockFd, sRecvPath, 1, -1 );
    if ( sRet != 0 )
    {
        DBM_PRT( "cmnUdsOpen Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }
    DBM_PRT( "cmnUdsOpen OK. sock[%d]", sSockFd );

    /*---------------------------------------------------------
    * Client 로부터의 connect 처리 및 data 수신
    *--------------------------------------------------------*/
    while ( 1 )
    {
        sTimeout.tv_sec  = 1;
        sTimeout.tv_usec = 0;

        memset( &sBuf, 0x00, sizeof(sBuf) );

        FD_ZERO( &sFD );
        FD_SET( sSockFd, &sFD );
        if ( sSockFd > 0 )
        {
            FD_SET( sSockFd, &sFD );
        }

        /*---------------------------------------------------------
        * 등록한 socket 에 대해 event 대기
        *--------------------------------------------------------*/
        if (( sRet = select( FD_SETSIZE, &sFD, NULL, NULL, &sTimeout ) ) <= 0 )
        {
            usleep( 40 );
            continue;
        }

        /*---------------------------------------------------------
        * client 로부터의 connect event 처리
        if ( FD_ISSET( sSockFd, &sFD ) )
        {
        *--------------------------------------------------------*/
            /*---------------------------------------------------------
            * 기존에 열린 것이 있으면 닫는다.
            if ( sAcceptSock > 0 )
            {
#ifdef _DEBUG
    DBM_PRT( "[DEBUG-1-2] [%d] already accept",sAcceptSock );
#endif
                cmnUdsClose( sAcceptSock );
                sAcceptSock = -1;
            }

            sRet = cmnUdsAccept( sSockFd, &sAcceptSock, -1 );
            if ( sRet != 0 )
            {
                DBM_PRT( "cmnUdsAccept Fail [%d] [%s]", sRet, strerror(errno) );
                usleep( 40 );
                continue;
            }
        }
            *--------------------------------------------------------*/

        /*---------------------------------------------------------
        * client 로부터의 data 수신 처리
        if ( sAcceptSock > 0 )
        * -------------------------------------------------------*/
        DBM_DBG( "[DEBUG-1-1] [%d]", sSockFd );
        if ( sSockFd > 0 && FD_ISSET( sSockFd, &sFD ) )
        {
            switch( sRet = cmnUdsRecvFrom( sSockFd, sRecvPath, (char*)&sBuf, sizeof(sBuf), &sRecvedSize ) )
            {
                /*---------------------------------------------------------
                * data 수신 성공
                *--------------------------------------------------------*/
                case 0:
                    DBM_DBG( "[DEBUG-1-4] [%d]",sRecvedSize );
                    if ( sCount == 1)
                    {
                        DBM_PRT( "cmnUdsRecvFrom OK. size : [%d:%d], body : (%s)", *((int*)sBuf), sRecvedSize, sBuf + sizeof(int) );
                    }
                    /*---------------------------------------------------------
                    * echo server 이기 때문에 수신한 data 를 그대로
                    * client 에게 전송한다.
                    *--------------------------------------------------------*/
                    sRet = cmnUdsSendTo( sSockFd, sSendPath, (char*)&sBuf, sizeof(sBuf), &sSentSize );
                    if ( sRet != 0 )
                    {
                        DBM_PRT( "cmnUdsSendTo Fail. [%d] [%s]", sRet, strerror(errno) );
                        cmnUdsClose( sSockFd );
                    }

                    /*---------------------------------------------------------
                    * 첫번째 echo 만 좀 찍어보자.
                    *--------------------------------------------------------*/
                    if ( sCount == 1)
                    {
                        DBM_PRT( "cmnUdsSendTo OK. size : [%d:%d] body : (%s)", *((int*)sBuf), sSentSize, sBuf + sizeof(int) );
                    }

                    /*---------------------------------------------------------
                    * 천건마다 건수 print
                    *--------------------------------------------------------*/
                    if ( sCount % 1000 == 0 ) DBM_PRT( "sCount : %d", sCount );

                    if (++sCount > TEST_COUNT)
                    {
                        goto end;
                    }

                    break;

                /*---------------------------------------------------------
                * data 수신 실패
                *   - socket 을 닫아서 client 가 다시 접속하도록 유도한다.
                *--------------------------------------------------------*/
                default:
                    DBM_PRT( "cmnUdsRecvFrom Fail. [%d] [%s]", sRet, strerror(errno) );
                    cmnUdsClose( sSockFd );
                    sSockFd = -1;
                    break;
            }
        }
    }

end:
    unlink( sRecvPath );
    return 0;
}
