#include "cmnApi.h"

#define TEST_COUNT  10000

int main( int argc, char*argv[] )
{
    int             sRet;
    int             sSockFd;
    int             sLen;
    int             sSentSize   = 0;
    int             sRecvedSize = 0;
    const char*     sTestStr = "this is test string";
    fd_set          sFD;
    char            sPath[2048];
    char            sBuf[2048];
    struct timeval  sTimeout;
    int             sCount = 1;

    if ( argc < 2 )
    {
        DBM_PRT( "Usage : %s file_path", argv[0] );
        return 1;
    }

    memset( sPath, 0x00, sizeof(sPath) );
    strcpy( sPath, argv[1] );

    /*---------------------------------------------------------
    * socket 을 생성한 후 server 로 connect 를 시도한다.
    *--------------------------------------------------------*/
CONNECT:
    sRet = cmnUdsConnect( &sSockFd, sPath, 1, -1 );
    if ( sRet != 0 )
    {
        DBM_PRT( "cmnUdsConnect Fail [%d] [%s]", sRet, strerror(errno) );
        return 1;
    }
    DBM_PRT( "cmnUdsConnect OK. sock[%d]", sSockFd );

    /*---------------------------------------------------------
    * server 와 연결이 되면 곧바로 첫 packet 을 전송해본다.
    * 반드시 맨앞 4 byte 는 전송할 data 길이
    *--------------------------------------------------------*/
    memset( &sBuf, 0x00, sizeof(sBuf) );

    sLen = sizeof(sBuf);
    memcpy( sBuf, &sLen, sizeof(int) );
    strcpy( sBuf + sizeof(int), sTestStr );

    sRet = cmnUdsSend( sSockFd, (char*)&sBuf, sizeof(sBuf), &sSentSize );
    if ( sRet != 0 )
    {
        DBM_PRT( "cmnUdsSend Fail. [%d] sentsize[%d] [%s]", sRet, sSentSize, strerror(errno) );
        /*---------------------------------------------------------
        * Socket 을 끊고 프로그램을 끝낼 것인지 다시 connect 부터
        * 시도할 것인지는 개인의 자유
        *--------------------------------------------------------*/
        cmnUdsClose( sSockFd );
        sSockFd = -1;
        goto CONNECT;
    }

    DBM_PRT( "cmnUdsSend OK. size : [%d:%d], body : (%s)", *((int*)sBuf), sSentSize, sBuf + sizeof(int) );

    /*---------------------------------------------------------
    * Server 로부터의 data 수신
    *--------------------------------------------------------*/
    while ( 1 )
    {
        sTimeout.tv_sec  = 1;
        sTimeout.tv_usec = 0;

        memset( &sBuf, 0x00, sizeof(sBuf) );

        FD_ZERO( &sFD );
        if ( sSockFd > 0 )
        {
            FD_SET( sSockFd, &sFD );
        }
    DBM_DBG( "[DEBUG-1-1] [%d] sSockFd",sSockFd );

        /*---------------------------------------------------------
        * 등록한 socket 에 대해 event 대기
        *--------------------------------------------------------*/
        if (( sRet = select( FD_SETSIZE, &sFD, NULL, NULL, &sTimeout) ) <= 0 )
        {
            continue;
        }

        /*---------------------------------------------------------
        * Server 로부터의 data 수신 처리
        if ( sSockFd > 0 )
        *--------------------------------------------------------*/
        if ( sSockFd > 0 && FD_ISSET( sSockFd, &sFD ) )
        {
            switch( sRet = cmnUdsRecv( sSockFd, (char*)&sBuf, &sRecvedSize ) )
            {
                /*---------------------------------------------------------
                 * data 수신 성공
                 *-------------------------------------------------------*/
                case 0:
                    /*---------------------------------------------------------
                     * 첫번째 echo 만 좀 찍어보자.
                     *-------------------------------------------------------*/
                    if ( sCount == 1)
                    {
                        DBM_PRT( "cmnUdsRecv OK. size : [%d:%d], body : (%s)", *((int*)sBuf), sRecvedSize, sBuf + sizeof(int) );
                    }

                    /*---------------------------------------------------------
                     * 천건마다 건수 print
                     *-------------------------------------------------------*/
                    if ( sCount % 1000 == 0 ) DBM_PRT( "sCount : %d", sCount );

                    if (++sCount > TEST_COUNT)
                    {
                        goto end;
                    }

                    sRet = cmnUdsSend( sSockFd, (char*)&sBuf, sizeof(sBuf), &sSentSize );
                    if ( sRet != 0 )
                    {
                        DBM_PRT( "cmnUdsSend Fail. [%d] [%s]", sRet, strerror(errno) );
                        cmnUdsClose( sSockFd );
                        sSockFd = -1;
                        exit(1 );
                    }
                    /*
                    DBM_PRT( "cmnUdsSend OK. size : [%d:%d] body : (%s)", *(int*)sBuf, sSentSize, sBuf + sizeof(int) );
                    */

                    break;
                /*---------------------------------------------------------
                 * data 수신 실패
                 *-------------------------------------------------------*/
                default:
                    DBM_PRT( "cmnUdsRecv Fail. [%d] [%s]", sRet, strerror(errno) );
                    cmnUdsClose( sSockFd );
                    sSockFd = -1;
                    break;
            }
        }
    }

end:
    return 0;
}
