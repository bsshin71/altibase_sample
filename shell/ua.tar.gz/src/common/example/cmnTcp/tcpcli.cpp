#include "cmnApi.h"

#define TEST_COUNT  100000

int main( int argc, char*argv[] )
{
    int             sRet;
    int             sSockFd;
    int             sLen;
    int             sSentSize   = 0;
    int             sRecvedSize = 0;
    const char*     sTestStr = "this is sock test";
    fd_set          sFD;
    char            sBuf[2048];
    struct timeval  sTimeout;
    int             sCount = 0;

    if ( argc < 3 )
    {
        printf( "Usage : %s server_ip port_no\n", argv[0] );
        return 1;
    }

    /*---------------------------------------------------------
     * socket 을 생성한 후 server 로 connect 를 시도한다.
     *-------------------------------------------------------*/
CONNECT:
    //sRet = cmnTcpConnect( &sSockFd, argv[1], atoi( argv[2]), -1, 3, -1 );
    sRet = cmnTcpConnect( &sSockFd, argv[1], atoi( argv[2]), -1 ); //, 3, -1 );
    if ( sRet != 0 )
    {
        printf( "cmnTcpConnect Fail [%d] [%s]\n", sRet, strerror(errno) );
        return 1;
    }
    printf( "cmnTcpConnect OK. sock[%d]\n", sSockFd );

    /*---------------------------------------------------------
     * server 와 연결이 되면 곧바로 첫 packet 을 전송해본다.
     * 반드시 맨앞 4 byte 는 전송할 data 길이
     *-------------------------------------------------------*/
    memset( &sBuf, 0x00, sizeof(sBuf) );

    sLen = strlen(sTestStr) + sizeof(int);
    memcpy(sBuf, &sLen, sizeof(int));
    strcpy(sBuf+sizeof(int), sTestStr);

    sRet = cmnTcpSend( sSockFd, (char*)&sBuf, sLen, &sSentSize );
    if ( sRet != 0 )
    {
        printf( "cmnTcpSend Fail. [%d] sentsize[%d] [%s]\n", sRet, sSentSize, strerror(errno) );
        /*---------------------------------------------------------
         * Socket 을 끊고 프로그램을 끝낼 것인지 다시 connect 부터
         * 시도할 것인지는 개인의 자유
         *-------------------------------------------------------*/
        cmnTcpClose( sSockFd );
        sSockFd = -1;
        goto CONNECT;
    }

    printf( "cmnTcpSend OK. size : [%d:%d] body : (%s)\n",
            *((int*)sBuf), sSentSize, sBuf + sizeof(int) );

    /*---------------------------------------------------------
     * Server 로부터의 data 수신
     *-------------------------------------------------------*/
    while ( 1 )
    {
        sTimeout.tv_sec  = 1;
        sTimeout.tv_usec = 0;

        memset( &sBuf, 0x00, sizeof(sBuf) );

        FD_ZERO( &sFD );
        if ( sSockFd > 0 )
        {
            FD_SET( sSockFd, &sFD );
        }

        /*---------------------------------------------------------
         * 등록한 socket 에 대해 event 대기
         *-------------------------------------------------------*/
        if ( ( sRet = select( FD_SETSIZE, &sFD, NULL, NULL, &sTimeout) ) <= 0 )
        {
            continue;
        }

        /*---------------------------------------------------------
         * Server 로부터의 data 수신 처리
         *-------------------------------------------------------*/
        if ( sSockFd > 0 && FD_ISSET( sSockFd, &sFD ) )
        {
            switch( sRet = cmnTcpRecv( sSockFd, (char*)&sBuf, 10, &sRecvedSize ) )
            {
                /*---------------------------------------------------------
                 * data 수신 성공
                 *-------------------------------------------------------*/
                case 0:
                    if ( ++sCount > TEST_COUNT )
                    {
                        goto end;
                    }

                    /*---------------------------------------------------------
                     * 첫번째 echo 만 좀 찍어보자.
                     *-------------------------------------------------------*/
                    if ( sCount == 1 )
                    {
                        printf( "cmnTcpRecv OK. size : [%d:%d], body : (%s)\n",
                                *((int*)sBuf), sRecvedSize, sBuf + sizeof(int) );
                    }

                    /*---------------------------------------------------------
                     * 만건마다 건수 print
                     *-------------------------------------------------------*/
                    if ( sCount % 10000 == 0 ) printf( "sCount : %d\n", sCount );

                    sRet = cmnTcpSend( sSockFd, (char*)&sBuf, sRecvedSize, &sSentSize );
                    if ( sRet != 0 )
                    {
                        printf( "cmnTcpSend Fail. [%d] [%s]\n", sRet, strerror(errno) );
                        cmnTcpClose( sSockFd );
                        sSockFd = -1;
                        exit(1 );
                    }
                    /*
                    printf( "cmnTcpSend OK. size : [%d:%d] body : (%s)\n",
                            *(int*)sBuf, sSentSize, sBuf + sizeof(int) );
                    */

                    break;
                /*---------------------------------------------------------
                 * data 수신 실패
                 *-------------------------------------------------------*/
                default:
                    printf( "cmnTcpRecv Fail. [%d] [%s]\n", sRet, strerror(errno) );
                    cmnTcpClose( sSockFd );
                    sSockFd = -1;
                    break;
            }
        }
    }

end:
    return 0;
}
