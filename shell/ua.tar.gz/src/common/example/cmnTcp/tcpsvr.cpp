#include "cmnApi.h"

#define TEST_COUNT  100000

int main( int argc, char*argv[] )
{
    int     sRet;
    int     sListenSock = -1;
    int     sAcceptSock = -1;
    int     sPortNo;
    fd_set  sFD;
    int     sNonBlockF = 1;
    int     sRecvedSize;
    int     sSentSize;
    char    sBuf[2048];
    struct timeval sTimeout;
    int     sCount = 0;

    if ( argc < 2 )
    {
        printf( "Usage : %s port_no\n", argv[0] );
        return 1;
    }

    sPortNo = atoi( argv[1] );

    /*---------------------------------------------------------
     * Listen Socket 을 생성한다.
     *-------------------------------------------------------*/
    //sRet = cmnTcpServerOpen( &sListenSock, sPortNo, -1, -1 );
    sRet = cmnTcpServerOpen( &sListenSock, sPortNo, -1 ); //, -1 );
    if ( sRet != 0 )
    {
        printf( "cmnTcpServerOpen Fail [%d] [%s]\n", sRet, strerror(errno) );
        return 1;
    }
    printf( "cmnTcpServerOpen OK. sock[%d]\n", sListenSock );

    /*---------------------------------------------------------
     * Client 로부터의 connect 처리 및 data 수신
     *-------------------------------------------------------*/
    sCount = 0;
    while ( 1 )
    {
        sTimeout.tv_sec  = 1;
        sTimeout.tv_usec = 0;

        memset( &sBuf, 0x00, sizeof(sBuf) );

        FD_ZERO( &sFD );
        FD_SET( sListenSock, &sFD );
        if ( sAcceptSock > 0 )
        {
            FD_SET( sAcceptSock, &sFD );
        }

        /*---------------------------------------------------------
         * 등록한 socket 에 대해 event 대기
         *-------------------------------------------------------*/
        if ( ( sRet = select( FD_SETSIZE, &sFD, NULL, NULL, &sTimeout) ) <= 0 )
        {
            usleep(40 );
            continue;
        }

        /*---------------------------------------------------------
         * client 로부터의 connect event 처리
         *-------------------------------------------------------*/
        if ( FD_ISSET( sListenSock, &sFD ) )
        {
            /*---------------------------------------------------------
             * 기존에 열린 것이 있으면 닫는다.
             *-------------------------------------------------------*/
            if ( sAcceptSock > 0 )
            {
                cmnTcpClose( sAcceptSock );
                sAcceptSock = -1;
            }

            sRet = cmnTcpAccept( sListenSock, &sAcceptSock, -1 );
            if ( sRet != 0 )
            {
                printf( "cmnTcpAccept Fail [%d] [%s]\n", sRet, strerror(errno) );
                usleep(40 );
                continue;
            }
            printf( "cmnTcpAccept OK. sock[%d]\n", sAcceptSock );
        }

        /*---------------------------------------------------------
         * client 로부터의 data 수신 처리
         *-------------------------------------------------------*/
        if ( sAcceptSock > 0 && FD_ISSET( sAcceptSock, &sFD ) )
        {
            switch( sRet = cmnTcpRecv( sAcceptSock, (char*)&sBuf, 10, &sRecvedSize ) )
            {
                /*---------------------------------------------------------
                 * data 수신 성공
                 *-------------------------------------------------------*/
                case 0 :
                    /*
                    printf( "cmnTcpRecv OK. size : [%d:%d], body : (%s)\n",
                            *(int*)sBuf, sRecvedSize, sBuf + sizeof(int) );
                    */

                    /*---------------------------------------------------------
                     * echo server 이기 때문에 수신한 data 를 그대로
                     * client 에게 전송한다.
                     *-------------------------------------------------------*/
                    sRet = cmnTcpSend( sAcceptSock, (char*)&sBuf, sRecvedSize, &sSentSize );
                    if ( sRet != 0 )
                    {
                        printf( "cmnTcpSend Fail. [%d] [%s]\n", sRet, strerror(errno) );
                        cmnTcpClose( sAcceptSock );
                        sAcceptSock = -1;
                    }

                    if ( ++sCount > TEST_COUNT )
                    {
                        goto end;
                    }

                    /*---------------------------------------------------------
                     * 첫번째 echo 만 좀 찍어보자.
                     *-------------------------------------------------------*/
                    if ( sCount == 1 )
                    {
                        printf( "cmnTcpSend OK. size : [%d:%d] body : (%s)\n",
                                *((int*)sBuf), sSentSize, sBuf + sizeof(int) );
                    }

                    /*---------------------------------------------------------
                     * 만건마다 건수 print
                     *-------------------------------------------------------*/
                    if ( sCount % 10000 == 0 ) printf( "sCount : %d\n", sCount );
                    break;
                /*---------------------------------------------------------
                 * data 수신 실패
                 *   - socket 을 닫아서 client 가 다시 접속하도록 유도한다.
                 *-------------------------------------------------------*/
                default:
                    printf( "cmnTcpRecv Fail. [%d] [%s]\n", sRet, strerror(errno) );
                    cmnTcpClose( sAcceptSock );
                    sAcceptSock = -1;
                    break;
            }
        }
    }

end:
    return 0;
}
