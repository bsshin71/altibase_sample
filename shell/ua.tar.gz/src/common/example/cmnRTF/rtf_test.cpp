#include "cmnApi.h"

int main()
{
    int     sRet;

    /*---------------------------------------------------------
     * KILL_HERE 로 정의된 지점에 1 번째 접근 시 Abort 해라.
     *-------------------------------------------------------*/
    cmnRTFEnable( (char *)"KILL_HERE",
                  1,
                  CMN_RTF_ABORT,
                  1 );

    /*---------------------------------------------------------
     * 여기가 abort 로 죽는 Point
     *-------------------------------------------------------*/
    RTF_POINT( "KILL_HERE" );

    printf("This Message must not be printed.\n");

    return 0;
}
