/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   모든 onmir 솔루션에서 공유하는 Error Code
 ******************************************************************************/

#ifndef __O_CMN_ERROR_H__
#define __O_CMN_ERROR_H__

#include "mvp.h"
#include "cmnErrorCode.h"
#include "dbmErrorCode.h"

#ifdef __cplusplus
extern "C"
{
#endif

#ifdef __cplusplus
extern char* cmnGetError    ( int aCode, char* aMsg = NULL );
#else
extern char* cmnGetError    ( int aCode, char* aMsg );
#endif

extern void cmnCatchErr ( const char* file, const char* func, int line, int aRc, int aLine, const char* aData = NULL );
extern void cmnCatchWarn( const char* file, const char* func, int line, int aRc, int aLine, const char* aData = NULL );
extern void cmnCatchInfo( const char* file, const char* func, int line, int aRc, int aLine, const char* aData = NULL );
extern void cmnCatchDbg ( const char* file, const char* func, int line, int aRc, int aLine, const char* aData = NULL );
//extern void cmnCatchDbg2( const char* file, const char* func, int line, int aRc, int aLine, const char* aData = NULL );
extern void cmnCatchTrc ( const char* file, const char* func, int line, int aRc, int aLine, const char* aData = NULL );
extern void cmnCatchPrt ( const char* file, const char* func, int line, int aRc, int aLine, const char* aData = NULL );

#ifdef __cplusplus
};
#endif

#endif  /* __O_CMN_ERROR_H__ */
