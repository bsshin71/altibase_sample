/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *
 ******************************************************************************/

#ifndef __O_CMN_CONFIG_H__
#define __O_CMN_CONFIG_H__

#include "mvp.h"

#ifdef __cplusplus
extern "C" {
#endif

extern int cmnOpenConfig ( const char* aFileName, int* aFD );
extern int cmnCloseConfig ( int* aFD );
extern int cmnFindEqualAndValue ( char* aBuff, int aPos, int aMax, char* aValue );
extern int cmnMoveSection ( int aFD, const char* aSecion );
extern int cmnReadElement ( int aFD, const char* aSection, char* aElement, char* aValue, int* aPosition );
extern int cmnParseFetch ( char* aBuff, char* aDelimeter, char* aValue, int* aPosition );

#ifdef __cplusplus
}
#endif

#endif  /* __O_CMN_CONFIG_H__ */
