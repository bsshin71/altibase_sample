/*
 * cmnDefine.h
 */

#ifndef CMNDEFINE_H_
#define CMNDEFINE_H_


/**************************************************************
 * 공통DEFINE
 **************************************************************/

#define _DBM_SRC                        // dbmDef.h 등 외부노출 샘플에서, 충돌가능성있는 매크로 등을 막는 용도

#if 0 //ndef _DEBUG
#define _DBM_PERF                       //TODO: 2014.11.18. -okt- 삼성증권 POC를 위해, 불필요한 건 다 빼고, 땡기는 용도.
#define _DBM_NEXT                       // 호환성 혹은 리스크 혹은 작성중 등의 이유로, 적용을 막아두는 용도.
#define _DBM_MVCC2                      // #891 ERR_DBM_FETCH_SCN_INVISIBLE (1137) 발생조건 완화
#define _DBM_UPDATE                     // 임시 : dbmRowUpdate 관련 ColBind 처리 
#endif


/*
 * 환경변수
 *
 * ENV_DBM_XX 환경변수는 dbmDefine.h 에 선언된 것과 중복되어 있음. 수정시 양쪽모두 필요.
 */
#define ENV_DBM_HOME                    "DBM_HOME"
#define ENV_DBM_INSTANCE                "DBM_INSTANCE"

#define ENV_DBM_TRCLOG_ECHO             "DBM_TRCLOG_ECHO"
#define ENV_DBM_TRCLOG_ASYNC_ENABLE     "DBM_TRCLOG_ASYNC_ENABLE"
#define ENV_DBM_TRCLOG_LEVEL            "DBM_TRCLOG_LEVEL"
#define ENV_DBM_TRCLOG_PID_TYPE         "DBM_TRCLOG_PID_TYPE"
#define ENV_DBM_TRCLOG_NAME_TYPE        "DBM_TRCLOG_NAME_TYPE"

#define DBM_ERROR_FILE_NAME             "dbm.error"

#define ENV_DBM_FILE_MODE               "DBM_FILE_MODE"
#define DBM_FILE_MODE                   ( 0660 )    // (S_IRUSR | S_IWUSR | S_IRGRP)


/**************************************************************
 * DBM 공통 상수 정의 ( 모듈별 상수는 각 모둘에 )
 **************************************************************/
#ifndef DBM_CLS_LEN
#define DBM_CLS_LEN                     64      // 64: cache line size (x86) vs 128: double cache line size
#endif

#define DBM_HOST_NAME_LEN               32      // 기존 16, ENAMETOOLONG 발생
#define DBM_FILE_NAME_LEN               256
#define DBM_FUNC_NAME_LEN               64      // FUNCTION 이름이 가지는 최대 길이
#define DBM_SERVICE_NAME_LEN            64      // 프로세스의 고유 명칭 ( 서비스명 )


/**************************************************************
 * 개인 전역 정의 ( 자신없는 임시코드를 막았다 풀었다 할때 )
 **************************************************************/
// gets rid of annoying "deprecated conversion from string constant blah blah" warning
#pragma GCC diagnostic ignored "-Wwrite-strings"
//#pragma GCC diagnostic pop

#ifdef _DEBUG               /* 릴리즈에서 포함안되도록 안전장치 */

#define _OKT_TIMER

//#define _OKT_TRC_CALLER
#if defined(_OKT_TRC_CALLER)
#warning "[_OKT_TRC_CALLER] 컴파일할때 여기가 출력되면 커밋이 잘못 된것임, 옥섭을 구박할것"
#endif

#endif  /* _DEBUG */


/**************************************************************
 * 개인 전역 정의 ( 동작하는 것 같고 일단 최종 적용전 후보 )
 **************************************************************/
#ifdef _DEBUG
//# define _DBM_USE_TRACE_CALLER
#   define _VALGRIND
#endif


/**************************************************************
 * 컴파일러 GCC 4.7.x ( C++2011 )
 **************************************************************/
#ifdef __linux__

#if ! __GNUC_PREREQ (4, 7)
//#warning "gcc version check warning, must be 4.7.x or greater or not float128 disabled"
#else

//#include <quadmath.h>         // [주의] 여기에 위치하면 이상한 오류
#ifdef __cplusplus
extern "C" {
#endif
    #include <quadmath.h>
    typedef __float128  FLOAT128;
#ifdef __cplusplus
}
#endif

#endif

#endif /* __linux__ */

/*
 * 2014.12.14. -okt- Per CPU Variables
 * > http://studyfoss.egloos.com/5375570
 * > http://desprofundis.blogspot.kr/2008/06/kernel-knowhow-per-cpu-variables.html
 * 사용하면 장점이 있을 것으로 생각했으나, 커널내부가 아니면 context-switch를 막을 방법이 없음.
 */

typedef _VOID cmnCbFunc ( void* arg );


#endif /* CMNDEFINE_H_ */
