/******************************************************************************
* Copyright 2012, OnmirSoft Corporation or its subsidiaries.
* All rights reserved.
******************************************************************************/

/******************************************************************************
* $Id$
*
* Description :
*
******************************************************************************/

#ifndef __O_CMN_QUEUE_H__
#define __O_CMN_QUEUE_H__

#include "mvp.h"

typedef struct cmnQData
{
    long long   qType;
    char        qData[2048];
} cmnQData;


#ifdef __cplusplus
extern "C" {
#endif

#ifdef __linux__    //TODO: [OKT]  윈도포팅

extern int cmnQueueOpen( int* aQueueId, char* KeyFilePath );
extern int cmnQueueRecv( int aQueueId, long long aMsgType, int aMsgRcvFlag, char* Data, int aSize, int* aRecvedSize );
extern int cmnQueueSend( int aQueueId, long long aMsgType, char* Data, int aSize );
extern int cmnQueueClose( int aQueueID );
extern int cmnQueueState( int aQueueId, long long* aMaxQBytes, long long* aCurrentMsgBytes, long long* aCurrentMsgCount );

#else

#define cmnQueueOpen(...)               (-1)
#define cmnQueueRecv(...)               (-1)
#define cmnQueueSend(...)               (-1)
#define cmnQueueClose(...)              (-1)
#define cmnQueueState(...)              (-1)

#endif /* __linux__ */

#ifdef __cplusplus
}
#endif

#endif  /* __O_CMN_QUEUE_H__ */
