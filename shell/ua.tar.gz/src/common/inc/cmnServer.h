#ifndef __O_CMN_SERVER_H__
#define __O_CMN_SERVER_H__

/*********** Type Definition **************************************************/
extern unsigned long long _cmn_sys_pagesize;
extern unsigned long long _cmn_sys_physmemsize;
extern unsigned long long _cmn_sys_avphysmemsize;

extern char             _cmn_cmd_name[32];
extern int              _cmn_sys_ncpu;
extern int              _cmn_log_echo;
extern int              _cmn_use_rtf;

extern int              _cmn_file_mode;
extern char*            _cmn_shm_prefix;

#endif  /* __O_CMN_SERVER_H__ */
