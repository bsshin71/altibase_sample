#ifndef __DBMEXCEPTIONS_H__
#define __DBMEXCEPTIONS_H__


////////////////////////////////////////////////////////////////////////////////
// 컴파일러 공통
////////////////////////////////////////////////////////////////////////////////

#ifndef __cplusplus
#define true    1
#define false   0
typedef int     bool;
#endif

#ifndef TRUE
#define TRUE    1
#define FALSE   0
#endif

/****************************************************
 * Return Value
****************************************************/
#define RC_SUCCESS              0
#define RC_FAILURE              -1


////////////////////////////////////////////////////////////////////////////////
// Exception Handling
////////////////////////////////////////////////////////////////////////////////

#ifndef __TRY_MACRO__
#define __TRY_MACRO__

extern volatile int _cmn_signo;
extern __thread int _cmn_signo_r;
extern int _cmn_errno;

#define _TRY                int _rc=0, _line=0;
#define _CATCH              if ( likely ( _rc == 0 || _line == 0 ) ) goto _finally; _catch: NULL;

#define _FINALLY            if ( unlikely ( _rc != 0 ) ) _cmn_errno = _rc; _finally: NULL; // NULL : '생성자' 유형에 필요.

#define _END                { return _rc; }
#define _ENDVOID            { return; }
#define _ENDNULL            { return NULL; }
#define _ENDBOOL            { return TRUE; }

// 2014.09.21 (OKT): _EXCEPTION 과 _CATCH를 함께 사용하기 위해 추가
#define _BEGIN_SUB_CATCH    goto _end_sub_catch;
#define _SUB_CATCH(x)       goto _end_sub_catch; x:
#define _END_SUB_CATCH      _end_sub_catch:
#define _IF_RAISE2(exp,x)   if ( unlikely(exp) ) { _line=__LINE__; goto x; }    // _rc 값을 넘겨줄수 없다.
#define _RAISE2(x)          { _line=__LINE__; goto x; }

#define _VOID               int                         /* 0:성공, n:오류 */
#define _BOOL               int                         /* 1:성공, 0:오류 */
#define _CALL(x)            if ( unlikely( (_rc=(x)) != 0 ) )  _THROW(_rc)
#define _BCALL(x)           if ( unlikely( (_rc=(x)) == 0 ) )  _THROW(-1)       // 윈도포팅, 윈도API 등이 _BOOL 리턴이 많음
#define _RETURN             { _rc = 0; /* _line=__LINE__; */ goto _finally; }   // 굳이 _line 은 필요없음.

#define _THROW(x)           { _rc = x; _line=__LINE__; goto _catch; }
#if 0 //def _DEBUG
#undef  _THROW
#define _THROW(x)           { if (!x)  { _PRT( "%s:%d _THROW(0) detected\n", __FILE__, __LINE__ ); _DASSERT(0); } _rc = x; _line=__LINE__; goto _catch; }
#endif

#define _TEST_THROW(exp,x)  if ( unlikely( !(exp) ) ) _THROW(x)
#define _IF_THROW(exp,x)    if ( unlikely(exp) ) _THROW(x)

#define _EXIT(x)            { cmnLogFlush(); exit(x); }
#define _ASSERT(x)          if ( unlikely( !(x) ) ) { _PRT("assert occur(%s) on %s:%d (err=%d,tid=%d)\n", #x, __FILE__, __LINE__, errno, gettid_s() ); cmnLogFlush(); abort(); }
#ifdef _DEBUG
#define _DASSERT(x)         _ASSERT(x)
#else
#define _DASSERT(x)         NULL
#endif

////////////////////////////////////////////////////////////////////////////////
// Exception Handling (그외)
////////////////////////////////////////////////////////////////////////////////

#define _RAISE(aLabel)                          \
    { goto aLabel; }

#define _LABEL(aLabel)                          aLabel:

#define _EXCEPTION_END                          EXCEPTION_END_LABEL:

#define _EXCEPTION(aLabel)                      \
    goto EXCEPTION_END_LABEL;                   \
    aLabel:

#define _TEST_RAISE(aExpr, aLabel)              \
    do {                                        \
        if ( !(aExpr) )                         \
        {                                       \
            goto aLabel;                        \
        }                                       \
        else                                    \
        {                                       \
        }                                       \
    } while(0)


// _TEST_xx와 조건이 반대되는 것으로 _IF_xx
#define _IF_RAISE(aExpr, aLabel)                \
    do {                                        \
        if (aExpr)                              \
        {                                       \
            goto aLabel;                        \
        }                                       \
        else                                    \
        {                                       \
        }                                       \
    } while(0)


#endif /* __TRY_MACRO__ */


#define _PRT_LN(k,v,w)      { _PRT( "  %-*s <int>     =  \"%d\"\n", w, k, v ); }
#define _PRT_LS(k,v,w)      { _PRT( "  %-*s <string>  =  \"%s\"\n", w, k, v ); }
#define _PRT_N(k,v)         _PRT_LN(k,v,30)
#define _PRT_S(k,v)         _PRT_LS(k,v,30)

#define _PRT_S2(v)          _PRT_LS((#v),v,30)          // 이런게 필요할까. 이걸 기본으로할까?


#endif /* __DBMEXCEPTIONS_H__ */
