/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 * Posix Thread Library
 ******************************************************************************/
#ifndef __O_CMN_PTHREAD_H__
#define __O_CMN_PTHREAD_H__

#include "mvp.h"

#ifdef __cplusplus
extern "C" {
#endif


typedef void* (*cmnThreadFunc) ( void* Info );

extern _VOID cmnCreateThread( pthread_t* aThread, short aCpuSet, pthread_attr_t* aAttr, cmnThreadFunc aFunc, void* Info );

//TODO: [OKT] 윈도포팅. cpu_set_t 미지원
#ifdef __linux__

extern _VOID cmnSetThrAffinity( pthread_t* aThread, short aCpuSet );
extern _VOID cmnSetCpuAffinity ( pthread_t aThread, void* aCpuSet ); // cpu_set_t* aCpuSet

#else

#define cmnSetThrAffinity(...)          (0)
#define cmnSetCpuAffinity(...)          (0)

#endif /* __linux__ */


#ifdef __cplusplus
}
#endif


#endif  /* __O_CMN_PTHREAD_H__ */
