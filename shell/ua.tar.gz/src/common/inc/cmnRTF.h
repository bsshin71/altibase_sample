/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    RTF (Recovery Test Framework)
 *    비정상종료 테스트를 위한 Test Frame Work.
 ******************************************************************************/

#ifndef __O_CMN_RTF_H__
#define __O_CMN_RTF_H__

#ifdef __cplusplus
extern "C" {
#endif


#define CMN_RTF_ABORT           0x00
#define CMN_RTF_DEFER_ABORT     0x01

#define MAX_RTF_HASH            100

#ifdef  _DEBUG
#define _RTF_TEST
#endif

/*
 * 실제 RTF Point 지점에는 RTF_POINT macro 를 사용한다.
 */
#ifdef _RTF_TEST

typedef struct cmnRTFInfo
{
    char        mName[64];
    char        mRTFType;
    char        mEnable;
    int         mTargetCount;
    int         mCurrCount;
    int         mPrintOutF;
    struct cmnRTFInfo* mNext;
} cmnRTFInfo;


extern cmnRTFInfo  gTestCaseMap[MAX_RTF_HASH];

extern void cmnRTFInit ( );
extern void cmnRTFEnable ( char* aName , int aTargetCount , int aRTFType , int aPrintOutF );
extern int cmnRTFPoint ( const char* aTestString );

#define RTF_POINT(x) cmnRTFPoint( x );

#else

//#define cmnRTFInit()
//#define cmnRTFEnable(a,b,c,d)
#define cmnRTFEnable(a,...)
//inline void cmnRTFEnable ( char* aName , int aTargetCount , int aRTFType , int aPrintOutF ) { };
#define cmnRTFPoint(x)
#define RTF_POINT(x)

#endif



#ifdef __cplusplus
}
#endif

#endif  /* __O_CMN_RTF_H__ */
