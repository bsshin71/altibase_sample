/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *
 ******************************************************************************/

#ifndef __O_CMN_SHM_H__
#define __O_CMN_SHM_H__

#include "mvp.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __linux__    //TODO: [OKT]  윈도포팅

extern int cmnGetKey ( char* KeyString );
extern int cmnShmCreate( char* KeyString, long long aSize );
extern int cmnShmAttach( char* aKeyString, long long aSize, char** aAttachAddr );
extern int cmnShmDrop( char* aKeyString );
extern int cmnShmDetach( char** ppAddr );
extern int cmnShmGetID( char* aKeyString, int* aShmID );
extern int cmnShmGetAttachNum ( char* aKeyString, int* aAttachNum );
extern int cmnShmIsDest( char* aKeyString );

#else

#define cmnGetKey(...)                  (-1)

// [윈도포팅] dbmSegmentManager.cpp에서 중복 정의됨
//#define cmnShmCreate(...)             (-1)
//#define cmnShmDrop(...)               (-1)
//#define cmnShmAttach(...)             (-1)
//#define cmnShmDetach(...)             (-1)

#define cmnShmGetID(...)                (-1)
#define cmnShmGetAttachNum(...)         (-1)
#define cmnShmIsDest(...)               (-1)

#endif /* __linux__ */

#ifdef __cplusplus
}
#endif

#endif  /* __O_CMN_SHM_H__ */
