/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 * Timer Statistics Library
 ******************************************************************************/
#ifndef __O_CMN_TIMER_STAT_H__
#define __O_CMN_TIMER_STAT_H__

#include "mvp.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MIN_SECTION_COUNT           1
#define MAX_SECTION_COUNT           1024

#define UNIT_DEFAULT                0
enum unit_type
{
    UNIT_MICRO                      = UNIT_DEFAULT,
    UNIT_SEC,
    UNIT_MILI,
    UNIT_NANO
};

typedef struct cmnTimerStat
{
    int             mUnitType;          // 단위 (SEC, MILI, MICRO, NANO)
    double          mSum;               // 전체 시간 합계 - 단위에 따른 시간
    int             mSumCnt;            // [가정] N개 쓰레드 테스트를 했으면, cmnSumTimer() 을 N번 호출했어야한다

    int             mBegin;             // 통계를 보여줄 시간구간의 시작 값
    int             mInterval;          // 통계를 보여줄 시간구간의 간격
    int             mSectionCount;      // 몇 개의 시간구간으로 보여줄 것인가

    struct timespec mStartTimer;
    struct timespec mEndTimer;
    struct timespec mTestStartTimer;    // 테스트의 시작 시간
    struct timespec mTestEndTimer;      // 테스트의 완료 시간

    char*           mTime;
    void*           mElapsedContainer;
} cmnTimerStat;


typedef void* PHTIMER;

extern _VOID cmnInitTimer   ( PHTIMER* aTimerHandle , int aUnit , int aBegin , int aInterval , int aSecCount );
extern _VOID cmnFinalTimer  ( PHTIMER* aTimerHandle );
extern _VOID cmnStartTimer  ( PHTIMER aTimerHandle );
extern _VOID cmnStartTimer2 ( PHTIMER aTimerHandle, struct timespec* aStartTime );
extern _VOID cmnSumTimer    ( PHTIMER aTimerHandle, PHTIMER aTimerSumHandle );
extern _VOID cmnEndTimer    ( PHTIMER aTimerHandle );
extern _VOID cmnElapseTimer ( PHTIMER aTimerHandle, int aIterCount, const char* aTestName );
extern _VOID cmnGetUnitTypeStr ( int aUnitType , char* aUnitTypeStr );
extern _VOID cmnWaitTimer    ( void* aTimerHandle );


#ifdef __cplusplus
}
#endif


#endif  /* __O_CMN_TIMER_STAT_H__ */
