/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *
 ******************************************************************************/

#ifndef __O_CMN_SEMAPHORE_H__
#define __O_CMN_SEMAPHORE_H__

#include "mvp.h"


#ifdef __cplusplus
extern "C" {
#endif

#ifdef __linux__    //TODO: [OKT]  윈도포팅

extern int cmnSemInit ( sem_t* aSem, int aShared, int value );
extern int cmnSemDrop ( sem_t* aSem );
extern int cmnSemWait ( sem_t* aSem, int aTryCount, int aTimeout );
extern int cmnSemPost ( sem_t* aSem );

#else

#define cmnSemInit(...)             (-1)
#define cmnSemDrop(...)             (-1)
#define cmnSemWait(...)             (-1)
#define cmnSemPost(...)             (-1)

#endif /* __linux__ */

#ifdef __cplusplus
}
#endif

#endif  /* __O_CMN_SEMAPHORE_H__ */
