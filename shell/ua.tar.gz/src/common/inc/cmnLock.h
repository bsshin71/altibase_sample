/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *
 ******************************************************************************/

#ifndef __O_CMN_LOCK_H__
#define __O_CMN_LOCK_H__

#include "mvp.h"

#ifdef __linux__
#define futex_wait(P,V,T)           syscall( SYS_futex, P, FUTEX_WAIT, V, T, NULL, 0 )
#define futex_wake(P,V)             syscall( SYS_futex, P, FUTEX_WAKE, V, NULL, NULL, 0 )
#else
#define futex_wait(P,V,T)           (-1)    // assert( 0 && "[WIN32] not yet supported" )
#define futex_wake(P,V)             (-1)
#endif /* __linux__ */


#define atomic_inc(P)               __sync_add_and_fetch( (P), 1 )
#define atomic_dec(P)               __sync_sub_and_fetch( (P), 1 )


#ifdef __cplusplus
extern "C" {
#endif


extern int cmnInitMutex ( pthread_mutex_t* aMutex );

extern int cmnInitRWMutex ( pthread_rwlock_t* aMutex );

extern int cmnInitCond ( pthread_cond_t* aCond );

#ifdef __cplusplus
extern int cmnLockMutex ( pthread_mutex_t* aMutex , int aSpinCount = 0 );
#else
extern int cmnLockMutex ( pthread_mutex_t* aMutex , int aSpinCount );
#endif

extern int cmnUnlockMutex ( pthread_mutex_t* aMutex );

#ifdef __cplusplus
extern int cmnCondWait ( pthread_cond_t* aCond , pthread_mutex_t* aMutex , int aUntilTime = 0 );
#else
extern int cmnCondWait ( pthread_cond_t* aCond , pthread_mutex_t* aMutex , int aUntilTime );
#endif

extern int cmnCondBroadCast ( pthread_cond_t* aCond );

extern int cmnCondSignal ( pthread_cond_t* aCond );

#ifdef __cplusplus
extern int cmnLockFutex ( int* aLock , int aValue , int aSpinCount = 0 );
#else
extern int cmnLockFutex ( int* aLock , int aValue , int aSpinCount );
#endif

extern int cmnUnlockFutex ( int* aLock , int aValue );

#ifdef __cplusplus
extern int cmnWaitFutex ( volatile int* aLock, int aTimeout = 0 );
#else
extern int cmnWaitFutex ( volatile int* aLock, int aTimeout );
#endif

extern void cmnSignalFutex ( volatile int* aCond );

//TODO: 2014.11.14. -okt- futex try for %sys
extern int cmnWaitFutex2 ( volatile int* aLock );
extern void cmnSignalFutex2_ ( volatile int* aCond );

#ifdef _DEBUG
#define cmnSignalFutex2(a)          cmnSignalFutex2_(a)
#else
#define cmnSignalFutex2(a)          futex_wake( a, *a );
#endif


#ifdef __cplusplus
}
#endif

#endif  /* __O_CMN_LOCK_H__ */
