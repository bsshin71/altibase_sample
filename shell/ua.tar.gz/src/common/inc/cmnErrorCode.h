/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   모든 onmir 솔루션에서 공유하는 Error Code
 ******************************************************************************/

#ifndef __O_CMN_ERROR_CODE_H__
#define __O_CMN_ERROR_CODE_H__

#define SYS_CALL_ERROR_BASE         0     /* 0 ~ 699     : error code for system call operation */
#define CMN_ERROR_BASE              700   /* 700 ~ 999   : error code for common library */

#define DBM_ERROR_BASE              1000  /* 1000 ~ 2999 : error code for dbm */
#define UTL_ERROR_BASE              3000  /* 3000 ~ 3999 : error code for utility */

/*--------------------------------------------------------
 * system call Operation Code
 *   system call 함수들을 모두 각각의 code 로 정의한 것이다.
 *   common library 의 각 함수에서 리턴할 때 어떤 system call 을
 *   수행하다가 error 가 발생했는지를 알 수 있도록 아래의 code 로 리턴한다.
 *
 * ** 만약 신규로 추가할 system call code 가 있다면 ERR_SYSCALL_ 뒤에
 *    원래 함수의 이름을 그대로 대문자화하여 붙이면 된다.
 --------------------------------------------------------*/
typedef char cmnSysCallCode;
/* memory */
#define ERR_SYSCALL_MALLOC                          1
#define ERR_SYSCALL_CALLOC                          2
#define ERR_SYSCALL_REALLOC                         3
#define ERR_SYSCALL_FREE                            4
/* file */
#define ERR_SYSCALL_OPEN                            5
#define ERR_SYSCALL_WRITE                           6
#define ERR_SYSCALL_READ                            7
#define ERR_SYSCALL_CLOSE                           8
#define ERR_SYSCALL_UNLINK                          9
#define ERR_SYSCALL_LSEEK                           10
/* file stream */
#define ERR_SYSCALL_FOPEN                           11
#define ERR_SYSCALL_FREAD                           12
#define ERR_SYSCALL_FWRITE                          13
#define ERR_SYSCALL_FFLUSH                          14
#define ERR_SYSCALL_FSYNC                           15
#define ERR_SYSCALL_FCLOSE                          16
#define ERR_SYSCALL_FSEEK                           17
#define ERR_SYSCALL_FTELL                           18
#define ERR_SYSCALL_REWIND                          19
#define ERR_SYSCALL_FGETPOS                         20
#define ERR_SYSCALL_FSETPOS                         21
/* time */
#define ERR_SYSCALL_LOCALTIME                       22
#define ERR_SYSCALL_LOCALTIME_R                     23
#define ERR_SYSCALL_ASCTIME                         24
#define ERR_SYSCALL_MKTIME                          25
#define ERR_SYSCALL_TIME                            26
#define ERR_SYSCALL_CTIME                           27
#define ERR_SYSCALL_GMTIME                          28
#define ERR_SYSCALL_STRFTIME                        29
#define ERR_SYSCALL_DIFFTIME                        30
#define ERR_SYSCALL_STRPTIME                        31
#define ERR_SYSCALL_GETTIMEOFDAY                    32
#define ERR_SYSCALL_CLOCK_GETTIME                   33
/* process */
#define ERR_SYSCALL_FORK                            34
#define ERR_SYSCALL_DUP                             35
#define ERR_SYSCALL_WAIT                            36
#define ERR_SYSCALL_WAITPID                         37
/* pthread */
#define ERR_SYSCALL_PTHREAD_CREATE                  38
#define ERR_SYSCALL_PTHREAD_JOIN                    39
#define ERR_SYSCALL_PTHREAD_CANCEL                  40
#define ERR_SYSCALL_PTHREAD_ATTR_INIT               41
#define ERR_SYSCALL_PTHREAD_DETACH                  42
#define ERR_SYSCALL_PTHREAD_EQUAL                   43
#define ERR_SYSCALL_PTHREAD_EXIT                    44
#define ERR_SYSCALL_PTHREAD_GETATTR_NP              45
#define ERR_SYSCALL_PTHREAD_SELF                    46
#define ERR_SYSCALL_PTHREAD_RWLOCK_INIT             47
#define ERR_SYSCALL_PTHREAD_RWLOCKATTR_INIT         48
#define ERR_SYSCALL_PTHREAD_RWLOCKATTR_SETPSHARED   49
#define ERR_SYSCALL_PTHREAD_RWLOCKATTR_DESTROY      50
#define ERR_SYSCALL_PTHREAD_MUTEX_INIT              51
#define ERR_SYSCALL_PTHREAD_MUTEXATTR_INIT          52
#define ERR_SYSCALL_PTHREAD_MUTEXATTR_SETPROTOCOL   53
#define ERR_SYSCALL_PTHREAD_MUTEXATTR_SETROBUST     54
#define ERR_SYSCALL_PTHREAD_MUTEXATTR_SETPSHARED    55
#define ERR_SYSCALL_PTHREAD_MUTEXATTR_SETTYPE       56
#define ERR_SYSCALL_PTHREAD_MUTEXATTR_DESTROY       57
#define ERR_SYSCALL_PTHREAD_MUTEX_LOCK              58
#define ERR_SYSCALL_PTHREAD_MUTEX_TRYLOCK           59
#define ERR_SYSCALL_PTHREAD_MUTEX_UNLOCK            60
#define ERR_SYSCALL_PTHREAD_COND_INIT               61
#define ERR_SYSCALL_PTHREAD_CONDATTR_INIT           62
#define ERR_SYSCALL_PTHREAD_CONDATTR_SETPSHARED     63
#define ERR_SYSCALL_PTHREAD_CONDATTR_DESTROY        64
#define ERR_SYSCALL_PTHREAD_COND_WAIT               65
#define ERR_SYSCALL_PTHREAD_COND_TIMEDWAIT          66
#define ERR_SYSCALL_PTHREAD_COND_SIGNAL             67
#define ERR_SYSCALL_PTHREAD_COND_BROADCAST          68
#define ERR_SYSCALL_PTHREAD_SETAFFINITY_NP          69
/* socket */
#define ERR_SYSCALL_SOCKET                          70
#define ERR_SYSCALL_BIND                            71
#define ERR_SYSCALL_SETSOCKOPT                      72
#define ERR_SYSCALL_FCNTL                           73
#define ERR_SYSCALL_LISTEN                          74
#define ERR_SYSCALL_SEND                            75
#define ERR_SYSCALL_RECV                            76
#define ERR_SYSCALL_CONNECT                         77
#define ERR_SYSCALL_ACCEPT                          78
#define ERR_SYSCALL_SENDTO                          79
#define ERR_SYSCALL_RECVFROM                        80
#define ERR_SYSCALL_SELECT                          81
#define ERR_SYSCALL_POLL                            82
#define ERR_SYSCALL_EPOLL                           83
/* shm */
#define ERR_SYSCALL_SHMGET                          84
#define ERR_SYSCALL_SHMCTL                          85
#define ERR_SYSCALL_SHMAT                           86
#define ERR_SYSCALL_SHMDT                           87
/* msg queue */
#define ERR_SYSCALL_MSGGET                          88
#define ERR_SYSCALL_MSGSND                          89
#define ERR_SYSCALL_MSGRCV                          90
#define ERR_SYSCALL_MSGCTL                          91
/* semaphore */
#define ERR_SYSCALL_SEM_INIT                        92
#define ERR_SYSCALL_SEM_WAIT                        93
#define ERR_SYSCALL_SEM_TRYWAIT                     94
#define ERR_SYSCALL_SEM_TIMEDWAIT                   95
#define ERR_SYSCALL_SEM_POST                        96
#define ERR_SYSCALL_SEM_DESTROY                     97
/* futex,syscall */
#define ERR_SYSCALL_FUTEX_WAIT                      98
#define ERR_SYSCALL_FUTEX_WAKE                      99
#define ERR_SYSCALL_SYSCALL                         100
/* add new system call here */
#define ERR_SYSCALL_MAX                             101

/*--------------------------------------------------------
 * Common Error Code
 *   공통 라이브러리 작성 시 system call 외에 기타 에러로
 *   리턴하고자할 경우 이곳에 정의하여 사용한다.
 --------------------------------------------------------*/
#define ERR_CMN_INVALID_ARG                         700
#define ERR_CMN_SHM_KEY_ERROR                       701
#define ERR_CMN_SHM_DUP_ERROR                       702
#define ERR_CMN_SHM_DEST_STAT                       703
#define ERR_CMN_INVALID_FILE_NAME                   704
#define ERR_CMN_INVALID_FILE_FD                     705
#define ERR_CMN_TIMEOUT                             706
#define ERR_CMN_SHM_OPEN                            707
#define ERR_CMN_FTRUNCATE                           708
#define ERR_CMN_MMAP                                709
#define ERR_CMN_MUNMAP                              710
#define ERR_CMN_SHM_UNLINK                          711
#define ERR_CMN_FSTAT                               712
#define ERR_CMN_LSTAT                               713
#define ERR_CMN_SHM_WRITE                           714
#define ERR_CMN_MAX                                 715


#endif  /* __O_CMN_ERROR_CODE_H__ */
