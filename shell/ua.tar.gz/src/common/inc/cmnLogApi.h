/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 *
 * 이 헤더파일은 외부에서도 (필요시) 사용가능하도록, 다른 헤더파일과 연관을 가지면 안됨.
******************************************************************************/


#ifndef CMNLOGAPI_H_
#define CMNLOGAPI_H_

//#include "mvp.h"

#ifdef __cplusplus
extern "C" {
#endif

#define DBM_MAX_LOG_LEN     2048
#define DBM_MAX_LOG_CNT     1024
#define _WHERE              __FILE__, __FUNCTION__, __LINE__


typedef enum cmnLogLevel
{
      LL_C          = (1 << 0)              // [사용하지말것] Critical 를 없애고 LL_SYS를 넣을까 함. (순서밀리지않게 동시에)
    , LL_E          = (1 << 1)              // Error    : 사용자에게 오류 노출이 필요한 경우만 사용
    , LL_W          = (1 << 2)              // Warning  : 비정상, 혹은 성능상 영향이 큰 상황이 발생하였으나, 내부적으로 복구가능한 경우
    , LL_I          = (1 << 3)              // Info     : 정상로그이나, 기본적인 동작을 확인하는 로그 (단 non verbose 해야한다)
    , LL_H          = (1 << 4)              // HEXA     : (미구현) INFO이나, 데이타를 HEXA로 출력, 레벨의 용도와 flag 동작을 함께 함.
    , LL_D          = (1 << 5)              // Debug    : verbose한 정상로그
    , LL_T          = (1 << 6)              // Trace    : DEBUG 보다 더 상세한 로그, 예를 들면 모든 I/D/U/S 마다 출력되는 로그
    , LL_F          = (LL_T - 1)            // Force    : 레벨 설정에 무관하게 무조건 출력하는 로그
    , LF_NOH        = (1 << 11)             // Log Flag NoHeader
    , LF_ECHO       = (1 << 12)             // Log Flag stdout
    , LF_SYNC       = (1 << 13)             // Log Flag Sync Mode ( LogThread에 위임하지 않고 직접 기록 )
    , LF_PRT        = LF_SYNC | (1 << 14)   // Log Flag stdout Print Only

    , LL_0          = 0                     // 로깅하지 않음 ( LL_FORCE 제외 )
    , LL_1          = LL_0 | LL_C | LL_E
    , LL_2          = LL_1 | LL_W
    , LL_3          = LL_2 | LL_I
    , LL_4          = LL_3 | LL_H
    , LL_5          = LL_4 | LL_D
    , LL_6          = LL_5 | LL_T
} cmnLogLevel ;

/**
 * @brief
 *      로그 FLUSH 함수. ( 현재시점까지의 모든 비동기로그를 디스크로 기록하고, 리턴한다. )
 *
 * @remark
 *      1. thread-safe 하지 않다. 즉. 여러 쓰레드가 LogFlush 호출하면, 그중 한 쓰레드만, 완료 이벤트를 받는다.
 *      2. _ASSERT 등의 매크로에 포함되어 있어서 노출되어 있으며, 사용자가 직접호출하면 안된다.
 */
extern int cmnLogFlush ( );
extern int cmnLogSend ( const char* file, const char* func, int line, int loglevel, const char* aFormat, ... );
extern int cmnLogSetLevel ( const char* aLevel );
extern int cmnLogGetAppType( const char* aName );

#define DBM_CERR(...)               { cmnLogSend ( _WHERE, LL_C, __VA_ARGS__ ); }
#define DBM_CERR_F(...)             { cmnLogSend ( _WHERE, LL_C|LF_SYNC, __VA_ARGS__ ); }

#define DBM_ERR(...)                cmnLogSend ( _WHERE, LL_E, __VA_ARGS__ )
#define DBM_WARN(...)               cmnLogSend ( _WHERE, LL_W, __VA_ARGS__ )
#define DBM_INFO(...)               cmnLogSend ( _WHERE, LL_I, __VA_ARGS__ )
#define DBM_HEXA(a,b)               cmnLogSend ( _WHERE, LL_H, "HexDump 미구현" )

#define DBM_ERR_F(...)              cmnLogSend ( _WHERE, LL_E|LF_SYNC, __VA_ARGS__ )
#define DBM_WARN_F(...)             cmnLogSend ( _WHERE, LL_W|LF_SYNC, __VA_ARGS__ )
#define DBM_INFO_F(...)             cmnLogSend ( _WHERE, LL_I|LF_SYNC, __VA_ARGS__ )

#ifdef _DEBUG

#   define DBM_DBG(...)             cmnLogSend ( _WHERE, LL_D, __VA_ARGS__ )
#   define DBM_DBG_F(...)           cmnLogSend ( _WHERE, LL_D|LF_SYNC, __VA_ARGS__ )
#   define DBM_DBG2(...)            cmnLogSend ( _WHERE, LL_T, __VA_ARGS__ )

#else

#ifndef _DBM_PERF
#   define DBM_DBG(...)             cmnLogSend ( _WHERE, LL_D, __VA_ARGS__ )
#   define DBM_DBG_F(...)           cmnLogSend ( _WHERE, LL_D|LF_SYNC, __VA_ARGS__ )
#   define DBM_DBG2(...)            cmnLogSend ( _WHERE, LL_T, __VA_ARGS__ )
#else
// 2014.11.24. -okt- 성능 모드에서는 DBM_DBG 등에 대한 함수 진입비용도 없앤다.
#   define DBM_DBG(...)
#   define DBM_DBG_F(...)
#   define DBM_DBG2(...)
#endif

#endif

#ifdef _DEBUG
#define DBM_TRC(...)                cmnLogSend ( _WHERE, LL_T, __VA_ARGS__ )
#define DBM_TRC_F(...)              cmnLogSend ( _WHERE, LL_T|LF_SYNC, __VA_ARGS__ )
#else
#define DBM_TRC(...)                // 가장 낮은 단계의 verbose 메시지 출력
#define DBM_TRC_F(...)
#endif

// 정상로그이지만. 프로세스 구동 종료처럼, system 로그에 남길려고 할때.
#define DBM_SYS(...)                cmnLogSend ( _WHERE, LL_F, __VA_ARGS__ )
#define DBM_SYS_F(...)              cmnLogSend ( _WHERE, LL_F|LF_SYNC, __VA_ARGS__ )

#define DBM_FORCE(...)              cmnLogSend ( _WHERE, LL_F, __VA_ARGS__ )
#define DBM_FORCE_F(...)            cmnLogSend ( _WHERE, LL_F|LF_SYNC, __VA_ARGS__ )

// printf 와 완전히 동일. 그러나 매크로를 사용하면 필요시 디버깅이 용이하다. ( printf 직접사용 자제 요망 )
#define _PRT(a,...)                 { printf( a, ##__VA_ARGS__); fflush(stdout); }
#define DBM_PRT(...)                cmnLogSend ( _WHERE, LF_PRT|LF_NOH, __VA_ARGS__ )   // 화면만
#define DBM_PRT2(...)               cmnLogSend ( _WHERE, LL_F|LF_NOH, __VA_ARGS__ )     // 화면없이 파일에만
#define DBM_ECHO(...)               cmnLogSend ( _WHERE, LL_F|LF_ECHO, __VA_ARGS__ )    // 화면과 파일 모두
#define DBM_ECHO2(...)              cmnLogSend ( _WHERE, LL_F|LF_ECHO|LF_NOH, __VA_ARGS__ ) // 파일에도 '헤더'없이
#define DBM_ECHO_F(...)             cmnLogSend ( _WHERE, LL_F|LF_ECHO|LF_SYNC, __VA_ARGS__ )

// 공백라인을 출력
#define DBM_LINE(a)                 { int i; for (i=0; i<a; i++) cmnLogSend( _WHERE, LL_I|LF_NOH, "" ); }
#define DBM_LINE_F(a)               { int i; for (i=0; i<a; i++) cmnLogSend( _WHERE, LL_I|LF_NOH|LF_SYNC, "" ); }


#define _CATCH_PRT                  cmnCatchPrt(_WHERE,_rc,_line)
#define _CATCH_ERR                  cmnCatchErr(_WHERE,_rc,_line)
#define _CATCH_WARN                 cmnCatchWarn(_WHERE,_rc,_line)
#define _CATCH_INFO                 cmnCatchInfo(_WHERE,_rc,_line)
#define _CATCH_DBG                  cmnCatchDbg(_WHERE,_rc,_line)
//#define _CATCH_DBG2                 cmnCatchDbg2(_WHERE,_rc,_line)
#ifdef _DEBUG
#define _CATCH_TRC                  cmnCatchTrc(_WHERE,_rc,_line)
#else
#define _CATCH_TRC
#endif
#define _CATCH_ABRT                 { _CATCH_ERR; _EXIT(_rc); }

#define _CATCH_ERR2(a)              cmnCatchErr(_WHERE,_rc,_line,a)
#define _CATCH_WARN2(a)             cmnCatchWarn(_WHERE,_rc,_line,a)
#define _CATCH_INFO2(a)             cmnCatchInfo(_WHERE,_rc,_line,a)
#define _CATCH_DBG2(a)              cmnCatchDbg(_WHERE,_rc,_line,a)
#define _CATCH_TRC2(a)              cmnCatchTrc(_WHERE,_rc,_line,a)

////////////////////////////////////////////////////////////////////////////////
// 구간 시간 출력
////////////////////////////////////////////////////////////////////////////////

#define DBM_MSEC                        ( 1000 )
#define DBM_USEC                        ( 1000000 )
#define DBM_NSEC                        ( 1000000000L )
#if 0
#define DBM_TIME_SCALE                  DBM_USEC
#else
#define DBM_TIME_SCALE                  DBM_NSEC
#endif

#if ( DBM_TIME_SCALE == DBM_NSEC )

#define cmnTime                         struct timespec
#define cmnTimeGet(a)                   clock_gettime(CLOCK_REALTIME,a)
#define cmnTimeDiff(s,e)                ( (e.tv_sec - s.tv_sec) * DBM_NSEC + (e.tv_nsec - s.tv_nsec) )

#else

#define cmnTime                         struct timeval
#define cmnTimeGet(a)                   gettimeofday(a,NULL)
#define cmnTimeDiff(s,e)                ( (e.tv_sec - s.tv_sec) * DBM_USEC + (e.tv_usec - s.tv_usec) )

#endif

#define cmnTimeCpy(u,n)                 do { u.tv_sec = n.tv_sec; u.tv_usec = n.tv_nsec / 1000; } while(0)
#define cmnTimeDiff2(s,e)               ( cmnTimeDiff(s,e) / (double)DBM_TIME_SCALE )


_INLINE
#ifdef __cplusplus
unsigned long long cmnTimeDiff_s ( const cmnTime& s, const cmnTime& e )
#else
unsigned long long cmnTimeDiff_s ( const cmnTime s, const cmnTime e )
#endif
{
    long long diff = cmnTimeDiff(s,e);
    if ( diff < 0 )
        return 0;

    return (unsigned long long)diff;
}

#define _CALL_TM(body) \
    do { \
        cmnTime s, e; double diff; \
        DBM_ECHO_F ( "<< %s Start..\n", #body ); \
        cmnTimeGet( &s ); \
        _CALL(body) \
        cmnTimeGet( &e ); \
        DBM_ECHO_F ( "<< %s End. ==> LapTime %ld\n", #body, cmnTimeDiff_s(s,e) ); \
    } while(0)

#define _CALL_TM2(body) \
    do { \
        cmnTime s, e; double diff; \
        DBM_ECHO_F ( "<< [TimeCheck] Start..\n" ); \
        cmnTimeGet( &s ); \
        body \
        cmnTimeGet( &e ); \
        DBM_ECHO_F ( "<< [TimeCheck] End. ==> LapTime %ld (tid=%d)\n", cmnTimeDiff_s(s,e), gettid_s() ); \
    } while(0)


////////////////////////////////////////////////////////////////////////////////
// 그외
////////////////////////////////////////////////////////////////////////////////
#define BITAND(a,b)         ((a) & (b))
#define BITOR(a,b)          ((a) | (b))
#define BITXOR(a,b)         ((a) ^ (b))
#define BITCHK(a,b)         (BITXOR( BITAND((a),(b)), (b) ) == 0)
#define BITMOD(a,b)         ((a) & (b-1))       // same with cmnPowerMod()


#ifdef __cplusplus
}
#endif

#endif /* CMNLOGAPI_H_ */
