/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    Posix Shm Library
 ******************************************************************************/

#ifndef __O_CMN_POSIX_SHM_H__
#define __O_CMN_POSIX_SHM_H__

#include "mvp.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
extern int cmnPShmCreate( const char* KeyString, long long aSize, void** aAttachAddr = NULL );
#else
extern int cmnPShmCreate( char* KeyString, long long aSize, void** aAttachAddr );
#endif

extern _VOID cmnPShmAttach( const char* aKeyFilePath, long long aSize, void** aAttachAddr );
extern _VOID cmnPShmDetach( void** ppAddr, long long aSize );
extern _VOID cmnPShmDrop  ( const char* aKeyFilePath );
extern _VOID cmnPShmGetStat ( const char* aKeyFilePath , struct stat* pStat );
extern _VOID cmnPShmGetAttachNum ( const char* aKeyFilePath, int* aAttachNum );

#ifdef __linux__  //TODO: [OKT] 윈도포팅

#ifdef _DEBUG
extern int shm_open_s_ ( const char* name, int oflag, mode_t mode );
#define shm_open_s                      shm_open_s_
#else
#define shm_open_s                      shm_open
#endif

#else

#define shm_open_s(...)                 (-1)

#endif /* __linux__ */

#ifdef __cplusplus
}
#endif

#endif  /* __O_CMN_POSIX_SHM_H__ */
