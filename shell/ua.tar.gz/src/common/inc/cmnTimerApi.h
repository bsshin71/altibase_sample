/*
 * cmnTimerApi.h
 *
 *  Created on: Mar 9, 2014
 *      Author: paul
 */

#ifndef CMNTIMERAPI_H_
#define CMNTIMERAPI_H_

#include "mvp.h"

#ifdef __cplusplus
extern "C" {
#endif

extern _VOID cmnTimerAdd ( int msec , cmnCbFunc* cbFunc , int* pTimerId );
extern _VOID cmnTimerDel ( int timerid );

#ifdef __cplusplus
}
#endif


#endif /* CMNTIMERAPI_H_ */
