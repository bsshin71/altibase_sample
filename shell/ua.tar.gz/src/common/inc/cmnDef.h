/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/

#ifndef __ONMIR_CMN_DEF_H__
#define __ONMIR_CMN_DEF_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>
#include <pthread.h>
#include <limits.h>
#include <float.h>
#include <fcntl.h>
#include <dirent.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef __linux__
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <syscall.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#endif /* __linux__ */

#if 0   // 그냥 native 타입을 사용하기로 결정 ( 2013.10 )
/******************************************************************************
 * Type redefinition
******************************************************************************/
typedef short                       mvp_sint16_t ;
typedef char                        mvp_char_t   ;
typedef unsigned char               mvp_uint8_t  ;
typedef int                         mvp_sint32_t ;
typedef int                         mvp_rc_t     ;
typedef long                        mvp_sint64_t ;
typedef float                       mvp_float_t  ;
typedef double                      mvp_double_t ;
typedef unsigned long               mvp_uint64_t ;
typedef mvp_uint64_t                mvp_size_t   ;
typedef unsigned int                mvp_uint32_t ;
typedef mvp_sint64_t                mvp_ssize_t  ;
typedef mvp_sint32_t                mvp_key_t    ;
#else
// [윈도포팅] mvp_pid_t 는 long인데, 이게 리눅스와 윈도우에서 길이가 다름.
//          #864 에 따라 큰 범위로 맞추지 않고 int로 맞춤.
typedef int                         mvp_pid_t ;
#endif

/******************************************************************************
 * define
******************************************************************************/
#define _INLINE                         static __inline__

#ifdef __GNUC__
#  define likely(x)                     __builtin_expect ((x), 1)
#  define unlikely(x)                   __builtin_expect ((x), 0)
#else
#  define likely(x)                     (x)
#  define unlikely(x)                   (x)
#endif


/******************************************************************************
 * system call wrapper function
******************************************************************************/
#ifndef free_s
#define free_s(ptr)         if ( likely ( ptr != 0 ) ) {  free (ptr); ptr = 0; }
#define delete_s(ptr)       if ( likely ( ptr != 0 ) ) {  delete ptr; ptr = 0; }

#define close_s(fd)         if ( likely ( fd  > 0 ) ) {  (void)close( fd ); fd = -1; }
#define fclose_s(fp)        if ( likely ( fp != 0 ) ) {  (void)fclose( fp ); fp = 0; }
#endif

#ifdef __cplusplus
extern "C" {
#endif

extern mvp_pid_t gettid_s ( );

#ifdef __cplusplus
}
#endif


#endif /* __ONMIR_CMN_DEF_H__ */
