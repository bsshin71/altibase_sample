/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *
 ******************************************************************************/

#ifndef __O_CMN_TCP_H__
#define __O_CMN_TCP_H__

#include "mvp.h"


#ifdef __cplusplus
extern "C" {
#endif

//#define CML_BUFFER_SIZE           ( 32 * 1024 )   // 선재꺼
#define CMN_TCP_BUFFER_SIZE         ( 32 * 1024 )   // TODO: 2014.11.17 -okt- 위치이동해야함.




//#ifdef __linux__    //TODO: [OKT]  윈도포팅

#ifdef __cplusplus
extern _VOID cmnTcpServerOpen( int* aSockFd, int aPortNo, int aNonBlockF, int aBufSize = CMN_TCP_BUFFER_SIZE );
extern _VOID cmnTcpConnect( int* aSockFd, char* Host, int aPortNo, int aNonBlockF, int aTimeout = 3, int aBufSize = CMN_TCP_BUFFER_SIZE );
#else
extern _VOID cmnTcpServerOpen( int* aSockFd, int aPortNo, int aNonBlockF, int aBufSize );
extern _VOID cmnTcpConnect( int* aSockFd, char* Host, int aPortNo, int aNonBlockF, int aTimeout, int aBufSize );
#endif

extern _VOID cmnTcpAccept( int aListenSockFd, int* aNewSockFd, int aNonBlockF );
extern _VOID cmnTcpAcceptGetCliIP( int aListenSockFd, int* aNewSockFd, int aNonBlockF, char* aCliIP );
extern _VOID cmnTcpSend( int aSockFd, char* aData, int aSize, int* aSentSize );
extern _VOID cmnTcpRecv( int aSockFd, char* Data, int aTimeout, int* aRecvedSize );
extern void cmnTcpClose( int aSockFd );

//#else
//
//#define cmnTcpServerOpen(...)       (-1)
//#define cmnTcpConnect(...)          (-1)
//#define cmnTcpAccept(...)           (-1)
//#define cmnSemPost(...)             (-1)
//#define cmnTcpSend(...)             (-1)
//#define cmnTcpRecv(...)             (-1)
//#define cmnTcpClose(...)            (-1)
//
//#endif /* __linux__ */



#ifdef __cplusplus
}
#endif

#endif  /* __O_CMN_TCP_H__ */
