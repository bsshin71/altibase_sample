/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *
 ******************************************************************************/

#ifndef __O_CMN_LICENSE_H__
#define __O_CMN_LICENSE_H__

#ifdef __cplusplus
extern "C" {
#endif

extern int cmnReadLicense ( char* aFileName, char* aLicense );
extern int cmnCheckLicense ( char* aLicense );
extern int cmnCheckLicense2 ( char* aLicense );

#ifdef __cplusplus
}
#endif

#endif  /* __O_CMN_LICENSE_H__ */
