/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   OLM Engine 과 Client 및 Admin Tool 등과의 연동을 위한 전문 definition.
 *   전문 구조는 다음과 같다.
 *       header(olmMsgHead) + body(sub message structure)
 ******************************************************************************/

#ifndef __O_OLM_MESSAGE_H__
#define __O_OLM_MESSAGE_H__

#include "mvp.h"

#ifdef __cplusplus
extern "C"
{
#endif

/*--------------------------------------------------------
 * definition
 --------------------------------------------------------*/
#define MAX_MSG_SIZE                2048
#define MAX_QRY_COUNT               20
#define MSG_HEAD_INFO_SIZE          8
#define MSG_ADMIN_BASE              0
#define MSG_CLIENT_BASE             300

#define MAX_VMG_NAME_LEN            32
#define MAX_USER_NAME_LEN           32
#define MAX_AUTH_KEY_LEN            32
#define MAX_TOPIC_NAME_LEN          128
#define DBM_OBJECT_NAME_LEN         32
#define DBM_INDEX_KEY_MAX_SIZE      40
#define MAX_QRY_STR_LEN             256

/*--------------------------------------------------------
 * message structure
 --------------------------------------------------------*/
typedef struct olmMsgHead
{
    unsigned int    mMsg;                       /* message type(16 bit) & name (16 bit) */
    char            mInfo[MSG_HEAD_INFO_SIZE];  /* additional user info                 */
} olmMsgHead;

typedef struct olmMsgBuf
{
    olmMsgHead      mHead;
    char            mBody[MAX_MSG_SIZE-sizeof(olmMsgHead)];
} olmMsgBuf;


/*--------------------------------------------------------
 * macro util for message processing
 --------------------------------------------------------*/
#define MK_MSG(type,name)           ( (type << 16) | (name & 0xffff) )
#define GET_MSG_TYPE(msg)           ( (msg >> 16) & 0xffff )
#define GET_MSG_NAME(msg)           ( msg & 0xffff )

#define MK_HEAD( aHead, aMsgType, aMsgName, aMsgSize, aInfo, aInfoLen ) \
{                                                                       \
    (aHead)->mMsg = MK_MSG(aMsgType,aMsgName);                          \
    if( aInfo != NULL && aInfoLen != 0 )                                \
    {                                                                   \
        memcpy(aHead->mInfo, aInfo, aInfoLen % MSG_HEAD_INFO_SIZE);     \
    }                                                                   \
}

#define MSG_HD_SIZE  sizeof(olmMsgHead)

/*--------------------------------------------------------
 * message type
 --------------------------------------------------------*/
typedef enum olmMessageType
{
    MSG_TYPE_REQ        ,
    MSG_TYPE_RSP        ,
    MSG_TYPE_RPT
} olmMessageType;

/*--------------------------------------------------------
 * message name
 --------------------------------------------------------*/
typedef enum olmMessageName
{
    /* admin message */
    MSG_CREATE_VMG      = MSG_ADMIN_BASE,       /* VMG 생성                     */
    MSG_CREATE_USER     ,                       /* User 생성                    */
    MSG_QRY_VMG_LIST    ,                       /* VMG List 조회                */
    MSG_QRY_VMG_INFO    ,                       /* 특정 VMG 상세 조회           */
    MSG_QRY_USER_LIST   ,                       /* User List 조회               */
    MSG_PREP_OBJECT     ,                       /* create & parepare dbm object */

    /* client message */
    MSG_CONNECT         = MSG_CLIENT_BASE,      /* VMG 에 접속                  */
    MSG_RECONNECT       ,
    MSG_DISCONNECT      ,
    MSG_SUBSCRIBE       ,
    MSG_PUBLISH         ,
    MSG_UNSUBSCRIBE     ,
    MSG_DBM_OPERATE     ,
    MSG_REQ_REPLY
} olmMessageName;

typedef enum olmDbmOperType
{
    OPER_INSERT         ,
    OPER_UPDATE         ,
    OPER_DELETE         ,
    OPER_SELECT         ,
    OPER_SELECT_LOCK    ,
    OPER_ENQUEUE        ,
    OPER_DEQUEUE
} olmDbmOperType;

/*--------------------------------------------------------
 * common info structure
 --------------------------------------------------------*/
/* VMG 정보 */
typedef struct olmVMGInfo
{
    char            mVMGName[MAX_VMG_NAME_LEN];
    int             mMaxClient;
    int             mMaxObjCnt;
    /* add more info here if exists */
} olmVMGInfo;

/* user 정보 */
typedef struct olmUserInfo
{
    char            mUserName[MAX_USER_NAME_LEN];
    char            mUserPass[MAX_AUTH_KEY_LEN];
    /* add more info here if exists */
} olmUserInfo;


/*--------------------------------------------------------
 * sub message structure for admin
 --------------------------------------------------------*/
/*
 * admin tool 을 통해 VMG 를 생성할 때 사용한다.
 */
typedef struct olmReqCreateVMG
{
    olmVMGInfo      mVMGInfo;
} olmReqCreateVMG;

typedef struct olmRspCreateVMG
{
    int             mResult;
} olmRspCreateVMG;


/*
 * admin tool 을 통해 User 를 생성할 때 사용
 * Client 는 이렇게 등록된 User 를 통해 인증이 되어야만
 * OLM Engine 에 접속이 가능하다.
 */
typedef struct olmReqCreateUser
{
    short           mNameLen;
    char            mUserName[MAX_USER_NAME_LEN];
    short           mPassLen;
    char            mUserPass[MAX_AUTH_KEY_LEN];
} olmReqCreateUser;

typedef struct olmRspCreateUser
{
    int             mResult;
} olmRspCreateUser;


/*
 * OLM Engine 에 생성되어 있는 VMG List 를 조회한다.
 */
typedef struct olmReqQryVMGList
{
    int             mNull;
} olmReqQryVMGList;

typedef struct olmRspQryVMGList
{
    int             mResult;
    short           mVMGCount;
    olmVMGInfo      mVMGList[MAX_QRY_COUNT];
} olmRspQryVMGList;


/*
 * 특정 VMG 에 대한 상세정보를 조회한다.
 */
typedef struct olmReqQryVMGInfo
{
    char            mVMGName[MAX_VMG_NAME_LEN];
} olmReqQryVMGInfo;

typedef struct olmRspQryVMGInfo
{
    int             mResult;
    olmVMGInfo      mVMGInfo;
} olmRspQryVMGInfo;


/*
 * 현재 OLM Engine 에 생성되어 있는 User 의 리스트를 조회한다.
 */
typedef struct olmReqQryUserList
{
    int             mNull;
} olmReqQryUserList;

typedef struct olmRspQryUserList
{
    int             mResult;
    short           mUserCount;
    olmUserInfo     mUserList[MAX_QRY_COUNT];
} olmRspQryUserList;

/*
 * DBM 의 Queue 및 Table 등 Object 생성 시 사용한다.
 * DBM 의 metaManager 에서 입력하는 것과 같은 형태로 string 을 전달.
 *   (string 을 만드는 것은 admin tool 에서 하면 된다)
 */
typedef struct olmReqPrepObject
{
    char            mQryStr[MAX_QRY_STR_LEN];
} olmReqPrepObject;

typedef struct olmRspPrepObject
{
    int             mResult;
} olmRspPrepObject;


/*--------------------------------------------------------
 * sub message structure for client
 --------------------------------------------------------*/
/*
 * Client(Publisher, Subscriber)가 OLM Engine 에 접속 시 사용한다.
 * Connect(인증키발급) -> Reconnect (Session ID 발급)
 */
typedef struct olmReqConnect
{
    char            mVMGName[MAX_VMG_NAME_LEN];
    olmUserInfo     mUserInfo;
} olmReqConnect;

typedef struct olmRspConnect
{
    int             mResult;
    char            mVMGName[MAX_VMG_NAME_LEN];
    char            mAuthKey[MAX_AUTH_KEY_LEN];
    int             mConnPort;
} olmRspConnect;

typedef struct olmReqReconnect
{
    char            mVMGName[MAX_VMG_NAME_LEN];
    char            mAuthKey[MAX_AUTH_KEY_LEN];
} olmReqReconnect;

typedef struct olmRspReconnect
{
    int             mResult;
    char            mVMGName[MAX_VMG_NAME_LEN];
    long long       mSessionID;
} olmRspReconnect;


/*
 * Disconnect from VMG
 */
typedef struct olmReqDisconnect
{
    char            mAuthKey[MAX_AUTH_KEY_LEN];
} olmReqDisconnect;

typedef struct olmRspDisconnect
{
    int             mResult;
} olmRspDisconnect;


/*
 * Subscribe Topic
 */
typedef struct olmReqSubscribe
{
    char            mTopicName[MAX_TOPIC_NAME_LEN];
} olmReqSubscribe;

typedef struct olmRspSubscribe
{
    int             mResult;
} olmRspSubscribe;


/*
 * Publish Topic Message
 */
typedef struct olmReqPublish
{
    char            mTopicName[MAX_TOPIC_NAME_LEN];
    char            mUserMsg;   /* starting point of user msg */
} olmReqPublish;

typedef struct olmRspPublish
{
    int             mResult;
    char            mTopicName[MAX_TOPIC_NAME_LEN];
} olmRspPublish;


/*
 * Unsubscribe Topic
 */
typedef struct olmReqUnsubscribe
{
    char            mTopicName[MAX_TOPIC_NAME_LEN];
} olmReqUnsubscribe;

typedef struct olmRspUnsubscribe
{
    int             mResult;
} olmRspUnsubscribe;


/*
 * DBM operation
 */
typedef struct olmReqDbmOperate
{
    olmDbmOperType  mOperType;

    char            mObjName[DBM_OBJECT_NAME_LEN];
    char            mKey[DBM_INDEX_KEY_MAX_SIZE];
    char            mUserMsg;   /* starting point of value */
} olmReqDbmOperate;

typedef struct olmRspDbmOperate
{
    int             mResult;
    olmDbmOperType  mOperType;
} olmRspDbmOperate;


#ifdef __cplusplus
};
#endif

#endif  /* __O_OLM_MESSAGE_H__ */
