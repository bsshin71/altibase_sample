/******************************************************************************
* Copyright 2012, OnmirSoft Corporation or its subsidiaries.
* All rights reserved.
******************************************************************************/

/*******************************************************************************
* $Id$
*
* Description :
*
******************************************************************************/

#ifndef __O_CMN_UDS_H__
#define __O_CMN_UDS_H__

#include "mvp.h"


#ifdef __cplusplus
extern "C" {
#endif


extern _VOID cmnUdsServerOpen ( int* aSockFd, char* aPath, int aNonBlockF, int aBufSize );

extern _VOID cmnUdsConnect ( int* aSockFd, char* aPath, int aNonBlockF, int aBufSize );

extern _VOID cmnUdsAccept( int aListenSockFd, int* aNewSockFd, int aNonBlockF );

extern _VOID cmnUdsOpen( int* aSockFd, char* aFileKeyPath, int aNonBlockF, int aBufSize );

extern _VOID cmnUdsSend ( int aSockFd, char* aBuf, int aSize, int* aSentSize );

extern _VOID cmnUdsSendTo ( int aSockFd, char* aServerPath, char* aBuf, int aSize, int* aSentSize );

extern _VOID cmnUdsRecv ( int aSockFd, char* aBuf, int* aRecvedSize );

extern _VOID cmnUdsRecvFrom ( int aSockFd, char* aClientPath, char* aBuf, int aSize, int* aRecvedSize );

extern _VOID cmnUdsClose ( int aSockFD );


#ifdef __cplusplus
}
#endif

#endif  /* __O_CMN_UDS_H__ */
