/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/
#ifndef __ONMIR_MVP_H__
#define __ONMIR_MVP_H__

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <errno.h>
#include <assert.h>
#include <stdarg.h>
#include <limits.h>
#include <signal.h>
#include <ctype.h>
#include <getopt.h>
#include <time.h>
#include <math.h>
#include <fcntl.h>
#include <semaphore.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>

#ifdef __linux__

#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <sys/mman.h>
#include <sys/uio.h>
#include <sys/ioctl.h>
#include <sys/syscall.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <linux/socket.h>
#include <linux/unistd.h>
#include <linux/futex.h>
#include <execinfo.h>       // backtrace
#include <dlfcn.h>          // dlopen

#endif /* __linux__ */

#include "cmnDef.h"
#include "cmnException.h"
#include "cmnError.h"
#include "cmnDefine.h"
#include "cmnLogApi.h"
#include "cmnUtil.h"
#include "cmnRTF.h"


#ifdef __cplusplus
extern "C" {
#endif

/****************************************************
 * Atomic Operation
 *   - assembly 코드가 이해안되면 아래 사이트를 보시라.
 *     http://wiki.kldp.org/KoreanDoc/html/GCC_Inline_Assembly-KLDP/c41.html
****************************************************/
/*
 * aAddr 에 들어있는 값이 aCmp 와 같으면 aWith 값으로 대체하고
 * aAddr 의 이전값을 리턴한다.
 * aAddr 에 들어있는 값이 aCmp 와 다르면 그냥 이전 aAddr 값을
 * 리턴한다.
 */
_INLINE
int mvpAtomicCas32( volatile void*  aAddr,
                    volatile int    aWith,
                    volatile int    aCmp )
{
    int     sPrev;

    __asm__ __volatile__ ( "lock; cmpxchgl %1,%2"
                          : "=a"(sPrev)
                          : "r"(aWith),
                            "m"(*(volatile int*)aAddr),
                            "0"(aCmp)
                          : "memory" );
    return sPrev;
}


_INLINE
int mvpAtomicSet32( volatile void* aAddr, volatile int aVal )
{
    __asm__ __volatile__ ( "xchgl %0,%1"
                          : "=r"(aVal)
                          : "m"(*(volatile int*)aAddr), "0"(aVal)
                          : "memory" );
    return aVal;
}


_INLINE
int mvpAtomicAdd32( volatile void* aAddr, volatile int aVal )
{
    int     sTemp = aVal;

    __asm__ __volatile__ ( "lock; xaddl %0,%1"
                          : "+r"(sTemp), "+m"(*(volatile int*)aAddr)
                          :
                          : "memory" );
    return sTemp + aVal;
}


/*
 * TODO: [WIN64] g++ 이 64bit 버전 설치했으나, 아래 오류
 *       Error: incorrect register `%edx' used with `q' suffix
 */

_INLINE
long long mvpAtomicCas64( volatile void* aAddr, volatile long long  aWith, volatile long long  aCmp )
{
#ifdef __linux__    //TODO: [OKT] 윈도포팅
    long long sPrev;

    __asm__ __volatile__ ( "lock; cmpxchgq %1,%2"
                          : "=a"(sPrev)
                          : "r"(aWith),
                            "m"(*(volatile long long*)aAddr),
                            "0"(aCmp)
                          : "memory" );
    return sPrev;

#else
    return __sync_val_compare_and_swap( (unsigned long long*)aAddr, aCmp, aWith );
#endif /* __linux__ */
}


_INLINE
long long mvpAtomicGet64( volatile void* aAddr )
{
    return *(volatile long long*)aAddr;
}


_INLINE
long long mvpAtomicSet64( volatile void* aAddr, volatile long long aVal )
{
    __asm__ __volatile__ ( "xchgq %0,%1"
                          : "=r"(aVal)
                          : "m"(*(volatile long long*)aAddr), "0"(aVal)
                          : "memory" );
    return aVal;
}


_INLINE
long long mvpAtomicAdd64( volatile void* aAddr, volatile long long aVal )
{
    long long sPrev = aVal;

    __asm__ __volatile__ ("lock; xaddq %0,%1"
                          : "+r"(sPrev), "+m"(*(volatile long long*)aAddr)
                          :
                          : "memory");
    return sPrev + aVal;
}

_INLINE
int mvpAtomicGet32 ( volatile void* aAddr )
{
    return *(volatile int*) aAddr;
}

_INLINE
int mvpAtomicInc32 ( volatile void* aAddr )
{
    return mvpAtomicAdd32 ( aAddr, 1 );
}

_INLINE
int mvpAtomicDec32 ( volatile void* aAddr )
{
    return mvpAtomicAdd32 ( aAddr, -1 );
}

_INLINE
long long mvpAtomicInc64 ( volatile void* aAddr )
{
    return mvpAtomicAdd64 ( aAddr, 1 );
}

_INLINE
long long mvpAtomicDec64 ( volatile void* aAddr )
{
    return mvpAtomicAdd64 ( aAddr, -1 );
}

#ifdef __cplusplus
}
#endif


#endif /* __ONMIR_MVP_H__ */
