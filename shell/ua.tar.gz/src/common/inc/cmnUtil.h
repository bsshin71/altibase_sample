/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    Posix Shm Library
 ******************************************************************************/

#ifndef __O_CMN_UTIL_H__
#define __O_CMN_UTIL_H__

#include "mvp.h"
#include "cmnLock.h"

/******************************************************************************
 * POSIX 시스템 콜 래퍼 ( for MinGW )
 * 2015.02.12 -okt- 윈도우 포팅
******************************************************************************/
#ifndef __linux__

//#define __MSVCRT_VERSION__                (0x0800)

#include <SDKDDKVer.h>

#define WIN32_LEAN_AND_MEAN             // 거의 사용되지 않는 내용은 Windows 헤더에서 제외합니다.
// Windows 헤더 파일:
#include <windows.h>

#include <stdexcept>
#include <winsock2.h>
#include <ws2tcpip.h>

#include <malloc.h>                     // _aligned_malloc

#endif /* __linux__ */


#ifdef __cplusplus
extern "C" {
#endif

/******************************************************************************
 * POSIX 시스템 콜 래퍼 ( for MinGW )
 * 2015.02.12 -okt- 윈도우 포팅
******************************************************************************/
#ifdef __linux__

#define clock_gettime_s     clock_gettime
#define gethostid_s         gethostid
#define strptime_s          strptime
#define basename_s          basename
#define localtime_s         localtime
#define localtime_r_s       localtime_r
#define lstat_s             lstat
#define strtok_r_s          strtok_r

#else

#define memalign            _aligned_malloc

extern int clock_gettime_s_( int clk_id, void* tv );
#define clock_gettime_s     clock_gettime_s_

extern int32_t gethostid_s_( );
#define gethostid_s         gethostid_s_

extern char* strptime_s_( const char* buf, const char* fmt, struct tm* tm );
#define strptime_s          strptime_s_

extern char* basename_s_( char* path );
#define basename_s          basename_s_

//TODO: [OKT] 윈도포팅, struct timeval 구조체의 tv_sec 에 대한 정의가 윈도우에서 다르다.
extern struct tm* localtime_r_s_( const long* timep, struct tm* result );
#define localtime_r_s       localtime_r_s_

extern struct tm* localtime_s_( const long* timep );
#define localtime_s         localtime_s_

#define lstat_s             stat

extern char* strtok_r_s_( char* str, const char* delim, char** saveptr );
#define strtok_r_s          strtok_r_s_

#endif /* __linux__ */

_INLINE
int mkdir_s ( const char *pathname, mode_t mode )
{
#ifdef __linux__
    return mkdir ( pathname, mode );
#else
    return mkdir ( pathname );
#endif /* __linux__ */
}



/******************************************************************************
 * POSIX (이하)
******************************************************************************/

/******************************************************************************
 * 공통 util (일반)
******************************************************************************/

extern mvp_pid_t getpid_s ( );
//extern mvp_pid_t gettid_s ( ); // [패키기] 노출을 위해 cmnDef.h에 정의됨.
extern pthread_t pthread_self_s ( );

#ifdef __linux__    //TODO: [OKT]  윈도포팅

extern _VOID cmnDlopen ( const char* aLibName, void** ppHandle );
extern _VOID cmnDlsym ( void* aHandle, const char* aFuncName, void** ppFunc );
extern _VOID cmnDlclose ( void* aHandle );

#else

#define cmnDlopen(...)              (-1)
#define cmnDlsym(...)               (-1)
#define cmnDlclose(...)             (-1)

#endif /* __linux__ */

extern _VOID cmnAccess ( char* pathname, int mode );

#ifdef _OKT_TRC_CALLER
#define cmnStrCpy           strncpy_s
#else
extern char* cmnStrCpy ( char* dest , const char* src , size_t len );
#endif
#define cmnStrCpyZ(a,b)     cmnStrCpy(a,b,sizeof(a))

extern long long cmnGetBuddy (long long aInput);
extern long long cmnGetSquare ( int i );
extern _VOID cmnCallStack( int sig );

extern _BOOL isalpha_s ( int c );
extern _BOOL cmnIsDigit ( char* aStr );


/******************************************************************************
 * 공통 util (시간)
******************************************************************************/

// DO: DateOnly, TM: Time, DT: DateTime
enum CMN_TIME_FMT
{
      TIME_FMT_ANY = -1     // flag를 명시하지 않고, len을 가지고 flag를 결정하는 용도
    , TIME_FMT_DO           // yyyymmdd : 8
    , TIME_FMT_DO_DELI      // yyyy/mm/dd : 10                      // [note] 홀수 값이 xx_DELI 구분자 있는 형태임.
    , TIME_FMT_DT_F0        // yyyymmddhhmiss : 14
    , TIME_FMT_DT_F0_DELI   // yyyy/mm/dd hh:mi:ss : 19
    , TIME_FMT_DT_F3        // yyyymmddhhmisssss : 17
    , TIME_FMT_DT_F3_DELI   // yyyy/mm/dd hh:mi:ss.sss : 23
    , TIME_FMT_DT_F6        // yyyymmddhhmissssssss : 20
    , TIME_FMT_DT_F6_DELI   // yyyy/mm/dd hh:mi:ss.ssssss : 26

    , TIME_FMT_TM_F0        // hhmiss : 6
    , TIME_FMT_TM_F0_DELI   // hh:mi:ss : 8
    , TIME_FMT_TM_F3        // hhmisssss : 9
    , TIME_FMT_TM_F3_DELI   // hh:mi:ss.sss : 11
    , TIME_FMT_TM_F6        // hhmissssssss : 12
    , TIME_FMT_TM_F6_DELI   // hh:mi:ss.ssssss : 15
};

#define CMN_NSLEEP_DEGREE       (5)             // cpu_relax() 어셈에 의한 예상 비용
#define CMN_YSLEEP_DEGREE       (2000)          // 2 usec, pthread_yield() 호출의 예상 비용
#define CMN_USLEEP_DEGREE       (1000*40)       // usleep에 대한 정밀도 한계 예상 비용. (20us 라는 경험치도 있다)

/**
 * @brief read-write barrier for compiler
 * @note
 *  1. __sync_synchronize() 는 cpu 최적화 까지 막음.
 *  2. http://locklessinc.com/articles/locks/
 */
#define barrier()               asm volatile("": : :"memory")

/**
 * @brief busy wait
 *        Pause instruction to prevent excess processor bus usage
 */
#define cpu_relax()             asm volatile("pause\n": : :"memory")


extern void cmnUSleep ( long long uSec );
extern void cmnNanoSleep ( long long nSec );


#ifdef __cplusplus
extern char* cmnTime2Str ( int aFmtLen, char* pDst = NULL, int flag = TIME_FMT_ANY, struct timeval* input_time = NULL );
extern char* cmnTime2StrN( int aFmtLen, char* pDst = NULL, int flag = TIME_FMT_ANY, struct timeval* input_time = NULL );
#else
extern char* cmnTime2Str ( int aFmtLen, char* pDst, int flag, struct timeval* input_time );
extern char* cmnTime2StrN( int aFmtLen, char* pDst, int flag, struct timeval* input_time );
#endif


/******************************************************************************
 * 나중에 위치 결정
******************************************************************************/

#ifdef _DEBUG
/*
 * 개수 변동되면,
 * PerfCount g_cnt_perf = { 0, 0, 0, 0, 0,   0, 0, 0, 0, 0,   0, 0, 0, 0 };
 * 를 cpp 파일에서 수정요.
 */
typedef struct PerfCount
{
    volatile unsigned int tkill;
    volatile unsigned int pthread_yield;
    volatile unsigned int pthread_yield_d;

    volatile unsigned int memset;
    volatile unsigned int malloc;
    volatile unsigned int memcpy;
    volatile unsigned int memcmp;
    volatile unsigned int memmove;

    volatile unsigned int strlen;
    volatile unsigned int strcmp;
    volatile unsigned int strncmp;
    volatile unsigned int strcpy;
    volatile unsigned int strncpy;

    volatile unsigned int write;
    volatile unsigned int read;
    volatile unsigned int lseek;

    volatile unsigned int sprintf;
    volatile unsigned int snprintf;
} PerfCount;

extern PerfCount g_cnt_perf;

#endif /* _DEBUG */


#ifdef _OKT_TRC_CALLER

#define atomic_inc_s(a)                 atomic_inc(a)
extern void print_map_perf ( void* pMap );

#else

#define atomic_inc_s(a)

#endif

#ifdef __cplusplus
}
#endif


/******************************************************************************
 * 그외
******************************************************************************/

/**
 * @brief
 *  [성능] 나누기(나머지) 연산의 Cost 는 매우 높다. memcpy에 필적한다.
 * @return
 *      = N % ( 2 ^ S )
 *
 * [참고]
 *  http://graphics.stanford.edu/~seander/bithacks.html#SwappingValuesXOR
 */
_INLINE
int cmnIsPowerNum ( long long v )
{
    return (int)( (v & (v - 1)) == 0 );
    //return( v && !(v & (v - 1)) );
}

_INLINE
long long cmnPowerMod ( long long n, long long s )
{
#ifdef _DEBUG
    if ( ! cmnIsPowerNum( s ) )
    {
        assert( 0 && "인자가 2의 거듭제곱(지수)이어야함" );
    }
#endif

    const long long d = 1U << s; // So d will be one of: 1, 2, 4, 8, 16, 32, ...
    return( n & (d - 1) );           // n % d
}

_INLINE
long long cmnPowerNumGE ( long long n )
{
    int     i;

    if ( cmnIsPowerNum( n ) )
    {
        return n;
    }

    for ( i = 0; ; i++ )
    {
        if ( n <= ( 1 << i ) )
        {
            return ( i << 1 );
        }
    }

    return -1; // NEVER
}

// 어떤수의 최소 배수
//#define ROUND_PAGE(x) (((x) + PAGE_SIZE - 1) & ~(PAGE_SIZE - 1))


/******************************************************************************
 * 시스템 콜 래퍼 ( Non-Portable )
******************************************************************************/

#ifdef _OKT_TRC_CALLER

extern int tkill_s_ ( mvp_pid_t tid, int sig, const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define tkill_s(a,b)    tkill_s_(a,b,_WHERE)

#else

_INLINE
int tkill_s ( mvp_pid_t tid, int sig )
{
    atomic_inc_s ( & g_cnt_perf.tkill );

#ifdef __linux__
//  return syscall ( SYS_tgkill, -1, tid, sig );
    return syscall ( SYS_tkill, tid, sig );
#else
    assert( 0 && "[WIN32] not yet supported" );
    return -1;
#endif /* __linux__ */
}

#endif

_INLINE
int tgkill_s ( int tgid, int tid, int sig )
{
#ifdef __linux__
    return syscall ( SYS_tgkill, tgid, tid, sig );
#else
    assert( 0 && "[WIN32] not yet supported" );
    return -1;
#endif /* __linux__ */
}

/******************************************************************************
 * 시스템 콜 래퍼
******************************************************************************/

// [OKT] XX_s 접미어를 OS 시스템콜에 대한 단순 레퍼이나, '안전' 의미로 사용 ( 혹은 단순 카운트 확인 )

#ifdef _OKT_TRC_CALLER

extern void* malloc_s_ ( size_t size, const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define malloc_s(a)     malloc_s_(a,_WHERE)

#else

_INLINE
void *malloc_s ( size_t size )
{
    void* pOut = NULL;

    atomic_inc_s ( & g_cnt_perf.malloc );

    pOut = malloc ( size );
    if ( pOut == NULL )
    {
        // malloc 이 실패할 정도면 abort로 바로 죽자.
        _ASSERT ( 0 );
    }
    return pOut;
}

#endif  /* _OKT_TRC_CALLER */

_INLINE
void* memalign_s ( size_t size, size_t alignment = 0 )          // 주의) 인자순서가 반대임.
{
    void*   pOut = NULL;
    int     sRC;

    atomic_inc_s ( & g_cnt_perf.malloc );

#ifdef __linux__
    sRC = posix_memalign ( &pOut, alignment == 0 ? DBM_CLS_LEN : alignment, size );

    if ( sRC != 0 )
    {
        // malloc 이 실패할 정도면 abort로 바로 죽자.
        _ASSERT ( 0 );
    }
#else
    //pOut = _aligned_malloc( size, alignment == 0 ? DBM_CLS_LEN : alignment );
    pOut = memalign ( size, alignment == 0 ? DBM_CLS_LEN : alignment );

    if ( pOut == NULL )
    {
        // malloc 이 실패할 정도면 abort로 바로 죽자.
        _ASSERT ( 0 );
    }
#endif /* __linux__ */

    return pOut;
}


/******************************************************************************
 * 시스템 콜 래퍼
 *
 * 주요 시스템콜에 대한 성능 추적 랩퍼함수.
 * release에서는 native를 호출하고,
 * debug에서는 래퍼를 호출하고.
 * debug + _OKT_TRC_CALLER 일때는 호출 위치까지 기록하면서 추적한다.
 *
 * 특이하게 pthread_yield_d() 의 경우 쉬지않는 retry 횟수를 추적하기 위한 용도로서.
 * release에서는 아무것도 안한다.
 *
******************************************************************************/

#define bzero_s(s,n)        memset_s(s,0x00,n)

#ifndef _DEBUG

#ifdef __linux__    //TODO: [OKT]  윈도포팅
#define pthread_yield_s     pthread_yield
#else
#define pthread_yield_s     sched_yield
#endif /* __linux__ */

#define pthread_yield_d()

#define strlen_s            strlen
#define strcmp_s            strcmp
#define strncmp_s           strncmp
#define strcpy_s            strcpy
#define strncpy_s           strncpy
#define memset_s            memset
#define memmove_s           memmove
#define memcpy_s            memcpy
#define memcmp_s            memcmp

#define write_s             write
#define read_s              read
#define lseek_s             lseek

#else   /* _DEBUG */

#ifdef _OKT_TRC_CALLER

extern int pthread_yield_s_ ( const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define pthread_yield_s()   pthread_yield_s_(_WHERE)

extern int pthread_yield_d_ ( const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define pthread_yield_d()   pthread_yield_d_(_WHERE)


/******************************************************************************
 * 문자 함수
 *****************************************************************************/
extern size_t strlen_s_ ( const char *s, const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define strlen_s(a)         strlen_s_(a,_WHERE)

extern int strcmp_s_ ( const char *s1 , const char *s2, const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define strcmp_s(a,b)       strcmp_s_(a,b,_WHERE)

extern int strncmp_s_ ( const char *s1 , const char *s2, size_t n, const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define strncmp_s(a,b,n)    strncmp_s_(a,b,n,_WHERE)

extern char* strcpy_s_ ( char *s1 , const char *s2, const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define strcpy_s(a,b)       strcpy_s_(a,b,_WHERE)

extern char* strncpy_s_ ( char *s1 , const char *s2, size_t n, const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define strncpy_s(a,b,n)    strncpy_s_(a,b,n,_WHERE)


/******************************************************************************
 * 메모리 함수
 *****************************************************************************/
extern void* memset_s_ ( void *dest , int cSrc , size_t len, const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define memset_s(a,b,c)     memset_s_(a,b,c,_WHERE)

extern void* memmove_s_ ( void *dest , const void *src , size_t len, const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define memmove_s(a,b,c)     memmove_s_(a,b,c,_WHERE)

extern void* memcpy_s_ ( void *dest , const void *src , size_t len, const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define memcpy_s(a,b,c)     memcpy_s_(a,b,c,_WHERE)

extern int memcmp_s_ ( void *dest , const void *src , size_t len, const char* file = __FILE__, const char* func = __FUNCTION__, int line = __LINE__ );
#define memcmp_s(a,b,c)     memcmp_s_(a,b,c,_WHERE)


#else   /* _OKT_TRC_CALLER */

_INLINE
int pthread_yield_s()
{
    atomic_inc_s ( & g_cnt_perf.pthread_yield );
#ifdef __linux__
    return pthread_yield();
#else
    return sched_yield();
#endif /* __linux__ */
}

/*
 * 아무것도 아나고 retry 하는 코드를 추적하기 위한 용도.
 */
_INLINE
int pthread_yield_d()
{
    atomic_inc_s ( & g_cnt_perf.pthread_yield_d );
    return 0;               // 실재로는 쉬지 않고, 횟수만 체크하는 더미 역활.
}


/******************************************************************************
 * 문자 함수
 *****************************************************************************/
_INLINE
size_t strlen_s ( const char *s )
{
    atomic_inc_s ( & g_cnt_perf.strlen );
    return strlen ( s );
}

_INLINE
int strcmp_s ( const char *s1 , const char *s2 )
{
    atomic_inc_s ( & g_cnt_perf.strcmp );
    return strcmp ( s1, s2 );
}

_INLINE
int strncmp_s ( const char *s1 , const char *s2 , size_t n )
{
    atomic_inc_s ( & g_cnt_perf.strncmp );
    return strncmp ( s1, s2, n );
}

_INLINE
char* strcpy_s ( char* dest , const char* src )
{
    atomic_inc_s ( &g_cnt_perf.strcpy );
    return strcpy ( dest, src );
}

_INLINE
char* strncpy_s ( char* dest , const char* src , size_t len )
{
    atomic_inc_s ( &g_cnt_perf.strncpy );
    return strncpy ( dest, src, len );
}


/******************************************************************************
 * 메모리 함수
 *****************************************************************************/
_INLINE
void* memset_s ( void *dest , int cSrc , size_t len )
{
    atomic_inc_s ( &g_cnt_perf.memset );

    _DASSERT( len < (size_t)(1<<31) );              // 가끔 음수가 들어온다.
    return memset ( dest, cSrc, len );
}

_INLINE
void* memmove_s ( void *dest , const void *src , size_t len )
{
    atomic_inc_s ( &g_cnt_perf.memmove );
    return memmove ( dest, src, len );
}

_INLINE
void* memcpy_s ( void *dest , const void *src , size_t len )
{
    atomic_inc_s ( &g_cnt_perf.memcpy );

    _DASSERT( len < (size_t)(1<<31) );              // 가끔 음수가 들어온다.
    return memcpy ( dest, src, len );
}

_INLINE
int memcmp_s (const void *s1, const void *s2, size_t n)
{
    atomic_inc_s ( &g_cnt_perf.memcmp );
    return memcmp ( s1, s2, n );
}

#endif  /* _OKT_TRC_CALLER */


_INLINE
ssize_t write_s ( int fd, void* buf, size_t count )
{
    atomic_inc_s ( &g_cnt_perf.write );
    return write ( fd, buf, count );
}

_INLINE
ssize_t read_s ( int fd, void* buf, size_t count )
{
    atomic_inc_s ( &g_cnt_perf.read );
    return read ( fd, buf, count );
}

_INLINE
off_t lseek_s ( int fd, off_t offset, int whence )
{
    atomic_inc_s ( &g_cnt_perf.lseek );
    return lseek ( fd, offset, whence );
}


#endif  /* _DEBUG */



// 2014.12.14. -okt- _WHERE 추가인자를 뒤가 아니고 앞에 붙이는게 가능할듯.
#if 0 //def _DEBUG

/*
 * [최종결과]
 * 가변인자에 대한 후킹이 "Variadic Templates" 로도 오류가 난다.. 방법을 못찾음.
 */

/*
 * 아래 형태를 하고 싶으나, 문제는 리턴을 받아서 처리하는 업무가 있다.
#define sprintf_s(str, ...) \
{ \
    atomic_inc_s ( &g_cnt_perf.sprintf ); \
    sprintf ( str, ##__VA_ARGS__); \
}
 */

template <typename... T>                            /* Variadic Templates (성능느리겠지) */
int sprintf_s ( char* str, T&... format )
{
    atomic_inc_s ( &g_cnt_perf.sprintf );
//  return sprintf ( str, format, ##__VA_ARGS__ );
    return sprintf ( str, format... );
}

template <typename... T>
int snprintf_s ( char* str, size_t size, T&... format )
{
    atomic_inc_s ( &g_cnt_perf.snprintf );
    return snprintf ( str, size, format... );
}

#endif
#else
#define sprintf_s               sprintf
#define snprintf_s              snprintf
#endif
