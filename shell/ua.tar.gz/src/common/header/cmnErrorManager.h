/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    DBM Error Message를 관리한다.
*******************************************************************************/
#ifndef __O_CMN_ERROR_INTERFACE_H__
#define __O_CMN_ERROR_INTERFACE_H__

#ifdef __cplusplus

#include <map>
#include <string>

/*******************************************************************************
 * CLASS
*******************************************************************************/
class cmnErrorManager
{
public:
    cmnErrorManager( );
    ~cmnErrorManager( );

    static _VOID init ( );
    static void mErrorGetMessage( char* aErrMsg , int aUserErrorCode );

private:
    static int mErrorGetFormat  ( char* aFormat, int aUserErrorCode );

public:
    static std::map<int, std::string>* mErrMap;

    /*
     * 2014/09/16 (OKT)
     * 사용되지 않는 dbmGetErrorByHandle() 함수를 없애서, 각 함수들에서 매번 mErrCode 셋팅하는것을 제거한다.
     */
    //void mGetMessage ( char* aErrMsg );
    //int     mErrCode;
};

#endif

#endif  /* __O_CMN_ERROR_INTERFACE_H__ */

