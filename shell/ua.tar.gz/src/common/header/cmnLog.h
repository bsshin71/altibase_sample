/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *
 ******************************************************************************/

#ifndef __O_CMN_LOG_H__
#define __O_CMN_LOG_H__

#include "mvp.h"


#define cmnLog(a,b,c, ... )         cmnLogImp(a, b, __func__, __LINE__, c, ##__VA_ARGS__)

/*********** Macro Definition *************************************************/

/* 로그가 가질 수 있는 최대 길이 */
#define MAX_SIZE_PER_LOG            2048
/* 로그파일의 이름의 최대 길이 */
#define MAX_FILE_NAME_LENGTH        1024
/* FUNCTION 이름이 가지는 최대 길이 */
#define FUNCTION_NAME_LENGTH        64
/******************************************************************************/




/*********** Type Definition **************************************************/

typedef enum _cmnLogLevel {
    C = (1 << 0),                       /*** Critical ***/
    E = (1 << 1),                       /*** Error    ***/
    W = (1 << 2),                       /*** Warning  ***/
    D = (1 << 3),                       /*** Debug    ***/
    I = (1 << 4),                       /*** Info     ***/
    A = ((1 << 5) - 1 )                 /*** All      ***/
} _cmnLogLevel ;


typedef struct cmnLogHandle
{
    char            mLogFileName[MAX_FILE_NAME_LENGTH];     /**< 파일 위치 */
    _cmnLogLevel    mLogLevel ;                             /**< 로그 레벨 */
    int             mLogLineLength ;                        /**< 로그 라인 사이즈 */
    int             mLogBufCount ;                          /**< 저장할 라인 갯수 */
    pthread_t       mSynchorThread;                         /**< Log Synchor Thread ID */
    long long       mWriteIndicator ;                       /**< 로그 Write Indicator */
    long long       mSyncIndicator ;                        /**< 로그 Sync Indicator */
    pthread_mutex_t mCondMutex;                             /**< Thread 간 동시성 제어를 위한 Mutex / Conditional variables */
    pthread_cond_t  mCond;
    int             mIsStop;                                /**< 종료 Flag */
    int             mFD;                                    /**< 파일의 FD */
} cmnLogHandle;


typedef struct cmnLogHeader
{
    char            mFunctionName[FUNCTION_NAME_LENGTH];
    int             mLogLevel;
    int             mLine;
    int             mSz;
    int             mWriteCommitFlag;                       /**< 쓰기 완료 표식 */
    struct timeval  mTime;
} cmnLogHeader ;



/******************************************************************************/

/* 2014.12.14. -okt- cmnLog.h 과거 로그모듈 막을까? - static 함수가 헤더파일에 오면 안된다. */
/*********** static Function  Definition   ************************************/
extern int cmnOpenFileForLogging ( cmnLogHandle* aLogHandle, int* aFD );
extern int cmnCreateLogThread ( cmnLogHandle* aLogHandle );
/******************************************************************************/


/*********** Interface Definition   *******************************************/

#ifdef __cplusplus
extern "C" {
#endif


extern int cmnOpenLog ( char* aLogFile, char aLogLevel, int aLogBufferLength, int aLogBufferCount, cmnLogHandle** aHandle ) ;

extern void  cmnWriteLogFile ( cmnLogHandle* aLogHandle, cmnLogHeader* aLogHeader, char * aLogMsg );

extern int cmnLogImp ( cmnLogHandle* aLogHandle, int aLogLevel , const char* FunctionName, int aLineNumber, const char* Format , ... );

extern int cmnCloseLog ( cmnLogHandle** aLogHandle ) ;

/* Thread Function */
extern void* cmnSyncLogFile ( void* LogHandle ) ;


#ifdef __cplusplus
}
#endif


#endif  /* __O_CMN_LOG_H__ */
