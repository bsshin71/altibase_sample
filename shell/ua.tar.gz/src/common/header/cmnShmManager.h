/*
 * cmnShmPool.h
 *
 *  Created on: Mar 10, 2014
 *      Author: paul
 */

#ifndef CMNSHMMANAGER_H_
#define CMNSHMMANAGER_H_

#include "mvp.h"
#include "cmnEvtBase.h"


typedef struct cmnShmSt
{
    unsigned int        mRefCount;
    void*               mAddr;
    long long           mSize;
    unsigned long long  mInode;
} cmnShmSt;

////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////

#ifdef __cplusplus

#include <string>
#include <map>

/**
 * 동일한 Posix Shm에 대해서 Ref-Count를 관리하여 사용편의를 도모한다.
 */
class cmnShmManager
{
public:
    static cmnShmManager* getInstance ( );
    static _VOID mInit ( );
    static _VOID mDestroy ( );                 // atexit에서 등록을 위해 static으로 선언 (미사용)

    static _VOID mCreate ( const char* aName, long long aSize, void** ppAddr, int aFlag = 0 );
    static _VOID mDrop   ( const char* aName );
    static _VOID mAttach ( const char* aName, long long aSize, void** ppAddr );
    static _VOID mDetach ( void** ppAddr, long long aSize, int aFlag = 0 );

private:
    cmnShmManager ( );                          // 싱글톤 생성자는 노출하지않고 getInstance 호출
    ~cmnShmManager( );                          // 외부에서 싱글톤 객체를 강제 delete을 막기위해

    // 멤버변수
public:
    static cmnShmManager* instance;
    static std::map<std::string, cmnShmSt*> mShmKeyMap;

private:
    static pthread_mutex_t  m_mtx;
    static pthread_cond_t   m_cond;
};
#endif


////////////////////////////////////////////////////////////////////////////////
// C TYPE Wrapper
////////////////////////////////////////////////////////////////////////////////
#ifdef __cplusplus
extern "C"
{
#endif

extern _VOID cmnShmCreate_s ( const char* aName, long long aSize, void** ppAddr );
extern _VOID cmnShmDrop_s ( const char* aName );
extern _VOID cmnShmDetach_s ( void** ppAddr, long long aSize );
extern _VOID cmnShmAttach_s ( const char* aName, long long aSize, void** aAddr );

#ifdef __cplusplus
}
#endif


#endif /* CMNSHMMANAGER_H_ */
