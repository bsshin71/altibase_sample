/*
 * cmnEvtBase.h
 *
 *  Created on: Mar 9, 2014
 *      Author: paul
 */

#ifndef CMNEVTBASE_H_
#define CMNEVTBASE_H_

#include "cmnEvtQue.h"

////////////////////////////////////////////////////////////////////////////////
// class ( Queue를 통해 메시지 교환을 하는 이벤트 Thread )
////////////////////////////////////////////////////////////////////////////////

class cmnEvtBase
{
public:
    cmnEvtBase ( );
    virtual ~cmnEvtBase ( );            // virtual 맴버함수있으면 소멸자도 virtual

    virtual _VOID thread_main ( ) = 0;  // 자식 class의 thread main 함수
    static void *thread_routine ( void *arg );

    _VOID startThread ( );
    _VOID stopThread ( );

    _VOID sig_send ( );
    _VOID sig_wait ( int sec = 0 );


#ifdef _DBM_USE_TRACE_CALLER
    _VOID sendCmd ( int cmd, const char* file=__FILE__, const char* func=__FUNCTION__, int line=__LINE__ );
#else
    _VOID sendCmd ( int cmd );
#endif

    int             m_bRunning;
    cmnEvtQue*      m_pEvtQue;          // 이벤트 큐, 포인터변수만 가지고 있고, 자식클래스에 실재 위치

private:
    pthread_t       m_tid;

    // signal 처리
    pthread_mutex_t m_mtx;
    pthread_cond_t  m_cond;
};

#endif /* CMNEVTBASE_H_ */
