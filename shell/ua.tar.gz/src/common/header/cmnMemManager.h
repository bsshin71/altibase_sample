/*
 * cmnMemPool.h
 *
 *  Created on: Mar 10, 2014
 *      Author: paul
 */

#ifndef CMNMEMMANAGER_H_
#define CMNMEMMANAGER_H_

#include "mvp.h"
#include "cmnEvtBase.h"

////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////

enum cmnMsgCode
{
      DBM_CMD_NONE
    , DBM_CMD_DATA
    , DBM_CMD_START
    , DBM_CMD_STOP
    , DBM_CMD_QUE_FLUSH
};

typedef struct cmnWhere
{
    const char* file;
    const char* func;
    int         line;
} cmnWhere;

/**
 * @remark
 *      1. mData[0] 은 64Byte 크기로 헤더를 고정하기 위한 더미.
 *      2. cmnTime 은 컴파일 시점에 usec, nsec 정밀도 선택가능.
 */
typedef struct cmnMsgHandle
{
    int             mMark;
    volatile int    mLock;          // 현재 그다지 용도가 없다. Slot가져간 thr 추적용도 뿐.
    int             mDataType;
    int             mDataCode;      // 제어메시지
    int             mDataSize;      // 헤더를 제외한 크기
    cmnTime         mSendTm;        // 구간성능 측정. ( 송신시간을 담아 보낸다. )
#ifdef _DBM_USE_TRACE_CALLER
    struct cmnWhere mWhere;
#endif
    char            mData[0]        __attribute__((aligned (DBM_CLS_LEN))) ;           // 이러면 64
//  char            mData[1]        __attribute__((aligned (DBM_CLS_LEN))) ;           // 이러면 128 크기
} cmnMsgHandle;


#ifdef __cplusplus

////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////

class cmnMemManager
{
public:
    static cmnMemManager* getInstance ( );
    static _VOID init ( );

    _VOID mAllocSlot ( void** ppRetSlot, size_t aSize = 0 );
    _VOID mFreeSlot ( void** ppSlot );

private:
    cmnMemManager ( );
    ~cmnMemManager( );                          // 외부에서 싱글톤 객체를 강제 delete을 막기위해

    _VOID mCreate ( );
    static _VOID mDestroy( );                   // atexit에서 등록을 위해 static으로 선언
    _VOID mExtendSegment ( );                   // 락을 잡고 다음 Segment를 활당.

    // 멤버변수
public:
    static cmnMemManager* instance;

    static int      bUseMemMgr;                 // 0: 일반 malloc

    static int      mSlotMaxSize;               // 디폴트 4K (PageSize), 한 Slot의 최대 크기
    static int      mSlotCountMax;              // Segment당 Slot의 개수
    static int      mSegmentCountMax;           // 확장 가능한 최대 Segment 개수

private:
    volatile int    mLock;                      // Extend 시점에 모두 대기다.
    volatile int    mFreeLock;                  // Free 를 줄세운다.  (현재는 로그쓰레드만 Free하므로 가능은함)
//  volatile int    mAllocLock;                 // Alloc 를 줄세운다. (성능상 불가능)

//  char            mDummy1[0]  __attribute__((aligned (DBM_CLS_LEN)));
    volatile long long mHead;
    volatile int    mRemainSlotCount;
    volatile long long mAllocatedSlotCount;

    int             mSegmentCount;              // 현재 Segment 개수
    size_t          mSegmentSize;               // 하나의 Segment 크기

    long long**     mStackAddress;              // 주소만 가지고 있는 스택 영역
    void*           mStartAddress;              // 실재 데이타 영역
};
#endif /* __cplusplus */


////////////////////////////////////////////////////////////////////////////////
// C TYPE Wrapper
////////////////////////////////////////////////////////////////////////////////

#ifdef __cplusplus

extern "C"
{
#endif

_INLINE
#ifdef __cplusplus
_VOID cmnMemAllocSlot ( void** ppRetSlot, size_t aSize = 0 )
#else
_VOID cmnMemAllocSlot ( void** ppRetSlot, size_t aSize )
#endif
{
    _DASSERT ( aSize <= cmnMemManager::mSlotMaxSize - sizeof(cmnMsgHandle) );
    return cmnMemManager::getInstance()->mAllocSlot( ppRetSlot, aSize );
}

_INLINE
_VOID cmnMemFreeSlot ( void** ppAddr )
{
    return cmnMemManager::getInstance()->mFreeSlot( ppAddr );
}

#ifdef __cplusplus
}
#endif


#endif /* CMNMEMMANAGER_H_ */
