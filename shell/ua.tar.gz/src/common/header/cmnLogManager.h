/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *
 ******************************************************************************/

#ifndef __O_CMN_LOG_MANAGER_H__
#define __O_CMN_LOG_MANAGER_H__

#include "mvp.h"
#include "cmnEvtBase.h"

#ifdef __cplusplus

extern unsigned long long _dbm_nLogCnt;
extern unsigned long long _dbm_nLogCntErr;
extern unsigned long long _dbm_nLogCntWarn;

// Log Manager Class
class cmnLogManager : public cmnEvtBase
{
public:
    cmnLogManager ();

    static _VOID init ( const char* name = NULL );

    // thread 함수
    _VOID create ( );
    static _VOID destroy ( );

    // LogManager 쓰레드의 메인 함수
    _VOID thread_main();

    static _VOID openFile ( );
    static _VOID closeFile ( );
    static _VOID flush ( );
    static _VOID flush2File ( );
    static _VOID write2File ( const void* buf, int len, int flag );
    static _VOID write2ULog ( const void* buf, int len, int flag );
    static _VOID write2SLog ( const void* buf, int len, int flag );
    static _VOID makeHeader ( const char* file, const char* func, int line, int loglevel, char* buf );

private:
    ~cmnLogManager();

public:
    static cmnLogManager*       instance;
    static cmnLogManager*       user_instance;  ///< 사용자 레벨 인스턴스

    cmnEvtQue               m_LogQue;

    static int              m_nLogLevel ;                       ///< 로그 레벨
    static int              m_nLogPidType ;                     ///< 로그 ID 타입(PID, TID)
    static int              m_nLogSyncFlag ;                    ///< 로그 강제 동기화 여부

    static char             m_ulog_file [DBM_FILE_NAME_LEN];    ///< 로그 파일
    static char             m_slog_file [DBM_FILE_NAME_LEN];    ///< alert 로그 파일
    static FILE*            m_ulog;
    static FILE*            m_slog;
    static int              m_ulogFd;
    static int              m_slogFd;

    static char             service_name [DBM_SERVICE_NAME_LEN];
    static mvp_pid_t        m_nProcessId;
    static char             m_zProcessId [5 + 1];
    static char             m_zHostName [DBM_HOST_NAME_LEN];

    static int              m_nLogMaxSize;                     ///< 로그 라인 사이즈
    static int              m_nLogHeaderSize;
    static int              m_nLogHeaderPidOffset;

};

#endif // __cplusplus


#endif  /* __O_CMN_LOG_MANAGER_H__ */
