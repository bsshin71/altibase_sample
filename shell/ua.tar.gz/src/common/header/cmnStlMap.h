/*
 * cmnShmPool.h
 *
 *  Created on: Mar 10, 2014
 *      Author: paul
 */

#ifndef CMNSTLMAP_H_
#define CMNSTLMAP_H_

#include "mvp.h"


////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////

#ifdef __cplusplus

#include <string>
#include <map>

class cmnStlMap
{
public:
    cmnStlMap (  );
    cmnStlMap (  int aType );
    ~cmnStlMap( );

    _VOID mInit ( );
    _VOID mDestroy ( );

    _VOID mInsert ( void* aKey, void* aVal );
    _VOID mErase ( void* aKey );
    void* mFind ( void* aKey, void** ppVal = NULL );

    _VOID mInsert ( void* aGrp, void* aKey, void* aVal );
    _VOID mErase ( void* aGrp, void* aKey );
    void* mFind ( void* aGrp, void* aKey, void** ppVal = NULL );

    _VOID mClear ( );
    //_VOID mPrint ( int aKey = -1 ); // 이상하게 인자가 있으면 gdb에서 안불림.
    _VOID mPrint ( );

    int mSize ( );

    _VOID mLock ( );
    _VOID mUnlock ( );

public:
    int                 mType;
    union
    {
        void*                           mMap;       // 대표이름
        std::map<std::string, void*>*   mMap1;      // 미사용
        std::map<void*, std::string>*   mMap3;      // 미사용
        std::map<long long, std::string>* mMap2;      // 미사용
        char*                           mMap20;     // 100만개의 배열 ( SlotID 매칭을 빠르게 )
        std::map<std::string, void*>*   mMap100;    // segment 이름 - mMap20 ( SlotID 검색 )
    };
    cmnStlMap*          mSub;


private:
    int                 mLockF;
    pthread_mutex_t     m_mtx;
//  pthread_cond_t      m_cond;
};
#endif


////////////////////////////////////////////////////////////////////////////////
// C TYPE Wrapper
////////////////////////////////////////////////////////////////////////////////


#endif /* CMNSTLMAP_H_ */
