/*
 * cmnTimer.h
 *
 *  Created on: Mar 9, 2014
 *      Author: paul
 */

#ifndef CMNTIMER_H_
#define CMNTIMER_H_

#include "cmnApi.h"
#include "cmnEvtBase.h"

#define CMN_TIMER_CNT_MAX       10

typedef struct cmnTimerSt
{
    int         m_nUse;         // 사용여부
    cmnCbFunc*  m_cbFunc;
    int         m_nInterval;    // 간격 (ms)
    int         m_nRemainTime;
} cmnTimerSt;


////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class cmnTimerManager : public cmnEvtBase
{
public:
    static cmnTimerManager* instance;
    static cmnTimerManager* user_instance;

    cmnTimerManager ( );
    inline ~cmnTimerManager ( ) { };

    _VOID thread_main ( );

    static _VOID init ( );
    static _VOID destroy ( );
    _VOID create ( );
    _VOID start ( );
    _VOID stop ( );

    static _VOID addTimer ( int msec , cmnCbFunc* cbFunc , int* pTimerId );
    static _VOID delTimer ( int timerid );


    static cmnTimerSt*      m_pTimerInfo;
    static int              m_nTimerIdMax;  // HWM
    static int              m_nTimeUnit_ms; // 타이머 발동 간격

    static cmnEvtQue*       m_pTimerQue;     // 타이머 데이타 큐

protected:
    _VOID onTimeout ();

private:
    static pthread_mutex_t  m_TimerLock;
};


#endif /* CMNTIMER_H_ */
