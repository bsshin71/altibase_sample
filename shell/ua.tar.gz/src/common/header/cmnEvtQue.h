/*
 * cmnEvtQue.h
 *
 *  Created on: Mar 10, 2014
 *      Author: paul
 */

#ifndef CMNEVTQUE_H_
#define CMNEVTQUE_H_

#include "mvp.h"

#ifdef __cplusplus

#include <queue>

////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class cmnEvtQue
{
public:
    cmnEvtQue();
    ~cmnEvtQue ();

    _VOID init ( );
    _VOID destroy ();

    _VOID push ( const void* pMsg );
    _VOID push_front ( const void* pMsg );
    _VOID pop ( void** ppOut );
    _VOID clear ( );
    int size ( ) { return m_nSize; }

    _VOID sig_wait ( void** ppOut, int usec = 0 );
#ifdef _DBM_USE_TRACE_CALLER
    _VOID sig_send ( const char* file=__FILE__, const char* func=__FUNCTION__, int line=__LINE__ );
#else
    _VOID sig_send ( );
#endif

private:
    _VOID pushLib ( const void* pMsg, int flag );

    std::queue<void*>           m_queue;
    unsigned long long          m_nSize;

    pthread_mutex_t             m_mtx;
    pthread_cond_t              m_cond;
};

#endif

#endif /* CMNEVTQUE_H_ */
