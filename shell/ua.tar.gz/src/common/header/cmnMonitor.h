/*
 * cmnMonitor.h
 *
 *  Created on: Mar 12, 2014
 *      Author: paul
 */

#ifndef CMNMONITOR_H_
#define CMNMONITOR_H_

#include "cmnApi.h"

#ifdef __cplusplus
extern "C" {
#endif

extern _VOID _dbm_monitor_cb ( void* arg );

#ifdef __cplusplus
}
#endif

class cmnMonitor
{
public:
    static cmnMonitor* instance;
    _VOID operator( ) ( void* arg );    // Functor (펑터)

private:
    void*           m_MonInfo;
    char*           m_pBuff;
    char*           m_pBuffPre;
};


#endif /* CMNMONITOR_H_ */
