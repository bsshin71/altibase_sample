/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   Dictionary Manager 는 혼자 그 자체로 복구까지 책임지는 완전체라서
 *   누구나 객체만 생성하면 Dictionary Manager 의 기능을 사용할 수 있다.
 *   Dictionary Manager 는 복구를 위해 Log Manager 와 Lock Manager 객체를
 *   사용하며, DML 수행을 위해 Table Manager 객체를 사용한다.
 *
 *   !! Dictionary Table/Index 이름이나 순서는 절대로 함부로 변경하면 안된다.
 *******************************************************************************/
#include "dbmHeader.h"
#include "dbmDicManager.h"


char dbmDicTableName[][DBM_NAME_LEN] =
{
    SYS_DIC_PREFIX"sys_instance"
  , SYS_DIC_PREFIX"sys_table"
  , SYS_DIC_PREFIX"sys_index"
  , SYS_DIC_PREFIX"sys_column"
  , SYS_DIC_PREFIX"sys_object"
  , SYS_DIC_PREFIX"sys_trigger"
};

char dbmDicIndexName[][DBM_NAME_LEN] =
{
    SYS_DIC_PREFIX"idx_sys_instance"
  , SYS_DIC_PREFIX"idx_sys_table"
  , SYS_DIC_PREFIX"idx_sys_index"
  , SYS_DIC_PREFIX"idx_sys_column"
  , SYS_DIC_PREFIX"idx_sys_object"
  , SYS_DIC_PREFIX"idx_sys_trigger"
};

char dbmObjectTypeName[][DBM_NAME_LEN] =
{
    "TABLE"
  , "DIRECT_TABLE"
  , "QUEUE"
  , "LIST"
  , "SEQUENCE"
  , "INDEX"
  , "TRIGGER"
};


__thread char   __gUserData[DBM_MAX_RECORD_SIZE];
__thread char   __gSelectUserData[DBM_MAX_RECORD_SIZE];

dbmDictionary::dbmDictionary( )
{
    _TRY
    {
        /***********************************************
         * 멤버변수 초기화
         ***********************************************/
        mTransID = -1;
        mTransHeader = NULL;

        mTxTable = NULL;
        mUndoHeader = NULL;

        mTableCount = 0;

        for ( int i = 0; i < DBM_DIC_TBL_MAX; i++ )
        {
            mTable[i] = NULL;
        }

        mUndoSegMgr = NULL;
        mLogMgr = NULL;
        mLockMgr = NULL;
        mDeadLockMgr = NULL;
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    //_END
}

dbmDictionary::~dbmDictionary( )
{
    _TRY
    {
        /***********************************************
         * 멤버변수 초기화
         * (메모리 할당된 것이 있으면 해제)
         ***********************************************/
        if ( mTransID >= 0 )
        {
            _CALL( mFinalTran ( ) );
        }

        mDetach ( );
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    //_END
}


/********************************************************************
 * ID : mParseCreateIndexDDL
 *
 * Description
 *   Index 생성 구문을 Parsing 하여 dbmTableInfo 의 Index 관련 정보를
 *   추가해준다.
 *   이 함수를 호출하기 전에 Table 생성구문에 대한 parsing 결과가
 *   dbmTableInfo 에 담겨있어야 한다.
 *
 ********************************************************************/
_VOID dbmDictionary::mParseCreateIndexDDL( dbmDicTableType  aTableType,
                                           dbmTableInfo*    aTableInfo,
                                           int              aIndexOrder,
                                           dbmUniqueType    aIsUniqueIndex,
                                           const char*      aKeyColumnListString )
{
    int                 sKeySize = 0;
    char                sSQL[4096];
    char                sObjName[64];
    dbmParseObject      sParseObj;
    dbmIndexDic*        sParseIndex = (dbmIndexDic *)&sParseObj.mObj.mIndex;

    _TRY
    {
        memset_s( sSQL, 0x00, sizeof(sSQL));
        memset_s( sObjName, 0x00, sizeof(sObjName));

        /***********************************************
         * index_name_숫자 와 같은 이름.
         ***********************************************/
        sprintf( sObjName, "%s_%d", dbmDicIndexName[aTableType], aIndexOrder );


        /***********************************************
         * TableInfo 의 TableObject 에도 Index 이름의 Array 정보가 있으므로.
         ***********************************************/
        cmnStrCpyZ( aTableInfo->mTable.mIndexName[aIndexOrder], sObjName );


        /***********************************************
         * TableInfo 의 aIndexOrder 번째 Index 정보를 채운다.
         ***********************************************/
        aTableInfo->mIndex[aIndexOrder].mIndexID = mvpAtomicInc64(&mUndoHeader->mGSCN);
        aTableInfo->mIndex[aIndexOrder].mInstID  = aTableInfo->mTable.mInstID;
        aTableInfo->mIndex[aIndexOrder].mTableID = aTableInfo->mTable.mTableID;

        cmnStrCpyZ( aTableInfo->mIndex[aIndexOrder].mInstName,  aTableInfo->mTable.mInstName );
        cmnStrCpyZ( aTableInfo->mIndex[aIndexOrder].mTableName, aTableInfo->mTable.mTableName );
        cmnStrCpyZ( aTableInfo->mIndex[aIndexOrder].mIndexName, sObjName );

        aTableInfo->mIndex[aIndexOrder].mIndexType  = DBM_INDEX_BTREE;

        /***********************************************
         * Index 생성 구문을 Parsing 한 결과는 사실 Key Column
         * 이름밖에 모르기 때문에 dbmTableInfo 의 ColumnSet
         * 정보들을 검색하여 Column 정보들을 채워야 한다.
         * Parsing 한 정보에서 이용할 수 있는 것은 Key Column Count 와
         * Key Column 의 이름 뿐이다.
         * 따라서, 이 Column 이름을 이용하여 TableInfo 의 ColumnSet
         * 정보를 검색해야하는 것이다.
         ***********************************************/
        if ( aIsUniqueIndex )
        {
            aTableInfo->mIndex[aIndexOrder].mIsUniqueIndex = DBM_UNIQUE;

            sprintf(sSQL, "create index %s on %s %s",
                            sObjName,
                            dbmDicTableName[aTableType],
                            aKeyColumnListString );
        }
        else
        {
            aTableInfo->mIndex[aIndexOrder].mIsUniqueIndex = DBM_NON_UNIQUE;

            sprintf(sSQL, "create non unique index %s on %s %s",
                            sObjName,
                            dbmDicTableName[aTableType],
                            aKeyColumnListString );
        }

        memset_s( &sParseObj, 0x00, sizeof(dbmParseObject) );

        _CALL( dbmParser::mParse( sSQL, &sParseObj ) );
        _CALL( mGetIndexKeyColumnInfo( sParseIndex, aTableInfo, &sKeySize ));

        gettimeofday( &aTableInfo->mIndex[aIndexOrder].mCreateTime, NULL );

        // #824 2015.02.24 -okt- 인덱스 컬럼개수 6개에서 32개로 늘림. - mParseCreateIndexDDL() 성능함수 아님.
        memcpy_s( aTableInfo->mIndex[aIndexOrder].mKey,
                  sParseIndex->mKey,
                  sizeof(dbmColumnObject)*DBM_MAX_COLUMN_PER_INDEX);

        aTableInfo->mIndex[aIndexOrder].mKeySize     = sKeySize;
        aTableInfo->mIndex[aIndexOrder].mColumnCount = sParseIndex->mColumnCount;

        _IF_THROW( sKeySize > DBM_INDEX_KEY_MAX_SIZE, ERR_DBM_TOO_LARGE_KEYSIZE );

        aTableInfo->mIndexCount++;
    }

    _CATCH
    {
        if ( _rc == ERR_DBM_TOO_LARGE_KEYSIZE )
        {
            printf("(%s)\n", sSQL );
        }
        _CATCH_ERR;
    }
    _FINALLY
    _END
} /* mParseCreateIndexDDL */


/********************************************************************
 * ID : mParseCreateDicDDL
 *
 * Description
 *   각 dictionary table 을 생성하는 구문을 통해 parser 로 하여금
 *   dbmTableInfo 구조체 값들을 채워주도록 한다.
 *
 ********************************************************************/
_VOID dbmDictionary::mParseCreateDicDDL ( dbmTableInfo* aTableInfo , dbmDicTableType aTableType )
{
    char                sSQL[4096];
    char                sObjName[64];
    dbmParseObject      sParseObj;
    dbmParseObject      sParseIndexObj;
    dbmTableInfo*       sTableInfo = &sParseObj.mObj.mTableInfo;
    dbmColumnObject*    sColumn = NULL;
    int                 sKeySize;

    _TRY
    {
        memset_s( &sParseObj, 0x00, sizeof(dbmParseObject) );
        memset_s( &sParseIndexObj, 0x00, sizeof(dbmParseObject) );
        memset_s( sSQL, 0x00, 4096 );

        switch( aTableType )
        {
            case DBM_DIC_TBL_INSTANCE:
                /***********************************************
                 * sys_instance table
                 ***********************************************/
                sprintf(sSQL, "create table %s                      \
                                    key              char   %d 0    \
                                    inst_id          long   10 0    \
                                    inst_name        char   %d 0    \
                                    max_seg_no       int    10 0    \
                                    init_size        long   10 0    \
                                    extend_size      long   10 0    \
                                    max_size         long   10 0    \
                                    create_time      char   16 0    \
                                    init %d  extend %d  max %d",
                                    dbmDicTableName[aTableType],
                                    DBM_INDEX_KEY_MAX_SIZE,
                                    DBM_NAME_LEN,
                                    SYS_INSTANCE_INIT_ROW,
                                    SYS_INSTANCE_EXTEND_ROW,
                                    SYS_INSTANCE_MAX_ROW );
                break;

            case DBM_DIC_TBL_TABLE:
                /***********************************************
                 * sys_table table
                 ***********************************************/
                sprintf(sSQL, "create table %s                      \
                                    key              char   %d 0    \
                                    inst_id          long   10 0    \
                                    table_id         long   10 0    \
                                    inst_name        char   %d 0    \
                                    table_name       char   %d 0    \
                                    table_type       int    10 0    \
                                    column_count     int    10 0    \
                                    record_size      int    10 0    \
                                    init_size        long   10 0    \
                                    extend_size      long   10 0    \
                                    max_size         long   10 0    \
                                    timeout          int    10 0    \
                                    nologging_flag   short  10 0    \
                                    no_memlog_flag   short  10 0    \
                                    index_name       char   %d 0    \
                                    create_time      char   16 0    \
                                    init %d  extend %d  max %d",
                                    dbmDicTableName[aTableType],
                                    DBM_INDEX_KEY_MAX_SIZE,
                                    DBM_NAME_LEN,
                                    DBM_NAME_LEN,
                                    DBM_MAX_INDEX_PER_TABLE*DBM_NAME_LEN,
                                    SYS_TBL_INIT_ROW,
                                    SYS_TBL_EXTEND_ROW,
                                    SYS_TBL_MAX_ROW );
                break;

            case DBM_DIC_TBL_INDEX:
                /***********************************************
                 * sys_index table
                 ***********************************************/
                sprintf(sSQL, "create table %s                      \
                                    key              char   %d 0    \
                                    index_id         long   10 0    \
                                    inst_id          long   10 0    \
                                    table_id         long   10 0    \
                                    inst_name        char   %d 0    \
                                    table_name       char   %d 0    \
                                    index_name       char   %d 0    \
                                    index_type       int    10 0    \
                                    is_unique        int    10 0    \
                                    column_count     int    10 0    \
                                    key_size         int    10 0    \
                                    key_cols         char   %d 0    \
                                    create_time      char   16 0    \
                                    init %d  extend %d  max %d",
                                    dbmDicTableName[aTableType],
                                    DBM_INDEX_KEY_MAX_SIZE,
                                    DBM_NAME_LEN,
                                    DBM_NAME_LEN,
                                    DBM_NAME_LEN,
                                    DBM_MAX_COLUMN_PER_INDEX * (int)sizeof(dbmColumnObject),
                                    SYS_TBL_INIT_ROW * 2,
                                    SYS_TBL_EXTEND_ROW * 2,
                                    SYS_TBL_MAX_ROW * 2 );
                break;

            case DBM_DIC_TBL_COLUMN:
                /***********************************************
                 * sys_column table
                 ***********************************************/
                sprintf(sSQL, "create table %s                      \
                                    key              char   %d 0    \
                                    inst_id          long   10 0    \
                                    table_id         long   10 0    \
                                    column_id        int    10 0    \
                                    column_type      int    10 0    \
                                    column_name      char   %d 0    \
                                    size             int    10 0    \
                                    offset           int    10 0    \
                                    precision        int    10 0    \
                                    scale            int    10 0    \
                                    init %d  extend %d  max %d",
                                    dbmDicTableName[aTableType],
                                    DBM_INDEX_KEY_MAX_SIZE,
                                    DBM_NAME_LEN,
                                    SYS_TBL_INIT_ROW * 4,
                                    SYS_TBL_EXTEND_ROW * 4,
                                    SYS_TBL_MAX_ROW * 4 );
                break;

            case DBM_DIC_TBL_OBJECT:
                /***********************************************
                 * sys_object table
                 ***********************************************/
                sprintf(sSQL, "create table %s                      \
                                    inst_name          char   %d 0    \
                                    object_name        char   %d 0    \
                                    object_type        char   %d 0    \
                                    init %d  extend %d  max %d",
                                    dbmDicTableName[aTableType],
                                    DBM_NAME_LEN,
                                    DBM_NAME_LEN,
                                    DBM_NAME_LEN,
                                    SYS_TBL_INIT_ROW * 4,
                                    SYS_TBL_EXTEND_ROW * 4,
                                    SYS_TBL_MAX_ROW * 4 );
                break;

            case DBM_DIC_TBL_TRIGGER:
                /***********************************************
                 * sys_trigger table
                 ***********************************************/
                sprintf(sSQL, "create table %s                      \
                                    inst_name          char   %d 0    \
                                    trigger_name       char   %d 0    \
                                    event_source       char   %d 0    \
                                    event_target       char   %d 0    \
                                    enable_flag        char   %d 0    \
                                    init %d  extend %d  max %d",
                                    dbmDicTableName[aTableType],
                                    DBM_NAME_LEN,
                                    DBM_NAME_LEN,
                                    DBM_NAME_LEN,
                                    DBM_NAME_LEN,
                                    8,
                                    SYS_TBL_INIT_ROW * 2,
                                    SYS_TBL_EXTEND_ROW * 2,
                                    SYS_TBL_MAX_ROW * 2 );
                break;

            case DBM_DIC_TBL_MAX:
                _THROW( ERR_DBM_INVALID_TABLE_TYPE );
        }

        _CALL( dbmParser::mParse( sSQL, &sParseObj ) );

        /***********************************************
         * Parser 에서 못채운 dbmTableObject 정보들
         ***********************************************/
        sTableInfo->mTable.mInstID  = -1;
        sTableInfo->mTable.mTableID = mvpAtomicInc64(&mUndoHeader->mGSCN);
        strncpy_s( sTableInfo->mTable.mInstName, SYS_INST_NAME, strlen_s(SYS_INST_NAME));
        gettimeofday( &sTableInfo->mTable.mCreateTime, NULL );

        /***********************************************
         * Parser 에서 ColumnSet 의 기본정보들은
         * 채워졌을테니 아래의 ID 정보만 채우면 됨.
         ***********************************************/
        for( int i = 0; i<sTableInfo->mColumn.mCount; i++ )
        {
            sColumn = &sTableInfo->mColumn.mCols[i];

            sColumn->mColumnID = i;
            sColumn->mInstID   = sTableInfo->mTable.mInstID;
            sColumn->mTableID  = sTableInfo->mTable.mTableID;
        }


        /***********************************************
         * Index 정보를 TableType 에 따라 각각 생성하여
         * TableInfo 의 IndexObject Array 에 채워둔다.
         ***********************************************/
        aTableInfo->mIndexCount = 0;

        switch( aTableType )
        {
            case DBM_DIC_TBL_INSTANCE:
                /***********************************************
                 * sys_instance 의 Index
                 ***********************************************/
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_INSTANCE, sTableInfo, 0, DBM_UNIQUE, "key") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_INSTANCE, sTableInfo, 1, DBM_UNIQUE, "inst_id") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_INSTANCE, sTableInfo, 2, DBM_UNIQUE, "inst_name") );
                break;

            case DBM_DIC_TBL_TABLE:
                /***********************************************
                 * sys_table 의 Index
                 ***********************************************/
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_TABLE, sTableInfo, 0, DBM_UNIQUE, "key") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_TABLE, sTableInfo, 1, DBM_UNIQUE, "inst_name table_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_TABLE, sTableInfo, 2, DBM_NON_UNIQUE, "inst_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_TABLE, sTableInfo, 3, DBM_NON_UNIQUE, "table_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_TABLE, sTableInfo, 4, DBM_NON_UNIQUE, "inst_name table_type") );
                break;

            case DBM_DIC_TBL_INDEX:
                /***********************************************
                 * sys_index 의 Index
                 ***********************************************/
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_INDEX, sTableInfo, 0, DBM_UNIQUE, "key") );
                //_CALL( mParseCreateIndexDDL( DBM_DIC_TBL_INDEX, sTableInfo, 1, DBM_UNIQUE, "inst_name table_name index_name") ); /* too long key */
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_INDEX, sTableInfo, 1, DBM_NON_UNIQUE, "inst_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_INDEX, sTableInfo, 2, DBM_NON_UNIQUE, "inst_name table_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_INDEX, sTableInfo, 3, DBM_NON_UNIQUE, "inst_name index_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_INDEX, sTableInfo, 4, DBM_NON_UNIQUE, "table_name") );
                //_CALL( mParseCreateIndexDDL( DBM_DIC_TBL_INDEX, sTableInfo, 3, DBM_NON_UNIQUE, "inst_name table_name index_type") ); /* too long key */
                break;

            case DBM_DIC_TBL_COLUMN:
                /***********************************************
                 * sys_column 의 Index
                 ***********************************************/
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_COLUMN, sTableInfo, 0, DBM_UNIQUE, "key") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_COLUMN, sTableInfo, 1, DBM_UNIQUE, "inst_id table_id column_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_COLUMN, sTableInfo, 2, DBM_NON_UNIQUE, "inst_id table_id") );
                break;

            case DBM_DIC_TBL_OBJECT:
                /***********************************************
                 * sys_object 의 Index
                 ***********************************************/
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_OBJECT, sTableInfo, 0, DBM_UNIQUE, "inst_name object_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_OBJECT, sTableInfo, 1, DBM_NON_UNIQUE, "inst_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_OBJECT, sTableInfo, 2, DBM_NON_UNIQUE, "object_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_OBJECT, sTableInfo, 3, DBM_NON_UNIQUE, "object_type") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_OBJECT, sTableInfo, 4, DBM_NON_UNIQUE, "inst_name object_type") );
                break;

            case DBM_DIC_TBL_TRIGGER:
                /***********************************************
                 * sys_trigger 의 Index
                 ***********************************************/
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_TRIGGER, sTableInfo, 0, DBM_UNIQUE, "inst_name event_source") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_TRIGGER, sTableInfo, 1, DBM_UNIQUE, "inst_name trigger_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_TRIGGER, sTableInfo, 2, DBM_NON_UNIQUE, "inst_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_TRIGGER, sTableInfo, 3, DBM_NON_UNIQUE, "trigger_name") );
                _CALL( mParseCreateIndexDDL( DBM_DIC_TBL_TRIGGER, sTableInfo, 4, DBM_NON_UNIQUE, "event_source") );
                //_CALL( mParseCreateIndexDDL( DBM_DIC_TBL_TRIGGER, sTableInfo, 5, DBM_NON_UNIQUE, "inst_name enable_flag") );
                break;

            case DBM_DIC_TBL_MAX:
                _THROW( ERR_DBM_INVALID_TABLE_TYPE );
                break;

            default:
                _DASSERT( 0 );
                break;
        }

        memcpy_s( aTableInfo, sTableInfo, sizeof(dbmTableInfo));
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
} /* mParseCreateDicDDL */


/********************************************************************
 * ID : mCreate
 *
 * Description
 *   mCreate 는 initdb 단계에서 metaManager 만이 호출한다.
 *   Dic 복구를 위한 Undo Segment 및 Dic Table Segment 들을 생성만 해둔다.
 *   이후에 이를 사용하고 싶으면 반드시 Attach 를 하고 사용해야 한다.
 *   (Create 만 하고 바로 사용할 수는 없다.)
 *
 ********************************************************************/
_VOID dbmDictionary::mCreate()
{
    dbmSegmentManager*  sUndoSegMgr  = NULL;
    dbmSegmentManager*  sTableSegMgr = NULL;
    dbmSegmentManager*  sIndexSegMgr = NULL;
    dbmTableInfo        sTableInfo[DBM_DIC_TBL_MAX];
    dbmTableInfo        sTableInfo2;
    dbmTableHeader*     sTableHeader = NULL;
    dbmIndexHeader*     sIndexHeader = NULL;
    char                sData[sizeof(dbmDataObject)];
    dbmInstanceDic*     sInstanceDic;
    dbmTableInfo*       sTableInfoDic;
    int                 sSlotSize = 0;
    int                 sInitSlotCount = 0;
    int                 sExtendSlotCount = 0;
    int                 sUserHeaderSize;
    char*               sUserHeader  = NULL;
    char                sFileName[256];
    char                sIndexName[DBM_NAME_LEN];
    int                 sMode = -1;
    int                 sFD = -1;
    int                 i, j;

    _TRY
    {
        DBM_INFO( "[DIC] Create Start" );

        sMode = umask(0x00);        // 777 모드로 오픈하기 위해 umask 필요.

        /***********************************************
         * Dictionary 용 Global Undo Segment 생성
         * Undo Segment 는 일단 여기에서 생성해두면 사용하고
         * 싶을 때 Attach 해서 사용하면 된다.
         * 사용자가 mCreate 를 반복적으로 호출하면 이미
         * Segment 가 존재하므로 에러가 발생할 것이다.
         ***********************************************/
        sUserHeaderSize = sizeof(dbmUndoHeader) + sizeof(dbmTransTable);

        _CALL( dbmSegmentManager::Create( SYS_INST_NAME,
                                          SYS_INST_NAME,
                                          UNDO_SLOT_SIZE_DEFS,      /* undo slot size */
                                          UNDO_INIT_SIZE_DEFS,      /* init undo slot number */
                                          UNDO_EXTEND_SIZE_DEFS,    /* extend undo slot number */
                                          UNDO_MAX_SIZE_DEFS,       /* max undo slot number */
                                          (size_t)sUserHeaderSize,
                                          &sUndoSegMgr ));

        RTF_POINT("DICMGR_CREATE_0");

        sUserHeader = sUndoSegMgr->GetUserHeader();
        mUndoHeader = (dbmUndoHeader*)(sUserHeader + sizeof(dbmTransTable));
        mUndoHeader->mGSCN   = -1;
        mUndoHeader->mGLSN   = -1;
        mUndoHeader->mSessID = -1;
        mUndoHeader->mLock   = -1;

        for( i=DBM_DIC_TBL_INSTANCE; i<DBM_DIC_TBL_MAX; i++ )
        {
            /***********************************************
             * Parse DDL for dictionary creation
             ***********************************************/
            _CALL( mParseCreateDicDDL( &sTableInfo[i], (dbmDicTableType)i ) );


            RTF_POINT("DICMGR_CREATE_1");

            /***********************************************
             * table segment 생성 및 Header 초기화
             ***********************************************/
            sSlotSize = sTableInfo[i].mTable.mRecordSize + sizeof(dbmRowHeader);
            _CALL( dbmSegmentManager::Create( SYS_INST_NAME,
                                              dbmDicTableName[i],
                                              sSlotSize,
                                              sTableInfo[i].mTable.mInitSize,
                                              sTableInfo[i].mTable.mExtendSize,
                                              sTableInfo[i].mTable.mMaxSize,
                                              (size_t)sizeof( dbmTableHeader ),
                                              &sTableSegMgr ));

            sTableHeader = (dbmTableHeader*)sTableSegMgr->GetUserHeader();

            memcpy_s( sTableHeader, &sTableInfo[i], sizeof(dbmTableInfo) );
            sTableHeader->mUseIndex      = 0;
            sTableHeader->mInitCompleteF = 1;


            /***********************************************
             * index segment 생성 및 Header 초기화
             ***********************************************/
            RTF_POINT("DICMGR_CREATE_2");

            sInitSlotCount   = CALC_IDX_SLOT_COUNT(sTableInfo[i].mTable.mInitSize);
            sExtendSlotCount = CALC_IDX_SLOT_COUNT(sTableInfo[i].mTable.mExtendSize);

            for ( j = 0; j < (int) sTableInfo[i].mIndexCount; j++ )
            {

                /* 0: unique 1: non-unque type */
                /* non-unique type 8byte ExtraValue값이 포함된 SlotSize로 처리를 함 */
                /* 2014.07.22 -shw- */
                if ( sTableInfo[i].mIndex[j].mIsUniqueIndex )
                {
                    sSlotSize = sizeof(dbmIndexNode) + ( sTableInfo[i].mIndex[j].mKeySize * DBM_INDEX_DEGREE );
                }
                else
                {
                    sSlotSize = sizeof(dbmIndexNode) + ( ( sTableInfo[i].mIndex[j].mKeySize + 8 ) * DBM_INDEX_DEGREE );
                }

                _CALL( dbmSegmentManager::Create( SYS_INST_NAME,
                                                  sTableInfo[i].mIndex[j].mIndexName,
                                                  sSlotSize,
                                                  sInitSlotCount,
                                                  sExtendSlotCount,
                                                  sTableInfo[i].mTable.mMaxSize,
                                                  (size_t)sizeof( dbmIndexHeader ),
                                                  &sIndexSegMgr ));

                sIndexHeader = (dbmIndexHeader *)sIndexSegMgr->GetUserHeader();

                memcpy_s( sIndexHeader, &sTableInfo[i].mIndex[j], sizeof(dbmIndexObject) );
                sIndexHeader->mLock          = -1;
                sIndexHeader->mPID           = gettid_s ();
                sIndexHeader->mRootAllocCk   = 0;
                sIndexHeader->mRootPid       = 0;
                sIndexHeader->mCurrStep      = 0;
                sIndexHeader->mInitCompleteF = 1;

#ifndef USE_NEW_SHM_NODETACH
                sIndexSegMgr->Detach();
#endif
                delete sIndexSegMgr; sIndexSegMgr = NULL;
            }


            /***********************************************
             * Segment Manager Handle 메모리 해제
             ***********************************************/
#ifndef USE_NEW_SHM_NODETACH
            sTableSegMgr->Detach();
#endif
            delete_s( sTableSegMgr );
        }

#ifndef USE_NEW_SHM_NODETACH
        sUndoSegMgr->Detach();
#endif
        delete_s( sUndoSegMgr );

        /********************************************************
         * 데이터파일 생성
         ********************************************************/
        sprintf ( sFileName, "%s/dic/system_dictionary-0", getenv ( ENV_DBM_HOME ) );
        sFD = open ( sFileName, O_RDWR, _cmn_file_mode );
        //_IF_THROW( sFD > 0, ERR_DBM_DIC_FILE_DUP );
        if( sFD > 0 )
        {
            unlink( sFileName );
            sFD = open ( sFileName, O_RDWR, _cmn_file_mode );
            _IF_THROW( sFD > 0, ERR_DBM_DIC_FILE_DUP );
        }

        sFD = open ( sFileName, O_CREAT | O_RDWR, _cmn_file_mode );
        _IF_THROW( sFD <= 0, ERR_DBM_DIC_FILE_OPEN );

        close_s ( sFD );

        /********************************************************
         * Attach 후 dictionary table 관련 정보 insert
         * 자신들(dictionary table)의 정보가 맨처음 dictionary table 들에
         * 들어가 있어야 하므로.
         ********************************************************/
        mDetach ( );
        _CALL( mInitTran ( ) );

        memset_s ( sData, 0x00, sizeof( sData ) );

        sInstanceDic = (dbmInstanceDic *) sData;
        sTableInfoDic = (dbmTableInfo*) sData;

        /* sys_instance insert */
        sInstanceDic->mInstanceID = sTableInfo[DBM_DIC_TBL_INSTANCE].mTable.mInstID;
        cmnStrCpyZ ( sInstanceDic->mInstanceName, sTableInfo[DBM_DIC_TBL_INSTANCE].mTable.mInstName );
        sInstanceDic->mMaxSegNo = 1;
        sInstanceDic->mInitSize = SYS_INSTANCE_INIT_ROW;
        sInstanceDic->mExtendSize = SYS_INSTANCE_EXTEND_ROW;
        sInstanceDic->mMaxSize = SYS_INSTANCE_MAX_ROW;
        gettimeofday ( &sInstanceDic->mCreateTime, NULL );

        _CALL( mInitInsert ( (void * )sInstanceDic, DBM_CREATE_INST ) );

        /* insert table info into sys_table */
        memset_s ( &sTableInfo2, 0x00, sizeof(dbmTableInfo) );
        memcpy_s ( &sTableInfo2, &sTableInfo[DBM_DIC_TBL_INSTANCE], sizeof(dbmTableInfo) );
        _CALL( mInitInsert ( (void * )&sTableInfo2, DBM_CREATE_TABLE ) );

        RTF_POINT( "DICMGR_CREATE_3" );

        memset_s ( &sTableInfo2, 0x00, sizeof(dbmTableInfo) );
        memcpy_s ( &sTableInfo2, &sTableInfo[DBM_DIC_TBL_TABLE], sizeof(dbmTableInfo) );
        _CALL( mInitInsert ( (void * )&sTableInfo2, DBM_CREATE_TABLE ) );

        memset_s ( &sTableInfo2, 0x00, sizeof(dbmTableInfo) );
        memcpy_s ( &sTableInfo2, &sTableInfo[DBM_DIC_TBL_INDEX], sizeof(dbmTableInfo) );
        _CALL( mInitInsert ( (void * )&sTableInfo2, DBM_CREATE_TABLE ) );

        memset_s ( &sTableInfo2, 0x00, sizeof(dbmTableInfo) );
        memcpy_s ( &sTableInfo2, &sTableInfo[DBM_DIC_TBL_COLUMN], sizeof(dbmTableInfo) );
        _CALL( mInitInsert ( (void * )&sTableInfo2, DBM_CREATE_TABLE ) );

        memset_s ( &sTableInfo2, 0x00, sizeof(dbmTableInfo) );
        memcpy_s ( &sTableInfo2, &sTableInfo[DBM_DIC_TBL_OBJECT], sizeof(dbmTableInfo) );
        _CALL( mInitInsert ( (void * )&sTableInfo2, DBM_CREATE_TABLE ) );

        memset_s ( &sTableInfo2, 0x00, sizeof(dbmTableInfo) );
        memcpy_s ( &sTableInfo2, &sTableInfo[DBM_DIC_TBL_TRIGGER], sizeof(dbmTableInfo) );
        _CALL( mInitInsert ( (void * )&sTableInfo2, DBM_CREATE_TABLE ) );

        RTF_POINT( "DICMGR_CREATE_4" );

        _CALL( mDicCommit ( ) );

        RTF_POINT( "DICMGR_CREATE_5" );

        _CALL( mFinalTran ( ) );
        mDetach ( );

        DBM_INFO( "[DIC] Create End" );
    }

    _CATCH
    {
        _CATCH_ERR;

        /********************************************************
         * Dictionary 생성 시 하나라도 삑사리나면 모두 Drop
         ********************************************************/
        if ( _rc != ERR_DBM_SHM_ALREADY_EXIST )
        {
            mDrop();
        }
    }
    _FINALLY
    {
        if ( sMode != -1 )
        {
            (void) umask ( sMode );     // 기존 umask 설정으로 원복.
        }
    }
    _END
} /* mCreate */


_VOID dbmDictionary::mDrop()
{
    dbmSegmentManager*  sSegMgr = NULL;
    char                sFileName[256];
    char                sIndexName[256];
    int                 sRC;
    int                 i, j;

    _TRY
    {
        DBM_INFO( "[DIC] Drop Start" );

        sRC = dbmSegmentManager::Attach ( SYS_INST_NAME, SYS_INST_NAME, &sSegMgr );
        if ( sRC == 0 ) // && sSegMgr != NULL )
        {
            sSegMgr->Drop ( );
            delete_s( sSegMgr );
        }

        sSegMgr = NULL;
        for ( i = DBM_DIC_TBL_INSTANCE; i < DBM_DIC_TBL_MAX; i++ )
        {
            sRC = dbmSegmentManager::Attach ( SYS_INST_NAME, dbmDicTableName[i], &sSegMgr );
            if ( sRC == 0 )
            {
                sSegMgr->Drop ( );
                delete_s( sSegMgr );
            }
            // 2014.12.14. -okt- 중간에 빠져나갈수 있는 구조가 아닌듯?
        }

        sSegMgr = NULL;
        for ( i = DBM_DIC_TBL_INSTANCE; i < DBM_DIC_TBL_MAX; i++ )
        {
            for ( j = 0; j < DBM_MAX_INDEX_PER_TABLE; j++ )
            {
                snprintf ( sIndexName, sizeof( sIndexName ), "%s_%d", dbmDicIndexName[i], j );

                sRC = dbmSegmentManager::Attach ( SYS_INST_NAME, sIndexName, &sSegMgr );
                if ( sRC == 0 )
                {
                    sSegMgr->Drop ( );
                    delete_s( sSegMgr );
                }
                // 2014.12.14. -okt- 중간에 빠져나갈수 있는 구조가 아닌듯?
            }
        }

        snprintf ( sFileName, sizeof(sFileName), "%s/dic/system_dictionary-%d", getenv ( ENV_DBM_HOME ), 0 );
        unlink ( sFileName );

        DBM_INFO( "[DIC] Drop End" );
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mDrop */


_VOID dbmDictionary::mRecoveryTxAll()
{
    dbmTransHeader* sTxHead = NULL;
    int             sOldPID;
    int             i;

    _TRY
    {
        DBM_INFO( "[DIC] Recovery All Start" );

        for ( i = 0; i < DBM_MAX_TRANS; i++ )
        {
            sTxHead = &mTxTable->mItem[i];

            if ( sTxHead->mStatus != DBM_TX_FREE )
            {
                sOldPID = mvpAtomicGet32( &sTxHead->mPID );
                if ( sOldPID > 0 && sTxHead->mMyTxID == i )
                {
                    if ( tkill_s ( sOldPID, 0 ) && errno == ESRCH )
                    {
                        _CALL( mDicRollbackRecovery( i ) );
                        _CALL( mFinalTran( i ) );
                    }
                }
            }
        }

        DBM_INFO( "[DIC] Recovery All End" );
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mRecoveryTxAll */


/********************************************************************
 * ID : mAttach
 *
 * Description
 *   Dictionary 를 사용하고 싶으면 반드시 Attach 를 하고 사용해야 한다.
 *   mAttach 는 Undo Segment 에 Attach 하고 Tx 하나를 점유하는 역할을 한다.
 *   그리고, LockMgr 및 LogMgr 를 준비한다.
 *
 ********************************************************************/
_VOID dbmDictionary::mAttach()
{
    dbmSegmentManager*  sUndoSegMgr = NULL;
    int                 sPidReplacedF = 0;
    char*               sUserHeader = NULL;
    int                 i;

    _TRY
    {
        DBM_DBG2( "[DIC] Attach Start" );

        /***********************************************
         * dic 객체 생성 후 첫번째 Attach 에서만
         * Undo Segment 에 Attach
         * 각종 Manager 객체는 Attach 시에 만들어둔다.
         * DML 이 발생할 때는 Tx 만 잡아서 수행하게 된다.
         ***********************************************/
        if ( mUndoSegMgr == NULL )
        {
            _rc = dbmSegmentManager::Attach ( SYS_INST_NAME, SYS_INST_NAME, &sUndoSegMgr );
            _IF_THROW( _rc, ERR_DBM_NO_DIC_SHM );

            RTF_POINT("DICMGR_ATTACH_0");

            sUserHeader = sUndoSegMgr->GetUserHeader();
            mTxTable    = (dbmTransTable*)sUserHeader;
            mUndoHeader = (dbmUndoHeader*)(sUserHeader + sizeof(dbmTransTable));
            mUndoSegMgr = sUndoSegMgr;


            /***********************************************
             * lock manager 객체 생성
             ***********************************************/
            mLockMgr = new dbmLockManager();
            _IF_THROW( mLockMgr == NULL, ERR_DBM_MEM_ALLOC );

            /* 20414.11.24 -shw- __mLockInfo 정보가 설정 되어 있지 않을 때만 생성 */
            if( mLockMgr->mGetLockInfoAddr() == NULL )
            {
                _CALL( mLockMgr->mInitLock( sizeof(dbmTransHeader), (char*)mTxTable ) );
            }

            /***********************************************
             * log/deadlock manager 객체 생성
             ***********************************************/
            mLogMgr = new dbmLogManager( (char*)mTransHeader,
                                         (char*)mUndoHeader,
                                         mUndoSegMgr );
            _IF_THROW( mLogMgr == NULL, ERR_DBM_MEM_ALLOC );

            mDeadLockMgr = new dbmDeadLockManager( mTxTable, mTransID, mLogMgr );
            _IF_THROW ( mDeadLockMgr == NULL, ERR_DBM_MEM_ALLOC );

            RTF_POINT("DICMGR_ATTACH_1");


            /***********************************************
             * prepare dictionary table manager
             ***********************************************/
            for ( i = DBM_DIC_TBL_INSTANCE; i < DBM_DIC_TBL_MAX; i++ )
            {
                _CALL( mPrepareDicTable( dbmDicTableName[i] ) );
            }

            RTF_POINT("DICMGR_ATTACH_2");
        }

        DBM_DBG2( "[DIC] Attach End" );
    }

    _CATCH
    {
        if ( _rc == ERR_DBM_NO_DIC_SHM )
        {
            _CATCH_WARN;
        }
        else
        {
            _CATCH_ERR;
        }

        mDetach();
    }
    _FINALLY
    _END
} /* mAttach */


_VOID dbmDictionary::mInitTran()
{
    int                 sTxID = -1;
    int                 sTry  = 0;
    int                 sMyPID;
    long long           sSessID;
    int                 sOldPID;
    int                 sPidReplacedF = 0;
    dbmTransHeader*     sTxHead     = NULL;
    long long           sAllocSlotID= -1;
    dbmLogSlotHeader*   sLogSlotH   = NULL;
    dbmLogSlotHeader*   sImageSlotH = NULL;
    dbmTransHeader      sTmpTxHead;
    char*               sUserHeader = NULL;
    int                 sRecoverCount = 0;
    int                 sRC;
    int                 i;

    _TRY
    {
        /***********************************************
         * Attach 안하고 사용하는 경우를 위해
         ***********************************************/
        if ( mUndoHeader == NULL )
        {
            _CALL( mAttach() );
        }

        if ( mTransID >= 0 )
        {
            DBM_DBG2( "[DIC] Init Tran Start. TxID[%d]", mTransID );
        }


        /***********************************************
         * dic manager 객체가 사용할 transaction 할당은
         * 여기에서 이루어지고 해제는 Commit/Rollback 에서
         * 이루어진다.
         ***********************************************/
        if ( mTransID < 0 )
        {
            sSessID = mvpAtomicInc64( &mUndoHeader->mSessID );
            sTxID = sSessID % DBM_MAX_TRANS;

            sMyPID = (int)gettid_s();
            sTry = 0;

            while ( 1 )
            {
                sTxHead = (dbmTransHeader*)(&mTxTable->mItem[sTxID]);

                sRC = mLockMgr->mLockPID( (char*)&sTxHead->mPID,
                                           sMyPID,
                                           &sPidReplacedF );
                if ( sRC == RC_SUCCESS )
                {
                    break;
                }
                else
                {
                    /***********************************************
                     * 없으면 다음 TxID 를 시도해본다.
                     ***********************************************/
                    sTxID = sTxID + 1;
                    if ( sTxID >= DBM_MAX_TRANS )
                    {
                        sTxID = 0;
                    }

                    /***********************************************
                     * 시도한 횟수가 Session 최대개수의 몇배수여도 실패하면
                     * 진짜 공간이 없다고 판단하고 빠져나온다.
                     ***********************************************/
                    sTry = sTry + 1;
                    _IF_THROW( sTry == ( DBM_MAX_TRANS*DBM_MAX_TRANS ), ERR_DBM_TX_NO_SPACE );
                    continue;
                }
            }

            DBM_DBG2( "[DIC] Init Tran Start. New TxID[%d]", sTxID );

            /***********************************************
             * 혹시나 획득하려는 Transaction ID 의 Number가 틀렸을지 모르니
             * DBM_MAX_TRANS 이내인지 체크해본다.
             ***********************************************/
            _IF_THROW( ( sTxID < 0 || sTxID >= DBM_MAX_TRANS ), ERR_DBM_INVALID_TX_BUCKET );

            RTF_POINT("DICMGR_INITTRAN_0");


            /***********************************************
             * 다른 놈들이 진입못하게 Lock 을 건다.
             ***********************************************/
            _CALL( mLock( sTxID ) );

            RTF_POINT("DICMGR_INITTRAN_1");


            /****************************************************
             * Transaction Header 초기화
             ****************************************************/
            mTransID     = sTxID;
            mTransHeader = (dbmTransHeader*)(&mTxTable->mItem[mTransID]);

            mInitTransItem( sTxID,
                            (dbmTransHeader*)mTransHeader,
                            sSessID,
                            0,
                            gettid_s(),
                            DBM_TX_ALLOC,
                            mUndoSegMgr->GetSlotSize() );

            RTF_POINT("DICMGR_INITTRAN_2");

            /****************************************************
             * Logging 을 위한 slot 을 할당해둠.
             ****************************************************/
            memcpy_s ( &sTmpTxHead, mTransHeader, sizeof(dbmTransHeader) );

            sRC = dbmSegAllocSlot ( mUndoSegMgr, &sAllocSlotID );
            _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT );

            sRC = mUndoSegMgr->Slot2Addr ( sAllocSlotID, &sLogSlotH );
            _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT );

            mInitLogSlot ( sLogSlotH, sAllocSlotID );

            sTmpTxHead.mLastAllocLogSlot = sAllocSlotID;
            sTmpTxHead.mLogStartPos      = MK_POS(sAllocSlotID,0);

            RTF_POINT("DICMGR_INITTRAN_3");

            /****************************************************
             * Image Logging 을 위한 slot 을 할당해둠.
             ****************************************************/
            sAllocSlotID = -1;

            sRC = dbmSegAllocSlot ( mUndoSegMgr, &sAllocSlotID );
            _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT );

            sRC = mUndoSegMgr->Slot2Addr ( sAllocSlotID, &sImageSlotH );
            _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT );

            mInitLogSlot ( sImageSlotH, sAllocSlotID );

            sTmpTxHead.mLastAllocImageSlot = sAllocSlotID;
            sTmpTxHead.mImageStartPos      = MK_POS(sAllocSlotID,0);

            RTF_POINT("DICMGR_INITTRAN_4");

            memcpy_s(mTransHeader, &sTmpTxHead, sizeof(dbmTransHeader));


            /***********************************************
             * log/deadlock manager 객체에 변경된 Tx 정보 설정
             ***********************************************/
            mLogMgr->mSetLogMgr( (char*)mTransHeader, (char*)mUndoHeader, mUndoSegMgr );
            _CALL( mDeadLockMgr->mSetDeadLockMgr( mTxTable, mTransID, mLogMgr ) );
        }

        DBM_DBG2( "[DIC] Init Tran End. TxID[%d]", mTransID );
    }

    _CATCH
    {
        _CATCH_ERR;

        if ( mTransID >= 0 )
        {
            mFinalTran();
        }
    }
    _FINALLY
    _END
} /* mInitTran */


_VOID dbmDictionary::mUnprepareDicTable ( char* aTableName )
{
    int     sObjectIdx = -1;
    int     sRC = -1;

    _TRY
    {
        /***********************************************
         * Dictionary Manager 객체가 가지고 있는
         * Table 객체를 해제
         ***********************************************/
        if ( mTableCount > 0 )
        {
            sRC = mGetTableIdx( aTableName, &sObjectIdx );
            if ( sRC == 0 )
            {
                delete_s( mTable[sObjectIdx] );

                if ( mTableCount > (sObjectIdx+1) )
                {
                    memmove_s( &mTable[sObjectIdx],
                               &mTable[sObjectIdx+1], sizeof(mTable[sObjectIdx])*(mTableCount-(sObjectIdx+1)));

                    mTable[mTableCount-1] = NULL;
                }

                --mTableCount;
            }
        }
    }

    _CATCH
    _FINALLY
    _END
}


_VOID dbmDictionary::mPrepareDicTable( char* aTableName )
{
    dbmSegmentManager*  sSegMgr      = NULL;
    dbmTableInfo*       sTableInfo   = NULL;
    dbmDicObject        sDicObject;
    int                 sTIdx        = -1;

    _TRY
    {
        memset_s( &sDicObject, 0x00, sizeof(dbmDicObject) );

        mUnprepareDicTable ( aTableName );

        /***********************************************
         * Table Segment 에 Attach
         *  -> Table Header 에 접근하여 정보 획득하기 위함.
         ***********************************************/
        _CALL( dbmSegmentManager::Attach(SYS_INST_NAME, aTableName, &sSegMgr ) );

        sTableInfo = (dbmTableInfo*) ( sSegMgr->GetUserHeader ( ) );

        /***********************************************
         * aTableName 을 담당할 Table Manager 생성 및 초기화
         ***********************************************/
        memcpy_s ( &sDicObject.mObj.mTableInfo, sTableInfo, sizeof(dbmTableInfo) );

        mTable[mTableCount] = new dbmTableManager ( );
        _IF_THROW( mTable[mTableCount] == NULL, ERR_DBM_MEM_ALLOC );

        _CALL ( mTable[mTableCount]->mInitTable( SYS_INST_NAME,
                                                 aTableName,
                                                 sTableInfo->mIndexCount,
                                                 sTableInfo->mIndex,
                                                 &sDicObject,
                                                 mLogMgr,
                                                 mLockMgr,
                                                 mDeadLockMgr ) );

        /***********************************************
         * dictionary table 이라는 것을 표시해두어서
         * table manager 가 복구를 해야하는 시점에서
         * 일반테이블과는 다르게 특정 에러(need to recover)로
         * 리턴하도록 한다.
         * 이 에러로 리턴하면 dictionary table 의 경우
         * recovery manager 가 아니라 dictionary manager 가
         * 직접 복구를 수행한다.
         ***********************************************/
        mTable[mTableCount]->mSetDicTableF ( );

        DBM_DBG2( "[DIC] prepared dictionary table[%s]. mTableIdx[%d]", aTableName, mTableCount );

        mTableCount++;

        if ( sSegMgr != NULL )
        {
#ifndef USE_NEW_SHM_NODETACH
            sSegMgr->Detach();
#endif
            delete_s( sSegMgr );
        }
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mGetTableIdx( char* aTableName, int* aTableIdx )
{
    int     i;

    for( i=0; i<mTableCount; i++ )
    {
        if ( strcmp_s( mTable[i]->mGetTableName(), aTableName ) == 0 )
        {
            *aTableIdx = i;
            break;
        }
    }

    if ( i >= mTableCount )
    {
        *aTableIdx = -1;
        return( RC_FAILURE );
    }

    return 0;
}


_VOID dbmDictionary::mDicCommit ( )
{
    long long           sSCN;
    char*               sCurImage = NULL;
    long long           sCurPos;
    long long           sTxEndLogPos;
    dbmRowHeader*       sRefRow   = NULL;
    dbmLogHeader*       sCurLog   = NULL;
    dbmTransHeader*     sTxH      = (dbmTransHeader *)mTransHeader;
    dbmSegmentManager*  sSegMgr   = NULL;
    dbmIndexManager*    sIdxMgr   = NULL;
    int                 sTableIdx;
    int                 sFound = 0;
    int                 sIsEnq = 0;
    int                 sRC;

    _TRY
    {
        DBM_DBG2( "[DIC] Commit Start. TxID[%d]", mTransID );

        /***********************************************
         * 아무 로그도 없으면 할 일 없음.
         ***********************************************/
        _IF_THROW( SLOTID( sTxH->mLogCurPos ) == -1, RC_SUCCESS );
        _IF_THROW( SLOTID( sTxH->mLogStartPos ) == -1, RC_SUCCESS );

        /***********************************************
         * Lock 을 못풀고 죽었을 경우 Lock 복구를 위해 사용.
         ***********************************************/
        sTxH->mLockRecoveryPos = sTxH->mLogCurPos;

        /***********************************************
         * SCN 채번
         ***********************************************/
        mLogMgr->mGetSCN ( &sSCN );

        sTxH->mStatus = DBM_TX_COMMIT;

        /***********************************************
         * 첫번째 로그로 이동
         ***********************************************/
        sCurPos = sTxH->mLogStartPos;

        /***********************************************
         * 모든 Log 를 차례로 방문하여 Log Type 별로
         * Commit 작업 수행
         ***********************************************/
        while(1)
        {
            sRefRow   = NULL;
            sIdxMgr   = NULL;
            sSegMgr   = NULL;
            sCurImage = NULL;
            sTableIdx = -1;

            sRC = mGetLogPtr(mUndoSegMgr, sCurPos, &sCurLog);
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

            /***********************************************
             * Commit 시에 CurPos 가 가리키는 로그가 valid 하지
             * 않다면 문제가 있는거다.
             * 복구 시라면 그럴 수 있겠지만...
             ***********************************************/
            _IF_THROW( sCurLog->mLogValidF != 1, ERR_DBM_INVALID_LOG );

            switch( sCurLog->mLogType )
            {
                case DBM_INSERT_SLOT_LOG:
                case DBM_UPDATE_SLOT_LOG:
                case DBM_UPDATE_KEY_LOG:
                    /***********************************************
                     * Row 의 SCN 만 변경해주면 된다.
                     ***********************************************/
                    sRefRow = (dbmRowHeader*)sCurLog->mRefPtr;
                    sRefRow->mSCN = sSCN;
                    break;

                case DBM_DELETE_SLOT_LOG:
                    /***********************************************
                     * Segment Manager 에게 Record Slot 을 반납.
                     ***********************************************/
                    // [변경전] sCurLog->mTableName -> [변경후] sCurLog->mObjectName
                    sRC = mGetTableIdx( sCurLog->mObjectName, &sTableIdx );
                    _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

                    sSegMgr = mTable[sTableIdx]->mGetSegMgr();
                    sRC = dbmSegFreeSlot( sSegMgr, sCurLog->mRefRecord, 0 );
                    break;

                case DBM_DELETE_INDEX_LOG:
                case DBM_DELETE_INDEX_LOG2:
                    /***********************************************
                     * Index Manager 에게 Delete Key 요청
                     ***********************************************/
                    sRC = mGetTableIdx( sCurLog->mTableName, &sTableIdx );
                    _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

                    sIdxMgr = mTable[sTableIdx]->mGetIndexMgrByObjID(sCurLog->mObjectID);
                    _IF_THROW( sIdxMgr == NULL, ERR_DBM_INVALID_LOG );

                    sRC = mGetImagePtr ( mUndoSegMgr, sCurLog->mImageLogPos, &sCurImage );
                    _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

                    // 2014.09.26 -okt- 의도적으로 오류처리 없는 부분을 (void)로 표시, 여기 의도적이 맞는거죠?
                    //sRC = sIdxMgr->mDeleteKey( sCurLog->mTransID, sCurImage );
                    if ( sCurLog->mLogType == DBM_DELETE_INDEX_LOG2 )
                    {
                        sRC = sIdxMgr->mDeleteKey( sCurLog->mTransID, sCurImage, 1 );
                    }
                    else
                    {
                        sRC = sIdxMgr->mDeleteKey( sCurLog->mTransID, sCurImage );
                    } 
                    if (sRC)
                    {
                        DBM_ERR ("insertKey rollback fail rc=%d, table=%s, index=%s, ref=%lld\n"
                                , sRC, sCurLog->mTableName, sCurLog->mObjectName, sCurLog->mRefRecord);
                    }
                    break;

                case DBM_DELETE_DATA_LOG:
                    sRefRow = (dbmRowHeader*)sCurLog->mRefPtr;
                    sRefRow->mSCN = 0;
                    break;

                case DBM_ENQUE_LOG:
                case DBM_DEQUE_LOG:
                case DBM_ALLOC_SLOT_LOG:
                case DBM_ALLOC_IDX_SLOT_LOG:
                case DBM_INSERT_INDEX_LOG:
                case DBM_INSERT_INDEX_LOG2:
                case DBM_LOCK_ROW_LOG:
                case DBM_DEFER_INSERT_LOG:
                case DBM_DEFER_UPDATE_LOG:
                case DBM_DDL_CREATE_TABLE_LOG:
                case DBM_DDL_CREATE_QUEUE_LOG:
                case DBM_DDL_CREATE_LIST_LOG:
                case DBM_DDL_CREATE_INDEX_LOG:
                case DBM_DDL_DROP_TABLE_LOG:
                case DBM_DDL_DROP_INDEX_LOG:
                case DBM_DDL_DROP_TRIG_LOG:
                case DBM_TRUNCATE_LOG:
                case DBM_SELECT_FOR_UPDATE_LOG:
                case DBM_SET_INDEX_LOG:
                    /* do nothing */
                    break;

                default:
                    _THROW( ERR_DBM_INVALID_LOG );
                    break;
            }

            sCurLog->mCommitCompleteF = 1;

            /***********************************************
             * Log 모두 commit 처리 완료.
             ***********************************************/
            if ( sCurPos == sTxH->mLogCurPos )
            {
                break;
            }

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            sRC = mLogMgr->mLogMoveForward ( mUndoSegMgr, sTxH, &sCurPos );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );
        }

        /***********************************************
         * 첫번째 로그로 이동
         ***********************************************/
        sCurPos = sTxH->mLogStartPos;

        /***********************************************
         * 로그 기록 위치 초기화.
         ***********************************************/
        sTxEndLogPos = sTxH->mLogCurPos;

        sTxH->mImageCurPos = MK_POS ( -1, -1 );
        sTxH->mRecoveryStartPos = MK_POS ( -1, -1 );
        sTxH->mLogCurPos = MK_POS ( -1, -1 );

        /***********************************************
         * Unlock Row
         ***********************************************/
        while ( 1 )
        {
            sRC = mGetLogPtr ( mUndoSegMgr, sCurPos, &sCurLog );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

            if ( sCurLog->mLogValidF != 1 )
            {
                /* do nothing */
            }
            else
            {
                switch ( sCurLog->mLogType )
                {
                    case DBM_LOCK_ROW_LOG:
                        sRefRow = (dbmRowHeader*) sCurLog->mRefPtr;
                        sRC = mLockMgr->mAtomicUnlockTry ( (char*) &sRefRow->mLock, mTransID );
                        break;

                    default:
                        break;
                }
            }

            /***********************************************
             * Log 모두 처리 완료.
             ***********************************************/
            if ( sCurPos == sTxEndLogPos )
                break;

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            sRC = mLogMgr->mLogMoveForward ( mUndoSegMgr, sTxH, &sCurPos );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );
        }

        sTxH->mLockRecoveryPos = MK_POS ( -1, -1 );

        DBM_DBG2( "[DIC] Commit End. TxID[%d]", mTransID );
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
} /* mDicCommit */


_VOID dbmDictionary::mDicRollback()
{
    long long           sCurPos;
    int                 sRowSize;
    char*               sImage   = NULL;
    dbmLogHeader*       sCurLog  = NULL;
    dbmRowHeader*       sRefRow  = NULL;
    dbmTransHeader*     sTxH     = (dbmTransHeader *)mTransHeader;
    dbmIndexManager*    sIdxMgr  = NULL;
    dbmSegmentManager*  sTblSegMgr = NULL;
    dbmSegmentManager*  sIdxSegMgr = NULL;
    dbmLogSlotHeader*   sLogSlotH = NULL;
    dbmDicObject        sDicObject;
    dbmTableInfo*       sTableInfo = NULL;
    dbmTableHeader*     sTableHeader = NULL;
    dbmQueueHeader*     sQueueHeader = NULL;
    dbmIndexHeader*     sIndexHeader = NULL;
    int                 sTableIdx  = -1;
    int                 sTableType = 0;
    int                 sRC;
    unsigned long long  i;

    _TRY
    {
        DBM_INFO( "[DIC] Rollback Start. TxID[%d]", mTransID );

        /***********************************************
         * 아무 로그도 없으면 할 일 없음.
         ***********************************************/
        if ( ( SLOTID( sTxH->mLogCurPos ) == -1 ) || ( SLOTID( sTxH->mLogStartPos ) == -1 ) )
        {
            DBM_INFO( "[DIC] Rollback End. TxID[%d]", mTransID );
            _RETURN
            ;
        }

        /***********************************************
         * Lock 을 못풀고 죽었을 경우 Lock 복구를 위해 사용.
         ***********************************************/
        sTxH->mStatus = DBM_TX_ROLLBACK;

        /***********************************************
         * 로그 Slot 들에 대해 역으로 List 로 연결해줌.
         * 평상 시에는 성능 상 dbmLogSlotHeader 의 mNext 만 연결.
         ***********************************************/
        sRC = dbmRecoveryManager::mLinkReverseList ( mUndoSegMgr, sTxH, -1 );
        _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

        /***********************************************
         * 마지막 로그로 이동
         ***********************************************/
        sCurPos = sTxH->mLogCurPos;

        /***********************************************
         * 모든 Log 를 차례로 방문하여 Log Type 별로
         * Rollback 작업 수행
         ***********************************************/
        while ( 1 )
        {
            sRefRow    = NULL;
            sCurLog    = NULL;
            sImage     = NULL;
            sIdxMgr    = NULL;
            sTblSegMgr = NULL;
            sIdxSegMgr = NULL;
            sTableInfo = NULL;
            sTableIdx  = -1;
            sTableHeader = NULL;
            sQueueHeader = NULL;
            sIndexHeader = NULL;

            sRC = mGetLogPtr ( mUndoSegMgr, sCurPos, &sCurLog );
            assert ( sRC == 0 /* && sCurLog != NULL */ );

            if ( ( sCurLog->mRollbackCompleteF == 1 ) || ( sCurLog->mLogValidF != 1 ) )
            {
                /* do nothing */
            }
            else
            {
                switch ( sCurLog->mLogType )
                {
                    case DBM_ALLOC_SLOT_LOG:
                        /***********************************************
                         * Free Slot 을 한다.
                         ***********************************************/
                        sRC = mGetTableIdx ( sCurLog->mObjectName, &sTableIdx );
                        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

                        sTblSegMgr = mTable[sTableIdx]->mGetSegMgr ( );
                        _IF_THROW( sTblSegMgr == NULL, ERR_DBM_TABLE_NOT_PREPARED );

                        sRC = dbmSegFreeSlot ( sTblSegMgr, sCurLog->mRefRecord, 0 );

                        break;

                    case DBM_INSERT_SLOT_LOG:
                        /***********************************************
                         * insert 한 row 를 초기화해버린다.
                         ***********************************************/
                        sRC = mGetTableIdx ( sCurLog->mTableName, &sTableIdx );
                        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

                        sTblSegMgr = mTable[sTableIdx]->mGetSegMgr ( );
                        _IF_THROW( sTblSegMgr == NULL, ERR_DBM_TABLE_NOT_PREPARED );

                        sTableHeader = (dbmTableHeader*) sTblSegMgr->GetUserHeader ( );
                        sRC = sTblSegMgr->Slot2Addr ( sCurLog->mRefRecord, &sRefRow );

                        sRowSize = sRefRow->mRowSize;
                        memset_s ( (char*)sRefRow + sizeof(dbmRowHeader), 0x00, sRowSize );

                        sRefRow->mSCN = 0;
                        sRefRow->mRowSize = 0;
                        break;

                    case DBM_DELETE_DATA_LOG:
                    case DBM_UPDATE_SLOT_LOG:
                    case DBM_UPDATE_KEY_LOG:
                        /***********************************************
                         * Image Log 를 통해 Row Image 를 복구한다.
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _THROW( ERR_DBM_INVALID_LOG );
                            }
                        }

                        sRC = mGetTableIdx( sCurLog->mTableName, &sTableIdx );
                        _IF_THROW( sRC || sTableIdx < 0, ERR_DBM_TABLE_NOT_PREPARED );

                        sTblSegMgr = mTable[sTableIdx]->mGetSegMgr();
                        _IF_THROW( sTblSegMgr == NULL, ERR_DBM_TABLE_NOT_PREPARED );

                        sTableHeader = (dbmTableHeader*) sTblSegMgr->GetUserHeader() ;

                        sRC = sTblSegMgr->Slot2Addr ( sCurLog->mRefRecord, &sRefRow ) ;

                        sRC = mGetImagePtr( mUndoSegMgr, sCurLog->mImageLogPos, &sImage );
                        _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

                        sRowSize = sCurLog->mImageSize;

                        memset_s ( (char*) sRefRow + sizeof(dbmRowHeader), 0x00, sRowSize - sizeof(dbmRowHeader) );
                        memcpy_s ( sRefRow, sImage, sRowSize );
                        break;

                    case DBM_INSERT_INDEX_LOG:
                    case DBM_INSERT_INDEX_LOG2:
                        /***********************************************
                         * ImageLog 에 저장된 key 를 이용하여 Delete Key를 수행
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _THROW( ERR_DBM_INVALID_LOG );
                            }
                        }

                        sRC = mGetTableIdx( sCurLog->mTableName, &sTableIdx );
                        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

                        sIdxMgr = mTable[sTableIdx]->mGetIndexMgrByObjID(sCurLog->mObjectID);
                        _IF_THROW(sRC || sIdxMgr == NULL, ERR_DBM_INVALID_LOG );

                        sRC = mGetImagePtr( mUndoSegMgr, sCurLog->mImageLogPos, &sImage );
                        _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

                        if ( sCurLog->mLogType == DBM_INSERT_INDEX_LOG2 )
                        {
                            sRC = sIdxMgr->mDeleteKey( sCurLog->mTransID, sImage, 1 );
                        }
                        else
                        {
                            sRC = sIdxMgr->mDeleteKey( sCurLog->mTransID, sImage );
                        }
                        if (sRC)
                        {
                            DBM_ERR ("insertKey rollback fail rc=%d, table=%s, index=%s, ref=%lld\n"
                                    , sRC, sCurLog->mTableName, sCurLog->mObjectName, sCurLog->mRefRecord);
                        }
                        break;

                    case DBM_DELETE_INDEX_LOG:
                    case DBM_DELETE_INDEX_LOG2:
                        /***********************************************
                         * image log 에 저장된 key 를 이용하여 Insert Key를
                         * 수행한다. 마지막 로그가 아니고 중간로그인데
                         * Image 가 valid 하지 않으면 에러다.
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _THROW( ERR_DBM_INVALID_LOG );
                            }
                        }

                        /***********************************************
                         * commit 과정에서 delete key 가 이미 수행된 것에
                         * 대해서만 delete key 를 하면 된다.
                         * 모두 다 delete key 를 하면 dup 이 날 것이므로.
                         ***********************************************/
                        if ( sCurLog->mCommitCompleteF == 1 )
                        {
                            sRC = mGetTableIdx( sCurLog->mTableName, &sTableIdx );
                            _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

                            sIdxMgr = mTable[sTableIdx]->mGetIndexMgrByObjID ( sCurLog->mObjectID );
                            _IF_THROW(sRC || sIdxMgr == NULL, ERR_DBM_INVALID_LOG );

                            sRC = mGetImagePtr ( mUndoSegMgr, sCurLog->mImageLogPos, &sImage );
                            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

                            sRC = sIdxMgr->mInsertKey( sCurLog->mTransID, sImage, sCurLog->mRefRecord );
                            // 2014.12.14. -okt- mDicRollback 함수에서 mInsertKey 호출할때, 오류체크 없다. 의도적인가? ( 2014/07/27 )
                            if ( sRC ) //, INSERT_KEY_FAIL );
                            {
                                DBM_ERR ("deleteKey Rollback Fail rc=%d, table=%s, index=%s, Slot=%lld\n"
                                        , sRC, sCurLog->mTableName, sCurLog->mObjectName, sCurLog->mRefRecord);
                                /* 빼는게 맞는 건가 모르겠다 */
                                //_IF_RAISE2( sRC, INVALID_LOG );
                            }
                        }
                        break;

                    case DBM_SELECT_FOR_UPDATE_LOG:
                    case DBM_ENQUE_LOG:
                    case DBM_DEQUE_LOG:
                    case DBM_DDL_CREATE_TABLE_LOG:
                    case DBM_DDL_CREATE_QUEUE_LOG:
                    case DBM_DDL_CREATE_LIST_LOG:
                    case DBM_DDL_CREATE_INDEX_LOG:
                    case DBM_DDL_DROP_INDEX_LOG:
                    case DBM_DDL_DROP_TRIG_LOG:
                    case DBM_DDL_DROP_TABLE_LOG:
                    case DBM_TRUNCATE_LOG:
                    case DBM_DELETE_SLOT_LOG:
                    case DBM_ALLOC_IDX_SLOT_LOG:
                    case DBM_LOCK_ROW_LOG:
                    case DBM_DEFER_INSERT_LOG:
                    case DBM_DEFER_UPDATE_LOG:
                    case DBM_SET_INDEX_LOG:
                        /* do nothing */
                        break;

                    default:
                        DBM_ERR( "invalid log type [%d]", sCurLog->mLogType );
                        _DASSERT( 0 );
                        _THROW( ERR_DBM_INVALID_LOG );
                        break;
                }

                sCurLog->mRollbackCompleteF = 1;
            }

            /***********************************************
             * 목표위치까지 Log 모두 rollback 처리 완료.
             ***********************************************/
            if ( sCurPos == sTxH->mLogStartPos )
            {
                break;
            }

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            sRC = mLogMgr->mLogMoveBackward( mUndoSegMgr, sTxH, &sCurPos );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );
        }

        /***********************************************
         * 마지막 로그로 다시 이동
         ***********************************************/
        sCurPos = sTxH->mLogCurPos;
        sTxH->mImageCurPos = MK_POS(-1,-1);


        /***********************************************
         * Unlock Row
         * Lock 걸었던 Row 를 모두 풀어버린다.
         ***********************************************/
        while(1)
        {
            sRC = mGetLogPtr(mUndoSegMgr, sCurPos, &sCurLog);
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

            if ( sCurLog->mLogValidF != 1 )
            {
                /* do nothing */
            }
            else
            {
                switch( sCurLog->mLogType )
                {
                    case DBM_LOCK_ROW_LOG:
                        sRC = mGetTableIdx( sCurLog->mTableName, &sTableIdx );
                        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

                        sTblSegMgr = mTable[sTableIdx]->mGetSegMgr();
                        _IF_THROW( sTblSegMgr == NULL, ERR_DBM_TABLE_NOT_PREPARED );

                        sRC = sTblSegMgr->Slot2Addr ( sCurLog->mRefRecord, &sRefRow ) ;

                        mLockMgr->mAtomicUnlockTry( (char*)&(sRefRow->mLock), mTransID );
                        break;

                    default:
                        break;
                }
            }

            /***********************************************
             * Log 모두 unlock 처리 완료.
             ***********************************************/
            if ( sCurPos == sTxH->mLogStartPos )
            {
                break;
            }

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            sRC = mLogMgr->mLogMoveBackward( mUndoSegMgr, sTxH, &sCurPos );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );
        }

        sTxH->mLogCurPos = MK_POS(-1,-1);

        DBM_INFO( "[DIC] Rollback End. TxID[%d]", mTransID );
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
} /* mDicRollback */


_VOID dbmDictionary::mDicRollbackRecovery ( int aTxID )
{
    long long           sCurPos;
    int                 sRowSize;
    char*               sImage       = NULL;
    dbmLogHeader*       sCurLog      = NULL;
    dbmRowHeader*       sRefRow      = NULL;
    dbmTransHeader*     sTxH         = NULL;
    dbmTransTable*      sTxTable     = NULL;
    dbmSegmentManager*  sSegMgr      = NULL;
    dbmSegmentManager*  sIdxSegMgr   = NULL;
    dbmTableInfo*       sTableInfo   = NULL;
    dbmTableHeader*     sTableHeader = NULL;
    dbmIndexHeader*     sIndexHeader = NULL;
    int                 sRC;
    unsigned long long  i;

    _TRY
    {
        sTxH = (dbmTransHeader*)&mTxTable->mItem[aTxID];
        DBM_WARN( "[DIC] Rollback Recovery Start. TxID[%d] PID[%d]", aTxID, sTxH->mPID );


        /***********************************************
         * 아무 로그도 없으면 할 일 없음.
         ***********************************************/
        if ( SLOTID(sTxH->mLogCurPos) == -1 )
        {
            sTxH->mRecoveryStartPos = MK_POS(-1,-1);
            sTxH->mImageCurPos      = MK_POS(-1,-1);

            _RAISE( UNLOCK_ROW );
        }

        if ( SLOTID(sTxH->mLogStartPos) == -1 )
        {
            DBM_WARN( "[DIC] Rollback Recovery End. TxID[%d]", aTxID );
            return RC_SUCCESS;
        }

        sTxH->mStatus = DBM_TX_ROLLBACK;


        /***********************************************
         * 로그 Slot 들에 대해 역으로 List 로 연결해줌.
         * 평상 시에는 성능 상 dbmLogSlotHeader 의 mNext 만 연결.
         ***********************************************/
        sRC = dbmRecoveryManager::mLinkReverseList( mUndoSegMgr, sTxH, -1 );
        _IF_THROW( sRC, ERR_DBM_INVALID_LOG );


        /***********************************************
         * 마지막 로그로 이동
         * 만약 mRecoveryStartPos 이 설정되어 있고, 이 위치가
         * CurPos 보다 작은 지점이라면 mRecoveryStartPos 부터
         * Rollback 을 시작해야 한다.
         * (Insert Key Log 기록 후 바로 Down 되는 case 등 때문에)
         ***********************************************/
        if ( SLOTID( sTxH->mRecoveryStartPos ) >= 0 && sTxH->mRecoveryStartPos < sTxH->mLogCurPos )
        {
            sCurPos = sTxH->mRecoveryStartPos;
        }
        else
        {
            sCurPos = sTxH->mLogCurPos;
        }


        /***********************************************
         * 모든 Log 를 차례로 방문하여 Log Type 별로
         * Rollback 작업 수행
         ***********************************************/
        while(1)
        {
            sRefRow    = NULL;
            sCurLog    = NULL;
            sImage     = NULL;
            sSegMgr    = NULL;
            sIdxSegMgr = NULL;
            sTableInfo = NULL;
            sTableHeader = NULL;
            sIndexHeader = NULL;

            sRC = mGetLogPtr ( mUndoSegMgr, sCurPos, &sCurLog );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

            if ( ( sCurLog->mRollbackCompleteF == 1 ) || ( sCurLog->mLogValidF != 1 ) )
            {
                /* do nothing */
            }
            else
            {
                switch( sCurLog->mLogType )
                {
                    case DBM_ALLOC_SLOT_LOG:
                    case DBM_ALLOC_IDX_SLOT_LOG:
                        /***********************************************
                         * 할당한 slot 을 free 한다.
                         ***********************************************/
                        _CALL( dbmSegmentManager::Attach( SYS_INST_NAME, sCurLog->mObjectName, &sSegMgr ) );

                        _CALL( dbmSegFreeSlot( sSegMgr, sCurLog->mRefRecord, 1 ) );

#ifndef USE_NEW_SHM_NODETACH
                        sSegMgr->Detach();
#endif
                        delete_s( sSegMgr );
                        break;

                    case DBM_INSERT_SLOT_LOG:
                        /***********************************************
                         * insert 한 row 를 초기화해버린다.
                         ***********************************************/
                        _CALL( dbmSegmentManager::Attach( SYS_INST_NAME, sCurLog->mObjectName, &sSegMgr ) );
                        _CALL( sSegMgr->Slot2Addr( sCurLog->mRefRecord, &sRefRow ) );

                        sRowSize = sRefRow->mRowSize;
                        memset_s( (char*)sRefRow+sizeof(dbmRowHeader), 0x00, sRowSize );

                        sRefRow->mSCN     = 0;
                        sRefRow->mRowSize = 0;

#ifndef USE_NEW_SHM_NODETACH
                        sSegMgr->Detach();
#endif
                        delete_s( sSegMgr );
                        break;

                    case DBM_DELETE_DATA_LOG:
                    case DBM_UPDATE_SLOT_LOG:
                    case DBM_UPDATE_KEY_LOG:
                        /***********************************************
                         * Image Log 를 통해 Row Image 를 복구한다.
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _THROW( ERR_DBM_INVALID_LOG );
                            }
                        }

                        _CALL( dbmSegmentManager::Attach( SYS_INST_NAME, sCurLog->mObjectName, &sSegMgr ) );
                        _CALL( sSegMgr->Slot2Addr( sCurLog->mRefRecord, &sRefRow ) );

                        sRC = mGetImagePtr( mUndoSegMgr, sCurLog->mImageLogPos, &sImage);
                        _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

                        sRowSize = ((dbmRowHeader*)sImage)->mRowSize;

                        memset_s( (char*)sRefRow+sizeof(dbmRowHeader), 0x00, sRowSize );
                        memcpy_s( sRefRow, sImage, sRowSize+sizeof(dbmRowHeader) );

#ifndef USE_NEW_SHM_NODETACH
                        sSegMgr->Detach();
#endif
                        delete_s( sSegMgr );
                        break;

                    case DBM_INSERT_INDEX_LOG:
                    case DBM_INSERT_INDEX_LOG2:
                        /***********************************************
                         * ImageLog 에 저장된 key 를 이용하여 Delete Key를 수행.
                         * Insert Index Log 의 Image Log 에는 Key 값만 들어있다.
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _THROW( ERR_DBM_INVALID_LOG );
                            }
                        }

                        sRC = mGetImagePtr( mUndoSegMgr, sCurLog->mImageLogPos, &sImage );
                        _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

                        if( sCurLog->mLogType == DBM_INSERT_INDEX_LOG )
                        {
                            sRC = dbmIndexManager::mDeleteKey( SYS_INST_NAME,
                                    sCurLog->mTransID, sCurLog->mObjectName, sImage);
                        }
                        else
                        {
                            sRC = dbmIndexManager::mDeleteKey( SYS_INST_NAME,
                                    sCurLog->mTransID, sCurLog->mObjectName, sImage, 1);
                        }
                        if (sRC)
                        {
                            DBM_ERR ("insertKey rollback fail rc=%d, table=%s, index=%s, ref=%lld\n"
                                    , sRC, sCurLog->mTableName, sCurLog->mObjectName, sCurLog->mRefRecord);
                        }
                        break;

                    case DBM_DELETE_INDEX_LOG:
                    case DBM_DELETE_INDEX_LOG2:
                        /***********************************************
                         * image log 에 저장된 key 를 이용하여 Insert Key를
                         * 수행한다. 마지막 로그가 아니고 중간로그인데
                         * Image 가 valid 하지 않으면 에러다.
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _THROW( ERR_DBM_INVALID_LOG );
                            }
                        }

                        /***********************************************
                         * Delete Index Log 의 Image Log 에는 Key 값만 들어있다.
                         ***********************************************/
                        sRC = mGetImagePtr( mUndoSegMgr, sCurLog->mImageLogPos, &sImage);
                        _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

                        /* 2014.07.22 -shw- commit flage가 정상 적으로 되었을 때만 실행 */
                        if ( sCurLog->mCommitCompleteF == 1 )
                        {
                            sRC = dbmIndexManager::mInsertKey( SYS_INST_NAME,
                                                               sCurLog->mRefRecord,
                                                               sCurLog->mTransID,
                                                               sCurLog->mObjectName,
                                                               sImage );
                            // 2014.12.14. -okt- mDicRollbackRecovery 함수에서 mInsertKey 호출할때, 오류체크 없다. 의도적인가? ( 2014/07/27 )
                            if ( sRC ) //, INSERT_KEY_FAIL );
                            {
                                DBM_ERR ("deleteKey Rollback Fail rc=%d, table=%s, index=%s, Slot=%lld\n"
                                        , sRC, sCurLog->mTableName, sCurLog->mObjectName, sCurLog->mRefRecord);
                                /* 빼는게 맞는 건가 모르겠다 */
                                //_IF_RAISE2( sRC, INVALID_LOG );
                            }
                        }

                        break;

                    case DBM_DDL_CREATE_TABLE_LOG:
                    case DBM_DDL_CREATE_QUEUE_LOG:
                    case DBM_DDL_CREATE_LIST_LOG:
                    case DBM_DDL_DROP_TABLE_LOG:
                    case DBM_DDL_CREATE_INDEX_LOG:
                    case DBM_DDL_DROP_INDEX_LOG:
                    case DBM_DDL_DROP_TRIG_LOG:
                    case DBM_TRUNCATE_LOG:
                    case DBM_SELECT_FOR_UPDATE_LOG:
                    case DBM_ENQUE_LOG:
                    case DBM_DEQUE_LOG:
                    case DBM_LOCK_ROW_LOG:
                    case DBM_DELETE_SLOT_LOG:
                    case DBM_DEFER_INSERT_LOG:
                    case DBM_DEFER_UPDATE_LOG:
                    case DBM_SET_INDEX_LOG:
                        /* do nothing */
                        break;

                    default:
                        _THROW( ERR_DBM_INVALID_LOG );
                        break;
                }

                sCurLog->mRollbackCompleteF = 1;
            }

            /***********************************************
             * Log 모두 rollback 처리 완료.
             ***********************************************/
            if ( sCurPos == sTxH->mLogStartPos )
            {
                break;
            }

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            sRC = dbmLogManager::mLogMoveBackward( mUndoSegMgr, sTxH, &sCurPos );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );
        }

        /***********************************************
         * 마지막 로그로 다시 이동
         ***********************************************/
        _LABEL( UNLOCK_ROW );

        if ( (SLOTID(sTxH->mRecoveryStartPos) >= 0)
         && (sTxH->mRecoveryStartPos < sTxH->mLogCurPos) )
        {
            sCurPos = sTxH->mRecoveryStartPos;
        }
        else
        {
            if ( SLOTID(sTxH->mLogCurPos) == -1 )
            {
                if ( SLOTID(sTxH->mLockRecoveryPos) == -1 )
                {
                    return RC_SUCCESS;
                }
                sCurPos = sTxH->mLockRecoveryPos;
            }
            else
            {
                sCurPos = sTxH->mLogCurPos;
            }
        }


        /***********************************************
         * Unlock Row
         ***********************************************/
        while(1)
        {
            sRC = mGetLogPtr(mUndoSegMgr, sCurPos, &sCurLog);
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

            if ( sCurLog->mLogValidF != 1 )
            {
                /* do nothing */
            }
            else
            {
                switch( sCurLog->mLogType )
                {
                    case DBM_LOCK_ROW_LOG:
                        _CALL( dbmSegmentManager::Attach( SYS_INST_NAME, sCurLog->mObjectName, &sSegMgr ) );
                        _CALL( sSegMgr->Slot2Addr( sCurLog->mRefRecord, &sRefRow ) );

                        dbmLockManager::mAtomicUnlockTry( (char*)&(sRefRow->mLock), sCurLog->mTransID );

#ifndef USE_NEW_SHM_NODETACH
                        sSegMgr->Detach();
#endif
                        delete_s( sSegMgr );
                        break;

                    default:
                        break;
                }
            }

            /***********************************************
             * Log 모두 unlock 처리 완료.
             ***********************************************/
            if ( sCurPos == sTxH->mLogStartPos )
            {
                break;
            }

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            sRC = dbmLogManager::mLogMoveBackward( mUndoSegMgr, sTxH, &sCurPos );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );
        } /* while */

        /***********************************************
         * 로그 기록 위치 초기화.
         ***********************************************/
        sTxH->mImageCurPos       = MK_POS(-1,-1);
        sTxH->mLogCurPos         = MK_POS(-1,-1);
        sTxH->mRecoveryStartPos  = MK_POS(-1,-1);
        sTxH->mLockRecoveryPos   = MK_POS(-1,-1);

        DBM_WARN( "[DIC] Rollback Recovery End. TxID[%d]", aTxID );
    }

    _CATCH
    {
        _CATCH_WARN;
        dbmRecoveryManager::mDumpTxHeader( (char*)sTxH );
    }
    _FINALLY
    _END
} /* mDicRollbackRecovery */


_VOID dbmDictionary::mDetach()
{
    _TRY
    {
        _CALL( mInitObject ( ) );
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mInsertInstance( dbmInstanceDic* aInstance )
{
    dbmDataObject   sDataObj;
    dbmInstanceDic* sInstanceDic;
    int             sTableIdx = -1;
    long long       sTmp1 = -1;
    long long       sTmp2 = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sInstanceDic = (dbmInstanceDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);

        memcpy_s( sInstanceDic, aInstance, sizeof(dbmInstanceDic) );


        /***********************************************
         * find dictionary table object
         ***********************************************/
        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_INSTANCE], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );


        /***********************************************
         * make key string & user data to insert
         *  - Instance ID 획득
         ***********************************************/
        sDataObj.mTransType = DBM_INSERT;

        cmnStrCpyZ ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_INSTANCE] );
        sDataObj.mDataSize = DBM_INDEX_KEY_MAX_SIZE + sizeof(dbmInstanceDic);

        sInstanceDic->mInstanceID = mvpAtomicInc64 ( &mUndoHeader->mGSCN );

        MK_INST_KEY ( __gUserData, aInstance->mInstanceName );
        gettimeofday ( &sInstanceDic->mCreateTime, NULL );

        _CALL( mTable[sTableIdx]->mInsert( mTransID,
                                           &sDataObj,
                                           mTransHeader,
                                           &sTmp1,
                                           &sTmp2 ) );


        /***********************************************
         * 사용자에게 새로 할당된 Instance ID 리턴
         ***********************************************/
        aInstance->mInstanceID = sInstanceDic->mInstanceID;

        memcpy_s( &aInstance->mCreateTime,
                  &sInstanceDic->mCreateTime,
                  sizeof(struct timeval));
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mSelectInstance ( dbmInstanceDic* aInstance , int aSelectType )
{
    dbmDataObject   sDataObj;
    dbmInstanceDic* sInstanceDic;
    int             sTableIdx = -1;
    long long       sTmp1 = -1;
    long long       sTmp2 = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sInstanceDic = (dbmInstanceDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);


        /***********************************************
         * find dictionary table object
         ***********************************************/
        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_INSTANCE], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );


        /***********************************************
         * make key string & select from table
         ***********************************************/
        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_INSTANCE] );
        MK_INST_KEY( __gUserData, aInstance->mInstanceName );

        if ( aSelectType == 1 )
        {
            sDataObj.mTransType = DBM_SELECT_GT;
            _CALL( mTable[sTableIdx]->mSelectGT( mTransID, &sDataObj, DBM_DIRTY_OFF ) );
        }
        else
        {
            sDataObj.mTransType = DBM_SELECT;
            _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );
        }

        memcpy_s( aInstance, sInstanceDic, sizeof(dbmInstanceDic) );
    }

    _CATCH
    {
        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_TRC;
        }
        else
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mDeleteInstance( dbmInstanceDic* aInstance )
{
    dbmDataObject   sDataObj;
    dbmInstanceDic* sInstanceDic;
    int             sTableIdx = -1;
    long long       sTmp1 = -1;
    long long       sTmp2 = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sInstanceDic = (dbmInstanceDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);


        /***********************************************
         * 혹시 필요할지 모르니까 조회한 정보는 복사해주자.
         ***********************************************/
        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_INSTANCE], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_SELECT;

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_INSTANCE] );
        MK_INST_KEY( __gUserData, aInstance->mInstanceName );

        _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );

        memcpy_s( aInstance, sInstanceDic, sizeof(dbmInstanceDic) );


        /***********************************************
         * 이제 삭제
         ***********************************************/
        sDataObj.mTransType = DBM_DELETE;

        _CALL( mTable[sTableIdx]->mDelete( mTransID, &sDataObj ) );
    }

    _CATCH
    {
        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_TRC;
        }
        else
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mInsertTable( dbmTableDic* aTableDic,
                                   int          aInitInsertF )
{
    dbmDataObject   sDataObj;
    dbmInstanceDic  sInstanceDic;
    dbmTableDic*    sTableDic = NULL;
    int             sTableIdx = -1;
    long long       sRollbackStartLogPos = -1;
    long long       sRollbackStartImagePos = -1;
    long long       sInstanceID;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sTableDic = (dbmTableDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);

        memcpy_s( sTableDic, aTableDic, sizeof(dbmTableDic) );


        /***********************************************
         * __sys_table 에 table 정보 insert 할 때
         * Instance id 도 넣어야 하기 때문에 sys_instance 조회
         ***********************************************/
        memset_s( &sInstanceDic, 0x00, sizeof(dbmInstanceDic) );

        memcpy_s( sInstanceDic.mInstanceName, aTableDic->mInstName, DBM_NAME_LEN );

        _CALL( mSelectInstance( &sInstanceDic, 0 ) );

        sInstanceID  = sInstanceDic.mInstanceID;


        /***********************************************
         * Buffer 재사용
         ***********************************************/
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sTableDic = (dbmTableDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);

        memcpy_s( sTableDic, aTableDic, sizeof(dbmTableDic) );


        /***********************************************
         * make key string & user data to insert
         *  - Table ID 획득
         *    (dictionary table 에 대한 init insert 일 경우는
         *     이미 Table ID 가 획득되어 있다)
         ***********************************************/
        sRC = mGetTableIdx ( dbmDicTableName[DBM_DIC_TBL_TABLE], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_INSERT;

        cmnStrCpyZ ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_TABLE] );
        sDataObj.mDataSize = DBM_INDEX_KEY_MAX_SIZE + sizeof(dbmTableDic);

        sTableDic->mInstID = sInstanceID;
        if ( aInitInsertF != 1 )
        {
            sTableDic->mTableID = mvpAtomicInc64 ( &mUndoHeader->mGSCN );
        }

        MK_TBL_KEY( __gUserData, sTableDic->mInstName, sTableDic->mTableName );
        gettimeofday( &sTableDic->mCreateTime, NULL );

        _rc = mTable[sTableIdx]->mInsert( mTransID,
                                          &sDataObj,
                                          mTransHeader,
                                          &sRollbackStartLogPos,
                                          &sRollbackStartImagePos );
        if ( _rc != 0 )
        {
            if ( sRollbackStartLogPos != -1 )
            {
                mTransHeader->mLogCurPos   = sRollbackStartLogPos;
                mTransHeader->mImageCurPos = sRollbackStartImagePos;
            }

            _THROW( _rc );
        }

        /***********************************************
         * 사용자에게 새로 할당된 Table ID 리턴
         ***********************************************/
        aTableDic->mInstID = sTableDic->mInstID;
        aTableDic->mTableID = sTableDic->mTableID;

        memcpy_s ( &aTableDic->mCreateTime, &sTableDic->mCreateTime, sizeof(struct timeval) );
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mInsertObject( dbmObjectDic* aObjectDic )
{
    dbmDataObject   sDataObj;
    dbmObjectDic*   sObjectDic = NULL;
    int             sTableIdx = -1;
    long long       sRollbackStartLogPos = -1;
    long long       sRollbackStartImagePos = -1;
    int             sRC;

    _TRY
    {
        memset_s ( &sDataObj, 0x00, sizeof( sDataObj ) );
        memset_s ( __gUserData, 0x00, sizeof( __gUserData ) );

        sDataObj.mUserData = __gUserData;
        sObjectDic = (dbmObjectDic *) __gUserData;

        memcpy_s ( sObjectDic, aObjectDic, sizeof(dbmObjectDic) );

        sRC = mGetTableIdx ( dbmDicTableName[DBM_DIC_TBL_OBJECT], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_INSERT;

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_OBJECT] );
        sDataObj.mDataSize  = sizeof(dbmObjectDic);

        _rc = mTable[sTableIdx]->mInsert( mTransID,
                                          &sDataObj,
                                          mTransHeader,
                                          &sRollbackStartLogPos,
                                          &sRollbackStartImagePos );
        if ( _rc != 0 )
        {
            if ( sRollbackStartLogPos != -1 )
            {
                mTransHeader->mLogCurPos   = sRollbackStartLogPos;
                mTransHeader->mImageCurPos = sRollbackStartImagePos;
            }

            _THROW( _rc );
        }
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mInsertTrigger( dbmEventDic* aEventDic )
{
    dbmDataObject   sDataObj;
    dbmEventDic*    sEventDic = NULL;
    int             sTableIdx = -1;
    long long       sRollbackStartLogPos = -1;
    long long       sRollbackStartImagePos = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sEventDic = (dbmEventDic *)__gUserData;

        memcpy_s( sEventDic, aEventDic, sizeof(dbmEventDic) );

        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_TRIGGER], &sTableIdx );
        _IF_THROW( sRC || sTableIdx < 0, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_INSERT;

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_TRIGGER] );
        sDataObj.mDataSize  = sizeof(dbmEventDic);

        _rc = mTable[sTableIdx]->mInsert( mTransID,
                                          &sDataObj,
                                          mTransHeader,
                                          &sRollbackStartLogPos,
                                          &sRollbackStartImagePos );
        if ( _rc != 0 )
        {
            if ( sRollbackStartLogPos != -1 )
            {
                mTransHeader->mLogCurPos   = sRollbackStartLogPos;
                mTransHeader->mImageCurPos = sRollbackStartImagePos;
            }

            _THROW( _rc );
        }
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mUpdateTrigger( dbmEventDic* aEventDic )
{
    dbmDataObject   sDataObj;
    dbmEventDic*    sEventDic = NULL;
    int             sTableIdx = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sEventDic = (dbmEventDic *)__gUserData;

        memcpy_s( sEventDic, aEventDic, sizeof(dbmEventDic) );

        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_TRIGGER], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_UPDATE;

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_TRIGGER] );
        sDataObj.mDataSize  = sizeof(dbmEventDic);

        _CALL( mTable[sTableIdx]->mUpdate( mTransID, &sDataObj ) );
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mSelectTable( dbmTableDic* aTableDic,
                                   int          aSelectType )
{
    dbmDataObject   sDataObj;
    dbmTableDic*    sTableDic = NULL;
    int             sTableIdx = -1;
    long long       sTmp1 = -1;
    long long       sTmp2 = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sTableDic = (dbmTableDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);


        /***********************************************
         * find dictionary table object
         ***********************************************/
        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_TABLE], &sTableIdx );
        _IF_THROW( sRC || sTableIdx < 0, ERR_DBM_TABLE_NOT_PREPARED );


        /***********************************************
         * make key string & select from table
         ***********************************************/
        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_TABLE] );
        MK_TBL_KEY( __gUserData, aTableDic->mInstName, aTableDic->mTableName );

        if ( aSelectType == 1 )
        {
            sDataObj.mTransType = DBM_SELECT_GT;
            _CALL( mTable[sTableIdx]->mSelectGT( mTransID, &sDataObj, DBM_DIRTY_OFF ) );
        }
        else
        {
            sDataObj.mTransType = DBM_SELECT;
            _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );
        }

        memcpy_s( aTableDic, sTableDic, sizeof(dbmTableDic) );
    }

    _CATCH
    {
        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_TRC2( sDataObj.mTableName );
        }
        else
        {
            _CATCH_WARN2( sDataObj.mTableName );
        }
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mSelectObject( dbmObjectDic* aObjectDic )
{
    dbmDataObject   sDataObj;
    dbmObjectDic*   sObjectDic = NULL;
    int             sTableIdx = -1;
    long long       sTmp1 = -1;
    long long       sTmp2 = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sObjectDic = (dbmObjectDic *)__gUserData;

        memcpy_s( sObjectDic, aObjectDic, sizeof(dbmObjectDic) );


        /***********************************************
         * find dictionary table object
         ***********************************************/
        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_OBJECT], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_SELECT;
        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_OBJECT] );

        _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );

        memcpy_s( aObjectDic, sObjectDic, sizeof(dbmObjectDic) );
    }

    _CATCH
    {
        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_TRC2( sDataObj.mTableName );
        }
        else
        {
            _CATCH_WARN2( sDataObj.mTableName );
        }
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mSelectTrigger( dbmEventDic* aEventDic )
{
    dbmDataObject   sDataObj;
    dbmEventDic*    sEventDic = NULL;
    int             sTableIdx = -1;
    long long       sTmp1 = -1;
    long long       sTmp2 = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sEventDic = (dbmEventDic *)__gUserData;

        memcpy_s( sEventDic, aEventDic, sizeof(dbmEventDic) );


        /***********************************************
         * find dictionary table object
         ***********************************************/
        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_TRIGGER], &sTableIdx );
        _IF_THROW( sRC || sTableIdx < 0, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_SELECT;
        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_TRIGGER] );

        _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );

        memcpy_s( aEventDic, sEventDic, sizeof(dbmEventDic) );
    }

    _CATCH
    {
        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_TRC2( sDataObj.mTableName );
        }
        else
        {
            _CATCH_WARN2( sDataObj.mTableName );
        }
    }
    _FINALLY
    _END
}

_VOID dbmDictionary::mUpdateTable( dbmTableDic* aTableDic )
{
    dbmDataObject   sDataObj;
    dbmTableDic*    sTableDic = NULL;
    int             sTableIdx = -1;
    long long       sTmp1 = -1;
    long long       sTmp2 = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sTableDic = (dbmTableDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);

        memcpy_s( sTableDic, aTableDic, sizeof(dbmTableDic));


        /***********************************************
         * find dictionary table object
         ***********************************************/
        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_TABLE], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );


        /***********************************************
         * make key string & select from table
         ***********************************************/
        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_TABLE] );
        MK_TBL_KEY( __gUserData, aTableDic->mInstName, aTableDic->mTableName );

        sDataObj.mTransType = DBM_UPDATE;
        sDataObj.mDataSize  = DBM_INDEX_KEY_MAX_SIZE + sizeof(dbmTableDic);

        _CALL( mTable[sTableIdx]->mUpdate( mTransID, &sDataObj ) );
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mDeleteTable( dbmTableDic* aTableDic )
{
    dbmDataObject   sDataObj;
    dbmTableDic*    sTableDic = NULL;
    int             sTableIdx = -1;
    long long       sTmp1 = -1;
    long long       sTmp2 = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sTableDic = (dbmTableDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);


        /***********************************************
         * 혹시 필요할지 모르니까 조회한 정보는 복사해주자.
         ***********************************************/
        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_TABLE], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_SELECT;

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_TABLE] );
        MK_TBL_KEY( __gUserData, aTableDic->mInstName, aTableDic->mTableName );

        _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );

        memcpy_s( aTableDic, sTableDic, sizeof(dbmTableDic) );


        /***********************************************
         * 이제 삭제
         ***********************************************/
        sDataObj.mTransType = DBM_DELETE;

        _CALL( mTable[sTableIdx]->mDelete( mTransID, &sDataObj ) );
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mDeleteObject( dbmObjectDic* aObjectDic )
{
    dbmDataObject   sDataObj;
    dbmObjectDic*   sObjectDic = NULL;
    int             sTableIdx = -1;
    long long       sTmp1 = -1;
    long long       sTmp2 = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sObjectDic = (dbmObjectDic *)__gUserData;

        memcpy_s( sObjectDic, aObjectDic, sizeof(dbmObjectDic) );

        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_OBJECT], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_DELETE;
        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_OBJECT] );

        _CALL( mTable[sTableIdx]->mDelete( mTransID, &sDataObj ) );
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mDeleteTrigger( dbmEventDic* aEventDic )
{
    dbmDataObject   sDataObj;
    dbmEventDic*    sEventDic = NULL;
    int             sTableIdx = -1;
    long long       sTmp1 = -1;
    long long       sTmp2 = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sEventDic = (dbmEventDic *)__gUserData;

        memcpy_s( sEventDic, aEventDic, sizeof(dbmEventDic) );

        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_TRIGGER], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_DELETE;
        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_TRIGGER] );

        _CALL( mTable[sTableIdx]->mDelete( mTransID, &sDataObj ) );
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mInsertColumn( dbmColumnDic* aColumnDic )
{
    dbmDataObject   sDataObj;
    dbmColumnDic*   sColumnDic = NULL;
    int             sTableIdx = -1;
    long long       sRollbackStartLogPos = -1;
    long long       sRollbackStartImagePos = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sColumnDic = (dbmColumnDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);

        memcpy_s( sColumnDic, aColumnDic, sizeof(dbmColumnDic) );


        /***********************************************
         * make key string & user data to insert
         ***********************************************/
        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_COLUMN], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_INSERT;

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_COLUMN] );
        sDataObj.mDataSize  = DBM_INDEX_KEY_MAX_SIZE + sizeof(dbmColumnDic);

        MK_COL_KEY( __gUserData,
                    sColumnDic->mInstID,
                    sColumnDic->mTableID,
                    sColumnDic->mColumnID );

        _CALL( mTable[sTableIdx]->mInsert( mTransID,
                                           &sDataObj,
                                           mTransHeader,
                                           &sRollbackStartLogPos,
                                           &sRollbackStartImagePos ) );
        if ( _rc != 0 )
        {
            if ( sRollbackStartLogPos != -1 )
            {
                mTransHeader->mLogCurPos   = sRollbackStartLogPos;
                mTransHeader->mImageCurPos = sRollbackStartImagePos;
            }

            _THROW( _rc );
        }
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mSelectColumn( dbmColumnDic*   aColumnDic )
{
    dbmDataObject       sDataObj;
    dbmColumnDic*       sColumnDic    = NULL;
    int                 sTableIdx     = -1;
    long long           sInstID;
    long long           sTableID;
    int                 sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sColumnDic = (dbmColumnDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);

        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_COLUMN], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_SELECT;

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_COLUMN] );

        MK_COL_KEY( __gUserData,
                    aColumnDic->mInstID,
                    aColumnDic->mTableID,
                    aColumnDic->mColumnID );

        _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );

        memcpy_s( aColumnDic, sColumnDic, sizeof(dbmColumnDic) );
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mUpdateColumn ( int aOldTableID , dbmColumnDic* aColumnDic )
{
    dbmDataObject   sDataObj;
    dbmColumnDic*   sColumnDic    = NULL;
    int             sTableIdx     = -1;
    long long       sInstID;
    long long       sTableID;
    long long       sRollbackStartLogPos = -1;
    long long       sRollbackStartImagePos = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sColumnDic = (dbmColumnDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);

        memcpy_s( sColumnDic, aColumnDic, sizeof(dbmColumnDic));

        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_COLUMN], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_COLUMN] );

        /***********************************************
         * Key 안에 TableID 가 포함되어 있기 때문에
         * Key 를 Update 할 수는 없고 Delete -> Insert 로 처리.
         ***********************************************/
        sDataObj.mTransType = DBM_DELETE;

        MK_COL_KEY( __gUserData,
                    aColumnDic->mInstID,
                    aOldTableID,            /* old tableid 로 delete */
                    aColumnDic->mColumnID );

        _CALL( mTable[sTableIdx]->mDelete( mTransID, &sDataObj ) );

        sDataObj.mTransType = DBM_INSERT;
        sDataObj.mDataSize  = DBM_INDEX_KEY_MAX_SIZE + sizeof(dbmColumnDic);

        MK_COL_KEY( __gUserData,
                    aColumnDic->mInstID,
                    sColumnDic->mTableID,   /* new tableid 로 다시 insert */
                    aColumnDic->mColumnID );

        _CALL( mTable[sTableIdx]->mInsert( mTransID,
                                           &sDataObj,
                                           mTransHeader,
                                           &sRollbackStartLogPos,
                                           &sRollbackStartImagePos ) );
        if ( _rc != 0 )
        {
            if ( sRollbackStartLogPos != -1 )
            {
                mTransHeader->mLogCurPos   = sRollbackStartLogPos;
                mTransHeader->mImageCurPos = sRollbackStartImagePos;
            }

            _THROW( _rc );
        }
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mDeleteColumn( dbmColumnDic*   aColumnDic )
{
    dbmDataObject   sDataObj;
    dbmColumnDic*   sColumnDic    = NULL;
    int             sTableIdx     = -1;
    long long       sInstID;
    long long       sTableID;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sColumnDic = (dbmColumnDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);


        /***********************************************
         * 혹시 필요할지 모르니까 조회한 정보는 복사해주자.
         ***********************************************/
        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_COLUMN], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_SELECT;

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_COLUMN] );

        MK_COL_KEY( __gUserData,
                    aColumnDic->mInstID,
                    aColumnDic->mTableID,
                    aColumnDic->mColumnID );

        _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );

        memcpy_s( aColumnDic, sColumnDic, sizeof(dbmColumnDic) );


        /***********************************************
         * 이제 삭제
         ***********************************************/
        sDataObj.mTransType = DBM_DELETE;

        _CALL( mTable[sTableIdx]->mDelete( mTransID, &sDataObj ) );
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mInsertIndex ( dbmIndexDic* aIndexDic , int aUpdateTableF )
{
    dbmDataObject       sDataObj;
    dbmTableDic*        sTableDic = NULL;
    dbmIndexDic*        sIndexDic = NULL;
    dbmSegmentManager*  sSegMgr = NULL;
    dbmTableHeader*     sTableHeader = NULL;
    int                 sTableIdx = -1;
    long long           sInstID;
    long long           sTableID;
    long long           sRollbackStartLogPos = -1;
    long long           sRollbackStartImagePos = -1;
    int                 sRC;
    int                 i;

    _TRY
    {
        /***********************************************
         * Instance id 와 table id 를 얻기 위해 __sys_table 조회
         ***********************************************/
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gSelectUserData, 0x00, sizeof(__gSelectUserData) );

        sDataObj.mUserData = __gSelectUserData;
        sTableDic = (dbmTableDic *)(__gSelectUserData + DBM_INDEX_KEY_MAX_SIZE);

        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_TABLE], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_SELECT;

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_TABLE] );
        MK_TBL_KEY( sDataObj.mUserData, aIndexDic->mInstName, aIndexDic->mTableName );

        _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );

        sInstID  = sTableDic->mInstID;
        sTableID = sTableDic->mTableID;


        /***********************************************
         * - __sys_table 에서 index 정보 update
         * - table header 에서 index 정보 update
         *
         * (mCreate 시 수행하는 mInitInsert 시에는 이미
         *  다 되어 있기 때문에 aUpdateTableF 는 0 임)
         ***********************************************/
        if ( aUpdateTableF == 1 )
        {
            /* __sys_table dictionary table update */
            for(i=0; i<DBM_MAX_INDEX_PER_TABLE; i++)
            {
                if ( sTableDic->mIndexName[i][0] == 0x00 )
                {
                    cmnStrCpyZ( sTableDic->mIndexName[i], aIndexDic->mIndexName );
                    break;
                }
            }

            _IF_THROW( i>= DBM_MAX_INDEX_PER_TABLE, ERR_DBM_TOO_MANY_INDEX);

            _CALL( mTable[sTableIdx]->mUpdate( mTransID, &sDataObj ) );

            /*
             * table header update
             *   - mIndexCount 와 mIndex[] 정보는 tx mgr 에서 수행하고 있음.
             *     table header 작업이 나누어진게 좀 이상하긴 하지만 일단 pass
             */
            _CALL( dbmSegmentManager::Attach( sTableDic->mInstName, sTableDic->mTableName, &sSegMgr ));
            sTableHeader = (dbmTableHeader*)sSegMgr->GetUserHeader();

            memcpy_s( sTableHeader->mTableObj.mIndexName,
                      sTableDic->mIndexName,
                      DBM_NAME_LEN * DBM_MAX_INDEX_PER_TABLE );

            delete sSegMgr; sSegMgr = NULL;
        }


        /***********************************************
         * - __sys_index 테이블에 insert
         * - index header 정보 update
         *
         * index id 는 처음 mInitInsert 시에는 mCreate 에서
         * 할당한 것을 사용하고 일반적인 insert index 에서는
         * 신규로 할당해야 한다.
         ***********************************************/
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sIndexDic = (dbmIndexDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);

        memcpy_s( sIndexDic, aIndexDic, sizeof(dbmIndexDic) );

        sIndexDic->mInstID  = sInstID;
        sIndexDic->mTableID = sTableID;
        if ( aUpdateTableF == 1 )
        {
            sIndexDic->mIndexID = mvpAtomicInc64(&mUndoHeader->mGSCN);
        }

        for(i=0; i<sIndexDic->mColumnCount; i++)
        {
            sIndexDic->mKey[i].mInstID  = sInstID;
            sIndexDic->mKey[i].mTableID = sTableID;
        }

        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_INDEX], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_INSERT;

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_INDEX] );
        sDataObj.mDataSize  = DBM_INDEX_KEY_MAX_SIZE + sizeof(dbmIndexDic);

        MK_IDX_KEY( __gUserData, sInstID, sTableID, sIndexDic->mIndexName );

        /*
         * insert 한 후의 dbmIndexDic 을 tx mgr 에서 이용한다.
         * (index header 작업을 위해)
         */
        memcpy_s( aIndexDic, sIndexDic, sizeof(dbmIndexDic) );

        _CALL( mTable[sTableIdx]->mInsert( mTransID,
                                           &sDataObj,
                                           mTransHeader,
                                           &sRollbackStartLogPos,
                                           &sRollbackStartImagePos ) );
        if ( _rc != 0 )
        {
            if ( sRollbackStartLogPos != -1 )
            {
                mTransHeader->mLogCurPos   = sRollbackStartLogPos;
                mTransHeader->mImageCurPos = sRollbackStartImagePos;
            }

            _THROW( _rc );
        }
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mSelectIndex( long long    aInstID,
                                   long long    aTableID,
                                   char*        aIndexName,
                                   dbmIndexDic* aIndexDic,
                                   int          aSelectType )
{
    dbmDataObject   sDataObj;
    dbmIndexDic*    sIndexDic = NULL;
    int             sTableIdx = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sIndexDic = (dbmIndexDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);

        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_INDEX], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_INDEX] );
        MK_IDX_KEY( __gUserData, aInstID, aTableID, aIndexName );

        if ( aSelectType == 1 )
        {
            sDataObj.mTransType = DBM_SELECT_GT;
            _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );
        }
        else
        {
            sDataObj.mTransType = DBM_SELECT;
            _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );
        }

        memcpy_s( aIndexDic, sIndexDic, sizeof(dbmIndexDic) );
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mUpdateIndex( int          aOldTableID,
                                   dbmIndexDic* aIndexDic )
{
    dbmDataObject   sDataObj;
    dbmIndexDic*    sIndexDic = NULL;
    int             sTableIdx = -1;
    long long       sRollbackStartLogPos = -1;
    long long       sRollbackStartImagePos = -1;
    int             sRC;

    _TRY
    {
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );

        sDataObj.mUserData = __gUserData;
        sIndexDic = (dbmIndexDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);

        memcpy_s( sIndexDic, aIndexDic, sizeof(dbmIndexDic));

        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_INDEX], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_INDEX] );

        /***********************************************
         * Key 안에 TableID 가 포함되어 있기 때문에
         * Key 를 Update 할 수는 없고 Delete -> Insert 로 처리.
         ***********************************************/
        sDataObj.mTransType = DBM_DELETE;

        MK_IDX_KEY( __gUserData,
                    sIndexDic->mInstID,
                    aOldTableID,
                    sIndexDic->mIndexName );

        _CALL( mTable[sTableIdx]->mDelete( mTransID, &sDataObj ) );

        sDataObj.mTransType = DBM_UPDATE;
        sDataObj.mDataSize  = DBM_INDEX_KEY_MAX_SIZE + sizeof(dbmIndexDic);

        MK_IDX_KEY( __gUserData,
                    sIndexDic->mInstID,
                    sIndexDic->mTableID,
                    sIndexDic->mIndexName );

        _CALL( mTable[sTableIdx]->mInsert( mTransID,
                                           &sDataObj,
                                           mTransHeader,
                                           &sRollbackStartLogPos,
                                           &sRollbackStartImagePos ) );
        if ( _rc != 0 )
        {
            if ( sRollbackStartLogPos != -1 )
            {
                mTransHeader->mLogCurPos   = sRollbackStartLogPos;
                mTransHeader->mImageCurPos = sRollbackStartImagePos;
            }

            _THROW( _rc );
        }
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mDeleteIndex( long long    aInstID,
                                   long long    aTableID,
                                   char*        aInstName,
                                   char*        aTableName,
                                   char*        aIndexName,
                                   dbmIndexDic* aIndexDic )
{
    dbmDataObject   sDataObj;
    dbmIndexDic*    sIndexDic = NULL;
    dbmTableDic*    sTableDic = NULL;
    int             sTableIdx = -1;
    int             sRC;
    int             i;

    _TRY
    {
        /***********************************************
         * Index 가 속한 Table 의 IndexName Array 에서
         * Delete 할 IndexName 은 빼야 함.
         * 조회 먼저 해서 TableDic 정보 획득 후 IndexName Array 만
         * 수정해서 Update 해버림.
         ***********************************************/
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );
        sDataObj.mUserData = __gUserData;

        sTableDic = (dbmTableDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);

        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_TABLE], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_SELECT;
        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_TABLE] );
        MK_TBL_KEY( __gUserData, aInstName, aTableName );

        _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );

        for( i=0;i<DBM_MAX_INDEX_PER_TABLE; i++ )
        {
            if ( sTableDic->mIndexName[i][0] != 0x00 )
            {
                if ( ! strcmp_s( sTableDic->mIndexName[i], aIndexName) )
                {
                    memset_s( sTableDic->mIndexName[i], 0x00, DBM_NAME_LEN );
                    break;
                }
            }
        }

        sDataObj.mTransType = DBM_UPDATE;

        _CALL( mTable[sTableIdx]->mUpdate( mTransID, &sDataObj ) );


        /***********************************************
         * 혹시 필요할지 모르니까 조회한 정보는 복사해주자.
         ***********************************************/
        memset_s( &sDataObj, 0x00, sizeof(sDataObj) );
        memset_s( __gUserData, 0x00, sizeof(__gUserData) );
        sDataObj.mUserData = __gUserData;

        sIndexDic = (dbmIndexDic *)(__gUserData + DBM_INDEX_KEY_MAX_SIZE);

        sRC = mGetTableIdx( dbmDicTableName[DBM_DIC_TBL_INDEX], &sTableIdx );
        _IF_THROW( sRC, ERR_DBM_TABLE_NOT_PREPARED );

        sDataObj.mTransType = DBM_SELECT;

        cmnStrCpyZ( sDataObj.mTableName, dbmDicTableName[DBM_DIC_TBL_INDEX] );
        MK_IDX_KEY( __gUserData, aInstID, aTableID, aIndexName );

        _CALL( mTable[sTableIdx]->mSelect( mTransID, &sDataObj, DBM_DIRTY_OFF ) );

        memcpy_s( aIndexDic, sIndexDic, sizeof(dbmIndexDic) );


        /***********************************************
         * 이제 삭제
         ***********************************************/
        sDataObj.mTransType = DBM_DELETE;

        _CALL( mTable[sTableIdx]->mDelete( mTransID, &sDataObj ) );
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/********************************************************************
 * ID : mInitInsert
 *
 * Description
 *   mCreate 직후 dictionary table 정보들을 insert 한다.
 *
 ********************************************************************/
_VOID dbmDictionary::mInitInsert( void*         aInfo,
                                  dbmTransType  aSQLType )
{
    dbmTableInfo*       sTableInfo;
    int                 i;

    _TRY
    {
        switch( aSQLType )
        {
            case DBM_CREATE_INST:
                _CALL( mInsertInstance( ( dbmInstanceDic*)aInfo ) );
                break;

            case DBM_CREATE_TABLE:
                sTableInfo = (dbmTableInfo*)aInfo;
                _IF_THROW( sTableInfo->mColumn.mCount <= 0, RC_FAILURE );

                _CALL( mInsertTable( ( dbmTableDic*)&sTableInfo->mTable, 1) );

                RTF_POINT("DICMGR_INSERT_0");

                for( i=0; i<sTableInfo->mColumn.mCount; i++ )
                {
                    sTableInfo->mColumn.mCols[i].mColumnID = i;
                    sTableInfo->mColumn.mCols[i].mInstID   = sTableInfo->mTable.mInstID;
                    sTableInfo->mColumn.mCols[i].mTableID  = sTableInfo->mTable.mTableID;

                    _CALL( mInsertColumn( ( dbmColumnDic*)&sTableInfo->mColumn.mCols[i] ) );

                    RTF_POINT("DICMGR_INSERT_1");
                }

                /***********************************************
                 * 이 시점에서는 Dictionary Table Segment 의
                 * Table Header 에는 Index 정보가 이미 들어가 있다.
                 * 그래서, 위의 Insert Table 이 성공한 것이다.
                 * 그런데, Index Dictionary Table 에 Index 정보도
                 * insert 해야 하는데 이 때 mInsertIndex 내부에서
                 *
                 * Table 의 mIndexName 정보도 추가하게 되어 Index 가
                 * 2 개인 상황이 발생한다. -- (1)
                 *
                 * mInsertIndex 는 create index 할 때도 함께 사용되기
                 * 때문에 (1) 의 작업을 안할 수도 없다.
                 * 그래서, mInsertIndex 에 두번째 인자를 추가한다.
                 ***********************************************/
                for( i=0; i<(int)sTableInfo->mIndexCount; i++ )
                {
                    _CALL( mInsertIndex( (dbmIndexDic*)&sTableInfo->mIndex[i], 0) );

                    RTF_POINT("DICMGR_INSERT_2");
                }
                break;

            default:
                _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                break;
        }
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mInsert( dbmDicObject*   aObject )
{
    dbmTableInfo*   sTableInfo;
    dbmIndexDic*    sIndexDic;
    dbmEventDic*    sEventDic;
    dbmObjectDic    sObjectDic;
    int             i;

    _TRY
    {
        _CALL( mInitTran() );

        memset_s( &sObjectDic, 0x00, sizeof(sObjectDic));

        switch( aObject->mSQLType )
        {
            case DBM_CREATE_INST:
                _CALL( mInsertInstance( ( dbmInstanceDic*)&aObject->mObj ) );
                _CALL( mDicCommit() );
                break;

            case DBM_CREATE_QUEUE:
            case DBM_CREATE_LIST:
            case DBM_CREATE_DIRECT_TABLE:
            case DBM_CREATE_TABLE:
            case DBM_CREATE_SEQUENCE:
                sTableInfo = (dbmTableInfo*)&aObject->mObj;
                _IF_THROW( sTableInfo->mColumn.mCount <= 0, RC_FAILURE );

                _CALL( mInsertTable( ( dbmTableDic*)&sTableInfo->mTable, 0) );

                cmnStrCpyZ( sObjectDic.mInstName, sTableInfo->mTable.mInstName );
                cmnStrCpyZ( sObjectDic.mObjectName, sTableInfo->mTable.mTableName );

                if ( aObject->mSQLType == DBM_CREATE_LIST )
                {
                    cmnStrCpyZ( sObjectDic.mObjectType, dbmObjectTypeName[DBM_OBJ_LIST]);
                }
                else if ( aObject->mSQLType == DBM_CREATE_QUEUE )
                {
                    cmnStrCpyZ( sObjectDic.mObjectType, dbmObjectTypeName[DBM_OBJ_QUEUE]);
                }
                else if ( aObject->mSQLType == DBM_CREATE_DIRECT_TABLE )
                {
                    cmnStrCpyZ( sObjectDic.mObjectType, dbmObjectTypeName[DBM_OBJ_DIRECT_TABLE]);
                }
                else if ( aObject->mSQLType == DBM_CREATE_SEQUENCE )
                {
                    cmnStrCpyZ( sObjectDic.mObjectType, dbmObjectTypeName[DBM_OBJ_SEQUENCE]);
                }
                else
                {
                    cmnStrCpyZ( sObjectDic.mObjectType, dbmObjectTypeName[DBM_OBJ_TABLE]);
                }

                _CALL( mInsertObject( &sObjectDic ) );

                RTF_POINT("DICMGR_INSERT_0");

                for( i=0; i<sTableInfo->mColumn.mCount; i++ )
                {
                    sTableInfo->mColumn.mCols[i].mColumnID = i;
                    sTableInfo->mColumn.mCols[i].mInstID   = sTableInfo->mTable.mInstID;
                    sTableInfo->mColumn.mCols[i].mTableID  = sTableInfo->mTable.mTableID;

                    _CALL( mInsertColumn( ( dbmColumnDic*)&sTableInfo->mColumn.mCols[i] ) );

                    RTF_POINT("DICMGR_INSERT_1");
                }

                _CALL( mDicCommit() );
                break;

            case DBM_CREATE_INDEX:
                _CALL( mInsertIndex( (dbmIndexDic*)&aObject->mObj, 1) );

                sIndexDic = (dbmIndexDic *)&aObject->mObj;

                memset_s( &sObjectDic, 0x00, sizeof(sObjectDic));

                cmnStrCpyZ( sObjectDic.mInstName, sIndexDic->mInstName );
                cmnStrCpyZ( sObjectDic.mObjectName, sIndexDic->mIndexName );
                cmnStrCpyZ( sObjectDic.mObjectType, dbmObjectTypeName[DBM_OBJ_INDEX] );

                _CALL( mInsertObject( &sObjectDic ) );

                _CALL( mDicCommit() );
                break;

            case DBM_CREATE_TRIG:
                sEventDic = (dbmEventDic *)&aObject->mObj.mEvent;
                /*
                 * TODO.
                 * 현재는 trigger 생성하면 무조건 enable
                 * 향후 개선 때 alter trigger 구문 추가하여 enable/disable 기능 추가.
                 */
                cmnStrCpyZ( sEventDic->mEnableFlag, "ENABLE" );

                _CALL( mInsertTrigger( sEventDic ) );

                memset_s( &sObjectDic, 0x00, sizeof(sObjectDic));

                cmnStrCpyZ( sObjectDic.mInstName, sEventDic->mInstName );
                cmnStrCpyZ( sObjectDic.mObjectName, sEventDic->mTriggerName );
                cmnStrCpyZ( sObjectDic.mObjectType, dbmObjectTypeName[DBM_OBJ_TRIGGER] );

                _CALL( mInsertObject( &sObjectDic ) );
                _CALL( mDicCommit() );
                break;

            default:
                _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                break;
        }

        mFinalTran();
    }

    _CATCH
    {
        mDicRollback();
        mFinalTran();

        _CATCH_ERR;
    }
    _FINALLY
    _END
} /* mInsert */


_VOID dbmDictionary::mDelete( dbmDicObject*   aObject )
{
    dbmTableInfo*   sTableInfo;
    dbmObjectDic    sObjectDic;
    int             i;

    _TRY
    {
        _CALL( mInitTran() );

        switch( aObject->mSQLType )
        {
            case DBM_DROP_INST:
                _CALL( mDeleteInstance( ( dbmInstanceDic*)&aObject->mObj ) );
                _CALL( mDicCommit() );
                break;

            case DBM_DROP_TABLE:
            case DBM_DROP_QUEUE:
            case DBM_DROP_SEQUENCE:
            case DBM_DROP_LIST:

                dbmColumnSetObject* sColumnSet;
                dbmIndexObject*     sIndex;

                sTableInfo = (dbmTableInfo*)&aObject->mObj;
                sColumnSet = &sTableInfo->mColumn;


                /***********************************************
                 * dbmTableObject 정보 조회
                 ***********************************************/
                _CALL( mSelectTable( (dbmTableDic*)&sTableInfo->mTable, 0) );

                RTF_POINT("DICMGR_DELETE_0");


                /***********************************************
                 * dbmColumnSetObject 정보 삭제
                 ***********************************************/
                sColumnSet->mCount = sTableInfo->mTable.mColumnCount;

                for( i=0; i<sColumnSet->mCount; i++ )
                {
                    sColumnSet->mCols[i].mColumnID = i;
                    sColumnSet->mCols[i].mInstID   = sTableInfo->mTable.mInstID;
                    sColumnSet->mCols[i].mTableID  = sTableInfo->mTable.mTableID;

                    mDeleteColumn( ( dbmColumnDic*)&sColumnSet->mCols[i] );

                    RTF_POINT("DICMGR_DELETE_1");
                }


                /***********************************************
                 * dbmIndexObject 정보 삭제
                 ***********************************************/
                sTableInfo->mIndexCount = 0;

                for( i=0;i<DBM_MAX_INDEX_PER_TABLE; i++ )
                {
                    if ( sTableInfo->mTable.mIndexName[i][0] != 0x00 )
                    {
                        sIndex = &sTableInfo->mIndex[sTableInfo->mIndexCount];

                        mDeleteIndex( sTableInfo->mTable.mInstID,
                                      sTableInfo->mTable.mTableID,
                                      sTableInfo->mTable.mInstName,
                                      sTableInfo->mTable.mTableName,
                                      sTableInfo->mTable.mIndexName[i],
                                      (dbmIndexDic *)sIndex );

                        memset_s( &sObjectDic, 0x00, sizeof(sObjectDic));

                        cmnStrCpyZ( sObjectDic.mInstName, sTableInfo->mTable.mInstName );
                        cmnStrCpyZ( sObjectDic.mObjectName, sTableInfo->mTable.mIndexName[i] );

                        mDeleteObject( &sObjectDic );

                        RTF_POINT("DICMGR_DELETE_2");
                    }
                }


                /***********************************************
                 * dbmTableObject 정보 삭제
                 ***********************************************/
                memset_s( &sObjectDic, 0x00, sizeof(sObjectDic));

                cmnStrCpyZ( sObjectDic.mInstName, sTableInfo->mTable.mInstName );
                cmnStrCpyZ( sObjectDic.mObjectName, sTableInfo->mTable.mTableName );

                mDeleteObject( &sObjectDic );

                _CALL( mDeleteTable( ( dbmTableDic*)&sTableInfo->mTable ) );

                RTF_POINT("DICMGR_DELETE_3");

                _CALL( mDicCommit() );
                break;

            case DBM_DROP_INDEX:
                dbmDicObject    sDicObj;

                memset_s( &sDicObj, 0x00, sizeof(dbmDicObject));
                sTableInfo = (dbmTableInfo*)&sDicObj.mObj;

                /***********************************************
                 * index name 으로 table 들을 검색하여 table id 획득
                 ***********************************************/
                _CALL( mGetTableOfIndex( aObject->mObj.mIndex.mInstName,
                                         aObject->mObj.mIndex.mIndexName,
                                         &sDicObj ) );

                _CALL( mInitTran() );


                /***********************************************
                 * dbmIndexObject 정보 삭제
                 ***********************************************/
                memset_s( &sObjectDic, 0x00, sizeof(sObjectDic));

                cmnStrCpyZ( sObjectDic.mInstName, aObject->mObj.mIndex.mInstName );
                cmnStrCpyZ( sObjectDic.mObjectName, aObject->mObj.mIndex.mIndexName );

                mDeleteObject( &sObjectDic );

                _CALL( mDeleteIndex( sTableInfo->mTable.mInstID,
                                     sTableInfo->mTable.mTableID,
                                     sTableInfo->mTable.mInstName,
                                     sTableInfo->mTable.mTableName,
                                     aObject->mObj.mIndex.mIndexName,
                                     (dbmIndexDic*)&aObject->mObj ) );

                _CALL( mDicCommit() );
                break;

            case DBM_DROP_TRIG:
                mDeleteTrigger( ( dbmEventDic*)&aObject->mObj );

                memset_s( &sObjectDic, 0x00, sizeof(sObjectDic));

                cmnStrCpyZ( sObjectDic.mInstName, aObject->mObj.mEvent.mInstName );
                cmnStrCpyZ( sObjectDic.mObjectName, aObject->mObj.mEvent.mTriggerName );

                mDeleteObject( &sObjectDic );

                _CALL( mDicCommit() );
                break;

            default:
                _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                break;
        }

        mFinalTran();       // 여기서 SlotID 중복 Free
    }

    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            mDicRollback();
        }
        mFinalTran();

        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_INFO;
        }
        else
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* mDelete */


_VOID dbmDictionary::mSelect ( dbmDicObject* aObject )
{
    dbmTableInfo*   sTableInfo;
    dbmObjectDic*   sObjectDic;
    int             sFound = 0;
    int             sRC = RC_SUCCESS;
    int             i;

    _TRY
    {
        //TODO: [OKT] ERR_DBM_FETCH_SCN_INVISIBLE 테스트를 metaManager로 수행할때는 막고 수행함.
        //      그런데 이거 select 인데 락잡아야하는겨? dictionary 라서 그런듯 ( dbmDictionary::mSelect )
        _CALL( mInitTran() );

        switch( aObject->mSQLType )
        {
            case DBM_CREATE_INST:
                _CALL( mSelectInstance( ( dbmInstanceDic*)&aObject->mObj, 0 ) );

                /***********************************************
                 * select 할 때도 mAttach 를 통해 Tx 를 잡기
                 * 때문에 해당 Tx 를 해제하려면 조회시마다 commit 을
                 * 하여 잡은 Tx 를 놓아준다.
                 ***********************************************/
                break;

            case DBM_CREATE_QUEUE:
            case DBM_CREATE_LIST:
            case DBM_CREATE_TABLE:
            case DBM_CREATE_DIRECT_TABLE:
            case DBM_CREATE_SEQUENCE:

                dbmIndexObject*     sIndex;
                dbmColumnSetObject* sColumnSet;

                sTableInfo = (dbmTableInfo*)&aObject->mObj;
                sColumnSet = &sTableInfo->mColumn;

                /***********************************************
                 * dbmTableObject 정보 조회
                 * (Inst name 과 table name 만 필요하니 쓰레기
                 *  싹 밀어버리고 두 정보만 남기고 조회)
                 ***********************************************/
                _CALL( mSelectTable ( (dbmTableDic* )&sTableInfo->mTable, 0 ) );

                /***********************************************
                 * dbmColumnSetObject 정보 조회
                 ***********************************************/
                sColumnSet->mCount = sTableInfo->mTable.mColumnCount;

                for( i=0; i<sColumnSet->mCount; i++ )
                {
                    sColumnSet->mCols[i].mColumnID = i;
                    sColumnSet->mCols[i].mInstID   = sTableInfo->mTable.mInstID;
                    sColumnSet->mCols[i].mTableID  = sTableInfo->mTable.mTableID;

                    _CALL( mSelectColumn( ( dbmColumnDic*)&sColumnSet->mCols[i] ) );
                }


                /***********************************************
                 * dbmIndexObject 정보 조회
                 ***********************************************/
                sTableInfo->mIndexCount = 0;

                for( i=0;i<DBM_MAX_INDEX_PER_TABLE; i++ )
                {
                    if ( sTableInfo->mTable.mIndexName[i][0] != 0x00 )
                    {
                        sIndex = &sTableInfo->mIndex[sTableInfo->mIndexCount];

                        _CALL( mSelectIndex( sTableInfo->mTable.mInstID,
                                             sTableInfo->mTable.mTableID,
                                             sTableInfo->mTable.mIndexName[i],
                                             (dbmIndexDic *)sIndex, 0) );

                        sTableInfo->mIndexCount++;
                    }
                }
                break;

            case DBM_CREATE_INDEX:
                dbmDicObject    sDicObj;

                memset_s( &sDicObj, 0x00, sizeof(dbmDicObject));
                sTableInfo = (dbmTableInfo*)&sDicObj.mObj;

                /***********************************************
                 * index name 으로 table 들을 검색하여 table id 획득
                 ***********************************************/
                _CALL( mGetTableOfIndex( aObject->mObj.mIndex.mInstName,
                                         aObject->mObj.mIndex.mIndexName,
                                         &sDicObj) );

                _CALL( mInitTran() );

                /***********************************************
                 * dbmIndexObject 정보 조회
                 ***********************************************/
                _CALL( mSelectIndex( sTableInfo->mTable.mInstID,
                                     sTableInfo->mTable.mTableID,
                                     aObject->mObj.mIndex.mIndexName,
                                     (dbmIndexDic*)&aObject->mObj, 0) );
                break;

            case DBM_CREATE_OBJECT:
                _CALL( mInitTran() );
                _CALL( mSelectObject((dbmObjectDic *)&aObject->mObj) );
                break;

            case DBM_CREATE_TRIG:
                _CALL( mInitTran() );
                _CALL( mSelectTrigger((dbmEventDic *)&aObject->mObj) );
                break;

            default:
                _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                break;
        }

        mFinalTran();
    }

    _CATCH
    {
        mFinalTran();

        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            // (I) .. mSelectTable 2314 ERR-1027] Data not found. ($sys_table) (err=0,tid=27950,l=2304)
            //_CATCH_INFO;
        }
        else
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
}


/********************************************************************
 * ID : mUpdateObjectID
 *
 * Description
 *   Table/Queue 를 Truncate 할 때 ObjectID 를 변경해야할 경우 사용한다.
 *   Dictionary Table 의 관련 정보를 모두 변경한 후 변경결과 TableInfo
 *   정보를 리턴한다.
 *
 ********************************************************************/
_VOID dbmDictionary::mUpdateTableID( dbmDicObject*   aObject )
{
    dbmTableInfo*   sTableInfo;
    int             sFound = 0;
    long long       sOldTableID = -1;
    int             sRC = RC_SUCCESS;
    int             i, j;

    _TRY
    {
        _CALL( mInitTran() );

        switch( aObject->mSQLType )
        {
            case DBM_CREATE_QUEUE:
            case DBM_CREATE_LIST:
            case DBM_CREATE_TABLE:
            case DBM_CREATE_DIRECT_TABLE:
            case DBM_CREATE_SEQUENCE:

                dbmIndexObject*     sIndex;
                dbmColumnSetObject* sColumnSet;

                sTableInfo = (dbmTableInfo*)&aObject->mObj;
                sColumnSet = &sTableInfo->mColumn;

                _CALL( mSelectTable((dbmTableDic*)&sTableInfo->mTable, 0));


                /***********************************************
                 * 새로운 TableID 롤 Update 한다.
                 ***********************************************/
                sOldTableID = sTableInfo->mTable.mTableID;
                sTableInfo->mTable.mTableID = mvpAtomicInc64(&mUndoHeader->mGSCN);

                _CALL( mUpdateTable((dbmTableDic*)&sTableInfo->mTable));

                RTF_POINT("DICMGR_UPDATE_0");


                /***********************************************
                 * Table 의 각 컬럼정보에서 TableID 를 신규값으로
                 * Update 한다.
                 ***********************************************/
                sColumnSet->mCount = sTableInfo->mTable.mColumnCount;

                for( i=0; i<sColumnSet->mCount; i++ )
                {
                    sColumnSet->mCols[i].mColumnID = i;
                    sColumnSet->mCols[i].mInstID   = sTableInfo->mTable.mInstID;
                    sColumnSet->mCols[i].mTableID  = sOldTableID;

                    _CALL( mSelectColumn( ( dbmColumnDic*)&sColumnSet->mCols[i] ) );

                    sColumnSet->mCols[i].mTableID  = sTableInfo->mTable.mTableID;
                    _CALL( mUpdateColumn( sOldTableID, ( dbmColumnDic*)&sColumnSet->mCols[i] ) );

                    RTF_POINT("DICMGR_UPDATE_1");
                }


                /***********************************************
                 * Table 의 각 Index 정보에서 TableID 값을 Update 한다.
                 ***********************************************/
                sTableInfo->mIndexCount = 0;

                for( i=0;i<DBM_MAX_INDEX_PER_TABLE; i++ )
                {
                    if ( sTableInfo->mTable.mIndexName[i][0] != 0x00 )
                    {
                        sIndex = &sTableInfo->mIndex[sTableInfo->mIndexCount];

                        sIndex->mTableID = sOldTableID;

                        _CALL( mSelectIndex( sTableInfo->mTable.mInstID,
                                             sOldTableID,
                                             sTableInfo->mTable.mIndexName[i],
                                             (dbmIndexDic *)sIndex, 0) );

                        sIndex->mTableID = sTableInfo->mTable.mTableID;
                        for(j=0; j<sIndex->mColumnCount; j++)
                        {
                            sIndex->mKey[j].mTableID = sIndex->mTableID;
                        }

                        _CALL( mUpdateIndex( sOldTableID, (dbmIndexDic *)sIndex ) );

                        RTF_POINT("DICMGR_UPDATE_2");

                        sTableInfo->mIndexCount++;
                    }
                }

                _CALL( mDicCommit() );

                /***********************************************
                 * 결국 리턴할 때는 dbmTableInfo 내의 table 정보,
                 * 컬럼정보, 인덱스 정보 내의 TableID 가 신규로
                 * 바뀌어 저장된다.
                 ***********************************************/
                break;

            default:
                _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                break;
        }

        mFinalTran();
    }

    _CATCH
    {
        mDicRollback();
        mFinalTran();

        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_INFO;
        }
        else
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* mUpdateTableID */


/********************************************************************
 * ID : mUpdate
 *
 * Description
 *   dbmDicObject 로 전달되는 정보를 이용해서 Update 수행
 *   (전달되는 정보에 제한이 있기 때문에 general 하게 사용하기는 힘들다.
 *    일단 trigger enable/disable 용도로 사용하고 있는 중)
 *
 ********************************************************************/
_VOID dbmDictionary::mUpdate( dbmDicObject*   aObject )
{
    _TRY
    {
        _CALL( mInitTran() );

        switch( aObject->mSQLType )
        {
            case DBM_CREATE_TRIG:
                _CALL( mUpdateTrigger( (dbmEventDic *)&aObject->mObj.mEvent) );
                _CALL( mDicCommit() );
                break;

            default:
                _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                break;
        }

        mFinalTran();
    }

    _CATCH
    {
        mDicRollback();
        mFinalTran();

        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_INFO;
        }
        else
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* mUpdate */


/********************************************************************
 * ID : mUpdateDiskLogFlag
 *
 * Description
 *   Table 에 대해 Disk Logging 을 안하고 싶을 경우 호출하여 1 로 설정.
 *
 * Arguments
 *   aObject   : dictionary object
 *   aLoggingF : 0(logging) / 1(no-logging)
 *
 ********************************************************************/
_VOID dbmDictionary::mSetDiskNoLogging ( dbmDicObject* aObject , int aNologgingF )
{
    dbmTableInfo*   sTableInfo;
    int             sFound = 0;
    int             sRC = RC_SUCCESS;
    int             i, j;

    _TRY
    {
        _CALL( mInitTran() );

        switch( aObject->mSQLType )
        {
            case DBM_CREATE_QUEUE:
            case DBM_CREATE_LIST:
            case DBM_CREATE_TABLE:
            case DBM_CREATE_DIRECT_TABLE:
            case DBM_CREATE_SEQUENCE:

                sTableInfo = (dbmTableInfo*)&aObject->mObj;

                _CALL( mSelectTable((dbmTableDic*)&sTableInfo->mTable, 0));


                /***********************************************
                 * $sys_table 의 nologging_flag 값을 변경하여 갱신
                 ***********************************************/
                sTableInfo->mTable.mNologgingF = aNologgingF;

                _CALL( mUpdateTable((dbmTableDic*)&sTableInfo->mTable));

                _CALL( mDicCommit() );
                break;

            default:
                _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                break;
        }

        mFinalTran();
    }

    _CATCH
    {
        mDicRollback();
        mFinalTran();

        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_INFO;
        }
        else
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* mSetDiskNoLogging */


/********************************************************************
 * ID : mUpdateMemLogFlag
 *
 * Description
 *   Table 에 대해 Memory Logging 을 안하고 싶을 경우 호출하여 1 로 설정.
 *
 * Arguments
 *   aObject   : dictionary object
 *   aLoggingF : 0(logging) / 1(no-logging)
 *
 ********************************************************************/
_VOID dbmDictionary::mSetMemNoLogging ( dbmDicObject* aObject , int aNologgingF )
{
    dbmTableInfo*   sTableInfo;
    int             sFound = 0;
    int             sRC = RC_SUCCESS;
    int             i, j;

    _TRY
    {
        _CALL( mInitTran() );

        switch( aObject->mSQLType )
        {
            case DBM_CREATE_QUEUE:
            case DBM_CREATE_TABLE:
            case DBM_CREATE_DIRECT_TABLE:

                sTableInfo = (dbmTableInfo*)&aObject->mObj;

                _CALL( mSelectTable((dbmTableDic*)&sTableInfo->mTable, 0));


                /***********************************************
                 * $sys_table 의 nologging_flag 값을 변경하여 갱신
                 ***********************************************/
                sTableInfo->mTable.mNoMemloggingF = (short)aNologgingF;

                _CALL( mUpdateTable((dbmTableDic*)&sTableInfo->mTable));

                _CALL( mDicCommit() );
                break;

            default:
                _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                break;
        }

        mFinalTran();
    }

    _CATCH
    {
        mDicRollback();
        mFinalTran();

        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_INFO;
        }
        else
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* mSetMemNoLogging */


/********************************************************************
 * ID : mGetFirst
 *
 * Description
 *   조건을 만족하는 첫번째 Row 를 검색한다는 것 이외에는
 *   mSelect 와 다를 것이 없음. (Table Manager 의 mSelectGT 이용)
 *
 ********************************************************************/
_VOID dbmDictionary::mGetFirst( dbmDicObject* aObject )
{
    int             i;
    dbmTableInfo*   sTableInfo;
    char            sInstName[DBM_NAME_LEN];

    _TRY
    {
        _CALL( mInitTran() );

        switch( aObject->mSQLType )
        {
            case DBM_CREATE_INST:
                /***********************************************
                 * mSelectGT 를 이용하여 sys_instance 에서 첫번째
                 * Row 를 조회
                 ***********************************************/
                ((dbmInstanceDic*)&aObject->mObj.mInstance)->mInstanceName[0] = '\0';
                _CALL( mSelectInstance( ( dbmInstanceDic*)&aObject->mObj.mInstance, 1 ) );
                break;

            case DBM_CREATE_QUEUE:
            case DBM_CREATE_LIST:
            case DBM_CREATE_TABLE:
            case DBM_CREATE_DIRECT_TABLE:
            case DBM_CREATE_SEQUENCE:

                dbmIndexObject*     sIndex;
                dbmColumnSetObject* sColumnSet;

                sTableInfo = (dbmTableInfo*)&aObject->mObj;
                sColumnSet = &sTableInfo->mColumn;

                /***********************************************
                 * dbmTableObject 정보 조회
                 * ($sys_dic_inst 의 __sys_table 에 있는 정보들만 보여주면 됨)
                 ***********************************************/
                //cmnStrCpyZ( sTableInfo->mTable.mTableName, "0" );
                sTableInfo->mTable.mTableName[0] = '\0';

                _CALL( mSelectTable((dbmTableDic*)&sTableInfo->mTable, 1));


                /***********************************************
                 * dbmColumnSetObject 정보 조회
                 ***********************************************/
                sColumnSet->mCount = sTableInfo->mTable.mColumnCount;

                for( i=0; i<sColumnSet->mCount; i++ )
                {
                    sColumnSet->mCols[i].mColumnID = i;
                    sColumnSet->mCols[i].mInstID   = sTableInfo->mTable.mInstID;
                    sColumnSet->mCols[i].mTableID  = sTableInfo->mTable.mTableID;

                    _CALL( mSelectColumn( ( dbmColumnDic*)&sColumnSet->mCols[i] ) );
                }


                /***********************************************
                 * dbmIndexObject 정보 조회
                 ***********************************************/
                sTableInfo->mIndexCount = 0;

                for( i=0;i<DBM_MAX_INDEX_PER_TABLE; i++ )
                {
                    if ( sTableInfo->mTable.mIndexName[i][0] != 0x00 )
                    {
                        sIndex = &sTableInfo->mIndex[sTableInfo->mIndexCount];

                        _CALL( mSelectIndex( sTableInfo->mTable.mInstID,
                                             sTableInfo->mTable.mTableID,
                                             sTableInfo->mTable.mIndexName[i],
                                             (dbmIndexDic *)sIndex, 1) );

                        sTableInfo->mIndexCount++;
                    }
                }
                break;

            case DBM_CREATE_INDEX:
                dbmDicObject    sDicObj;
                sTableInfo = (dbmTableInfo*)&sDicObj.mObj;

                /***********************************************
                 * dbmTableObject 정보 조회
                 ***********************************************/
                memcpy_s( sTableInfo->mTable.mInstName,
                          aObject->mObj.mIndex.mInstName,
                          DBM_NAME_LEN );

                memcpy_s( sTableInfo->mTable.mTableName,
                          aObject->mObj.mIndex.mTableName,
                          DBM_NAME_LEN );

                _CALL( mSelectTable((dbmTableDic*)&sTableInfo->mTable, 0));


                /***********************************************
                 * dbmIndexObject 정보 조회
                 ***********************************************/
                aObject->mObj.mIndex.mIndexName[0] = '0';

                _CALL( mSelectIndex( sTableInfo->mTable.mInstID,
                                     sTableInfo->mTable.mTableID,
                                     aObject->mObj.mIndex.mIndexName,
                                     (dbmIndexDic*)&aObject->mObj, 1) );
                break;

            default:
                _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                break;
        }

        mFinalTran();
    }

    _CATCH
    {
        mFinalTran();

        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* mGetFirst */


_VOID dbmDictionary::mGetNext ( dbmDicObject* aObject )
{
    dbmTableInfo*   sTableInfo;
    int             i;

    _TRY
    {
        _CALL( mInitTran() );

        switch( aObject->mSQLType )
        {
            case DBM_CREATE_INST:
                _CALL( mSelectInstance( ( dbmInstanceDic*)&aObject->mObj, 1 ) );
                break;

            case DBM_CREATE_QUEUE:
            case DBM_CREATE_TABLE:
            case DBM_CREATE_DIRECT_TABLE:

                dbmIndexObject*     sIndex;
                dbmColumnSetObject* sColumnSet;

                sTableInfo = (dbmTableInfo*)&aObject->mObj;
                sColumnSet = &sTableInfo->mColumn;

                /***********************************************
                 * dbmTableObject 정보 조회
                 * ($sys_dic_inst 의 __sys_table 에 있는 정보들만 보여주면 됨)
                 ***********************************************/
                _CALL( mSelectTable((dbmTableDic*)&sTableInfo->mTable, 1));


                /***********************************************
                 * dbmColumnSetObject 정보 조회
                 ***********************************************/
                sColumnSet->mCount = sTableInfo->mTable.mColumnCount;

                for( i=0; i<sColumnSet->mCount; i++ )
                {
                    sColumnSet->mCols[i].mColumnID = i;
                    sColumnSet->mCols[i].mInstID   = sTableInfo->mTable.mInstID;
                    sColumnSet->mCols[i].mTableID  = sTableInfo->mTable.mTableID;

                    _CALL( mSelectColumn( ( dbmColumnDic*)&sColumnSet->mCols[i] ) );
                }


                /***********************************************
                 * dbmIndexObject 정보 조회
                 ***********************************************/
                sTableInfo->mIndexCount = 0;

                for( i=0;i<DBM_MAX_INDEX_PER_TABLE; i++ )
                {
                    if ( sTableInfo->mTable.mIndexName[i][0] != 0x00 )
                    {
                        sIndex = &sTableInfo->mIndex[sTableInfo->mIndexCount];

                        _CALL( mSelectIndex( sTableInfo->mTable.mInstID,
                                             sTableInfo->mTable.mTableID,
                                             sTableInfo->mTable.mIndexName[i],
                                             (dbmIndexDic *)sIndex, 1) );

                        sTableInfo->mIndexCount++;
                    }
                }
                break;

            case DBM_CREATE_INDEX:
                dbmDicObject    sDicObj;
                sTableInfo = (dbmTableInfo*)&sDicObj.mObj;

                /***********************************************
                 * dbmTableObject 정보 조회
                 ***********************************************/
                memcpy_s( sTableInfo->mTable.mInstName,
                          aObject->mObj.mIndex.mInstName,
                          DBM_NAME_LEN );

                memcpy_s( sTableInfo->mTable.mTableName,
                          aObject->mObj.mIndex.mTableName,
                          DBM_NAME_LEN );

                _CALL( mSelectTable((dbmTableDic*)&sTableInfo->mTable, 0));


                /***********************************************
                 * dbmIndexObject 정보 조회
                 ***********************************************/
                _CALL( mSelectIndex( sTableInfo->mTable.mInstID,
                                     sTableInfo->mTable.mTableID,
                                     aObject->mObj.mIndex.mIndexName,
                                     (dbmIndexDic*)&aObject->mObj, 1) );
                break;

            default:
                _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                break;
        }

        mFinalTran();
    }

    _CATCH
    {
        mFinalTran();

        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* mGetNext */


_VOID dbmDictionary::mCheck()
{
    dbmSegmentManager*  sUndoSegMgr = NULL;
    char                sFileName  [256];
    char*               sPtr;
    int                 sFD;
    int                 sMode = -1;
    int                 sRC;

    _TRY
    {
        //TODO: 2014.12.14. -okt- not yet supported - 현재는 복구용 Dictionary File 지원 안하므로 그냥 성공으로 (확인요)
        return RC_SUCCESS;

        sMode = umask(0x00);        // 777 모드로 오픈하기 위해 umask 필요.

        sprintf ( sFileName, "%s/dic/system_dictionary-%d", getenv ( ENV_DBM_HOME ), 0 );

        sFD = open ( sFileName, O_RDWR, _cmn_file_mode );
        if ( sFD <= 0 )
        {
            _rc = ERR_DBM_NO_DIC_FILE;
            DBM_WARN( "[DIC] file open fail. rc=%d, (%s) (err=%d)", _rc, sFileName, errno );
            _THROW( _rc );
        }
        close_s(sFD);

        _IF_THROW( dbmSegmentManager::Attach(SYS_INST_NAME, SYS_INST_NAME, &sUndoSegMgr ),
                   ERR_DBM_NO_DIC_SHM );

#ifndef USE_NEW_SHM_NODETACH
        sUndoSegMgr->Detach();
#endif
        delete_s( sUndoSegMgr );
    }

    _CATCH
    {
        if ( _rc != ERR_DBM_NO_DIC_FILE )
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    {
        if ( sMode != -1 )
        {
            (void) umask ( sMode );     // 기존 umask 설정으로 원복.
        }
    }
    _END
} /* mCheck */


_VOID dbmDictionary::mRecover()
{
    return RC_SUCCESS;
}

_VOID dbmDictionary::mInitObject ( )
{
    _TRY
    {
        mTransID = -1;
        mTransHeader = NULL;

        mTxTable = NULL;
        mUndoHeader = NULL;

        mTableCount = 0;
        for ( int i = 0; i < DBM_DIC_TBL_MAX; i++ )
        {
            delete_s( mTable[i] );
        }

        delete_s( mUndoSegMgr );
        delete_s( mLogMgr );
        delete_s( mLockMgr );
        delete_s( mDeadLockMgr );
    }
    _CATCH
    _FINALLY
    _END
}

void dbmDictionary::mPrintAll()
{
    // 미구현인듯.
}


inline void dbmDictionary::MK_INST_KEY( char* v, char* inst_name )
{
    char    v1[DBM_INDEX_KEY_MAX_SIZE+1];

    memset_s ( v1, 0x00, sizeof( v1 ) );
    snprintf( v1,
              DBM_INDEX_KEY_MAX_SIZE+1,
              "%-32s%-32s",
              inst_name,
              inst_name );

    memcpy_s( v, v1, DBM_INDEX_KEY_MAX_SIZE );
}

inline void dbmDictionary::MK_TBL_KEY( char* v, char* inst_name, char* table_name)
{
    char    v1[DBM_INDEX_KEY_MAX_SIZE+1];

    memset_s ( v1, 0x00, sizeof( v1 ) );
    snprintf( v1,
              DBM_INDEX_KEY_MAX_SIZE+1,
              "%-32s%-32s",
              inst_name,
              table_name );

    memcpy_s( v, v1, DBM_INDEX_KEY_MAX_SIZE );
}

inline void dbmDictionary::MK_IDX_KEY( char* v, long long instid, long long tblid, char* index_name)
{
    char    v1[DBM_INDEX_KEY_MAX_SIZE+1];

    memset_s ( v1, 0x00, sizeof( v1 ) );
    snprintf( v1,
              DBM_INDEX_KEY_MAX_SIZE+1,
              "%-16lld%-16lld%-32s",
              instid,
              tblid,
              index_name);

    memcpy_s( v, v1, DBM_INDEX_KEY_MAX_SIZE );
}

inline void dbmDictionary::MK_COL_KEY( char* v, long long instid, long long tblid, int col_id)
{
    char    v1[DBM_INDEX_KEY_MAX_SIZE+1];

    memset_s ( v1, 0x00, sizeof( v1 ) );
    snprintf( v1,
              DBM_INDEX_KEY_MAX_SIZE+1,
              "%-16lld%-16lld%-32d",
              instid,
              tblid,
              col_id );

    memcpy_s( v, v1, DBM_INDEX_KEY_MAX_SIZE );
}

_VOID dbmDictionary::mGetLogPtr ( dbmSegmentManager* aSegMgr , long long aLogPos , void* aLogPtr /* char** aLogPtr */ )
{
    char*   sTmp = NULL;
    int     sRC;

    sRC = aSegMgr->Slot2Addr ( SLOTID( aLogPos ), &sTmp );
    // 2014.11.18. -okt- 성능구간 중복검사 제거
    if ( unlikely( sRC ) ) //|| sTmp == NULL )
    {
        return( -2 );
    }

    *(dbmLogHeader**)aLogPtr = GETLOG ( sTmp, OFFSET ( aLogPos ) );

    return 0;
}

_VOID dbmDictionary::mGetImagePtr ( dbmSegmentManager* aSegMgr , long long aImagePos , void* aImagePtr /* char** aImagePtr */ )
{
    char*   sTmp = NULL;
    int     sRC;

    // 2014.11.18. -okt- 성능구간 중복검사 제거
    sRC = aSegMgr->Slot2Addr ( SLOTID ( aImagePos ), &sTmp );
    if ( unlikely( sRC ) ) //|| sTmp == NULL )
    {
        return( -2 );
    }

    *(dbmRowHeader**)aImagePtr = GETIMG ( sTmp, OFFSET ( aImagePos ) );

    return 0;
}

void dbmDictionary::mInitTransItem( int               aTransID,
                                    dbmTransHeader*   aHeader,
                                    long long         aSessionID,
                                    int               aUserID,
                                    int               aPID,
                                    dbmTxStatus       aStatus,
                                    int               aSlotSize)
{
    dbmTransHeader  sInitTransH;

    _TRY
    {
        memset_s( &sInitTransH, 0x00, sizeof(dbmTransHeader) );

        sInitTransH.mMyTxID    = aTransID;
        sInitTransH.mSessionID = aSessionID;
        sInitTransH.mUserID    = aUserID;
        sInitTransH.mStatus    = aStatus;
        sInitTransH.mPID       = aPID;

        sInitTransH.mLastAllocLogSlot   = -1;
        sInitTransH.mLastAllocImageSlot = -1;

        sInitTransH.mLogCntPerSlot =
            ( aSlotSize - sizeof(dbmLogSlotHeader) ) / sizeof(dbmLogHeader);

        sInitTransH.mImageCntPerSlot =
            ( aSlotSize - sizeof(dbmLogSlotHeader) ) / ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );

        sInitTransH.mLogStartPos      = MK_POS(-1,-1);
        sInitTransH.mImageStartPos    = MK_POS(-1,-1);
        sInitTransH.mLogCurPos        = MK_POS(-1,-1);
        sInitTransH.mImageCurPos      = MK_POS(-1,-1);
        sInitTransH.mRecoveryStartPos = MK_POS(-1,-1);
        sInitTransH.mLockRecoveryPos  = MK_POS(-1,-1);

        memcpy_s( aHeader, &sInitTransH, sizeof(dbmTransHeader) );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _ENDVOID
}

void dbmDictionary::mInitLogSlot ( dbmLogSlotHeader* aSlot , long long aSlotID )
{
    aSlot->mMySlotID = aSlotID;
    aSlot->mNext = -1;
    aSlot->mPrev = -1;
}


_VOID dbmDictionary::mGetTableOfIndex ( char* aInstName , char* aIndexName , dbmDicObject* aDicObj )
{
    int             sFound = 0;
    dbmTableInfo*   sTableInfo = NULL;
    int             sRC = RC_SUCCESS;
    int             i;

    _TRY
    {
        sTableInfo = (dbmTableInfo*)&aDicObj->mObj;

        /***********************************************
         * dbmTableObject 정보 조회
         * (inst id, table id 획득)
         * Drop Index 등을 수행할 때는 aObject.mObj 에
         * TableName 이 설정 안되어 있을 수도 있다.
         * 그래서, 해당 Index Name 을 가진 Table 을 먼저
         * 찾아야 한다. 이는 SelectIndex 에서 사용할
         * Key 에 TableID 가 필요하기 때문이다.
         * Table 별로 같은 Index 이름을 가질 수 있도록 하려니
         * 아래처럼 Table 을 다 뒤져봐야 함.
         ***********************************************/
        memcpy_s( sTableInfo->mTable.mInstName,
                  aInstName,
                  DBM_NAME_LEN );

        aDicObj->mSQLType = DBM_CREATE_TABLE;
        _CALL( mGetFirst( aDicObj ) );

        for( i=0; i<DBM_MAX_INDEX_PER_TABLE; i++ )
        {
            if ( sTableInfo->mTable.mIndexName[i][0] != 0x00 )
            {
                if ( ! strcmp_s( sTableInfo->mTable.mIndexName[i], aIndexName) )
                {
                    sFound = 1;
                    break;
                }
            }
        }

        if ( sFound != 1 )
        {
            while(1)
            {
                memset_s( sTableInfo->mTable.mIndexName,
                        0x00,
                        sizeof(sTableInfo->mTable.mIndexName) );

                sRC = mGetNext( aDicObj );
                if ( sRC ) break;

                for( i=0; i<DBM_MAX_INDEX_PER_TABLE; i++ )
                {
                    if ( sTableInfo->mTable.mIndexName[i][0] != 0x00 )
                    {
                        if ( ! strcmp_s( sTableInfo->mTable.mIndexName[i], aIndexName) )
                        {
                            sFound = 1;
                            break;
                        }
                    }
                }

                if ( sFound == 1 )
                {
                    break;
                }
            }
        }

        _IF_THROW( sFound == 0, ERR_DBM_NO_MATCH_RECORD );
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mFinalTran ( int aTxID )
{
    dbmTransHeader* sTxHead = NULL;

    _TRY
    {
        /***********************************************
         * Transaction 에 할당된 모든 slot 반납 및
         * Tx Header 초기화
         ***********************************************/
        sTxHead = (dbmTransHeader*) ( &mTxTable->mItem[aTxID] );

        if ( sTxHead != NULL )
        {
            if ( sTxHead->mStatus != DBM_TX_FREE )
            {
                DBM_INFO( "[DIC] Final Trans. txid[%d]", aTxID );

                _CALL( mLogMgr->mFreeAllSlotList ( 1, mUndoSegMgr, (dbmTransHeader*) sTxHead ) );
                _CALL( mClearTransItem ( (dbmTransHeader*) sTxHead ) );
            }
            else
            {
                if ( SLOTID ( sTxHead->mLogCurPos ) < 0 )
                {
                    /***********************************************
                     * InitTran 에서 TxHead 에 PID 만 박아놓고
                     * 아무 것도 못하고 죽었을 경우는 그냥
                     * TxHead 를 Clear 시켜버린다.
                     ***********************************************/
                    _CALL( mClearTransItem ( (dbmTransHeader*) sTxHead ) );
                }
            }
        }
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}

_VOID dbmDictionary::mFinalTran()
{
    _TRY
    {
        /***********************************************
         * Transaction 에 할당된 모든 slot 반납 및
         * Tx Header 초기화
         ***********************************************/
        if ( mTransID >= 0 )
        {
            DBM_DBG2( "[DIC] Final My Trans. txid[%d]", mTransID );

            _CALL( mLogMgr->mFreeAllSlotList ( 0, mUndoSegMgr, (dbmTransHeader*) mTransHeader ) );
            _CALL( mClearTransItem ( (dbmTransHeader*) mTransHeader ) );

            _CALL( mUnlock ( mTransID ) );

            mTransID = -1;
            mTransHeader = NULL;
        }
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mClearTransItem( dbmTransHeader* aHeader )
{
    dbmTransHeader  sClearTransH;

    _TRY
    {
        DBM_DBG2( "[DIC] Clear Trans Header. txid[%d]", aHeader->mMyTxID );

        memset_s( &sClearTransH, 0x00, sizeof(dbmTransHeader) );

        /*
         *  2014.12.14. -okt- 복구하던 놈이, 자기 TxID를 박고 죽으면, mPID가 -1로 남아서, dbmLockManager::mSpinLock에서 해제를 못함. (2014/06/24)
         * 때문에 '0'으로 변경하니.
         * (E)21:01:39.471156 23848 dbmIndexManager    mInsertCheck 3904 index Curr State ERROR Index Rebulid Request !!! step [1] lock[3]
         * 오류가 발생하여, 다시 -1로 원복.
         */
        sClearTransH.mPID        = -1;
//      sClearTransH.mPID        = 0;       // 더미코드이나 반드시 '0'이라는 것을 기억하기위한 코드

        sClearTransH.mMyTxID     = -1;
        sClearTransH.mStatus     = DBM_TX_FREE;

        sClearTransH.mLastAllocLogSlot   = -1;
        sClearTransH.mLastAllocImageSlot = -1;

        sClearTransH.mLogStartPos      = MK_POS(-1,-1);
        sClearTransH.mImageStartPos    = MK_POS(-1,-1);
        sClearTransH.mLogCurPos        = MK_POS(-1,-1);
        sClearTransH.mImageCurPos      = MK_POS(-1,-1);
        sClearTransH.mRecoveryStartPos = MK_POS(-1,-1);

        sClearTransH.mWaitForObjectID = -1;
        sClearTransH.mWaitForSlotID = -1;
        sClearTransH.mWaitForTransID = -1;

        memcpy_s( aHeader, &sClearTransH, sizeof(dbmTransHeader) );
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mGetIndexKeyColumnInfo ( dbmIndexObject* aParseIndex , dbmTableInfo* aDicTableInfo , int* aKeySize )
{
    int     i, j;

    _TRY
    {
        *aKeySize = 0;

        for ( i = 0; i < aParseIndex->mColumnCount; i++ )
        {
            for ( j = 0; j < aDicTableInfo->mColumn.mCount; j++ )
            {
                if ( strcmp_s( aParseIndex->mKey[i].mColumnName,
                              aDicTableInfo->mColumn.mCols[j].mColumnName) == 0)
                {
                    memcpy_s( &aParseIndex->mKey[i],
                              &aDicTableInfo->mColumn.mCols[j], sizeof(dbmColumnObject) );

                    *aKeySize += aDicTableInfo->mColumn.mCols[j].mSize;
                    break;
                }
            }

            if ( j >= aDicTableInfo->mColumn.mCount )
            {
                _THROW( RC_FAILURE );
            }
        }
    }

    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mLock( int aMyTxID )
{
    int     sOldTID;
    int     sOldPID;
    int     sMyPID;
    int     sRC;

    _TRY
    {
        DBM_DBG2( "[DIC] Lock Start. mOldTID[%d] -> TxID[%d]", mUndoHeader->mLock, aMyTxID );

        sMyPID = gettid_s();
        while ( 1 )
        {
            sOldTID = mvpAtomicCas32 ( &mUndoHeader->mLock, aMyTxID, DBM_NOT_USED );
            if ( sOldTID  == DBM_NOT_USED || sOldTID == aMyTxID )
            {
                /* success */
                break;
            }

            sOldPID = mvpAtomicGet32( &((dbmTransHeader*)(&mTxTable->mItem[sOldTID]))->mPID );

            if ( sOldPID > 0 )
            {
                /***********************************************
                 * 누가 Lock 을 잡고 있는데 Process 가 죽었는지 검사.
                 * 죽어 있으면 해당 Tx 를 검사하여 복구해버린다.
                 ***********************************************/
                //if ( tkill_s ( ( (dbmTransHeader*) ( &mTxTable->mItem[sOldTID] ) )->mPID, 0 ) && errno == ESRCH )
                if ( sOldPID == sMyPID || ( tkill_s ( sOldPID, 0 ) && errno == ESRCH ) )
                {
                    /* old process down */
                    sRC = mvpAtomicCas32 ( &mUndoHeader->mLock, aMyTxID, sOldTID );
                    if ( sRC == sOldTID )
                    {
                        _CALL ( mDicRollbackRecovery( sOldTID ) );
                        mFinalTran( sOldTID );
                    }
                }
            }
            else
            {
                /***********************************************
                 * undo header 는 Lock 잡힌 상태이지만 TxHeader 는 초기화되었다.
                 * (Lock 만 잡고 InitTran 은 못한 상태이거나,
                 *  FinalTran 은 했는데 Unlock 은 못하고 죽은 경우)
                 ***********************************************/
                mvpAtomicCas32 ( &mUndoHeader->mLock, aMyTxID, sOldTID );
                continue;
            }
        }

        DBM_DBG2( "[DIC] Lock End. OldTID[%d] -> TxID[%d]", sOldTID, aMyTxID );
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

_VOID dbmDictionary::mUnlock( int aMyTxID )
{
    int     sOldTID;

    _TRY
    {
        DBM_DBG2( "[DIC] Unlock Start. TxID[%d]", aMyTxID );

        sOldTID = mvpAtomicCas32 ( &mUndoHeader->mLock, -1, aMyTxID );
        if ( sOldTID == -1 || sOldTID == aMyTxID )
        {
            /*
             * mLock 값은 아래 로그를 찍기 전에 이미 다른 값으로 바뀌었을 수 있음.
             * (다른 tx 가 lock 을 잡았다면)
             */
            DBM_DBG2( "[DIC] Unlock End. TxID[%d] OldTID[%d] -> mLock[%d]", aMyTxID, sOldTID, mUndoHeader->mLock );
            _RETURN;
        }
        else
        {
            DBM_DBG( "[DIC] mUndoHeader->mLock=%d (%d), myTx=%d (err=%d,tid=%d)", mUndoHeader->mLock, sOldTID, aMyTxID, errno, gettid_s() );

            // 2014.09.20 -okt- 락을 안잡고 호출하는 코드가 남아 있다. 일단 성공 리턴.
//            if ( sOldTID != aMyTxID )
//            {
//                _DASSERT( 0 );
//            }

            //_THROW( RC_FAILURE );
            _RETURN;
        }
    }

    _CATCH
    {
        //_CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mSetIndex( char* aTableName, char* aIndexName )
{
    int     sTIdx = -1;
    int     sUseIndex;
    int     sRC;

    _TRY
    {
        sRC = mFindTableInTx( aTableName, &sTIdx );
        if ( unlikely( sRC != 0 ) ) // || sTIdx < 0 ) //, NOT_EXIST );
        {
            DBM_INFO( "Find dictionary table(%s) fail. rc=%d", aTableName, sRC );
            _THROW( ERR_DBM_TABLE_NOT_PREPARED );
        }

        sRC = mFindIndexInTbl(mTable[sTIdx], aIndexName, &sUseIndex );
        if ( unlikely( sRC != 0 ) ) //, INDEX_NOT_EXIST );
        {
            DBM_INFO( "Find index(%s) in dictionary table(%s) fail. rc=%d", aIndexName, aTableName, sRC );
            _THROW( ERR_DBM_INDEX_NOT_PREPARED );
        }

        mTable[sTIdx]->mSetUseIndex( sUseIndex );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmDictionary::mFindIndexInTbl ( dbmTableManager* aTable , char* aIndexName , int* aIdx )
{
    for ( int i = 0; i < aTable->mGetIndexCount ( ); i++ )
    {
        if ( !strcmp_s ( aTable->mGetIndexMgrByIdx(i)->mGetIndexName(), aIndexName ) )
        {
            *aIdx = i;
            return ( RC_SUCCESS );
        }
    }

    return ( RC_FAILURE );
}


_VOID dbmDictionary::mFindTableInTx( char* aTableName, int* aTableIdx )
{
    for ( int i = 0; i < mTableCount; i++ )
    {
        if ( strcmp_s ( mTable[i]->mTableName, aTableName ) == 0 )
        {
            *aTableIdx = i;
            return( RC_SUCCESS );
        }
    }

    return( RC_FAILURE );
}
