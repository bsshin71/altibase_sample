/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
 *   dbmListManager 의 멤버함수 구현
 ******************************************************************************/

#include "dbmHeader.h"
//#include "dbmListManager.h"


/******************************************************************************
 * Name : dbmListManager()
 *
 * Description
 *     destructor
 *
 ******************************************************************************/
dbmListManager::dbmListManager( )
{
    memset_s( mListName, 0x00, DBM_NAME_LEN );
    memset_s( mInstName, 0x00, DBM_NAME_LEN );

    mListHeader = NULL;

    mSegMgr  = NULL;
    mLogMgr  = NULL;
    mLockMgr = NULL;
    mTransLogger = NULL;

    mTableID = -1;
//    mListTotalCount = -1;
//    mListLeftStart  = -1;
//    mListLeftLast   = -1;
//    mListRightStart = -1;
//    mListRightLast  = -1;
}


/******************************************************************************
 * Name : ~dbmListManager
 *
 * Description
 *     destructor
 *
 ******************************************************************************/
dbmListManager::~dbmListManager( )
{
    if ( mSegMgr != NULL )
    {
#ifndef USE_NEW_SHM_NODETACH
        mSegMgr->Detach () ;
#endif
        delete mSegMgr;
        mSegMgr = NULL;
    }
}

/******************************************************************************
 * Name : dbmListManager
 *
 * Description
 *     prepare 처리 시 list 정보를 채운다.
 *
 * Argument
 *     aInstName      : input   : Instance name
 *     aListName      : input   : List name
 *     dbmDicObject   : input   : dic info
 *     dbmLogManager  : input   : log info
 *     dbmLockManager : input   : lock info
 ******************************************************************************/
_VOID dbmListManager::mInitList( char*              aInstName,
                                 char*              aListName,
                                 dbmDicObject*      aDicObject,
                                 dbmLogManager*     aLogMgr,
                                 dbmLockManager*    aLockMgr )
{

    dbmTableInfo*   sDicTableInfo = NULL;

    _TRY
    {
        sDicTableInfo = &aDicObject->mObj.mTableInfo;

        memset_s( mListName, 0x00, DBM_NAME_LEN );
        memset_s( mInstName, 0x00, DBM_NAME_LEN );

        strncpy_s( mInstName, aInstName, sizeof(mInstName) );
        strncpy_s( mListName, aListName, sizeof(mListName) );


        /* list attach:
         * list segmenet attach process */
         _CALL( dbmSegmentManager::AttachList(mInstName, mListName, &mSegMgr) );


         /* list user attach:
          * list table user pointer attach */
         mListHeader = (dbmListHeader *)mSegMgr->GetUserHeader();
         _IF_THROW( mListHeader->mInitCompleteF != 1, ERR_DBM_INVALID_HEADER );

         /* tablie setting:
          * list create시 생성된 talbe id로 golbal mTableID setting */
         mTableID = mListHeader->mTableObj.mTableID;

         /* dictionary info check :
          */
         if( strcmp_s( sDicTableInfo->mTable.mTableName, mListHeader->mTableObj.mTableName ) )
         {
             DBM_ERR( "LIST (%s) header info and dictionary info does not match.", aListName );
             _THROW( ERR_DBM_HEAD_DIC_INFO_NOT_MATCH );
         }

        mLogMgr = aLogMgr;
        mLockMgr = aLockMgr;


        /* 변수 초기화 :
         */
        //mListTotalCount = -1;
        //mListLeftStart  = -1;
        //mListLeftLast   = -1;
        //mListRightStart = -1;
        //mListRightLast  = -1;

    }
    _CATCH
    {
        _CATCH_ERR;

    }
    _FINALLY
    _END


}

__thread char* g_pBuffer_mPush = NULL;

/******************************************************************************
 * Name : mListExtend
 *
 * Description
 * 내가 사용하려고 할 segment manager 번호를 추출 한다.
 *
 * Argument
 *     aAllocSlot : input : 처리 하려고 하는 slot no.
 *
 ******************************************************************************/
_VOID dbmListManager::mListExtend(long long aAllocSlot)
{
    int sRC;
    dbmTableObject* sTableObj = &mListHeader->mTableObj;

    _TRY
    {
        /* segment extend diff:
           처음에는 0이 올거야 또는 처음에는 100이 올거야 어떻게 구분을 하면 될까...

           - Max Slot은 알고 있다. (sTableObj->mMaxSize)

           -  (sAllocSlot > mHeader->mInitSlotCount + mHeader->mExtendSlotCount * ( mHeader->mSegmentCount - 1 ) ) - 1
              조건 : initCount 10 + extend 10  + Max 100X_SEGMENT_COUNT
              처음 생성 시
                 10          10         1
              ( initSlot + ( Extned * ( SegmentCount -1 ) ) ) - 1
              --> ( 10 + ( 10 * (1-1) ) ) -1 --> ( 10 + (0) ) -1 --> 10

            - 10 --> segemnt 1번
              100 -> segment 10번
              MazSize / 10 = 몇개가 나올지 알 수 있다.  -> 100 / 10 = 10 segment10개까지 올 수 있다.
              semgnet MAX MAX_SEGMENT_COUNT(1024 512에서 바꼈음)

            - example
              MAX - sAllocSlot = VALUE / INIT = EXTEND - VALUE = VALUE( 몇번째 segment 사용할지 알 수 있다. )

              100 - 15 = 85 / 10 = 10 - 8 = 2 2번째 segment 사용 해라.
              100 - 10 = 90 / 10 = 10 - 9 = 1 1번째 segment 사용 해라.
              100 - 100 = 0 / 10 = 10 - 0 = 10 10번째 segment 사용 해라.

              여기에서의 공식 의미
              sAllotSlot은 --> 개수를 의미 sAllotSlot 0 으로 온다면  개수는 1나
              10번째 segment가 구해지면 실제 segment는 0부터 시작하므로 0으로 주어 처리
       */


        /* RPUSH ---> 0 번째 sgement 처음에 할당을 하고 사용을 하는 놈이여서.. Exntend할 필요가 없다 */

        //sRC = sRC - 1;
        sRC = mSegMgr->GetUsageExtendSlotNo(aAllocSlot);

        /* 0번째는 sgement 생성 서 할당 되어 있기 때문에 새로 할당 할 필요 없다 */
        if( mListHeader->mSegmentAllocCk[sRC] == -1 && sRC != 0 )
        {
            mListHeader->mSegmentAllocCk[sRC] = sRC;

            return( sRC );
        }
        else
        {
            /* slot이 할당 되어 있으니 따로 할당하지 말고 걍 써라. Extend 불필요. */
            return( RC_FAILURE );
        }
    }
    _CATCH
    {
        _CATCH_ERR;

    }
    _FINALLY
    _END
}


/******************************************************************************
 * Name : mListMakeKey
 *
 * Description
 * ListHeader의 Position Offset을 보고 해당 Slot 번호를 찾아 반환한다.
 *
 * Argument
 *     aCheck     : input : 0:LPUSH 1:RPUSH 2:LPUSH Header Process 4:RPUSH Header Process
 *     aAllocSlot : output: 할당 받아 처리해야 할 Slot NO
 *
 ******************************************************************************/
_VOID dbmListManager::mListMakeKey( int aCheck, long long* aAllocSlot )
{
    dbmTableObject* sTableObj = &mListHeader->mTableObj;

    _TRY
    {
/*
        2. segment attach 해서 받아와야 하고(mListMakeKey)
           - index key 생성 모듈 call
*/

        switch( aCheck )
        {
            case 0: // LPUSH PROCESS
                /* mListLeftStart 0보다 작다는 것은 처음이라는 것을 알 수 있다 */
                if( mListHeader->mListLeftLast < 0 )
                {
                    /* left push:
                       제일 마지막번째 slot을 부터 left push 처리를 한다.
                       slot은 0부터 시작하므로 -1를 넣어주어 Max 개수로 처리 한다 */
                    *aAllocSlot = sTableObj->mMaxSize - 1;
                }
                else
                {
                    /* left push 에서 한칸씩 -1처리하여 key slot을 전달해 준다 */
                    *aAllocSlot = mListHeader->mListLeftLast - 1;

                    /* list 형식은 round robin 형식으로 되어 있어 0의 값이 올 수 있다.
                     * 0의 값이 오면 제일 큰값으로 넘겨준다 */
                    if( *aAllocSlot < 0 )
                    {
                        *aAllocSlot = sTableObj->mMaxSize - 1;
                    }
                }

                break;

            case 1: // RPUSH PROCESS
                /* mListRightStart 0보다 작다는 것은 Right PUSH가 처음 이라는 것을 알 수 있다 */
                if( mListHeader->mListRightLast < 0 )
                {
                    *aAllocSlot = 0;
                }
                else
                {
                    *aAllocSlot = mListHeader->mListRightLast + 1;

                    /* list 형식은 round rogin 형식으로 되어 있어 Max 보다 값이 넘어가게 되면
                     * 0의 값으로 넘겨 주어야 한다 */
                    if( *aAllocSlot > sTableObj->mMaxSize - 1 )
                    {
                        *aAllocSlot = 0;
                    }
                }

                break;

            case 2: // LPUSH PROCESS HEADER

                mListHeader->mListLeftLast--;

#if 0
                /* mListLeftStart 0보다 작다는 것은 처음이라는 것을 알 수 있다 */
                if( mListHeader->mListLeftLast < 0 )
                {
                    /* left push:
                       제일 마지막번째 slot을 부터 left push 처리를 한다.
                       slot은 0부터 시작하므로 -1를 넣어주어 Max 개수로 처리 한다 */
                    mListHeader->mListLeftLast  = sTableObj->mMaxSize-1;

                    /* total count가 1건이면 LeftLast, RightLast Pointer 지정해 준다 */
                    if( mListHeader->mListTotalCount == 0 )
                    {
                        mListHeader->mListRightLast = sTableObj->mMaxSize-1;
                    }

                }
                else
                {
                    /* left push 에서 한칸씩 -1처리하여 key slot을 전달해 준다 */
                    mListHeader->mListLeftLast = *aAllocSlot;
                }
#endif
                mListHeader->mListLeftLast = *aAllocSlot;

                /* logging 해두었기 때문에 비정상 종료 하면 뭐... 리커버리 하면 되기 때문에
                 * 여기에서 Total Count 증가 시켜 버린다. */
                mvpAtomicInc32(&mListHeader->mListTotalCount);

                break;

            case 3: // RPUSH PROCESS HEADER
#if 0
                /* mListRightStart 0보다 작다는 것은 Right PUSH가 처음 이라는 것을 알 수 있다 */
                if( mListHeader->mListRightLast < 0 )
                {
                    mListHeader->mListRightLast  = 0;

                    /* total count가 1건이면 LeftLast, RightLast Pointer 지정해 준다 */
                    if( mListHeader->mListTotalCount == 0 )
                    {
                        mListHeader->mListLeftLast = 0;
                    }

                }
                else
                {
                    mListHeader->mListRightLast = *aAllocSlot;
                }
#endif

                mListHeader->mListRightLast = *aAllocSlot;

                /* logging 해두었기 때문에 비정상 종료 하면 뭐... 리커버리 하면 되기 때문에
                 * 여기에서 Total Count 증가 시켜 버린다. */
                mvpAtomicInc32(&mListHeader->mListTotalCount);

                break;

            case 4: // LPOP Processor LEFT POP 처리
                /* mListLeftCount, mListLeftLast가 0보다 작다는 것은 값이 없다는 것이니 오류리턴 */
                /* Total Count가 0보다 작다는 것은 없는 것이다 */
                if( mListHeader->mListLeftLast < 0 || mListHeader->mListTotalCount < 1 )
                {
                    _THROW(ERR_DBM_LIST_NOT_DATA);
                }

                /* left slot의 맨 마지막에서 값을 가져오자 */
                *aAllocSlot = mListHeader->mListLeftLast;

                break;

            case 5: // RPOP Process RIGHT POP 처리
                /* mListRightStart, mListRightLast 0보다 작다는 것은 값이 없다는 것이다 */
                if( mListHeader->mListRightLast < 0 || mListHeader->mListTotalCount < 1 )
                {
                    _THROW(ERR_DBM_LIST_NOT_DATA);
                }

                /* left slot의 맨 마지막에서 값을 가져오자 */
                *aAllocSlot = mListHeader->mListRightLast;

                break;

            case 6: // LPOP Processor Header Process
                /* mListLeftCount, mListLeftLast가 0보다 작다는 것은 값이 없다는 것이니 오류리턴 */
                /* Total Count 가 없다는 것은 오류인 것이다 */
                if( mListHeader->mListLeftLast < 0 || mListHeader->mListTotalCount < 1 )
                {
                    _THROW(ERR_DBM_LIST_NOT_DATA);
                }

                /* left 꺼내 왔으니 증가 시켜주자 98->99 (left)*/
                mvpAtomicInc64(&mListHeader->mListLeftLast);

                if( mListHeader->mListLeftLast == sTableObj->mMaxSize )
                {
                    /* 2건 이상 있냐는 것이다 */
                    if( mListHeader->mListTotalCount > 1 )
                    {
                        /* MAX로 왔고 값이 더있다면 0번째것부터 가져와라 */
                        mListHeader->mListLeftLast = 0;
                    }
                    else
                    {
                        /*
                        위의 값과 동일하다는 것은 마지막 이라는 것을 뜻한다. 설정한 값이 없다는 것이니
                        처음처럼 -1로 주자. */
                        mListHeader->mListLeftLast = -1;
                    }
                }

                /* 하나를 꺼내왔으니 전체 count 감소 시켜주자 */
                mListHeader->mListTotalCount--;

                break;

            case 7: // RPOP Processor Header Process
                /* mListRightStart, mListRightLast 0보다 작다는 것은 값이 없다는 것이다 */
                if( mListHeader->mListRightLast < 0 || mListHeader->mListTotalCount < 1 )
                {
                    _THROW(ERR_DBM_LIST_NOT_DATA);
                }

                /* left 꺼내 왔으니 감소  시켜주자 3->2 (right)*/
                mListHeader->mListRightLast--;


                /* 0번째에서 RPUSH 하고 데이터가 있으면 마지막으로 옮겨져야 한다 */
                if( mListHeader->mListRightLast < 0 )
                {
                    /* 2건 이상 있을 때만 Position을 적용 한다 */
                    if( mListHeader->mListTotalCount > 1 )
                    {
                        mListHeader->mListRightLast = sTableObj->mMaxSize-1;
                    }
                    else
                    {
                        /* 2건 이상 없을 때에는 뭐냐 초기화 해버린다 */
                        mListHeader->mListRightLast = -1;
                    }

                }

                /* 하나를 꺼내왔으니 전체 count 감소 시켜주자 */
                mListHeader->mListTotalCount--;

                break;

            default:
                _THROW( ERR_DBM_INVALID_DATATYPE );
        }


    }
    _CATCH
    {
        _CATCH_ERR;

    }
    _FINALLY
    _END
}

/******************************************************************************
 * Name : mListCheck
 *
 * Description
 *
 * Argument
 *     aTransID   : input   : Transaction ID
 *     aDataObject: input   : LPUSH 처리 할 data struct.
 *
 ******************************************************************************/
_VOID dbmListManager::mListCheck( int aTransID, void* aDataObject)
{
    dbmDataObject*  sData = (dbmDataObject*) aDataObject;
    dbmTableObject* sTableObj = &mListHeader->mTableObj;


    _TRY
    {

        /*
        1. check 사항. (mListCheck)
            - g_pBuffer_mPush check
            - list type check
            - drop 된 테이블인지 체크
            - 입력된 data size가 테이블 레코드 사이즈보다 큰지 체크
        */


        /* data copy global declare chec */
        if( g_pBuffer_mPush == NULL )
        {
            g_pBuffer_mPush = (char*) malloc_s( DBM_MAX_RECORD_SIZE + sizeof(dbmListSlotHeader) );
            memset_s( g_pBuffer_mPush, 0, DBM_MAX_RECORD_SIZE + sizeof(dbmListSlotHeader) );
        }

        /* list type check */
        _IF_THROW( sTableObj->mTableType != DBM_TBL_LIST, ERR_DBM_INVALID_TABLE_TYPE );

        /* 처리하려는 list가 삭제된 놈인지 체크해 본다 */
        /* 이놈은 list init 처리 시 setting 해준다.(mTableID)   */
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /* 입력된 data size가 테이블 레코드 사이즈보다 큰지 체크 */
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE );

        if( sData->mTransType ==  DBM_LIST_LPUSH || sData->mTransType ==  DBM_LIST_RPUSH )
        {
            _IF_THROW( mListHeader->mListTotalCount > sTableObj->mMaxSize, ERR_DBM_EXCEED_TABLE_PER_TX );
        }

        if( sData->mTransType == DBM_LIST_LPOP || sData->mTransType == DBM_LIST_RPOP )
        {
            _IF_THROW( mListHeader->mListTotalCount < 1 , ERR_DBM_LIST_NOT_DATA );
        }


    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END

}

/******************************************************************************
 * Name : mListLock
 *
 * Description
 * List Recovery를 하기 위하여 list lock을 따로 두었다. 현재 dead lock 걸리지
 * 않겠지 하면 포함 시키지 않았다.
 *
 * Argument
 *     aInstNamt   : input   : Instancename
 *     aListRow    : input   : list header struct pointer
 *     aBeforeImage: outputut: Recovery 처리 후 list row data가 변경이 이룰어질
 *                             있기 때문에 before image간직하고 있다 리턴한다.
 *     aTransID    : input   : Transaction ID
 *
 ******************************************************************************/
_VOID dbmListManager::mListLock( char* aInstName, dbmListSlotHeader* aListRow, char* aBeforeImage, int aTransID )
{

    int     sPidReplacedF = 0;
    int     sPirReplaced  = 0;
    int     sRC = -1;

    int     sLockTryCount = 0;
    int     sFirstWaitTx  = 0;
    int     sPidTryCheck  = 0;
    int     sOldTxID;

    _TRY
    {

retry:

        sOldTxID     = mvpAtomicGet32( &aListRow->mLock );
        sFirstWaitTx = mvpAtomicGet32( &aListRow->mLock );

        sRC = mLockMgr->mLock( &aListRow->mLock,
                               aTransID,
                               &sPidReplacedF,
                               &sPirReplaced );

        /* PID 죽은 놈이여서 PID 교체 성공 했다 */
        if( ( sRC == ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC )  && ( sPidReplacedF == 1 ) )
        {
            /* 다른 놈이 process에 의해 lock이 걸린 후 해당 process가 다운 되었다면
             * 기존의 header부분을 원복해야 한다. 왜냐 현재의 놈꺼로 엎어버리면 안되니까. */

            sRC = dbmRecoveryManager::mRecoverTrans( aInstName, sOldTxID );
            if( sRC )
            {
                DBM_ERR( "[%s] rollback tx(%d) for rowlock fail. rc(%d)", aInstName, sOldTxID, sRC );
                _THROW( ERR_DBM_ROW_LOCK );
            }

            _THROW( ERR_DBM_ABNORMAL_ROLLBACK );
        }
        else
        if( ( sRC == ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC ) && ( sPidReplacedF == 0 ) )
        {
            /* pid가 없는 놈인데 pid 대체 하려고 하다 실패 했다 다시 시도해 본다 */
            DBM_ERR(" mListLock tx for rowlock faile.  ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC[%d] \n", sRC);

            pthread_yield_s();
            goto retry;
        }
        else
        if( sRC == ERR_DBM_LOCK_ROW_BY_OTHER_ALIVE_PROC )
        {
            /* 찔러 봤더니 산놈이더라 자기 자신인지 체크해 본다 */

            sLockTryCount++;
            sOldTxID = mvpAtomicGet32( &aListRow->mLock );

#if 0
            if ( ( sLockTryCount & 131071 ) == 0 && sFirstWaitTx == sOldTxID )
            {
                if ( mDeadLockMgr->mCheckDeadLock ( mTableID, aSlotID, sOldTxID ) == ERR_DBM_DEADLOCK_DETECTED )
                {
                    _CALL( mDeadLockMgr->mUnsetTransHeader ( ) );
                    return ERR_DBM_DEADLOCK_DETECTED;       // 의도적
                }

                sLockTryCount = 0;
                sFirstWaitTx = mvpAtomicGet32( &aListRow->mLock );
            }
#endif
            if( sOldTxID != mvpAtomicGet32( &aListRow->mLock ) )
            {
                pthread_yield_s();
                goto retry;
            }

            if( sPirReplaced == -1 )
            {
                if( sPidTryCheck == 10000 )
                {
                    mvpAtomicCas32( &aListRow->mLock, aTransID, sOldTxID );
                }
                sPidTryCheck++;
            }

            pthread_yield_s ( );
            goto retry;
        }

        memcpy_s ( aBeforeImage, aListRow, sizeof(dbmListSlotHeader) + aListRow->mRowSize );

    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END

}

/******************************************************************************
 * Name : mReadList
 *
 * Description
 * List slot에서 해당 slot의 data를 Read 처리 한다.
 *
 * Argument
 *
 ******************************************************************************/
_VOID dbmListManager::mReadList ( int aMyTxID , long long aSlotID , char* aData , int* aDataSize , int* aInserted )
{
    dbmListSlotHeader* sListRow = NULL;
    int         sBeforeTxID;
    long long   sBeforeSCN;
    long long   sSCN;
    int         sRC;

    _TRY
    {

        /* slot id attach */
        _CALL( mSegMgr->Slot2Addr( aSlotID, &sListRow ) );

 retry:
        // TODO: [OKT] 2015.03.06 #889 처럼 동일 SCN으로 쭉 가져오면 되는 것 아닌가?.나중에 다시 구현 시각할때 확인하다. (mReadList)
        /* 현재 undo의 scn을 가져온다 */
        mLogMgr->mPeekSCN( &sSCN );

        sBeforeTxID = mvpAtomicGet32( &sListRow->mLock );
        sBeforeSCN  = mvpAtomicGet64( &sListRow->mSCN );


        /* 누군가 lock을 걸고 처리 하고 있는 중이라면 */
        if( unlikely( sBeforeTxID != -1 ) )
        {
            /* 현재 누군가 변경중 이다. 처리해 보자. */

            /* TransID가 자기 자신이면 내꺼니까 걍 읽으면 된다. */
            if( sBeforeTxID == aMyTxID )
            {
                /* sRowSize :
                내꺼니까 읽으면 되는데 push 처리로 값이 없을 수 가 있다. 만약 값이 없다면
                sRowSize가 0일꺼야 그러면 not found 에러 처리 하자 . */

                _IF_THROW( sListRow->mRowSize == 0 , ERR_DBM_NO_MATCH_RECORD );

                /* sRowSize가 0이 아니야 그러면 걍 읽으면 된다. */
                memcpy_s( aData, ( (char*)sListRow + sizeof(dbmListSlotHeader) ), sListRow->mRowSize );
                *aDataSize = sListRow->mRowSize;
            }
            else
            {
                /* -미구현- 나중에 예외 사항 체크 할 때 구현 */
                _THROW( ERR_DBM_NO_MATCH_RECORD );
            }
        }
        else /* 누군가 lock을 걸고 있는 상태가 아니라면 */
        {
            /* -미구현- 나중에 예외 사항 체크 할 때 구현 */
            _THROW( ERR_DBM_NO_MATCH_RECORD );
        }

    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END


}


/******************************************************************************
 * Name : mListLpush
 *
 * Description
 * List 항목에 LPUSH Left 방향으로 PUSH 처리를 한다.
 *
 * input : 1 2 3
 * 순서  : 3 2 1  left 처리를 하였으므로 들어온 순서가 First로 되어 처리된다.
 *
 * Argument
 *     aTransID   : input   : Transaction ID
 *     aDataObject: input   : LPUSH 처리 할 data struct.
 *
 ******************************************************************************/
_VOID dbmListManager::mListLpush( int aTransID , void* aDataObject )
{
    long long sAllocSlot = -1;
    long long sSCN;
    int     sSegmentNo;
    int     sRC;
    int     sLogType;


    dbmLogHeader*       sLogHead = NULL;
    dbmDataObject*      sData = (dbmDataObject*) aDataObject;
    dbmTableObject*     sTableObj = &mListHeader->mTableObj;
    dbmListSlotHeader*  sListRow = NULL;
    dbmListSlotHeader*  sTmp = NULL;
    dbmListSlotHeader   sTmpRow;


    _TRY
    {

        /* 입력 받은 값들을 체크 한다. */
        _CALL( mListCheck( aTransID, aDataObject ) );

        /* 사용하려는 Key & Index 값을 구한다 */
        _CALL( mListMakeKey( 0, &sAllocSlot ) );

        /* Slot에 처리 될 segment을 구한다 */
        sSegmentNo = mListExtend(sAllocSlot);

        /* 해당 sAllocSlot에 해당 되는 segment가 할당 되어 있지 않으면 Extend 처리 해라. */
        if( sSegmentNo != -1 )
        {

            _CALL( mSegMgr->AllocExtend(sSegmentNo) );
        }

        /* 따로 Alloc을 하지 않으니 alloc segment만 일단 해놓자 */
        _CALL( mSegMgr->ListSetAlloc() );

        /* segment attach 처리 */
        sRC = mSegMgr->ListSlot2Addr( sAllocSlot, (char**)&sListRow );
        _IF_THROW( sRC || sListRow == NULL, ERR_DBM_ALLOC_SLOT );

        /* attach 한놈의 size가 중복으로 되어 있는지 체크 */
        _IF_THROW( sListRow->mRowSize > 0 , ERR_DBM_DUP_ERROR );

        /* disk mode가 아닐때 lock  logging 처리 */
        if( !sTableObj->mNoMemloggingF )
        {
            /* lock recovery sAllocSlot 필요 없다. 현재 쓰레기값  */
            sLogType = DBM_LOCK_LIST_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mListName, NULL, sAllocSlot,
                                          NULL,
                                          0,
                                          sListRow,
                                          mListHeader, &sLogHead);
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        /* lock :
         * lock를 잡고 시작 하자 */
        sRC = mListLock( sTableObj->mInstName, sListRow, (char*)&sTmpRow, aTransID );
        if( sRC == ERR_DBM_ROW_LOCK )
        {
            _THROW(ERR_DBM_ROW_LOCK);
        }

        /* mRowLock 처리 하고. 딴놈이 들어오면 안되니까... */
        _IF_THROW( sListRow->mRowSize > 0 , ERR_DBM_DUP_ERROR );


        /* Slot에 대한 List Header의 값에 값을 setting 한다. */
        _CALL( mListMakeKey( 2, &sAllocSlot ) );

        /* 중요 : 여기에서 Header값을 변경하고 로깅을 하지 못하고 죽으면 Header의 slot segment 값은
         * 증가하고 recovery 하지 못한다. 걍 하나 버린다. */
        /* list logging :
            List Header의 값을 복구하기 위하여 List Header 로깅을 한다. */
        if( !sTableObj->mNoMemloggingF )
        {
            /* lock recovery sAllocSlot 필요 없다. 현재 쓰레기값  */
            sLogType = DBM_LIST_HEADER_LPUSH_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mListName, NULL, sAllocSlot,
                                          NULL,
                                          0,
                                          sListRow,
                                          mListHeader, &sLogHead);
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        /* Recored 삽입 */
        memcpy_s( g_pBuffer_mPush, &sTmpRow, sizeof(dbmListSlotHeader) );

        memcpy_s( g_pBuffer_mPush + sizeof(dbmListSlotHeader), sData->mUserData, sData->mDataSize );

        /* memory logging */
        if( !sTableObj->mNoMemloggingF )
        {
            /* lock recovery sAllocSlot 필요 없다. 현재 쓰레기값  */
            sLogType = DBM_LIST_LPUSH_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mListName,
                                          NULL,
                                          sAllocSlot,
                                          g_pBuffer_mPush,
                                          sData->mDataSize + sizeof(dbmListSlotHeader),
                                          sListRow,
                                          mListHeader,
                                          &sLogHead);
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        sTmp = (dbmListSlotHeader*) g_pBuffer_mPush;

        if( !sTableObj->mNoMemloggingF )
        {
            sTmp->mSCN = INFINITE_SCN;
        }
        else
        {
            mLogMgr->mGetSCN ( &sSCN );
            sTmp->mSCN = sSCN;
        }

        sTmp->mRowSize = sData->mDataSize;
        memcpy_s( (char*)sListRow, g_pBuffer_mPush, sData->mDataSize + sizeof(dbmListSlotHeader) );

        if( sTableObj->mNoMemloggingF )
        {
            sListRow->mLock = -1;
        }

    }
    _CATCH
    {

        _CATCH_ERR;
    }
    _FINALLY
    _END

}


/******************************************************************************
 * Name : mListRpush
 *
 * Description
 * 입력받은 data를 right 기준으로 PUSH 처리 한다.
 * input 1 2 3 4
 * data 삽입 : 4 3 2 1
 *
 * Argument
 *     aTransID   : input   : Transaction ID
 *     aDataObject: input   : LPUSH 처리 할 data struct.
 *
 ******************************************************************************/
_VOID dbmListManager::mListRpush ( int aTransID , void* aDataObject )
{

    long long sAllocSlot = -1;
    long long sSCN;
    int     sSegmentNo;
    int     sRC;
    int     sLogType;


    dbmLogHeader*       sLogHead = NULL;
    dbmDataObject*      sData = (dbmDataObject*) aDataObject;
    dbmTableObject*     sTableObj = &mListHeader->mTableObj;
    dbmListSlotHeader*  sListRow = NULL;
    dbmListSlotHeader*  sTmp = NULL;
    dbmListSlotHeader   sTmpRow;


    _TRY
    {

        /* 입력 받은 값들을 체크 한다. */
        _CALL( mListCheck( aTransID, aDataObject ) );

        /* 사용하려는 Key & Index 값을 구한다 */
        _CALL( mListMakeKey( 1, &sAllocSlot ) );

        /* Slot에 처리 될 segment을 구한다 */
        sSegmentNo = mListExtend(sAllocSlot);

        /* 해당 sAllocSlot에 해당 되는 segment가 할당 되어 있지 않으면 Extend 처리 해라. */
        if( sSegmentNo != -1 )
        {

            _CALL( mSegMgr->AllocExtend(sSegmentNo) );
        }

        /* 따로 Alloc을 하지 않으니 alloc segment만 일단 해놓자 */
        _CALL( mSegMgr->ListSetAlloc() );

        /* segment attach 처리 */
        sRC = mSegMgr->ListSlot2Addr( sAllocSlot, (char**)&sListRow );
        _IF_THROW( sRC || sListRow == NULL, ERR_DBM_ALLOC_SLOT );

        /* attach 한놈의 size가 중복으로 되어 있는지 체크 */
        _IF_THROW( sListRow->mRowSize > 0 , ERR_DBM_DUP_ERROR );

        /* disk mode가 아닐때 lock  logging 처리 */
        if( !sTableObj->mNoMemloggingF )
        {
            /* lock recovery sAllocSlot 필요 없다. 현재 쓰레기값  */
            sLogType = DBM_LOCK_LIST_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mListName, NULL, sAllocSlot,
                                          NULL,
                                          0,
                                          sListRow,
                                          mListHeader, &sLogHead);
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        /* lock :
         * lock를 잡고 시작 하자 */
        sRC = mListLock( sTableObj->mInstName, sListRow, (char*)&sTmpRow, aTransID );
        if( sRC == ERR_DBM_ROW_LOCK )
        {
            _THROW(ERR_DBM_ROW_LOCK);
        }

        /* mRowLock 처리 하고. 딴놈이 들어오면 안되니까... */
        _IF_THROW( sListRow->mRowSize > 0 , ERR_DBM_DUP_ERROR );


        /* Slot에 대한 List Header의 값에 값을 setting 한다. */
        _CALL( mListMakeKey( 3, &sAllocSlot ) );

        /* 중요 : 여기에서 Header값을 변경하고 로깅을 하지 못하고 죽으면 Header의 slot segment 값은
         * 증가하고 recovery 하지 못한다. 걍 하나 버린다. */
        /* list logging :
            List Header의 값을 복구하기 위하여 List Header 로깅을 한다. */
        if( !sTableObj->mNoMemloggingF )
        {
            /* lock recovery sAllocSlot 필요 없다. 현재 쓰레기값  */
            sLogType = DBM_LIST_HEADER_RPUSH_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mListName, NULL, sAllocSlot,
                                          NULL,
                                          0,
                                          sListRow,
                                          mListHeader, &sLogHead);
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        /* Recored 삽입 */
        memcpy_s( g_pBuffer_mPush, &sTmpRow, sizeof(dbmListSlotHeader) );

        memcpy_s( g_pBuffer_mPush + sizeof(dbmListSlotHeader), sData->mUserData, sData->mDataSize );

        /* memory logging */
        if( !sTableObj->mNoMemloggingF )
        {
            /* lock recovery sAllocSlot 필요 없다. 현재 쓰레기값  */
            sLogType = DBM_LIST_RPUSH_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mListName, NULL, sAllocSlot,
                                          g_pBuffer_mPush,
                                          sData->mDataSize + sizeof(dbmListSlotHeader),
                                          sListRow,
                                          mListHeader,
                                          &sLogHead);
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        sTmp = (dbmListSlotHeader*) g_pBuffer_mPush;

        if( !sTableObj->mNoMemloggingF )
        {
            sTmp->mSCN = INFINITE_SCN;
        }
        else
        {
            mLogMgr->mGetSCN ( &sSCN );
            sTmp->mSCN = sSCN;
        }

        sTmp->mRowSize = sData->mDataSize;
        memcpy_s( (char*)sListRow, g_pBuffer_mPush, sData->mDataSize + sizeof(dbmListSlotHeader) );

        if( sTableObj->mNoMemloggingF )
        {
            sListRow->mLock = -1;
        }

    }
    _CATCH
    {

        _CATCH_ERR;
    }
    _FINALLY
    _END

}

/******************************************************************************
 * Name : mListLpop
 *
 * Description
 * LPOP 처리를 한다. Right 부터 POP 처리를 한다.
 * 1 2 3 4 10  ---> 10 4 3 2 1 순으로 처리 한다.
 *
 * Argument
 *     aTransID   : input   : Transaction ID
 *     aDataObject: input   : LPUSH 처리 할 data struct.
 *
 ******************************************************************************/
_VOID dbmListManager::mListLpop ( int aTransID , void* aDataObject )
{
    long long sAllocSlot = -1;
    long long sSCN;
    int     sSegmentNo;
    int     sRC;
    int     sLogType;
    int     sRowSize = 0;
    int     sInserted = 0;


    dbmLogHeader*       sLogHead = NULL;
    dbmDataObject*      sData = (dbmDataObject*) aDataObject;
    dbmTableObject*     sTableObj = &mListHeader->mTableObj;
    dbmListSlotHeader*  sListRow = NULL;
    dbmListSlotHeader*  sTmp = NULL;

    _TRY
    {

        /* 입력 받은 값들을 체크 한다. */
        _CALL( mListCheck( aTransID, aDataObject ) );

        /* 사용하려는 Key & Index 값을 구한다 */
        _CALL( mListMakeKey( 4, &sAllocSlot ) );

        /* 처리 하려는 Slot ID가 현재 MAX값보다 큰지 체크해 보자 */
        _IF_THROW( sAllocSlot >  sTableObj->mMaxSize , ERR_DBM_NO_MATCH_RECORD );

        /* Alloc Free count 처리 하자 */
        _CALL( mSegMgr->ListFreeAlloc() );

        /* segment attach 처리 */
        sRC = mSegMgr->ListSlot2Addr( sAllocSlot, (char**)&sListRow );
        _IF_THROW( sRC || sListRow == NULL, ERR_DBM_ALLOC_SLOT );

        /* Row Size가 -1인지 체크해 보자 */
        /* data가 없다면 초기값은 -1일 것이다 */
        _IF_THROW( sListRow->mRowSize == -1, ERR_DBM_NO_MATCH_RECORD );

        /* disk mode가 아닐때 lock  logging 처리 */
        if( !sTableObj->mNoMemloggingF )
        {
            /* lock recovery sAllocSlot 필요 없다. 현재 쓰레기값  */
            sLogType = DBM_LOCK_LIST_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mListName, NULL, sAllocSlot,
                                          NULL,
                                          0,
                                          sListRow,
                                          mListHeader, &sLogHead);
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        /* lock :
         * lock를 잡고 시작 하자 */
        sRC = mListLock( sTableObj->mInstName, sListRow, g_pBuffer_mPush, aTransID );
        if( sRC == ERR_DBM_ROW_LOCK )
        {
            _THROW(ERR_DBM_ROW_LOCK);
        }

        /* lock 성공 후 딴놈이 들어 왔는지 sRowSize 0인지 체크해 보자 */
        /* mRowLock 처리 하고. 딴놈이 들어오면 안되니까... */
        /* Rollback Success 처리하게 되면 mRowSize 0으로 초기화해 버린다 다시 pop 처리 하자 */
        _IF_THROW( sListRow->mRowSize == 0 , ERR_DBM_DUP_ERROR );

        /* Slot에 대한 List Header의 값에 값을 setting 한다. */
        _CALL( mListMakeKey( 6, &sAllocSlot ) );

        /* 중요 : 여기에서 Header값을 변경하고 로깅을 하지 못하고 죽으면 Header의 slot segment 값은
         * 증가하고 recovery 하지 못한다. 걍 하나 버린다. */
        /* list logging :
            List Header의 값을 복구하기 위하여 List Header 로깅을 한다. */
        if( !sTableObj->mNoMemloggingF )
        {
            /* lock recovery sAllocSlot 필요 없다. 현재 쓰레기값  */
            sLogType = DBM_LIST_HEADER_LPOP_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mListName, NULL, sAllocSlot,
                                          NULL,
                                          0,
                                          sListRow,
                                          mListHeader, &sLogHead);
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        /* delete data log 로깅해 놓자 */
        /* memory logging */
        if( !sTableObj->mNoMemloggingF )
        {
            /* lock recovery sAllocSlot 필요 없다. 현재 쓰레기값  */
            sLogType = DBM_LIST_LPOP_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mListName,
                                          NULL,
                                          sAllocSlot,
                                          g_pBuffer_mPush,
                                          sListRow->mRowSize + sizeof(dbmListSlotHeader),
                                          sListRow,
                                          mListHeader,
                                          &sLogHead);
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        /* 출력 data를 copy 한다 */
        memcpy_s( sData->mUserData, ( (char*)sListRow + sizeof(dbmListSlotHeader) ), sListRow->mRowSize );


        /* delete data를 처리 하자 */
        if( !sTableObj->mNoMemloggingF )
        {
            sRowSize        = sListRow->mRowSize;

            sListRow->mSCN  = INFINITE_SCN;

            sListRow->mRowSize = 0;
        }
        else
        {
            sListRow->mSCN      = 0;
            sListRow->mRowSize  = 0;
        }

        memset_s( (char*)sListRow + sizeof(dbmListSlotHeader), 0x00, sRowSize);

#if 0
        /* SlotID를 이용하여 list data 읽어온다 */
        _CALL( mReadList( aTransID, sAllocSlot, sData->mUserData, &sData->mDataSize, &sInserted ) );
#endif
        if( sTableObj->mNoMemloggingF )
        {
            sListRow->mLock = -1;
        }

    }
    _CATCH
    {

        _CATCH_ERR;
    }
    _FINALLY
    _END

}

/******************************************************************************
 * Name : mListRpop
 *
 * Description
 * input data 에서 right 부터 값을 꺼내 오도록 한다.
 *
 * Argument
 *     aTransID   : input   : Transaction ID
 *     aDataObject: input   : LPUSH 처리 할 data struct.
 *
 ******************************************************************************/
_VOID dbmListManager::mListRpop ( int aTransID , void* aDataObject )
{

    long long sAllocSlot = -1;
    long long sSCN;
    int     sSegmentNo;
    int     sRC;
    int     sLogType;
    int     sRowSize = 0;
    int     sInserted = 0;


    dbmLogHeader*       sLogHead = NULL;
    dbmDataObject*      sData = (dbmDataObject*) aDataObject;
    dbmTableObject*     sTableObj = &mListHeader->mTableObj;
    dbmListSlotHeader*  sListRow = NULL;
    dbmListSlotHeader*  sTmp = NULL;

    _TRY
    {

        /* 입력 받은 값들을 체크 한다. */
        _CALL( mListCheck( aTransID, aDataObject ) );

        /* 사용하려는 Key & Index 값을 구한다 */
        _CALL( mListMakeKey( 5, &sAllocSlot ) );

        /* 처리 하려는 Slot ID가 현재 MAX값보다 큰지 체크해 보자 */
        _IF_THROW( sAllocSlot >  sTableObj->mMaxSize , ERR_DBM_NO_MATCH_RECORD );

        /* Alloc Free count 처리 하자 */
        _CALL( mSegMgr->ListFreeAlloc() );

        /* segment attach 처리 */
        sRC = mSegMgr->ListSlot2Addr( sAllocSlot, (char**)&sListRow );
        _IF_THROW( sRC || sListRow == NULL, ERR_DBM_ALLOC_SLOT );

        /* Row Size가 -1인지 체크해 보자 */
        /* data가 없다면 초기값은 -1일 것이다 */
        _IF_THROW( sListRow->mRowSize == -1, ERR_DBM_NO_MATCH_RECORD );

        /* disk mode가 아닐때 lock  logging 처리 */
        if( !sTableObj->mNoMemloggingF )
        {
            /* lock recovery sAllocSlot 필요 없다. 현재 쓰레기값  */
            sLogType = DBM_LOCK_LIST_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mListName, NULL, sAllocSlot,
                                          NULL,
                                          0,
                                          sListRow,
                                          mListHeader, &sLogHead);
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        /* lock :
         * lock를 잡고 시작 하자 */
        sRC = mListLock( sTableObj->mInstName, sListRow, g_pBuffer_mPush, aTransID );
        if( sRC == ERR_DBM_ROW_LOCK )
        {
            _THROW(ERR_DBM_ROW_LOCK);
        }

        /* lock 성공 후 딴놈이 들어 왔는지 sRowSize 0인지 체크해 보자 */
        /* mRowLock 처리 하고. 딴놈이 들어오면 안되니까... */
        /* Rollback Success 처리하게 되면 mRowSize 0으로 초기화해 버린다 다시 pop 처리 하자 */
        _IF_THROW( sListRow->mRowSize == 0 , ERR_DBM_DUP_ERROR );

        /* Slot에 대한 List Header의 값에 값을 setting 한다. */
        _CALL( mListMakeKey( 7, &sAllocSlot ) );

        /* 중요 : 여기에서 Header값을 변경하고 로깅을 하지 못하고 죽으면 Header의 slot segment 값은
         * 증가하고 recovery 하지 못한다. 걍 하나 버린다. */
        /* list logging :
            List Header의 값을 복구하기 위하여 List Header 로깅을 한다. */
        if( !sTableObj->mNoMemloggingF )
        {
            /* lock recovery sAllocSlot 필요 없다. 현재 쓰레기값  */
            sLogType = DBM_LIST_HEADER_RPOP_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mListName, NULL, sAllocSlot,
                                          NULL,
                                          0,
                                          sListRow,
                                          mListHeader, &sLogHead);
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        /* delete data log 로깅해 놓자 */
        /* memory logging */
        if( !sTableObj->mNoMemloggingF )
        {
            /* lock recovery sAllocSlot 필요 없다. 현재 쓰레기값  */
            sLogType = DBM_LIST_RPOP_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mListName, NULL, sAllocSlot,
                                          g_pBuffer_mPush,
                                          sListRow->mRowSize + sizeof(dbmListSlotHeader),
                                          sListRow,
                                          mListHeader,
                                          &sLogHead);
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        /* 출력 data를 copy 한다 */
        memcpy_s( sData->mUserData, ( (char*)sListRow + sizeof(dbmListSlotHeader) ), sListRow->mRowSize );


        /* delete data를 처리 하자 */
        if( !sTableObj->mNoMemloggingF )
        {
            sRowSize        = sListRow->mRowSize;

            sListRow->mSCN  = INFINITE_SCN;

            sListRow->mRowSize = 0;
        }
        else
        {
            sListRow->mSCN      = 0;
            sListRow->mRowSize  = 0;
        }

        memset_s( (char*)sListRow + sizeof(dbmListSlotHeader), 0x00, sRowSize);

#if 0
        /* SlotID를 이용하여 list data 읽어온다 */
        _CALL( mReadList( aTransID, sAllocSlot, sData->mUserData, &sData->mDataSize, &sInserted ) );
#endif
        if( sTableObj->mNoMemloggingF )
        {
            sListRow->mLock = -1;
        }

    }
    _CATCH
    {

        _CATCH_ERR;
    }
    _FINALLY
    _END

}

/******************************************************************************
 * Name : mListRange
 *
 * Description
 *
 *
 ******************************************************************************/
_VOID dbmListManager::mListRange ( int aTransID , void* aDataObject )
{

    _TRY
    {

/*
        redis
            reply = redisCommand(c,"LRANGE list 0 -1");

            for (j = 0; j < reply->elements; j++)
            {
                printf("%u) %s\n", j, reply->element[j]->str);
            }


        1. 입력 받은값 체크

        2. Range 범위 검색 조건 SET
           LEFT 숫자값을 구한다.
           0의 값이 오면 : LeftLast 에서의 첫번째 값을 settting
           2의 값이 오면 : LeftLast 에서 -2한 값을 setting
           3의 값이 오면 : 3의 값이 왔을 때 98..99..0..1 위와 같이 처리 될 때
                           무조건 마이너스 처리를 할 수 없다. 어떨게 할거냐

           RIGHT 숫자값을 구한다.
           -1의 값이 오면 : RightLast 에서의 첫번째 값을 setting 한다.
           -2의 값이 오면 : RightLast 에서 -1한 값을 settting 한다.
           -3의 값이 오면 : -3의 값이 오면 99..0..1 값이 왔을 때 무조건 마이너스
                           처리 할 수 없다 어떻게 할거냐.
        3. segment attach 처리 하자.

        4. LOCK memory logging 처리를 한다

        5. LOCK 처리
           SLOCK 처리 어떻게 할거냐
           PUSH, POP 처리를 할 경우 해당 테이블에 LOCK을 걸고 처리를 하는데 해당
           RANGE검색 처리 시 데이터가 사라질 수 있다. 이건 어떻게 처리 할거냐.
           걍 해당 SCN값을가지고 있다가 해당 값보다 큰 값이 올경우 처리 변경이
           일어 났다고 오류를 리턴 할까.

           아니면.... PUSH, POP 처리 시 IX_LOCK, IS_LOCK 두개를 두어 먼저 IS_LOCK
           잡은 놈이 있으면 처리를 하지 못하고 대기 하게 할까.

        6. RANGE LOGGING 처리를 한다.

        7. 현재 가져오려는 키의 data copy 처리 한다.

        8. LOCK를 풀어준다.
*/


    }
    _CATCH
    {

        _CATCH_ERR;
    }
    _FINALLY
    _END

}



