/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
 *   dbmTableManager 의 멤버함수 구현
 ******************************************************************************/
#include "dbmHeader.h"
#include "dbmTableManager.h"

static _VOID dbmChgDirectKey2SlotID ( dbmColumnType aKeyColumnType , char* aKey , long long* aSlotID, int aCheck = 0 );

/******************************************************************************
 * Name : dbmTableManager
 *
 * Description
 *     constructor
 *
 ******************************************************************************/
dbmTableManager::dbmTableManager()
{
    memset_s ( mTableName, 0x00, DBM_NAME_LEN );
    mTableID        = -1;
    mTableHeader    = NULL;

    mSegMgr         = NULL;
    mUseIndex       = 0;
    mSetIndexF      = 0;
    mIndexCount     = 0;

    memset_s ( mIndex, 0x00, sizeof(char*) * DBM_MAX_INDEX_PER_TABLE );

    mLogMgr         = NULL;
    mLockMgr        = NULL;
    mBindCols       = NULL;
    mDeadLockMgr    = NULL;
    mTrigger        = NULL ;
    mDicTableF      = 0;
    mFetchScn       = -1;

    mSelect_extrakey = -1;
    mSelect_curr_extrakey = -1;
}


/******************************************************************************
 * Name : ~dbmTableManager
 *
 * Description
 *     destructor
 *
 ******************************************************************************/
dbmTableManager::~dbmTableManager( )
{
    for ( int i = 0; i < mIndexCount; i++ )
    {
        if ( mIndex[i] != NULL )
        {
            delete_s( mIndex[i] );
        }
    }

    if ( mSegMgr != NULL )
    {
#ifndef USE_NEW_SHM_NODETACH
        mSegMgr->Detach ( ) ;
#endif
        delete_s( mSegMgr );
    }

    if ( mBindCols != NULL )
    {
        free_s( mBindCols );
    }
}


/*
 * 2014.12.14. -okt- 사용되는 곳이 없지만, 함수호출을 하지 않고 직접하고 있어서 그렇다. 어떻게 할까? ( 2014.09.21 )
 */
_VOID dbmTableManager::mSetEventQueue ( char* aEventQueue )
{
    _TRY
    {
        /*** 첫번째 Byte 가 NULL 이면 Event 가 unSet 되었다고 본다. */
        if ( mTableHeader->mEventQueue[0] == '\0' )
        {
            cmnStrCpy ( mTableHeader->mEventQueue, aEventQueue, sizeof(mTableHeader->mEventQueue) );
            _RETURN;
        }

        /*** 이미 세팅된 경우 다시 세팅할 수 없다. **/
        _THROW( ERR_DBM_EVENT_ALREADY_SET );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


/******************************************************************************
 * Name : mInitTable
 *
 * Description
 *     initialize table manager
 *
 ******************************************************************************/
_VOID dbmTableManager::mInitTable( char*            aInstName,
                                 char*              aTableName,
                                 int                aIndexCount,
                                 dbmIndexObject*    aIndexObject,
                                 dbmDicObject*      aDicObject,
                                 dbmLogManager*     aLogMgr,
                                 dbmLockManager*    aLockMgr,
                                 dbmDeadLockManager* aDeadLockMgr)
{
    dbmIndexObject* sIndexObj = NULL;
    dbmTableInfo*   sDicTableInfo = &aDicObject->mObj.mTableInfo;
    int             sRC = -1;
    int             i;

    _TRY
    {
        memset_s ( mInstName, 0x00, DBM_NAME_LEN );
        memset_s ( mTableName, 0x00, DBM_NAME_LEN );
        memset_s ( mPkeyData, 0x00, DBM_INDEX_KEY_MAX_SIZE );

        strcpy_s ( mInstName, aInstName );
        strcpy_s ( mTableName, aTableName );
        mTableID = -1;

        mSelect_extrakey = -1;
        mSelect_curr_extrakey = -1;

        /****************************************************
         * table segment manager 객체 생성
         ****************************************************/
        _CALL( dbmSegmentManager::Attach( mInstName, mTableName, &mSegMgr ) );

        /****************************************************
         * table header pointer 설정
         ****************************************************/
        mTableHeader = (dbmTableHeader*)mSegMgr->GetUserHeader();
        _IF_THROW( mTableHeader->mInitCompleteF != 1, ERR_DBM_INVALID_HEADER );


        /****************************************************
         * dictionary 정보와 table header 정보가 다르면 에러.
         ****************************************************/
        if ( strcmp_s ( sDicTableInfo->mTable.mTableName, mTableHeader->mTableObj.mTableName ) )
        {
            DBM_ERR( "Table(%s) header info and dictionary info does not match.", aTableName );
            _THROW( ERR_DBM_HEAD_DIC_INFO_NOT_MATCH );
        }

        // 2014.09.21 (OKT): 불필요할 것 같지만. 성능구간 아니므로.
        _IF_THROW( sDicTableInfo->mIndexCount != mTableHeader->mIndexCount, ERR_DBM_HEAD_DIC_INFO_NOT_MATCH );


        /****************************************************
         * dbmLogManager 객체 설정
         * dbmLockManager 객체 설정
         ****************************************************/
        mLogMgr  = aLogMgr;
        mLockMgr = aLockMgr;
        mDeadLockMgr = aDeadLockMgr;

        /****************************************************
         * Table Header 의 Table ID 로 Table Manager 객체의
         * Table ID 를 셋팅.
         ****************************************************/
        mTableID = mTableHeader->mTableObj.mTableID;

        /****************************************************
         * 컬럼 binding 에 사용할 메모리 공간 할당
         ****************************************************/
        if ( mBindCols == NULL )
        {
            mBindCols = (char*) malloc_s ( sizeof(dbmBindCols) );
            _IF_THROW( mBindCols == NULL, ERR_DBM_MEM_ALLOC );
        }

        memset_s ( mBindCols, 0x00, sizeof(dbmBindCols) );

        /***********************************************
         * aIndexObject 을 이용하여 Index Name 을
         * index manager 객체에 설정해준다.
         ***********************************************/
        sIndexObj   = aIndexObject;
        mIndexCount = aIndexCount;

        if ( mTableHeader->mTableObj.mTableType == DBM_TBL_NORMAL )
        {
            /***********************************************
             * direct table 일 경우는 index 를 사용하지
             * 않기 때문에 아래 과정이 불필요하다.
             ***********************************************/
            for( i=0; i<aIndexCount; i++ )
            {
                mIndex[i] = new dbmIndexManager();
                _IF_THROW( mIndex[i] == NULL, ERR_DBM_MEM_ALLOC );

                _CALL( mIndex[i]->mInitIndex ( mInstName, sIndexObj->mIndexName, aLogMgr, aLockMgr ) );

                if ( sIndexObj->mKey[sIndexObj->mColumnCount - 1].mColumnType == DBM_COLUMN_CHAR_TYPE
                        && !strcmp_s( sIndexObj->mKey[sIndexObj->mColumnCount - 1].mColumnName,
                                      mTableHeader->mCols.mCols[mTableHeader->mCols.mCount - 1].mColumnName ) )
                {
                    /***********************************************
                     * mInsert 시 사용
                     * (Index KeySize 비교 skip - 성능을 위해)
                     ***********************************************/
                    mIndex[i]->mSetSkipCompareKeysize ( 1 );
                }
                else
                {
                    mIndex[i]->mSetSkipCompareKeysize ( 0 );
                }

                sIndexObj++;
            }
        }

        mSetIndexF = 0;
        mUseIndex  = 0; /* default index */
        mDicTableF = 0; /* default 는 dictionary table 이 아니다. */
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mInitTable */


/******************************************************************************
 * Name : mPrepareIndex
 *
 * Description
 *     prepare index manager
 *
 ******************************************************************************/
//_VOID dbmTableManager::mPrepareIndex ( char* aIndexName , dbmLogManager* aLogMgr , dbmLockManager* aLockMgr )
//{
//    unsigned long long   i;
//    int             sRC = -1;
//
//    _TRY
//    {
//        _IF_THROW( aLogMgr  == NULL, ERR_DBM_INVALID_ARGUENT );
//        _IF_THROW( aLockMgr == NULL, ERR_DBM_INVALID_ARGUENT );
//
//        if ( mTableHeader->mTableObj.mTableType == DBM_TBL_NORMAL )
//        {
//            /***********************************************
//             * direct table 일 경우는 index 를 사용하지
//             * 않기 때문에 아래 과정이 불필요하다.
//             ***********************************************/
//            for( i=0; i<mIndexCount; i++ )
//            {
//                if ( ! strcmp_s( aIndexName, mIndex[i]->mGetIndexName()) )
//                {
//                    /* already prepared */
//                    return RC_SUCCESS;
//                }
//            }
//
//            mIndex[mIndexCount] = new dbmIndexManager();
//            _IF_THROW( mIndex[mIndexCount] == NULL, ERR_DBM_MEM_ALLOC );
//
//            _CALL( mIndex[mIndexCount]->mInitIndex ( mInstName, aIndexName, aLogMgr, aLockMgr ) );
//            mIndexCount++;
//        }
//    }
//    _CATCH
//    {
//        _CATCH_WARN;
//    }
//    _FINALLY
//    _END
//} /* mPrepareIndex */


/******************************************************************************
 * Name : mRemoveIdxMgr
 *
 * Description
 *     remove index manager by using index name
 *
 ******************************************************************************/
_VOID dbmTableManager::mRemoveIdxMgr( char* aIndexName )
{
    int     i;

    _TRY
    {
        for ( i = 0; i < mIndexCount; i++ )
        {
            if ( !strcmp_s ( aIndexName, mIndex[i]->mGetIndexName ( ) ) )
            {
                break;
            }
        }

        if ( i >= mIndexCount )
        {
            _RETURN;
        }

        if ( mIndex[i] != NULL )
        {
            delete_s( mIndex[i] );
            DBM_WARN( "remove index(%s) manager from table(%s) manager. idx(%ld)", aIndexName, mTableName, i );

            if ( mIndexCount > ( i + 1 ) )
            {
                memmove_s ( &mIndex[i], &mIndex[i + 1], sizeof(dbmIndexManager*) * ( mIndexCount - ( i + 1 ) ) );
            }

            mIndexCount = mIndexCount - 1;
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mRemoveIdxMgr */


/******************************************************************************
 * Name : mFetch
 *
 * Description
 *     select operation
 *
 ******************************************************************************/
_VOID dbmTableManager::mFetch ( int aTransID , void* aDataObject )
{
    int             sRC;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE]; // non-unique type check value 8 byte 2014.05.30 -shw-
    long long       sSlotID    = -1;
    dbmDataObject*  sData      = (dbmDataObject*)aDataObject;
    dbmIndexHeader* sIndexHead = NULL;
    dbmLogType      sLogType = DBM_LOG_TYPE_MAX;
    char            sTempKey[DBM_NON_UNIQUE_KEY_SIZE];
    int             sInserted  = 0;

    _TRY
    {
        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( mTableHeader->mTableObj.mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( mTableHeader->mTableObj.mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mTableHeader->mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectSelect() 함수 호출
         ***********************************************/
        if ( mTableHeader->mTableObj.mTableType == DBM_TBL_DIRECT )
        {
            _IF_THROW( mSelect_curr_extrakey < 0, ERR_DBM_NO_MATCH_RECORD );
            _CALL( mDirectSelect ( aTransID, aDataObject ) );
            mSelect_curr_extrakey = -1;
            _RETURN;
        }

        /***********************************************
         * Search Key 수행
         ***********************************************/

        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader();

        _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sKey ) );

        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            _IF_THROW( mSelect_curr_extrakey < 0, ERR_DBM_NO_MATCH_RECORD );
            sRC = mIndex[mUseIndex]->mSearchKey( aTransID, sKey, &sSlotID );
            mSelect_extrakey = -1;
            mSelect_curr_extrakey = -1;
        }
        else
        {
retry:
            if ( mSelect_extrakey == -1 && mSelect_curr_extrakey != 0)
            {
                /* 마직막 이면 리턴 코드를 -1로 주어 처리 한다 */
                sRC = ERR_DBM_KEY_NOT_EXIST;
            }
            else
            if ( mSelect_extrakey != -1 && mSelect_curr_extrakey == 0 )
            {
                mSelect_curr_extrakey = -1;
                sRC = mIndex[mUseIndex]->mSearchKeyNu( aTransID, sKey, &sSlotID, &mSelect_curr_extrakey );
                mSelect_extrakey = mSelect_curr_extrakey;
                mSelect_curr_extrakey = -1;
            }
            else
            {
                sRC = mIndex[mUseIndex]->mSearchKeyNu( aTransID, sKey, &sSlotID, &mSelect_extrakey );
                mSelect_curr_extrakey = -1;
            }
        }

        if ( sRC != 0 )
        {
            _IF_THROW( sRC == ERR_DBM_KEY_NOT_EXIST, ERR_DBM_NO_MATCH_RECORD );
        }
        else
        {
            //_IF_THROW( sRC || sSlotID < 0, sRC /* SEARCH_KEY_FAIL */ );
            if ( sSlotID < 0 )
            {
                DBM_WARN( "mSearchKey error. sSlotID=%d", sSlotID );
                _THROW( -1 );
            }
        }

        /***********************************************
         * sSlotID 를 이용하여 Record 를 읽는다.
         ***********************************************/
        sRC = mFetchReadRecord( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted, &sLogType );
        //만약에 읽어온 레코드가 undo에서 읽어왔는데 DBM_UPDATE_KEY_LOG에 의한 이미지이거나
        //내가 변경한 레코드라면 정상적인 로우인지 확인해 봐야한다.
        if( sLogType == DBM_UPDATE_KEY_LOG )
        {
            sLogType = DBM_LOG_TYPE_MAX;
            _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sTempKey ) );
            if( memcmp_s( sKey, sTempKey, sIndexHead->mIndex.mKeySize ) )
            {
                sRC = ERR_DBM_NO_MATCH_RECORD;
            }
        }

        if ( ! sIndexHead->mIndex.mIsUniqueIndex && sRC == ERR_DBM_NO_MATCH_RECORD && mSelect_extrakey != -1 )
        {
            sInserted = 0;
            goto retry;
        }

        _IF_THROW( sRC == ERR_DBM_NO_MATCH_RECORD, ERR_DBM_NO_MATCH_RECORD );
        _IF_THROW( sRC, sRC /* READ_RECORD_FAIL */ );

    }
    _CATCH
    {
        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_TRC;
        }
        else
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* mFetch */



/******************************************************************************
 * Name : mSelect
 *
 * Description
 *     select operation
 *
 ******************************************************************************/
_VOID dbmTableManager::mSelect ( int aTransID , void* aDataObject, int aDirtyFlag )
{
    int             sRC;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE]; // non-unique type check value 8 byte 2014.05.30 -shw-
    long long       sSlotID    = -1;
    dbmDataObject*  sData      = (dbmDataObject*)aDataObject;
    dbmIndexHeader* sIndexHead = NULL;
    dbmLogType      sLogType = DBM_LOG_TYPE_MAX;
    char            sTempKey[DBM_NON_UNIQUE_KEY_SIZE];
    int             sInserted  = 0;

    _TRY
    {
        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( mTableHeader->mTableObj.mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( mTableHeader->mTableObj.mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mTableHeader->mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectSelect() 함수 호출
         ***********************************************/
        if ( mTableHeader->mTableObj.mTableType == DBM_TBL_DIRECT ||
             mTableHeader->mTableObj.mTableType == DBM_TBL_SEQUENCE )
        {
            _CALL( mDirectSelect ( aTransID, aDataObject ) );
            mSelect_curr_extrakey = 0;
            _RETURN;
        }

        /***********************************************
         * Search Key 수행
         ***********************************************/

        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader();
        _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sKey ) );

        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            sRC = mIndex[mUseIndex]->mSearchKey( aTransID, sKey, &sSlotID );
            mSelect_extrakey = -1;
            mSelect_curr_extrakey = 0;
        }
        else
        {
            mSelect_extrakey = -1;
retry:
            sRC = mIndex[mUseIndex]->mSearchKeyNu( aTransID, sKey, &sSlotID, &mSelect_extrakey );
            mSelect_curr_extrakey = 0;

        }

        if ( sRC != 0 )
        {
            _IF_THROW( sRC == ERR_DBM_KEY_NOT_EXIST, ERR_DBM_NO_MATCH_RECORD );
        }
        else
        {
            //_IF_THROW( sRC || sSlotID < 0, sRC /* SEARCH_KEY_FAIL */ );
            if ( sSlotID < 0 )
            {
                DBM_WARN( "mSearchKey error. sSlotID=%d", sSlotID );
                _THROW( -1 );
            }
        }

        /***********************************************
         * sSlotID 를 이용하여 Record 를 읽는다.
         ***********************************************/
        sRC = mReadRecord( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted, aDirtyFlag, &sLogType );
        //만약에 읽어온 레코드가 undo에서 읽어왔는데 DBM_UPDATE_KEY_LOG에 의한 이미지이거나
        //내가 변경한 레코드라면 정상적인 로우인지 확인해 봐야한다.
        if( sLogType == DBM_UPDATE_KEY_LOG )
        {
            sLogType = DBM_LOG_TYPE_MAX;
            _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sTempKey ) );
            if( memcmp_s( sKey, sTempKey, sIndexHead->mIndex.mKeySize ) )
            {
                sRC = ERR_DBM_NO_MATCH_RECORD;
            }
        }

        if ( ! sIndexHead->mIndex.mIsUniqueIndex && sRC == ERR_DBM_NO_MATCH_RECORD && mSelect_extrakey != -1 )
        {
            sInserted = 0;
            goto retry;
        }

        _IF_THROW( sRC == ERR_DBM_NO_MATCH_RECORD, ERR_DBM_NO_MATCH_RECORD );
        _IF_THROW( sRC, sRC /* READ_RECORD_FAIL */ );

    }
    _CATCH
    {
        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_TRC;
        }
        else
        {
            _CATCH_ERR;
        }
        
        // mReadRecord를 갔다오면 땄을꺼다...
        // 근데 오류가 났다는건 못딴건데... 
        // 이 상태에서 아래 코드없이 fetchNext를 부르는 구조들이 있다.
        // NonUnique index search의 경우인데 이러면 mFetchScn을 아무데서도 Setting하지 않는 문제가 있음.
        if (aDirtyFlag == DBM_DIRTY_ON)
        { 
            mFetchScn = LONG_MAX;
        }
        else 
        {
            mLogMgr->mPeekSCN( &mFetchScn );
        }
    }
    _FINALLY
    _END
} /* mSelect */


_VOID dbmTableManager::mBuildDataObject ( char* aData , int aDataLen , dbmDataObject* aOutput )
{
    aOutput->mTransType = DBM_ENQUE;
    aOutput->mDataSize  =  aDataLen + sizeof (dbmEventDataHeader);
    aOutput->mTimeout   =  0 ;
    aOutput->mUserData  = aData;

    return 0;   // 원래는 void 인데. 성능함수도 아니고 오류체크 누락이 아니라는 구분 편의를 위해 _VOID로
}


/******************************************************************************
 * Name : mInsert
 *
 * Description
 *     insert operation
 *
 ******************************************************************************/
__thread char* g_pBuffer_mInsert = NULL;

_VOID dbmTableManager::mInsert ( int                aTransID ,
                                 void*              aDataObject ,
                                 dbmTransHeader*    aTxHead ,
                                 long long*         aBackLogPos ,
                                 long long*         aBackImagePos )
{
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmRowHeader*   sRow  = NULL;
    dbmRowHeader*   sTmp  = NULL;
    dbmRowHeader    sTmpRow;
    dbmLogHeader*   sLogHead    = NULL;
    dbmIndexHeader* sIdxHead    = NULL;
    dbmIndexObject* sIndex      = NULL;
    dbmTableObject* sTableObj   = &mTableHeader->mTableObj;
    int             sLogType    = DBM_LOG_TYPE_MAX;
    char            sKey[DBM_INDEX_KEY_MAX_SIZE];
    long long       sAllocSlot  = -1;
    long long       sExtraKey   = -1;
    int             sIndexKeySize = 0;
    int             sRowHeadPlusRecSize = sData->mDataSize + sizeof(dbmRowHeader);
    int             sRC;
    int             sKeyOffset  = 0;

    _TRY
    {
        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectInsert() 함수 호출
         ***********************************************/
        _DASSERT( sTableObj != NULL );
        if ( sTableObj->mTableType == DBM_TBL_DIRECT ||
             sTableObj->mTableType == DBM_TBL_SEQUENCE )
        {
            return mDirectInsert ( aTransID, aDataObject );     // 의도적
        }

        /***********************************************
         * Big Stack 변수 제거
         ***********************************************/
        if ( unlikely( g_pBuffer_mInsert == NULL ) )
        {
            g_pBuffer_mInsert = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            memset_s ( g_pBuffer_mInsert, 0, DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * User Data 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE ); // INVALID_RECORD_SIZE );

        /***********************************************
         * Trigger 체크 이미 삭제되었을 수도 있음.
         **********************************************/
        if ( mTrigger != NULL )
        {
            if ( mTableHeader->mEventQueue[0] == '\0' ) // 만약 헤더에 Trigger 가 없다
            {
                mTrigger = NULL;
            }
        }

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * alloc slot to write record
         *   1. alloc slot
         *   2. row header 초기화
         *   3. logging
         ***********************************************/
        sRC = dbmSegAllocSlot ( mSegMgr, &sAllocSlot );
        _IF_THROW( sRC, sRC ); //ALLOC_SLOT_FAIL );

        sRC = mSegMgr->Slot2Addr ( sAllocSlot, &sRow );
        _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT ); // SLOT2ADDR_FAIL );

        RTF_POINT( "TBLMGR_INSERT_1" );

        sTmpRow.mSCN     = 0;
        sTmpRow.mLock    = -1;
        sTmpRow.mRowSize = 0;

        memcpy_s ( sRow, &sTmpRow, sizeof(dbmRowHeader) ); // 16 byte

        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_ALLOC_SLOT_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sAllocSlot,
                                         NULL,
                                         0,
                                         mTableHeader,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW ( sRC, ERR_DBM_WRITE_LOG );
        }

        RTF_POINT( "TBLMGR_INSERT_2" );

        /***********************************************
         * Row Lock
         *   1. Logging( DBM_LOCK_ROW_LOG )
         *   2. Row Lock 수행 (Lock 잡은 상태의 Row Header 를
         *      sTmpRow 에 저장)
         ***********************************************/
        if ( !sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_LOCK_ROW_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sAllocSlot,
                                         NULL,
                                         0,
                                         sRow, /* commit, rollback 때 사용 */
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW ( sRC, ERR_DBM_WRITE_LOG );
        }


        //TODO: 2014.11.18. -okt- void* 바꾸어서 (char*) 비용 없앨수는 있다. 한군데 뿐이라서 그냥둠.
        sRC = mRowLock ( sTableObj->mInstName, sAllocSlot, sRow, (char*) &sTmpRow, aTransID, 0 );
        //_IF_RAISE( sRC == ERR_DBM_DEADLOCK_DETECTED, DEAD_LOCK );
        if ( sRC == ERR_DBM_DEADLOCK_DETECTED )
        {
            return( ERR_DBM_DEADLOCK_DETECTED ); // 의도적
        }

        //_IF_RAISE( sRC && (sRC != ERR_DBM_ABNORMAL_ROLLBACK), ROW_LOCK_FAIL );
        if ( sRC && (sRC != ERR_DBM_ABNORMAL_ROLLBACK) ) //, ROW_LOCK_FAIL );
        {
            DBM_ERR( "lock row fail. TxID[%d] table[%s] rowslot[%ld] sRC[%d]",
                     aTransID, mTableHeader->mTableObj.mTableName, sAllocSlot, sRC );
            _THROW( sRC );
        }

        RTF_POINT( "TBLMGR_INSERT_3" );

        /***********************************************
         * 모든 Index 에 Insert Key 작업.
         * Insert Key 가 Fail 나면 DBM_INSERT_INDEX_LOG 는
         * Rollback 하면 안되기 때문에 Backup Log Position 을
         * Logging 전에 backup 해둔다.
         * mRecoveryStartPos 는 그런 상황에서 죽었을 때
         * 복구의 시작지점을 기억해두기 위함.
         ***********************************************/
        for ( int i = 0; i < mIndexCount; i++ )
        {
            sIndex = &mTableHeader->mIndex[i];

            if ( mIndex[i]->mGetSkipCompareKeysize ( ) )
            {
                /*
                 * index 의 마지막 컬럼이 table 의 마지막 컬럼이면서
                 * char 형이면 mKeySize 와 비교할 필요없다.
                 * (실제 데이터만큼만 사용자가 사이즈를 줄 수 있기 때문)
                 * 이 Index 별 Flag 는 mInitTable 단계에서 셋팅해둔걸 체크.
                 */
            }
            else
            {
                _IF_THROW( sData->mDataSize < sIndex->mKeySize, ERR_DBM_INVALID_RECORD_SIZE ); // INVALID_RECORD_SIZE );
            }

            _CALL( mMakeKey ( sIndex, sData->mUserData, sKey ) );

            *aBackLogPos   = aTxHead->mLogCurPos;
            *aBackImagePos = aTxHead->mImageCurPos;

            aTxHead->mRecoveryStartPos = aTxHead->mLogCurPos;

            /* 2015.06.29 -shw- input 처리 시 key 값에 null이 들어오는지 체크를 한다 */
            /* keyh의 첫번째 자리가 null이면 key error로 처리 한다 */
            /* dic null 값을 사용하고 있다. 요거를 풀어야 하는데 잘모르겠다. 동표님 오면
             * 요청 해서 해결하자 */
            if ( memcmp_s ( sTableObj->mTableName, "$sys", 4  ) && sIndex->mIsUniqueIndex == DBM_UNIQUE ) 
            {
                for ( int j = 0; j < sIndex->mColumnCount; j++ )
                {

                    //if ( unlikely( sKey[sKeyOffset] == NULL ) )
                    if ( unlikely( sKey[sKeyOffset] == '\0'  && 
                         sIndex->mKey[j].mColumnType == DBM_COLUMN_CHAR_TYPE ) )
                    {
                        _THROW( ERR_DBM_INVALID_KEY );
                    }

                    sKeyOffset = sKeyOffset + sIndex->mKey[j].mSize;

                }
            }

            sKeyOffset = 0;

            /***********************************************
             * 변경자 : wind * 변경일 : 15.10.26 * 참고 : #1011
             * 변경 내용 : NU인덱스에 키 입력 시 extrakey 값을 미리 할당 받고, 할당 받은 extrakey 값을 로깅한다.
             * 복구 시 해당 extrakey값으로 의도한 삭제 작업을 수행한다.
             ***********************************************/
            if ( sIndex->mIsUniqueIndex == DBM_UNIQUE )
            {
                sLogType = DBM_INSERT_INDEX_LOG;
                sIndexKeySize = sIndex->mKeySize;
            }
            else
            {
                sLogType = DBM_INSERT_INDEX_LOG2;
                sIdxHead = (dbmIndexHeader*) mIndex[i]->mGetIndexHeader();
                _IF_THROW( sIdxHead == NULL, ERR_DBM_TABLE_NOT_PREPARED );
                sIndexKeySize = sIndex->mKeySize + 8;
                //sExtraKey = mvpAtomicInc64 ( &sIdxHead->mExtra );
                //*(long long*) ( sKey + sIndex->mKeySize ) = sExtraKey;
                *(long long*) ( sKey + sIndex->mKeySize ) = SLOT2EXTRA( sAllocSlot );
                //mvpAtomicInc64 ( &(sIdxHead->mExtra) );
                //*(long long*) ( sKey + sIndex->mKeySize ) = sIdxHead->mExtra;
            }

            if ( ! sTableObj->mNoMemloggingF )
            {
                //sLogType = DBM_INSERT_INDEX_LOG;
                sRC = mLogMgr->mWriteMemLog( sLogType,
                                             aTransID,
                                             sIndex->mIndexID,
                                             sIndex->mIndexName,
                                             mTableName,
                                             sAllocSlot,
                                             sKey,
                                             sIndexKeySize,
                                             /*
                                             (char*)mIndex[i]->mGetIndexHeader(),
                                             (char*)mIndex[i]->mGetIndexHeader(),
                                             */
                                             NULL,
                                             NULL,
                                             &sLogHead );
                _IF_THROW ( sRC, ERR_DBM_WRITE_LOG );
            }

            RTF_POINT( "TBLMGR_INSERT_4" );

            //_CALL( mIndex[i]->mInsertKey ( aTransID, sData->mUserData, sAllocSlot, &sExtraKey ) );
            //_CALL( mIndex[i]->mInsertKey ( aTransID, sKey, sAllocSlot, &sExtraKey ) );
            _CALL( mIndex[i]->mInsertKey ( aTransID, sKey, sAllocSlot ) );
//            _IF_THROW( sRC == ERR_DBM_DUP_ERROR, ERR_DBM_DUP_ERROR );
//            _IF_THROW( sRC, sRC ); // INSERT_KEY_FAIL );

            RTF_POINT( "TBLMGR_INSERT_5" );

            /***********************************************
             * TODO.
             * 이거 mInsertKey 와 이거 변경 사이에 죽으면
             * Recovery Rollback 의 시작시점이 달라져서
             * 문제가 될 수 있다.
             ***********************************************/
            aTxHead->mRecoveryStartPos = MK_POS ( -1, -1 );
        } /* for */

        RTF_POINT( "TBLMGR_INSERT_6" );

        /***********************************************
         * Record 삽입
         *   1. logging( DBM_INSERT_SLOT_LOG )
         *   2. Record 복사
         ***********************************************/
        memcpy_s ( g_pBuffer_mInsert, &sTmpRow, sizeof(dbmRowHeader) ); // 16 byte
        memcpy_s ( g_pBuffer_mInsert + sizeof(dbmRowHeader), sData->mUserData, sData->mDataSize );

        if ( !sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_INSERT_SLOT_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sAllocSlot,
                                         g_pBuffer_mInsert,      /* dbmRowHeader + UserData */
                                         sRowHeadPlusRecSize,
                                         sRow,           /* commit, rollback 때 사용 */
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW ( sRC, ERR_DBM_WRITE_LOG );
        }

        RTF_POINT( "TBLMGR_INSERT_7" );

        sTmp = (dbmRowHeader*) g_pBuffer_mInsert;

        if ( !sTableObj->mNoMemloggingF )
        {
            sTmp->mSCN = INFINITE_SCN;
        }
        else
        {
            /***********************************************
             * mem nologging 모드일 때는 auto commit 처럼
             ***********************************************/
            mLogMgr->mGetSCN ( (long long*)&sTmp->mSCN );
        }
        sTmp->mRowSize = sData->mDataSize;

        memcpy_s ( sRow, g_pBuffer_mInsert, sRowHeadPlusRecSize );

        sRC = mHandleTrigger (DBM_EVENT_INSERT ,
                              aTransID,
                              sData->mUserData,
                              sData->mDataSize ) ;
        _IF_THROW ( sRC , ERR_DBM_TRIGGER_FAIL );

        if ( sTableObj->mNoMemloggingF )
        {
            sRow->mLock = -1;
        }
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_DUP_ERROR )
        {
            _CATCH_TRC; // DUP 오류는 인덱스에서 찍었다. DBG이지만.
        }
        else if ( _rc == ERR_DBM_WRITE_LOG )
        {
            DBM_ERR( "mWriteMemLog log fail. log_type [%d]", sLogType );
            _CATCH_ERR;
        }
        else
        {
            _CATCH_WARN;
        }

        if ( sTableObj->mNoMemloggingF )
        {
            /***********************************************
             * mem nologging 모드일 때 insert key 도중에 fail 나면
             * 복구가 불가능하다.
             * 이 때는 그냥 table drop & create 가 상책이다.
             * 그 이외의 것은 아래처럼 복구.
             ***********************************************/
            if ( sRow != NULL )
            {
                if ( sAllocSlot != -1 )
                {
                    dbmSegFreeSlot ( mSegMgr, sAllocSlot, 0 );
                }
                sRow->mRowSize = 0;
                sRow->mLock = -1;
            }
        }
    }
    _FINALLY
    _END
} /* mInsert */


/******************************************************************************
 * Name : mDelete
 *
 * Description
 *     insert operation
 *
 ******************************************************************************/
__thread char* g_sBeforeImage_mDelete = NULL;
__thread char* g_sReadBuffer_mDelete = NULL;

_VOID dbmTableManager::mDelete( int             aTransID,
                                void*           aDataObject,
                                dbmTransHeader* aTxHead,
                                long long*      aBackLogPos,
                                long long*      aBackImagePos )
{
    int             sLogType = -1;
    int             sRowSize   = 0;
    int             sRetryCnt = 0;
    int             sRC;
    int             sIndexKeySize = 0;
    int             sIndexFirst = 0;
    long long       sSlotID = -1;
    long long       sRetrySlotID = -1;
    long long       sIndexSlotID = -1;
    long long       sExtraKey = -1;                 // non-unique type bucket value
    long long       sCurrExtraKey = -1;             // non-unique type bucket value
    long long       sIDX2CurrExtra = -1;             // non-unique type bucket value
    long long       sIDX2NextExtra = -1;
    long long       sBeforeExtraKey = -1;
    long long       sDeleteExtraKey = -1;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE];      // non-unique type check value 8 byte 2014.05.30 -shw-
    char            sRetryKey[DBM_NON_UNIQUE_KEY_SIZE];
    char            sNextKey[DBM_NON_UNIQUE_KEY_SIZE];

    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    dbmIndexHeader* sIndexHead = NULL;
    dbmRowHeader*   sRow = NULL;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmLogHeader*   sLogHead = NULL;
    dbmIndexObject* sIndex   = NULL;

    _TRY
    {
        /***********************************************
         * Big Stack 변수 제거
         ***********************************************/
        if ( unlikely( g_sBeforeImage_mDelete == NULL ) )
        {
            g_sBeforeImage_mDelete = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            memset_s ( g_sBeforeImage_mDelete, 0, DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }

        if ( unlikely( g_sReadBuffer_mDelete == NULL ) )
        {
            g_sReadBuffer_mDelete = (char*) malloc_s ( DBM_MAX_RECORD_SIZE );
            memset_s ( g_sReadBuffer_mDelete, 0, DBM_MAX_RECORD_SIZE );
        }

        /***********************************************
         * Trigger 체크 이미 삭제되었을 수도 있음.
         **********************************************/
        if ( unlikely( mTrigger != NULL ) )
        {
            /** 만약 헤더에 Trigger 가 없다 */
            if ( mTableHeader->mEventQueue[0] == '\0' )
            {
                mTrigger = NULL;
            }
        }

        /***********************************************
         * User Data 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize,
                   ERR_DBM_INVALID_RECORD_SIZE );


        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID,
                   ERR_DBM_INVALID_OBJECT );


        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE,
                   ERR_DBM_INVALID_TABLE_TYPE );


        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mTableHeader->mIndexCount <= 0,
                   ERR_DBM_NO_INDEX_IN_TABLE );


        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectDelete() 함수 호출
         ***********************************************/
        if ( sTableObj->mTableType == DBM_TBL_DIRECT )
        {
            return mDirectDelete( aTransID, aDataObject );      // _RETURN 아님
        }


        /***********************************************
         * delete 할 Row 존재하는지 검사.
         ***********************************************/

        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader();
        _CALL( mMakeKey( &sIndexHead->mIndex, sData->mUserData, sKey ) );

retry:
        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            sRC = mIndex[mUseIndex]->mSearchKey( aTransID, sKey, &sSlotID );
            sExtraKey = -1;
        }
        else
        {
            sBeforeExtraKey = sExtraKey;
            sRC = mIndex[mUseIndex]->mSearchKeyNu( aTransID, sKey, &sSlotID , &sExtraKey );
            memcpy_s ( sRetryKey, sKey, sIndexHead->mIndex.mKeySize );
        }

        if ( sRC == ERR_DBM_KEY_NOT_EXIST )
        {
            _THROW( ERR_DBM_NO_MATCH_RECORD );
        }
        _IF_THROW( sRC || sSlotID < 0, sRC );

        sRC = mSegMgr->Slot2Addr( sSlotID, &sRow );
        _IF_THROW( sRC, sRC );

        /***********************************************
         * Row Lock
         *   1. Logging( DBM_LOCK_ROW_LOG )
         *   2. Row Lock 수행
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_LOCK_ROW_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         NULL,
                                         0,
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW ( sRC != 0, ERR_DBM_WRITE_LOG );
        }




        RTF_POINT("TBLMGR_DELETE_1");

        sRC = mRowLock( sTableObj->mInstName,
                        sSlotID,
                        sRow,
                        g_sBeforeImage_mDelete,
                        aTransID,
                        1 );

        if ( sRC == ERR_DBM_ABNORMAL_ROLLBACK )
        {
            DBM_WARN("delete abnormal rollback. txid[%d] table[%s] slot[%ld]",
                            aTransID, sTableObj->mTableName, sSlotID );
            if ( ! sIndexHead->mIndex.mIsUniqueIndex )
            {
                sExtraKey = sBeforeExtraKey;
            }
            goto retry;
        }
        _IF_THROW( sRC == ERR_DBM_DEADLOCK_DETECTED , ERR_DBM_DEADLOCK_DETECTED ) ;
        _IF_THROW( sRC == ERR_DBM_NO_MATCH_RECORD, ERR_DBM_NO_MATCH_RECORD );
        _IF_THROW( sRC && (sRC != ERR_DBM_ABNORMAL_ROLLBACK), ERR_DBM_ROW_LOCK );

        /* 2015.07.17 -shw- Key  관련 동시성 제어를 위해 수정 
         * : T1 : Key1 (unique) , key2 (unique) --> 1 1
         * session 1: key 1 조건으로 key2에 대한 update
         * session 2: key 2 조건으로 deelte (session1 commit 전으로 lock 대기)
         * session 1 : commit
         * session 2 : lock을 풀리고 난후 보면 session1에서 key 변경 된 값임에도
         * 불구하고 기존의 select 한 값으로 delete 하게 되어서 success가 되어 버림
         * 이에 lock을 풀고 난후 다시 한번 기존의 key값을로 데이터가 있는지 검색 */
        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            sRC = mIndex[mUseIndex]->mSearchKey( aTransID, sKey, &sRetrySlotID );
            sExtraKey = -1;
        }
        else
        {
            /* 기존에 들어왔떤 ExtarKey로 move */
            sExtraKey = sBeforeExtraKey;
lock_retry:
            /* sBeforeExtraKey key는 이미 있음. 다시검색 */
            sRC = mIndex[mUseIndex]->mSearchKeyNu( aTransID, sKey, &sRetrySlotID , &sExtraKey, &sCurrExtraKey );
            memcpy_s ( sRetryKey, sKey, sIndexHead->mIndex.mKeySize );
        }

        if ( sRC == ERR_DBM_KEY_NOT_EXIST )
        {
            /* 혹시 오류가 나면 recovery를 해야 하기 때문에 loging 값을 넣어 주어야 한다 */
            *aBackLogPos   = aTxHead->mLogCurPos;
            *aBackImagePos = aTxHead->mImageCurPos;

            /* 참고 : ERROR cord를 ERR_DBM_NO_MATCH_RECORD 주면 자기 session이 죽어야지만
             * 해당 rolllback을 할 수 있기 때문에 바로 PartialRollback 하기 위해 아래의 
             * error code로 바꾼다. */
            _THROW( ERR_DBM_LOCK_NO_MATCH_RECORD );
        }

        if( sSlotID != sRetrySlotID )
        {
            if( sIndexHead->mIndex.mIsUniqueIndex == DBM_NON_UNIQUE && sExtraKey != -1 )
            {
                goto lock_retry;
            }
            else
            {
                *aBackLogPos   = aTxHead->mLogCurPos;
                *aBackImagePos = aTxHead->mImageCurPos;
                _THROW( ERR_DBM_LOCK_NO_MATCH_RECORD );
            }
        }

        /* lock 성공 후 보니 data 없으면 delete 된 것임 */
        _IF_THROW( sRow->mRowSize == 0, ERR_DBM_NO_MATCH_RECORD );

        RTF_POINT("TBLMGR_DELETE_2");

        /***********************************************
         * 모든 Index 에 Delete Key Logging 작업.
         * 실제 Delete Key 작업은 commit 시에 수행.
         * User 가 준 Key 값외에 다른 index key 들도 추출하기 위해
         * record 전체를 한번 읽어야 함.
         ***********************************************/
        memcpy_s( g_sReadBuffer_mDelete,
                  ((char*)sRow + sizeof(dbmRowHeader)),
                  sRow->mRowSize );

        for ( int i = 0; i < mIndexCount; i++ )
        {
            sIndex = &mTableHeader->mIndex[i];

            _CALL( mMakeKey( sIndex, g_sReadBuffer_mDelete, sKey ) );



            /* 2015.04.23 -shw
               : unique index & non-nunique index 생성 후 unique index
               삭제하게 되면 해당 non unique index와의 관계가 연결 되어
               있지 않기에 삭제 되는 slot이 어긋나게 된다.
               이에 정확하게 수정 하려면 unique inex -non unique 처리시 
               unqiey index 처리 할 때 non unique extra value을 같이 저장
               하여 관계를 맺는 방법으로 수정을 하면 된다. 하지만 전체
               구조를 다시 고쳐야 되기 때문에 일단 조회로 연결 관계를
               맺게 처리 한다. */
//            if ( sIndexHead->mIndex.mIsUniqueIndex  && 
//                 memcmp_s ( sIndexHead->mIndex.mTableName, "$sys", 4  ))
            //if ( memcmp_s ( sIndexHead->mIndex.mTableName, "$sys", 4  ) )
            //{
                sIDX2NextExtra = -1;

                /***********************************************
                 * 변경자 : wind * 변경일 : 15.10.23 * 참고 : #1004
                 * 변경 내용 : NU인덱스에서 slotid를 무조건 비교하게 하고 extrakey 값도 항상 저장하게 한다.
                 * 변경하면서 절차를 간소화 하였다.
                 ***********************************************/
                /***********************************************
                 * 변경자 : wind * 변경일 : 15.10.27 * 참고 : #1004
                 * 변경 내용 : NU인덱스 처리 시 mUseIndex도 같은 방식으로 처리 해야 한다.
                 ***********************************************/
#if 0
                if ( sIndex->mIsUniqueIndex == DBM_NON_UNIQUE )
                {
                    if ( mUseIndex != i )
                    {
Index_retry:
                        _CALL ( mIndex[i]->mSearchKeyNu( aTransID, sKey, &sIndexSlotID , &sIDX2NextExtra, &sIDX2CurrExtra ) );
                        if ( sSlotID == sIndexSlotID )
                        {
                            sLogType = DBM_DELETE_INDEX_LOG2;
                            sIndexKeySize = sIndex->mKeySize + 8;
                            *(long long*) ( sKey + sIndex->mKeySize ) = sIDX2CurrExtra;
                        }
                        else
                        {
                            if( sIDX2NextExtra == -1 )
                            {
                                DBM_CERR("The slot id does not exist in another index. slot_id=[%lld]", sSlotID );
                                _THROW ( ERR_DBM_INVALID_KEY );
                            }
                            goto Index_retry;
                        }
                    }
                    else
                    {
                        sLogType = DBM_DELETE_INDEX_LOG2;
                        sIndexKeySize = sIndex->mKeySize + 8;
                        *(long long*) ( sKey + sIndex->mKeySize ) = sCurrExtraKey;
                    }
                }
                else
                {
                    sLogType = DBM_DELETE_INDEX_LOG;
                    sIndexKeySize = sIndex->mKeySize;
                }
#endif
                if ( sIndex->mIsUniqueIndex == DBM_NON_UNIQUE )
                {
                    sLogType = DBM_DELETE_INDEX_LOG2;
                    sIndexKeySize = sIndex->mKeySize + 8;
                    *(long long*) ( sKey + sIndex->mKeySize ) = SLOT2EXTRA( sSlotID );
                }
                else
                {
                    sLogType = DBM_DELETE_INDEX_LOG;
                    sIndexKeySize = sIndex->mKeySize;
                }
            //}


            RTF_POINT("TBLMGR_DELETE_3");

            if ( ! sTableObj->mNoMemloggingF )
            {
                sRC = mLogMgr->mWriteMemLog( sLogType,
                                             aTransID,
                                             sIndex->mIndexID,
                                             sIndex->mIndexName,
                                             mTableName,
                                             sSlotID,
                                             sKey,
                                             sIndexKeySize,
                                             mIndex[i]->mGetIndexHeader(),
                                             mIndex[i]->mGetIndexHeader(),
                                             &sLogHead );
                _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
            }
            else
            {
                // logging 모드가 아닐 때는 바로 delete 해버림.
                if ( sIndex->mIsUniqueIndex == DBM_UNIQUE )
                {
                    _CALL( mIndex[i]->mDeleteKey( aTransID, sKey ) );
                }
                else
                {
                    _CALL( mIndex[i]->mDeleteKey( aTransID, sKey, 1 ) );
                }
            }

            RTF_POINT("TBLMGR_DELETE_4");
        } /* for */


        /***********************************************
         * Before Image Logging
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_DELETE_DATA_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         g_sBeforeImage_mDelete,
                                         sRow->mRowSize + sizeof(dbmRowHeader),
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        RTF_POINT("TBLMGR_DELETE_5");


        /***********************************************
         * Commit 때 FreeSlot 을 위해서 Logging
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_DELETE_SLOT_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         NULL,
                                         0,
                                         mTableHeader,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }
        else
        {
            /***********************************************
             * nologging 모드일 때는 slot 도 바로 free
             ***********************************************/
            sRC = dbmSegFreeSlot( mSegMgr, sSlotID, 0 );
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );    // 2014.12.14. -okt- 오류코드 바꾸기.
        }

        RTF_POINT("TBLMGR_DELETE_6");


        /***********************************************
         * Row 를 다른 놈이 읽지 못하게 INFINITE 로 변경하고,
         * 데이터는 NULL 로 기록해버림
         ***********************************************/
        sRowSize = sRow->mRowSize;

        if ( ! sTableObj->mNoMemloggingF )
        {
            RTF_POINT("TBLMGR_DELETE_7");

            sRow->mSCN     = INFINITE_SCN;

            RTF_POINT("TBLMGR_DELETE_8");

            sRow->mRowSize = 0;

            RTF_POINT("TBLMGR_DELETE_9");
        }
        else
        {
            sRow->mSCN     = 0;
            sRow->mRowSize = 0;
        }

        // 그냥둔다. delete 좀 늦어도 된다.
        //memset_s( (char*)sRow + sizeof( dbmRowHeader ), 0x00, sRowSize );

        if ( unlikely( mTrigger != NULL ) )
        {
            sRC = mHandleTrigger (DBM_EVENT_DELETE,
                            aTransID ,
                            g_sBeforeImage_mDelete + sizeof (dbmRowHeader) ,
                            sRowSize );

            _IF_THROW ( sRC , ERR_DBM_TRIGGER_FAIL ) ;
        }

        sRetryCnt++;

        /* non-unique index delete 한꺼번에 처리 하기 위하여 동일키에 대한 여러건을 로깅한다 */
        /* 2014.05.30 -shw- */
        if ( sExtraKey != -1 )
        {

            /* 마지막 이미지를 기록하여 해당 이미지값을 가지고 리커버리 해야 하기 때문에
             * 맨 마지막 까지 처리 한 값을 백업해 놓는다 */
            /* 이전 이미지 값을 백업해 놓는다. */
            *aBackLogPos   = aTxHead->mLogCurPos;
            *aBackImagePos = aTxHead->mImageCurPos;


            /* 2015.04.24 -shw- 
               : non-unique idnex -> unique inex 생성 시 retry 하게 되면
                 unique inex segment 에서 key 값을 변경 하기 때문에 기존에
                 copy 해두었던 값을 move 해준다 */
            memcpy_s ( sKey, sRetryKey, sIndexHead->mIndex.mKeySize );

            goto retry;
        }

        if ( ! sIndexHead->mIndex.mIsUniqueIndex )
        {
            /* non-unique index count move */
            sData->mIndexCount = sRetryCnt;
        }

        if ( sTableObj->mNoMemloggingF )
        {
            /***********************************************
             * mem nologging 모드일 때는 commit 때가 아니라
             * 여기에서 lock 을 풀어버림.
             ***********************************************/
            sRow->mLock = -1;
        }
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_DBG;
        }
        else
        {
            if ( sTableObj->mNoMemloggingF )
            {
                /***********************************************
                 * mem nologging 모드일 때는 실패해도 자꾸
                 * 재시도할 수 있도록.
                 ***********************************************/
                if ( sRow != NULL )
                {
                    sRow->mSCN     = 0;
                    sRow->mRowSize = 0;
                    sRow->mLock    = -1;
                }
            }

            if ( _rc == ERR_DBM_WRITE_LOG )
            {
                DBM_CERR("write log fail. log_type [%d]", sLogType );
            }
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* mDelete */


_VOID dbmTableManager::mDirectInsert ( int aTransID , void* aDataObject )
{
    dbmDataObject*  sData = (dbmDataObject*) aDataObject;
    dbmRowHeader*   sRow = NULL;
    dbmRowHeader*   sTmp = NULL;
    dbmRowHeader    sTmpRow;
    dbmTableObject* sTableObj = &mTableHeader->mTableObj;
    dbmLogHeader*   sLogHead = NULL;
    dbmColumnType   sKeyColumnType;
    char    sKey[DBM_INDEX_KEY_MAX_SIZE];
    long long sAllocSlot = -1;
    long long sSCN;
    int     sLogType;
    int     sRC;

    _TRY
    {
        /***********************************************
         * Big Stack 변수 제거
         ***********************************************/
        if ( unlikely( g_pBuffer_mInsert == NULL ) )
        {
            g_pBuffer_mInsert = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            memset_s ( g_pBuffer_mInsert, 0, DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }

#ifdef _DEBUG   // mInsert, 상위단에서 검사
        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_DIRECT 아니면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType != DBM_TBL_DIRECT &&
                   sTableObj->mTableType != DBM_TBL_SEQUENCE ,
                   ERR_DBM_INVALID_TABLE_TYPE );
#endif

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * User Data 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE ); // INVALID_RECORD_SIZE );
        /***********************************************
         * 주어진 record size 가 index key 보다 작음.
         ***********************************************/
        _IF_THROW( sData->mDataSize < mTableHeader->mIndex[0].mKeySize, ERR_DBM_INVALID_RECORD_SIZE );

        /***********************************************
         * User Data 에서 Key 를 만드는데, 그 Key 값이
         * 곧 Slot 번호가 된다.
         *
         * Get Slot ID
         *   1. User Data 로부터 Key 추출
         *   2. Key Column Type 에 따라 추출한 Key 값을 Slot ID 로 변경
         *   3. mMaxSize 로 modular
         *   4. Table Segment 의 현재 할당 공간에서 최대 Slot ID 값과
         *      비교하여 이보다 큰 Slot ID 이면 Segment 확장.
         ***********************************************/
        _CALL( mMakeKey ( &mTableHeader->mIndex[0], sData->mUserData, sKey ) );

        sKeyColumnType = mTableHeader->mIndex[0].mKey[0].mColumnType;

        sRC = dbmChgDirectKey2SlotID ( sKeyColumnType, sKey, &sAllocSlot );
        if ( sRC ) //, CHANGE_KEY_2_SLOTID );
        {
            DBM_ERR( "fail to change made key to slotid for direct table(%s). type[%d]", mTableName, sKeyColumnType );
            _THROW( ERR_DBM_INVALID_COLUMN_TYPE );
        }

        /*
         * 2014.12.14. -okt- (성능) 최대건수를 제한하는 사용자 max와, 내부적으로 mod연산을 위한 mMaxInt를 두면 direct 테이블은 부작용없이 가능하다.
         */
        sAllocSlot = sAllocSlot % sTableObj->mMaxSize;

        // by lim272
        // Index Key column에 의해 slot이 정해진다면
        // 해당 slot이 음수가 되어서는 안된다. 실제로도 할당되지 못하고
        // 할당되어도 slot_id = -1 과 같은 문제가 있는 상태임으로 이를 아예 하지 못하게 방어한다.
        _IF_THROW (sAllocSlot < 0, ERR_DBM_INVALID_SLOT_FOR_DIRECT_TBL);

        /***********************************************
         * Direct Table 은 AllocSlot 과정이 없기 때문에
         * Table Manager 가 직접 Segment 를 Extend 함.
         * 갑자기 확 건너뛰는 key 가 들어오면
         * extend 를 여러번 해야할 수 있다.
         ***********************************************/
        while ( sAllocSlot > mSegMgr->GetLastExtendSlotNo ( ) )
        {
            sRC = mSegMgr->Extend ( );
            if ( sRC ) //, EXTEND_SEG_FAIL );
            {
                DBM_ERR( "table(%s) segment extend fail. rc(%d) cur_slot(%ld) last_seg_slot(%ld)",
                         mTableName, sRC, sAllocSlot, mSegMgr->GetLastExtendSlotNo() );
                _THROW( sRC );
            }

        }

        // #63 DIRECT 테이블에 대한 사용량 출력을 위해 추가코드, 락이없어 부정확 - 2014/09/16 (OKT)
        _CALL( mSegMgr->SetAlloc ( sAllocSlot ) );

        sRC = mSegMgr->Slot2Addr ( sAllocSlot, &sRow );
        _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT );

        /***********************************************
         * RowSize 가 0 이 아니면 이미 Data 가 있는 것으로
         * Dup 처리를 한다.
         * Direct Table 은 실제 Index 가 존재하지 않기 때문에
         * 이렇게 Dup 처리를 한다.
         ***********************************************/
        _IF_THROW( sRow->mRowSize > 0, ERR_DBM_DUP_ERROR );

        /***********************************************
         * Row Lock
         *   1. Logging( DBM_LOCK_ROW_LOG )
         *   2. Row Lock 수행 (Lock 잡은 상태의 Row Header 를
         *      sTmpRow 에 저장)
         *
         * Direct Table 의 경우 사용자가 준 Key 를 이용하여
         * 이를 Slot ID 로 삼기 때문에 AllocSlot 과정이 없다.
         * 이 말은 일반테이블처럼 AllocSlot 후에 Row->mLock 변수를
         * -1 로 Clear 시켜주는 시점이 별도로 없다는 말이다.
         * 따라서, mLock 의 초기값은 -1 이어야 하므로
         * Segment Manager 에서 Segment 를 만들면 모든 Slot
         * 영역을 -1 로 Clear 하도록 했다. (변경 전은 0)
         * 이렇게 하면 아래의 RowLock 에 맨처음 접근하는 놈은
         * mLock 값이 -1 이라는 보장이 된다.
         ***********************************************/
        if ( !sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_LOCK_ROW_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mTableName, NULL, sAllocSlot,
                                          NULL,
                                          0, sRow, /* commit, rollback 때 사용 */
                                          mTableHeader, &sLogHead );
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        RTF_POINT( "TBLMGR_DIRECT_INSERT_1" );

        sRC = mRowLock ( sTableObj->mInstName, sAllocSlot, sRow, (char*) &sTmpRow, aTransID, 0 );
        //_IF_RAISE ( sRC == ERR_DBM_DEADLOCK_DETECTED, DEAD_LOCK );
        if ( sRC == ERR_DBM_DEADLOCK_DETECTED )
        {
            return ERR_DBM_DEADLOCK_DETECTED;   // 의도적
        }

        //_IF_RAISE( sRC && (sRC != ERR_DBM_ABNORMAL_ROLLBACK), ROW_LOCK_FAIL );
        if ( sRC && ( sRC != ERR_DBM_ABNORMAL_ROLLBACK ) ) //, ROW_LOCK_FAIL );
        {
            DBM_ERR( "lock row fail. TxID[%d] table[%s] rowslot[%ld] sRC[%d]",
                     aTransID,
                     mTableHeader->mTableObj.mTableName,
                     sAllocSlot,
                     sRC );
            _THROW( sRC );
        }

        RTF_POINT( "TBLMGR_DIRECT_INSERT_2" );

        /***********************************************
         * Lock 거는 사이 다른 놈이 이미 썼을 수 있음.
         ***********************************************/
        _IF_THROW( sRow->mRowSize > 0, ERR_DBM_DUP_ERROR );

        /***********************************************
         * Record 삽입
         *   1. logging( DBM_INSERT_SLOT_LOG )
         *   2. Record 복사
         ***********************************************/
        memcpy_s ( g_pBuffer_mInsert, &sTmpRow, sizeof(dbmRowHeader) );

        memcpy_s ( g_pBuffer_mInsert + sizeof(dbmRowHeader), sData->mUserData, sData->mDataSize );

        if ( !sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_INSERT_SLOT_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType, aTransID, mTableID, mTableName, NULL, // mTableName,
                                          sAllocSlot,
                                          g_pBuffer_mInsert, /* dbmRowHeader + UserData */
                                          sData->mDataSize + sizeof(dbmRowHeader),
                                          sRow, /* commit, rollback 때 사용 */
                                          mTableHeader,
                                          &sLogHead );
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        RTF_POINT( "TBLMGR_DIRECT_INSERT_3" );

        sTmp = (dbmRowHeader*) g_pBuffer_mInsert;

        if ( !sTableObj->mNoMemloggingF )
        {
            sTmp->mSCN = INFINITE_SCN;
        }
        else
        {
            /***********************************************
             * mem nologging 모드일 때는 auto commit 처럼
             ***********************************************/
            mLogMgr->mGetSCN ( &sSCN );
            sTmp->mSCN = sSCN;
        }
        sTmp->mRowSize = sData->mDataSize;

        memcpy_s ( (char*)sRow, g_pBuffer_mInsert, sData->mDataSize + sizeof(dbmRowHeader) );

        /* sequence type은 trigger 적용할 수 없다. 2015.03.16 -shw- */
        if ( sTableObj->mTableType != DBM_TBL_SEQUENCE )
        {
            sRC = mHandleTrigger ( DBM_EVENT_INSERT, aTransID, sData->mUserData, sData->mDataSize );
            _IF_THROW( sRC , ERR_DBM_TRIGGER_FAIL );
        }

        if ( sTableObj->mNoMemloggingF )
        {
            sRow->mLock = -1;
        }
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_WRITE_LOG )
        {
            DBM_ERR( "mWriteMemLog log fail. log_type [%d]", sLogType );
            _CATCH_ERR;
        }
        else
        {
            _CATCH_WARN;
        }

        if ( sTableObj->mNoMemloggingF )
        {
            /***********************************************
             * mem nologging 모드일 때 insert key 도중에 fail 나면
             * 복구가 불가능하다.
             * 이 때는 그냥 table drop & create 가 상책이다.
             * 그 이외의 것은 아래처럼 복구.
             ***********************************************/
            if ( sRow != NULL )
            {
                if ( sAllocSlot != -1 )
                {
                    dbmSegFreeSlot ( mSegMgr, sAllocSlot, 0 );
                }
                sRow->mRowSize = 0;
                sRow->mLock = -1;
            }
        }
    }
    _FINALLY
    _END
} /* mDirectInsert */



/******************************************************************************
 * Name : mSelectLT
 *
 * Description
 *     select less than operation
 *
 ******************************************************************************/
_VOID dbmTableManager::mSelectLT ( int aTransID , void* aDataObject, int aDirtyFlag )
{
    int             sRC;
    long long       sSlotID = -1;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmIndexHeader* sIndexHead = NULL;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    dbmLogType      sLogType = DBM_LOG_TYPE_MAX;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE];     // non-unique type check value 8 byte 2014.05.30 -shw-
    char            sPrevKey[DBM_NON_UNIQUE_KEY_SIZE];
    char            sTempKey[DBM_NON_UNIQUE_KEY_SIZE];
    int             sInserted  = 0;
    int             sRetryCheck = 0;

    _TRY
    {
        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );


        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );


        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectFetchNextGT() 함수 호출
         ***********************************************/
        if ( unlikely( sTableObj->mTableType == DBM_TBL_DIRECT ) )
        {
            _CALL( mDirectSelectLT( aTransID, aDataObject ) );
            _RETURN;
        }

        /***********************************************
         * Initialize for Multi-Fetch variable
         ***********************************************/
        sData->mFetchCount = 0;
        sData->mFetchInd   = 0;
        memset_s ( sData->mFetchRows, 0x00, sizeof(sData->mFetchRows) );

        /***********************************************
         * Search Key 수행
         ***********************************************/

        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader();

        _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sKey ) );

retry:
        /* non-unique index 8byte 추가 */
        memset_s ( sPrevKey, 0x00, DBM_NON_UNIQUE_KEY_SIZE );

        /************************************************************
         * multi fetch
        ************************************************************/
        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            if ( sRetryCheck != 1 )
            {
                /* key copy */
                memcpy_s(mPkeyData, sKey, sIndexHead->mIndex.mKeySize);
            }

            //sRC = mIndex[mUseIndex]->mSearchKeyLT( aTransID, sKey, &sSlotID, sPrevKey ,aEQCnt);
            // 최초인 경우거나 이미 자기가 가져온걸 다 읽은 상태면
            // 다시 인덱스에게 요청해야 한다.
            if (sRetryCheck != 1 || (sRetryCheck == 1 && sData->mFetchInd == sData->mFetchCount) )
            {
                //기존에 slotid를 배열로 가져오던 것에 키도 배열로 받아오도록 변경
                sRC = mIndex[mUseIndex]->mSearchKeyLT ( aTransID, sKey, sData->mFetchRows, &sData->mFetchCount, sData->mFetchKey , sData->mEQCnt );
                mSelect_extrakey = -1;
                mSelect_curr_extrakey = 0;
                // 자신의 첫번째는 가져온 첫번째꺼지..
                sSlotID = sData->mFetchRows [0];
                memcpy_s( sPrevKey, sData->mFetchKey[0], DBM_NON_UNIQUE_KEY_SIZE );
            }
            else
            {
                // 0번은 이미 줬으니까 +1을 한 후 다음걸 리턴해줘야 한다.
                sData->mFetchInd++;
                // 근데 자기꺼를 이미 다 읽은 경우면 다시 Index에게 요청한다.
                // 이때 key는 이미 변수로 들어오니까 다시 key 는 조립된 상태다.
                if (sData->mFetchInd == sData->mFetchCount)
                {
                    //sData->mFetchInd++;
                    mSelect_extrakey   = -1;
                    sData->mFetchCount = 0;
                    sData->mFetchInd   = 0;
                    memset_s (sData->mFetchRows, 0x00, sizeof(sData->mFetchRows));
                    goto retry;
                }
                sSlotID = sData->mFetchRows [sData->mFetchInd];
                memcpy_s( sPrevKey, sData->mFetchKey[sData->mFetchInd], DBM_NON_UNIQUE_KEY_SIZE );

                // 실제 데이터를 접근해야 하는데 하기 직전이라 그냥 가라로 셋팅해버린다.
                //sPrevKey [0] = 'C';
                sRC = 0;
            }
        }
        else
        {
            if ( sRetryCheck != 1 )
            {
                mSelect_extrakey = -1;
            }

            sRC = mIndex[mUseIndex]->mSearchKeyLTNu( aTransID, sKey, &sSlotID, sPrevKey, &mSelect_extrakey, sData->mEQCnt );
            mSelect_curr_extrakey = 0;

        }
        _IF_THROW( sRC == ERR_DBM_KEY_NOT_EXIST, ERR_DBM_NO_MATCH_RECORD );
        _IF_THROW( sRC || sSlotID < 0, sRC /* SEARCH_KEY_FAIL */ );


        /***********************************************
         * sSlotID 를 이용하여 Record 를 읽는다.
         ***********************************************/
        sRC = mReadRecord( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted, aDirtyFlag, &sLogType );
        //만약에 읽어온 레코드가 undo에서 읽어왔는데 DBM_UPDATE_KEY_LOG에 의한 이미지이거나
        //내가 변경한 레코드라면 정상적인 로우인지 확인해 봐야한다.
        if( sLogType == DBM_UPDATE_KEY_LOG )
        {
            sLogType = DBM_LOG_TYPE_MAX;
            _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sTempKey ) );
            if( memcmp_s( sPrevKey, sTempKey, sIndexHead->mIndex.mKeySize ) )
            {
                sRC = ERR_DBM_NO_MATCH_RECORD;
            }
        }

        if ( sInserted )
        {
            //memset_s( sKey, 0x00, DBM_INDEX_KEY_MAX_SIZE );
            memcpy_s( sKey, sPrevKey, DBM_INDEX_KEY_MAX_SIZE );
            sInserted = 0;
            sRetryCheck = 1;
            goto retry;
        }
        if ( unlikely( sRC == ERR_DBM_NO_MATCH_RECORD && sPrevKey[0] != 0x00 ) )
        {
            //memset_s ( sKey, 0x00, sizeof(sKey) );
            memcpy_s ( sKey, sPrevKey, sizeof(sKey) );
            sRetryCheck = 1;
            goto retry;
        }
        _IF_THROW( sRC == ERR_DBM_NO_MATCH_RECORD, ERR_DBM_NO_MATCH_RECORD );
        _IF_THROW( sRC, sRC /* READ_RECORD_FAIL */ );

    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }

        // mReadRecord에서 정상적이라면 dirty일때 mFetchScn이 LONG_MAX가 되어야 한다.
        // 근데 위의 코드에 mReadRecord 오기전부터 여기로 빠지는 경우가 있네..
        // 그래서 그냥 강제로 여기서 박는다.
        if (aDirtyFlag == DBM_DIRTY_ON)
        {
            mFetchScn = LONG_MAX;
        }
        else
        {
            mLogMgr->mPeekSCN( &mFetchScn );
        }
    }
    _FINALLY
    _END
} /* mSelectLT */


// memset을 없애기 위한 쓰레드 변수
__thread char* g_pBeforeImage = NULL;

_VOID dbmTableManager::mSelectForUpdate ( int             aTransID,
                                          void*           aDataObject,
                                          dbmTransHeader* aTxHead,
                                          long long*      aBackLogPos,
                                          long long*      aBackImagePos )
{
    long long       sSlotID     = -1;
    long long       sRetrySlotID = -1;
    int             sLogType    = DBM_LOG_TYPE_MAX;
    dbmDataObject*  sData       = (dbmDataObject*)aDataObject;
    dbmRowHeader*   sRow        = NULL;
    dbmLogHeader*   sLogHead    = NULL;
    dbmTableObject* sTableObj   = &mTableHeader->mTableObj;
    dbmIndexHeader* sIndexHead  = NULL;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE]; // non-unique type check value 8 byte 2014.05.30 -shw-
    long long       sExtraKey   = -1;                 // non-unique type bucket value
    long long       sBeforeExtraKey = -1;

    _TRY
    {
        if ( g_pBeforeImage == NULL )
        {
            g_pBeforeImage = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );

            memset_s ( g_pBeforeImage,
                       0,
                       DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectDelete() 함수 호출
         ***********************************************/
        if ( sTableObj->mTableType == DBM_TBL_DIRECT ||
             sTableObj->mTableType == DBM_TBL_SEQUENCE )
        {
            _CALL( mDirectSelectForUpdate ( aTransID, aDataObject ) );
            _RETURN;
        }


        /***********************************************
         * update 할 Row 존재하는지 검사.
         ***********************************************/
        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader ( );
        _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sKey ) );

retry:
        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            _rc = mIndex[mUseIndex]->mSearchKey( aTransID, sKey, &sSlotID );
            sExtraKey = -1;
        }
        else
        {
            sBeforeExtraKey = sExtraKey;
            _rc = mIndex[mUseIndex]->mSearchKeyNu( aTransID, sKey, &sSlotID , &sExtraKey );
        }

        if ( _rc != 0 )
        {
            _IF_THROW( _rc == ERR_DBM_KEY_NOT_EXIST, ERR_DBM_NO_MATCH_RECORD );
            _THROW( _rc );
        }
        else if ( sSlotID < 0 )
        {
            DBM_WARN( "mSearchKey SlotID=%d", sSlotID );
            _THROW( -1 );
        }

        _rc = mSegMgr->Slot2Addr( sSlotID, &sRow );
        _IF_THROW( _rc, ERR_DBM_ALLOC_SLOT );


        /***********************************************
         * Row Lock
         *   1. Logging( DBM_LOCK_ROW_LOG )
         *   2. Row Lock 수행
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_LOCK_ROW_LOG;
            _rc = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         NULL,
                                         0,
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW( _rc, ERR_DBM_WRITE_LOG );
        }

        _rc = mRowLock( sTableObj->mInstName,
                        sSlotID,
                        sRow,
                        g_pBeforeImage,
                        aTransID,
                        0 );

        if ( _rc == ERR_DBM_ABNORMAL_ROLLBACK )
        {
            DBM_WARN( "update abnormal rollback. txid[%d] table[%s] slot[%ld] (err=%d,tid=%d)",
                            aTransID, mTableName, sSlotID, errno, gettid_s() );
            if ( ! sIndexHead->mIndex.mIsUniqueIndex )
            {
                sExtraKey = sBeforeExtraKey;
            }

            goto retry;
        }
        else if ( _rc != 0 )
        {
            _IF_THROW( _rc == ERR_DBM_DEADLOCK_DETECTED, ERR_DBM_DEADLOCK_DETECTED ) ;
            _IF_THROW( _rc == ERR_DBM_NO_MATCH_RECORD, ERR_DBM_NO_MATCH_RECORD );
            _THROW( _rc );
        }

        /* 2015.07.17 -shw- Key  관련 동시성 제어를 위해 수정 
         * : T1 : Key1 (unique) , key2 (unique) --> 1 1
         * session 1: key 1 조건으로 key2에 대한 update
         * session 2: key 2 조건으로 deelte (session1 commit 전으로 lock 대기)
         * session 1 : commit
         * session 2 : lock을 풀리고 난후 보면 session1에서 key 변경 된 값임에도
         * 불구하고 기존의 select 한 값으로 delete 하게 되어서 success가 되어 버림
         * 이에 lock을 풀고 난후 다시 한번 기존의 key값을로 데이터가 있는지 검색 */
        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            _rc = mIndex[mUseIndex]->mSearchKey( aTransID, sKey, &sRetrySlotID );
            sExtraKey = -1;
        }
        else
        {
            /* 기존에 들어왔떤 ExtarKey로 move */
            sExtraKey = sBeforeExtraKey;
lock_retry:
            /* sBeforeExtraKey key는 이미 있음. 다시검색 */
            _rc = mIndex[mUseIndex]->mSearchKeyNu( aTransID, sKey, &sRetrySlotID , &sExtraKey );
        }

        if ( _rc == ERR_DBM_KEY_NOT_EXIST )
        {
            /* 혹시 오류가 나면 recovery를 해야 하기 때문에 loging 값을 넣어 주어야 한다 */
            *aBackLogPos   = aTxHead->mLogCurPos;
            *aBackImagePos = aTxHead->mImageCurPos;

            /* 참고 : ERROR cord를 ERR_DBM_NO_MATCH_RECORD 주면 자기 session이 죽어야지만
             * 해당 rolllback을 할 수 있기 때문에 바로 PartialRollback 하기 위해 아래의 
             * error code로 바꾼다. */
            _THROW( ERR_DBM_LOCK_NO_MATCH_RECORD );
        }

        if( sSlotID != sRetrySlotID )
        {
            if( sIndexHead->mIndex.mIsUniqueIndex == DBM_NON_UNIQUE && sExtraKey != -1 )
            {
                goto lock_retry;
            }
            else
            {
                *aBackLogPos   = aTxHead->mLogCurPos;
                *aBackImagePos = aTxHead->mImageCurPos;
                _THROW( ERR_DBM_LOCK_NO_MATCH_RECORD );
            }
        }

        /* lock 성공 후 보니 data 없으면 delete 된 것임 */
        _IF_THROW( sRow->mRowSize == 0, ERR_DBM_NO_MATCH_RECORD );

        /***********************************************
         * Before Image 를 logging 한다.
         * (Row Lock 으로 내 TxID 가 기록되었으므로
         *  만약 SelectForUpdate 가 끝나고 곧바로 다른 놈이
         *  Select 를 하면 mReadRecord 에서 Undo 를
         *  읽어야 하므로 Before Image Logging 필요)
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_SELECT_FOR_UPDATE_LOG;
            _rc = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         g_pBeforeImage,
                                         sRow->mRowSize + sizeof(dbmRowHeader),
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW( _rc, ERR_DBM_WRITE_LOG );
        }


        /***********************************************
         * 이미지를 읽어서 리턴
         ***********************************************/
        sRow->mSCN = INFINITE_SCN;

        memcpy_s( sData->mUserData, (char*)sRow + sizeof(dbmRowHeader), sRow->mRowSize );

        /* non-unique type -shw- 2014.05.30 */
        if ( sExtraKey != -1)
        {
            /* 이전 이미지 값을 백업해 놓는다. */
            *aBackLogPos   = aTxHead->mLogCurPos;
            *aBackImagePos = aTxHead->mImageCurPos;

            goto retry;
        }
    }
    _CATCH
    {
        if ( sTableObj->mNoMemloggingF )
        {
            if ( sRow != NULL )
            {
                sRow->mLock = -1;
            }
        }

#ifndef _DEBUG
        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            // 정상 로그 찍으면 성능튄다. (W)02:08:34.454193 12369 dbmTableManager mSelectForUpdat 1887 ERR-1027] Data not found. (err=0,tid=12369,l=1769)
            _CATCH_TRC;
        }
        else
#endif
        {
            if ( _rc == ERR_DBM_WRITE_LOG )
            {
                DBM_ERR( "write log fail. log_type[%d] table[%s]", sLogType, mTableName );
            }

            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mSelectForUpdate */


/******************************************************************************
 * Name : mSelectGT
 *
 * Description
 *     select greater than operation
 *
 ******************************************************************************/
_VOID dbmTableManager::mSelectGT ( int aTransID , void* aDataObject, int aDirtyFlag )
{
    int             sRC;
    long long       sSlotID = -1;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmIndexHeader* sIndexHead = NULL;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    dbmLogType      sLogType = DBM_LOG_TYPE_MAX;
    dbmRowHeader*   sRow = NULL;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE]; // non-unique type check value 8 byte 2014.05.30 -shw-
    char            sNextKey[DBM_NON_UNIQUE_KEY_SIZE];
    char            sTempKey[DBM_NON_UNIQUE_KEY_SIZE];
    int             sInserted  = 0;
    int             sRetryCheck = 0;

    _TRY
    {
        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );


        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );


        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );


        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectFetchNextGT() 함수 호출
         ***********************************************/
        if ( unlikely(sTableObj->mTableType == DBM_TBL_DIRECT ||
                      sTableObj->mTableType == DBM_TBL_SEQUENCE ) )
        {
            _CALL( mDirectSelectGT ( aTransID, aDataObject ) );
            _RETURN;
        }

        /***********************************************
         * Initialize for Multi-Fetch variable
         ***********************************************/
        sData->mFetchCount = 0;
        sData->mFetchInd   = 0;
        memset_s (sData->mFetchRows, 0x00, sizeof(sData->mFetchRows));

        /***********************************************
         * Search Key 수행
         ***********************************************/
        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader ( );

        _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sKey ) );

retry:
        memset_s ( sNextKey, 0x00, DBM_NON_UNIQUE_KEY_SIZE );

        /************************************************************
         * by lim272
         * 솔직히 변수의미들을 잘 모르겠다.
         * 다만, 다음과 같다.
         * Index로부터는 N개를 리턴받겠다.
         * 그래서 자신의 Handle내의 dataObject에 이걸 저장해둔다.
         * 그런후 Indicator변수를 +1씩 증가시키면서 리턴해준다고 보면 된다.
        ************************************************************/
        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            if ( sRetryCheck != 1 )
            {
                /* key copy */
                memcpy_s(mPkeyData, sKey, sIndexHead->mIndex.mKeySize);
            }

            //sRC = mIndex[mUseIndex]->mSearchKeyGT ( aTransID, sKey, &sSlotID, sNextKey , aEQCnt );
            // 최초인 경우거나 이미 자기가 가져온걸 다 읽은 상태면
            // 다시 인덱스에게 요청해야 한다.
            if ( sRetryCheck != 1 || (sRetryCheck == 1 && sData->mFetchInd == sData->mFetchCount) )
            {
                //기존에 slotid를 배열로 가져오던 것에 키도 배열로 받아오도록 변경
                sRC = mIndex[mUseIndex]->mSearchKeyGT ( aTransID, sKey, sData->mFetchRows, &sData->mFetchCount, sData->mFetchKey , sData->mEQCnt );
                mSelect_extrakey = -1;
                mSelect_curr_extrakey = 0;
                // 자신의 첫번째는 가져온 첫번째꺼지..
                sSlotID = sData->mFetchRows [0];
                memcpy_s( sNextKey, sData->mFetchKey[0], DBM_NON_UNIQUE_KEY_SIZE );
            }
            else
            {
                // 0번은 이미 줬으니까 +1을 한 후 다음걸 리턴해줘야 한다.
                sData->mFetchInd++;
                // 근데 자기꺼를 이미 다 읽은 경우면 다시 Index에게 요청한다.
                // 이때 key는 이미 변수로 들어오니까 다시 key 는 조립된 상태다.
                if ( sData->mFetchInd == sData->mFetchCount )
                {
                    mSelect_extrakey   = -1;
                    sData->mFetchCount = 0;
                    sData->mFetchInd   = 0;
#ifdef _DEBUG
                    // 2015.03.07 -okt- 매번 할 작업이 아니다.
                    memset_s (sData->mFetchRows, 0x00, sizeof(sData->mFetchRows));
#endif
                    goto retry;
                }
                sSlotID = sData->mFetchRows [sData->mFetchInd];
                memcpy_s( sNextKey, sData->mFetchKey[sData->mFetchInd], DBM_NON_UNIQUE_KEY_SIZE );

                // 코드를 보니까 nextKey가 있어야지만 된다.
                // 이건 Index가 리턴해주는데 이런 경우는 index로부터 읽는게 아니고
                // 실제 데이터를 접근해야 하는데 하기 직전이라 그냥 가라로 셋팅해버린다.
                //sNextKey [0] = 'C';
                sRC = 0;
            }
        }
        else
        {
            if ( sRetryCheck != 1 )
            {
                mSelect_extrakey = -1;
            }

            sRC = mIndex[mUseIndex]->mSearchKeyGTNu ( aTransID, sKey, &sSlotID, sNextKey ,&mSelect_extrakey, sData->mEQCnt );
            mSelect_curr_extrakey = 0;
        }

        _IF_THROW( sRC == ERR_DBM_KEY_NOT_EXIST, ERR_DBM_NO_MATCH_RECORD );
        _IF_THROW( sRC || sSlotID < 0, sRC /* SEARCH_KEY_FAIL */ );

        /***********************************************
         * sSlotID 를 이용하여 Record 를 읽는다.
         *  - 다른 놈이 새롭게 Insert 한 것이면 읽으면 안됨.
         *  - 내가 Delete 를 했다면 읽으면 안되고 다음 Key 로.
         ***********************************************/
        _CALL( mSegMgr->Slot2Addr ( sSlotID, &sRow ) );

#ifdef _DEBUG
        // 2015.03.07 -okt- 보장되어 있다.
        if ( sRow->mRowSize > 0 && sRow->mRowSize <= DBM_MAX_RECORD_SIZE )
        {
            memset_s ( sData->mUserData, 0x00, sRow->mRowSize );
        }
#else
        if ( sRow->mRowSize > 0 )
        {
            sData->mUserData[0] = 0x00;
        }
#endif

        sRC = mReadRecord ( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted, aDirtyFlag, &sLogType );
        //만약에 읽어온 레코드가 undo에서 읽어왔는데 DBM_UPDATE_KEY_LOG에 의한 이미지이거나
        //내가 변경한 레코드라면 정상적인 로우인지 확인해 봐야한다.
        if( sLogType == DBM_UPDATE_KEY_LOG )
        {
            sLogType = DBM_LOG_TYPE_MAX;
            _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sTempKey ) );
            if( memcmp_s( sNextKey, sTempKey, sIndexHead->mIndex.mKeySize ) )
            {
                sRC = ERR_DBM_NO_MATCH_RECORD;
            }
        }

        if ( unlikely( sInserted ) )
        {
            //memset_s ( sKey, 0x00, sizeof(sKey) );
            memcpy_s ( sKey, sNextKey, sizeof(sKey) );
            sInserted = 0;
            sRetryCheck = 1;
            goto retry;
        }

        if ( unlikely( sRC == ERR_DBM_NO_MATCH_RECORD && sNextKey[0] != 0x00 ) )
        {
            //memset_s ( sKey, 0x00, sizeof(sKey) );
            memcpy_s ( sKey, sNextKey, sizeof(sKey) );
            sRetryCheck = 1;
            goto retry;
        }

        _IF_THROW( sRC, sRC /* READ_RECORD_FAIL */ );

#ifdef _DEBUG
        //if ( sData->mDataSize < DBM_MAX_RECORD_SIZE )
        _DASSERT ( sData->mDataSize <= DBM_MAX_RECORD_SIZE );
#endif
       // {
       //     *(char*) ( (char*)sData->mUserData + sData->mDataSize ) = 0x00;
       // }
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
        // mReadRecord에서 정상적이라면 dirty일때 mFetchScn이 LONG_MAX가 되어야 한다.
        // 근데 위의 코드에 mReadRecord 오기전부터 여기로 빠지는 경우가 있네..
        // 그래서 그냥 강제로 여기서 박는다.
        if (aDirtyFlag == DBM_DIRTY_ON)
        {
            mFetchScn = LONG_MAX;
        }
        else
        {
            mLogMgr->mPeekSCN( &mFetchScn );
        }
    }
    _FINALLY
    _END
} /* mSelectGT */


_VOID dbmTableManager::mDirectSelectGT ( int aTransID , void* aDataObject )
{
    int             sRC;
    long long       sSlotID = -1;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmRowHeader*   sRow = NULL;
    dbmTableObject* sTableObj = &mTableHeader->mTableObj;
    char            sKey[DBM_INDEX_KEY_MAX_SIZE];
    int             sInserted  = 0;
    dbmColumnType   sKeyColumnType;

    _TRY
    {
        /***********************************************
         * User Data Key Size 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE );

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_DIRECT 가 아니면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType != DBM_TBL_DIRECT &&
                   sTableObj->mTableType != DBM_TBL_SEQUENCE,
                   ERR_DBM_INVALID_TABLE_TYPE );


        /***********************************************
         * 최초 Record Slot ID 획득
         *   1. User Data 로부터 Key 추출
         *   2. Key Column Type 에 따라 추출한 Key 값을 Slot ID 로 변경
         ***********************************************/
        _CALL( mMakeKey( &mTableHeader->mIndex[0], sData->mUserData, sKey ) );

        sKeyColumnType = mTableHeader->mIndex[0].mKey[0].mColumnType;

        /* 2014.09.12 -shw- GT일 경우에만 -1의 값이 올수 있도록 한다 */
        _rc = dbmChgDirectKey2SlotID ( sKeyColumnType, sKey, &sSlotID );
        if ( _rc ) //, CHANGE_KEY_2_SLOTID );
        {
            DBM_ERR( "fail to change made key to slotid for direct table(%s). type[%d], rc=%d", mTableName, sKeyColumnType, _rc );
            _THROW( ERR_DBM_INVALID_COLUMN_TYPE );
        }

        /* 2014.07.15 -shw- */
        /* 임시로 Key Copy 하여 Fetch Next LT, GT 에서 사용을 한다 */
        mSelect_curr_extrakey = 0;
        /* key copy */
        memcpy_s ( mPkeyData, sKey, mTableHeader->mIndex[0].mKeySize );

        /* 2014.09.12 -shw- direct table slot id -1이 올 수 있도록 한다. GT일 경우에만 */
        //_IF_RAISE( sSlotID < 0, NOT_FOUND );
        /* 2015.01.07 -shw-
         * : direct talbe  key 값은 -1이 올수 없다. 하지만 현재 key 보다 큰값을 가지고
         * 오려면 해당 GT에서 key값은 마이너스(-) 값으로 주어 GT로 조회 할 수 있다.
         * 이에 -2던, -1 이던 GT에서 key value가 -1로 오면 해당 값을 -1보다 큰값이라
         * 기준을 정하여 해당 SLOT ID값을 -1로 DEFINE 하도록 한다 */
        if ( unlikely( sSlotID < 0 ) )
        {
            sSlotID = -1;
        }

        sSlotID = sSlotID % sTableObj->mMaxSize;

        _IF_THROW( sSlotID > mSegMgr->GetLastExtendSlotNo ( ), ERR_DBM_NO_MATCH_RECORD );

        /***********************************************
         * sSlotID 를 이용하여 Record 를 읽는다.
         * Key 로 받은 sSlotID 다음 ID 부터 시작. (Greater Than)
         ***********************************************/
        sSlotID = sSlotID + 1;

        while ( 1 )
        {
            _IF_THROW( sSlotID > mSegMgr->GetLastExtendSlotNo ( ), ERR_DBM_NO_MATCH_RECORD );

            sRC = mSegMgr->Slot2Addr ( sSlotID, &sRow );
            if ( unlikely( sRC ) ) //, SLOT2ADDR_FAIL );
            {
                DBM_ERR( "fail to change slot to address. slot[%ld]", sSlotID );
                _THROW( ERR_DBM_SLOT2ADDR_FAIL );
            }

            if ( sRow->mRowSize > 0 )
            {
                memset_s ( sData->mUserData, 0x00, sRow->mRowSize );

                sRC = mReadRecord ( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted, DBM_DIRTY_OFF);
                /* 다른 tx 에 의해 신규 insert 된 것 */
                if ( sInserted )
                {
                    sSlotID = sSlotID + 1;
                    sInserted = 0;
                    continue;
                }

                _IF_THROW( sRC && (sRC != ERR_DBM_NO_MATCH_RECORD), sRC );

                //if ( sData->mDataSize < DBM_MAX_RECORD_SIZE )
                //{
                //    *(char*)((char*)sData->mUserData + sData->mDataSize) = 0x00;
                //}

                /* read done */
                break;
            }

            sSlotID = sSlotID + 1;
        }
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mDirectSelectGT */


_VOID dbmTableManager::mDirectFetchNextGT ( int aTransID , void* aDataObject )
{
    long long       sSlotID = -1;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmRowHeader*   sRow = NULL;
    dbmTableObject* sTableObj = &mTableHeader->mTableObj;
    char            sKey[DBM_INDEX_KEY_MAX_SIZE];
    int             sInserted  = 0;
    dbmColumnType   sKeyColumnType;
    int             sRC;

    _TRY
    {
        /***********************************************
         * User Data Key Size 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE );

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_DIRECT 가 아니면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType != DBM_TBL_DIRECT &&
                   sTableObj->mTableType != DBM_TBL_SEQUENCE ,
                   ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * 최초 Record Slot ID 획득
         *   1. User Data 로부터 Key 추출
         *   2. Key Column Type 에 따라 추출한 Key 값을 Slot ID 로 변경
         ***********************************************/
        _CALL( mMakeKey ( &mTableHeader->mIndex[0], sData->mUserData, sKey ) );

        sKeyColumnType = mTableHeader->mIndex[0].mKey[0].mColumnType;

        if ( mSelect_curr_extrakey != -1 )
        {
            sRC = dbmChgDirectKey2SlotID ( sKeyColumnType, mPkeyData, &sSlotID );
            mSelect_curr_extrakey = -1;
        }
        else
        {
            sRC = dbmChgDirectKey2SlotID ( sKeyColumnType, sKey, &sSlotID );
        }

        if ( sRC ) //, CHANGE_KEY_2_SLOTID );
        {
            DBM_ERR( "fail to change made key to slotid for direct table(%s). type[%d], rc=%d", mTableName, sKeyColumnType, sRC );
            _THROW( ERR_DBM_INVALID_COLUMN_TYPE );
        }

        // GT는 -1 보다 큰값을 가지고 조회 할 수 있으므로 아래 체크는 막는다 2015.01.05 -shw-
        //_IF_THROW( sSlotID < 0, ERR_DBM_NO_MATCH_RECORD );
        /* 2015.01.07 -shw-
         * : direct talbe  key 값은 -1이 올수 없다. 하지만 현재 key 보다 큰값을 가지고
         * 오려면 해당 GT에서 key값은 마이너스(-) 값으로 주어 GT로 조회 할 수 있다.
         * 이에 -2던, -1 이던 GT에서 key value가 -1로 오면 해당 값을 -1보다 큰값이라
         * 기준을 정하여 해당 SLOT ID값을 -1로 DEFINE 하도록 한다 */
        if ( unlikely( sSlotID < 0 ) )
        {
            sSlotID = -1;
        }

        sSlotID = sSlotID % sTableObj->mMaxSize;
        _IF_THROW( sSlotID > mSegMgr->GetLastExtendSlotNo ( ), ERR_DBM_NO_MATCH_RECORD );

        /***********************************************
         * sSlotID 를 이용하여 Record 를 읽는다.
         * Key 로 받은 sSlotID 다음 ID 부터 시작. (Greater Than)
         ***********************************************/
        sSlotID = sSlotID + 1;

        while(1)
        {
            _IF_THROW( sSlotID > mSegMgr->GetLastExtendSlotNo ( ), ERR_DBM_NO_MATCH_RECORD );

            sRC = mSegMgr->Slot2Addr ( sSlotID, &sRow );
            if ( unlikely( sRC ) ) //, SLOT2ADDR_FAIL );
            {
                DBM_ERR( "fail to change slot to address. slot[%ld]", sSlotID );
                _THROW( ERR_DBM_SLOT2ADDR_FAIL );
            }

            if ( sRow->mRowSize > 0 )
            {
                memset_s ( sData->mUserData, 0x00, sRow->mRowSize );

                sRC = mFetchReadRecord ( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted );
                /* 다른 tx 에 의해 신규 insert 된 것 */
                if ( sInserted )
                {
                    sSlotID = sSlotID + 1;
                    sInserted = 0;
                    continue;
                }

                _IF_THROW( sRC && (sRC != ERR_DBM_NO_MATCH_RECORD), sRC );

                //if ( sData->mDataSize < DBM_MAX_RECORD_SIZE )
                //{
                //    *(char*)((char*)sData->mUserData + sData->mDataSize) = 0x00;
                //}

                /* read done */
                break;
            }

            sSlotID = sSlotID + 1;
        }
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mDirectFetchNextGT */


_VOID dbmTableManager::mDirectSelectLT ( int aTransID , void* aDataObject )
{
    long long       sSlotID = -1;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmRowHeader*   sRow = NULL;
    dbmTableObject* sTableObj = &mTableHeader->mTableObj;
    char            sKey[DBM_INDEX_KEY_MAX_SIZE];
    int             sInserted  = 0;
    dbmColumnType   sKeyColumnType;
    int             sRC;
    dbmSpaceStat    sSpaceStat;

    _TRY
    {
        /***********************************************
         * User Data Key Size 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE );

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_DIRECT 가 아니면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType != DBM_TBL_DIRECT, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * 최초 Record Slot ID 획득
         *   1. User Data 로부터 Key 추출
         *   2. Key Column Type 에 따라 추출한 Key 값을 Slot ID 로 변경
         *      (Less Than 을 해야하므로 sSlotID 는 1 보다 작으면 안됨)
         ***********************************************/
        _CALL( mMakeKey ( &mTableHeader->mIndex[0], sData->mUserData, sKey ) );

        sKeyColumnType = mTableHeader->mIndex[0].mKey[0].mColumnType;

        sRC = dbmChgDirectKey2SlotID ( sKeyColumnType, sKey, &sSlotID );
        if ( sRC ) //, CHANGE_KEY_2_SLOTID );
        {
            DBM_ERR( "fail to change made key to slotid for direct table(%s). type[%d], rc=%d", mTableName, sKeyColumnType, sRC );
            _THROW( ERR_DBM_INVALID_COLUMN_TYPE );
        }

        /* 2014.07.15 -shw- */
        /* 임시로 Key Copy 하여 Fetch Next LT, GT 에서 사용을 한다 */
        mSelect_curr_extrakey = 0;
        /* key copy */
        memcpy_s ( mPkeyData, sKey, mTableHeader->mIndex[0].mKeySize );

        /* 2015.01.07 -shw- key value alloc check */
        /* LT로 조회 하려는 값이 해당 alloc 값보다 클 수 없다.
         * max 값보다 크면 alloc 값 이하로 조회를 하기 위하여
         * slot 값을 alloc 값으로 define 한다 */

        _CALL( mSegMgr->GetSpaceStat( sTableObj->mInstName, sTableObj->mTableName, &sSpaceStat ) );

        if( unlikely( sSlotID > sSpaceStat.mAllocSlot ) )
        {
            sSlotID = sSpaceStat.mAllocSlot + 1;
        }

        _IF_THROW( sSlotID < 1, ERR_DBM_NO_MATCH_RECORD );
        sSlotID = sSlotID % sTableObj->mMaxSize;


        /***********************************************
         * sSlotID 를 이용하여 Record 를 읽는다.
         * Key 로 받은 sSlotID 다음 ID 부터 시작. (Less Than)
         ***********************************************/
        sSlotID = sSlotID - 1;

        while ( 1 )
        {
            sRC = mSegMgr->Slot2Addr ( sSlotID, &sRow );
            if ( unlikely( sRC ) ) //, SLOT2ADDR_FAIL );
            {
                DBM_ERR( "fail to change slot to address. slot[%ld], rc=%d", sSlotID, sRC );
                _THROW( ERR_DBM_SLOT2ADDR_FAIL );
            }

            if ( sRow->mRowSize > 0 )
            {
                sRC = mReadRecord ( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted, DBM_DIRTY_OFF );
                /* 다른 tx 에 의해 신규 insert 된 것 */
                if ( sInserted )
                {
                    sSlotID = sSlotID - 1;
                    _IF_THROW( sSlotID < 1, ERR_DBM_NO_MATCH_RECORD );

                    sInserted = 0;
                    continue;
                }

                _IF_THROW( sRC && (sRC != ERR_DBM_NO_MATCH_RECORD), sRC ); //READ_RECORD_FAIL );

                //if ( sData->mDataSize < DBM_MAX_RECORD_SIZE )
                //{
                //    *(char*)((char*)sData->mUserData + sData->mDataSize) = 0x00;
                //}

                /* read done */
                break;
            }

            sSlotID = sSlotID - 1;

            _IF_THROW( sSlotID < 1, ERR_DBM_NO_MATCH_RECORD );
        }
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mDirectSelectLT */


_VOID dbmTableManager::mDirectFetchNextLT ( int aTransID , void* aDataObject )
{
    long long       sSlotID = -1;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmRowHeader*   sRow = NULL;
    dbmTableObject* sTableObj = &mTableHeader->mTableObj;
    char            sKey[DBM_INDEX_KEY_MAX_SIZE];
    int             sInserted  = 0;
    dbmColumnType   sKeyColumnType;
    int             sRC;
    dbmSpaceStat    sSpaceStat;

    _TRY
    {
        /***********************************************
         * User Data Key Size 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE );

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_DIRECT 가 아니면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType != DBM_TBL_DIRECT, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * 최초 Record Slot ID 획득
         *   1. User Data 로부터 Key 추출
         *   2. Key Column Type 에 따라 추출한 Key 값을 Slot ID 로 변경
         *      (Less Than 을 해야하므로 sSlotID 는 1 보다 작으면 안됨)
         ***********************************************/
        _CALL( mMakeKey ( &mTableHeader->mIndex[0], sData->mUserData, sKey ) );

        sKeyColumnType = mTableHeader->mIndex[0].mKey[0].mColumnType;

        if ( mSelect_curr_extrakey != -1 )
        {
            sRC = dbmChgDirectKey2SlotID ( sKeyColumnType, mPkeyData, &sSlotID );
            mSelect_curr_extrakey = -1;
        }
        else
        {
            sRC = dbmChgDirectKey2SlotID ( sKeyColumnType, sKey, &sSlotID );
        }

        if ( sRC ) //, CHANGE_KEY_2_SLOTID );
        {
            DBM_ERR( "fail to change made key to slotid for direct table(%s). type[%d], rc=%d", mTableName, sKeyColumnType, sRC );
            _THROW( ERR_DBM_INVALID_COLUMN_TYPE );
        }

        /* 2015.01.07 -shw- key value alloc check */
        /* LT로 조회 하려는 값이 해당 alloc 값보다 클 수 없다.
         * max 값보다 크면 alloc 값 이하로 조회를 하기 위하여
         * slot 값을 alloc 값으로 define 한다 */
        _CALL( mSegMgr->GetSpaceStat( sTableObj->mInstName, sTableObj->mTableName, &sSpaceStat ) );

        if( unlikely( sSlotID > sSpaceStat.mAllocSlot ) )
        {
            sSlotID = sSpaceStat.mAllocSlot + 1;
        }

        _IF_THROW( sSlotID < 1, ERR_DBM_NO_MATCH_RECORD );

        sSlotID = sSlotID % sTableObj->mMaxSize;


         /***********************************************
          * sSlotID 를 이용하여 Record 를 읽는다.
          * Key 로 받은 sSlotID 다음 ID 부터 시작. (Less Than)
          ***********************************************/
         sSlotID = sSlotID - 1;

        while ( 1 )
        {
            sRC = mSegMgr->Slot2Addr ( sSlotID, &sRow );
            if ( unlikely( sRC ) ) //, SLOT2ADDR_FAIL );
            {
                DBM_ERR( "fail to change slot to address. slot[%ld], rc=%d", sSlotID, sRC );
                _THROW( ERR_DBM_SLOT2ADDR_FAIL );
            }

            if ( sRow->mRowSize > 0 )
            {
                sRC = mFetchReadRecord ( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted );
                /* 다른 tx 에 의해 신규 insert 된 것 */
                if ( sInserted )
                {
                    sSlotID = sSlotID - 1;
                    _IF_THROW( sSlotID < 1, ERR_DBM_NO_MATCH_RECORD );

                    sInserted = 0;
                    continue;
                }

                _IF_THROW( sRC && (sRC != ERR_DBM_NO_MATCH_RECORD), sRC ); //READ_RECORD_FAIL );

                //if ( sData->mDataSize < DBM_MAX_RECORD_SIZE )
                //{
                //    *(char*)((char*)sData->mUserData + sData->mDataSize) = 0x00;
                //}

                /* read done */
                break;
            }

            sSlotID = sSlotID - 1;
            _IF_THROW( sSlotID < 1, ERR_DBM_NO_MATCH_RECORD );
        }
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mDirectFetchNextLT */


_VOID dbmTableManager::mDirectSelect ( int aTransID , void* aDataObject )
{
    char            sKey[DBM_INDEX_KEY_MAX_SIZE];
    long long       sSlotID    = -1;
    dbmDataObject*  sData      = (dbmDataObject*)aDataObject;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    int             sInserted  = 0;
    dbmColumnType   sKeyColumnType;

    _TRY
    {
        /***********************************************
         * User Data 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE );

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_DIRECT 가 아니면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType != DBM_TBL_DIRECT &&
                   sTableObj->mTableType != DBM_TBL_SEQUENCE ,
                   ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * 읽을 Record Slot ID 획득
         *   1. User Data 로부터 Key 추출
         *   2. Key Column Type 에 따라 추출한 Key 값을 Slot ID 로 변경
         ***********************************************/
        _CALL( mMakeKey( &mTableHeader->mIndex[0], sData->mUserData, sKey ) );

        sKeyColumnType = mTableHeader->mIndex[0].mKey[0].mColumnType;

        _rc = dbmChgDirectKey2SlotID( sKeyColumnType, sKey, &sSlotID );
        if ( _rc != 0 )
        {
            DBM_ERR( "Fail to change made key to slotid for direct table(%s). type[%d], rc=%d",
                     mTableName, sKeyColumnType, _rc );
            // ERR_DBM_INVALID_KEY_VALUE 가 발생할수도 있다.
            //_THROW( ERR_DBM_INVALID_COLUMN_TYPE );
            _THROW( _rc );
        }
        _IF_THROW( sSlotID < 0, ERR_DBM_NO_MATCH_RECORD );

        sSlotID = sSlotID % sTableObj->mMaxSize;

        _IF_THROW( sSlotID > mSegMgr->GetLastExtendSlotNo ( ), ERR_DBM_NO_MATCH_RECORD );

        /***********************************************
         * sSlotID 를 이용하여 Record 를 읽는다.
         ***********************************************/
        _rc = mReadRecord( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted, DBM_DIRTY_OFF );
        _IF_THROW( _rc == ERR_DBM_NO_MATCH_RECORD, ERR_DBM_NO_MATCH_RECORD );
        _IF_THROW( _rc != 0, _rc );
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mDirectSelect */


_VOID dbmTableManager::mFetchNextGT( int aTransID, void* aDataObject )
{
    long long       sSlotID = -1;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmIndexHeader* sIndexHead = NULL;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    dbmLogType      sLogType = DBM_LOG_TYPE_MAX;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE] = { 0, };
    char            sNextKey[DBM_NON_UNIQUE_KEY_SIZE];
    char            sTempKey[DBM_NON_UNIQUE_KEY_SIZE];
    int             sInserted  = 0;
    int             sRC;

    _TRY
    {
        /***********************************************
         * User Data Key Size 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE );

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectFetchNextGT() 함수 호출
         ***********************************************/
        if ( unlikely( sTableObj->mTableType == DBM_TBL_DIRECT   ) ||
             unlikely( sTableObj->mTableType == DBM_TBL_SEQUENCE )   )
        {
            return mDirectFetchNextGT ( aTransID, aDataObject ) ;     // 의도적
        }

        /***********************************************
         * Search Key 수행
         ***********************************************/

        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader ( );

        // [성능] #897 2015.03.07 -okt- 만일 이미 FETECH 된 경우는 필요가 없다.
        if ( sData->mFetchCount == 0 || sData->mFetchInd >= sData->mFetchCount )
        {
            _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sKey ) );
        }

retry:
        // [성능] 2015.03.07 -okt- memset 사용할때는 생각을 2번 더 하자.!!
        //memset_s ( sNextKey, 0x00, DBM_NON_UNIQUE_KEY_SIZE );
        sNextKey[0] = 0x00;
        //*(long long*)sNextKey = 0LL;

        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            /* 저장해 놓았던 것을  가지고 조회 한다 */
            if ( likely( sData->mFetchInd < sData->mFetchCount ) )
            {
                sSlotID = sData->mFetchRows [sData->mFetchInd];
                memcpy_s( sNextKey, sData->mFetchKey[sData->mFetchInd], DBM_NON_UNIQUE_KEY_SIZE );
                sData->mFetchInd++;
                //sNextKey[0] = 'C';
                sRC = 0;
            }
            else
            {
                //기존에 slotid를 배열로 가져오던 것에 키도 배열로 받아오도록 변경
                sData->mFetchCount = 0;
                sData->mFetchInd   = 1;
                sRC = mIndex[mUseIndex]->mSearchKeyGT ( aTransID, sKey, sData->mFetchRows, &sData->mFetchCount, sData->mFetchKey, sData->mEQCnt );
                sSlotID = sData->mFetchRows[0];
                memcpy_s( sNextKey, sData->mFetchKey[0], DBM_NON_UNIQUE_KEY_SIZE );
            }

            mSelect_extrakey = -1;
            mSelect_curr_extrakey = -1;

        }
        else
        {
            //TODO: [OKT] 2015.03.07 Fetch 성능 개선이 Non-Unique에도 적용 필요하다.

            if ( mSelect_curr_extrakey != -1 )
            {
                sRC = mIndex[mUseIndex]->mSearchKeyGTNu ( aTransID, sKey, &sSlotID, sNextKey, &mSelect_curr_extrakey, sData->mEQCnt );
                mSelect_extrakey = mSelect_curr_extrakey;
                mSelect_curr_extrakey = -1;
            }
            else
            {
                sRC = mIndex[mUseIndex]->mSearchKeyGTNu ( aTransID, sKey, &sSlotID, sNextKey, &mSelect_extrakey, sData->mEQCnt );
            }
        }

        _IF_THROW( sRC == ERR_DBM_KEY_NOT_EXIST, ERR_DBM_NO_MATCH_RECORD );
        _IF_THROW( sRC || sSlotID < 0, sRC ); //SEARCH_KEY_FAIL );

        /***********************************************
         * sSlotID 를 이용하여 Record 를 읽는다.
         ***********************************************/
        sRC = mFetchReadRecord ( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted, &sLogType );
        //만약에 읽어온 레코드가 undo에서 읽어왔는데 DBM_UPDATE_KEY_LOG에 의한 이미지이거나
        //내가 변경한 레코드라면 정상적인 로우인지 확인해 봐야한다.
        if( sLogType == DBM_UPDATE_KEY_LOG )
        {
            sLogType = DBM_LOG_TYPE_MAX;
            _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sTempKey ) );
            if( memcmp_s( sNextKey, sTempKey, sIndexHead->mIndex.mKeySize ) )
            {
                sRC = ERR_DBM_NO_MATCH_RECORD;
            }
        }

        if ( unlikely( sInserted ) )
        {
            memcpy_s ( sKey, sNextKey, DBM_INDEX_KEY_MAX_SIZE );
            sInserted = 0;
            goto retry;
        }

        if ( unlikely ( sRC ) )
        {
            if ( sRC == ERR_DBM_NO_MATCH_RECORD )
            {
                if ( sNextKey[0] != 0x00 )
                {
                    //memset_s ( sKey, 0x00, sizeof( sKey ) );
                    memcpy_s ( sKey, sNextKey, sizeof( sKey ) );
                    goto retry;
                }
                //_THROW( ERR_DBM_NO_MATCH_RECORD );
            }

            _THROW( sRC ); //, READ_RECORD_FAIL );
        }

       //if ( sData->mDataSize < DBM_MAX_RECORD_SIZE )
       //{
       //    *(char*) ( (char*)sData->mUserData + sData->mDataSize ) = 0x00;
       //}
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mFetchNextGT */


_VOID dbmTableManager::mFetchNextLT( int aTransID, void* aDataObject )
{
    long long       sSlotID = -1;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmIndexHeader* sIndexHead = NULL;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    dbmLogType      sLogType = DBM_LOG_TYPE_MAX;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE]; // non-unique type check value 8 byte 2014.05.30 -shw-
    char            sPrevKey[DBM_NON_UNIQUE_KEY_SIZE];
    char            sTempKey[DBM_NON_UNIQUE_KEY_SIZE];
    int             sInserted  = 0;
    int             sRC;

    _TRY
    {
        /***********************************************
         * User Data Key Size 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE );

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectFetchNextLT() 함수 호출
         ***********************************************/
        if ( unlikely( sTableObj->mTableType == DBM_TBL_DIRECT ) )
        {
            return mDirectFetchNextLT ( aTransID, aDataObject );    // 의도적
        }

        /***********************************************
         * Search Key 수행
         ***********************************************/
        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader ( );
        _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sKey ) );

retry:
        /* non-unique index 8byte 추가 */
        memset_s ( sPrevKey, 0x00, DBM_NON_UNIQUE_KEY_SIZE );

        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            //if ( mSelect_curr_extrakey != -1 )
            //{
                /* 저장해 놓았던 것을  가지고 조회 한다 */
                //sRC = mIndex[mUseIndex]->mSearchKeyLT ( aTransID, mPkeyData, sData->mFetchRows, &sData->mFetchCount, sPrevKey, aEQCnt );
                //sRC = mIndex[mUseIndex]->mSearchKeyLT ( aTransID, sKey, sData->mFetchRows, &sData->mFetchCount, sPrevKey, aEQCnt );
            if (sData->mFetchInd < sData->mFetchCount)
            {
                sSlotID = sData->mFetchRows [sData->mFetchInd];
                memcpy_s( sPrevKey, sData->mFetchKey[sData->mFetchInd], DBM_NON_UNIQUE_KEY_SIZE );
                sData->mFetchInd++;
                //sPrevKey[0] = 'C';
                sRC = 0;
            }
            else
            {
                //기존에 slotid를 배열로 가져오던 것에 키도 배열로 받아오도록 변경
                sData->mFetchCount = 0;
                sData->mFetchInd   = 1;
                sRC = mIndex[mUseIndex]->mSearchKeyLT ( aTransID, sKey, sData->mFetchRows, &sData->mFetchCount, sData->mFetchKey, sData->mEQCnt );
                sSlotID = sData->mFetchRows[0];
                memcpy_s( sPrevKey, sData->mFetchKey[0], DBM_NON_UNIQUE_KEY_SIZE );
            }

            mSelect_extrakey = -1;
            mSelect_curr_extrakey = -1;
        }
        else
        {
            if ( mSelect_curr_extrakey != -1 )
            {
                /* LT는 제일 큰값 부터 조회를 아래로 해야 하기 때문에 long값의 제일 큰값 부터
                 * 주어 해당 key 값의 제일 큰값을 가져온다 long(9223372036854775807) */
                mSelect_curr_extrakey = LONG_MAX;

                sRC = mIndex[mUseIndex]->mSearchKeyLTNu ( aTransID, sKey, &sSlotID, sPrevKey, &mSelect_curr_extrakey, sData->mEQCnt );
                mSelect_extrakey = mSelect_curr_extrakey;
                mSelect_curr_extrakey = -1;
            }
            else
            {
                sRC = mIndex[mUseIndex]->mSearchKeyLTNu ( aTransID, sKey, &sSlotID, sPrevKey, &mSelect_extrakey, sData->mEQCnt );
            }
        }

        _IF_THROW( sRC == ERR_DBM_KEY_NOT_EXIST, ERR_DBM_NO_MATCH_RECORD );
        _IF_THROW( sRC || sSlotID < 0, sRC ); //SEARCH_KEY_FAIL );

        /***********************************************
         * sSlotID 를 이용하여 Record 를 읽는다.
         ***********************************************/
        sRC = mFetchReadRecord ( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted, &sLogType );
        //만약에 읽어온 레코드가 undo에서 읽어왔는데 DBM_UPDATE_KEY_LOG에 의한 이미지이거나
        //내가 변경한 레코드라면 정상적인 로우인지 확인해 봐야한다.
        if( sLogType == DBM_UPDATE_KEY_LOG )
        {
            sLogType = DBM_LOG_TYPE_MAX;
            _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sTempKey ) );
            if( memcmp_s( sPrevKey, sTempKey, sIndexHead->mIndex.mKeySize ) )
            {
                sRC = ERR_DBM_NO_MATCH_RECORD;
            }
        }
        if ( sInserted )
        {
            //memset_s( sKey, 0x00, DBM_INDEX_KEY_MAX_SIZE );
            memcpy_s ( sKey, sPrevKey, DBM_INDEX_KEY_MAX_SIZE );
            sInserted = 0;
            goto retry;
        }

        if ( sRC )
        {
            //TODO: 2014.10.22 -okt- GT 함수와 로직이 다르다. 확인요.
            // if ( sNextKey[0] != 0x00 )
            //_IF_THROW( sRC == ERR_DBM_NO_MATCH_RECORD, ERR_DBM_NO_MATCH_RECORD );
            if( sRC == ERR_DBM_NO_MATCH_RECORD )
            {
                if ( sPrevKey[0] != 0x00 )
                {
                    //memset_s ( sKey, 0x00, sizeof( sKey ) );
                    memcpy_s ( sKey, sPrevKey, sizeof( sKey ) );
                    goto retry;
                }
            }
            _THROW( sRC ); //, READ_RECORD_FAIL );
        }
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mFetchNextLT */

_VOID dbmTableManager::mSelectMax ( int aTransID , void* aDataObject )
{
    int             sRC;
    int             sNodeNo = -1;
    int             sDepth = -1;
    long long       sSlotID = -1;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmIndexHeader* sIndexHead = NULL;
    dbmIndexNode*   sIndexNode = NULL;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    dbmLogType      sLogType = DBM_LOG_TYPE_MAX;
    dbmRowHeader*   sRow = NULL;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE]; // non-unique type check value 8 byte 2014.05.30 -shw-
    char            sTempKey[DBM_NON_UNIQUE_KEY_SIZE];
    int             sInserted  = 0;

    _TRY
    {
        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectFetchNextGT() 함수 호출
         ***********************************************/
        if ( unlikely(sTableObj->mTableType == DBM_TBL_DIRECT ||
                      sTableObj->mTableType == DBM_TBL_SEQUENCE ) )
        {
            //_CALL( mDirectSelectMax ( aTransID, aDataObject ) );
            _RETURN;
        }

        /***********************************************
         * Search Key 수행
         ***********************************************/
        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader ( );

retry:

        sRC = mIndex[mUseIndex]->mMax ( aTransID, sIndexNode, &sNodeNo, &sDepth, &sSlotID, sKey );
        _IF_THROW( sRC == ERR_DBM_KEY_NOT_EXIST, ERR_DBM_NO_MATCH_RECORD );
        _IF_THROW( sRC || sSlotID < 0, sRC /* SEARCH_KEY_FAIL */ );

        /***********************************************
         * sSlotID 를 이용하여 Record 를 읽는다.
         *  - 다른 놈이 새롭게 Insert 한 것이면 읽으면 안됨.
         *  - 내가 Delete 를 했다면 읽으면 안되고 다음 Key 로.
         ***********************************************/
        _CALL( mSegMgr->Slot2Addr ( sSlotID, &sRow ) );

#ifdef _DEBUG
        // 2015.03.07 -okt- 보장되어 있다.
        if ( sRow->mRowSize > 0 && sRow->mRowSize <= DBM_MAX_RECORD_SIZE )
        {
            memset_s ( sData->mUserData, 0x00, sRow->mRowSize );
        }
#else
        if ( sRow->mRowSize > 0 )
        {
            sData->mUserData[0] = 0x00;
        }
#endif
 
        sRC = mReadRecord ( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted, DBM_DIRTY_OFF, &sLogType );
        //만약에 읽어온 레코드가 undo에서 읽어왔는데 DBM_UPDATE_KEY_LOG에 의한 이미지이거나
        //내가 변경한 레코드라면 정상적인 로우인지 확인해 봐야한다.
        if( sLogType == DBM_UPDATE_KEY_LOG )
        {
            sLogType = DBM_LOG_TYPE_MAX;
            _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sTempKey ) );
            if( memcmp_s( sKey, sTempKey, sIndexHead->mIndex.mKeySize ) )
            {
                //_PRT( "updated record [%d:%d]\n", *(int*)sKey, *(int*)sTempKey );
                goto retry;
            }
            /*
            else
            {
                _PRT( "mod by mine but not update key\n" );
            }
            */
        }

        if ( unlikely( sInserted ) )
        {
            //_PRT( "inserted record\n" );
            sInserted = 0;
            goto retry;
        }

        /*
        if ( unlikely( sRC == ERR_DBM_NO_MATCH_RECORD && sNextKey[0] != 0x00 ) )
        {
        }
        */

        _IF_THROW( sRC, sRC /* READ_RECORD_FAIL */ );

#ifdef _DEBUG
        //if ( sData->mDataSize < DBM_MAX_RECORD_SIZE )
        _DASSERT ( sData->mDataSize <= DBM_MAX_RECORD_SIZE );
#endif
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
}

_VOID dbmTableManager::mSelectMin ( int aTransID , void* aDataObject )
{
    int             sRC;
    int             sNodeNo = -1;
    int             sDepth = -1;
    long long       sSlotID = -1;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmIndexHeader* sIndexHead = NULL;
    dbmIndexNode*   sIndexNode = NULL;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    dbmLogType      sLogType = DBM_LOG_TYPE_MAX;
    dbmRowHeader*   sRow = NULL;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE]; // non-unique type check value 8 byte 2014.05.30 -shw-
    char            sTempKey[DBM_NON_UNIQUE_KEY_SIZE];
    int             sInserted  = 0;

    _TRY
    {
        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectFetchNextGT() 함수 호출
         ***********************************************/
        if ( unlikely(sTableObj->mTableType == DBM_TBL_DIRECT ||
                      sTableObj->mTableType == DBM_TBL_SEQUENCE ) )
        {
            //_CALL( mDirectSelectMax ( aTransID, aDataObject ) );
            _RETURN;
        }

        /***********************************************
         * Search Key 수행
         ***********************************************/
        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader ( );

retry:

        sRC = mIndex[mUseIndex]->mMin ( aTransID, sIndexNode, &sNodeNo, &sDepth, &sSlotID, sKey );
        _IF_THROW( sRC == ERR_DBM_KEY_NOT_EXIST, ERR_DBM_NO_MATCH_RECORD );
        _IF_THROW( sRC || sSlotID < 0, sRC /* SEARCH_KEY_FAIL */ );

        /***********************************************
         * sSlotID 를 이용하여 Record 를 읽는다.
         *  - 다른 놈이 새롭게 Insert 한 것이면 읽으면 안됨.
         *  - 내가 Delete 를 했다면 읽으면 안되고 다음 Key 로.
         ***********************************************/
        _CALL( mSegMgr->Slot2Addr ( sSlotID, &sRow ) );

#ifdef _DEBUG
        // 2015.03.07 -okt- 보장되어 있다.
        if ( sRow->mRowSize > 0 && sRow->mRowSize <= DBM_MAX_RECORD_SIZE )
        {
            memset_s ( sData->mUserData, 0x00, sRow->mRowSize );
        }
#else
        if ( sRow->mRowSize > 0 )
        {
            sData->mUserData[0] = 0x00;
        }
#endif

        sRC = mReadRecord ( aTransID, sSlotID, sData->mUserData, &sData->mDataSize, &sInserted, DBM_DIRTY_OFF, &sLogType );
        //만약에 읽어온 레코드가 undo에서 읽어왔는데 DBM_UPDATE_KEY_LOG에 의한 이미지이거나
        //내가 변경한 레코드라면 정상적인 로우인지 확인해 봐야한다.
        if( sLogType == DBM_UPDATE_KEY_LOG )
        {
            sLogType = DBM_LOG_TYPE_MAX;
            _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sTempKey ) );
            if( memcmp_s( sKey, sTempKey, sIndexHead->mIndex.mKeySize ) )
            {
                //_PRT( "updated record [%d:%d]\n", *(int*)sKey, *(int*)sTempKey );
                goto retry;
            }
            /*
            else
            {
                _PRT( "mod by mine but not update key\n" );
            }
            */
        }

        if ( unlikely( sInserted ) )
        {
            //_PRT( "inserted record\n" );
            sInserted = 0;
            goto retry;
        }

        /*
        if ( unlikely( sRC == ERR_DBM_NO_MATCH_RECORD && sNextKey[0] != 0x00 ) )
        {
        }
        */

        _IF_THROW( sRC, sRC /* READ_RECORD_FAIL */ );

#ifdef _DEBUG
        //if ( sData->mDataSize < DBM_MAX_RECORD_SIZE )
        _DASSERT ( sData->mDataSize <= DBM_MAX_RECORD_SIZE );
#endif
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
}

__thread char* g_sBeforeImage_mDirectDelete = NULL;
_VOID dbmTableManager::mDirectDelete ( int aTransID , void* aDataObject )
{
    int             sRC;
    long long       sSlotID = -1;
    int             sLogType = DBM_LOG_TYPE_MAX;
    dbmRowHeader*   sRow = NULL;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmLogHeader*   sLogHead = NULL;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    char            sKey[DBM_INDEX_KEY_MAX_SIZE];
    dbmTableHeader* sTableHead = NULL;
    dbmColumnType   sKeyColumnType;
    int             sRowSize = 0;

    _TRY
    {
        /***********************************************
         * Big Stack 변수 제거
         ***********************************************/
        if ( g_sBeforeImage_mDirectDelete == NULL )
        {
            g_sBeforeImage_mDirectDelete = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            memset_s ( g_sBeforeImage_mDirectDelete,
                       0,
                       DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }

        /***********************************************
         * User Data 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE );

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_DIRECT 가 아니면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType != DBM_TBL_DIRECT, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * 읽을 Record Slot ID 획득
         *   1. User Data 로부터 Key 추출
         *   2. Key Column Type 에 따라 추출한 Key 값을 Slot ID 로 변경
         *   3. Slot ID 가 table 의 max size 보다 크거나 현재
         *      확장된 segment 의 최대 slot id 보다 크면 not found
         ***********************************************/
        _CALL( mMakeKey( &mTableHeader->mIndex[0], sData->mUserData, sKey ) );

        sKeyColumnType = mTableHeader->mIndex[0].mKey[0].mColumnType;

        _rc = dbmChgDirectKey2SlotID( sKeyColumnType, sKey, &sSlotID );
        if ( _rc != 0 )
        {
            DBM_ERR( "Fail to change made key to slotid for direct table(%s). type[%d], rc=%d",
                     mTableName, sKeyColumnType, _rc );
            _THROW( _rc );
        }
        _IF_THROW( sSlotID < 0, ERR_DBM_NO_MATCH_RECORD );

        sSlotID = sSlotID % sTableObj->mMaxSize;

retry:
        _IF_THROW( sSlotID > mSegMgr->GetLastExtendSlotNo( ), ERR_DBM_NO_MATCH_RECORD );

        _CALL( mSegMgr->Slot2Addr( sSlotID, &sRow ) );

        /*
         * TODO: 2014.12.14. -okt- 2014/07/04 direct table 생성하고 0건에서 delete 하면 -1 나온다.
         *             락을 잡고나서, 검사을 하지 않아도 되는가 모르겠다.
         *             락 잡고 검사하면, 로깅을 했기대문에 Recovery에서 죽는다.
         */
        _IF_THROW( sRow->mRowSize == -1, ERR_DBM_NO_MATCH_RECORD );

        /***********************************************
         * Row Lock
         *   1. Logging( DBM_LOCK_ROW_LOG )
         *   2. Row Lock 수행
         ***********************************************/
        sTableHead = (dbmTableHeader*)mSegMgr->GetUserHeader();

        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_LOCK_ROW_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         NULL,
                                         0,
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        RTF_POINT("TBLMGR_DIRECT_DELETE_1");

        sRC = mRowLock( sTableObj->mInstName,
                        sSlotID,
                        sRow,
                        g_sBeforeImage_mDirectDelete,
                        aTransID,
                        1 );

        if ( sRC == ERR_DBM_DEADLOCK_DETECTED )
        {
            return ERR_DBM_DEADLOCK_DETECTED;
        }
        _IF_THROW( sRC == ERR_DBM_NO_MATCH_RECORD, ERR_DBM_NO_MATCH_RECORD );
        //_IF_RAISE( sRC && (sRC != ERR_DBM_ABNORMAL_ROLLBACK), ROW_LOCK_FAIL );
        if ( sRC != ERR_DBM_ABNORMAL_ROLLBACK && sRC != 0 )
        {
            _THROW( sRC );
        }

        RTF_POINT("TBLMGR_DIRECT_DELETE_2");

        if ( sRC == ERR_DBM_ABNORMAL_ROLLBACK )
        {
            DBM_WARN("direct delete abnormal rollback. txid[%d] table[%s] slot[%ld]",
                            aTransID, mTableName, sSlotID );
            goto retry;
        }

        /* lock 성공 후 보니 data 없으면 delete 된 것임 */
        _IF_THROW( sRow->mRowSize == 0, ERR_DBM_NO_MATCH_RECORD );


        /***********************************************
         * Before Image Logging
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_DELETE_DATA_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         g_sBeforeImage_mDirectDelete,
                                         sRow->mRowSize + sizeof(dbmRowHeader),
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
        }

        RTF_POINT("TBLMGR_DIRECT_DELETE_3");


        /***********************************************
         * Commit 때 FreeSlot 을 위해서 Logging
         ***********************************************/
// #620 direct table은 FreeSlot 로그가 필요없다.
//        if ( ! sTableObj->mNoMemloggingF )
//        {
//            sLogType = DBM_DELETE_SLOT_LOG;
//            sRC = mLogMgr->mWriteMemLog( sLogType,
//                                         aTransID,
//                                         mTableID,
//                                         mTableName,
//                                         NULL, // mTableName,
//                                         sSlotID,
//                                         NULL,
//                                         0,
//                                         (char*)mTableHeader,
//                                         (char*)mTableHeader,
//                                         (char**)&sLogHead );
//            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
//        }

        RTF_POINT("TBLMGR_DIRECT_DELETE_4");


        /***********************************************
         * Row 를 다른 놈이 읽지 못하게 INFINITE 로 변경하고,
         * 데이터는 NULL 로 기록해버림
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sRowSize       = sRow->mRowSize;

            RTF_POINT("TBLMGR_DIRECT_DELETE_5");

            sRow->mSCN     = INFINITE_SCN;

            RTF_POINT("TBLMGR_DIRECT_DELETE_6");

            sRow->mRowSize = 0;

            RTF_POINT("TBLMGR_DIRECT_DELETE_7");
        }
        else
        {
            sRow->mSCN     = 0;
            sRow->mRowSize = 0;
        }

        memset_s ( (char*)sRow + sizeof(dbmRowHeader), 0x00, sRowSize );

        sRC = mHandleTrigger( DBM_EVENT_DELETE,
                              aTransID ,
                              g_sBeforeImage_mDirectDelete+ sizeof (dbmRowHeader) ,
                              sRowSize );
        _IF_THROW ( sRC , ERR_DBM_TRIGGER_FAIL ) ;

        if ( sTableObj->mNoMemloggingF )
        {
            sRow->mLock = -1;
        }
    }
    _CATCH
    {
        if ( sTableObj->mNoMemloggingF )
        {
            if ( sRow != NULL )
            {
                sRow->mSCN     = 0;
                sRow->mRowSize = 0;
            }
        }

        if ( _rc == ERR_DBM_WRITE_LOG )
        {
            DBM_CERR("write log fail. log_type [%d]", sLogType );
        }
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN2( mTableName );
        }
    }
    _FINALLY
    _END
} /* mDirectDelete */


__thread char* g_sBeforeImage_mDirectUpdate = NULL;
_VOID dbmTableManager::mDirectUpdate ( int aTransID , void* aDataObject )
{
    long long       sSlotID     = -1;
    int             sLogType    = DBM_LOG_TYPE_MAX;
    dbmDataObject*  sData       = (dbmDataObject*)aDataObject;
    dbmRowHeader*   sRow        = NULL;
    dbmLogHeader*   sLogHead    = NULL;
    dbmTableObject* sTableObj   = &mTableHeader->mTableObj;
    char            sKey[DBM_INDEX_KEY_MAX_SIZE];
    dbmColumnType   sKeyColumnType;
    long long       sSCN;

    _TRY
    {
        /***********************************************
         * Big Stack 변수 제거
         ***********************************************/
        if ( g_sBeforeImage_mDirectUpdate == NULL )
        {
            g_sBeforeImage_mDirectUpdate =
                    (char*)malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );

            memset_s ( g_sBeforeImage_mDirectUpdate,
                       0,
                       DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }

        /***********************************************
         * User Data 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE );

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_DIRECT 가 아니면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType != DBM_TBL_DIRECT &&
                   sTableObj->mTableType != DBM_TBL_SEQUENCE ,
                   ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * 읽을 Record Slot ID 획득
         *   1. User Data 로부터 Key 추출
         *   2. Key Column Type 에 따라 추출한 Key 값을 Slot ID 로 변경
         *   3. Slot ID 가 table 의 max size 보다 크거나 현재
         *      확장된 segment 의 최대 slot id 보다 크면 not found
         ***********************************************/
        //memset_s( sKey, 0x00, DBM_INDEX_KEY_MAX_SIZE );
        _CALL( mMakeKey ( &mTableHeader->mIndex[0], sData->mUserData, sKey ) );

        sKeyColumnType = mTableHeader->mIndex[0].mKey[0].mColumnType;

        _rc = dbmChgDirectKey2SlotID ( sKeyColumnType, sKey, &sSlotID );
        if ( _rc != 0 )
        {
            DBM_ERR( "fail to change made key to slotid for direct table(%s). type[%d] (err=%d,tid=%d)",
                                mTableName, sKeyColumnType, errno, gettid_s() );
            _THROW( ERR_DBM_INVALID_COLUMN_TYPE );
        }

        _IF_THROW( sSlotID < 0, ERR_DBM_NO_MATCH_RECORD );

        sSlotID = sSlotID % sTableObj->mMaxSize;

retry:
        _IF_THROW( sSlotID > mSegMgr->GetLastExtendSlotNo ( ), ERR_DBM_NO_MATCH_RECORD );

        _rc = mSegMgr->Slot2Addr ( sSlotID, &sRow );
        _IF_THROW( _rc, ERR_DBM_ALLOC_SLOT );

        /*
         * TODO: 2014.12.14. -okt- 2014/07/04 direct table 생성하고 0건에서 delete 하면 -1 나온다.
         *             락을 잡고나서, 검사을 하지 않아도 되는가 모르겠다.
         *             락 잡고 검사하면, 로깅을 했기대문에 Recovery에서 죽는다.
         */
        _IF_THROW( sRow->mRowSize == -1, ERR_DBM_NO_MATCH_RECORD );


        /***********************************************
         * Row Lock
         *   1. Logging( DBM_LOCK_ROW_LOG )
         *   2. Row Lock 수행
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_LOCK_ROW_LOG;
            _rc = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         NULL,
                                         0,
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW( _rc, ERR_DBM_WRITE_LOG );
        }

        RTF_POINT("TBLMGR_DIRECT_UPDATE_1");

        _rc = mRowLock( sTableObj->mInstName,
                        sSlotID,
                        sRow,
                        g_sBeforeImage_mDirectUpdate,
                        aTransID,
                        1 );

        RTF_POINT("TBLMGR_DIRECT_UPDATE_2");

        if ( _rc == ERR_DBM_ABNORMAL_ROLLBACK )
        {
            DBM_WARN("update abnormal rollback. txid[%d] table[%s] slot[%ld]",
                            aTransID, mTableName, sSlotID );
            goto retry;
        }
        else if ( _rc != 0 )
        {
            _IF_THROW( _rc == ERR_DBM_DEADLOCK_DETECTED, ERR_DBM_DEADLOCK_DETECTED ) ;
            _IF_THROW( _rc == ERR_DBM_NO_MATCH_RECORD, ERR_DBM_NO_MATCH_RECORD );
            _THROW( _rc );
        }

        /* lock 성공 후 보니 data 없으면 delete 된 것임 */
        _IF_THROW( sRow->mRowSize == 0, ERR_DBM_NO_MATCH_RECORD );


        /***********************************************
         * Before Image 를 logging 한다.
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_UPDATE_SLOT_LOG;
            _rc = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         g_sBeforeImage_mDirectUpdate,
                                         sRow->mRowSize + sizeof(dbmRowHeader),
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW( _rc, ERR_DBM_WRITE_LOG );
        }

        RTF_POINT("TBLMGR_DIRECT_UPDATE_3");


        /***********************************************
         * 새로운 Image 로 Row 를 덮어쓴다.
         ***********************************************/
        sRow->mSCN = INFINITE_SCN;

        RTF_POINT("TBLMGR_DIRECT_UPDATE_4");

        _DASSERT( sRow->mRowSize != -1 );   // -1이 넘어가는 경우가 있는데 못찾음 ( 2014/06/25 )
        memcpy_s( (char*)sRow + sizeof(dbmRowHeader),
                  sData->mUserData,
                  sRow->mRowSize );


        /************************************************
         * 트리거 처리
         ************************************************/
        /* sequence type은 trigger 적용할 수 없다. 2015.03.16 -shw- */
        if ( sTableObj->mTableType != DBM_TBL_SEQUENCE )
        {
            _rc = mHandleTrigger ( DBM_EVENT_UPDATE_BEFORE,
                                   aTransID,
                                   g_sBeforeImage_mDirectUpdate + sizeof( dbmRowHeader ) ,
                                   sRow->mRowSize ) ;
            _IF_THROW( _rc, ERR_DBM_TRIGGER_FAIL ) ;

            _rc = mHandleTrigger ( DBM_EVENT_UPDATE_AFTER,
                                   aTransID,
                                   (char*)sRow + sizeof(dbmRowHeader)  ,
                                   sRow->mRowSize ) ;
            _IF_THROW( _rc, ERR_DBM_TRIGGER_FAIL ) ;
        }

        if ( sTableObj->mNoMemloggingF )
        {
            /************************************************
             * mem nologging 일 때는 여기에서 auto commit 처럼 처리.
             ************************************************/
            mLogMgr->mGetSCN( &sSCN );

            sRow->mSCN  = sSCN;
            sRow->mLock = -1;
        }
    }
    _CATCH
    {
        if ( sTableObj->mNoMemloggingF )
        {
            if ( sRow != NULL )
            {
                sRow->mLock = -1;
            }
        }

        if ( _rc == ERR_DBM_WRITE_LOG )
        {
            DBM_ERR( "write log fail. log_type[%d] table[%s]", sLogType, mTableName );
        }

        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN2( mTableName );
        }
    }
    _FINALLY
    _END
} /* mDirectUpdate */


__thread char* g_sBeforeImage_mDirectSelectForUpdate = NULL;
_VOID dbmTableManager::mDirectSelectForUpdate ( int aTransID , void* aDataObject )
{
    long long       sSlotID     = -1;
    int             sLogType    = DBM_LOG_TYPE_MAX;
    dbmDataObject*  sData       = (dbmDataObject*)aDataObject;
    dbmRowHeader*   sRow        = NULL;
    dbmLogHeader*   sLogHead    = NULL;
    dbmTableObject* sTableObj   = &mTableHeader->mTableObj;
    char            sKey[DBM_INDEX_KEY_MAX_SIZE];
    dbmColumnType   sKeyColumnType;

    _TRY
    {
        /***********************************************
         * Big Stack 변수 제거
         ***********************************************/
        if ( g_sBeforeImage_mDirectSelectForUpdate == NULL )
        {
            g_sBeforeImage_mDirectSelectForUpdate
                    = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );

            memset_s ( g_sBeforeImage_mDirectSelectForUpdate,
                       0,
                       DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }

        /***********************************************
         * User Data 가 Table 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sTableObj->mRecordSize, ERR_DBM_INVALID_RECORD_SIZE );

        // (성능) mSelectForUpdate 를 통해서만 호출되며, 상위에서 체크되었다.
#ifdef _DEBUG
        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_DIRECT 가 아니면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType != DBM_TBL_DIRECT &&
                   sTableObj->mTableType != DBM_TBL_SEQUENCE ,
                   ERR_DBM_INVALID_TABLE_TYPE );
#endif

        /***********************************************
         * 읽을 Record Slot ID 획득
         *   1. User Data 로부터 Key 추출
         *   2. Key Column Type 에 따라 추출한 Key 값을 Slot ID 로 변경
         *   3. Slot ID 가 table 의 max size 보다 크거나 현재
         *      확장된 segment 의 최대 slot id 보다 크면 not found
         ***********************************************/
        _CALL( mMakeKey ( &mTableHeader->mIndex[0], sData->mUserData, sKey ) );

        sKeyColumnType = mTableHeader->mIndex[0].mKey[0].mColumnType;

        _rc = dbmChgDirectKey2SlotID ( sKeyColumnType, sKey, &sSlotID );
        if ( _rc != 0 )
        {
            DBM_ERR( "fail to change made key to slotid for direct table(%s). type[%d] (err=%d,tid=%d)",
                                mTableName, sKeyColumnType, errno, gettid_s() );
            _THROW( ERR_DBM_INVALID_COLUMN_TYPE );
        }
        _IF_THROW( sSlotID < 0, ERR_DBM_NO_MATCH_RECORD );

        // 2014.12.14. -okt- direct table 에서 이게 필요한가? 오히려 아래 코드가 필요한게 아닌가?
        //             의도적이라고함.
        sSlotID = sSlotID % sTableObj->mMaxSize;
        //_IF_THROW( sSlotID >= sTableObj->mMaxSize, ERR_DBM_NO_MATCH_RECORD );

        // dbmChgDirectKey2SlotID에서 결정되고 바뀌지 않는 조건이다. 한번만 체크.
        _IF_THROW( sSlotID > mSegMgr->GetLastExtendSlotNo ( ), ERR_DBM_NO_MATCH_RECORD );
retry:
        //_IF_THROW( sSlotID > mSegMgr->GetLastExtendSlotNo ( ), ERR_DBM_NO_MATCH_RECORD );

        _rc = mSegMgr->Slot2Addr ( sSlotID, &sRow );
        _IF_THROW( _rc, ERR_DBM_ALLOC_SLOT );

        /***********************************************
         * Row Lock
         *   1. Logging( DBM_LOCK_ROW_LOG )
         *   2. Row Lock 수행
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_LOCK_ROW_LOG;
            _rc = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         NULL,
                                         0,
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW( _rc, ERR_DBM_WRITE_LOG );
        }

        _rc = mRowLock( sTableObj->mInstName,
                        sSlotID,
                        sRow,
                        g_sBeforeImage_mDirectSelectForUpdate,
                        aTransID,
                        1 );

        if ( _rc == ERR_DBM_ABNORMAL_ROLLBACK )
        {
            DBM_WARN("update abnormal rollback. txid[%d] table[%s] slot[%ld]",
                            aTransID, mTableName, sSlotID );
            goto retry;
        }
        else if ( _rc != 0 )
        {
            _IF_THROW( _rc == ERR_DBM_DEADLOCK_DETECTED, ERR_DBM_DEADLOCK_DETECTED ) ;
            _IF_THROW( _rc == ERR_DBM_NO_MATCH_RECORD, ERR_DBM_NO_MATCH_RECORD );
            _THROW( _rc );
        }

        /***********************************************
         * Before Image 를 logging 한다.
         * (Row Lock 으로 내 TxID 가 기록되었으므로
         *  만약 SelectForUpdate 가 끝나고 곧바로 다른 놈이
         *  Select 를 하면 mReadRecord 에서 Undo 를
         *  읽어야 하므로 Before Image Logging 필요)
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_SELECT_FOR_UPDATE_LOG;
            _rc = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         mTableName,
                                         sSlotID,
                                         g_sBeforeImage_mDirectSelectForUpdate,
                                         sRow->mRowSize + sizeof(dbmRowHeader),
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW( _rc, ERR_DBM_WRITE_LOG );
        }

        /***********************************************
         * 이미지를 읽어서 리턴
         ***********************************************/
        /*
         * 2014.12.14. -okt- [성능] 일반 SELECT는 대기하고 있다가 여기서, 풀린다.
         *              1. unsigned 변수를 CPU가 더 빠르게 처리할 수 있다. ( C 최적화 팁 )
         *              2. 0 에 대한 비교를 ""
         *              3. 변경중이라는 표시를 홀수 SCN으로 료시하면 어떻게 될까? ( 골디X ). 장점이 있을가? (망상)
         *
         */
        sRow->mSCN = INFINITE_SCN;
        memcpy_s ( sData->mUserData, (char*)sRow + sizeof(dbmRowHeader), sRow->mRowSize );
    }
    _CATCH
    {
        if ( sTableObj->mNoMemloggingF )
        {
            if ( sRow != NULL )
            {
                sRow->mLock = -1;
            }
        }

        if ( _rc == ERR_DBM_WRITE_LOG )
        {
            DBM_ERR( "write log fail. log_type[%d] table[%s]", sLogType, mTableName );
        }

        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN2( mTableName );
        }
    }
    _FINALLY
    _END
} /* mDirectSelectForUpdate */


__thread char* g_sBeforeImage_mDirectUpdateCol = NULL;
int dbmTableManager::mDirectUpdateCol( int aTransID, void* )
{
    int             i;
    int             sRC;
    long long       sSlotID = -1;
    int             sLogType;
    dbmRowHeader*   sRow       = NULL;
    dbmLogHeader*   sLogHead   = NULL;
    dbmBindCols*    sBindCols  = (dbmBindCols *)mBindCols;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    char            sKey[DBM_INDEX_KEY_MAX_SIZE];
    dbmColumnType   sKeyColumnType;
    int             sTableColCount;
    dbmColumnObject* sTableLastCol;

    _TRY
    {
        /***********************************************
         * Big Stack 변수 제거
         ***********************************************/
        if ( g_sBeforeImage_mDirectUpdateCol == NULL )
        {
            g_sBeforeImage_mDirectUpdateCol = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            memset_s ( g_sBeforeImage_mDirectUpdateCol, 0, DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_DIRECT 가 아니면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType != DBM_TBL_DIRECT, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * 읽을 Record Slot ID 획득
         *   1. User Data 로부터 Key 추출
         *   2. Key Column Type 에 따라 추출한 Key 값을 Slot ID 로 변경
         *   3. Slot ID 가 table 의 max size 보다 크거나 현재
         *      확장된 segment 의 최대 slot id 보다 크면 not found
         ***********************************************/
        _CALL( mMakeKey ( &mTableHeader->mIndex[0], sBindCols->mData, sKey ) );

        sKeyColumnType = mTableHeader->mIndex[0].mKey[0].mColumnType;

        sRC = dbmChgDirectKey2SlotID ( sKeyColumnType, sKey, &sSlotID );
        if ( sRC ) //, CHANGE_KEY_2_SLOTID );
        {
            DBM_ERR( "fail to change made key to slotid for direct table(%s). type[%d], rc=%d", mTableName, sKeyColumnType, sRC );
            _THROW( ERR_DBM_INVALID_COLUMN_TYPE );
        }

        _IF_THROW( sSlotID < 0, ERR_DBM_NO_MATCH_RECORD );
        sSlotID = sSlotID % sTableObj->mMaxSize;

retry:
        _IF_THROW( sSlotID > mSegMgr->GetLastExtendSlotNo ( ), ERR_DBM_NO_MATCH_RECORD );

        sRC = mSegMgr->Slot2Addr ( sSlotID, &sRow );
        _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT ); //SLOT2ADDR_FAIL );


        /***********************************************
         * Row Lock
         *   1. Logging( DBM_LOCK_ROW_LOG )
         *   2. Row Lock 수행
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_LOCK_ROW_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         NULL,
                                         0,
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            if ( sRC ) //, WRITE_LOG_FAIL );
            {
                DBM_ERR( "write log fail. log_type[%d] table[%s] rc=%d", sLogType, mTableName, sRC );
                _THROW( ERR_DBM_WRITE_LOG );
            }
        }

        sRC = mRowLock( sTableObj->mInstName,
                        sSlotID,
                        sRow,
                        g_sBeforeImage_mDirectUpdateCol,
                        aTransID,
                        1 );

        if ( sRC )
        {
            if ( sRC == ERR_DBM_DEADLOCK_DETECTED ) //, DEAD_LOCK );
            {
                return ERR_DBM_DEADLOCK_DETECTED;   // 의도적
            }

            if ( sRC == ERR_DBM_ABNORMAL_ROLLBACK )
            {
                DBM_WARN( "direct updatecol abnormal rollback. txid[%d] table[%s] slot[%ld] rc=%d", aTransID, mTableName, sSlotID, sRC );
                goto retry;
            }

            _IF_THROW( sRC == ERR_DBM_NO_MATCH_RECORD, ERR_DBM_NO_MATCH_RECORD );
            _IF_THROW( sRC && (sRC != ERR_DBM_ABNORMAL_ROLLBACK), sRC ); //ROW_LOCK_FAIL );
        }

        /* lock 성공 후 보니 data 없으면 delete 된 것임 */
        _IF_THROW( sRow->mRowSize == 0, ERR_DBM_NO_MATCH_RECORD );


        /***********************************************
         * Before Image 를 logging 한다.
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_UPDATE_SLOT_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         g_sBeforeImage_mDirectUpdateCol,
                                         sRow->mRowSize + sizeof(dbmRowHeader),
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            if ( sRC ) //, WRITE_LOG_FAIL );
            {
                DBM_ERR( "write log fail. log_type[%d] table[%s] rc=%d", sLogType, mTableName, sRC );
                _THROW( ERR_DBM_WRITE_LOG );
            }
        }

        /***********************************************
         * Bind 된 컬럼별로 data 를 덮어쓴다.
         ***********************************************/
        sRow->mSCN = INFINITE_SCN;

        for ( i = 0; i < sBindCols->mBindCount; i++ )
        {
            //memset_s ( (char*)sRow + sizeof(dbmRowHeader) + sBindCols->mOffset[i], 0x00, sBindCols->mDataSize[i] );
            memcpy_s ( (char*)sRow + sizeof(dbmRowHeader) + sBindCols->mOffset[i],
                       sBindCols->mData + sBindCols->mOffset[i], sBindCols->mDataSize[i] );

            /***********************************************
             * Bind 된 컬럼이 Table 의 마지막 컬럼이면서
             * Char 형이면 현재 Row Size 를 지금 Update 하는
             * Data 의 길이에 따라 조정해주어야 한다.
             * 그래야만, Select 할 때 짤리지 않는 Data 를
             * 수신할 수 있다.
             ***********************************************/
            sTableColCount = mTableHeader->mCols.mCount;
            sTableLastCol = (dbmColumnObject*) &mTableHeader->mCols.mCols[sTableColCount - 1];

            if ( (sTableLastCol->mOffset == sBindCols->mOffset[i])
                    && (sTableLastCol->mColumnType == DBM_COLUMN_CHAR_TYPE) )
            {
                if ( (sRow->mRowSize - sBindCols->mOffset[i]) < sBindCols->mDataSize[i] )
                {
                    sRow->mRowSize = sBindCols->mOffset[i] + sBindCols->mDataSize[i];
                }
            }
        }


        /******************************************************************
         * mHandleTrigger
         *****************************************************************/
        if ( mTrigger != NULL )
        {
            sRC = mHandleTrigger ( DBM_EVENT_UPDATE_BEFORE,
                                   aTransID,
                                   g_sBeforeImage_mDirectUpdateCol + sizeof(dbmRowHeader)  ,
                                   sRow->mRowSize ) ;
            _IF_THROW ( sRC, ERR_DBM_TRIGGER_FAIL ) ;

            sRC = mHandleTrigger ( DBM_EVENT_UPDATE_AFTER,
                                   aTransID,
                                   (char*)sRow + sizeof(dbmRowHeader)  ,
                                   sRow->mRowSize ) ;
            _IF_THROW ( sRC, ERR_DBM_TRIGGER_FAIL ) ;
        }
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN2( mTableName );
        }
    }
    _FINALLY
    _END
} /* mDirectUpdateCol */


/********************************************************************************
 * Name : mUpdate
 *
 * Description
 *     update operation
 *
 ******************************************************************************/
__thread char* g_sBeforeImage_mUpdate = NULL;

_VOID dbmTableManager::mUpdate ( int             aTransID,
                                 void*           aDataObject,
                                 dbmTransHeader* aTxHead,
                                 long long*      aBackLogPos,
                                 long long*      aBackImagePos )

{
    long long       sSlotID = -1;
    long long       sRetrySlotID = -1;
    int             sLogType = DBM_LOG_TYPE_MAX; // 초기화 워닝제거
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    dbmRowHeader*   sRow = NULL;
    dbmLogHeader*   sLogHead = NULL;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    dbmIndexHeader* sIndexHead = NULL;
    dbmIndexHeader* sCmpIdxHead = NULL;
    //dbmIndexHeader* sTempIdxHead = NULL;
    //dbmIndexHeader* sTempIdxHead2 = NULL;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE]; // non-unique type check value 8 byte 2014.05.30 -shw-
    long long       sExtraKey = -1;                 // non-unique type bucket value
    long long       sBeforeExtraKey = -1;
    long long       sRetryCnt = 0;
    long long       sSCN;
    //int             sCond,i,j,k,l;
    int             i;
    int             sRC;
    int             sBackupF = 0;

    _TRY
    {
        /***********************************************
         * Big Stack 변수 제거
         ***********************************************/
        if ( g_sBeforeImage_mUpdate == NULL )
        {
            g_sBeforeImage_mUpdate = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );

            memset_s ( g_sBeforeImage_mUpdate,
                       0,
                       DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Trigger 체크 이미 삭제되었을 수도 있음.
         **********************************************/
        if ( mTrigger != NULL )
        {
            /** 만약 헤더에 Trigger 가 없다 */
            if ( mTableHeader->mEventQueue[0] == '\0' )
            {
                mTrigger = NULL;
            }
        }

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * TODO:wind 임시적으로 막음
         * Index 가 두개 이상이어도 에러 처리
         ***********************************************/
#if 0
#ifdef _DEBUG
        _IF_THROW( strncmp_s ( mInstName, SYS_DIC_PREFIX, strlen_s ( SYS_DIC_PREFIX ) ) && mIndexCount > 1, ERR_DBM_TOO_MANY_INDEX );
#else
        _IF_THROW( mInstName[0] != SYS_DIC_PREFIX_CHAR && mIndexCount > 1, ERR_DBM_TOO_MANY_INDEX );
#endif
#endif

        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectDelete() 함수 호출
         ***********************************************/
        if ( sTableObj->mTableType == DBM_TBL_DIRECT ||
             sTableObj->mTableType == DBM_TBL_SEQUENCE )
        {
            _CALL( mDirectUpdate ( aTransID, aDataObject ) );
            _RETURN;
        }

        /***********************************************
         * update 할 Row 존재하는지 검사.
         ***********************************************/
        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader ( );
        _CALL( mMakeKey ( &sIndexHead->mIndex, sData->mUserData, sKey ) );

retry:
        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            _rc = mIndex[mUseIndex]->mSearchKey ( aTransID, sKey, &sSlotID );
            sExtraKey = -1;
        }
        else
        {
            sBeforeExtraKey = sExtraKey;
            _rc = mIndex[mUseIndex]->mSearchKeyNu ( aTransID, sKey, &sSlotID, &sExtraKey );
        }

        if ( _rc != 0 )
        {
            _IF_THROW( _rc == ERR_DBM_KEY_NOT_EXIST, ERR_DBM_NO_MATCH_RECORD );
            _THROW( _rc );
        }
        else if ( sSlotID < 0 )
        {
            DBM_WARN( "mSearchKey SlotID=%d", sSlotID );
            _THROW( -1 );
        }

        _rc = mSegMgr->Slot2Addr ( sSlotID, &sRow );
        _IF_THROW( _rc, ERR_DBM_ALLOC_SLOT );


        /***********************************************
         * Row Lock
         *   1. Logging( DBM_LOCK_ROW_LOG )
         *   2. Row Lock 수행
         ***********************************************/
        if ( likely( ! sTableObj->mNoMemloggingF ) )
        {
            sLogType = DBM_LOCK_ROW_LOG;
            _rc = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         NULL,
                                         0,
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW( _rc, ERR_DBM_WRITE_LOG );
        }

        RTF_POINT("TBLMGR_UPDATE_1");

        _rc = mRowLock( sTableObj->mInstName,
                        sSlotID,
                        sRow,
                        g_sBeforeImage_mUpdate,
                        aTransID,
                        1 );

        RTF_POINT("TBLMGR_UPDATE_2");

        if ( _rc == ERR_DBM_ABNORMAL_ROLLBACK )
        {
            DBM_WARN("update abnormal rollback. txid[%d] table[%s] slot[%ld]",
                            aTransID, mTableName, sSlotID );
            if ( ! sIndexHead->mIndex.mIsUniqueIndex )
            {
                sExtraKey = sBeforeExtraKey;
            }

            goto retry;
        }
        else if ( _rc != 0 )
        {
            _IF_THROW( _rc == ERR_DBM_DEADLOCK_DETECTED, ERR_DBM_DEADLOCK_DETECTED ) ;
            _IF_THROW( _rc == ERR_DBM_NO_MATCH_RECORD, ERR_DBM_NO_MATCH_RECORD );
            _THROW( _rc );
        }

        /* 2015.07.17 -shw- Key  관련 동시성 제어를 위해 수정 
         * : T1 : Key1 (unique) , key2 (unique) --> 1 1
         * session 1: key 1 조건으로 key2에 대한 update
         * session 2: key 2 조건으로 deelte (session1 commit 전으로 lock 대기)
         * session 1 : commit
         * session 2 : lock을 풀리고 난후 보면 session1에서 key 변경 된 값임에도
         * 불구하고 기존의 select 한 값으로 delete 하게 되어서 success가 되어 버림
         * 이에 lock을 풀고 난후 다시 한번 기존의 key값을로 데이터가 있는지 검색 */

        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            _rc = mIndex[mUseIndex]->mSearchKey ( aTransID, sKey, &sRetrySlotID );
            sExtraKey = -1;
        }
        else
        {
            sExtraKey = sBeforeExtraKey;
lock_retry:
            _rc = mIndex[mUseIndex]->mSearchKeyNu ( aTransID, sKey, &sRetrySlotID, &sExtraKey );
        }

        if ( _rc == ERR_DBM_KEY_NOT_EXIST )
        {
            *aBackLogPos   = aTxHead->mLogCurPos;
            *aBackImagePos = aTxHead->mImageCurPos;

            _THROW( ERR_DBM_LOCK_NO_MATCH_RECORD );
        }

        if( sSlotID != sRetrySlotID )
        {
            if( sIndexHead->mIndex.mIsUniqueIndex == DBM_NON_UNIQUE && sExtraKey != -1 )
            {
                goto lock_retry;
            }
            else
            {
                *aBackLogPos   = aTxHead->mLogCurPos;
                *aBackImagePos = aTxHead->mImageCurPos;
                _THROW( ERR_DBM_LOCK_NO_MATCH_RECORD );
            }
        }

        /* 아래의 부분은 aBackLogPos 아래로 수정한 것은 마찬가지로 로깅을 하고 이미지
         * 백업을 하지 않으면 recovedry 할 수 없기 때문이다. -shw- 2015.07.17 */
        /* lock 성공 후 보니 data 없으면 delete 된 것임 */
        _IF_THROW( sRow->mRowSize == 0, ERR_DBM_NO_MATCH_RECORD );

        /***********************************************
         * update 하려는 데이터가 인덱스의 키 컬럼을 변경시키는지 확인하고 그렇다면 mUpdateKey 함수 호출
         * before image를 백업하는 데 아래와 같이 두가지 부류로 나뉜다.
         * 1. 키 변경을 하지 않는 일반적인 업데이트는 DBM_UPDATE_SLOT_LOG로
         * 2. 키 변경이 되는 키 업데이트는 DBM_UPDATE_KEY_LOG로
         * mUpdateKey 함수내에서 백업을 했다면 sBackupF 값이 활성화 되어 아래 백업을 건너뛰게 된다.
         ***********************************************/
        for( i = 0; i < mIndexCount; i++ )
        {
            /***********************************************
             * 내가 선택한 인덱스는 변경될리 없다.
             ***********************************************/
            if( i == mUseIndex )
            {
                continue;
            }
            sCmpIdxHead = mIndex[i]->mGetIndexHeader();
            _IF_THROW( sCmpIdxHead == NULL, ERR_DBM_TABLE_NOT_PREPARED );
            sRC = mCheckKey( sIndexHead, sCmpIdxHead, (char*)sRow + sizeof(dbmRowHeader), sData->mUserData );
            if( sRC )
            {
                //_PRT( "idx key different...idx(%d)\n", i );
                _CALL( mUpdateKey( aTransID, aTxHead, aBackLogPos, aBackImagePos, sSlotID, g_sBeforeImage_mUpdate, sRow, sLogHead, i, sData->mUserData, &sBackupF) );
            }
        }

        /***********************************************
         * Before Image 를 logging 한다.
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF && sBackupF == 0 )
        {
            sLogType = DBM_UPDATE_SLOT_LOG;
            _rc = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         g_sBeforeImage_mUpdate,
                                         sRow->mRowSize + sizeof(dbmRowHeader),
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            _IF_THROW( _rc, ERR_DBM_WRITE_LOG );
        }

        RTF_POINT("TBLMGR_UPDATE_3");

        /***********************************************
         * 새로운 Image 로 Row 를 덮어쓴다.
         ***********************************************/
        sRow->mSCN = INFINITE_SCN;

        RTF_POINT("TBLMGR_UPDATE_4");

        //마지막 컬럼이 char 형인 경우 업데이트 전후에 mRowSize가 변할수가 없을까?
        memcpy_s( (char*)sRow + sizeof(dbmRowHeader),
                  sData->mUserData,
                  sRow->mRowSize );

        /************************************************
         * 트리거 처리
         ************************************************/
        _rc = mHandleTrigger ( DBM_EVENT_UPDATE_BEFORE,
                               aTransID,
                               g_sBeforeImage_mUpdate + sizeof( dbmRowHeader ) ,
                               sRow->mRowSize ) ;
        _IF_THROW( _rc, ERR_DBM_TRIGGER_FAIL ) ;

        _rc = mHandleTrigger ( DBM_EVENT_UPDATE_AFTER,
                               aTransID,
                               (char*)sRow + sizeof(dbmRowHeader)  ,
                               sRow->mRowSize ) ;
        _IF_THROW( _rc, ERR_DBM_TRIGGER_FAIL ) ;


        sRetryCnt++;

        if ( sExtraKey != -1)
        {
            /* 이전 이미지 값을 백업해 놓는다. */
            *aBackLogPos   = aTxHead->mLogCurPos;
            *aBackImagePos = aTxHead->mImageCurPos;
            sBackupF = 0;

            goto retry;
        }

        if ( ! sIndexHead->mIndex.mIsUniqueIndex )
        {
            /* non-unique index count move */
            sData->mIndexCount = sRetryCnt;
        }

        if ( sTableObj->mNoMemloggingF )
        {
            /************************************************
             * mem nologging 에서는 auto commit 처럼 처리.
             ************************************************/
            mLogMgr->mGetSCN( &sSCN );

            sRow->mSCN  = sSCN;
            sRow->mLock = -1;
        }
    }
    _CATCH
    {
        if ( sTableObj->mNoMemloggingF )
        {
            sRow->mLock = -1;
        }

        if ( _rc == ERR_DBM_WRITE_LOG )
        {
            DBM_ERR( "write log fail. log_type[%d] table[%s]", sLogType, mTableName );
        }

        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN2( mTableName );
        }
    }
    _FINALLY
    _END
} /* mUpdate */

_VOID dbmTableManager::mFetchRange( int, void* )
{
    // 미구현
    _TRY
    {
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


/********************************************************************************
 * Name : mBindCol
 *
 * Description
 *     column binding before mUpdateCol
 *
 ******************************************************************************/
_VOID dbmTableManager::mBindCol( int aTransID, void* aDataObject )      // 2014.12.14. -okt- aTransID 미사용인자
{
    dbmDataObject*      sData      = (dbmDataObject *)aDataObject;
    dbmTableObject*     sTableObj  = &mTableHeader->mTableObj;
    dbmColumnSetObject* sCols      = NULL;
    dbmBindCols*        sBindCols  = NULL;
    int                 i, j;

    _TRY
    {
        sCols = (dbmColumnSetObject *) &mTableHeader->mCols;

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * Table Header 의 컬럼정보를 검색하여 존재하는
         * 컬럼인지 확인
         ***********************************************/
        for ( i = 0; i < sCols->mCount; i++ )
        {
            if ( !strcmp_s ( sData->mColName, sCols->mCols[i].mColumnName ) )
            {
                break;
            }
        }

        if ( i >= sCols->mCount ) //, INVALID_COLUMN );
        {
            DBM_WARN("invalid column name(%s), i=%d, mCount=%d", sData->mColName, i, sCols->mCount );
            _THROW( ERR_DBM_COLUMN_NOT_EXIST_IN_TABLE );
        }

        /***********************************************
         * Bind 할 데이터의 크기가 컬럼의 크기를 초과하면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > sCols->mCols[i].mSize, ERR_DBM_INVALID_DATA_SIZE );

        /***********************************************
         * 이미 Bind 한 놈인지 확인.
         * Bind 한놈이면 덮어쓴다.
         ***********************************************/
        sBindCols = (dbmBindCols *) mBindCols;

        for ( j = 0; j < sBindCols->mBindCount; j++ )
        {
            if ( !strcmp_s ( sData->mColName, sBindCols->mColName[j] ) )
            {
                break;
            }
        }

        /***********************************************
         * mUpdateCol 에서 Update 시 사용할 컬럼정보들을 설정
         ***********************************************/
        sBindCols->mOffset[j] = sCols->mCols[i].mOffset;
        sBindCols->mDataSize[j] = sData->mDataSize;
        sBindCols->mColSize[j] = sCols->mCols[i].mSize;

        /*
         * TOOD (OKT): (성능), memset 없애거나, 구간 줄일수 있을듯, 나중에. ( 2014.09.21 )
         */
        memset_s ( sBindCols->mData + sBindCols->mOffset[j], 0x00, sBindCols->mColSize[j] );
        memcpy_s ( sBindCols->mData + sBindCols->mOffset[j], sData->mUserData, sData->mDataSize );

        if ( j >= sBindCols->mBindCount )
        {
            strncpy_s ( sBindCols->mColName[j], sData->mColName, DBM_NAME_LEN );
            sBindCols->mBindCount++;
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mBindCol */


/********************************************************************************
 * Name : mClearBind
 *
 * Description
 *     clear bound columns
 *
 ******************************************************************************/
_VOID dbmTableManager::mClearBind( int aTransID, void* aDataObject )
{
    //TODO: [OKT] 이게 무슨 의미가 있을까? 실제 데이타가 0x00 일수도 있는데.
    memset_s ( mBindCols, 0x00, sizeof(dbmBindCols) );

    return 0;
}


/********************************************************************************
 * Name : mUpdateCol
 *
 * Description
 *     update bound columns
 *
 ******************************************************************************/
__thread char* g_sBeforeImage_mUpdateCol = NULL;
__thread char* g_sUpdateImage_mUpdateCol = NULL;

_VOID dbmTableManager::mUpdateCol ( int aTransID , void* aDataObject , dbmTransHeader* aTxHead ,
                                    long long* aBackLogPos , long long* aBackImagePos )
{
    long long       sSlotID = -1;
    long long       sRetrySlotID = -1;
    int             sLogType;
    dbmRowHeader*   sRow       = NULL;
    dbmRowHeader*   sUpdateRow = NULL;
    dbmLogHeader*   sLogHead   = NULL;
    dbmIndexHeader* sIndexHead = NULL;
    dbmIndexHeader* sCmpIdxHead = NULL;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    dbmBindCols*    sBindCols  = (dbmBindCols *)mBindCols;
    dbmDataObject*  sData = (dbmDataObject*)aDataObject;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE]; // non-unique type check value 8 byte 2014.05.30 -shw-
    int             sTableColCount;
    dbmColumnObject* sTableLastCol;
    long long       sExtraKey = -1;                 // non-unique type bucket value 2014.05.30 -shw-
    long long       sRetryCnt = 0;
    long long       sBeforeExtraKey = -1;
    long long       sSCN;
    int             i;
    int             sRC;
    //int             i, xi, xj, xk, xl;
    int             sBackupF = 0;

    _TRY
    {
        /***********************************************
         * Big Stack 변수 제거
         ***********************************************/
        if ( unlikely( g_sBeforeImage_mUpdateCol == NULL ) )
        {
            g_sBeforeImage_mUpdateCol = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            memset_s ( g_sBeforeImage_mUpdateCol, 0, DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }

        if ( unlikely( g_sUpdateImage_mUpdateCol == NULL ) )
        {
            g_sUpdateImage_mUpdateCol = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            memset_s ( g_sUpdateImage_mUpdateCol, 0, DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }
        sUpdateRow = (dbmRowHeader*)g_sUpdateImage_mUpdateCol;

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Trigger 체크 이미 삭제되었을 수도 있음.
         **********************************************/
        if ( mTrigger != NULL )
        {
            /** 만약 헤더에 Trigger 가 없다 */
            if ( mTableHeader->mEventQueue[0] == '\0' )
            {
                mTrigger = NULL;
            }
        }

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectUpdateCol() 함수 호출
         ***********************************************/
        if ( sTableObj->mTableType == DBM_TBL_DIRECT )
        {
            return mDirectUpdateCol ( aTransID, aDataObject );
        }

        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader ( );
        _IF_THROW( sIndexHead == NULL, ERR_DBM_TABLE_NOT_PREPARED ); // INDEX_NOT_READY );

        /***********************************************
         * Index Search 수행
         ***********************************************/
        //memset_s( sKey, 0x00, DBM_INDEX_KEY_MAX_SIZE );
        _CALL( mMakeKey ( &sIndexHead->mIndex, sBindCols->mData, sKey ) );

retry:
        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            sRC = mIndex[mUseIndex]->mSearchKey ( aTransID, sKey, &sSlotID );
            sExtraKey = -1;
        }
        else
        {
            sBeforeExtraKey = sExtraKey;
            sRC = mIndex[mUseIndex]->mSearchKeyNu ( aTransID, sKey, &sSlotID, &sExtraKey );
        }

        if ( sRC )
        {
            _IF_THROW( sRC == ERR_DBM_KEY_NOT_EXIST, ERR_DBM_NO_MATCH_RECORD );
            _THROW( sRC ); // || sSlotID < 0, SEARCH_KEY_FAIL );
        }
        // 2014.12.14. -okt- 성공인데 음수 가능할까? 이렇게 검사안해도 되게 작성해야함.
        _IF_THROW( sSlotID < 0, -1 ); // SEARCH_KEY_FAIL );


        sRC = mSegMgr->Slot2Addr ( sSlotID, &sRow );
        _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT );


        /***********************************************
         * Row Lock
         *   1. Logging( DBM_LOCK_ROW_LOG )
         *   2. Row Lock 수행
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_LOCK_ROW_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         NULL,
                                         0,
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            if ( sRC ) // , WRITE_LOG_FAIL );
            {
                DBM_ERR( "write log fail. log_type[%d] table[%s] rc=%d", sLogType, mTableName, sRC );
                sRC = ERR_DBM_WRITE_LOG;
            }
        }

        sRC = mRowLock( sTableObj->mInstName,
                        sSlotID,
                        sRow,
                        g_sBeforeImage_mUpdateCol,
                        aTransID,
                        1 );
        if ( sRC )
        {
            if ( sRC == ERR_DBM_DEADLOCK_DETECTED ) // , DEAD_LOCK );
            {
                return ERR_DBM_DEADLOCK_DETECTED;   // 의도적
            }

            if ( sRC == ERR_DBM_ABNORMAL_ROLLBACK )
            {
                DBM_WARN( "updatecol abnormal rollback. txid[%d] table[%s] slot[%ld]", aTransID, mTableName, sSlotID );

                if ( !sIndexHead->mIndex.mIsUniqueIndex )
                {
                    sExtraKey = sBeforeExtraKey;
                }

                goto retry;
            }

            //_IF_RAISE( sRC == ERR_DBM_NO_MATCH_RECORD, NOT_FOUND );
            _THROW( sRC ); //&& (sRC != ERR_DBM_ABNORMAL_ROLLBACK), ROW_LOCK_FAIL );
        }

        /* 2015.07.17 -shw- Key  관련 동시성 제어를 위해 수정 
         * : T1 : Key1 (unique) , key2 (unique) --> 1 1
         * session 1: key 1 조건으로 key2에 대한 update
         * session 2: key 2 조건으로 deelte (session1 commit 전으로 lock 대기)
         * session 1 : commit
         * session 2 : lock을 풀리고 난후 보면 session1에서 key 변경 된 값임에도
         * 불구하고 기존의 select 한 값으로 delete 하게 되어서 success가 되어 버림
         * 이에 lock을 풀고 난후 다시 한번 기존의 key값을로 데이터가 있는지 검색 */
        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            sRC = mIndex[mUseIndex]->mSearchKey ( aTransID, sKey, &sRetrySlotID );
            sExtraKey = -1;
        }
        else
        {
            sExtraKey = sBeforeExtraKey;
lock_retry:
            sRC = mIndex[mUseIndex]->mSearchKeyNu ( aTransID, sKey, &sRetrySlotID, &sExtraKey );
        }

        if ( sRC == ERR_DBM_KEY_NOT_EXIST )
        {
            *aBackLogPos = aTxHead->mLogCurPos;
            *aBackImagePos = aTxHead->mImageCurPos;

            _THROW( ERR_DBM_LOCK_NO_MATCH_RECORD );
        }

        if( sSlotID != sRetrySlotID )
        {
            if( sIndexHead->mIndex.mIsUniqueIndex == DBM_NON_UNIQUE && sExtraKey != -1 )
            {
                goto lock_retry;
            }
            else
            {
                *aBackLogPos   = aTxHead->mLogCurPos;
                *aBackImagePos = aTxHead->mImageCurPos;
                _THROW( ERR_DBM_LOCK_NO_MATCH_RECORD );
            }
        }

        memcpy_s ( g_sUpdateImage_mUpdateCol, sRow, sizeof(dbmRowHeader) + sRow->mRowSize );
        /* lock 성공 후 보니 data 없으면 delete 된 것임 */
        _IF_THROW( sRow->mRowSize == 0, ERR_DBM_NO_MATCH_RECORD );

        /***********************************************
         * 임의의 공간에 키 컬럼이 변경되는지 확인할 로우이미지를 만들어낸다.
         ***********************************************/
        sTableColCount = mTableHeader->mCols.mCount;
        for ( i = 0; i < sBindCols->mBindCount; i++ )
        {
            memcpy_s ( g_sUpdateImage_mUpdateCol + sizeof(dbmRowHeader) + sBindCols->mOffset[i],
                       sBindCols->mData + sBindCols->mOffset[i], sBindCols->mColSize[i] );

            /***********************************************
             * Bind 된 컬럼이 Table 의 마지막 컬럼이면서
             * Char 형이면 현재 Row Size 를 지금 Update 하는
             * Data 의 길이에 따라 조정해주어야 한다.
             * 그래야만, Select 할 때 짤리지 않는 Data 를
             * 수신할 수 있다.
             ***********************************************/
            sTableLastCol = (dbmColumnObject*) &mTableHeader->mCols.mCols[sTableColCount - 1];

            if ( ( sTableLastCol->mOffset == sBindCols->mOffset[i] )
                    && ( sTableLastCol->mColumnType == DBM_COLUMN_CHAR_TYPE ) )
            {
                if ( ( sUpdateRow->mRowSize - sBindCols->mOffset[i] ) < sBindCols->mDataSize[i] )
                {
                    sUpdateRow->mRowSize = sBindCols->mOffset[i] + sBindCols->mDataSize[i];
                }
            }
        }

        /***********************************************
         * update 하려는 데이터가 인덱스의 키 컬럼을 변경시키는지 확인하고 그렇다면 mUpdateKey 함수 호출
         * before image를 백업하는 데 아래와 같이 두가지 부류로 나뉜다.
         * 1. 키 변경을 하지 않는 일반적인 업데이트는 DBM_UPDATE_SLOT_LOG로
         * 2. 키 변경이 되는 키 업데이트는 DBM_UPDATE_KEY_LOG로
         * mUpdateKey 함수내에서 백업을 했다면 sBackupF 값이 활성화 되어 아래 백업을 건너뛰게 된다.
         ***********************************************/
        for( i = 0; i < mIndexCount; i++ )
        {
            /***********************************************
             * 내가 선택한 인덱스는 변경될리 없다.
             ***********************************************/
            if( i == mUseIndex )
            {
                continue;
            }
            sCmpIdxHead = mIndex[i]->mGetIndexHeader();
            _IF_THROW( sCmpIdxHead == NULL, ERR_DBM_TABLE_NOT_PREPARED );
            sRC = mCheckKey( sIndexHead, sCmpIdxHead, (char*)sRow + sizeof(dbmRowHeader), g_sUpdateImage_mUpdateCol + sizeof(dbmRowHeader) );
            if( sRC )
            {
                //_PRT( "idx key different...idx(%d)\n", i );
                _CALL( mUpdateKey( aTransID, aTxHead, aBackLogPos, aBackImagePos, sSlotID, g_sBeforeImage_mUpdateCol, sRow, sLogHead, i, g_sUpdateImage_mUpdateCol + sizeof(dbmRowHeader), &sBackupF) );
                //continue;
            }
        }

        /***********************************************
         * Before Image 를 logging 한다.
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF && sBackupF == 0 )
        {
            sLogType = DBM_UPDATE_SLOT_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         g_sBeforeImage_mUpdateCol,
                                         sRow->mRowSize + sizeof(dbmRowHeader),
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            if ( sRC ) // , WRITE_LOG_FAIL );
            {
                DBM_ERR( "write log fail. log_type[%d] table[%s] rc=%d", sLogType, mTableName, sRC );
                sRC = ERR_DBM_WRITE_LOG;
            }
        }

        /***********************************************
         * 위에서 준비한 update 될 이미지로 한방에 엎어친다.
         ***********************************************/
        sRow->mSCN = INFINITE_SCN;

        memcpy_s( (char*)sRow + sizeof(dbmRowHeader), g_sUpdateImage_mUpdateCol + sizeof(dbmRowHeader), sUpdateRow->mRowSize );
        sRow->mRowSize = sUpdateRow->mRowSize;

        /******************************************************************
         * mHandleTrigger
         *****************************************************************/
        if ( mTrigger != NULL )
        {
            sRC = mHandleTrigger ( DBM_EVENT_UPDATE_BEFORE,
                                   aTransID,
                                   g_sBeforeImage_mUpdateCol + sizeof(dbmRowHeader)  ,
                                   sRow->mRowSize ) ;
            _IF_THROW ( sRC, ERR_DBM_TRIGGER_FAIL ) ;
            sRC = mHandleTrigger ( DBM_EVENT_UPDATE_AFTER,
                                   aTransID,
                                   (char*)sRow + sizeof(dbmRowHeader)  ,
                                   sRow->mRowSize ) ;
            _IF_THROW ( sRC, ERR_DBM_TRIGGER_FAIL );
        }

        sRetryCnt++;

        if ( sExtraKey != -1 )
        {
            /* 이전 이미지 값을 백업해 놓는다. */
            *aBackLogPos = aTxHead->mLogCurPos;
            *aBackImagePos = aTxHead->mImageCurPos;
            sBackupF = 0;

            goto retry;
        }

        if ( !sIndexHead->mIndex.mIsUniqueIndex )
        {
            /* non-unique index count move */
            sData->mIndexCount = sRetryCnt;
        }

        if ( sTableObj->mNoMemloggingF )
        {
            /************************************************
             * mem nologging 에서는 auto commit 처럼 처리.
             ************************************************/
            mLogMgr->mGetSCN ( &sSCN );

            sRow->mSCN = sSCN;
            sRow->mLock = -1;
        }
    }
    _CATCH
    {
        if ( sTableObj->mNoMemloggingF )
        {
            if ( sRow != NULL )
            {
                sRow->mLock = -1;
            }
        }

        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN2( mTableName );
        }
    }
    _FINALLY
    _END
} /* mUpdateCol */

_VOID dbmTableManager::mUpdateColGT ( int aTransID , void* aDataObject , dbmTransHeader* aTxHead ,
                                    long long* aBackLogPos , long long* aBackImagePos )
{
    long long       sSlotID = -1;
    int             sLogType;
    dbmRowHeader*   sRow       = NULL;
    dbmRowHeader*   sUpdateRow = (dbmRowHeader*)g_sUpdateImage_mUpdateCol;
    dbmLogHeader*   sLogHead   = NULL;
    dbmIndexHeader* sIndexHead = NULL;
    dbmIndexHeader* sCmpIdxHead = NULL;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    dbmBindCols*    sBindCols  = (dbmBindCols *)mBindCols;
    dbmDataObject   sData;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE]; // non-unique type check value 8 byte 2014.05.30 -shw-
    char            sNextKey[DBM_NON_UNIQUE_KEY_SIZE];
    int             sTableColCount;
    dbmColumnObject* sTableLastCol;
    long long       sRetryCnt = 0;
    long long       sExtraKey = -1;                 // non-unique type bucket value 2014.05.30 -shw-
    long long       sBeforeExtraKey = -1;
    long long       sSCN;
    int             i, j;
    int             sRC;
    //int             i, xi, xj, xk, xl;
    int             sBackupF = 0;

    _TRY
    {
        /***********************************************
         * Big Stack 변수 제거
         ***********************************************/
        if ( unlikely( g_sBeforeImage_mUpdateCol == NULL ) )
        {
            g_sBeforeImage_mUpdateCol = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            memset_s ( g_sBeforeImage_mUpdateCol, 0, DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }

        if ( unlikely( g_sUpdateImage_mUpdateCol == NULL ) )
        {
            g_sUpdateImage_mUpdateCol = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            memset_s ( g_sUpdateImage_mUpdateCol, 0, DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            sUpdateRow = (dbmRowHeader*)g_sUpdateImage_mUpdateCol;
        }

        memset_s( &sData, 0x00, sizeof(sData) );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Trigger 체크 이미 삭제되었을 수도 있음.
         **********************************************/
        if ( mTrigger != NULL )
        {
            /** 만약 헤더에 Trigger 가 없다 */
            if ( mTableHeader->mEventQueue[0] == '\0' )
            {
                mTrigger = NULL;
            }
        }

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectUpdateCol() 함수 호출
         ***********************************************/
        if ( sTableObj->mTableType == DBM_TBL_DIRECT )
        {
            _THROW( ERR_DBM_INVALID_OBJECT );
            //return mDirectUpdateCol ( aTransID, aDataObject );
        }

        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader ( );
        _IF_THROW( sIndexHead == NULL, ERR_DBM_TABLE_NOT_PREPARED ); // INDEX_NOT_READY );

        /***********************************************
         * Index Search 수행
         ***********************************************/
        //memset_s( sKey, 0x00, DBM_INDEX_KEY_MAX_SIZE );
        _CALL( mMakeKey ( &sIndexHead->mIndex, sBindCols->mData, sKey ) );

retry:
        sBackupF = 0;
        memset_s ( sNextKey, 0x00, DBM_NON_UNIQUE_KEY_SIZE );
        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            if ( likely( sData.mFetchInd < sData.mFetchCount ) )
            {
                sSlotID = sData.mFetchRows [sData.mFetchInd];
                memcpy_s( sNextKey, sData.mFetchKey[sData.mFetchInd], DBM_NON_UNIQUE_KEY_SIZE );
                sData.mFetchInd++;
                sRC = 0;
            }
            else
            {
                sData.mFetchCount = 0;
                sData.mFetchInd   = 1;
                sRC = mIndex[mUseIndex]->mSearchKeyGT ( aTransID, sKey, sData.mFetchRows, &sData.mFetchCount, sData.mFetchKey, sData.mEQCnt );
                sSlotID = sData.mFetchRows[0];
                memcpy_s( sNextKey, sData.mFetchKey[0], DBM_NON_UNIQUE_KEY_SIZE );
            }

        }
        else
        {
            sBeforeExtraKey = sExtraKey;
            sRC = mIndex[mUseIndex]->mSearchKeyGTNu ( aTransID, sKey, &sSlotID, sNextKey ,&sExtraKey, sData.mEQCnt );
        }
        //_IF_THROW( sRC == ERR_DBM_KEY_NOT_EXIST, RC_SUCCESS );
        if( sRC == ERR_DBM_KEY_NOT_EXIST )
        {
            if( sRetryCnt == 0 )
            {
                _THROW( ERR_DBM_NO_MATCH_RECORD );
            }
            else
            {
                return RC_SUCCESS;
            }
        }
        _IF_THROW( sRC || sSlotID < 0, sRC /* SEARCH_KEY_FAIL */ );

        sRC = mSegMgr->Slot2Addr ( sSlotID, &sRow );
        _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT );

        /***********************************************
         * Row Lock
         *   1. Logging( DBM_LOCK_ROW_LOG )
         *   2. Row Lock 수행
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_LOCK_ROW_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         NULL,
                                         0,
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            if ( sRC ) // , WRITE_LOG_FAIL );
            {
                DBM_ERR( "write log fail. log_type[%d] table[%s] rc=%d", sLogType, mTableName, sRC );
                sRC = ERR_DBM_WRITE_LOG;
            }
        }

        sRC = mRowLock( sTableObj->mInstName,
                        sSlotID,
                        sRow,
                        g_sBeforeImage_mUpdateCol,
                        aTransID,
                        1 );
        if ( sRC )
        {
            if ( sRC == ERR_DBM_DEADLOCK_DETECTED ) // , DEAD_LOCK );
            {
                return ERR_DBM_DEADLOCK_DETECTED;   // 의도적
            }

            if ( sRC == ERR_DBM_ABNORMAL_ROLLBACK )
            {
                DBM_WARN( "updatecol abnormal rollback. txid[%d] table[%s] slot[%ld]", aTransID, mTableName, sSlotID );

                if ( !sIndexHead->mIndex.mIsUniqueIndex )
                {
                    sExtraKey = sBeforeExtraKey;
                }

                goto retry;
            }

            //_IF_RAISE( sRC == ERR_DBM_NO_MATCH_RECORD, NOT_FOUND );
            _THROW( sRC ); //&& (sRC != ERR_DBM_ABNORMAL_ROLLBACK), ROW_LOCK_FAIL );
        }

        memcpy_s ( g_sUpdateImage_mUpdateCol, sRow, sizeof(dbmRowHeader) + sRow->mRowSize );
        /* lock 성공 후 보니 data 없으면 delete 된 것임 */
        //_IF_THROW( sRow->mRowSize == 0, ERR_DBM_NO_MATCH_RECORD );
        if( sRow->mRowSize == 0 )
        {
            if ( sExtraKey != -1 || sNextKey != 0x00 )
            {
                /* 이전 이미지 값을 백업해 놓는다. */
                //*aBackLogPos = aTxHead->mLogCurPos;
                //*aBackImagePos = aTxHead->mImageCurPos;
                memcpy_s ( sKey, sNextKey, sizeof(sKey) );

                goto retry;
            }
            if ( sRetryCnt == 0 )
            {
                _THROW( ERR_DBM_NO_MATCH_RECORD );
            }
            else
            {
                return RC_SUCCESS;
            }
        }

        /***********************************************
         * 임의의 공간에 키 컬럼이 변경되는지 확인할 로우이미지를 만들어낸다.
         ***********************************************/
        sTableColCount = mTableHeader->mCols.mCount;
        for ( i = 0; i < sBindCols->mBindCount; i++ )
        {
            /***********************************************
             * mUpdateCol과는 다르게 LT에 의해 키컬럼은 계속 변경되므로 
             * bind에서 키 컬럼은 가져오면 안된다.
             ***********************************************/
            for( j = 0; j < sIndexHead->mIndex.mColumnCount; j++ )
            {
                if( sBindCols->mOffset[i] == sIndexHead->mIndex.mKey[j].mOffset )
                {
                    break;
                }
            }
            if( sBindCols->mOffset[i] == sIndexHead->mIndex.mKey[j].mOffset )
            {
                continue;
            }
            memcpy_s ( (char*)g_sUpdateImage_mUpdateCol + sizeof(dbmRowHeader) + sBindCols->mOffset[i],
                       sBindCols->mData + sBindCols->mOffset[i], sBindCols->mColSize[i] );

            /***********************************************
             * Bind 된 컬럼이 Table 의 마지막 컬럼이면서
             * Char 형이면 현재 Row Size 를 지금 Update 하는
             * Data 의 길이에 따라 조정해주어야 한다.
             * 그래야만, Select 할 때 짤리지 않는 Data 를
             * 수신할 수 있다.
             ***********************************************/
            sTableLastCol = (dbmColumnObject*) &mTableHeader->mCols.mCols[sTableColCount - 1];

            if ( ( sTableLastCol->mOffset == sBindCols->mOffset[i] )
                    && ( sTableLastCol->mColumnType == DBM_COLUMN_CHAR_TYPE ) )
            {
                if ( ( sUpdateRow->mRowSize - sBindCols->mOffset[i] ) < sBindCols->mDataSize[i] )
                {
                    sUpdateRow->mRowSize = sBindCols->mOffset[i] + sBindCols->mDataSize[i];
                }
            }
        }

        /***********************************************
         * update 하려는 데이터가 인덱스의 키 컬럼을 변경시키는지 확인하고 그렇다면 mUpdateKey 함수 호출
         * before image를 백업하는 데 아래와 같이 두가지 부류로 나뉜다.
         * 1. 키 변경을 하지 않는 일반적인 업데이트는 DBM_UPDATE_SLOT_LOG로
         * 2. 키 변경이 되는 키 업데이트는 DBM_UPDATE_KEY_LOG로
         * mUpdateKey 함수내에서 백업을 했다면 sBackupF 값이 활성화 되어 아래 백업을 건너뛰게 된다.
         ***********************************************/
        for( i = 0; i < mIndexCount; i++ )
        {
            /***********************************************
             * 내가 선택한 인덱스는 변경될리 없다.
             ***********************************************/
            if( i == mUseIndex )
            {
                continue;
            }
            sCmpIdxHead = mIndex[i]->mGetIndexHeader();
            _IF_THROW( sCmpIdxHead == NULL, ERR_DBM_TABLE_NOT_PREPARED );
            sRC = mCheckKey( sIndexHead, sCmpIdxHead, (char*)sRow + sizeof(dbmRowHeader), g_sUpdateImage_mUpdateCol + sizeof(dbmRowHeader) );
            if( sRC )
            {
                _CALL( mUpdateKey( aTransID, aTxHead, aBackLogPos, aBackImagePos, sSlotID, g_sBeforeImage_mUpdateCol, sRow, sLogHead, i, g_sUpdateImage_mUpdateCol + sizeof(dbmRowHeader), &sBackupF) );
                //continue;
            }
        }

        /***********************************************
         * Before Image 를 logging 한다.
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF && sBackupF == 0 )
        {
            sLogType = DBM_UPDATE_SLOT_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         g_sBeforeImage_mUpdateCol,
                                         sRow->mRowSize + sizeof(dbmRowHeader),
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            if ( sRC ) // , WRITE_LOG_FAIL );
            {
                DBM_ERR( "write log fail. log_type[%d] table[%s] rc=%d", sLogType, mTableName, sRC );
                sRC = ERR_DBM_WRITE_LOG;
            }
        }

        /***********************************************
         * 위에서 준비한 update 될 이미지로 한방에 엎어친다.
         ***********************************************/
        sRow->mSCN = INFINITE_SCN;

        memcpy_s( (char*)sRow + sizeof(dbmRowHeader), g_sUpdateImage_mUpdateCol + sizeof(dbmRowHeader), sUpdateRow->mRowSize );
        sRow->mRowSize = sUpdateRow->mRowSize;

        /******************************************************************
         * mHandleTrigger
         *****************************************************************/
        if ( mTrigger != NULL )
        {
            sRC = mHandleTrigger ( DBM_EVENT_UPDATE_BEFORE,
                                   aTransID,
                                   g_sBeforeImage_mUpdateCol + sizeof(dbmRowHeader)  ,
                                   sRow->mRowSize ) ;
            _IF_THROW ( sRC, ERR_DBM_TRIGGER_FAIL ) ;
            sRC = mHandleTrigger ( DBM_EVENT_UPDATE_AFTER,
                                   aTransID,
                                   (char*)sRow + sizeof(dbmRowHeader)  ,
                                   sRow->mRowSize ) ;
            _IF_THROW ( sRC, ERR_DBM_TRIGGER_FAIL );
        }

        sRetryCnt++;

        if ( sExtraKey != -1 || sNextKey != 0x00 )
        {
            /* 이전 이미지 값을 백업해 놓는다. */
            *aBackLogPos = aTxHead->mLogCurPos;
            *aBackImagePos = aTxHead->mImageCurPos;
            memcpy_s ( sKey, sNextKey, sizeof(sKey) );

            goto retry;
        }

        if ( sTableObj->mNoMemloggingF )
        {
            /************************************************
             * mem nologging 에서는 auto commit 처럼 처리.
             ************************************************/
            mLogMgr->mGetSCN ( &sSCN );

            sRow->mSCN = sSCN;
            sRow->mLock = -1;
        }
    }
    _CATCH
    {
        /*
        if ( sTableObj->mNoMemloggingF )
        {
            if ( sRow != NULL )
            {
                sRow->mLock = -1;
            }
        }
        */

        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN2( mTableName );
        }
    }
    _FINALLY
    _END
} /* mUpdateColGT */

_VOID dbmTableManager::mUpdateColLT ( int aTransID , void* aDataObject , dbmTransHeader* aTxHead ,
                                    long long* aBackLogPos , long long* aBackImagePos )
{
    long long       sSlotID = -1;
    int             sLogType;
    dbmRowHeader*   sRow       = NULL;
    dbmRowHeader*   sUpdateRow = (dbmRowHeader*)g_sUpdateImage_mUpdateCol;
    dbmLogHeader*   sLogHead   = NULL;
    dbmIndexHeader* sIndexHead = NULL;
    dbmIndexHeader* sCmpIdxHead = NULL;
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    dbmBindCols*    sBindCols  = (dbmBindCols *)mBindCols;
    dbmDataObject   sData;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE]; // non-unique type check value 8 byte 2014.05.30 -shw-
    char            sPrevKey[DBM_NON_UNIQUE_KEY_SIZE];
    int             sTableColCount;
    dbmColumnObject* sTableLastCol;
    long long       sRetryCnt = 0;
    long long       sExtraKey = -1;                 // non-unique type bucket value 2014.05.30 -shw-
    long long       sBeforeExtraKey = -1;
    long long       sSCN;
    int             i, j;
    int             sRC;
    //int             i, xi, xj, xk, xl;
    int             sBackupF = 0;

    _TRY
    {
        /***********************************************
         * Big Stack 변수 제거
         ***********************************************/
        if ( unlikely( g_sBeforeImage_mUpdateCol == NULL ) )
        {
            g_sBeforeImage_mUpdateCol = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            memset_s ( g_sBeforeImage_mUpdateCol, 0, DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
        }

        if ( unlikely( g_sUpdateImage_mUpdateCol == NULL ) )
        {
            g_sUpdateImage_mUpdateCol = (char*) malloc_s ( DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            memset_s ( g_sUpdateImage_mUpdateCol, 0, DBM_MAX_RECORD_SIZE + sizeof(dbmRowHeader) );
            sUpdateRow = (dbmRowHeader*)g_sUpdateImage_mUpdateCol;
        }

        memset_s( &sData, 0x00, sizeof(sData) );

        /***********************************************
         * dbmTableHeader 에서 table type 이
         * DBM_TBL_QUEUE 이면 에러
         ***********************************************/
        _IF_THROW( sTableObj->mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * Trigger 체크 이미 삭제되었을 수도 있음.
         **********************************************/
        if ( mTrigger != NULL )
        {
            /** 만약 헤더에 Trigger 가 없다 */
            if ( mTableHeader->mEventQueue[0] == '\0' )
            {
                mTrigger = NULL;
            }
        }

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( sTableObj->mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * Index 가 하나도 안만들어져 있으면 에러
         ***********************************************/
        _IF_THROW( mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * table type 이 DBM_TBL_DIRECT 이면
         * mDirectUpdateCol() 함수 호출
         ***********************************************/
        if ( sTableObj->mTableType == DBM_TBL_DIRECT )
        {
            _THROW( ERR_DBM_INVALID_OBJECT );
            //return mDirectUpdateCol ( aTransID, aDataObject );
        }

        sIndexHead = mIndex[mUseIndex]->mGetIndexHeader ( );
        _IF_THROW( sIndexHead == NULL, ERR_DBM_TABLE_NOT_PREPARED ); // INDEX_NOT_READY );

        /***********************************************
         * Index Search 수행
         ***********************************************/
        //memset_s( sKey, 0x00, DBM_INDEX_KEY_MAX_SIZE );
        _CALL( mMakeKey ( &sIndexHead->mIndex, sBindCols->mData, sKey ) );

retry:
        sBackupF = 0;
        memset_s ( sPrevKey, 0x00, DBM_NON_UNIQUE_KEY_SIZE );
        if ( sIndexHead->mIndex.mIsUniqueIndex )
        {
            if ( likely( sData.mFetchInd < sData.mFetchCount ) )
            {
                sSlotID = sData.mFetchRows [sData.mFetchInd];
                memcpy_s( sPrevKey, sData.mFetchKey[sData.mFetchInd], DBM_NON_UNIQUE_KEY_SIZE );
                sData.mFetchInd++;
                sRC = 0;
            }
            else
            {
                sData.mFetchCount = 0;
                sData.mFetchInd   = 1;
                sRC = mIndex[mUseIndex]->mSearchKeyLT ( aTransID, sKey, sData.mFetchRows, &sData.mFetchCount, sData.mFetchKey, sData.mEQCnt );
                sSlotID = sData.mFetchRows[0];
                memcpy_s( sPrevKey, sData.mFetchKey[0], DBM_NON_UNIQUE_KEY_SIZE );
            }
        }
        else
        {
            sBeforeExtraKey = sExtraKey;
            sRC = mIndex[mUseIndex]->mSearchKeyLTNu ( aTransID, sKey, &sSlotID, sPrevKey ,&sExtraKey, sData.mEQCnt );
        }
        if( sRC == ERR_DBM_KEY_NOT_EXIST )
        {
            if( sRetryCnt == 0 )
            {
                _THROW( ERR_DBM_NO_MATCH_RECORD );
            }
            else
            {
                return RC_SUCCESS;
            }
        }
        _IF_THROW( sRC || sSlotID < 0, sRC /* SEARCH_KEY_FAIL */ );

        sRC = mSegMgr->Slot2Addr ( sSlotID, &sRow );
        _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT );

        /***********************************************
         * Row Lock
         *   1. Logging( DBM_LOCK_ROW_LOG )
         *   2. Row Lock 수행
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF )
        {
            sLogType = DBM_LOCK_ROW_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         NULL,
                                         0,
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            if ( sRC ) // , WRITE_LOG_FAIL );
            {
                DBM_ERR( "write log fail. log_type[%d] table[%s] rc=%d", sLogType, mTableName, sRC );
                sRC = ERR_DBM_WRITE_LOG;
            }
        }

        sRC = mRowLock( sTableObj->mInstName,
                        sSlotID,
                        sRow,
                        g_sBeforeImage_mUpdateCol,
                        aTransID,
                        1 );
        if ( sRC )
        {
            if ( sRC == ERR_DBM_DEADLOCK_DETECTED ) // , DEAD_LOCK );
            {
                return ERR_DBM_DEADLOCK_DETECTED;   // 의도적
            }

            if ( sRC == ERR_DBM_ABNORMAL_ROLLBACK )
            {
                DBM_WARN( "updatecol abnormal rollback. txid[%d] table[%s] slot[%ld]", aTransID, mTableName, sSlotID );

                if ( !sIndexHead->mIndex.mIsUniqueIndex )
                {
                    sExtraKey = sBeforeExtraKey;
                }

                goto retry;
            }

            //_IF_RAISE( sRC == ERR_DBM_NO_MATCH_RECORD, NOT_FOUND );
            _THROW( sRC ); //&& (sRC != ERR_DBM_ABNORMAL_ROLLBACK), ROW_LOCK_FAIL );
        }

        memcpy_s ( g_sUpdateImage_mUpdateCol, sRow, sizeof(dbmRowHeader) + sRow->mRowSize );
        /* lock 성공 후 보니 data 없으면 delete 된 것임 */
        //_IF_THROW( sRow->mRowSize == 0, ERR_DBM_NO_MATCH_RECORD );
        if( sRow->mRowSize == 0 )
        {
            if ( sExtraKey != -1 || sPrevKey != 0x00 )
            {
                /* 이전 이미지 값을 백업해 놓는다. */
                //*aBackLogPos = aTxHead->mLogCurPos;
                //*aBackImagePos = aTxHead->mImageCurPos;
                memcpy_s ( sKey, sPrevKey, sizeof(sKey) );

                goto retry;
            }
            if ( sRetryCnt == 0 )
            {
                _THROW( ERR_DBM_NO_MATCH_RECORD );
            }
            else
            {
                return RC_SUCCESS;
            }
        }

        /***********************************************
         * 임의의 공간에 키 컬럼이 변경되는지 확인할 로우이미지를 만들어낸다.
         ***********************************************/
        sTableColCount = mTableHeader->mCols.mCount;
        for ( i = 0; i < sBindCols->mBindCount; i++ )
        {
            /***********************************************
             * mUpdateCol과는 다르게 LT에 의해 키컬럼은 계속 변경되므로 
             * bind에서 키 컬럼은 가져오면 안된다.
             ***********************************************/
            for( j = 0; j < sIndexHead->mIndex.mColumnCount; j++ )
            {
                if( sBindCols->mOffset[i] == sIndexHead->mIndex.mKey[j].mOffset )
                {
                    break;
                }
            }
            if( sBindCols->mOffset[i] == sIndexHead->mIndex.mKey[j].mOffset )
            {
                continue;
            }
            memcpy_s ( (char*)g_sUpdateImage_mUpdateCol + sizeof(dbmRowHeader) + sBindCols->mOffset[i],
                       sBindCols->mData + sBindCols->mOffset[i], sBindCols->mColSize[i] );

            /***********************************************
             * Bind 된 컬럼이 Table 의 마지막 컬럼이면서
             * Char 형이면 현재 Row Size 를 지금 Update 하는
             * Data 의 길이에 따라 조정해주어야 한다.
             * 그래야만, Select 할 때 짤리지 않는 Data 를
             * 수신할 수 있다.
             ***********************************************/
            sTableLastCol = (dbmColumnObject*) &mTableHeader->mCols.mCols[sTableColCount - 1];

            if ( ( sTableLastCol->mOffset == sBindCols->mOffset[i] )
                    && ( sTableLastCol->mColumnType == DBM_COLUMN_CHAR_TYPE ) )
            {
                if ( ( sUpdateRow->mRowSize - sBindCols->mOffset[i] ) < sBindCols->mDataSize[i] )
                {
                    sUpdateRow->mRowSize = sBindCols->mOffset[i] + sBindCols->mDataSize[i];
                }
            }
        }

        /***********************************************
         * update 하려는 데이터가 인덱스의 키 컬럼을 변경시키는지 확인하고 그렇다면 mUpdateKey 함수 호출
         * before image를 백업하는 데 아래와 같이 두가지 부류로 나뉜다.
         * 1. 키 변경을 하지 않는 일반적인 업데이트는 DBM_UPDATE_SLOT_LOG로
         * 2. 키 변경이 되는 키 업데이트는 DBM_UPDATE_KEY_LOG로
         * mUpdateKey 함수내에서 백업을 했다면 sBackupF 값이 활성화 되어 아래 백업을 건너뛰게 된다.
         ***********************************************/
        for( i = 0; i < mIndexCount; i++ )
        {
            /***********************************************
             * 내가 선택한 인덱스는 변경될리 없다.
             ***********************************************/
            if( i == mUseIndex )
            {
                continue;
            }
            sCmpIdxHead = mIndex[i]->mGetIndexHeader();
            _IF_THROW( sCmpIdxHead == NULL, ERR_DBM_TABLE_NOT_PREPARED );
            sRC = mCheckKey( sIndexHead, sCmpIdxHead, (char*)sRow + sizeof(dbmRowHeader), g_sUpdateImage_mUpdateCol + sizeof(dbmRowHeader) );
            if( sRC )
            {
                _CALL( mUpdateKey( aTransID, aTxHead, aBackLogPos, aBackImagePos, sSlotID, g_sBeforeImage_mUpdateCol, sRow, sLogHead, i, g_sUpdateImage_mUpdateCol + sizeof(dbmRowHeader), &sBackupF) );
                //continue;
            }
        }

        /***********************************************
         * Before Image 를 logging 한다.
         ***********************************************/
        if ( ! sTableObj->mNoMemloggingF && sBackupF == 0 )
        {
            sLogType = DBM_UPDATE_SLOT_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                         aTransID,
                                         mTableID,
                                         mTableName,
                                         NULL, // mTableName,
                                         sSlotID,
                                         g_sBeforeImage_mUpdateCol,
                                         sRow->mRowSize + sizeof(dbmRowHeader),
                                         sRow,
                                         mTableHeader,
                                         &sLogHead );
            if ( sRC ) // , WRITE_LOG_FAIL );
            {
                DBM_ERR( "write log fail. log_type[%d] table[%s] rc=%d", sLogType, mTableName, sRC );
                sRC = ERR_DBM_WRITE_LOG;
            }
        }

        /***********************************************
         * 위에서 준비한 update 될 이미지로 한방에 엎어친다.
         ***********************************************/
        sRow->mSCN = INFINITE_SCN;

        memcpy_s( (char*)sRow + sizeof(dbmRowHeader), g_sUpdateImage_mUpdateCol + sizeof(dbmRowHeader), sUpdateRow->mRowSize );
        sRow->mRowSize = sUpdateRow->mRowSize;

        /******************************************************************
         * mHandleTrigger
         *****************************************************************/
        if ( mTrigger != NULL )
        {
            sRC = mHandleTrigger ( DBM_EVENT_UPDATE_BEFORE,
                                   aTransID,
                                   g_sBeforeImage_mUpdateCol + sizeof(dbmRowHeader)  ,
                                   sRow->mRowSize ) ;
            _IF_THROW ( sRC, ERR_DBM_TRIGGER_FAIL ) ;
            sRC = mHandleTrigger ( DBM_EVENT_UPDATE_AFTER,
                                   aTransID,
                                   (char*)sRow + sizeof(dbmRowHeader)  ,
                                   sRow->mRowSize ) ;
            _IF_THROW ( sRC, ERR_DBM_TRIGGER_FAIL );
        }

        sRetryCnt++;

        if ( sExtraKey != -1 || sPrevKey != 0x00 )
        {
            /* 이전 이미지 값을 백업해 놓는다. */
            *aBackLogPos = aTxHead->mLogCurPos;
            *aBackImagePos = aTxHead->mImageCurPos;
            memcpy_s ( sKey, sPrevKey, sizeof(sKey) );

            goto retry;
        }
 
        if ( sTableObj->mNoMemloggingF )
        {
            /************************************************
             * mem nologging 에서는 auto commit 처럼 처리.
             ************************************************/
            mLogMgr->mGetSCN ( &sSCN );

            sRow->mSCN = sSCN;
            sRow->mLock = -1;
        }
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN2( mTableName );
        }
    }
    _FINALLY
    _END
}

/********************************************************************************
 * Name : mFetchReadRecord
 *
 * Description
 *     insert operation
 *
 ******************************************************************************/
_VOID dbmTableManager::mFetchReadRecord ( int aMyTxID , long long aSlotID , char* aData ,
                                          int* aDataSize , int* aInserted , dbmLogType* aLogType )
{
    dbmRowHeader*   sRow = NULL;
    long long       sSCN;
    int             sRowSize;
    long long       sBeforeSCN;
    int             sBeforeTxID;
    int             sInsertedRowF = 0;
    int             sRC;

    _TRY
    {
        sRC = mSegMgr->Slot2Addr ( aSlotID, &sRow );
        _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT );

retry:
        *aDataSize = 0;

        // 2014.12.14. -okt- SELECT에서는 SCN을 증가하지 않는다. SELECT 후 결과 SCN이 바뀌었는지 계속 검사하므로..
        //mLogMgr->mPeekSCN ( &sSCN );
        // #888 2015.03.06 -okt- 동일 SCN으로 가져오는 FETCH이다. SCN을 다시 채번하면 안된다.
        sSCN = mFetchScn;

        sBeforeTxID = mvpAtomicGet32 ( &sRow->mLock );
        sBeforeSCN = mvpAtomicGet64 ( &sRow->mSCN );

        /*
         * TODO: 2015.03.06 -okt- 1137 오류를 해결하기위한 수정 위험이 커서
         *       oracle 의 SCN_ASCENDING 힌트 기능 추가를 먼저 진행
         */
        if ( likely( _dbm_scn_ascending == 0 ) )
        {
            /* 기존에 Select 해서 간직 했던 fetch scn 값과 현재의 row scn 값을 비교 한다.
             * Row SCN이 fetch SCN 값보다 크다는 것은 OLD 버젼보다 값이 커졌다는 것을 얘기한다.
             * 기존 이미지 값이 틀려 졌기 때문에 오류를 리턴한다. */
            if ( sRow->mSCN > mFetchScn ) //, INVISIBLE_SCN );
            {
                DBM_WARN ( "sRow->mSCN[%ld] mFetchScn[%ld]", sRow->mSCN, mFetchScn );
                _THROW( ERR_DBM_FETCH_SCN_INVISIBLE );
            }
        }

        if ( unlikely ( sBeforeTxID != -1 ) )
        {
            if ( sBeforeSCN == INFINITE_SCN )
            {
                /***********************************************
                 * 1. Trans ID 가 sRow->mLock 인 누군가 변경 중이다.
                 *    - Trans ID 가 자신의 것일 경우
                 *     : 그냥 읽으면 된다.
                 *    - Trans ID 가 남의 것일 경우
                 *     : Undo 에서 최초 버전을 읽는다.
                 *     : 신규로 Insert 된 것이면 Not Found 처리.
                 *     : Undo 에 Before Image 가 없다면 다시 읽기 시도.
                 ***********************************************/
                if ( sBeforeTxID == aMyTxID )
                {
                    /***********************************************
                     * 내가 변경한 것이므로 그냥 최종 것을 읽으면 됨.
                     * 하지만, 내가 delete 를 했다면 rowsize = 0 일 것이므로
                     * 이때는 Not Found.
                     ***********************************************/
                    _IF_THROW( sRow->mRowSize == 0, ERR_DBM_NO_MATCH_RECORD );

                    memcpy_s( aData, ((char*)sRow + sizeof(dbmRowHeader)), sRow->mRowSize );
                    *aDataSize = sRow->mRowSize;
                    //내가 변경한 로우라면 볼 수 있는 로우인지 확인해 봐야한다.
                    //이를 확인할 수 있게 해주기 위해 별도의 플래그를 사용할 수 있지만 aLogType을 DBM_UPDATE_KEY_LOG로 해주어 비교할 수 있게 한다.
                    if( aLogType != NULL )
                    {
                        *aLogType = DBM_UPDATE_KEY_LOG;
                    }
                }
                else
                {
#ifdef _DBM_MVCC2
READ_UNDO_DATA:
#endif
                    /***********************************************
                     * 내가 변경한 것이 아니므로 sBeforeTxID 의
                     * Undo 로그(before image)를 읽어서 aData 에 담아줌.
                     ***********************************************/
                    sRC = mLogMgr->mReadUndoRecord( sBeforeTxID,
                                                    aSlotID,
                                                    aData,
                                                    aDataSize,
                                                    sSCN,
                                                    &sInsertedRowF,
                                                    aLogType);
                    if ( sRC == 0 )
                    {
                        /***********************************************
                         * Log 에서 찾아서 최초 이미지를 읽었다.
                         ***********************************************/
                    }
                    else if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        if ( ( sBeforeSCN != mvpAtomicGet64 ( &sRow->mSCN ) )
                                || ( sBeforeTxID != mvpAtomicGet32 ( &sRow->mLock ) ) )
                        {
                            cmnUSleep ( 1000 );
                            goto retry;
                        }

                        /***********************************************
                         * 신규로 Insert 된 Record 면 읽으면 안된다.
                         * 그러나, aInserted 를 1 로 설정하여 해당 Row 가
                         * 다른 Tx 에 의해 신규로 삽입된 것이라고 알려준다.
                         * 이는 SelectGT 등에서 Not Found 로 사용자에게
                         * 리턴하지 않고 그 다음을 계속해서 Search 하도록
                         * 하기 위함이다.
                         ***********************************************/
                        if ( sInsertedRowF == 1 )
                        {
                            *aInserted = 1;
                            _THROW( ERR_DBM_NO_MATCH_RECORD );
                        }

                        /***********************************************
                         * 누군가 scn 을 infinite 로 해놓고 lock 까지
                         * 잡았는데 before image 가 없다는 것은
                         * 아직 undo 가 기록되지 않은 상황이다.
                         * 이럴 때는 다시 try
                         ***********************************************/
                        cmnUSleep ( 1000 );
                        goto retry;

                        /*
                        memcpy_s( aData, ((char*)sRow + sizeof(dbmRowHeader)), sRow->mRowSize );
                        *aDataSize = sRow->mRowSize;
                        */
                    }
                    else
                    {
                        /***********************************************
                         * 진짜 Fail 이거나 또는 해당 Transaction 이
                         * 갑자기 완전히 해제된 경우. 다시 해보자.
                         ***********************************************/
                        cmnUSleep ( 1000 );
                        goto retry;
                    }
                }

                /***********************************************
                 * 읽었어도 다시 체크
                 ***********************************************/
                if ( ( sBeforeSCN != mvpAtomicGet64 ( &sRow->mSCN ) )
                        || ( sBeforeTxID != mvpAtomicGet32 ( &sRow->mLock ) ) )
                {
                    cmnUSleep ( 1000 );
                    goto retry;
                }
            }
            else
            {
                /***********************************************
                 * Commit 처리는 다 했는데 Lock 을 못풀고 죽은 경우.
                 * 다른 놈이 잡고 죽었으면 Lock 을 풀어준다.
                 ***********************************************/
                /* 2015.07.15 -shw- 변경 사유는 mRecoverCheckLockPID 요기에 있음 */
                //sRC = mLockMgr->mCheckLockPID ( sBeforeTxID );
                sRC = mLockMgr->mRecoverCheckLockPID( sBeforeTxID, aMyTxID );
                if ( sRC == ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC )
                {
                    if ( mDicTableF == 0 )
                    {
                        _CALL( dbmRecoveryManager::mRecoverTrans ( mTableHeader->mTableObj.mInstName, sBeforeTxID ) );
                    }
                    else
                    {
                        _THROW( ERR_DBM_NEED_DIC_RECOVERY );
                    }
                }

                cmnUSleep ( 1000 );
                goto retry;
            }
        }
        else
        {
            if ( unlikely ( mvpAtomicGet64 ( &sRow->mSCN ) > sSCN && _dbm_scn_ascending == 0 ) )
            {
                /***********************************************
                 * 2. 그 사이 다른 Trans 가 Row SCN 을 commit 해버려서
                 *    읽을 수 없음. 다시 시도.
                 ***********************************************/
                if ( sRow->mSCN > 0 )
                {
#ifdef _DBM_MVCC2
                    //TODO: 2015.03.06 -okt- UNDO에 있는지 확인해본다.
                    goto READ_UNDO_DATA;
#else
                    cmnUSleep ( 1000 );
                    goto retry;
#endif
                }
                else
                {
                    goto READ_DATA;
                }
            }
            else
            {
READ_DATA:
                /***********************************************
                 * 3. 읽으면 된다.
                 *    하지만, line by line 으로 다른 transaction 이
                 *    해당 Row 에 변경을 가할 수 있다는 것을 고려해야 한다.
                 ***********************************************/
                if ( ( mvpAtomicGet64 ( &sRow->mSCN ) == INFINITE_SCN )
                        && ( mvpAtomicGet32 ( &sRow->mLock ) != -1 ) )
                {
                    goto retry;
                }

                if ( mvpAtomicGet32 ( &sRow->mRowSize ) <= 0 )
                {
                    _THROW( ERR_DBM_NO_MATCH_RECORD );
                }

                sRowSize = sRow->mRowSize;

                memcpy_s ( aData, ( (char*)sRow + sizeof(dbmRowHeader) ), sRowSize );
                *aDataSize = sRowSize;

                if ( sBeforeSCN != mvpAtomicGet64 ( &sRow->mSCN )
                        || sBeforeTxID != mvpAtomicGet32 ( &sRow->mLock ) )
                {
                    goto retry;
                }
            }
        }
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mFetchReadRecord */


/********************************************************************************
 * Name : mReadRecord
 *
 * Description
 *     insert operation
 *
 ******************************************************************************/
_VOID dbmTableManager::mReadRecord ( int aMyTxID , long long aSlotID , char* aData , int* aDataSize , int* aInserted, 
                                     int aDirtyFlag,
                                     dbmLogType* aLogType )
{
    dbmRowHeader*   sRow          = NULL;
    long long       sSCN;
    int             sRowSize;
    long long       sBeforeSCN;
    int             sBeforeTxID;
    int             sInsertedRowF = 0;
    int             sRC;

    _TRY
    {
        _CALL( mSegMgr->Slot2Addr( aSlotID, &sRow ) );
        //_IF_THROW( sRC || sRow == NULL, ERR_DBM_ALLOC_SLOT );

retry:
        *aDataSize = 0;

//        mLogMgr->mGetSCN( &sSCN );

        /***********************************************************************
         * Dirty Read 허용기능때문에 추가작업 by lim272, 2015-10-23
         * 호출단계
         * dbmAPI (OpenCursorGT) -> dbmTransManager -> dbmTableManager (mReadRecord)
         * 이후 Fetch에서는 dbmTrans -> dbmTable -> mFetchReadRecord
         * 이 과정에서 최초 SCN을 따는 시점은 여기로 보임.
         * mFetchReadRecord의 경우는 여기서 호출된 SCN를 쓰니까 건드릴게 없다.
        ***********************************************************************/
        if (aDirtyFlag == DBM_DIRTY_ON)
        {
            sSCN = LONG_MAX;
        }
        else
        {
            mLogMgr->mPeekSCN( &sSCN );
        }

        sBeforeTxID = mvpAtomicGet32 ( &sRow->mLock );
        sBeforeSCN  = mvpAtomicGet64 ( &sRow->mSCN );

        if ( unlikely( sBeforeTxID != -1 ) )
        {
            if ( sBeforeSCN == INFINITE_SCN )
            {
                /***********************************************
                 * 1. Trans ID 가 sRow->mLock 인 누군가 변경 중이다.
                 *    - Trans ID 가 자신의 것일 경우
                 *     : 그냥 읽으면 된다.
                 *    - Trans ID 가 남의 것일 경우
                 *     : Undo 에서 최초 버전을 읽는다.
                 *     : 신규로 Insert 된 것이면 Not Found 처리.
                 *     : Undo 에 Before Image 가 없다면 다시 읽기 시도.
                 ***********************************************/
                if ( sBeforeTxID == aMyTxID )
                {
                    /***********************************************
                     * 내가 변경한 것이므로 그냥 최종 것을 읽으면 됨.
                     * 하지만, 내가 delete 를 했다면 rowsize = 0 일 것이므로
                     * 이때는 Not Found.
                     ***********************************************/
                    _IF_THROW( sRow->mRowSize == 0, ERR_DBM_NO_MATCH_RECORD );

                    memcpy_s( aData, ((char*)sRow + sizeof(dbmRowHeader)), sRow->mRowSize );
                    *aDataSize = sRow->mRowSize;
                    //내가 변경한 로우라면 볼 수 있는 로우인지 확인해 봐야한다.
                    //이를 확인할 수 있게 해주기 위해 별도의 플래그를 사용할 수 있지만 aLogType을 DBM_UPDATE_KEY_LOG로 해주어 비교할 수 있게 한다.
                    if( aLogType != NULL )
                    {
                        *aLogType = DBM_UPDATE_KEY_LOG;
                    }
                }
                else
                {
                    /***********************************************
                     * 내가 변경한 것이 아니므로 sBeforeTxID 의
                     * Undo 로그(before image)를 읽어서 aData 에 담아줌.
                     ***********************************************/
                    sRC = mLogMgr->mReadUndoRecord( sBeforeTxID,
                                                    aSlotID,
                                                    aData,
                                                    aDataSize,
                                                    sSCN,
                                                    &sInsertedRowF,
                                                    aLogType);

                    if ( sRC == RC_SUCCESS )
                    {
                        /***********************************************
                         * Log 에서 찾아서 최초 이미지를 읽었다.
                         ***********************************************/
                    }
                    else if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        if ( ( sBeforeSCN != mvpAtomicGet64 ( &sRow->mSCN ) )
                                || ( sBeforeTxID != mvpAtomicGet32 ( &sRow->mLock ) ) )
                        {
                            cmnUSleep ( 1000 );
                            goto retry;
                        }

                        /***********************************************
                         * 신규로 Insert 된 Record 면 읽으면 안된다.
                         * 그러나, aInserted 를 1 로 설정하여 해당 Row 가
                         * 다른 Tx 에 의해 신규로 삽입된 것이라고 알려준다.
                         * 이는 SelectGT 등에서 Not Found 로 사용자에게
                         * 리턴하지 않고 그 다음을 계속해서 Search 하도록
                         * 하기 위함이다.
                         ***********************************************/
                        if ( sInsertedRowF == 1 )
                        {
                            *aInserted = 1;
                            _THROW( ERR_DBM_NO_MATCH_RECORD );
                        }

                        /***********************************************
                         * 누군가 scn 을 infinite 로 해놓고 lock 까지
                         * 잡았는데 before image 가 없다는 것은
                         * 아직 undo 가 기록되지 않은 상황이다.
                         * 이럴 때는 다시 try
                         ***********************************************/
                        cmnUSleep ( 1000 );
                        goto retry;

                        /*
                         memcpy_s( aData, ((char*)sRow + sizeof(dbmRowHeader)), sRow->mRowSize );
                         *aDataSize = sRow->mRowSize;
                         */
                    }
                    else
                    {
                        /***********************************************
                         * 진짜 Fail 이거나 또는 해당 Transaction 이
                         * 갑자기 완전히 해제된 경우. 다시 해보자.
                         ***********************************************/
                        cmnUSleep ( 1000 );
                        goto retry;
                    }
                }

                /***********************************************
                 * 읽었어도 다시 체크
                 ***********************************************/
                if ( ( sBeforeSCN != mvpAtomicGet64 ( &sRow->mSCN ) )
                        || ( sBeforeTxID != mvpAtomicGet32 ( &sRow->mLock ) ) )
                {
                    cmnUSleep ( 1000 );
                    goto retry;
                }
            }
            else
            {
                /***********************************************
                 * Commit 처리는 다 했는데 Lock 을 못풀고 죽은 경우.
                 * 다른 놈이 잡고 죽었으면 Lock 을 풀어준다.
                 ***********************************************/
                /* 2015.07.15 -shw- 변경 사유는 mRecoverCheckLockPID 요기에 있음 */
                //sRC = mLockMgr->mCheckLockPID ( sBeforeTxID );
                sRC = mLockMgr->mRecoverCheckLockPID( sBeforeTxID, aMyTxID );
                if ( sRC == ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC )
                {
                    if ( mDicTableF == 0 )
                    {
                        _CALL( dbmRecoveryManager::mRecoverTrans ( mTableHeader->mTableObj.mInstName, sBeforeTxID ) );
                    }
                    else
                    {
                        _THROW( ERR_DBM_NEED_DIC_RECOVERY );
                    }
                }

                cmnUSleep ( 1000 );
                goto retry;
            }
        }
        else
        {
            if ( mvpAtomicGet64 ( &sRow->mSCN ) > sSCN )
            {
                /***********************************************
                 * 2. 그 사이 다른 Trans 가 Row SCN 을 commit 해버려서
                 *    읽을 수 없음. 다시 시도.
                 ***********************************************/
                if ( sRow->mSCN > 0 )
                {
                    // 2014.12.14. -okt- (성능) mvcc12 테스트에 여기서 대기하는 스택발견. ( 2014/07/21 )
                    //cmnUSleep ( 1000 );
                    pthread_yield_s ( );
                    goto retry;
                }
                else
                {
                    goto READ_DATA;
                }
            }
            else
            {
                READ_DATA:
                /***********************************************
                 * 3. 읽으면 된다.
                 *    하지만, line by line 으로 다른 transaction 이
                 *    해당 Row 에 변경을 가할 수 있다는 것을 고려해야 한다.
                 ***********************************************/
                if ( ( mvpAtomicGet64 ( &sRow->mSCN ) == INFINITE_SCN )
                        && ( mvpAtomicGet32 ( &sRow->mLock ) != -1 ) )
                {
                    pthread_yield_d ( );      // _DEBUG 모드에서만 통계를 내기위한 비어있는 매크로.
                    goto retry;
                }

                if ( mvpAtomicGet32 ( &sRow->mRowSize ) <= 0 )
                {
                    _THROW( ERR_DBM_NO_MATCH_RECORD );
                }

                sRowSize = sRow->mRowSize;

                memcpy_s ( aData, ( (char*)sRow + sizeof(dbmRowHeader) ), sRowSize ); // (성능) SELECT
                *aDataSize = sRowSize;

                if ( sBeforeSCN != mvpAtomicGet64 ( &sRow->mSCN )
                        || sBeforeTxID != mvpAtomicGet32 ( &sRow->mLock ) )
                {
                    pthread_yield_d ( );
                    goto retry;
                }
            }
        }

        /* 2014.06.19 -shw- row scn 값을 mFetchScn Table 객체의 변수에 넣어주어 Fetch 처리 시 조건값이다. */
        /*
         * 2014.12.14. -okt- 여기서 할당을 하면, 사용자가 Fetch 시작시의 SCN이 아니고 성공시의 SCN이다. 그리고 여러건이면 ?
         *             이상한데. 여기가 아니고 mFetchReadRecord에 위치가 의도 아닌가?
         */
        mFetchScn = sSCN;
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mReadRecord */


_VOID dbmTableManager::mRowLock ( char* aUndoName , long long aSlotID , dbmRowHeader* aRow ,
                                  char* aBeforeImage , int aTransID , int aChkInsertF )
{
    int     sPidReplacedF = 0;
    int     sInsertedF = 0;
    int     sOldTxID;
    int     sDeadLockCheck  = 0 ;
    int     sLockTryCount   = 0;
    int     sFirstWaitTx = 0;
    int     sPidTryCheck = 0;
    int     sPirReplaced = 0;
    int     sRC = -1;

    _TRY
    {
        sInsertedF = 0;

        // #383 mvcc17 deadlock 문제로 위치 변경. - 2014/07/05 (OKT) -
        //sFirstWaitTx = mvpAtomicGet32( &aRow->mLock );
retry:
        sFirstWaitTx = mvpAtomicGet32( &aRow->mLock );
        sOldTxID = mvpAtomicGet32( &aRow->mLock );

        sRC = mLockMgr->mLock( &aRow->mLock,
                               aTransID,
                               &sPidReplacedF,
                               &sPirReplaced );

        if ( ( sRC == ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC ) && ( sPidReplacedF == 1 ) )
        {
            /***********************************************
             * 다른 process 에 의해 lock 이 걸린 후 해당
             * process 는 down 되었다.
             * my pid 로 대체되고 lock 이 걸렸지만 이전 놈의
             * Transaction 은 강제 Rollback 시켜야 한다.
             ***********************************************/
            RTF_POINT( "TBLMGR_ROW_LOCK_1" );

            if ( mDicTableF == 0 )
            {
                sRC = dbmRecoveryManager::mRecoverTrans ( aUndoName, sOldTxID );
                if ( sRC ) //, RECOVER_TX_FAIL );
                {
                    DBM_ERR( "[%s] rollback tx(%d) for rowlock fail. rc(%d)", aUndoName, sOldTxID, sRC );
                    _THROW( ERR_DBM_ROW_LOCK );
                }

                _THROW( ERR_DBM_ABNORMAL_ROLLBACK );
            }
            else
            {
                _THROW( ERR_DBM_NEED_DIC_RECOVERY );
            }
        }
        else if ( ( sRC == ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC ) && ( sPidReplacedF == 0 ) )
        {
            /***********************************************
             * 다른 process 에 의해 lock 이 걸린 후 해당
             * process 는 down 되었다.
             * my pid 로 대체하려고 했는데 무슨 이유인지 실패했다.
             ***********************************************/

            pthread_yield_s ( );
            goto retry;
        }
        else if ( sRC == ERR_DBM_LOCK_ROW_BY_OTHER_ALIVE_PROC )
        {
            /***********************************************
             * 다른 process 에 의해 lock 이 걸린 상태인데
             * 그 process 는 아직 살아있다.
             * 그래서, Lock 은 못잡았다.
             * 그게 내 process 일 수도 있지만, TxID 는 다른놈이다.
             * 이 때 검사해야할 것은 Dead Lock 과 해당 Row 가
             * 다른 놈이 신규로 insert 한 Row 인지에 대한 것이다.
             ***********************************************/
            /*
             * Lock Wait 으로 빠져있으니 Dead Lock 임을 체크해서 Transaction 을 Rollback
             * 이떄 Dead Lock 이라면 두번 체크할 필요는 없다. 들어올때 한번만 체크하면
             * 검출 가능하다.
             */

            sLockTryCount++;
            sOldTxID = mvpAtomicGet32 ( &aRow->mLock );

            if ( aChkInsertF && ( aTransID != sOldTxID ) )
            {
                if ( sOldTxID != mvpAtomicGet32 ( &aRow->mLock ) )
                {
                    pthread_yield_s ( );
                    goto retry;
                }

                sRC = mLogMgr->mIsInsertedRow ( mvpAtomicGet32 ( &aRow->mLock ), aSlotID, &sInsertedF );
                if ( ( sRC == 0 ) && ( sInsertedF == TRUE ) )
                {
                    _THROW( ERR_DBM_NO_MATCH_RECORD );
                }
            }

            /*
             * [나눗셈제거] 2의 지수로 나눗셈을 대체한다.
             *            ( (1<<17) - 1) = 131071       // 비트연산의 우선순위가 낮다. 콸호 필수.
             *            굳이 비트연산을 하지 아니해도 2^N - 1 조건에 맞는 나누기는 컴파일러 최적화 가능.
             */
    //      if ( sLockTryCount == 100000 && sFirstWaitTx == sOldTxID )
            if ( ( sLockTryCount & 131071 ) == 0 && sFirstWaitTx == sOldTxID )
            {
                if ( mDeadLockMgr->mCheckDeadLock ( mTableID, aSlotID, sOldTxID ) == ERR_DBM_DEADLOCK_DETECTED )
                {
                    _CALL( mDeadLockMgr->mUnsetTransHeader ( ) );

                    return ERR_DBM_DEADLOCK_DETECTED;       // 의도적
                }
                sLockTryCount = 0;
                sFirstWaitTx = mvpAtomicGet32( &aRow->mLock );
            }

            /*
             * lock 상황이 중간에 변경될 수도 있다.
             * mLock 값 뿐아니라 TxHeader 의 상황도 수시로
             * 변하는 상태이기 때문에 mIsInsertedRow 를 수행하는 과정은
             * 동시성을 수시로 고려해야 한다.
             */
            if ( sOldTxID != mvpAtomicGet32 ( &aRow->mLock ) )
            {
                pthread_yield_s ( );
                sDeadLockCheck = 0;
                goto retry;
            }

            /* 동시성 제어 관련 PID가 -1경우 해당 값을 retry 하도록 수정 한다 */
            /* 2014.07.08 -shw */
            if ( sPirReplaced == -1 )
            {
                if ( sPidTryCheck == 10000 )
                {
                    mvpAtomicCas32 ( &aRow->mLock, aTransID, sOldTxID );
                }
                sPidTryCheck++;
            }

            pthread_yield_s ( );
            goto retry;
        }
        // 2014.09.20 (OKT): 여기가 성공인가? 함수 이름이 좀 거시기하다.
        else
        {
            /*
             *  Lock 을 잡았다면 더이상 TxHeader 에 LockWait 정보를 남길필요없다.
             */
            _CALL( mDeadLockMgr->mUnsetTransHeader ( ) );
        }

        RTF_POINT( "TBLMGR_ROW_LOCK_2" );

        /***********************************************
         * Before Image 복사
         ***********************************************/
        memcpy_s ( aBeforeImage, aRow, sizeof(dbmRowHeader) + aRow->mRowSize );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mRowLock */


_VOID dbmTableManager::mMakeKey ( dbmIndexObject* aIndexObj , char* aUsrData , char* aKey )
{
    dbmColumnObject*    sCol;
    int                 sKeyPos;
    int                 i;

    _TRY
    {
        sKeyPos = 0;
        for ( i = 0; i < aIndexObj->mColumnCount; i++ )
        {
            sCol = &aIndexObj->mKey[i];

            switch( sCol->mColumnType )
            {
                case DBM_COLUMN_CHAR_TYPE:
                    memcpy_s ( aKey + sKeyPos, aUsrData + sCol->mOffset, sCol->mSize );
                    sKeyPos += sCol->mSize;
                    break;

                case DBM_COLUMN_LONG_TYPE:
                    *(long long*) ( aKey + sKeyPos ) = *(long long*) ( aUsrData + sCol->mOffset );
                    sKeyPos += 8;
                    break;

                case DBM_COLUMN_INT_TYPE:
                    *(int*) ( aKey + sKeyPos ) = *(int*) ( aUsrData + sCol->mOffset );
                    sKeyPos += 4;
                    break;

                case DBM_COLUMN_SHORT_TYPE:
                    *(short*) ( aKey + sKeyPos ) = *(short*) ( aUsrData + sCol->mOffset );
                    sKeyPos += 2;
                    break;

                case DBM_COLUMN_DOUBLE_TYPE:
                case DBM_COLUMN_FLOAT_TYPE:
                default:
                    DBM_DBG( "invalid column type, dbmColumnType=%d", sCol->mColumnType );
                    _THROW( ERR_DBM_INVALID_COLUMN_TYPE );
                    break;
            }
        }

        //aKey[sKeyPos] = 0x00;
    }
    _CATCH
    {
        _CATCH_INFO;
    }
    _FINALLY
    _END
} /* mMakeKey */


/*
 * DIRECT 테이블 전용이다.
 *
 * direct 테이블은 array를 테이블화 한 것으로, 하나의 정수 컬럼만. 인덱스에 올수 있다.
 * 인덱스의 최대개수도 1개
 * 인덱스 키 컬럼의 값 자체가 array의 인자이므로, 0 혹은 양수 값만 가능.
 *
 * 참고로 DBMS의 IOT는 PK인덱스 순서로 테이블이 저장된 것으로, LOB 타입이 불가한것 외의 다른 제약은 없다. (맞나?)
 *
 */
_VOID dbmChgDirectKey2SlotID ( dbmColumnType aKeyColumnType , char* aKey , long long* aSlotID, int aCheck )
{
    _TRY
    {
        switch( aKeyColumnType )
        {
            case DBM_COLUMN_SHORT_TYPE:
            {
                short   sKey;

                sKey = *(short *)aKey;
                if ( aCheck == 1 )
                {
                    _IF_THROW( sKey < 0, ERR_DBM_INVALID_KEY_VALUE );
                }
                *aSlotID = (long long)sKey;
                break;
            }
            case DBM_COLUMN_INT_TYPE:
            {
                int     sKey;

                sKey = *(int *)aKey;
                //_IF_THROW( sKey < 0, ERR_DBM_INVALID_KEY_VALUE );
                if ( aCheck == 1 )
                {
                    if ( unlikely ( sKey < 0 ) )
                    {
                        DBM_DBG( "invalid key value. type=%d, key=%d", aKeyColumnType, sKey );
                        _THROW( ERR_DBM_INVALID_KEY_VALUE );
                    }
                }
                *aSlotID = (long long)sKey;
                break;
            }
            case DBM_COLUMN_LONG_TYPE:
            {
                long long sKey;

                sKey = *(long long*)aKey;
                if ( aCheck == 1 )
                {
                    _IF_THROW( sKey < 0, ERR_DBM_INVALID_KEY_VALUE );
                }
                *aSlotID = sKey;
                break;
            }
            default:
            {
                DBM_DBG( "invalid column type, dbmColumnType=%d", aKeyColumnType );
                _THROW( ERR_DBM_INVALID_COLUMN_TYPE );
                break;
            }
        }
    }
    _CATCH
    {
        // 사용자 실수로 비정상 값이 온것이면. 엔진입장에선 ERR가 아니고 INFO이다.
        _CATCH_INFO;
    }
    _FINALLY
    _END
} /* dbmChgDirectKey2SlotID */


dbmIndexManager* dbmTableManager::mGetIndexMgrByObjID ( int aIndexID )
{
    _TRY
    {
        for( int i=0; i<mIndexCount; i++ )
        {
            if ( mIndex[i]->mGetIndexID() == aIndexID )
            {
                return mIndex[i];
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _ENDNULL    // 성능구간 아닌듯하여, _ENDNULL 예제삼아, _TRY 적용해봄 ( 2014.09.21 )
}

/**
 * @param aEventType
 * @param aTransID
 * @param aData             aData 는 순수 데이터
 * @param aDataLen          aDataLen  도 순수 데이터 길이
 * @return
 */
_VOID dbmTableManager::mHandleTrigger ( dbmEventOperation aEventType , int aTransID , char* aData , int aDataLen )
{
//    dbmEventDataHeader      sTriggerHeader;
//    char                    sBuffer[DBM_MAX_RECORD_SIZE];
//    dbmDataObject           sTriggerDataObject;

    _TRY
    {
        /****************************************************************
         * Trigger 가 존재여부를 검사
         ***************************************************************/
        if ( mTrigger == NULL )
        {
            _RETURN;
        }

        if ( aDataLen + sizeof(dbmEventDataHeader) > DBM_MAX_RECORD_SIZE )
        {
            DBM_ERR( "Event source data is too long [%d] max [%d]", aDataLen, DBM_MAX_RECORD_SIZE - sizeof (dbmEventDataHeader) );
            _THROW( RC_FAILURE );
        }

        // 2014.09.21 (OKT) 굳이 여기서 묶어준 이유는 스택변수가 크고, mTrigger 없으면 바로 빠져나가므로,
        {
            dbmEventDataHeader      sTriggerHeader;
            char                    sBuffer[DBM_MAX_RECORD_SIZE];
            dbmDataObject           sTriggerDataObject;

            sTriggerHeader.mObjectID  =  mTableID;
            sTriggerHeader.mCommitSCN = 0;
            sTriggerHeader.mTxID      = aTransID;
            sTriggerHeader.mEventType = aEventType;
            strcpy_s (sTriggerHeader.mObjectName, mTableName ) ;
            sTriggerHeader.mDataLen   = aDataLen;

            /****************************************************************
             * 기존의 Queue 에 담을 일련의 데이터를 처리
             ***************************************************************/
            memcpy_s ( sBuffer, &sTriggerHeader, sizeof(dbmEventDataHeader) );
            memcpy_s ( sBuffer + sizeof(dbmEventDataHeader), aData, aDataLen );

            /****************************************************************
             * Data Object 로 변환
             ***************************************************************/
            _CALL( mBuildDataObject ( sBuffer , aDataLen, &sTriggerDataObject ) );
            _CALL( mTrigger->mEnque ( aTransID, &sTriggerDataObject ) );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}  /* mHandleTrigger */

_VOID dbmTableManager::mCheckKey ( dbmIndexHeader* aUseIdxHead, dbmIndexHeader* aIdxHead, char* aSrcData, char* aUserData )
{
    int                 i,j,sCond;

    _TRY
    {
        /***********************************************
         * 판별이 필요한 인덱스와 기준 인덱스를 받고 인덱스의 키 컬럼의 위치가 값이 다르다면 에러 리턴
         * 인덱스 별로 mMakeKey를 통해서 한방에 비교하는 것이 더 좋을지도 모르겠다.
         ***********************************************/
        for( i = 0; i < aIdxHead->mIndex.mColumnCount; i++ )
        {
            sCond = FALSE;
            for( j = 0; j < aUseIdxHead->mIndex.mColumnCount; j++ )
            {
                if( aIdxHead->mIndex.mKey[i].mOffset == aUseIdxHead->mIndex.mKey[j].mOffset )
                {
                    sCond = TRUE;
                    break;
                }
            }

            if( sCond != TRUE )
            {
                if( memcmp_s(aSrcData + aIdxHead->mIndex.mKey[i].mOffset,
                            aUserData + aIdxHead->mIndex.mKey[i].mOffset,
                            aIdxHead->mIndex.mKey[i].mSize) )
                {
                    //_PRT( "idx key different...idx offset(%d)\n", aIdxHead->mIndex.mKey[i].mOffset );
                    _THROW (RC_FAILURE);
                }
            }
        }
    }
    _CATCH
    _FINALLY
    _END
}

_VOID dbmTableManager::mUpdateKey ( int                aTransID,
                                     dbmTransHeader*    aTxHead,
                                     long long*         aBackLogPos,
                                     long long*         aBackImagePos,
                                     long long          aSlotID,
                                     char*              aData,
                                     dbmRowHeader*      aRow,
                                     dbmLogHeader*      aLogHead,
                                     int                aIdxInd,
                                     char*              aUserData,
                                     int*               aBackupF )
{
    dbmTableObject* sTableObj  = &mTableHeader->mTableObj;
    dbmIndexHeader* sIdxHead = NULL;
    int             sIndexFirst = 0;
    int             sLogType = -1;
    int             sIndexKeySize = 0;
    int             sKeyOffset  = 0;
    char            sKey[DBM_NON_UNIQUE_KEY_SIZE];
    char            sKey2[DBM_NON_UNIQUE_KEY_SIZE];
    //char            sNextKey[DBM_NON_UNIQUE_KEY_SIZE];
    long long       sIndexSlotID = -1;
    long long       sExtraKey    = -1;
    long long       sNextExtraKey = -1;
    long long       sCurrExtraKey = -1;
    long long       sDeleteExtraKey = -1;

    _TRY
    {
        /***********************************************
         * 키가 변경되는 update의 경우 새로운 키를 입력하고
         * 기존의 키는 삭제한다.
         ***********************************************/
        sIdxHead = mIndex[aIdxInd]->mGetIndexHeader();
        _IF_THROW( sIdxHead == NULL, ERR_DBM_TABLE_NOT_PREPARED ); // INDEX_NOT_READY );

        if( !sTableObj->mNoMemloggingF )
        {
            if( *aBackupF == 0 )
            {
                _rc = mLogMgr->mWriteMemLog( DBM_UPDATE_KEY_LOG,
                        aTransID,
                        mTableID,
                        mTableName,
                        NULL, // mTableName,
                        aSlotID,
                        aData,
                        aRow->mRowSize + sizeof(dbmRowHeader),
                        aRow,
                        mTableHeader,
                        &aLogHead );
                _IF_THROW( _rc, ERR_DBM_WRITE_LOG );
                *aBackupF = 1;
                RTF_POINT("TBLMGR_UPDATE_KEY_1");
            }

            _CALL( mMakeKey ( &sIdxHead->mIndex, aUserData, sKey ) );

            *aBackLogPos    = aTxHead->mLogCurPos;
            *aBackImagePos  = aTxHead->mImageCurPos;
            aTxHead->mRecoveryStartPos = aTxHead->mLogCurPos;

            if ( memcmp_s ( sTableObj->mTableName, "$sys", 4  ) && sIdxHead->mIndex.mIsUniqueIndex == DBM_UNIQUE ) 
            {
                for ( int j = 0; j < sIdxHead->mIndex.mColumnCount; j++ )
                {

                    //if ( unlikely( sKey[sKeyOffset] == NULL ) )
                    if ( unlikely( sKey[sKeyOffset] == '\0'  && 
                         sIdxHead->mIndex.mKey[j].mColumnType == DBM_COLUMN_CHAR_TYPE ) )
                    {
                        _THROW( ERR_DBM_INVALID_KEY );
                    }

                    sKeyOffset = sKeyOffset + sIdxHead->mIndex.mKey[j].mSize;

                }
            }

            /***********************************************
             * 변경자 : wind * 변경일 : 15.10.26 * 참고 : #1011
             * 변경 내용 : NU인덱스에 키 입력 시 extrakey 값을 미리 할당 받고, 할당 받은 extrakey 값을 로깅한다.
             * 복구 시 해당 extrakey값으로 의도한 삭제 작업을 수행한다.
             ***********************************************/
            if ( sIdxHead->mIndex.mIsUniqueIndex == DBM_NON_UNIQUE )
            {
                sLogType = DBM_INSERT_INDEX_LOG2;
                sIndexKeySize = sIdxHead->mIndex.mKeySize + 8;
                //sExtraKey = mvpAtomicInc64 ( &sIdxHead->mExtra );
                //*(long long*) ( sKey + sIdxHead->mIndex.mKeySize ) = sExtraKey;
                *(long long*) ( sKey + sIdxHead->mIndex.mKeySize ) = SLOT2EXTRA( aSlotID );
            }
            else
            {
                sLogType = DBM_INSERT_INDEX_LOG;
                sIndexKeySize = sIdxHead->mIndex.mKeySize;
            }

            _rc = mLogMgr->mWriteMemLog( sLogType,
                    aTransID,
                    sIdxHead->mIndex.mIndexID,
                    sIdxHead->mIndex.mIndexName,
                    mTableName,
                    aSlotID,
                    sKey,
                    sIndexKeySize,
                    NULL,
                    NULL,
                    &aLogHead );
            _IF_THROW( _rc, ERR_DBM_WRITE_LOG );
        }

        RTF_POINT("TBLMGR_UPDATE_KEY_2");
        //_CALL( mIndex[aIdxInd]->mInsertKey( aTransID, aUserData, aSlotID, &sExtraKey) );
        //_CALL( mIndex[aIdxInd]->mInsertKey( aTransID, sKey, aSlotID, &sExtraKey) );
        _CALL( mIndex[aIdxInd]->mInsertKey( aTransID, sKey, aSlotID ) );

        RTF_POINT("TBLMGR_UPDATE_KEY_3");
        aTxHead->mRecoveryStartPos = MK_POS( -1, -1 );

        RTF_POINT("TBLMGR_UPDATE_KEY_4");
        _CALL( mMakeKey ( &sIdxHead->mIndex, (char*)aRow + sizeof(dbmRowHeader), sKey2 ) );

        if ( ! sTableObj->mNoMemloggingF )
        {
            //if ( memcmp_s ( sIdxHead->mIndex.mTableName, "$sys", 4 ) )
            //{
                /***********************************************
                 * 변경자 : wind * 변경일 : 15.10.23 * 참고 : #1004
                 * 변경 내용 : NU인덱스에서 slotid를 무조건 비교하게 하고 extrakey 값도 항상 저장하게 한다.
                 * 변경하면서 절차를 간소화 하였다.
                 ***********************************************/
#if 0
                if ( sIdxHead->mIndex.mIsUniqueIndex == DBM_NON_UNIQUE )
                {
Index_retry:
                    _CALL ( mIndex[aIdxInd]->mSearchKeyNu( aTransID, sKey2, &sIndexSlotID , &sNextExtraKey, &sCurrExtraKey ) );
                    if ( aSlotID == sIndexSlotID )
                    {
                        sLogType = DBM_DELETE_INDEX_LOG2;
                        sIndexKeySize = sIdxHead->mIndex.mKeySize + 8;
                        *(long long*) ( sKey2 + sIdxHead->mIndex.mKeySize ) = sCurrExtraKey;
                    }
                    else
                    {
                        if( sNextExtraKey == -1 )
                        {
                            DBM_CERR("The slot id does not exist in another index. slot_id=[%lld]", aSlotID );
                            _THROW ( ERR_DBM_INVALID_KEY );
                        }
                        goto Index_retry;
                    }
                }
                else
                {
                    sLogType = DBM_DELETE_INDEX_LOG; 
                    sIndexKeySize = sIdxHead->mIndex.mKeySize; 
                }
#endif
                if ( sIdxHead->mIndex.mIsUniqueIndex == DBM_NON_UNIQUE )
                {
                    sLogType = DBM_DELETE_INDEX_LOG2;
                    sIndexKeySize = sIdxHead->mIndex.mKeySize + 8;
                    *(long long*) ( sKey2 + sIdxHead->mIndex.mKeySize ) = SLOT2EXTRA( aSlotID );
                }
                else
                {
                    sLogType = DBM_DELETE_INDEX_LOG;
                    sIndexKeySize = sIdxHead->mIndex.mKeySize;
                }
            //}

            _rc = mLogMgr->mWriteMemLog( sLogType,
                    aTransID,
                    sIdxHead->mIndex.mIndexID,
                    sIdxHead->mIndex.mIndexName,
                    mTableName,
                    aSlotID,
                    sKey2,
                    sIndexKeySize,
                    sIdxHead,
                    sIdxHead,
                    &aLogHead );
            _IF_THROW( _rc, ERR_DBM_WRITE_LOG );
        }
        else
        {
            if ( sIdxHead->mIndex.mIsUniqueIndex == DBM_UNIQUE )
            {
                _CALL(mIndex[aIdxInd]->mDeleteKey( aTransID, sKey2 ));
            }
            else
            {
                _CALL(mIndex[aIdxInd]->mDeleteKey( aTransID, sKey2, 1 ));
            }
        }
        RTF_POINT("TBLMGR_UPDATE_KEY_5");
    }
    _CATCH
    _FINALLY
    _END
}
