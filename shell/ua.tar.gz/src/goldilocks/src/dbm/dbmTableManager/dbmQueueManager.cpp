/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
 *   dbmQueueManager 의 멤버함수 구현
 ******************************************************************************/
#include "dbmHeader.h"
#include "dbmQueueManager.h"


/******************************************************************************
 * Name : dbmQueueManager
 *
 * Description
 *     constructor
 *
 * Argument
 *
 * Return
 *
 ******************************************************************************/
dbmQueueManager::dbmQueueManager( )
{
    memset_s ( mQueueName, 0x00, DBM_NAME_LEN );

    mQueueHeader = NULL;

    mSegMgr  = NULL;
    mLogMgr  = NULL;
    mLockMgr = NULL;
    mTableID = -1;

    mQStartPtr = NULL;
    mLastSlotID = -1;
    mRollbackStartPtr = NULL;
    mRollbackLastSlotID = -1;
    mTransLogger = NULL;
}

/******************************************************************************
 * Name : dbmQueueManager
 *
 * Description
 *     constructor
 *
 ******************************************************************************/
int dbmQueueManager::mInitQueue( char*              aInstName,
                                 char*              aQueueName,
                                 dbmDicObject*      aDicObject,
                                 dbmLogManager*     aLogMgr,
                                 dbmLockManager*    aLockMgr )
{
    dbmTableInfo*   sDicTableInfo = NULL;

    _TRY
    {
        sDicTableInfo = &aDicObject->mObj.mTableInfo;

        memset_s ( mQueueName, 0x00, DBM_NAME_LEN );
        memset_s ( mInstName, 0x00, DBM_NAME_LEN );

        cmnStrCpy ( mInstName, aInstName, sizeof(mInstName) );
        cmnStrCpy ( mQueueName, aQueueName, sizeof(mQueueName) );


        /****************************************************
         * queue segment manager 객체 생성
         ****************************************************/
        _CALL( dbmSegmentManager::Attach(mInstName, mQueueName, &mSegMgr ) );

        /****************************************************
         * table header pointer 설정
         ****************************************************/
        mQueueHeader = (dbmQueueHeader *)mSegMgr->GetUserHeader();
        _IF_THROW( mQueueHeader->mInitCompleteF != 1, ERR_DBM_INVALID_HEADER );


        /****************************************************
         * Queue Header 의 Table ID 로 Queue Manager 객체의
         * Table ID 를 셋팅.
         ****************************************************/
        mTableID = mQueueHeader->mTableObj.mTableID;

        /****************************************************
         * dictionary 정보와 table header 정보가 다르면 에러.
         ****************************************************/
        if ( strcmp_s ( sDicTableInfo->mTable.mTableName, mQueueHeader->mTableObj.mTableName ) )
        {
            DBM_ERR( "Queue(%s) header info and dictionary info does not match.", aQueueName );
            _THROW( ERR_DBM_HEAD_DIC_INFO_NOT_MATCH );
        }

        /****************************************************
         * dbmLogManager 객체 설정
         * dbmLockManager 객체 설정
         ****************************************************/
        mLogMgr  = aLogMgr;
        mLockMgr = aLockMgr;

        /****************************************************
         * Enqueue 등에서 사용하는 내부 변수 초기화
         ***************************************************/
        mQStartPtr = NULL ;
        mLastSlotID = -1;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mInitQueue */


/******************************************************************************
 * Name : ~dbmQueueManager
 *
 * Description
 *     destructor
 *
 ******************************************************************************/
dbmQueueManager::~dbmQueueManager( )
{
    /**************************************************************************
     * Queue Object 가 Delete 된다면, 해당 Segment 들도 날려야한다.
     * Init Queue 상태에서 Attach 된것이니 해당 메모리의 Scope 는 여기까지.
     *************************************************************************/
    if ( mSegMgr != NULL )
    {
#ifndef USE_NEW_SHM_NODETACH
        mSegMgr->Detach () ;
#endif
        delete mSegMgr;
        mSegMgr = NULL;
    }
}


/********************************************************************************
 * Name : mBuildNewNode
 *
 * Description
 * 새로운 Node 를 생성하고 데이터를 복사한다.
 *
 ******************************************************************************/
_VOID dbmQueueManager::mBuildNewNode ( int aTransID , void* aData , dbmQNodeHeader** aRtnPtr )
{
    dbmLogHeader*   sLogHead = NULL ;
    dbmQNodeHeader* sQNodeHeader = NULL ;
    dbmDataObject*  sData = (dbmDataObject*) aData ;
    int     sLogType ;
    long long sAllocSlot;

    _TRY
    {
        /***********************************************
         * 1. 슬롯을 할당 받는다.
         ***********************************************/
        _CALL( dbmSegAllocSlot( mSegMgr, &sAllocSlot ) );

        /***********************************************
         * 2. 할당받은 슬롯의 로그를 기록한다.
         ***********************************************/
        sLogType = DBM_ALLOC_SLOT_LOG;
        _CALL( mLogMgr->mWriteMemLog( sLogType,
                aTransID,
                mQueueHeader->mTableObj.mTableID,
                mQueueHeader->mTableObj.mTableName,
                NULL, // mQueueHeader->mTableObj.mTableName,
                sAllocSlot,
                NULL,
                0,
                mQueueHeader,
                mQueueHeader,
                &sLogHead ) );
        //_IF_RAISE (sRC, WRITE_LOG_FAIL ) ;

        RTF_POINT ("QUEMGR_ENQUEUE_1");


        /***********************************************
         * 3. 해당 주소를 얻어온다.
         ***********************************************/
        _CALL( mSegMgr->Slot2Addr ( sAllocSlot , &sQNodeHeader ) );

        /***********************************************
         * 4. 사용자가 넘긴데이터를 복사한다.
         ***********************************************/
        memcpy_s ( (char*) sQNodeHeader + sizeof(dbmQNodeHeader), sData->mUserData, sData->mDataSize );

        /***********************************************
         * 5. 헤더를 초기화 한다.
         ***********************************************/
        sQNodeHeader->mMySlot = sAllocSlot;
        sQNodeHeader->mNext = -1 ;
        sQNodeHeader->mDataSize = sData->mDataSize ;
        sQNodeHeader->mLock = -1;
        mLogMgr->mGetSCN (&sQNodeHeader->mSCN) ;

        *aRtnPtr = sQNodeHeader;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mBuildNewNode */


_VOID dbmQueueManager::mEnque( int aTransID, void* aData )
{
    dbmDataObject*  sData  = (dbmDataObject*)aData;
    dbmLogHeader*   sLogHead = NULL;
    dbmQNodeHeader* sNodeHeader = NULL;
    dbmQNodeHeader* sCurNodeHeader = mQStartPtr ;
    int             sLogType;

    _TRY
    {
        /***********************************************
         * User Data 가 Queue 의 RecordSize 보다 크면 에러
         ***********************************************/
        _IF_THROW( sData->mDataSize > mQueueHeader->mTableObj.mRecordSize, ERR_DBM_INVALID_RECORD_SIZE );

        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( mQueueHeader->mTableObj.mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * dbmQueueHeader 에서 table type 이
         * DBM_TBL_QUEUE 이 아니면 에러
         ***********************************************/
        _IF_THROW( mQueueHeader->mTableObj.mTableType != DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * NEW
         * Enqueue 시 Slot 을 직접 할당 받는다.
         ***********************************************/
        _CALL( mBuildNewNode ( aTransID, sData, &sNodeHeader ) );

        /***********************************************
         * NEW
         * Commit 후 죽으면 복구해야한다. 로깅하자.
         ***********************************************/
        sLogType = DBM_ENQUE_LOG;
        _rc = mLogMgr->mWriteMemLog( sLogType,
                aTransID,
                mQueueHeader->mTableObj.mTableID,
                mQueueHeader->mTableObj.mTableName,
                NULL, // mQueueHeader->mTableObj.mTableName,
                sNodeHeader->mMySlot,
                sData->mUserData,  /* Row Header 없는 Image */
                sData->mDataSize,
                mQueueHeader,
                mQueueHeader,
                &sLogHead );
        if ( _rc != 0 ) //, WRITE_LOG_FAIL );
        {
            DBM_ERR( "write log fail. rc=%d, log_type [%d]", _rc, sLogType );
            _THROW( ERR_DBM_WRITE_LOG );
        }
        sLogHead -> mQueProcDone = 1;

        RTF_POINT ("QUEMGR_ENQUEUE_2");
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mEnque */


_VOID dbmQueueManager::mBuildEnqueueLink( int aSlotID )
{
    dbmQNodeHeader* sNodeHeader = NULL;
    dbmQNodeHeader* sCurNodeHeader = NULL;

    _TRY
    {
        _CALL( mSegMgr->Slot2Addr ( aSlotID, &sNodeHeader ) );

        /***********************************************
         * NEW
         * 링크를 구성한다.
         ***********************************************/
        if ( mQStartPtr == NULL )
        {
            mQStartPtr = sNodeHeader ;
            mLastSlotID = sNodeHeader->mMySlot;
        }
        else
        {
            sCurNodeHeader = mQStartPtr;

            /*** Do Traverse  ***/
            do {
               if ( sCurNodeHeader->mNext == -1 )
               {
                   sCurNodeHeader->mNext = sNodeHeader->mMySlot;
                   mLastSlotID = sNodeHeader->mMySlot;
                   break;
               }
                _CALL( mSegMgr->Slot2Addr ( sCurNodeHeader->mNext, &sCurNodeHeader ) );
           } while ( true  ) ;
        }

        RTF_POINT ("QUEMGR_ENQUEUE_3");
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mBuildEnqueueLink */


/********************************************************************************
 *
 * 전체 Queue 에 대한 Commit 이 완료되면, Q Header 의 있는 주소를 Shared Queue Header로
 * 바꿔치겠다.
 *
 *******************************************************************************/
_VOID dbmQueueManager::mEnqCommitAll ( int aTransID )
{
    dbmQNodeHeader* sTmpQNode;
    int     sOldTx;

    _TRY
    {
        /******************************************************************
         * Check if there is nothing to do .
         *****************************************************************/
        if ( mQStartPtr == NULL )
        {
            _RETURN;
        }

        /******************************************************************
         * Commit 시점에는 아무도 못온다. Table Lock 을 잡아버린다.
         *****************************************************************/
        _rc = dbmLockManager::mTableLock ( &mQueueHeader->mLockEnq, aTransID, &sOldTx );
        if ( unlikely ( _rc != 0 ) )
        {
            if ( _rc == ERR_DBM_ABNORMAL_ROLLBACK )
            {
                if ( sOldTx >= 0 )
                {
                    _CALL( dbmRecoveryManager::mRecoverTrans ( mQueueHeader->mTableObj.mInstName, sOldTx ) );
                }
            }
            else
            {
                _THROW( _rc ); //, TABLE_LOCK_FAIL );
            }
        }

        _rc = dbmLockManager::mTableLock ( &mQueueHeader->mLock, aTransID, &sOldTx );
        if ( unlikely ( _rc != 0 ) )
        {
            if ( _rc == ERR_DBM_ABNORMAL_ROLLBACK )
            {
                if ( sOldTx >= 0 )
                {
                    _CALL( dbmRecoveryManager::mRecoverTrans ( mQueueHeader->mTableObj.mInstName, sOldTx ) );
                }
            }
            else
            {
                _THROW( _rc ); //, TABLE_LOCK_FAIL );
            }
        }

        /*** 테이블 Lock 을 잡은 상태이다. 자유롭게 변수를 바꿔준다.   */

        /** 먼저 Queue 가 Empty 상태라면 **/
        if ( mQueueHeader->mDeq == -1 )
        {
            /***************************************************
             * Enqueue 시 Critical 섹션인데, 보호할 방법이 없다.
             * 미봉책으로 다음과 같이 하겠다.
             *
             * CRITICAL_SECTION_START
             ***************************************************/
            mQueueHeader->mDeq = -2;                    // 잠깐 아무도 못보게 용도
            RTF_POINT( "QUEMGR_ENQUEUE_4" );
            mQueueHeader->mEnq = mLastSlotID;
            RTF_POINT( "QUEMGR_ENQUEUE_5" );
            mQueueHeader->mDeq = mQStartPtr->mMySlot;
            RTF_POINT( "QUEMGR_ENQUEUE_6" );
            /***************************************************
             * CRITICAL_SECTION_START
             ****************************************************/
        }
        /*** Queue 에 뭔가 뺄게 있는 상황 **/
        else
        {
            _CALL( mSegMgr->Slot2Addr ( mQueueHeader->mEnq, &sTmpQNode ) );

            mQueueHeader->mEnq = -2;
            /***************************************************
             * Enqueue 시 Critical 섹션인데, 보호할 방법이 없다.
             ***************************************************/
            RTF_POINT( "QUEMGR_ENQUEUE_7" );
            sTmpQNode->mNext = mQStartPtr->mMySlot;
            RTF_POINT( "QUEMGR_ENQUEUE_8" );
            mQueueHeader->mEnq = mLastSlotID;
            RTF_POINT( "QUEMGR_ENQUEUE_9" );
        }

        /******************************************************************
         * 모두 완료되었으면 다시 Old 값을 세팅해놓는다.
         *****************************************************************/
        RTF_POINT( "QUEMGR_ENQUEUE_10" );
        mQueueHeader->mOldDeq = mQueueHeader->mDeq;
        RTF_POINT( "QUEMGR_ENQUEUE_11" );
        mQueueHeader->mOldEnq = mQueueHeader->mEnq;
        RTF_POINT( "QUEMGR_ENQUEUE_12" );

        /*** 모두 Commit 이 완료되었으니 이제 봐라 **/
        _CALL( dbmLockManager::mTableUnlock ( &mQueueHeader->mLockEnq, aTransID ) );
        _CALL( dbmLockManager::mTableUnlock ( &mQueueHeader->mLock, aTransID ) );
        mQStartPtr = NULL;
        mLastSlotID = -1;

        cmnSignalFutex ( &mQueueHeader->mRFutex );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mEnqCommitAll */


/********************************************************************************
 * Name : mDeque
 *
 * Description
 *    mEnqueCommit 으로 기록된 Queue Data 를 읽는다.
 *
 * Argument
 *    aTransID    : input   : transaction id
 *    aDataObject : input   : user data object
 *
 ******************************************************************************/
_VOID dbmQueueManager::mDeque ( int aTransID , void* aDataObject )
{
    dbmDataObject*  sData  = (dbmDataObject *)aDataObject;
    dbmLogHeader*   sLogHead = NULL;
    dbmQNodeHeader* sQNodeHeader = NULL;
    dbmTransLog     sTransLog;
    long long       sCurRSlot = -1;
    int             sLogType;
    int             sOldTx = -1;
    int             sDeq = -1;
    int             sRC;

    _TRY
    {
        //TODO: 2015.03.24 -okt- 위치를 한칸 내려도 될까?
retry:
        /***********************************************
         * Drop 된 Table 이다.
         ***********************************************/
        _IF_THROW( mQueueHeader->mTableObj.mTableID != mTableID, ERR_DBM_INVALID_OBJECT );

        /***********************************************
         * Recovery 시점이라면 이걸 Dequeue 하면 안되고 대기한다.
         ***********************************************/
        if ( unlikely( mQueueHeader->mRecoveryProcessF == 1 ) )
        {
//          cmnUSleep ( 100000 );     // too big ??
            cmnUSleep ( 1000 );
            goto retry;
        }


        /*
         * TODO: 2015.03.24 -okt- [NOCS] 24개 인큐/디큐 경합에서, %sys 도 높고, 락 행 걸리는듯. 완화해본다.
         *       1) 데이타가 있을때만, 락 획득 시도한다.
         */
        if ( mQueueHeader->mDeq == -1 )  // There is nothing to deq
        {
            if ( sData->mTimeout != 0 )
            {
                sRC = cmnWaitFutex ( &mQueueHeader->mRFutex, sData->mTimeout );
                if ( sRC == ETIMEDOUT )
                {
                    DBM_TRC( "Queue(%s) timeout. timeout(%d) txid(%d)", mQueueName, sData->mTimeout, aTransID );
                    _THROW( ERR_DBM_NO_MATCH_RECORD );
                }

                //pthread_yield_s();    // 꺠었으면 바로간다.
                goto retry2;
            }
            else
            {
                _THROW( ERR_DBM_NO_MATCH_RECORD );
            }
        }


retry2:
        /***********************************************
         * Table Lock
         ***********************************************/
        sRC = dbmLockManager::mTableLock ( &mQueueHeader->mLock, aTransID, &sOldTx );
        if ( sRC == ERR_DBM_ABNORMAL_ROLLBACK )
        {
            if ( sOldTx >= 0 )
            {
                _rc = dbmRecoveryManager::mRecoverTrans ( mQueueHeader->mTableObj.mInstName, sOldTx );
                if ( _rc != 0 )
                {
                    DBM_ERR( "rollback tx(%d) for queue table lock fail. rc=%d (err=%d,tid=%d)",
                             sOldTx, _rc, errno, gettid_s() );
                    _THROW( _rc );
                }
            }
        }
        else if ( sRC != 0 )
        {
            DBM_ERR( "Queue(%s) lock fail. lock(%d) txid(%d) rc=%d (err=%d,tid=%d)",
                     mQueueName, mQueueHeader->mLock, aTransID, sRC, errno, gettid_s() );
            _THROW( ERR_DBM_LOCK );
        }


        sDeq = mQueueHeader->mDeq;
        if ( sDeq == -1 )  // There is nothing to deq
        {
            if ( sData->mTimeout != 0 )
            {
                /***********************************************
                 * Waiting 들어가기 전에 Lock 을 푼다.
                 ***********************************************/
                _CALL( dbmLockManager::mTableUnlock ( &mQueueHeader->mLock, aTransID ) );

                //TODO: [BUGBUG] Timeout must be decreased.
                sRC = cmnWaitFutex ( &mQueueHeader->mRFutex, sData->mTimeout );
                if ( sRC == ETIMEDOUT )
                {
                    DBM_TRC( "Queue(%s) timeout. timeout(%d) txid(%d)", mQueueName, sData->mTimeout, aTransID );
                    _THROW( ERR_DBM_NO_MATCH_RECORD );
                }

                pthread_yield_s();
                goto retry;
            }
            else
            {
                _CALL( dbmLockManager::mTableUnlock ( &mQueueHeader->mLock, aTransID ) );
                _THROW( ERR_DBM_NO_MATCH_RECORD );
            }

        }
        else  // There is somehing to deq
        {
            /***********************************************
             * Deq 할 데이터를 복사해놓겠다.
             ***********************************************/
            _CALL( mSegMgr->Slot2Addr ( sDeq, &sQNodeHeader ) );
            sData->mDataSize = sQNodeHeader->mDataSize;

            _DASSERT( sData->mUserData != NULL );
            memcpy_s ( sData->mUserData, (char*) sQNodeHeader + sizeof(dbmQNodeHeader), sData->mDataSize );


            /*************************************************
             * Disk Logging 을 수행한다.
             ************************************************/
            if ( mTransLogger != NULL )
            {

                if ( mQueueHeader->mTableObj.mNologgingF == 0 )
                {
                    sTransLog.mLogType = DBM_DEQUE_LOG ;
                    sTransLog.mObjectID = mQueueHeader->mTableObj.mTableID;
                    sTransLog.mSlot = sDeq ;
                    strncpy ( sTransLog.mObjectName, mQueueHeader->mTableObj.mTableName, DBM_NAME_LEN );
                    /*** Disk Dequeue Logging 시는 데이터를 다 남길 필요가 없다  일단 테스트 삼아 다 남김 **/
                    sTransLog.mImagePtr = sData->mUserData;
                    sTransLog.mImageSize = 0;
                    sTransLog.mSCN = sQNodeHeader->mSCN;
                    mTransLogger->mWriteLog (&sTransLog) ;
                }
            }

            /***********************************************
             * Logging 을 수행한다
             ***********************************************/
            sLogType = DBM_DEQUE_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                                          aTransID,
                                          mQueueHeader->mTableObj.mTableID,
                                          mQueueHeader->mTableObj.mTableName,
                                          NULL, // mQueueHeader->mTableObj.mTableName,
                                          sDeq,
                                          sData->mUserData,
                                          sData->mDataSize,
                                          mQueueHeader,
                                          mQueueHeader,
                                          &sLogHead );
            if ( sRC != 0 )
            {
                DBM_CERR( "write log fail. log_type [%d] rc=%d (err=%d,tid=%d)", sLogType, sRC, errno, gettid_s() );
                _THROW( ERR_DBM_WRITE_LOG );
            }

            RTF_POINT( "QUEMGR_DEQUEUE_1" );
            sLogHead->mQueProcDone = 1;
            RTF_POINT( "QUEMGR_DEQUEUE_2" );

            /***********************************************
             * Queue Header 의 Link 를 변경
             ***********************************************/
            mQueueHeader->mDeq = sQNodeHeader->mNext;
            RTF_POINT( "QUEMGR_DEQUEUE_3" );

            /***********************************************
             * 이전 Slot 을 Free 한다.
             ***********************************************/
            _CALL( dbmSegFreeSlot( mSegMgr, sDeq, 0 ) );

            mQueueHeader->mOldDeq = mQueueHeader->mDeq;
            sLogHead->mQueProcDone = 2;

            _rc = dbmLockManager::mTableUnlock ( &mQueueHeader->mLock, aTransID );
            if ( _rc != 0 )
            {
                DBM_ERR( "Unlock Fail, rc=%d Lock=%d TxID=%d sDeq=%d (err=%d,tid=%d)",
                         _rc, mQueueHeader->mLock, aTransID, sDeq, errno, gettid_s() );
                _THROW( _rc );
            }


            // 원래코드가 Timeout 검사 조건이 없다. 이유는, 다음 혹시 모를 대기자를 깨우는 것이기 때문인듯.
            //if ( sData->mTimeout != 0 )
            {
                cmnSignalFutex ( &mQueueHeader->mRFutex );
            }
        }

        /*** Deq를 수행했으니 해당 값을 올드로 복사해놓는다 */
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mDeque */


/***********************************************************************
 *
 * 정상 롤백이라면, Slot ID 만 가지고 Rollback 데이터를 복구할 수 있다.
 * Commit 되지 않은 데이터는 Free 시점에 복구 되기 때문이다.
 *
 * mDeqRollback 함수는 mEnque 함수와 하는 일은 거의 대부분 동일함.
 * 그런데 이건 순서 보장을 위해서 List 가 역순으로 구성되는 것이 다름.
 *
 **********************************************************************/
_VOID dbmQueueManager::mDeqRollback ( char* aBeforeImage , int aImageLength )
{
    dbmQNodeHeader* sNodeHeader;
    dbmQNodeHeader* sCurNodeHeader;
    dbmTransLog     sTransLog;
    long long sSlotID = -1;
    int     sLogCount = 0 ;
    int     sRC;

    _TRY
    {
        /**************************************************************
         * 만약 Dequeue 를 수회 수행후 다른 Enqueue 가 수행해서 Queue 를 Full
         * 내버렸다면 Rollback 시 Alloc Slot 실패로 에러가 날 수 있는데,
         * 크리티컬한 상황이다. 만약에 Alloc Slot 이 ERR_DBM_NO_SPACE 라면
         * 로그를 남겨주며, 재 시도한다.
         *************************************************************/
        while ( 1 )
        {
            sRC = dbmSegAllocSlot( mSegMgr, &sSlotID ) ;
            if ( sRC == ERR_DBM_NO_SPACE )
            {
                // 2014.12.14. -okt- 2014.09.21, _CALL로 묶어 오류처리 해주고 싶은데. 여러놈이 동시시도 하면 다른놈은 '정상실패' 가능한가?
                sRC = mSegMgr->Extend() ;
                continue;
            }
            break;
        }

        if ( sRC != 0 ) //, ALLOC_SLOT_FAIL ) ;
        {
            DBM_ERR( "Queue(%s) alloc slot fail. slot(%ld)", mQueueName, sSlotID );
            _THROW( ERR_DBM_SLOT2ADDR_FAIL );
        }

        sRC = mSegMgr->Slot2Addr ( sSlotID, &sNodeHeader) ;
        if ( unlikely( sRC != 0 ) ) //, SLOT2ADDR_FAIL ) ;
        {
            DBM_ERR( "Queue(%s) slot2addr fail. slot(%ld)", mQueueName, sSlotID );
            _THROW( ERR_DBM_SLOT2ADDR_FAIL );
        }

        /*************************************************************
         * 할당 받은 슬롯에 복사
         ************************************************************/

        sNodeHeader->mMySlot = sSlotID;
        sNodeHeader->mNext = -1;
        sNodeHeader->mDataSize = aImageLength;
        sNodeHeader->mLock = -1;

        memcpy_s ( (char*)sNodeHeader + sizeof(dbmQNodeHeader), aBeforeImage, aImageLength );

        /***************************************************************
         * Disk Log 를 남긴다. 나 Enque 되었음.
         **************************************************************/
        if ( mTransLogger != NULL )
        {

            sTransLog.mLogType = DBM_ENQUE_LOG;
            sTransLog.mObjectID = mQueueHeader->mTableObj.mTableID;
            sTransLog.mSlot = sSlotID;
            cmnStrCpy ( sTransLog.mObjectName, mQueueName, DBM_NAME_LEN );
            sTransLog.mImagePtr = aBeforeImage;
            sTransLog.mImageSize = aImageLength;
            sTransLog.mSCN = sNodeHeader->mSCN;

            _CALL( mTransLogger->mWriteLog ( &sTransLog ) );
        }

        if ( mRollbackStartPtr == NULL )
        {

            /*************************************************************
             * 역순으로 리스트를 구성하기 위해서 처음에 들어오는 것은 마감 친다.
             ************************************************************/
            mRollbackStartPtr = sNodeHeader ;
            mRollbackLastSlotID = sNodeHeader->mMySlot;
        }
        else
        {
            /*************************************************************
             * 들어온 순서의 역순으로 리스트를 구성한다.
             ***********************************************************/
            sNodeHeader->mNext = mRollbackStartPtr->mMySlot;
            mRollbackStartPtr = sNodeHeader;
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mDeqRollback */


/***********************************************************************
 *
 * mEnqCommitAll () 와 비슷하게 mDeqRollback 에서 수행한 로그를 한번에 모아
 * Header 에 연결한다.
 *
 **********************************************************************/
_VOID dbmQueueManager::mDeqRollbackComplete ( int aTransID )
{
    dbmQNodeHeader* sTmpQNode = NULL;
    int     sRC ;
    int     sOldTx;

    _TRY
    {
        /******************************************************************
         * Check if there is nothing to do .
         *****************************************************************/
        if ( mRollbackStartPtr == NULL )
        {
            _RETURN;
        }

        /******************************************************************
         * Rollback 을 하기 위해서는 아무도 못온다. Lock 을 잡아야한다.
         *****************************************************************/
        _rc = dbmLockManager::mTableLock( &mQueueHeader->mLock, aTransID, &sOldTx );
        if( _rc != 0 )
        {
            if( _rc == ERR_DBM_ABNORMAL_ROLLBACK )
            {
                if( sOldTx >= 0 )
                {
                    _CALL( dbmRecoveryManager::mRecoverTrans( mQueueHeader->mTableObj.mInstName, sOldTx ) );
                }
            }
            else
            {
                _THROW( _rc );
            }
        }

        /*** 테이블 Lock 을 잡은 상태이다. 자유롭게 변수를 바꿔준다.   */

        /*******************************************************************
         *  롤백 시점에는 무조건 mDeq 와 바꿔야한다.
         ******************************************************************/
        if ( mQueueHeader->mDeq == -1)
        {
            mQueueHeader->mDeq = mRollbackStartPtr->mMySlot;
            mQueueHeader->mEnq = mRollbackLastSlotID;
        }
        else
        {
            _CALL( mSegMgr->Slot2Addr ( mRollbackLastSlotID, &sTmpQNode) );

            sTmpQNode->mNext = mQueueHeader->mDeq;
            mQueueHeader->mDeq = mRollbackStartPtr->mMySlot;
        }

        mQueueHeader->mOldDeq = mQueueHeader->mDeq;
        /*** 모두 Rollback 이 완료되었으니 이제 봐라 **/
        _CALL( dbmLockManager::mTableUnlock( &mQueueHeader->mLock, aTransID ) );
        //assert (sRC == RC_SUCCESS) ;

        mRollbackStartPtr = NULL ;
        mRollbackLastSlotID = -1;

        cmnSignalFutex( &mQueueHeader->mRFutex );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mDeqRollbackComplete */


/*
 * temporary for linking
 * 2014.12.14. -okt- 2014.09.21 미구현인듯 막음.
 */
//int dbmQueueManager::mDequeArray(int, void*)
//{
//    return RC_SUCCESS;
//}
//
//int dbmQueueManager::mDequeMore(int, void*)
//{
//    return RC_SUCCESS;
//}
