/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
 *   dbmLogManager 의 멤버함수들을 구현한다.
 ******************************************************************************/
#include "dbmHeader.h"
#include "dbmLogManager.h"


char dbmLogTypeStr[][32] =
{
    ""
  , "DBM_ALLOC_SLOT_LOG"
  , "DBM_ALLOC_IDX_SLOT_LOG"
  , "DBM_FREE_SLOT_LOG"
  , "DBM_INSERT_SLOT_LOG"
  , "DBM_UPDATE_SLOT_LOG"

  , "DBM_UPDATE_KEY_LOG"
  , "DBM_DELETE_SLOT_LOG"
  , "DBM_INSERT_INDEX_LOG"
  , "DBM_INSERT_INDEX_LOG2"
  , "DBM_DELETE_INDEX_LOG"

  , "DBM_DELETE_INDEX_LOG2"
  , "DBM_DELETE_INDEX_LOG3"
  , "DBM_DELETE_INDEX_LOG4"
  , "DBM_DELETE_DATA_LOG"
  , "DBM_SELECT_FOR_UPDATE_LOG"

  , "DBM_TRUNCATE_LOG"
  , "DBM_ENQUE_LOG"
  , "DBM_DEQUE_LOG"
  , "DBM_DDL_CREATE_QUEUE_LOG"
  , "DBM_DDL_CREATE_TABLE_LOG"

  , "DBM_DDL_CREATE_DIRECT_LOG"
  , "DBM_DDL_DROP_TABLE_LOG"
  , "DBM_DDL_CREATE_INDEX_LOG"
  , "DBM_DDL_DROP_INDEX_LOG"
  , "DBM_DDL_DROP_QUEUE_LOG"

  , "DBM_DDL_CREATE_TRIG_LOG"
  , "DBM_DDL_DROP_TRIG_LOG"
  , "DBM_DDL_DROP_USER_LOG"
  , "DBM_LOCK_ROW_LOG"
  , "DBM_DEFER_INSERT_LOG"

  , "DBM_DEFER_UPDATE_LOG"
  , "DBM_BEGIN_TX_LOG"
  , "DBM_REPL_COMMIT_LOG"
  , "DBM_REPL_ROLLBACK_LOG"
  , "DBM_COMMIT_LOG"

  , "DBM_ROLLBACK_LOG"
  , "DBM_SET_INDEX_LOG"
  , "DBM_COMMIT_ACK_LOG"
  , "DBM_CLEAR_DEFER_LOG"
  , "DBM_DEQUE_CONFIRM_LOG"

  , "DBM_DUMMY_ACK_LOG"
  , "DBM_DDL_CREATE_LIST_LOG"
  , "DBM_LIST_LPUSH_LOG"
  , "DBM_LIST_RPUSH_LOG"
  , "DBM_LIST_LPOP_LOG"

  , "DBM_LIST_RPOP_LOG"
  , "DBM_LIST_LRANG_LOG"
  , "DBM_LOCK_LIST_LOG"
  , "DBM_LIST_HEADER_LPUSH_LOG"
  , "DBM_LIST_HEADER_RPUSH_LOG"

  , "DBM_LIST_HEADER_LPOP_LOG"
  , "DBM_LIST_HEADER_RPOP_LOG"
  , "DBM_RECOVER_END_LOG"

  , "DBM_LOG_TYPE_MAX"                     // 컴파일 워닝 제거용. 초기값
};


/******************************************************************************
 * Name : mWriteMemLog
 *
 * Description
 *      Memory Log 기록.
 *      alloc extent 일 경우에는 aRefRID 에 할당된 일련의 Page 중 시작 페이지를,
 *      aRefRID2 에 마지막 페이지를 저장해서 넘어와야 한다.
 *
 * Argument
 *     aLogType        : input   : Log Type
 *     aTransID        : input   : Transaction ID
 *     aObjectID       : input   : Object ID
 *     aObjectName     : input   : Object Name
 *     aRefRecord      : input   : Reference Record Slot ID
 *     aValue          : input   : Image to Write
 *     aSize           : input   : Image Size (user data + sizeof(dbmRowHeader))
 *                                 Index 의 경우는 그냥 row header 없이 key 값의 size 만.
 *     aRefPointer     : input   : 각종 Reference 포인터 - 정상 운영 때만 사용.
 *     aObjectHeader   : input   : Pointer to Object Header
 *     aLogHead        : output  : 이번 로그를 기록한 dbmLogHeader 포인터
 *
 ******************************************************************************/

typedef struct dbmCloneHeader
{
    int     mPID;
    int     mMyTxID;
    int     mLastAllocLogSlot;
    int     mLastAllocImageSlot;
    long long mLogCurPos;
    long long mImageCurPos;
} dbmCloneHeader;


/*
 * (성능) perf 기준 INSERT에서 TOP-3 비용함수임. 신경쓰자.!!
 */
_VOID dbmLogManager::mWriteMemLog(
                                 int            aLogType, /* dbmLogType     aLogType, */
                                 int            aTransID,
                                 int            aObjectID,
                                 char*          aObjectName,
                                 char*          aTableName,
                                 long long      aRefRecord,
                                 char*          aValue,
                                 int            aSize,
                                 /* 2014.11.20. -okt- 타입캐스팅 비용제거. 혹은 내부에서.
                                 char*          aRefPointer,
                                 char*          aObjectHeader,
                                 char**         aLogHead
                                  */
                                 void*          aRefPointer,
                                 void*          aObjectHeader,
                                 void*          aLogHead /* char** aLogHead */
                                 )
{
    //__builtin_prefetch ( mTxHeader, 0, 1 ); //TODO: 2014.11.18. -okt- 효과있을까? 부작용 없다는 것을 어찌 검증할까?

    dbmLogHeader*   sLogPtr = NULL;
    dbmTransHeader* sTxH = (dbmTransHeader*)mTxHeader;
    dbmCloneHeader  sCloneH;
    char*           sSlotPtr = NULL;
    char*           sImagePtr = NULL;
    long long       sLSN;
    long long       sSlotID;
    long long       sOffset;
    int             sRC = -1;

#if 0
    // -okt- __builtin_prefetch 예제.
   long __builtin_prefetch (const void *ADDR, int RW, int LOCALITY)
   → 매개변수 ADDR에 있는 데이터를 캐시에 prefetch하고자 할 경우 사용한다.
   매개변수 RW가 1일 경우는 가까운 곳에 기록할 내용이 있음을, 0일 경우는 가까운 곳에 읽어야 할 내용이 있음을 나타낸다.
   매개변수 LOCALITY는 0~3사이 값으로 0은 사용하면 바로 불필요한 데이터, 3은 사용하기 시작하면 당분간 계속 사용할 데이터임을 나타냄.

    for (i = 0; i < n; i++)
      {
        a[i] = a[i] + b[i];
        __builtin_prefetch (&a[i+j], 1, 1);
        __builtin_prefetch (&b[i+j], 0, 1);
        /* ... */
      }
#endif

    _TRY
    {
        _DASSERT( aObjectName[0] != 0x00 ); // 2014.10.02 -okt- 성능함수이고 내부에서 호출되는 함수이다. 오류없이 상위에서 잘써야한다.

        /****************************************************
         * Transaction 상태를 Logging 상태로 변경
         ***************************************************/
        sTxH->mStatus = DBM_TX_LOGGING;
        RTF_POINT( "LOGMGR_WRITE_MEMLOG_1" );


        /****************************************************
         * 작업을 마칠 때까지는 원래의 trans header 를
         * 변경하지 않기 위해 복제된 header 에 값을 셋팅한다.
         ***************************************************/
        sCloneH.mPID                = sTxH->mPID;               // 2014.11.18. -okt- perf에서 여기가 수치가 보여서, __builtin_prefetch를 함수 맨앞에.. 시도.
        sCloneH.mMyTxID             = sTxH->mMyTxID;
        sCloneH.mLastAllocLogSlot   = sTxH->mLastAllocLogSlot;
        sCloneH.mLogCurPos          = sTxH->mLogCurPos;
        sCloneH.mLastAllocImageSlot = sTxH->mLastAllocImageSlot;
        sCloneH.mImageCurPos        = sTxH->mImageCurPos;


        /****************************************************
         * Log 를 기록할 위치 탐색
         * mLogCurPos 를 먼저 증가시키고 작업한다.
         * 복구 시에는 mLogCurPos 부터 역으로 복구하면서
         * Valid 한 로그만 복구하면 된다.
         ***************************************************/
        _CALL( mGetPos2Write ( &sCloneH.mLastAllocLogSlot,
                               sTxH->mLogCntPerSlot,
                               sTxH->mLogStartPos,
                               &sCloneH.mLogCurPos ) );
        //_IF_RAISE( sRC, GET_OFFSET2WRITE_FAIL );

        RTF_POINT( "LOGMGR_WRITE_MEMLOG_2" );

        sSlotID = SLOTID ( sCloneH.mLogCurPos );
        sOffset = OFFSET ( sCloneH.mLogCurPos );

        _CALL( mUndoSegMgr->Slot2Addr ( sSlotID, &sSlotPtr ) );

        sLogPtr = GETLOG( sSlotPtr, sOffset );

        /****************************************************
         * 이전 공간이 재 사용될 수 있기 때문에 반드시
         * 먼저 LogValidF 를 초기화 먼저 한다.
         * 그렇지 않으면 로그 기록을 마치지 않은 상황에서
         * 다른 놈이 읽을 수도 있는 상황이 발생할 수 있다.
         ***************************************************/
        sLogPtr->mLogValidF         = 0;
        RTF_POINT( "LOGMGR_WRITE_MEMLOG_3" );

        sLogPtr->mImageLogValidF    = 0;
        sLogPtr->mCommitCompleteF   = 0;
        RTF_POINT("LOGMGR_WRITE_MEMLOG_4");

        sLogPtr->mRollbackCompleteF = 0;
        sLogPtr->mQueProcDone       = 0;
/*
 * TODO: 2014.11.18. -okt-
 *
       │             sLogPtr->mLogValidF         = 0;                                                                   ▒
  0.98 │       movb   $0x0,0x80(%rbp)                                                                                   ▒
       │             RTF_POINT( "LOGMGR_WRITE_MEMLOG_3" );                                                              ▒
       │                                                                                                                ▒
       │             sLogPtr->mImageLogValidF    = 0;                                                                   ▒
  9.71 │       movb   $0x0,0x81(%rbp)                                                                                   ▒
       │             sLogPtr->mCommitCompleteF   = 0;                                                                   ▒
  3.12 │       movb   $0x0,0x82(%rbp)                                                                                   ▒
       │             RTF_POINT("LOGMGR_WRITE_MEMLOG_4");                                                                ▒
       │                                                                                                                ▒
       │             sLogPtr->mRollbackCompleteF = 0;                                                                   ▒
  0.56 │       movb   $0x0,0x83(%rbp)                                                                                   ▒
       │             sLogPtr->mQueProcDone       = 0;                                                                   ▒
  1.03 │       movq   $0x0,0x88(%rbp)
 */

        /****************************************************
         * 기록할 Log Header 셋팅해둠
         ***************************************************/
        // 2014.09.20 -okt- 어짜피 매번 성공이다.
        mGetLSN( &sLSN );

#ifdef _DEBUG
        // 2014.12.14. -okt- (성능) aObjectName과 aTableName이 동일하면 상위에서 NULL을 넘겨야한다. 방어코드 추가.
//        if ( strcmp( aTableName, aObjectName ) == 0 )
//        {
//            _DASSERT( 0 );
//        }
#endif
        if ( aTableName != NULL )
        {
            //if ( aTableName[0] != 0x00 )  //2014.09.20 (OKT): (성능) 거의 항상 성립할것이다. 아니어도 strcpy 이므로 동일결과
            {
                strncpy_s( sLogPtr->mTableName, aTableName, DBM_NAME_LEN );
            }
        }
        else
        {
            sLogPtr->mTableName[0] = 0;
        }

        sLogPtr->mLogType           = (dbmLogType)aLogType;
        sLogPtr->mMyLogPos          = sCloneH.mLogCurPos;
        sLogPtr->mTransID           = aTransID;
        sLogPtr->mObjectID          = aObjectID;

        /*
         * 2014.12.14. -okt- (성능) insert 한건당. 4번 호출발생. mWriteMemLog
         */
        strncpy_s( sLogPtr->mObjectName, aObjectName, DBM_NAME_LEN );

        sLogPtr->mRefRecord         = aRefRecord;
        sLogPtr->mImageLogPos       = MK_POS(-1,-1);
        sLogPtr->mImageSize         = aSize;
        sLogPtr->mLSN               = sLSN;
        sLogPtr->mRefPtr            = (char*)aRefPointer;
        sLogPtr->mObjectHeader      = (char*)aObjectHeader;

#if 0
        /*
         * 현재는 필요없는 코드인것을 근한님께 확인함.
         * 지우지 않고 남기는 것은 추후 필요하더라도. 1회 INSERT 호출에 4번 호출되는 성능 함수로.
         * LOG_TYPE 별로 더 적게 호출할 수 있다면. 그게 성능에 도움이 됨.
         *
         * mGetSCN 는 전역경합 함수이다. 주의요.
         */
        if ( sTxH->mDiskLoggingEnableF == 1 )
        {
            //mGetSCN ( &sLogPtr->mSCN );
            mPeekSCN ( &sLogPtr->mSCN );
        }
#endif

        switch( aLogType )
        {
            /****************************************************
             * Log 와 Image 를 둘다 기록해야하는 놈들
             ***************************************************/
            case DBM_INSERT_SLOT_LOG:           // INSERT(4)
            case DBM_UPDATE_SLOT_LOG:
            case DBM_UPDATE_KEY_LOG:
            case DBM_INSERT_INDEX_LOG:          // INSERT(3)
            case DBM_INSERT_INDEX_LOG2:
            case DBM_DELETE_INDEX_LOG:
            case DBM_DELETE_INDEX_LOG2:
            case DBM_DELETE_INDEX_LOG3:
            case DBM_DELETE_INDEX_LOG4:
            case DBM_DELETE_DATA_LOG:
            case DBM_SELECT_FOR_UPDATE_LOG:
            case DBM_ENQUE_LOG:
            case DBM_DEQUE_LOG:
            case DBM_DEFER_INSERT_LOG:
            case DBM_DEFER_UPDATE_LOG:
            case DBM_LIST_LPUSH_LOG:
            case DBM_LIST_RPUSH_LOG:
            case DBM_LIST_LPOP_LOG:
            case DBM_LIST_RPOP_LOG:
            case DBM_DDL_CREATE_LIST_LOG:
            case DBM_DDL_CREATE_QUEUE_LOG:
            case DBM_DDL_CREATE_TABLE_LOG:
            case DBM_DDL_CREATE_INDEX_LOG:


                /****************************************************
                 * Image 를 기록할 위치 탐색
                 ***************************************************/
                RTF_POINT("LOGMGR_WRITE_MEMLOG_5");

                _CALL( mGetPos2Write( &sCloneH.mLastAllocImageSlot,
                                      sTxH->mImageCntPerSlot,
                                      sTxH->mImageStartPos,
                                      &sCloneH.mImageCurPos ) );
                //_IF_RAISE( sRC, GET_OFFSET2WRITE_FAIL );

                RTF_POINT( "LOGMGR_WRITE_MEMLOG_6" );

                sSlotID = SLOTID ( sCloneH.mImageCurPos );
                sOffset = OFFSET ( sCloneH.mImageCurPos );

                sSlotPtr = NULL;

                _CALL( mUndoSegMgr->Slot2Addr( sSlotID, &sSlotPtr ) );

                sImagePtr = (char*)GETIMG( sSlotPtr, sOffset );

                /****************************************************
                 * Transaction Header 갱신
                 ***************************************************/
                memcpy_s( sTxH, &sCloneH, sizeof(dbmCloneHeader) ); //TODO: 2014.11.23 -okt- 12byte 고정크기이다. 더 빠른 방법은 없나?
                RTF_POINT( "LOGMGR_WRITE_MEMLOG_7" );

                /****************************************************
                 * Set Log Valid
                 ***************************************************/
                sLogPtr->mLogValidF = 1;

                /****************************************************
                 * Image Copy
                 * mImageLogValidF = 1 이 셋팅되기 전에 Down 된다면
                 * 해당 이미지는 기록되지 않은 셈이므로 복구 시
                 * Log 도 쓸모없어진다.
                 ***************************************************/
                memcpy_s( sImagePtr, aValue, aSize );
                RTF_POINT("LOGMGR_WRITE_MEMLOG_8");

                sLogPtr->mImageLogPos    = sCloneH.mImageCurPos;
                /*
                 * 2014.12.14. -okt- #486 라인순서가 바뀐 것 같음, 컴파일러 최적화? CPU 최적화?
                 * https://kldp.org/node/84286
                 * smp_rmb();
                 */
                barrier();
                sLogPtr->mImageLogValidF = 1;

                break;

            /****************************************************
             * Log 만 기록하면 되는 놈들
             ***************************************************/
            case DBM_ALLOC_SLOT_LOG:            // INSERT(1)
            case DBM_ALLOC_IDX_SLOT_LOG:
            case DBM_FREE_SLOT_LOG:
            case DBM_TRUNCATE_LOG:
            case DBM_DELETE_SLOT_LOG:
            case DBM_DDL_CREATE_DIRECT_LOG:
            case DBM_DDL_DROP_TABLE_LOG:
            case DBM_DDL_DROP_INDEX_LOG:
            case DBM_DDL_CREATE_TRIG_LOG:
            case DBM_DDL_DROP_TRIG_LOG:
            case DBM_DDL_DROP_USER_LOG:
            case DBM_LOCK_ROW_LOG:              // INSERT(2)
            case DBM_BEGIN_TX_LOG:
            case DBM_REPL_COMMIT_LOG:
            case DBM_REPL_ROLLBACK_LOG:
            case DBM_COMMIT_LOG:
            case DBM_ROLLBACK_LOG:
            case DBM_COMMIT_ACK_LOG:
            case DBM_CLEAR_DEFER_LOG:
            case DBM_DEQUE_CONFIRM_LOG:
            case DBM_DUMMY_ACK_LOG:
            case DBM_LIST_HEADER_LPUSH_LOG:
            case DBM_LIST_HEADER_LPOP_LOG:
            case DBM_LIST_HEADER_RPUSH_LOG:
            case DBM_LIST_HEADER_RPOP_LOG:
            case DBM_LOCK_LIST_LOG:
            case DBM_SET_INDEX_LOG:
                /****************************************************
                 * Transaction Header 갱신
                 ***************************************************/
                memcpy_s( sTxH, &sCloneH, sizeof(dbmCloneHeader) );
                RTF_POINT("LOGMGR_WRITE_MEMLOG_9");

                /****************************************************
                 * Set Log Valid
                 ***************************************************/
                //barrier();                  // 2014.12.14. -okt- 2014.09.20 넣을까 말까?
                sLogPtr->mLogValidF = 1;
                break;

            default:
                DBM_ERR( "Invalid log type [%d]", aLogType );
                _THROW( -1 ); //_RAISE( INVALID_LOG_TYPE );
                break;
        }

        *(dbmLogHeader**)aLogHead = sLogPtr;
/*
 * TODO: 2014.11.18 -okt- 참내.
       │             *aLogHead = (char*)sLogPtr;                                                                        ▒
  0.60 │309:   mov    0xb8(%rsp),%rax                                                                                   ▒
  1.84 │       mov    %rbp,(%rax)
 */

        /****************************************************
         * 다음 Logging 대기 중 상태로 변경
         ***************************************************/
        sTxH->mStatus = DBM_TX_LOG_WAIT; //   5.99 │       movl   $0x2,0x38(%r12)
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mWriteMemLog */


/******************************************************************************
 * Name : mGetPos2Write
 *
 * Description
 *   Log & Image 를 기록할 위치( Offset ) 탐색
 *
 * Argument
 *     aLastAllocSlot    : input    : alloc 된 마지막 Slot 의 ID
 *     aLogCntPerSlot    : input    : slot 당 log 갯수
 *     aStartPos         : input    : log start 위치
 *     aCurPos           : input    : 마지막으로 기록한 위치
 *     aPos2Write        : output   : 이번에 기록할 위치
 *
 ******************************************************************************/
_VOID dbmLogManager::mGetPos2Write ( int* aLastAllocSlot , int aLogCntPerSlot , long long aStartPos , long long* aCurPos )
{
    long long           sNewSlotID   = -1;
    dbmLogSlotHeader*   sCurLogSlotH = NULL;
    dbmLogSlotHeader*   sNewLogSlotH = NULL;
    long long           sCurPos = *aCurPos;
    int                 sRC = -1;

    _TRY
    {
        if ( OFFSET ( sCurPos ) == -1 )
        {
            /****************************************************
             * 첫번째 Log
             ***************************************************/
            *aCurPos = aStartPos;

            return RC_SUCCESS;
        }

        if ( ( OFFSET ( sCurPos ) + 1 ) == aLogCntPerSlot )
        {
            if ( SLOTID ( sCurPos ) == *aLastAllocSlot )
            {
                /****************************************************
                 * 1. Alloc 된 slot 모두 소진된 경우 신규 slot 할당.
                 *    아래 과정에서 죽으면 그냥 이 Slot 은 버리자.
                 ***************************************************/
                sRC = dbmSegAllocSlot ( mUndoSegMgr, &sNewSlotID );
                if ( sRC ) //, ALLOC_SLOT_FAIL );
                {
                    DBM_ERR( "alloc undo page fail. rc[%d] slot[%ld]", sRC, sNewSlotID );
                    _THROW( ERR_DBM_ALLOC_PAGE );
                }

                _CALL( mUndoSegMgr->Slot2Addr ( sNewSlotID, &sNewLogSlotH ) );
                //_IF_RAISE( sRC || sNewLogSlotH == NULL, SLOT2ADDR_FAIL );

                _CALL( mInitLogSlot ( sNewLogSlotH, sNewSlotID ) );

                _CALL( mUndoSegMgr->Slot2Addr ( SLOTID ( sCurPos ), &sCurLogSlotH ) );

                sCurLogSlotH->mNext = sNewSlotID;

                *aLastAllocSlot = sNewSlotID;
                //TODO: 2014.11.23 -okt- #486 관련 디버그 정보 추가.
#ifdef _DEBUG
                if ( sNewSlotID == -1 )
                {
                    _DASSERT( 0 );
                }
#endif
                *aCurPos = MK_POS ( sNewSlotID, 0 );
            }
            else
            {
                _CALL( mUndoSegMgr->Slot2Addr ( SLOTID ( sCurPos ), &sCurLogSlotH ) );

                /****************************************************
                 * 2. 다음 alloc slot 사용.
                 ***************************************************/
                if ( sCurLogSlotH->mNext < 0 ) //, INVALID_SLOT_LIST );
                {
                    DBM_ERR( "invalid slot list." );
                    _THROW( ERR_DBM_INVALID_LOG_SLOT_LIST );
                }

                //TODO: 2014.11.23 -okt- #486 관련 디버그 정보 추가.
#ifdef _DEBUG
                if ( sCurLogSlotH->mNext == -1 )
                {
                    _DASSERT( 0 );
                }
#endif
                *aCurPos = MK_POS ( sCurLogSlotH->mNext, 0 );
            }
        }
        else
        {
            /****************************************************
             * 3. 사용하던 slot 의 다음 offset 사용
             ***************************************************/
            /*
             sCurSlot   = SLOTID(sCurPos);
             sCurOffset = OFFSET(sCurPos) + 1;
             *aPos2Write = MK_POS( sCurSlot, sCurOffset );
             */
            *aCurPos = sCurPos + 1;
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mGetPos2Write */


/******************************************************************************
 * Name : mGetSCN
 *
 * Description
 *     SCN 채번
 *
 * Argument
 *     aSCN        : output   : 채번된 SCN
 *
 ******************************************************************************/
void dbmLogManager::mGetSCN( long long* aSCN )
{
    *aSCN = mvpAtomicInc64( &( ((dbmUndoHeader*)mUndoHeader)->mGSCN ) );

    /*
     * 2014.09.22 (OKT): 간단한, 언제나 성공하는 함수라도 _VOID 타입이 권고이나. 여기는 성능 구간으로 void 처리
     */
    //return RC_SUCCESS;
}


/******************************************************************************
 * Name : mGetLSN
 *
 * Description
 *     LSN 채번
 *
 * Argument
 *     aLSN        : output   : 채번된 LSN
 *
 ******************************************************************************/
void dbmLogManager::mGetLSN( long long* aLSN )
{
    *aLSN = mvpAtomicInc64 ( &((dbmUndoHeader*)mUndoHeader)->mGLSN );
    //return RC_SUCCESS;    // 반드시 성공하므로 리턴 타입도 제거.
}


void dbmLogManager::mPeekSCN( long long* aSCN )
{
    *aSCN = mvpAtomicGet64( &((dbmUndoHeader*)mUndoHeader)->mGSCN );
}


_VOID dbmLogManager::mInitLogSlot ( dbmLogSlotHeader* aSlot , long long aSlotID )
{
    aSlot->mMySlotID = aSlotID;
    aSlot->mNext     = -1;
    aSlot->mPrev     = -1;

    return 0;
}


/******************************************************************************
 * Name : mReadUndoRecord
 *
 * Description
 *     Undo Log 를 모두 돌면서 Record SlotID 에 해당하는 최초 이미지를 읽는다.
 *     Select 시에 ReadRecord 를 하려고 할 때 Row Header 에 자신의 TxID 가 아닌
 *     다른 TxID 가 기록되어 있다면 다른 Tx 에서 변경 중이므로 해당 Tx 의
 *     Undo Log 들을 뒤져서 가장 최초의 before 이미지를 읽게 된다.
 *     즉, 해당 Row 가 변경되기 직전의 image 를 읽는다.
 *
 * Argument
 *     aTransID        : input   : 읽을 Transaction Log 의 ID
 *     aRecordSlotID   : input   : 읽을 Record Slot ID
 *     aData           : output  : 읽은 Record 이미지
 *     aDataSize       : output  : 읽은 Record 이미지의 size
 *     aMySCN          : output  : 읽을 수 있는 이미지인지를 판단하기 위한 SCN
 *
 ******************************************************************************/
_VOID dbmLogManager::mReadUndoRecord ( int aTransID , long long aRecordSlotID , char* aData ,
                                       int* aDataSize , long long aMySCN , int* aInsertedRowF, dbmLogType* aLogType )
{
    dbmLogSlotHeader*   sStartSlot  = NULL;
    dbmLogSlotHeader*   sCurSlot    = NULL;
    dbmLogSlotHeader*   sNextSlot   = NULL;
    dbmTransHeader*     sTxHeader   = NULL;
    int                 sFound      = 0;
    long long           sLastOffset;
    int                 sRC;

    _TRY
    {
        sTxHeader = (dbmTransHeader*)( (char*)mUndoSegMgr->GetUserHeader ( ) + sizeof(dbmTransHeader) * aTransID );

        if ( unlikely( SLOTID ( sTxHeader->mLogStartPos ) == -1 ) ) //, INVALID_LOGHEAD_INFO );
        {
            static int ix = 0;

            ix ++;
            if ( ix > 10 )
            {
                cmnUSleep( 100 * 1000 );            // 2014.12.14. -okt- 로그도배방지, 죽어야하는 것 아닌지?.
            }

            // 2014.12.14. -okt- 여기서 나가면 상위에서 무한루프 인가?
            DBM_ERR( "invalid tx header info. tx=%d, slot=%ld, LogPos=%ld", aTransID, aRecordSlotID, sTxHeader->mLogStartPos );

            _THROW( ERR_DBM_INVALID_HEADER );
        }

        sRC = mUndoSegMgr->Slot2Addr ( SLOTID ( sTxHeader->mLogStartPos ), &sStartSlot );
        _IF_THROW( sRC, ERR_DBM_SLOT2ADDR_FAIL );

        sCurSlot = sStartSlot;

        while ( 1 )
        {
            /****************************************************
             * sCurSlot 에서 Reference Record 가 aRecordSlotID 인
             * 이미지를 읽는다.
             ***************************************************/
            if ( sCurSlot->mNext == -1 )
            {
                sLastOffset = OFFSET ( sTxHeader->mLogCurPos );
            }
            else
            {
                sLastOffset = sTxHeader->mLogCntPerSlot;
            }

            /****************************************************
             * 그사이 이 Transaction 이 commit 되면 mLogCurPos 가
             * -1 로 설정되므로 읽으면 안됨.
             ***************************************************/
            _IF_THROW( SLOTID ( sTxHeader->mLogCurPos ) == -1, ERR_DBM_NO_MATCH_RECORD );

            sRC = mReadUndoSlotRecord( sTxHeader,
                                       (char*)sCurSlot,
                                       sLastOffset,
                                       aRecordSlotID,
                                       aData,
                                       aDataSize,
                                       aMySCN,
                                       aInsertedRowF,
                                       aLogType );
            if ( sRC == RC_SUCCESS )
            {
                /****************************************************
                 * 일단 발견되면 aData 에 최초 이미지가 저장되고,
                 * 이를 리턴하면 됨
                 ***************************************************/
                sFound = 1;
                break;
            }
            else
            {
                if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                {
                    /****************************************************
                     * 신규로 insert 된 Record 는 Undo 를 읽을 필요없음.
                     ***************************************************/
                    if ( *aInsertedRowF == 1 )
                    {
                        sFound = 0;
                        break;
                    }
                }

                // 2015-07-29 by lim272.
                // 여러개의 Undo Page를 가질 수 있기 때문에
                // 여기서는 실제 1개의 UndoPage만 봤을때 없다는 의미이다.
                // 따라서, 에러를 리턴하면 안되고 NextPos를 더 탐색해야만 함.
                // 그래서 아래 Line을 주석처리한다.
                // 여기서 나가고 다음Page가 없다면 아래 코드에서 break하고 
                // Not found로 리턴하게 될 것임.
                //_THROW( sRC ); //READ_UNDOSLOT_FAIL );
            }

            if ( sCurSlot->mNext != -1 )
            {
                /****************************************************
                 * 다음 Log Slot 으로 이동
                 ***************************************************/
                sRC = mUndoSegMgr->Slot2Addr ( sCurSlot->mNext, &sNextSlot );
                _IF_THROW( sRC, ERR_DBM_SLOT2ADDR_FAIL );

                sCurSlot = sNextSlot;
            }
            else
            {
                break;
            }
        }

        _IF_THROW( sFound == 0, ERR_DBM_NO_MATCH_RECORD );
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_TRC;
        }
        else
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mReadUndoRecord */


/******************************************************************************
 * Name : mReadUndoSlotRecord
 *
 * Description
 *   aLogSlot 하나에 기록된 log 들을 모두 확인하여 aRecordSlotID 와 Row ID 가
 *   같은 Before Image 들 중 최초 Image 를 aData 에 복사해준다.
 *   그리고, aInsertedRowF 가 1 인 것은 신규로 insert 된 Row 인 것이므로
 *   Image 를 읽을 필요가 없는 것이다.
 *
 ******************************************************************************/
_VOID dbmLogManager::mReadUndoSlotRecord ( dbmTransHeader*  aTxHeader,
                                         char*              aLogSlot,
                                         int                aLastOffset,
                                         long long          aRecordSlotID,
                                         char*              aData,
                                         int*               aDataSize,
                                         long long          aMySCN,
                                         int*               aInsertedRowF,
                                         dbmLogType*        aLogType )
{
    dbmLogHeader*   sCurLog;
    char*           sImageSlot;
    dbmRowHeader*   sImageRowHdr = NULL;
    long long       sImageSCN;
    int             sImageRowSize;
    int             sFound = 0;
    int             sRC;
    int             i;

    _TRY
    {
        for ( i = 0; i <= aLastOffset; i++ )
        {
            _IF_THROW( SLOTID ( aTxHeader->mLogCurPos ) == -1, ERR_DBM_NO_MATCH_RECORD );

            sCurLog = (dbmLogHeader*) ( aLogSlot + sizeof(dbmLogSlotHeader) + sizeof(dbmLogHeader) * i );

            /****************************************************
             * valid 한 log 만 읽으면 된다.
             ***************************************************/
            if ( sCurLog->mLogValidF == 1 )
            {
                if( aLogType != NULL )
                {
                    *aLogType = sCurLog->mLogType;
                }

                switch( sCurLog->mLogType )
                {
                case DBM_UPDATE_SLOT_LOG:
                case DBM_UPDATE_KEY_LOG:
                case DBM_DELETE_DATA_LOG:
                case DBM_SELECT_FOR_UPDATE_LOG:
                    if ( sCurLog->mImageLogValidF == 1 )
                    {
                        if ( sCurLog->mRefRecord == aRecordSlotID )
                        {
                            /****************************************************
                             * Row Slot ID 가 같은 것들만 찾아보면 됨.
                             ***************************************************/
//TODO: 2014.11.23 -okt- #486 관련 디버그 정보 추가.
#ifdef _DEBUG
                            if ( SLOTID(sCurLog->mImageLogPos) == -1 )
                            {
                                DBM_ERR( "[FATAL] invalid log, F=%d, Ref=%ld, Pos=%ld (%ld) (err=%d,tid=%d)",
                                         sCurLog->mImageLogValidF, sCurLog->mRefRecord,
                                         sCurLog->mImageLogPos, SLOTID(sCurLog->mImageLogPos),
                                         errno, gettid_s() );
                                _DASSERT( 0 );
                            }
#endif
                            sRC = mUndoSegMgr->Slot2Addr( SLOTID(sCurLog->mImageLogPos), &sImageSlot );
                            _IF_THROW( sRC, ERR_DBM_SLOT2ADDR_FAIL );

                            sImageRowHdr = GETIMG( sImageSlot, OFFSET(sCurLog->mImageLogPos));

                            sImageSCN     = mvpAtomicGet64( &sImageRowHdr->mSCN );
                            sImageRowSize = mvpAtomicGet32( &sImageRowHdr->mRowSize );

                            if ( (sImageSCN <= aMySCN) && (sImageRowHdr->mLock != -1) )
                            {
                                memcpy_s( aData, (char*)sImageRowHdr + sizeof(dbmRowHeader), sImageRowSize );
                                *aDataSize = sImageRowSize;

                                sFound = 1;
                                _RETURN; //_RAISE( IMAGE_FOUND );
                            }
                        }
                    }
                    else
                    {
                        /****************************************************
                         * 이 로그타입에서 image 가 valid 하지 않다는 것은
                         * 로그 남기던 놈이 죽었거나 지금도 기록중이란 얘기다.
                         * 이건 안읽으면 된다.
                         ***************************************************/
                        _THROW( ERR_DBM_NO_MATCH_RECORD );
                    }
                    break;

                case DBM_INSERT_SLOT_LOG:
                    if ( sCurLog->mRefRecord == aRecordSlotID )
                    {
                        /****************************************************
                         * 찾는 aRecordSlotID 가 가리키는 Row 는
                         * 삽입된 Row 라는 것을 알려줌.
                         ***************************************************/
                        *aInsertedRowF = 1;
                        _THROW( ERR_DBM_NO_MATCH_RECORD ); // _RAISE( INSERT_FOUND );
                    }
                    break;
                default:
                    break;
                }
            }
            else
            {
                break;
            }
        } /* for */

        _IF_THROW( sFound == 0, ERR_DBM_NO_MATCH_RECORD );
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_NO_MATCH_RECORD )
        {
            _CATCH_TRC;
        }
        else
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mReadUndoSlotRecord */


/******************************************************************************
 * Name : mFindLockedRecord
 *
 * Description
 *      주어진 Record 가 aTransID 에 Lock 이 잡혀있는지에 대해서 체크한다.
 *
 * Argument
 *     aTransID      : input   : Transaction Log 의 ID
 *     aObjectID     : input   : Object ID
 *     aSlotID       : input   : 검사할 Row 의 Slot ID
 *     aLockedF      : output  : Inserted Row 의 존재 여부.
 *
 ******************************************************************************/
_VOID dbmLogManager::mFindLockedRecord ( int aTransID , int aObjectID , long long aSlotID , int* aLockedF )
{
    dbmLogHeader*       sCurLog   = NULL;
    dbmLogSlotHeader*   sCurSlot  = NULL;
    dbmTransHeader*     sTxH      = NULL;
    long long           sLastPos;
    long long           sCurPos;
    int                 sRC;

    _TRY
    {
        /***********************************************
         * Transaction Header Pointer
         ***********************************************/
        sTxH = (dbmTransHeader*) ( (char*) mUndoSegMgr->GetUserHeader ( ) + sizeof(dbmTransHeader) * aTransID );

        _IF_THROW( SLOTID ( sTxH->mLogStartPos ) == -1
                   || aTransID < 0 || sTxH->mMyTxID < 0, RC_FAILURE ); //, INVALID_TRANS );

        /***********************************************
         * 아무 로그도 없으면 이미 Commit 된 것.
         ***********************************************/
        if ( SLOTID ( sTxH->mLogCurPos ) == -1 )
        {
            *aLockedF = 0;
            _RETURN;
        }

        /***********************************************
         * insert 된 로그 찾기.
         ***********************************************/
        sLastPos = sTxH->mLogCurPos;
        sCurPos = sTxH->mLogStartPos;

        if ( SLOTID ( sLastPos ) < 0 )
        {
            *aLockedF = 0;
            _RETURN;
        }

        while ( 1 )
        {
            /***********************************************
             * 그 사이 commit 이나 rollback.
             ***********************************************/
            if ( ( SLOTID ( sTxH->mLogCurPos ) < 0 ) || ( sLastPos != sTxH->mLogCurPos ) )
            {
                *aLockedF = 0;
                _RETURN;
            }

            sRC = mUndoSegMgr->Slot2Addr ( SLOTID ( sCurPos ), &sCurSlot );
            if ( unlikely( sRC ) ) //, SLOT2ADDR_FAIL );
            {
                DBM_ERR( "slot2addr(%ld) for fail. rc(%d)", sCurSlot, sRC );
                _THROW( sRC );
            }

            sCurLog = GETLOG ( (char*) sCurSlot, OFFSET ( sCurPos ) );

            if ( sCurLog->mLogValidF != 1 )
            {
                /* do nothing */
            }
            else
            {
                if ( sCurLog->mLogType == DBM_LOCK_ROW_LOG )
                {
                    if ( sCurLog->mRefRecord == aSlotID && sCurLog->mObjectID == aObjectID )
                    {
                        _IF_THROW( sTxH->mMyTxID < 0, -1 ); //INVALID_TRANS );

                        *aLockedF = 1;
                        _RETURN;
                    }
                }
            }

            /***********************************************
             * Log 모두 처리 완료.
             ***********************************************/
            if ( ( SLOTID ( sCurPos ) >= SLOTID ( sLastPos ) ) && ( OFFSET ( sCurPos ) >= OFFSET ( sLastPos ) ) )
            {
                break;
            }

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            _CALL( mLogMoveForward ( mUndoSegMgr, sTxH, &sCurPos ) );
            //_IF_RAISE( sRC, INVALID_LOGSLOT_LIST );
        }

        _IF_THROW( sTxH->mMyTxID < 0, -1 ); //INVALID_TRANS );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mFindLockedRecord */


/******************************************************************************
 * Name : mIsInsertedRow
 *
 * Description
 *     aSlotID 가 신규로 aTransID 에 의해 insert 된 것인지를 Log 를 통해 확인.
 *
 * Argument
 *     aTransID      : input   : Transaction Log 의 ID
 *     aSlotID       : input   : 검사할 Row 의 Slot ID
 *     aInsertedRowF : output  : Inserted Row 의 존재 여부.
 *
 ******************************************************************************/
_VOID dbmLogManager::mIsInsertedRow ( int aTransID , long long aSlotID , int* aInsertedRowF )
{
    dbmLogHeader*       sCurLog   = NULL;
    dbmLogSlotHeader*   sCurSlot  = NULL;
    dbmTransHeader*     sTxH      = NULL;
    long long           sLastPos;
    long long           sCurPos;
    int                 sRC;

    _TRY
    {
        /***********************************************
         * Transaction Header Pointer
         ***********************************************/
        sTxH = (dbmTransHeader*) ( (char*) mUndoSegMgr->GetUserHeader ( ) + sizeof(dbmTransHeader) * aTransID );

        //_IF_THROW( SLOTID ( sTxH->mLogStartPos ) == -1
        //           || aTransID < 0 || sTxH->mMyTxID < 0, RC_FAILURE ); //INVALID_TRANS );
        if( SLOTID ( sTxH->mLogStartPos ) == -1
                || aTransID < 0 || sTxH->mMyTxID < 0 )
        {
            DBM_WARN( "invalid trans. mLogStartPos=%d, aTransID=%d, mMyTxID=%d", SLOTID ( sTxH->mLogStartPos ), aTransID, sTxH->mMyTxID );
            _THROW( RC_FAILURE );
        }

        *aInsertedRowF = FALSE;
        /***********************************************
         * 아무 로그도 없으면 이미 Commit 된 것.
         ***********************************************/
        if ( SLOTID ( sTxH->mLogCurPos ) == -1 )
        {
            _RETURN;
        }

        /***********************************************
         * insert 된 로그 찾기.
         ***********************************************/
        sLastPos = sTxH->mLogCurPos;
        sCurPos  = sTxH->mLogStartPos;

        if ( SLOTID ( sLastPos ) < 0 )
        {
            _RETURN;
        }

        while ( 1 )
        {
            /***********************************************
             * 그 사이 commit 이나 rollback.
             ***********************************************/
            if ( ( SLOTID ( sTxH->mLogCurPos ) < 0 ) || ( sLastPos != sTxH->mLogCurPos ) )
            {
                _RETURN;
            }

            sRC = mUndoSegMgr->Slot2Addr ( SLOTID ( sCurPos ), &sCurSlot );
            if ( unlikely( sRC ) ) //, SLOT2ADDR_FAIL );
            {
                DBM_ERR( "slot2addr(%ld) for fail. rc(%d)", sCurSlot, sRC );
                _THROW( sRC );
            }

            sCurLog = GETLOG ( (char*) sCurSlot, OFFSET ( sCurPos ) );

            if ( sCurLog->mLogValidF != 1 )
            {
                /* do nothing */
            }
            else
            {
                if ( sCurLog->mLogType == DBM_INSERT_SLOT_LOG )
                {
                    if ( sCurLog->mRefRecord == aSlotID )
                    {
                        _IF_THROW( sTxH->mMyTxID < 0, -1 ); //INVALID_TRANS );

                        *aInsertedRowF = TRUE;
                        _RETURN;
                    }
                }
            }

            /***********************************************
             * Log 모두 처리 완료.
             ***********************************************/
            if ( ( SLOTID ( sCurPos ) >= SLOTID ( sLastPos ) ) && ( OFFSET ( sCurPos ) >= OFFSET ( sLastPos ) ) )
            {
                break;
            }

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            _CALL( mLogMoveForward ( mUndoSegMgr, sTxH, &sCurPos ) );
            //_IF_RAISE( sRC, INVALID_LOGSLOT_LIST );
        }

        _IF_THROW( sTxH->mMyTxID < 0, -1 ); //INVALID_TRANS );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mIsInsertedRow */


/******************************************************************************
 * Name : mExistEnqueToSameQueue
 *
 * Description
 *     transaction 내에서 특정 큐에 대한 enque 로그가 있는지를 검사.
 *
 * Argument
 *     aTransID     : input   : Transaction Log 의 ID
 *     aTableID     : input   : 검사할 Table 의 ID
 *     aExistF      : output  : 존재 여부.
 *
 ******************************************************************************/
_VOID dbmLogManager::mExistEnqueLog ( int aTransID , int aTableID , int* aExistF )
{
    dbmLogHeader*       sCurLog   = NULL;
    dbmLogSlotHeader*   sCurSlot  = NULL;
    dbmTransHeader*     sTxH      = NULL;
    long long           sLastPos;
    long long           sCurPos;
    int                 sRC;

    _TRY
    {
        /***********************************************
         * Transaction Header Pointer
         ***********************************************/
        sTxH = (dbmTransHeader*) ( (char*) mUndoSegMgr->GetUserHeader ( ) + sizeof(dbmTransHeader) * aTransID );

        _IF_THROW( SLOTID ( sTxH->mLogStartPos ) == -1 || aTransID < 0, RC_FAILURE ); //INVALID_TRANS );

        /***********************************************
         * 아무 로그도 없으면 OK
         ***********************************************/
        if ( SLOTID ( sTxH->mLogCurPos ) == -1 )
        {
            *aExistF = 0;
            return RC_SUCCESS;
        }

        /***********************************************
         * insert 된 로그 찾기.
         ***********************************************/
        sLastPos = sTxH->mLogCurPos;
        sCurPos = sTxH->mLogStartPos;

        while ( 1 )
        {
            /***********************************************
             * 그 사이 commit 이나 rollback.
             ***********************************************/
            if ( SLOTID ( sTxH->mLogCurPos ) < 0 )
            {
                *aExistF = 0;
                return RC_SUCCESS;
            }

            sRC = mUndoSegMgr->Slot2Addr ( SLOTID ( sCurPos ), &sCurSlot );
            if ( unlikely( sRC ) ) //, SLOT2ADDR_FAIL );
            {
                DBM_ERR( "slot2addr(%ld) for fail. rc(%d)", sCurSlot, sRC );
                _THROW( sRC );
            }

            sCurLog = GETLOG ( (char*) sCurSlot, OFFSET ( sCurPos ) );

            if ( sCurLog->mLogValidF != 1 )
            {
                /* do nothing */
            }
            else
            {
                if ( sCurLog->mLogType == DBM_ENQUE_LOG )
                {
                    if ( sCurLog->mObjectID == aTableID )
                    {
                        *aExistF = 1;
                        _RETURN;
                    }
                }
            }

            /***********************************************
             * Log 모두 처리 완료.
             ***********************************************/
            if ( ( SLOTID ( sCurPos ) >= SLOTID ( sLastPos ) ) && ( OFFSET ( sCurPos ) >= OFFSET ( sLastPos ) ) )
            {
                break;
            }

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            _CALL( mLogMoveForward ( mUndoSegMgr, sTxH, &sCurPos ) );
            //_IF_RAISE( sRC, INVALID_LOGSLOT_LIST );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mExistEnqueLog */


/******************************************************************************
 * Name : mFreeAllSlotList
 *
 * Description
 *     특정 Tranaction 에 할당되어 있는 모든 Slot 들을 반납한다.
 *
 * Argument
 *     aRecoverFlag  : input   : Flag for notifying that this func was called for recovery
 *     aUndoSegMgr   : input   : segment manager
 *     aHeader       : input   : transaction header
 *
 ******************************************************************************/
_VOID dbmLogManager::mFreeAllSlotList ( int aRecoverFlag , dbmSegmentManager* aUndoSegMgr , dbmTransHeader* aHeader )
{
    dbmLogSlotHeader*   sStartSlot  = NULL;
    int                 sRC;

    _TRY
    {
        /***********************************************
         * 할당된 Slot 없음.
         ***********************************************/
        if ( aHeader->mLastAllocLogSlot < 0 )
        {
            _RETURN;
        }

        /***********************************************
         * Log Slot List 해제
         ***********************************************/
        sRC = aUndoSegMgr->Slot2Addr ( SLOTID ( aHeader->mLogStartPos ), &sStartSlot );
        if ( sRC ) // || sStartSlot == NULL )
        {
            _RETURN;
        }

        if ( aRecoverFlag == 1 )
        {
            if ( sStartSlot->mNext < 0 )
            {
                /***********************************************
                 * 첫 slot 하나만 있을 경우
                 ***********************************************/
                _CALL( dbmSegFreeSlot ( aUndoSegMgr, SLOTID ( aHeader->mLogStartPos ), 1 ) );
            }
            else
            {
                _CALL( dbmLogManager::mFreeSlotList ( 1, aUndoSegMgr, sStartSlot ) );
            }
        }
        else
        {
            if ( sStartSlot->mNext < 0 )
            {
                _CALL( dbmSegFreeSlot ( aUndoSegMgr, SLOTID ( aHeader->mLogStartPos ), 0 ) );
            }
            else
            {
                _CALL( dbmLogManager::mFreeSlotList ( 0, aUndoSegMgr, sStartSlot ) );
            }
        }


        /***********************************************
         * Image Slot List 해제
         ***********************************************/
        sStartSlot = NULL;
        sRC = aUndoSegMgr->Slot2Addr ( SLOTID ( aHeader->mImageStartPos ), &sStartSlot );
        if ( sRC ) // || sStartSlot == NULL )
        {
            _RETURN;
        }

        /***********************************************
         * 첫 slot 하나만 있을 경우
         ***********************************************/
        if ( aRecoverFlag == 1 )
        {
            if ( sStartSlot->mNext < 0 )
            {
                _CALL( dbmSegFreeSlot ( aUndoSegMgr, SLOTID ( aHeader->mImageStartPos ), 1 ) );
            }
            else
            {
                _CALL( dbmLogManager::mFreeSlotList ( 1, aUndoSegMgr, sStartSlot ) );
            }
        }
        else
        {
            if ( sStartSlot->mNext < 0 )
            {
                _CALL( dbmSegFreeSlot ( aUndoSegMgr, SLOTID ( aHeader->mImageStartPos ), 0 ) );
            }
            else
            {
                _CALL( dbmLogManager::mFreeSlotList ( 0, aUndoSegMgr, sStartSlot ) );
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mFreeAllSlotList */


_VOID dbmLogManager::mFreeSlotList( int                aRecoveryFlag,
                                    dbmSegmentManager* aUndoSegMgr,
                                    dbmLogSlotHeader*  aStartSlot )
{
    dbmLogSlotHeader*   sCurSlot    = NULL;
    dbmLogSlotHeader*   sNextSlot   = NULL;
    dbmLogSlotHeader*   sBeforeSlot = NULL;
    int                 sRC;

    _TRY
    {
        sCurSlot = aStartSlot;

        while ( 1 )
        {
            if ( sCurSlot->mNext >= 0 )
            {
                /***********************************************
                 * 끝이 아닐 경우 다음 slot 으로 이동
                 ***********************************************/
                sRC = aUndoSegMgr->Slot2Addr ( sCurSlot->mNext, &sNextSlot );
                if ( sRC ) // || sNextSlot == NULL )
                {
                    _RETURN;
                }

                sBeforeSlot = sCurSlot;
                sCurSlot = sNextSlot;

                /***********************************************
                 * Log Slot Header 의 mPrev 를 설정해가면서 이동함.
                 ***********************************************/
                sCurSlot->mPrev = sBeforeSlot->mMySlotID;
            }
            else
            {
next:
                if ( sCurSlot != aStartSlot )
                {
                    /***********************************************
                     * 여기에서부터 역으로 Start Slot 까지 Free 해
                     * 나가면 된다.
                     ***********************************************/
                    if ( aRecoveryFlag == 1 )
                    {
                        _CALL( dbmSegFreeSlot ( aUndoSegMgr, sCurSlot->mMySlotID, 1 ) );
                    }
                    else
                    {
                        _CALL( dbmSegFreeSlot ( aUndoSegMgr, sCurSlot->mMySlotID, 0 ) );
                    }

                    sRC = aUndoSegMgr->Slot2Addr ( sCurSlot->mPrev, &sBeforeSlot );
                    if ( sRC ) //|| sBeforeSlot == NULL )
                    {
                        _RETURN;
                    }

                    sBeforeSlot->mNext = -1;
                    sCurSlot->mPrev = -1;

                    sCurSlot = sBeforeSlot;
                    goto next;
                }
#if 0 // 2014.04.09 -shw- startSlot free 하기 위하여 막음.
                else
                {
                    break;
                }
#endif

                if ( aRecoveryFlag == 1 )
                {
                    _CALL( dbmSegFreeSlot ( aUndoSegMgr, sCurSlot->mMySlotID, 1 ) );
                }
                else
                {
                    _CALL( dbmSegFreeSlot ( aUndoSegMgr, sCurSlot->mMySlotID, 0 ) );
                }
                break;
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mFreeSlotList */


/******************************************************************************
 * Name : mLogMoveForward
 *
 * Description
 *     다음 로그 위치를 찾음. (순방향)
 *
 ******************************************************************************/
int dbmLogManager::mLogMoveForward ( dbmSegmentManager* aSegMgr , dbmTransHeader* aTxH , long long* aCurPos )
{
    dbmLogSlotHeader*   sCurSlotPtr;
    //int                 sOffset;
    long long             sCurPos = *aCurPos;
    long long             sCurSlot;

    _TRY
    {
        if ( ( OFFSET ( *aCurPos ) + 1 ) >= aTxH->mLogCntPerSlot )
        {
            /***********************************************
             * 다음 Slot 으로 이동.
             * 아직 Log 끝이 아닌데 다음 slot 연결이 안되어
             * 있으면 에러.
             ***********************************************/
            sCurSlot = SLOTID ( *aCurPos );

            _CALL( aSegMgr->Slot2Addr ( sCurSlot, &sCurSlotPtr ) );
            //_IF_RAISE( sRC || sCurSlotPtr == NULL, SLOT2ADDR_FAIL );

            if ( unlikely( sCurSlotPtr->mNext == -1 ) ) //, INVALID_LOGSLOT_LIST );
            {
                if ( aTxH->mMyTxID >= 0 )
                {
                    DBM_ERR( "invalid log slot list. TxID[%d] curPos[%d:%d] txCurPos[%d:%d] slot_log_count[%d] nextslot[%ld]",
                                    aTxH->mMyTxID,
                                    SLOTID(*aCurPos),
                                    OFFSET(*aCurPos),
                                    SLOTID(aTxH->mLogCurPos),
                                    OFFSET(aTxH->mLogCurPos),
                                    aTxH->mLogCntPerSlot,
                                    sCurSlotPtr->mNext );
                }
                _THROW( ERR_DBM_INVALID_LOG );
            }

            *aCurPos = MK_POS ( sCurSlotPtr->mNext, 0 );
        }
        else
        {
            /***********************************************
             * 현재 page 에 기록된 Log 가 아직 남아있음.
             * 다음 Log 로 이동.
             ***********************************************/
            //sOffset  = OFFSET(*aCurPos);
            //*aCurPos = MK_POS( SLOTID(*aCurPos), ++sOffset );
            *aCurPos = sCurPos + 1;
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mLogMoveForward */


/******************************************************************************
 * Name : mLogMoveBackward
 *
 * Description
 *     다음 로그 위치를 찾음. (역방향)
 *
 ******************************************************************************/
_VOID dbmLogManager::mLogMoveBackward ( dbmSegmentManager* aSegMgr , dbmTransHeader* aTxH , long long* aCurPos )
{
    dbmLogSlotHeader*   sCurSlotPtr;
    int                 sOffset;
    long long           sCurSlot;

    _TRY
    {
        if ( OFFSET(*aCurPos) == 0 )
        {
            /***********************************************
             * 다음 slot 으로 이동.
             * 아직 Log 끝이 아닌데 다음 slot 연결이 안되어
             * 있으면 에러.
             ***********************************************/
            sCurSlot = SLOTID(*aCurPos);

            _CALL( aSegMgr->Slot2Addr(sCurSlot, &sCurSlotPtr) );

            if ( unlikely( sCurSlotPtr->mPrev == -1 ) ) //, INVALID_LOGSLOT_LIST );
            {
                DBM_ERR( "invalid log slot list. TxID[%d] curPos[%d:%d] txCurPos[%d:%d] slot_log_count[%d] nextslot[%ld]",
                                aTxH->mMyTxID,
                                SLOTID(*aCurPos),
                                OFFSET(*aCurPos),
                                SLOTID(aTxH->mLogCurPos),
                                OFFSET(aTxH->mLogCurPos),
                                aTxH->mLogCntPerSlot,
                                sCurSlotPtr->mNext );
                _THROW( ERR_DBM_INVALID_LOG );
            }

            *aCurPos = MK_POS( sCurSlotPtr->mPrev, (aTxH->mLogCntPerSlot - 1));
        }
        else
        {
            /***********************************************
             * 현재 page 에 기록된 Log 가 아직 남아있음.
             * 다음 Log 로 이동.
             ***********************************************/
            sOffset  = OFFSET(*aCurPos);
            --sOffset;
            *aCurPos = MK_POS( SLOTID(*aCurPos), sOffset );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mLogMoveBackward */


_VOID dbmLogManager::mDumpLog ( char* aLog )
{
    dbmLogHeader* sLog = (dbmLogHeader*) aLog;

    DBM_ERR( "[%d:%ld:%ld:%d:%d:(%s,%s):%ld:%ld:%d:%ld:%d:%d:%d:%d]",
             sLog->mLogType, sLog->mMyLogPos, sLog->mSCN, sLog->mTransID, sLog->mObjectID,
             sLog->mObjectName, sLog->mTableName, sLog->mRefRecord, sLog->mImageLogPos, sLog->mImageSize,
             sLog->mLSN, sLog->mLogValidF, sLog->mImageLogValidF, sLog->mCommitCompleteF, sLog->mRollbackCompleteF );

    return 0;
}


_VOID dbmLogManager::mDumpLog ( char* aLogHeader , long long aLogPos )
{
    dbmLogHeader*   sLogH = (dbmLogHeader*)aLogHeader;
    long long       sLogPos = aLogPos;

    DBM_ECHO( "Log Position [%ld:%ld]", SLOTID ( sLogPos ), OFFSET ( sLogPos ) );
    DBM_ECHO( "  Log Type          [%s]", dbmLogTypeStr[sLogH->mLogType] );
    DBM_ECHO( "  My Log Pos        [%ld:%ld]", SLOTID ( sLogH->mMyLogPos ), OFFSET ( sLogH->mMyLogPos ) );
    DBM_ECHO( "  SCN               [%ld]", sLogH->mSCN );
    DBM_ECHO( "  Trans ID          [%d]", sLogH->mTransID );
    DBM_ECHO( "  Object ID         [%d]", sLogH->mObjectID );
    DBM_ECHO( "  Object Name       [%s]", sLogH->mObjectName );
    DBM_ECHO( "  Table Name        [%s]", sLogH->mTableName );
    DBM_ECHO( "  Ref Record        [%ld]", sLogH->mRefRecord );
    DBM_ECHO( "  Image LogPos      [%ld:%ld]", SLOTID ( sLogH->mImageLogPos ), OFFSET ( sLogH->mImageLogPos ) );
    DBM_ECHO( "  Image Size        [%d]", sLogH->mImageSize );
    DBM_ECHO( "  LSN               [%ld]", sLogH->mLSN );
    DBM_ECHO( "  Log ValidF        [%d]", sLogH->mLogValidF );
    DBM_ECHO( "  Image ValidF      [%d]", sLogH->mImageLogValidF );
    DBM_ECHO( "  Commit CompleteF  [%d]", sLogH->mCommitCompleteF );
    DBM_ECHO( "  Rollback CompleteF[%d]", sLogH->mRollbackCompleteF );


    return 0;
}
