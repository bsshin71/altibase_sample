/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/******************************************************************************
 * $Id$*
 * Description :
 ******************************************************************************/
#include "dbmHeader.h"
#include "dbmRecoveryManager.h"
#include "dbmQueueRecoveryHandler.h"

char dbmTxStr[][32] =
{
    "DBM_TX_FREE"
  , "DBM_TX_ALLOC"
  , "DBM_TX_LOG_WAIT"
  , "DBM_TX_LOGGING"
  , "DBM_TX_COMMIT"
  , "DBM_TX_ROLLBACK"
};


_VOID dbmRecoveryManager::mRollbackRecovery ( char* aInstName , int aTxID )
{
    dbmSegmentManager*  sUndoSegMgr  = NULL;
    int                 sRC;

    _TRY
    {
        sRC = dbmSegmentManager::Attach ( aInstName, aInstName, &sUndoSegMgr );
        if ( unlikely( sRC ) ) //, ATTACH_UNDOSEG_FAIL );
        {
            DBM_ERR( "attach inst(%s) seg fail. rc(%d)", aInstName, sRC );
            _THROW( sRC );
        }

        _CALL( dbmRecoveryManager::mRollbackRecovery ( aInstName, sUndoSegMgr, aTxID ) );

#ifndef USE_NEW_SHM_NODETACH
        sUndoSegMgr->Detach();
#endif
        delete_s( sUndoSegMgr );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mRollbackRecovery */


_VOID dbmRecoveryManager::mRollbackRecovery ( char* aInstName , dbmSegmentManager* aUndoSegMgr , int aTxID )
{
    long long           sCurPos;
    int                 sRowSize;
    char*               sImage       = NULL;
    dbmLogHeader*       sCurLog      = NULL;
    dbmRowHeader*       sRefRow      = NULL;
    dbmListSlotHeader*  sListRow     = NULL;
    dbmTransHeader*     sTxH         = NULL;
    dbmTransTable*      sTxTable     = NULL;
    dbmSegmentManager*  sSegMgr      = NULL;
    dbmSegmentManager*  sSegMgr1     = NULL;
    dbmSegmentManager*  sIdxSegMgr   = NULL;
    dbmTableInfo*       sTableInfo   = NULL;
    dbmTableHeader*     sTableHeader = NULL;
    dbmQueueHeader*     sQueueHeader = NULL;
    dbmListHeader*      sListHeader  = NULL;
    dbmIndexHeader*     sIndexHeader = NULL;
    int                 sFirstDeq = 0;
    int                 sFirstEnq = 0;
    dbmLogAnchor        *sLogAnchor;
    int                 sRC;
    unsigned long long  i;

    _TRY
    {
        /***********************************************
         * Trans Header 구하기
         ***********************************************/
        sTxTable = (dbmTransTable*)aUndoSegMgr->GetUserHeader();
        sTxH     = (dbmTransHeader*)dbmRecoveryManager::mGetTxHead( sTxTable, aTxID );
        sLogAnchor = &((dbmUndoHeader*)(aUndoSegMgr->GetUserHeader() + sizeof (dbmTransTable)))->mAnchor ;

        DBM_WARN( "mRollbackRecovery Start.. force rollback. txid[%d] pid[%d]", aTxID, sTxH->mPID );


        /***********************************************
         * 아무 로그도 없으면 할 일 없음.
         ***********************************************/
        if ( SLOTID(sTxH->mLogCurPos) == -1 )
        {
            sTxH->mRecoveryStartPos = MK_POS(-1,-1);
            sTxH->mImageCurPos      = MK_POS(-1,-1);

            DBM_WARN ( " mRollbackRecovery SLOTID(sTxH->mLogCurPos) failure.[%d]\n", sTxH->mLogCurPos );

            goto UNLOCK_ROW;
        }
        if ( SLOTID(sTxH->mLogStartPos) == -1 ) //, NO_TRANS_LOG );
            _RETURN;

        sTxH->mStatus = DBM_TX_ROLLBACK;


        /***********************************************
         * 로그 Slot 들에 대해 역으로 List 로 연결해줌.
         * 평상 시에는 성능 상 dbmLogSlotHeader 의 mNext 만 연결.
         ***********************************************/
        sRC = dbmRecoveryManager::mLinkReverseList( aUndoSegMgr, sTxH, -1 );
        if ( sRC ) //, LINK_REVERSE_FAIL );
        {
            dbmRecoveryManager::mDumpTxHeader( (char*)sTxH );
            _THROW( ERR_DBM_INVALID_LOG );
        }


        /************************************************
         * 만약 Disk Logging 인 상태이고, 해당 Disk 의 마지막 로그에 Commit 로그가 있다면
         * Rollback 할 게 없다.
         ***********************************************/
        sRC = mCheckRollbackWithDisk ( sTxH, aTxID,  sLogAnchor ) ;
        if ( sRC == RC_SUCCESS )
        {
            sTxH->mRecoveryStartPos = MK_POS(-1,-1);
            sTxH->mImageCurPos      = MK_POS(-1,-1);

            DBM_WARN ( " mRollbackRecovery mCheckRollbackWithDisk failure.[%d]\n", sRC );

            goto UNLOCK_ROW;
        }


        /***********************************************
         * 마지막 로그로 이동
         * 만약 mRecoveryStartPos 이 설정되어 있고, 이 위치가
         * CurPos 보다 작은 지점이라면 mRecoveryStartPos 부터
         * Rollback 을 시작해야 한다.
         * (Insert Key Log 기록 후 바로 Down 되는 case 등 때문에)
         ***********************************************/
        if ( (SLOTID(sTxH->mRecoveryStartPos) >= 0)
         && (sTxH->mRecoveryStartPos < sTxH->mLogCurPos) )
        {
            sCurPos = sTxH->mRecoveryStartPos;
        }
        else
        {
            sCurPos = sTxH->mLogCurPos;
        }


        /***********************************************
         * 모든 Log 를 차례로 방문하여 Log Type 별로
         * Rollback 작업 수행
         ***********************************************/
        while ( 1 )
        {
            sRefRow    = NULL;
            sCurLog    = NULL;
            sImage     = NULL;
            sSegMgr    = NULL;
            sIdxSegMgr = NULL;
            sTableInfo = NULL;
            sTableHeader = NULL;
            sQueueHeader = NULL;
            sIndexHeader = NULL;

            sRC = dbmRecoveryManager::mGetLogPtr ( aUndoSegMgr, sCurPos, &sCurLog );
            _IF_RAISE2( sRC, INVALID_LOG );

            #if 0
            dbmLogManager::mDumpLog( (char*)sCurLog, sCurPos );
            #endif

            if ( (sCurLog->mRollbackCompleteF == 1)
             || (sCurLog->mLogValidF != 1) )
            {
                /* do nothing */
            }
            else
            {
                DBM_WARN( "Recovery log type [%ld:%ld] [%s] [%s] [%lld]", 
                                            SLOTID ( sCurPos ), OFFSET ( sCurPos)
                                            , LogType2Str(sCurLog->mLogType)
                                            , sCurLog->mObjectName
                                            , sCurLog->mRefRecord
                        );
                switch( sCurLog->mLogType )
                {
                    case DBM_ALLOC_SLOT_LOG:
                    case DBM_ALLOC_IDX_SLOT_LOG:
                        /***********************************************
                         * 할당한 slot 을 free 한다.
                         ***********************************************/
                        _CALL( dbmSegmentManager::Attach( aInstName, sCurLog->mObjectName, &sSegMgr ) );
                        _DASSERT( sSegMgr != NULL );
                        //_IF_THROW( sRC || sSegMgr == NULL, ERR_DBM_SEGMENT_ATTACH_FAIL ); //SEG_ATTACH_FAIL );

                        sRC = dbmSegFreeSlot( sSegMgr, sCurLog->mRefRecord, 1 );

    #ifndef USE_NEW_SHM_NODETACH
                        sSegMgr->Detach();
    #endif
                        delete_s( sSegMgr );
                        break;

                    case DBM_INSERT_SLOT_LOG:
                        /***********************************************
                         * insert 한 row 를 초기화해버린다.
                         ***********************************************/
                        _CALL( dbmSegmentManager::Attach( aInstName, sCurLog->mObjectName, &sSegMgr ) );
                        _DASSERT( sSegMgr != NULL );
                        //_IF_THROW( sRC || sSegMgr == NULL, ERR_DBM_SEGMENT_ATTACH_FAIL ); //SEG_ATTACH_FAIL );

                        sRC = sSegMgr->Slot2Addr( sCurLog->mRefRecord, &sRefRow );
                        _IF_RAISE2( sRC, INVALID_LOG );

                        sRowSize = sRefRow->mRowSize;

                        // 2014.12.14. -okt- 2014/07/04 direct 테이블은 -1 이 올수 있다.
                        if ( sRowSize > 0 )
                        {
                            memset_s ( (char*) sRefRow + sizeof(dbmRowHeader), 0x00, sRowSize );
                        }

                        sRefRow->mSCN     = 0;
                        sRefRow->mRowSize = 0;

    #ifndef USE_NEW_SHM_NODETACH
                        sSegMgr->Detach();
    #endif
                        delete_s( sSegMgr );
                        break;

                    case DBM_ENQUE_LOG:
                        break;
                    case DBM_DEQUE_LOG:
                        /***********************************************
                         * 나머지 로그를 쭈욱 돌면서 Deque 했던 것을 한꺼번에
                         * enque 해버린다.
                         * sCurLog->mQueProcDone 이 셋팅된 것, 즉 Indicator를
                         * 감소시킨 것이 확실한 것만 enque 하면 된다.
                         ***********************************************/
                        if ( sFirstDeq == 0 )
                        {
                            _CALL( dbmRecoveryManager::mRollbackDequeAll( aInstName,
                                                                         sTxH,
                                                                         sCurPos,
                                                                         sTxH->mLogStartPos,
                                                                         aUndoSegMgr ) );
                            //_IF_RAISE( sRC, ROLLBACK_DEQUE_FAIL );

                            sFirstDeq = 1;
                        }
                        break;

                    case DBM_DELETE_DATA_LOG:
                    case DBM_UPDATE_SLOT_LOG:
                    case DBM_UPDATE_KEY_LOG:
                    case DBM_SELECT_FOR_UPDATE_LOG:
                        /***********************************************
                         * Image Log 를 통해 Row Image 를 복구한다.
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _RAISE2( INVALID_LOG );
                            }
                        }

                        _CALL( dbmSegmentManager::Attach ( aInstName, sCurLog->mObjectName, &sSegMgr ) );
                        _DASSERT( sSegMgr != NULL );
                        //_IF_TRHOW( sRC || sSegMgr == NULL, ERR_DBM_SEGMENT_ATTACH_FAIL ); SEG_ATTACH_FAIL );

                        sRC = sSegMgr->Slot2Addr ( sCurLog->mRefRecord, &sRefRow );
                        _IF_RAISE2( sRC, INVALID_LOG );

                        sRC = dbmRecoveryManager::mGetImagePtr ( aUndoSegMgr, sCurLog->mImageLogPos, &sImage );
                        _IF_RAISE2( sRC, INVALID_LOG );

                        sRowSize = ( (dbmRowHeader *) sImage )->mRowSize;

                        //memset_s ( (char*)sRefRow + sizeof(dbmRowHeader), 0x00, sRowSize );
                        memcpy_s ( sRefRow, sImage, sRowSize + sizeof(dbmRowHeader) );

#ifndef USE_NEW_SHM_NODETACH
                        sSegMgr->Detach();
#endif
                        delete_s( sSegMgr );
                        break;

                    case DBM_LIST_LPUSH_LOG:
                    case DBM_LIST_RPUSH_LOG:
                        /***********************************************
                         * insert 한 row 를 초기화해버린다.
                         ***********************************************/
                        _CALL( dbmSegmentManager::AttachList( aInstName, sCurLog->mObjectName, &sSegMgr ) );
                        _DASSERT( sSegMgr != NULL );

                        sRC = sSegMgr->ListSlot2Addr( sCurLog->mRefRecord, &sListRow );
                        _IF_RAISE2(sRC || sListRow == NULL, INVALID_LOG );

                        sRowSize = sListRow->mRowSize;

                        if ( sRowSize > 0 )
                        {
                            memset_s ( (char*) sListRow + sizeof(dbmListSlotHeader), 0x00, sRowSize );
                        }

                        sListRow->mSCN     = 0;
                        sListRow->mRowSize = 0;

#ifndef USE_NEW_SHM_NODETACH
                        sSegMgr->Detach();
#endif
                        delete_s( sSegMgr );
                        break;

                    case DBM_LIST_LPOP_LOG:
                    case DBM_LIST_RPOP_LOG:

                        if( sCurLog->mImageLogValidF != 1 )
                        {
                            if( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _RAISE2( INVALID_LOG );
                            }
                        }

                        _CALL( dbmSegmentManager::AttachList( aInstName, sCurLog->mObjectName, &sSegMgr ) );
                        _DASSERT( sSegMgr != NULL );

                        sRC = sSegMgr->Slot2Addr( sCurLog->mRefRecord, &sListRow );
                        _IF_RAISE2( sRC || sListRow == NULL, INVALID_LOG );

                        sRC = dbmRecoveryManager::mGetImagePtr( aUndoSegMgr, sCurLog->mImageLogPos, (char**)&sImage );
                        _IF_RAISE2( sRC || sImage == NULL, INVALID_LOG );

                        sRowSize = ((dbmListSlotHeader*)sImage)->mRowSize;

                        //memset_s( (char*)sListRow + sizeof(dbmListSlotHeader), 0x00, sRowSize );
                        memcpy_s( sListRow, sImage, sRowSize + sizeof(dbmListSlotHeader) );

#ifndef USE_NEW_SHM_NODETACH
                        sSegMgr->Detach();
#endif
                        delete_s( sSegMgr );

                        break;

                    case DBM_INSERT_INDEX_LOG:
                    case DBM_INSERT_INDEX_LOG2:
                        /***********************************************
                         * ImageLog 에 저장된 key 를 이용하여 Delete Key를 수행.
                         * Insert Index Log 의 Image Log 에는 Key 값만 들어있다.
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _RAISE2( INVALID_LOG );
                            }
                        }

                        sRC = dbmRecoveryManager::mGetImagePtr ( aUndoSegMgr, sCurLog->mImageLogPos, &sImage );
                        _IF_RAISE2( sRC, INVALID_LOG );

                        if( sCurLog->mLogType == DBM_INSERT_INDEX_LOG )
                        {
                        sRC = dbmIndexManager::mDeleteKey ( aInstName,
                                                            sCurLog->mTransID,
                                                            sCurLog->mObjectName,
                                                            sImage );
                        //DBM_WARN( "mDeleteKey sRC=[%d], aInstName=[%s], mTransID=[%lld], mObjectName=[%s]",
                        //        sRC, aInstName, sCurLog->mTransID, sCurLog->mObjectName);
                        // 빼는게 맞는건가 모르겠다.
                        //_IF_RAISE2( sRC, INVALID_LOG );
                        }
                        else
                        {
                        sRC = dbmIndexManager::mDeleteKey ( aInstName,
                                                            sCurLog->mTransID,
                                                            sCurLog->mObjectName,
                                                            sImage,
                                                            1 );
                        }
                        if (sRC)
                        {
                            DBM_ERR ("insertKey rollback fail rc=%d, table=%s, index=%s, ref=%lld\n"
                                    , sRC, sCurLog->mTableName, sCurLog->mObjectName, sCurLog->mRefRecord);
                            /* 빼는게 맞는 건가 모르겠다 */
                            //_IF_RAISE2( sRC, INVALID_LOG );
                        }

                        break;

                    case DBM_DELETE_INDEX_LOG:
                    case DBM_DELETE_INDEX_LOG2:
                    case DBM_DELETE_INDEX_LOG3:
                    case DBM_DELETE_INDEX_LOG4:
                        /***********************************************
                         * image log 에 저장된 key 를 이용하여 Insert Key를
                         * 수행한다. 마지막 로그가 아니고 중간로그인데
                         * Image 가 valid 하지 않으면 에러다.
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                DBM_ERR( "image log is not valid. logpos[%ld]", sCurPos );
                                _RAISE2( INVALID_LOG );
                            }
                        }

                        /* 2014.07.01 -shw- mDelete 처리에서만 위의 로깅을 하는데 실제 commit
                         * 시점에서 insert 처리 하므로 아래의 처리는 필요 없는 것으로 보여 주석으로
                         * 막는다 */
                        if ( sCurLog->mCommitCompleteF == 1             ||
                             sCurLog->mLogType == DBM_DELETE_INDEX_LOG3 ||
                             sCurLog->mLogType == DBM_DELETE_INDEX_LOG4   )
                        {
                            /***********************************************
                             * Delete Index Log 의 Image Log 에는 Key 값만 들어있다.
                             ***********************************************/
                            sRC = dbmRecoveryManager::mGetImagePtr ( aUndoSegMgr, sCurLog->mImageLogPos, &sImage );
                            _IF_RAISE2( sRC, INVALID_LOG );

                            sRC = dbmIndexManager::mInsertKey( aInstName,
                                                               sCurLog->mRefRecord,
                                                               sCurLog->mTransID,
                                                               sCurLog->mObjectName,
                                                               sImage );
                            if ( sRC ) //, INSERT_KEY_FAIL );
                            {
                                DBM_ERR ("deleteKey Rollback Fail rc=%d, table=%s, index=%s, Slot=%lld\n"
                                        , sRC, sCurLog->mTableName, sCurLog->mObjectName, sCurLog->mRefRecord);
                                /* 빼는게 맞는 건가 모르겠다 */
                                //_IF_RAISE2( sRC, INVALID_LOG );
                            }
                        }

                        break;

                    case DBM_DDL_CREATE_TABLE_LOG:
                    case DBM_DDL_CREATE_QUEUE_LOG:
                    case DBM_DDL_CREATE_LIST_LOG:
                    case DBM_DDL_DROP_TABLE_LOG:
                        /***********************************************
                         * 1. Segment 를 Drop
                         *    index segment 부터 Drop 한다.
                         * 2. Dictionary 에서 삭제
                         *    Prepare 되었을 리는 없으므로 Unprepare 과정은 불필요.
                         ***********************************************/
                        sRC = dbmSegmentManager::Attach( aInstName, sCurLog->mObjectName, &sSegMgr );
                        if ( sRC == 0 )
                        {
                            sTableInfo = (dbmTableInfo *)(sSegMgr->GetUserHeader() );

                            if ( sTableInfo->mTable.mTableType == DBM_TBL_QUEUE )
                            {
                                sQueueHeader = (dbmQueueHeader*)sTableInfo;
                                sQueueHeader->mTableObj.mTableID = -1;
                            }
                            else
                            {
                                sTableHeader = (dbmTableHeader*)sTableInfo;
                                sTableHeader->mTableObj.mTableID = -1;
                            }

                            for( i=0; i<sTableInfo->mIndexCount; i++ )
                            {
                                sRC = dbmSegmentManager::Attach( aInstName,
                                                                 sTableInfo->mIndex[i].mIndexName,
                                                                 &sSegMgr1 );
                                if ( sRC == 0 )
                                {
                                    sRC = sSegMgr1->Drop();
                                    delete_s( sSegMgr1 );
                                }
                            }

                            sRC = sSegMgr->Drop();
                            delete_s( sSegMgr );
                        }

                        /*
                         * Dictionary 는 자체 복구로 가자.
                         * 의존성때문에 안되겠다.
                        sTableInfo = &sDicObject.mObj.mTableInfo;

                        sDicObject.mSQLType = DBM_DROP_TABLE;
                        strncpy( sTableInfo->mTable.mInstanceName, aInstName, DBM_NAME_LEN );
                        strncpy( sTableInfo->mTable.mTableName, sCurLog->mObjectName, DBM_NAME_LEN );

                        sRC = aDicMgr->mDelete( &sDicObject );
                        */
                        break;

                    case DBM_DDL_CREATE_INDEX_LOG:
                    case DBM_DDL_DROP_INDEX_LOG:
                        /***********************************************
                         * Index 의 흔적을 깔끔히 없애는게 목적.
                         *   1. Segment 를 Drop
                         *   2. Dictionary 에서 삭제
                         *   3. update table header
                         ***********************************************/
                        sRC = dbmSegmentManager::Attach( aInstName, sCurLog->mObjectName, &sSegMgr );
                        if ( sRC == 0 )
                        {
                            sRC = sSegMgr->Drop();
                            delete_s( sSegMgr );
                        }

                        /*
                         * Dictionary 는 자체 알아서 복구로 간다.
                        sDicObject.mSQLType = DBM_DROP_INDEX;
                        strncpy( sDicObject.mObj.mIndex.mInstanceName,
                                 aInstName,
                                 DBM_NAME_LEN );
                        strncpy( sDicObject.mObj.mIndex.mIndexName,
                                 sCurLog->mObjectName,
                                 DBM_NAME_LEN );

                        sRC = aDicMgr->mDelete( &sDicObject );
                        */

                        sRC = dbmRecoveryManager::mDropIndexFromTableHeader( aInstName,
                                                                             sCurLog->mTableName,
                                                                             sCurLog->mObjectName );
                        break;

                    case DBM_DDL_CREATE_TRIG_LOG:
                    case DBM_DDL_DROP_TRIG_LOG:
                        sRC = dbmSegmentManager::Attach( aInstName,
                                                         sCurLog->mTableName,
                                                         &sSegMgr );
                        if ( sRC == 0 )
                        {
                            sTableHeader = (dbmTableHeader*)sSegMgr->GetUserHeader();
                            memset_s( &sTableHeader->mEventQueue, 0x00, DBM_NAME_LEN );
                        }
                        break;

                    case DBM_TRUNCATE_LOG:
                        /***********************************************
                         * 1. truncate segment 를 완료해버린다.
                         * 2  Table 의 모든 Index Header 초기화.
                         * 3. Table Header 초기화.
                         ***********************************************/
                        sRC = dbmSegmentManager::Attach( aInstName,
                                                         sCurLog->mObjectName,
                                                         &sSegMgr );
                        if ( sRC == 0 )
                        {
                            sTableHeader = (dbmTableHeader*)sSegMgr->GetUserHeader();
                            dbmInitTableHeader( sTableHeader );

                            for(i=0; i<sTableHeader->mIndexCount; i++)
                            {
                                sIdxSegMgr = NULL;
                                sRC = dbmSegmentManager::Attach( aInstName,
                                                                 sTableHeader->mIndex[i].mIndexName,
                                                                 &sIdxSegMgr );
                                if ( sRC == 0 )
                                {
                                    sIdxSegMgr->Truncate();

                                    sIndexHeader = (dbmIndexHeader*)sIdxSegMgr->GetUserHeader();
                                    dbmInitIndexHeader( sIndexHeader );

                                    sIdxSegMgr->Detach();
                                    delete_s( sIdxSegMgr );
                                }
                            }

                            sSegMgr->Truncate();
    #ifndef USE_NEW_SHM_NODETACH
                            sRC = sSegMgr->Detach();
    #endif
                            delete_s( sSegMgr );
                        }
                        break;

                    case DBM_LOCK_ROW_LOG:
                    case DBM_LOCK_LIST_LOG:
                    case DBM_DELETE_SLOT_LOG:
                    case DBM_DEFER_INSERT_LOG:
                    case DBM_DEFER_UPDATE_LOG:
                    case DBM_SET_INDEX_LOG:
                        /* do nothing */
                        break;

                    case DBM_LIST_HEADER_LPUSH_LOG:
                        sRC = dbmSegmentManager::AttachList( aInstName,
                                                             sCurLog->mObjectName,
                                                             &sSegMgr );
                        if ( sRC == 0 && sSegMgr != NULL )
                        {
                            sListHeader = (dbmListHeader*) sSegMgr->GetUserHeader();
                            dbmTableObject* sTableObj = &sListHeader->mTableObj;

                            /* 제일 처음에 할당 된 LPUSH 값이면 초기값은 -1이니 -1로 해주어야 한다. */
                            if( sListHeader->mListLeftLast == sTableObj->mMaxSize-1 &&
                                sListHeader->mListTotalCount == 1 )
                            {
                                sListHeader->mListLeftLast  = -1;
                                sListHeader->mListRightLast = -1;
                            }
                            else
                            if( sListHeader->mListLeftLast == sTableObj->mMaxSize-1 &&
                                sListHeader->mListTotalCount > 1 )
                            {
                                /* round robin 형식이기 때문에 마지막 값에 rollback이 있을 때기존게 있다면
                                 * LPUSH 형식으로 마지막 0 값으로 position을 이동 한다 */
                                sListHeader->mListLeftLast = 0;
                            }
                            else
                            {
                                sListHeader->mListLeftLast++;
                            }

                            sListHeader->mListTotalCount = sListHeader->mListTotalCount - 1;

                            _CALL( sSegMgr->ListFreeAlloc() );
                        }

                        break;

                    case DBM_LIST_HEADER_RPUSH_LOG:
                        sRC = dbmSegmentManager::AttachList( aInstName,
                                                             sCurLog->mObjectName,
                                                             &sSegMgr );
                        if ( sRC == 0 && sSegMgr != NULL )
                        {
                            sListHeader = (dbmListHeader*) sSegMgr->GetUserHeader();
                            dbmTableObject* sTableObj = &sListHeader->mTableObj;

                            /* 제일 처음에 할당 된 LPUSH 값이면 초기값은 -1이니 -1로 해주어야 한다. */
                            if( sListHeader->mListRightLast == 0 && sListHeader->mListTotalCount == 1 )
                            {
                                sListHeader->mListRightLast  = -1;
                            }
                            else
                            if( sListHeader->mListRightLast == 0 && sListHeader->mListTotalCount > 1 )
                            {
                                sListHeader->mListRightLast = sTableObj->mMaxSize - 1;
                            }
                            else
                            {
                                sListHeader->mListRightLast--;
                            }

                            sListHeader->mListTotalCount = sListHeader->mListTotalCount - 1;

                            _CALL( sSegMgr->ListFreeAlloc() );
                        }

                        break;

                    case DBM_LIST_HEADER_LPOP_LOG:
                        sRC = dbmSegmentManager::AttachList( aInstName,
                                                             sCurLog->mObjectName,
                                                             &sSegMgr );
                        if ( sRC == 0 && sSegMgr != NULL )
                        {
                            sListHeader = (dbmListHeader*) sSegMgr->GetUserHeader();
                            dbmTableObject* sTableObj = &sListHeader->mTableObj;

                            /* left하여 하나 빼갔다가 롤백하는 거니 원상 복구해 주자 */
                            /* 99 -> 98 */
                            if( sListHeader->mListLeftLast == -1 && sListHeader->mListTotalCount < 1 )
                            {
                                /* 처음이라는 것이니 MAX에서 -1을 하자 */
                                sListHeader->mListLeftLast  = sTableObj->mMaxSize-1;
                            }
                            else
                            {
                                if( sListHeader->mListLeftLast == 0 && sListHeader->mListTotalCount > 0 )
                                {
                                    sListHeader->mListLeftLast = sTableObj->mMaxSize-1;
                                }
                                else
                                {
                                    sListHeader->mListLeftLast--;
                                }
                            }

                            mvpAtomicInc32(&sListHeader->mListTotalCount);

                            _CALL( sSegMgr->ListSetAlloc() );
                        }

                        break;

                    case DBM_LIST_HEADER_RPOP_LOG:
                        sRC = dbmSegmentManager::AttachList( aInstName,
                                                             sCurLog->mObjectName,
                                                             &sSegMgr );
                        if ( sRC == 0 && sSegMgr != NULL )
                        {
                            sListHeader = (dbmListHeader*) sSegMgr->GetUserHeader();
                            dbmTableObject* sTableObj = &sListHeader->mTableObj;

                            /* left하여 하나 빼갔다가 롤백하는 거니 원상 복구해 주자 */
                            /* 99 -> 98 */
                            if( sListHeader->mListRightLast == -1 && sListHeader->mListTotalCount < 1 )
                            {
                                /* 처음이라는 것이니 MAX에서 -1을 하자 */
                                sListHeader->mListRightLast  = 0;
                            }
                            else
                            {
                                if( sListHeader->mListRightLast == sTableObj->mMaxSize-1 &&
                                    sListHeader->mListTotalCount > 0 )
                                {
                                    sListHeader->mListRightLast = 0;
                                }
                                else
                                {
                                    sListHeader->mListRightLast++;
                                }
                            }

                            mvpAtomicInc32(&sListHeader->mListTotalCount);

                            _CALL( sSegMgr->ListSetAlloc() );
                        }

                        break;

                    default:
                        DBM_ERR( "invalid log type [%d]", sCurLog->mLogType );
                        _RAISE2( INVALID_LOG );
                        break;
                }

                sCurLog->mRollbackCompleteF = 1;
            }

            /***********************************************
             * Log 모두 rollback 처리 완료.
             ***********************************************/
            if ( sCurPos == sTxH->mLogStartPos )
            {
                break;
            }

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            sRC = dbmLogManager::mLogMoveBackward( aUndoSegMgr, sTxH, &sCurPos );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG ); //INVALID_LOGSLOT_LIST );
        }

        /***********************************************
         * 마지막 로그로 다시 이동
         ***********************************************/
UNLOCK_ROW:

        if ( ( SLOTID ( sTxH->mRecoveryStartPos ) >= 0 ) && ( sTxH->mRecoveryStartPos < sTxH->mLogCurPos ) )
        {
            sCurPos = sTxH->mRecoveryStartPos;
        }
        else
        {
            if ( SLOTID ( sTxH->mLogCurPos ) == -1 )
            {
                if ( SLOTID ( sTxH->mLockRecoveryPos ) == -1 ) //, NO_TRANS_LOG );
                    _RETURN;

                sCurPos = sTxH->mLockRecoveryPos;
            }
            else
            {
                sCurPos = sTxH->mLogCurPos;
            }
        }


        /***********************************************
         * Unlock Row
         ***********************************************/
        while(1)
        {
            sRC = dbmRecoveryManager::mGetLogPtr(aUndoSegMgr, sCurPos, &sCurLog);
            _IF_RAISE2( sRC, INVALID_LOG );

            if ( sCurLog->mLogValidF != 1 )
            {
                /* do nothing */
            }
            else
            {
                switch( sCurLog->mLogType )
                {
                    case DBM_LOCK_ROW_LOG:
                        _CALL( dbmSegmentManager::Attach( aInstName, sCurLog->mObjectName, &sSegMgr ) );
                        _ASSERT( sSegMgr != NULL );
                        //_IF_TRHOW( sRC || sSegMgr == NULL, ERR_DBM_SEGMENT_ATTACH_FAIL ); SEG_ATTACH_FAIL );

                        sRC = sSegMgr->Slot2Addr( sCurLog->mRefRecord, &sRefRow );
                        _IF_RAISE2( sRC, INVALID_LOG );

unlock_retry:
                        sRC = dbmLockManager::mAtomicUnlockTry( (char*)&(sRefRow->mLock), sCurLog->mTransID );
                        if( sRC )
                        {
                            _ASSERT( sRC == ERR_DBM_UNLOCK );

                            goto unlock_retry;
                        }

    #ifndef USE_NEW_SHM_NODETACH
                        sSegMgr->Detach();
    #endif
                        delete_s( sSegMgr );
                        break;

                    case DBM_LOCK_LIST_LOG:
                        _CALL( dbmSegmentManager::AttachList( aInstName, sCurLog->mObjectName, &sSegMgr ) );
                        _DASSERT( sSegMgr != NULL );

                        sRC = sSegMgr->Slot2Addr( sCurLog->mRefRecord, &sListRow );
                        _IF_RAISE2( sRC, INVALID_LOG );

                        dbmLockManager::mAtomicUnlockTry( (char*)&(sListRow->mLock), sCurLog->mTransID );

    #ifndef USE_NEW_SHM_NODETACH
                        sSegMgr->Detach();
    #endif
                        delete_s( sSegMgr );

                        break;

                    case DBM_ENQUE_LOG:
                        /***********************************************
                         * 일반적인 상황이라면 DBM_ENQUE_LOG 를 만났을 대 해야할 일이 없다.
                         * 하지만 Queue Header 의 Old 와 New 가 다른상황이라면, 이건 Commit 을
                         * 수행하여다가 죽었을 것이기 때문에 DBM_ENQUEUE_LOG 를 읽어서 모두
                         * 강제로  Commit 처리를 해야한다.
                         ***********************************************/
                        _CALL( dbmSegmentManager::Attach( aInstName, sCurLog->mObjectName, &sSegMgr ) );
                        _DASSERT( sSegMgr != NULL );
                        //_IF_TRHOW( sRC || sSegMgr == NULL, ERR_DBM_SEGMENT_ATTACH_FAIL ); SEG_ATTACH_FAIL );

                        sQueueHeader = (dbmQueueHeader*)sSegMgr->GetUserHeader () ;


                        if ( sFirstEnq == 0  )
                        {
                            if ( sQueueHeader -> mEnq != sQueueHeader->mOldEnq || sQueueHeader->mDeq == -2 )
                            {

                                _CALL( dbmRecoveryManager::mForceEnqueueCommit( aInstName,
                                                                               sTxH,
                                                                               sCurPos,
                                                                               sTxH->mLogStartPos,
                                                                               aUndoSegMgr ) );
                                //_IF_RAISE( sRC, ROLLBACK_DEQUE_FAIL );
                                sFirstEnq = 1;
                            }
                        }

                        break;

                    default:
                        break;
                }
            }

            /***********************************************
             * Log 모두 unlock 처리 완료.
             ***********************************************/
            if ( sCurPos == sTxH->mLogStartPos )
            {
                break;
            }

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            sRC = dbmLogManager::mLogMoveBackward( aUndoSegMgr, sTxH, &sCurPos );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG ); //INVALID_LOGSLOT_LIST );
        } /* while */

        /***********************************************
         * 로그 기록 위치 초기화.
         ***********************************************/
        sTxH->mImageCurPos       = MK_POS(-1,-1);
        sTxH->mLogCurPos         = MK_POS(-1,-1);
        sTxH->mRecoveryStartPos  = MK_POS(-1,-1);
        sTxH->mLockRecoveryPos   = MK_POS(-1,-1);

    }
    _CATCH
    {
        _BEGIN_SUB_CATCH
        {
            _SUB_CATCH( INVALID_LOG )
            {
                dbmRecoveryManager::mDumpTxHeader( (char*)sTxH );
                _rc = ERR_DBM_INVALID_LOG;
            }
        }
        _END_SUB_CATCH

        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mRollbackRecovery */


_VOID dbmRecoveryManager::mFinalTran ( dbmSegmentManager* aUndoSegMgr , int aTransID )
{
    dbmTransHeader* sTransH     = NULL;
    char*           sUserHeader = NULL;

    _TRY
    {
        /***********************************************
         * Transaction Header 주소 획득
         ***********************************************/
        sUserHeader = (char*) aUndoSegMgr->GetUserHeader ( );
        sTransH = (dbmTransHeader*) dbmRecoveryManager::mGetTxHead ( sUserHeader, aTransID );

        DBM_WARN( "mFinalTran Start.. txid[%d] pid=%d", aTransID, sTransH->mPID );

        /***********************************************
         * Transaction 에 할당된 모든 Page 들을 반납한다.
         ***********************************************/
        dbmLogManager::mFreeAllSlotList ( 1, aUndoSegMgr, sTransH );

        /***********************************************
         * Transaction header 초기화
         ***********************************************/
        dbmRecoveryManager::mClearTransItem ( (dbmTransHeader*) sTransH );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mCreate */


/*
 * undo name 과 txid 만 주어졌을 때 해당 transaction 을
 * rollback 하고 tx 를 반납하기 위해 사용.
 */
_VOID dbmRecoveryManager::mRecoverTrans ( char* aInstName , int aTxID )
{
    dbmDictionary*      sDic = NULL;
    dbmSegmentManager*  sUndoSegMgr = NULL;
    int                 sRC;

    _TRY
    {
        DBM_WARN( "mRecoverTrans. inst[%s] txid[%d]", aInstName, aTxID );

        sRC = dbmSegmentManager::Attach ( aInstName, aInstName, &sUndoSegMgr );
        if ( unlikely( sRC ) ) //, ATTACH_UNDOSEG_FAIL );
        {
            DBM_ERR( "attach inst(%s) seg fail. rc(%d)", aInstName, sRC );
            _THROW( sRC );
        }

        // aTxID 에 해당하는 Undo Log 를 모두 Rollback 시킴.
        _CALL( dbmRecoveryManager::mRollbackRecovery ( aInstName, sUndoSegMgr, aTxID ) );

        // aTxID 에 해당하는 Tx 를 재사용 가능하게 함.
        _CALL( dbmRecoveryManager::mFinalTran ( sUndoSegMgr, aTxID ) );

#ifndef USE_NEW_SHM_NODETACH
        sUndoSegMgr->Detach();
#endif
        delete_s( sUndoSegMgr );

    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/*
 * undo segment manager 와 txid 만 주어졌을 때 해당 transaction 을
 * rollback 하고 tx 를 반납하기 위해 사용.
 */
_VOID dbmRecoveryManager::mRecoverTrans ( char* aInstName , dbmSegmentManager* aUndoSegMgr , int aTxID )
{
    _TRY
    {
        // aTxID 에 해당하는 Undo Log 를 모두 Rollback 시킴.
        _CALL( dbmRecoveryManager::mRollbackRecovery ( aInstName, aUndoSegMgr, aTxID ) );

        // aTxID 에 해당하는 Tx 를 재사용 가능하게 함.
        _CALL( dbmRecoveryManager::mFinalTran ( aUndoSegMgr, aTxID ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/*
 * undo name 만 주어지면 해당 undo 에 있는 모든 transaction 에 대해
 * 복구를 수행. (tx 잡고 process 가 죽은 것들)
 */
_VOID dbmRecoveryManager::mRecoverAllTrans ( char* aInstName )
{
    int                 sOldPID;
    dbmTransHeader*     sTxHead = NULL;
    dbmSegmentManager*  sUndoSegMgr = NULL;
    dbmTransTable*      sTxTable = NULL;
    static int          sSyncFlag = -1;
    int                 tid;
    int                 sFound = 0;
    int                 sRC;
    int                 i;

    _TRY
    {
        DBM_DBG2( "RecoverAllTrans Start. inst[%s] (err=%d,tid=%d)", aInstName, errno, gettid_s() );
        tid = gettid_s( );

retry:
        // 중복진입하는 경우가 있을 수 있다. 별문제는 없을 수 있지만. 문제 가능성을 줄인다.
        if ( sSyncFlag == -1 )
        {
            sOldPID = mvpAtomicCas32 ( &sSyncFlag, tid, -1 );
            if ( sOldPID != -1 )
            {
                // InitTran에서 매번 진입한다. 길게 쉬면 곤란.
                //cmnUSleep( 100 );
                pthread_yield_s();
                goto retry;
            }
        }
        else
        {
            cmnUSleep( 100 );
            goto retry;
        }

        sRC = dbmSegmentManager::Attach( aInstName, aInstName, &sUndoSegMgr );
        _IF_THROW( sRC, ERR_DBM_SEGMENT_ATTACH_FAIL );

        sTxTable = (dbmTransTable*)sUndoSegMgr->GetUserHeader();

        for ( i = 0; i < DBM_MAX_TRANS; i++ )
        {
            sTxHead = &sTxTable->mItem[i];

            if ( sTxHead->mStatus != DBM_TX_FREE )
            {
                // 2014.09.30 -okt- for skip log
                if ( sFound == 0 )
                {
                    DBM_WARN( "[%d] RecoverAllTrans Start. inst[%s] (err=%d,tid=%d)", i, aInstName, errno, gettid_s() );
                    sFound = 1;
                }

                sOldPID = mvpAtomicGet32 ( &sTxHead->mPID );
                // 0 혹은 -1 일수있다.
                if ( sOldPID > 0 && sTxHead->mMyTxID == i )
                {
                    if ( tkill_s ( sOldPID, 0 ) && errno == ESRCH )
                    {
                        if ( mvpAtomicCas32 ( &sTxHead->mPID, tid, sOldPID ) == sOldPID )
                        {
                            DBM_WARN( "Try RecoverTrans Start.. txid[%d] old_pid[%d] getpid[%d]", i, sOldPID, tid );

                            dbmRecoveryManager::mDumpTxHeader ( dbmRecoveryManager::mGetTxHead ( (char*) sTxTable, i ) );

                            sRC = dbmRecoveryManager::mRecoverTrans ( aInstName, sUndoSegMgr, i );
                            if ( sRC == 0 )
                            {
                                DBM_WARN( "[%s] RecoverTrans ok. txid[%d] old_pid[%d] getpid[%d]", aInstName, i, sOldPID, tid );
                            }
                            else
                            {
                                DBM_ERR( "[%s] RecoverTrans fail. txid[%d] rc[%d] (err=%d,tid=%d)", aInstName, i, sRC, errno, gettid_s ( ) );
                            }
                        }
                    }
                }
            }
        } /* for */

#ifndef USE_NEW_SHM_NODETACH
        sUndoSegMgr->Detach();
#endif
        delete_s( sUndoSegMgr );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    {
        sOldPID = mvpAtomicCas32 ( &sSyncFlag, -1, tid );
    }
    _END
} /* mRecoverAllTrans */


/******************************************************************************
 * Name : mLinkReverseList
 *
 * Description
 *     Transaction Header 에 연결된 로그 Slot 들이 앞에서 뒤로 단방향 List 로
 *     연결되어 있는데(mNext), Rollback 이나 복구 시에는 마지막 로그부터
 *     역으로 와야하기 때문에 해당 List 를 역으로 쫓아올 수 있도록
 *     2 중 Linked List 를 만들어주어야 한다.
 *
 ******************************************************************************/
_VOID dbmRecoveryManager::mLinkReverseList ( dbmSegmentManager* aUndoSegMgr , dbmTransHeader* aHeader , long long aSlotID )
{
    dbmLogSlotHeader*   sStartSlot   = NULL;
    dbmLogSlotHeader*   sCurSlot     = NULL;
    dbmLogSlotHeader*   sBeforeSlot  = NULL;
    dbmLogSlotHeader*   sNextSlot    = NULL;
    long long           sSlotID      = -1;
    int                 sRC;

    _TRY
    {
        if ( aSlotID > 0 )
        {
            /***********************************************
             * Log Slot 들 중 중간의 특정 Slot 까지만
             * 연결해주고 싶을 때.
             ***********************************************/
            sSlotID = aSlotID;
        }
        else
        {
            /***********************************************
             * 모든 Log Slot 을 연결해줌.
             ***********************************************/
            sSlotID = SLOTID ( aHeader->mLogStartPos );
        }

        sRC = aUndoSegMgr->Slot2Addr ( sSlotID, &sStartSlot );
        if ( unlikely( sRC ) ) // || sStartSlot == NULL )
        {
            dbmRecoveryManager::mDumpTxHeader( (char*)aHeader );
            _THROW( RC_FAILURE );
        }

        sCurSlot = sStartSlot;

        while ( 1 )
        {
            if ( sCurSlot->mNext != -1 )
            {
                /***********************************************
                 * 끝이 아닐 경우 다음 slot 으로 이동
                 ***********************************************/
                sSlotID = sCurSlot->mNext;

                sRC = aUndoSegMgr->Slot2Addr ( sSlotID, &sNextSlot );
                if ( unlikely( sRC ) ) // || sNextSlot == NULL )
                {
                    dbmRecoveryManager::mDumpTxHeader( (char*)aHeader );
                    _THROW( RC_FAILURE );
                }

                sBeforeSlot = sCurSlot;
                sCurSlot = sNextSlot;

                /***********************************************
                 * LogSlot Header 의 mPrev 를 설정해가면서 이동함.
                 ***********************************************/
                sCurSlot->mPrev = sBeforeSlot->mMySlotID;
            }
            else
            {
                break;
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mLinkReverseList */


/******************************************************************************
 * Name : mClearTransItem
 *
 * Description
 *     특정 Transaction Header 에 대한 초기화 작업.
 *
 * Argument
 *     aHeader      : input   : pointer to mTransHeader
 *
 ******************************************************************************/
_VOID dbmRecoveryManager::mClearTransItem( dbmTransHeader* aHeader )
{
    dbmTransHeader  sClearTransH;

    _TRY
    {
        memset_s( &sClearTransH, 0x00, sizeof(dbmTransHeader) );

        sClearTransH.mPID               = -1;           // 2014/06/09 추가. rtf_insert_TBLMGR_INSERT_3 에서 멈춤.
        sClearTransH.mMyTxID            = -1;
        sClearTransH.mStatus            = DBM_TX_FREE;

        sClearTransH.mLastAllocLogSlot   = -1;
        sClearTransH.mLastAllocImageSlot = -1;

        sClearTransH.mLogStartPos      = MK_POS(-1,-1);
        sClearTransH.mImageStartPos    = MK_POS(-1,-1);
        sClearTransH.mLogCurPos        = MK_POS(-1,-1);
        sClearTransH.mImageCurPos      = MK_POS(-1,-1);
        sClearTransH.mRecoveryStartPos = MK_POS(-1,-1);

        sClearTransH.mWaitForObjectID = -1;
        sClearTransH.mWaitForSlotID = -1;
        sClearTransH.mWaitForTransID = -1;

        memcpy_s( aHeader, &sClearTransH, sizeof(dbmTransHeader) );
    }
    _CATCH
    _FINALLY
    _END
}


/*
 * Force Enqueue 하도록 바꾼다.
 */
_VOID dbmRecoveryManager::mForceEnqueueCommit ( char* aInstName , dbmTransHeader* aTxH , long long aStartPos ,
                                                long long aEndPos , dbmSegmentManager* aUndoSegMgr )
{
    long long             sCurPos;
    dbmLogHeader*       sCurLog   = NULL;
    char*               sCurImage = NULL;
    dbmQueueHeader*     sQHead    = NULL;
    dbmSegmentManager*  sSegMgr   = NULL;
    dbmQNodeHeader*     sQNodeHeader = NULL;
    dbmQNodeHeader*     sQHeaderPtr = NULL;

    long long           sSlotID  = -1;

    int                 sTransID = -1;
    int                 sOldTx = -1;
    int                 sLogCount = 0;
    int                 sRC;

    _TRY
    {
        sCurPos = aStartPos;

        while ( 1 )
        {
            sRC = dbmRecoveryManager::mGetLogPtr ( aUndoSegMgr, sCurPos, &sCurLog );
            _IF_RAISE2( sRC, INVALID_LOG );

            if ( ( sCurLog->mRollbackCompleteF == 1 ) || ( sCurLog->mLogValidF != 1 ) )
            {
                /* do nothing */
            }
            else
            {
                switch ( sCurLog->mLogType )
                {
                    case DBM_ENQUE_LOG:
                        sTransID = sCurLog->mTransID;

                        if ( sCurLog->mQueProcDone > 0 )  // 완전한 로그이다.
                        {
                            sRC = dbmRecoveryManager::mGetImagePtr ( aUndoSegMgr, sCurLog->mImageLogPos, &sCurImage );
                            _IF_RAISE2( sRC, INVALID_LOG );

                            sSegMgr = NULL;

                            sRC = dbmSegmentManager::Attach ( aInstName, sCurLog->mObjectName, &sSegMgr );
                            if ( sRC ) //, ATTACH_SEG_FAIL );
                            {
                                DBM_ERR( "attach fail for queue(%s) during recovery deque rollback. rc(%d)",
                                                  sCurLog->mObjectName, sRC );
                                dbmLogManager::mDumpLog( (char*)sCurLog );
                                _THROW( sRC );
                            }

                            sQHead = (dbmQueueHeader*) sSegMgr->GetUserHeader ( );


                            /**************************************************************
                              여기서 기존 복구 대상로그의 Table ID 를 검사한다. 만약 이미 Drop
                              된 Table ID라면 쌩깐다.  이미 Drop 된 Table 이기 떄문에 로그를
                              복구하면 안된다.
                            **************************************************************/

                            if ( sCurLog->mObjectID != sQHead->mTableObj.mTableID )
                            {
    #ifndef USE_NEW_SHM_NODETACH
                                sSegMgr->Detach();
    #endif
                                delete_s( sSegMgr );
                                break;
                            }


                            /**************************************************************
                              Commit 시 변경하기 전의 Header 값으로 바꿔놓는다.
                            **************************************************************/
                            sQHead->mDeq = sQHead->mOldDeq;
                            sQHead->mEnq = sQHead->mOldEnq;

                            /**************************************************************
                             * 기존의 로그에 존재하는 슬롯번호는 DBM_ALLOC_SLOT_LOG 를 남겼을 것이고,
                             * 이는 자동으로 Recovery 시점에 FREE 된다. 그러므로 새로운 Slot 을 할당받아
                             * Enqueue 처리한다.  Table Lock 이므로 건건히 처리해도 상관없겠다
                             **************************************************************/

                            while ( 1 )
                            {
                                sRC = dbmSegAllocSlot( sSegMgr, &sSlotID );
                                if ( sRC == ERR_DBM_NO_SPACE )
                                {
                                    sRC = sSegMgr->Extend () ;

                                    _THROW( sRC ); //, EXTEND_FAIL ) ;
                                    continue;
                                }

                                break;
                            }

                            _CALL( sSegMgr->Slot2Addr (sSlotID , &sQNodeHeader ) );

                            /**************************************************************
                             * Enqueue  할 데이터를 할당 받은 슬롯에 복사
                             *************************************************************/
                            memcpy_s ( (char*) sQNodeHeader + sizeof(dbmQNodeHeader), sCurImage, sCurLog->mImageSize );

                            /**************************************************************
                             * 다른 놈이 못들어오게 막는다.
                             *
                             * 2015.03.24 -okt- 리커버리 단계이므로, 추가된 mLockEnq 는 사용하지 않아도 될듯
                             *************************************************************/
                            sRC = dbmLockManager::mTableLock ( &sQHead->mLock, sTransID, &sOldTx );
                            if ( sRC && (sRC != ERR_DBM_ABNORMAL_ROLLBACK) ) //, TABLE_LOCK_FAIL );
                            {
                                DBM_ERR( "Lock Fail for queue(%s) during recovery deque rollback. rc(%d)",
                                                  sCurLog->mObjectName, sRC );
                                dbmLogManager::mDumpLog( (char*)sCurLog );
                                _THROW( sRC );
                            }


                            /**************************************************************
                             * Enqueue Force Commit 은 mEnq 만 복구해주면 된다. 근데 mDeq 가 -2
                             * 경우라면 mDeq 로 -1 로 바꿔줘야 한다.
                             *************************************************************/
                            sQNodeHeader->mMySlot = sSlotID;
                            sQNodeHeader->mNext = -1;
                            sQNodeHeader->mLock = -1;
                            sQNodeHeader->mDataSize = sCurLog->mImageSize;
                            if ( sQHead->mEnq == -1 )
                            {
                                sQHead->mEnq = sSlotID;
                                sQHead->mDeq = sSlotID;
                            }
                            else
                            {
                                sRC = sSegMgr->Slot2Addr ( sQHead->mEnq, &sQHeaderPtr ) ;
                                if ( sRC ) //, SLOT2ADDR_FAIL );
                                {
                                    DBM_ERR( "Slot2Addr Slot Fail [%s] . rc(%d)", sCurLog->mObjectName, sRC );
                                    (void) dbmLogManager::mDumpLog( (char*)sCurLog );
                                    _THROW( sRC );
                                }

                                sQHeaderPtr->mNext = sSlotID;
                                sQHead->mEnq = sSlotID;
                            }

                             /**************************************************************
                             * 이 함수가 호출되는 시점은 Commit 시점이고 이미 DBM_ALLOC_SLOT_LOG는
                             * 호출 될 수 없다. 그러므로 수동으로 로그의 Slot 번호를 보고 Free 해줘야한다.
                             *************************************************************/
                            sRC = dbmSegFreeSlot( sSegMgr, sCurLog->mRefRecord, 1 ) ;

                            /**************************************************************
                            * Lock 을 푼다
                            *************************************************************/
                            sRC = dbmLockManager::mTableUnlock( &sQHead->mLock, sTransID );
                            cmnSignalFutex( &sQHead->mRFutex );
#ifndef USE_NEW_SHM_NODETACH
                            sSegMgr->Detach();
#endif
                            delete_s( sSegMgr );
                        }
                        /***  이거 두개 외의 로그는 로그 자체도 아예 쓰여지다가 만 경우 */
                        break;

                    default:
                        break;
                }

                sCurLog->mRollbackCompleteF = 1;
            }

            if ( sCurPos == aEndPos )
            {
                break;
            }

            sRC = dbmLogManager::mLogMoveBackward( aUndoSegMgr, aTxH, &sCurPos );
            _IF_RAISE2( sRC, INVALID_LOG );
        }
    }
    _CATCH
    {
        _BEGIN_SUB_CATCH
        {
            _SUB_CATCH( INVALID_LOG )
            {
                DBM_ERR( "invalid log for rollback deque." );
                dbmLogManager::mDumpLog( (char*)sCurLog );
                _rc = ERR_DBM_INVALID_LOG;
            }
        }
        _END_SUB_CATCH

        _CATCH_WARN;
    }
    _FINALLY
    _END
//    return sRC;
} /* mForceEnqueueCommit */


/*
 * Log 중에서 모든 Deque 로그를 Rollback 한다. (다시 Enque)
 */
_VOID dbmRecoveryManager::mRollbackDequeAll ( char* aInstName , dbmTransHeader* aTxH , long long aStartPos ,
                                              long long aEndPos , dbmSegmentManager* aUndoSegMgr )
{
    long long           sCurPos;
    dbmLogHeader*       sCurLog   = NULL;
    char*               sCurImage = NULL;
    dbmQueueHeader*     sQHead    = NULL;
    dbmSegmentManager*  sSegMgr   = NULL;
    dbmQNodeHeader*     sQNodeHeader = NULL;
    dbmQNodeHeader*     sQHeaderPtr = NULL;
    dbmTransLogger*     sTransLogger = NULL;
    dbmLogAnchor*       sLogAnchor = NULL ;
    dbmDiskSyncOption   sDiskSyncOption = FSYNC;

    long long           sSlotID  = -1;

    int                 sTransID = aTxH->mMyTxID;
    int                 sOldTx = -1;
    int                 sLogCount = 0;
    int                 sRC;

    _TRY
    {
        sLogAnchor = &( (dbmUndoHeader*) ( aUndoSegMgr->GetUserHeader ( ) + sizeof(dbmTransTable) ) )->mAnchor;

        /**************************************************************************
         * Disk_LOGGING_ENABLE 시점에서만 처리되어야 한다.
         ************************************************************************/
#ifdef __linux__    //TODO: [OKT]  윈도포팅
        if ( aTxH->mDiskLoggingEnableF == 1 )
        {
            sTransLogger = new dbmDiskLogger ( sTransID, sLogAnchor, 1024 * 1024 * 10, sDiskSyncOption );
        }
#endif /* __linux__ */

        dbmQueueRecoveryHandler* sQueueRecoveryHandler = new dbmQueueRecoveryHandler ( );

        sQueueRecoveryHandler->mSetTransLogger ( sTransLogger );

        sCurPos = aStartPos;

        while ( 1 )
        {
            sRC = dbmRecoveryManager::mGetLogPtr ( aUndoSegMgr, sCurPos, &sCurLog );
            _IF_RAISE2( sRC, INVALID_LOG );

            /***************************************************************************
             * Dequeue 로그 시점에는 이미 읽었던 것도 다시 읽을 수 있따.
             **************************************************************************/
            if ( sCurLog->mLogValidF != 1 )
            {
                /* do nothing */
            }
            else
            {
                switch ( sCurLog->mLogType )
                {
                    case DBM_DEQUE_LOG:
                        sTransID = sCurLog->mTransID;
                        if ( sCurLog->mQueProcDone > 0 )  // 완전한 로그이다.
                        {
                            sRC = dbmRecoveryManager::mGetImagePtr ( aUndoSegMgr, sCurLog->mImageLogPos, &sCurImage );
                            _IF_RAISE2( sRC, INVALID_LOG );

                            sQueueRecoveryHandler->mHandleDequeLog ( aInstName, sCurLog, sCurImage );
                        }
                        /***  이거 두개 외의 로그는 로그 자체도 아예 쓰여지다가 만 경우 */
                        break;

                    default:
                        break;
                }

                sCurLog->mRollbackCompleteF = 1;
            }

            if ( sCurPos == aEndPos )
            {

                if ( sTransLogger != NULL )
                {
                    _CALL( sTransLogger->mFlush ( ) );
                    //_IF_RAISE ( sRC, LOGGING_ERROR );
                }

                (void) sQueueRecoveryHandler->mComplete ( );
                (void) sQueueRecoveryHandler->mFinalize ( );
                delete_s( sQueueRecoveryHandler );
                break;
            }

            sRC = dbmLogManager::mLogMoveBackward ( aUndoSegMgr, aTxH, &sCurPos );
            _IF_RAISE2( sRC, INVALID_LOG );
        }

        delete_s( sTransLogger );
    }
    _CATCH
    {
        _BEGIN_SUB_CATCH
        {
            _SUB_CATCH( INVALID_LOG )
            {
                DBM_CERR( "invalid log for rollback deque." );
                dbmLogManager::mDumpLog( (char*)sCurLog );
                _rc = ERR_DBM_INVALID_LOG;
            }
        }
        _END_SUB_CATCH

        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mRollbackDequeAll */


#if 0
/*
 * Deque 한 것을 다시 Enque 한다.
 */
int dbmRecoveryManager::mRollbackDequeOne( dbmLogHeader*       aCurLog,
                                           char*               aImage,
                                           int                 aImageSize,
                                           dbmSegmentManager*  aSegMgr,
                                           dbmQueueHeader*     aQueueHeader )
{
    int             sRC;
    dbmRowHeader*   sRow = NULL;
    int             sCurWSlot;
    int             sOldTx = -1;
    int             sTransID;
    long long       sCommitSCN;

    _IF_RAISE( aImage == NULL, INVALID_ARG );
    _IF_RAISE( aImageSize <= 0, INVALID_ARG );
    _IF_RAISE( aCurLog == NULL, INVALID_ARG );


    sTransID   = aCurLog->mTransID;
    sCommitSCN = aCurLog->mSCN;


    /***********************************************
     * Write Table Lock 을 건다.
     * 이미 복구 중이므로 ERR_DBM_ABNORMAL_ROLLBACK 라도
     * 복구할 필요는 없다.
     ***********************************************/
    sRC = dbmLockManager::mTableLock( (char*)&aQueueHeader->mLock, sTransID, &sOldTx );
    _IF_RAISE( sRC && (sRC != ERR_DBM_ABNORMAL_ROLLBACK),
                    TABLE_LOCK_FAIL );


    /***********************************************
     * 원래의 위치에 데이터 원복.
     * (logging 은 before indicator 를 기록하므로 + 1)
     ***********************************************/
    sCurWSlot = (aCurLog->mRefRecord + 1) % (aQueueHeader->mTableObj.mMaxSize);

    sRC = aSegMgr->Slot2Addr( sCurWSlot, &sRow);
    if ( sRC || sRow == NULL )
    {
        sRC = dbmLockManager::mTableUnlock( (char*)&aQueueHeader->mLock, sTransID );
        _RAISE( SLOT2ADDR_FAIL );
    }

    memcpy_s( (char*)sRow + sizeof(dbmRowHeader), aImage, aImageSize );
    sRow->mRowSize = aImageSize;
    sRow->mSCN     = sCommitSCN;

    /***********************************************
     * Write Indicator 원복.
     * TODO. 그런데 요 위치에 이미 다른 놈이 enque 했다면 ???
     ***********************************************/
    aQueueHeader->mRInd = aCurLog->mRefRecord;


    /***********************************************
     * Table Write Lock 풀어주고 읽을놈 깨워준다.
     ***********************************************/
    sRC = dbmLockManager::mTableUnlock( (char*)&aQueueHeader->mLock, sTransID );
    sRC = cmnSignalFutex( &aQueueHeader->mRFutex );

    return RC_SUCCESS;


    _EXCEPTION( INVALID_ARG )
    {
        DBM_ERR( "invalid log arguemnt. aCurLog(0x%x) aImage(0x%x) aImageSize(%d0",
                            aCurLog, aImage, aImageSize );
        sRC = ERR_DBM_INVALID_LOG;
    }
    _EXCEPTION( TABLE_LOCK_FAIL )
    {
        DBM_ERR( "Queue(%s) lock fail. lock(%d) txid(%d)",
                            aQueueHeader->mTableObj.mTableName, aQueueHeader->mLock, sTransID);
        sRC = ERR_DBM_LOCK;
    }
    _EXCEPTION( SLOT2ADDR_FAIL )
    {
        DBM_ERR( "Queue(%s) slot2addr fail. slot(%ld) txid(%d)",
                            aQueueHeader->mTableObj.mTableName, sCurWSlot, sTransID);
        sRC = ERR_DBM_SLOT2ADDR_FAIL;
    }
    _EXCEPTION_END;

    return sRC;
}

#endif

#if 0       // -fno-inline 옵션을 제거하기 위해
inline char* dbmRecoveryManager::mGetTxHead( char*     aUserHeader,
                                             int       aTransID )
{
    return (char*)( aUserHeader
                   + sizeof(dbmTransHeader) * aTransID );
}

inline char* dbmRecoveryManager::mGetTxHead( dbmTransTable*   aTxTable,
                                             int              aTransID )
{
    return (char*)( (char*)aTxTable
                   + sizeof(dbmTransHeader) * aTransID );
}

inline int dbmRecoveryManager::mGetLogPtr( dbmSegmentManager*    aSegMgr,
                                           long long             aLogPos,
                                           char**                aLogPtr)
{
    int     sRC;
    char*   sTmp = NULL;

    sRC = aSegMgr->Slot2Addr( SLOTID(aLogPos), &sTmp );
    if ( sRC || sTmp == NULL )
    {
        return -2;
    }

    *aLogPtr = (char*)GETLOG( sTmp, OFFSET(aLogPos) );

    return RC_SUCCESS;
}

inline int dbmRecoveryManager::mGetImagePtr( dbmSegmentManager*  aSegMgr,
                                             long long           aImagePos,
                                             char**              aImagePtr )
{
    int     sRC;
    char*   sTmp = NULL;

    sRC = aSegMgr->Slot2Addr( SLOTID(aImagePos), &sTmp );
    if ( sRC || sTmp == NULL )
    {
        return -2;
    }

    *aImagePtr = (char*)GETIMG( sTmp, OFFSET(aImagePos) );

    return RC_SUCCESS;
}
#endif


_VOID dbmRecoveryManager::mDropIndexFromTableHeader ( char* aInstName, char* aTableName , char* aIndexName )
{
    unsigned long long  i;
    int                 sRC;
    dbmSegmentManager*  sSegMgr      = NULL;
    dbmTableHeader*     sTableHeader = NULL;

    _TRY
    {
        sRC = dbmSegmentManager::Attach ( aInstName, aTableName, &sSegMgr );
        if ( sRC == 0 )
        {
            sTableHeader = (dbmTableHeader*) sSegMgr->GetUserHeader ( );

            for ( i = 0; i < sTableHeader->mIndexCount; i++ )
            {
                if ( !strcmp_s ( aIndexName, sTableHeader->mIndex[i].mIndexName ) )
                {
                    break;
                }
            }

            if ( i < sTableHeader->mIndexCount )
            {
                if ( sTableHeader->mIndexCount > ( i + 1 ) )
                {
                    memmove_s ( &sTableHeader->mIndex[i],
                                &sTableHeader->mIndex[i + 1], sizeof(dbmIndexObject) * sTableHeader->mIndexCount - ( i + 1 ) );
                }

                sTableHeader->mIndexCount = sTableHeader->mIndexCount - 1;
            }

#ifndef USE_NEW_SHM_NODETACH
            sSegMgr->Detach();
#endif
            delete_s( sSegMgr );
        }
        else
        {
            _THROW( ERR_DBM_ATTACH_SHM_FAIL ); // ATTACH_FAIL );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID dbmInitIndexHeader ( dbmIndexHeader* aIndexHeader )
{
    aIndexHeader->mLock          = -1;
    aIndexHeader->mPID           = gettid_s ();
    aIndexHeader->mRootAllocCk   = 0;
    aIndexHeader->mRootPid       = 0;
    aIndexHeader->mCurrStep      = 0;
    aIndexHeader->mInitCompleteF = 1;
    /***********************************************
     * 변경자 : wind * 변경일 : 15.11.06 * 참고 : #
     * 변경 내용 : extrakey 값의 초기화 및 증가를 인덱스 매니저 안에서 처리했었으나
     * 증가 작업을 인덱스 매니저보다 선행하는 테이블 매니저에게 이관하면서 초기화 또한
     * 선행하게 변경했는데 truncate의 경우 따로 처리되는줄 몰라 누락되어 추가함
     ***********************************************/
    aIndexHeader->mExtra         = 0;
    return 0;   // 가독성 코드를 위한 더미 리턴 , 사용하는 쪽에서 "(void) f1(xx);" 이렇게 호출
}

_VOID dbmInitQueueHeader ( dbmQueueHeader* aQueueHeader )
{
    aQueueHeader->mLock         = -1;
    aQueueHeader->mLockEnq      = -1;
    aQueueHeader->mWFutex       = 0;
    aQueueHeader->mRFutex       = 0;
    aQueueHeader->mDeq          = -1;
    aQueueHeader->mEnq          = -1;
    aQueueHeader->mOldDeq       = -1;
    aQueueHeader->mOldEnq       = -1;
    aQueueHeader->mDDLCount     = 0;
    return 0;
}

_VOID dbmInitListHeader ( dbmListHeader* aListHeader )
{

    aListHeader->mLock = -1;
    aListHeader->mDDLCount = 0;
    aListHeader->mInitCompleteF = 1;
    aListHeader->mRecoveryProcessF = 0;

    aListHeader->mListTotalCount = 0;
    aListHeader->mListLeftLast   = -1;
    aListHeader->mListRightLast  = -1;
    memset_s( aListHeader->mSegmentAllocCk, -1, sizeof(int) * MAX_SEGMENT_COUNT );
    aListHeader->mSegmentAllocCk[0] = 0;

    return 0;
}

_VOID dbmInitTableHeader ( dbmTableHeader* aTableHeader )
{
    aTableHeader->mUseIndex    = 0;
    aTableHeader->mLock        = -1;
    aTableHeader->mRecordCount = 0;
    aTableHeader->mDDLCount    = 0;
    return 0;
}


/******************************************************************************
 * Name : mDumpTxHeader
 *
 * Description
 *     Transaction Header 의 현재 상태를 dump 로 보여줌.
 ******************************************************************************/
_VOID dbmRecoveryManager::mDumpTxHeader ( char* aTransHeader, int aFlag )
{
    dbmTransHeader* sHead = (dbmTransHeader*)aTransHeader;

    if (aFlag == 0)
    {
        DBM_WARN( "  [Tx Header : %d]", sHead->mMyTxID );
        DBM_WARN( "      User ID                 : %d", sHead->mUserID );
        DBM_WARN( "      Session ID              : %ld", sHead->mSessionID );
        DBM_WARN( "      Status                  : %s", dbmTxStr[sHead->mStatus] );
        DBM_WARN( "      Process ID              : %d", sHead->mPID );
        DBM_WARN( "      Last Alloc Log Slot     : [%d]", sHead->mLastAllocLogSlot );
        DBM_WARN( "      Last Alloc Image Slot   : [%d]", sHead->mLastAllocImageSlot );
        DBM_WARN( "      Log Cnt Per Slot        : %d", sHead->mLogCntPerSlot );
        DBM_WARN( "      Image Cnt Per Slot      : %d", sHead->mImageCntPerSlot );
        DBM_WARN( "      Log Start Pos           : [%ld:%ld]", SLOTID ( sHead->mLogStartPos ), OFFSET ( sHead->mLogStartPos ) );
        DBM_WARN( "      Image Start Pos         : [%ld:%ld]", SLOTID ( sHead->mImageStartPos ), OFFSET ( sHead->mImageStartPos ) );
        DBM_WARN( "      Log Cur Pos             : [%ld:%ld]", SLOTID ( sHead->mLogCurPos ), OFFSET ( sHead->mLogCurPos ) );
        DBM_WARN( "      Image Cur Pos           : [%ld:%ld]", SLOTID ( sHead->mImageCurPos ), OFFSET ( sHead->mImageCurPos ) );
    }
    else
    {
        DBM_ECHO( "  [Tx Header : %d]", sHead->mMyTxID );
        DBM_ECHO( "      User ID                 : %d", sHead->mUserID );
        DBM_ECHO( "      Session ID              : %ld", sHead->mSessionID );
        DBM_ECHO( "      Status                  : %s", dbmTxStr[sHead->mStatus] );
        DBM_ECHO( "      Process ID              : %d", sHead->mPID );
        DBM_ECHO( "      Last Alloc Log Slot     : [%d]", sHead->mLastAllocLogSlot );
        DBM_ECHO( "      Last Alloc Image Slot   : [%d]", sHead->mLastAllocImageSlot );
        DBM_ECHO( "      Log Cnt Per Slot        : %d", sHead->mLogCntPerSlot );
        DBM_ECHO( "      Image Cnt Per Slot      : %d", sHead->mImageCntPerSlot );
        DBM_ECHO( "      Log Start Pos           : [%ld:%ld]", SLOTID ( sHead->mLogStartPos ), OFFSET ( sHead->mLogStartPos ) );
        DBM_ECHO( "      Image Start Pos         : [%ld:%ld]", SLOTID ( sHead->mImageStartPos ), OFFSET ( sHead->mImageStartPos ) );
        DBM_ECHO( "      Log Cur Pos             : [%ld:%ld]", SLOTID ( sHead->mLogCurPos ), OFFSET ( sHead->mLogCurPos ) );
        DBM_ECHO( "      Image Cur Pos           : [%ld:%ld]", SLOTID ( sHead->mImageCurPos ), OFFSET ( sHead->mImageCurPos ) );
    }

    return 0;
}

/****************************************************************************
 * 비정상 Rollback 에 대한 처리시 Disk 로그를 검사하여 COMMIT 로그가 존재하는지
 * 확인하고 존재하면 0 , 아니면 -1 을 리턴한다 .
 **************************************************************************/
int dbmRecoveryManager::mCheckRollbackWithDisk ( dbmTransHeader* aTxH , int aTxID , dbmLogAnchor* aAnchor )
{
    dbmLogBlockHeader *sDiskLogHdr;
    int     sRC ;
    int     sFD ;
    char    sFileName [DBM_FILE_NAME_LEN ];
    char*   sLogBuffer = NULL;
    char*   sCompressBuffer = NULL;
    char    sReadBlockBuffer [ DBM_LOG_BLOCK_SIZE ] ;
    int     sIdx = 0;
    int     sCheckIdx = 0 ;
    int     sReadIndex = 0;
    int     sFound = 0 ;
    int     sIsCompress = 0 ;

    dbmTransLog* sTransLog = NULL;

    _TRY
    {
        /***********************************************************************
         * Disk Logging 이 Enable 된 상태가 아니라면 검사할게 없다. 원래대로 진행
         **********************************************************************/
        if ( aTxH->mDiskLoggingEnableF == 0 )
        {
            // 이 상황은 복구할게 존재한다. 복구하자.
            _THROW( -1 );
        }

        // Size자체의 변경은 쓴 후 쓰기 전 Atomic하지 않다.
        // 따라서 아래코드는 주석으로 막는다.
#if 0
        /***********************************************************************
         * 로그 앵커를 통해서 마지막 Sync 된 바이트와 Write 된 Byte 를 비교한다.
         * 만약 같다면 여기에 아예 들어올 수 없는데 만약 같다면 걍 복구하지 않는다.
         **********************************************************************/
        if ( aAnchor->mTxAnchor[aTxID].mLastSyncSize == aAnchor->mTxAnchor[aTxID].mLastFileSize )
        {
            /* size check :
             * 정상 적으로 commit이 완료 된 상태에서 mLastSyncSize, mLastFileSize 같을 수 있다.
             * 이 후 write 하기전 비정상 종료 하였다면 recover해야 한다. case-643 참고 */
            if( aAnchor->mTxAnchor[aTxID].mStat != 1 )
            {
                _RETURN;
            }
            else
            {
                _THROW(RC_FAILURE);
            }
        }
#endif

        /**********************************************************************
         * 파일 열어서 해당 로그파일을 연다.
         *********************************************************************/
        sprintf ( sFileName, "%s/%s.tx.%d.%d", aAnchor->mLogDest, aAnchor->mInstanceName,
                                               aTxID, aAnchor->mTxAnchor[aTxID].mCurFileNo ) ;

        sLogBuffer = (char*) malloc_s ( 1024 * 1024 * 10 ) ;
        _DASSERT( sLogBuffer != NULL );

        sFD = open ( sFileName, O_RDONLY );

        // DBM_DISK_WATER_MARK가 나올때까지 뒤에서부터 읽어봐야 함.
        sReadIndex = 1;
        while (1)
        {
            // 1 block씩 앞으로 땡겨가면서 읽어본다.
            lseek_s (sFD, ((-1) * DBM_LOG_BLOCK_SIZE * sReadIndex), SEEK_END);
            sRC = read_s ( sFD, sReadBlockBuffer, DBM_LOG_BLOCK_SIZE );

            // 읽어봤는데 읽지도 못해...그럼 복구해야 함.
            if (sRC != DBM_LOG_BLOCK_SIZE)
            {
                DBM_WARN ("Find Last-Block Fail rc=%d\n", sRC);
                _THROW( RC_FAILURE );
            }

            // BlockHeaderdml MagicNo가 맞나 체크한다.
            sDiskLogHdr = (dbmLogBlockHeader*)(sReadBlockBuffer);
            if (sDiskLogHdr->mMagicNo == DBM_DISK_WATER_MARK)
            {
                break;
            }

            sReadIndex++;
        }

        //마지막 Sync 위치로 이동시킨다.
        lseek_s (sFD, ((-1) * DBM_LOG_BLOCK_SIZE * sReadIndex), SEEK_END);

        do
        {
            // 블록을 읽어서 임시 버퍼에 쌓는다.
            sRC = read_s ( sFD, sReadBlockBuffer, DBM_LOG_BLOCK_SIZE );
            if ( sRC != DBM_LOG_BLOCK_SIZE )
            {
                break;
            }

            sIsCompress = ( (dbmLogBlockHeader*) sReadBlockBuffer )->mIsCompressF;

            // Block Header를 제거하고 TransLog만 연속적으로 묶는다.
            memcpy_s ( sLogBuffer + sIdx 
                     ,  sReadBlockBuffer + sizeof(dbmLogBlockHeader)
                     ,  DBM_LOG_BLOCK_SIZE - sizeof(dbmLogBlockHeader) );
            sIdx += DBM_LOG_BLOCK_SIZE - sizeof(dbmLogBlockHeader);
        }
        while ( 1 );

        // 이용가치가 있음으로 Final에서 닫도록 하자.
        //close_s ( sFD );


        if ( sIsCompress )
        {
            if ( unlikely( __LZ4_decompress_safe == NULL ) )
            {
                int sRC;

                if ( unlikely( __liblz4_so == NULL ) )
                {
                    sRC = cmnDlopen( "liblz4.so", &__liblz4_so );
                    assert ( sRC == 0 && "Compress library dlopen Fail !" );
                }

                sRC = cmnDlsym ( __liblz4_so, "LZ4_decompress_safe", (void**)&__LZ4_decompress_safe );
                assert ( sRC == 0 && "dlsym Fail (LZ4_decompress_safe)" );
            }

            sCompressBuffer = (char*) malloc_s ( 1024 * 1024 * 10 ) ;
            memcpy_s ( sCompressBuffer, sLogBuffer , sIdx )  ;
            __LZ4_decompress_safe ( sCompressBuffer, sLogBuffer, sIdx, 1024*1024*10 ) ;
        }

        /**********************************************************************
         * 로그파일에 맞도록 처리한다.
         *********************************************************************/
        while ( sCheckIdx < sIdx )
        {
            sTransLog = (dbmTransLog*) ( sCheckIdx + sLogBuffer );

            DBM_WARN ("Check LogType<%d>. (DiskLogSCN=%lld : MemLogSCN=%lld, sCheckIdx=%d : sIdx=%d)\n", 
                         sTransLog->mLogType, sTransLog->mSCN, aTxH->mSCN, sCheckIdx, sIdx);
            // 다음과 같이 비교를 바꾼다.
            // 메모리로깅의 mSCN과 디스크로깅시 기록된 SCN이 같으면서
            // 커밋로그가 있다면 이것은 디스크로 내려간 상태임으로
            // 복구를 하면 안되도록 체크한다.
            if ( sTransLog->mSCN == aTxH->mSCN && sTransLog->mLogType == DBM_COMMIT_LOG )
            {
                //DBM_WARN ("Check CommitLog. (DiskLogSCN=%lld : MemLogSCN=%lld)\n", sTransLog->mSCN, aTxH->mSCN);
                sFound = 1;
                break;
            }
            if ( sTransLog->mImageSize < 0 )
            {
                DBM_ERR ("[CRIT] Invalid image size. (mImageSize=%d)\n", sTransLog->mImageSize);
                sFound = 1;
                break;
            }
            sCheckIdx += sizeof(dbmTransLog) + sTransLog->mImageSize;
        }

        free_s ( sLogBuffer ) ;


        // 모두 처리했으니 초기화
        // 좋은데...파일 마지막위치로 쓰는게 맞을꺼란거..
        // 여기까지 왔다면 Commit을 찾았을테니까.
        // 찾았다면 현재파일위치가 젤루 정확한 위치인거고
        // 못찾았다면 지금쓴거는 뭉개도 된다. 덮어치도록 위치를 원래코드처럼 하믄 된다.
        if (sFound == 1)
        {
            aAnchor->mTxAnchor[aTxID].mLastSyncSize = aAnchor->mTxAnchor[aTxID].mLastFileSize = lseek(sFD, 0L, SEEK_CUR)  ;
        }
        else
        {
            aAnchor->mTxAnchor[aTxID].mLastFileSize = aAnchor->mTxAnchor[aTxID].mLastSyncSize  ;
        }

        if ( ! sFound )
        {
            _THROW( RC_FAILURE );
        }
    }
    _CATCH
    {
        _CATCH_TRC;
    }
    _FINALLY
        close_s ( sFD );
    _END    // 0 의 의미는 디스크 롤백데이타가 존재함을 의미.

} /* mCheckRollbackWithDisk */

