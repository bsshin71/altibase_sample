/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/******************************************************************************
 * $Id$*
 * Description :
 ******************************************************************************/
#include "dbmHeader.h"
#include "dbmTransManager.h"


/*
 * 2014.09.21 (OKT)
 * 외부에 노출하지 않는 static function 을 선언할때는 앞에 static을 붙여야지. nm에서 헷갈리지 않는다.
 */
static _VOID dbmGetIndexKeyColumnInfo ( dbmIndexObject* aParseIndex , dbmTableInfo* aDicTableInfo , int* aKeySize );
//static _VOID dbmGetRefRowPtr ( dbmTransManager* aTxMgr , char* aTableName , long long aRowSlot , dbmRowHeader** aRow );
static _VOID dbmGetIndexMgrByObjID ( dbmTransManager* aTxMgr , char* aTableName , int aIndexID , dbmIndexManager** aIndexMgr );
static _VOID dbmGetTableSegMgr ( dbmTransManager* aTxMgr , char* aTableName , dbmSegmentManager** aIndexMgr );
static _VOID dbmGetQueueSegMgr ( dbmTransManager* aTxMgr , char* aQueueName , dbmSegmentManager** aIndexMgr );
static _VOID dbmGetListSegMgr  ( dbmTransManager* aTxMgr , char* aListName , dbmSegmentManager** aSegMgr );
static _VOID dbmGetIndexSegMgrByObjID ( dbmTransManager* aTxMgr , char* aTableName , int aIndexID , dbmSegmentManager** aSegMgr );
static _BOOL dbmIsFirstEnqueLog ( dbmSegmentManager* aUndoSegMgr , dbmTransHeader* aTxH , long long aEndPos , int aObjectID );
static _VOID dbmGetColumnType ( dbmTableInfo* aDicTableInfo , char* aColumnName , dbmColumnType* aColumnType );

extern char dbmDicTableName[][DBM_NAME_LEN];
extern char dbmDicIndexName[][DBM_NAME_LEN];


/******************************************************************************
 * Name : mClearTransMgr
 *
 * Description
 *     dbmTransManager 객체의 모든 멤버변수들을 단순히 초기화한다.
 *
 ******************************************************************************/
void dbmTransManager::mClearTransMgr()
{
    int     i;

    memset_s ( mInstName, 0x00, DBM_NAME_LEN );

    mTransID     = -1;
    mTransHeader = NULL;

    mParseObj    = NULL;
    mUndoSegMgr  = NULL;

    mTableCount  = 0;
    mQueueCount  = 0;
    mListCount   = 0;

    for( i=0; i<DBM_MAX_TABLE_PER_TRANS; i++ )
    {
        mTable[i] = NULL;
        mQueue[i] = NULL;
    }

    mLogMgr      = NULL;
    mLockMgr     = NULL;
    mConfigMgr   = NULL;
    mDic         = NULL;
    mDeadLockManager = NULL;
    mTransLogger = NULL;

    mDiskLoggingF= 0;
}


/******************************************************************************
 * Name : mFreeTransMgr
 *
 * Description
 *     dbmTransManager 객체의 모든 멤버변수에 할당된 heap 메모리를 해제하고
 *     변수들을 초기화한다.
 *
 ******************************************************************************/
_VOID dbmTransManager::mFreeTransMgr( )
{
    _TRY
    {
        memset_s ( mInstName, 0x00, DBM_NAME_LEN );

        mTransID     = -1;
        mTransHeader = NULL;

        free_s(mParseObj);

        if ( mUndoSegMgr != NULL )
        {
#ifndef USE_NEW_SHM_NODETACH
            mUndoSegMgr->Detach();
#endif
            delete_s( mUndoSegMgr );
        }

        mTableCount  = 0;
        mQueueCount  = 0;

        for( int i=0; i<DBM_MAX_TABLE_PER_TRANS; i++ )
        {
            delete_s( mTable[i] );
            delete_s( mQueue[i] );
        }

        delete_s( mLogMgr );
        delete_s( mLockMgr );
        delete_s( mDic );
        delete_s( mDeadLockManager );
        delete_s( mTransLogger );

        mConfigMgr = NULL;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}

#if 0       // -fno-inline 옵션을 제거하기 위해
inline void dbmInitLogSlot( dbmLogSlotHeader* aSlot, long long aSlotID )
{
    aSlot->mMySlotID = aSlotID;
    aSlot->mNext     = -1;
    aSlot->mPrev     = -1;
}
#else
inline
static void dbmInitLogSlot ( dbmLogSlotHeader* aSlot , long long aSlotID )
{
    aSlot->mMySlotID = aSlotID;
    aSlot->mNext = -1;
    aSlot->mPrev = -1;
}
#endif


/******************************************************************************
 * Name : dbmTransManager
 *
 * Description
 *     constructor
 *
 ******************************************************************************/
dbmTransManager::dbmTransManager( )
{
    _TRY
    {
        mClearTransMgr();
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    //_END      // 생성자에서도 _TRY가 사용은 가능함을 보여주기위한 예제.
}

/******************************************************************************
 * Name : ~dbmTransManager
 *
 * Description
 *     destructor
 *
 ******************************************************************************/
dbmTransManager::~dbmTransManager( )
{
    _TRY
    {
        _CALL( mFreeTransMgr() );
    }
    _CATCH
    _FINALLY
}


/******************************************************************************
 * Name : dbmGetTransID
 *
 * Description
 *     get this object's transaction ID
 *
 ******************************************************************************/
// 2015.02.16 -okt- 호출되는 곳 없음
//_VOID dbmTransManager::mGetTableObj( int aIdx, dbmTableManager* aTableObj )
//{
//    // -Wunused-but-set-parameter 거짓알람같은데..
//    aTableObj = mTable[aIdx];
//
//    return RC_SUCCESS;
//}


/******************************************************************************
 * Name : dbmGetTransID
 *
 * Description
 *     get this object's transaction ID
 *
 ******************************************************************************/
int dbmTransManager::mGetTransID( void )
{
    return mTransID;
}


/******************************************************************************
 * Name : dbmInitTransItem
 *
 * Description
 *     Transaction 이 할당될 때 사용되는 Transaction 의 변수들 할당 작업.
 *
 * Argument
 *     aHeader      : input   : pointer to mTransHeader
 *     aSessionID   : input   : session ID
 *     aUserID      : input   : user ID
 *     aPID         : input   : process ID
 *     aStatus      : input   : transaction status
 *
 ******************************************************************************/
void dbmTransManager::mInitTransItem( int               aTransID,
                                      dbmTransHeader* aHeader,
                                      long long         aSessionID,
                                      int               aUserID,
                                      int               aPID,
                                      dbmTxStatus       aStatus,
                                      int               aSlotSize)
{
    dbmTransHeader  sInitTransH;

    memset_s( &sInitTransH, 0x00, sizeof(dbmTransHeader) );

    sInitTransH.mPID       = aPID;
    sInitTransH.mMyTxID    = aTransID;
    sInitTransH.mSessionID = aSessionID;
    sInitTransH.mUserID    = aUserID;
    sInitTransH.mStatus    = aStatus;
    sInitTransH.mSCN       = -1;

    sInitTransH.mWaitForTransID        = -1;
    sInitTransH.mWaitForObjectID       = -1;
    sInitTransH.mWaitForSlotID         = -1;

    sInitTransH.mLastAllocLogSlot   = -1;
    sInitTransH.mLastAllocImageSlot = -1;
    sInitTransH.mDiskLoggingEnableF = 0;

    sInitTransH.mLogCntPerSlot =
        ( aSlotSize-sizeof(dbmLogSlotHeader))/sizeof( dbmLogHeader );

    sInitTransH.mImageCntPerSlot =
        ( aSlotSize-sizeof(dbmLogSlotHeader))/(DBM_MAX_RECORD_SIZE+sizeof(dbmRowHeader));

    DBM_DBG( "Init Trans. id[%d] session[%ld] pid[%d] slot_size[%d] log_cnt_per_slot[%d] image_cnt_per_slot[%d]",
                     aTransID, aSessionID, aPID, aSlotSize,
                     sInitTransH.mLogCntPerSlot, sInitTransH.mImageCntPerSlot );

    sInitTransH.mLogStartPos      = MK_POS(-1,-1);
    sInitTransH.mImageStartPos    = MK_POS(-1,-1);
    sInitTransH.mLogCurPos        = MK_POS(-1,-1);
    sInitTransH.mImageCurPos      = MK_POS(-1,-1);
    sInitTransH.mRecoveryStartPos = MK_POS(-1,-1);
    sInitTransH.mLockRecoveryPos  = MK_POS(-1,-1);

    memcpy_s( aHeader, &sInitTransH, sizeof(dbmTransHeader) );
}


/******************************************************************************
 * Name : mInitTran
 *
 * Description
 *     init transaction manager object
 *
 ******************************************************************************/
_VOID dbmTransManager::mInitTran ( char* aUndoName , void* aSessInfo , void* aConfigObj, dbmConnType aConType )
{
    int                 sRC = -1;
    int                 sBucket = -1;
    int                 sTry = 0;
    int                 sMyPID;
    int                 sPidReplacedF = 0;
    dbmSessionObject*   sSessInfo    = (dbmSessionObject*)aSessInfo;
    dbmTransHeader*     sTxHead      = NULL;
    long long           sAllocSlotID = -1;
    dbmLogSlotHeader*   sLogSlotH    = NULL;
    dbmLogSlotHeader*   sImageSlotH  = NULL;
    dbmTransHeader      sTmpTxHead;
    char*               sUserHeader;
    int                 sSlotSize;
    char                sConfigVal[1024];
    long long           sSessID;
    int                 sUndoExist = 0;
    dbmUndoHeader*      sUndoHeader = NULL;
    dbmDicObject        sDicObj;

    long long           sLogBufferSize = 0 ;
    dbmDiskSyncOption   sSyncOption  = FSYNC ;
    int                 sIsCompressF = 0;

    _TRY
    {
        DBM_DBG( "mInitTrans Start. undo(%s)", aUndoName );

        /***********************************************
         * argument check
         ***********************************************/
        if ( aConfigObj == NULL ) //, NO_CONFIG );
        {
            DBM_ERR( "no config" );
            _THROW( ERR_DBM_INVALID_ARGUENT );
        }

//        _IF_THROW( aUndoName  == NULL, INVALID_ARG );
//        _IF_THROW( sSessInfo->mPID <= 0, INVALID_ARG );
        if ( aUndoName == NULL || sSessInfo->mPID <= 0 )
        {
            DBM_ERR( "Invalid Session Infomati" );
            _THROW( ERR_DBM_INVALID_SESS_INFO );
        }

        /***********************************************
         * 멤버변수들에 할당된 메모리 해제 후 초기화.
         * Trace Log Handle 은 생성자에서 이미 셋팅이
         * 되어 있을 수 있기 때문에 이는 살려야 한다.
         ***********************************************/
        _CALL( mFreeTransMgr() );  /* FreeHandle 안했을 수 있으므로 */


        /***********************************************
         * Dictionary Manager 객체 생성 후 존재하는
         * Undo 인지 Dictionary 검색.
         ***********************************************/
        mDic = new dbmDictionary();
        _IF_THROW( mDic == NULL, ERR_DBM_MEM_ALLOC );

        sRC = mDic->mAttach ( );
        if ( sRC != 0 ) //, DIC_PREPARE_FAIL );
        {
            delete_s( mDic );
            DBM_WARN( "Dic Prepare fail. rc=%d (err=%d)", sRC, errno );
            _THROW( ERR_DBM_DICTIONARY_NOT_PREPARED );
        }

        memset_s( &sDicObj, 0x00, sizeof(dbmDicObject) );
        sDicObj.mSQLType = DBM_CREATE_INST;

        sRC = mDic->mGetFirst( &sDicObj );
        _IF_THROW( sRC, ERR_DBM_INVALID_UNDO_NAME );

        if ( ! strcmp_s( sDicObj.mObj.mInstance.mInstanceName, aUndoName) )
        {
            sUndoExist = 1;
        }

        while(1)
        {
            sDicObj.mSQLType = DBM_CREATE_INST;

            sRC = mDic->mGetNext( &sDicObj );
            if ( sRC ) break;

            if ( ! strncmp_s( sDicObj.mObj.mInstance.mInstanceName, aUndoName, strlen_s(aUndoName)) )
            {
                sUndoExist = 1;
                break;
            }
        }
        _IF_THROW( sUndoExist == 0, ERR_DBM_INVALID_UNDO_NAME );


        /***********************************************
         * undo segment attach.
         * invalid 한 undo_name 이라면 여기서 바로 걸러짐.
         ***********************************************/
        sRC = dbmSegmentManager::Attach( aUndoName, aUndoName, &mUndoSegMgr );
        _IF_THROW( sRC, ERR_DBM_ATTACH_SHM_FAIL );

        sUserHeader = mUndoSegMgr->GetUserHeader();
        _IF_THROW( sUserHeader == NULL, ERR_DBM_ATTACH_SHM_FAIL );

        strcpy_s( mInstName, aUndoName );


        /***********************************************
         * DDL Parsing 결과를 저장할 Memory 할당
         ***********************************************/
        mParseObj = (dbmParseObject*)malloc_s( sizeof(dbmParseObject) );
        _IF_THROW( mParseObj == NULL, ERR_DBM_MEM_ALLOC );


        /***********************************************
         * Disk Logging 여부 판단
         ***********************************************/
        mConfigMgr = (dbmConfig * ) aConfigObj;

        /***********************************************
         * lock manager 객체 생성
         ***********************************************/
        mLockMgr = new dbmLockManager();
        _IF_THROW( mLockMgr == NULL, ERR_DBM_MEM_ALLOC );

        mLockMgr->mInitLock( sizeof(dbmTransHeader), (char*)sUserHeader );


        /***********************************************
         * 모든 Transaction 을 돌면서 Tx 잡고 죽은 놈들을
         * 모두 Rollback & FreeTx 시킨다.
         ***********************************************/
        sRC = dbmRecoveryManager::mRecoverAllTrans( mInstName );
        if ( sRC )
        {
            DBM_ERR( "recover all trans fail. undo[%s] rc[%d]", mInstName, sRC );
            //TODO: 2014.12.14. -okt- 복구실패하고 밑으로 진행, 죽어야하는 것 아닌가? ( 2014/07/23 )
        }

        // Replication 으로 들어온 경우
        if ( sSessInfo->mConnType == DBM_REPL_CONNECT )
        {
            sUndoHeader = (dbmUndoHeader *)mGetUndoHead( sUserHeader );

            /* 2014.11.30 -shw- REPL_MEMORY_ENABLE type에 따라 logging 여부를 경정한다 */
            if( sUndoHeader->mAnchor.mReplMemoryEnableF == 1 )
            {
                mDiskLoggingF = 0;
            }
            else
            {
                mDiskLoggingF = sUndoHeader->mAnchor.mLoggerEnableF;
            }

            sBucket = 0 ;
            sMyPID = (int)gettid_s ();

            sTxHead = (dbmTransHeader*)dbmRecoveryManager::mGetTxHead( sUserHeader, sBucket );

            sRC = mLockMgr->mLockPID( (char*)&sTxHead->mPID,
                    sMyPID,
                    &sPidReplacedF );

            if ( sRC != 0 )
            {
                sBucket = 1 ;
                sTxHead = (dbmTransHeader*)dbmRecoveryManager::mGetTxHead( sUserHeader, sBucket );
                sRC = mLockMgr->mLockPID( (char*)&sTxHead->mPID,
                      sMyPID,
                      &sPidReplacedF );

            }

            if ( sRC != 0 )
            {
                assert ("Replication transID 할당 실패"&& 1==0 ) ;
                DBM_ERR( "Replication Undo Alloc Failed [%d]", sBucket );
                _THROW( ERR_DBM_INVALID_TX_BUCKET );
            }


        }
        // Replication 이 아닌 경우
        else
        {

            /***********************************************
             * transaction 할당 및 복구
             ***********************************************/
            sUndoHeader = (dbmUndoHeader *)mGetUndoHead( sUserHeader );
            mDiskLoggingF = sUndoHeader->mAnchor.mLoggerEnableF;

            while ( 1  )
            {
                mGetSessID( sUndoHeader, &sSessID );
                sBucket = sSessID % DBM_MAX_TRANS;


                // 만약 TxID 가 0 이라면 이는 Replication 으로 Reserve
                // 되어있기 때문에 한번 더 딴다.

                if ( sBucket == 0 || sBucket == 1 )
                {
                    continue ;
                }
                else
                {
                    break;
                }

            }

            sMyPID = (int)gettid_s ();
            sTry = 0;

            while ( 1 )
            {
                sTxHead = (dbmTransHeader*)dbmRecoveryManager::mGetTxHead( sUserHeader, sBucket );

                sRC = mLockMgr->mLockPID( (char*)&sTxHead->mPID,
                        sMyPID,
                        &sPidReplacedF );
                if ( sRC == 0 )
                {
                    break;
                }
                else
                {
                    /***********************************************
                     * 없으면 다음Bucket을 시도해본다.
                     ***********************************************/
                    sBucket = sBucket + 1;
                    if ( sBucket >= DBM_MAX_TRANS )
                    {
                        sBucket = 1;
                    }

                    /***********************************************
                     * 시도한 횟수가 Session최대개수의 몇배수여도 실패하면
                     * 진짜 공간이 없다고 판단하고 빠져나온다.
                     ***********************************************/
                    sTry = sTry + 1;
                    if ( sTry == ( DBM_MAX_TRANS * DBM_MAX_TRANS ) ) //, OVER_ERROR );
                    {
                        DBM_ERR( "Undo Slot has no space. sTry[%d]", sTry );
                        mDumpTxTable ( (dbmTransTable*) mGetTxTable ( mUndoSegMgr->GetUserHeader ( ) ) );
                        _THROW( ERR_DBM_TX_NO_SPACE );
                    }
                    continue;
                }
            }


            RTF_POINT( "TXMGR_INIT_TRAN_1" ) ;

            /***********************************************
             * 혹시나 획득하려는 Transaction ID 의 Number가 틀렸을지 모르니
             * DBM_MAX_TRANS 이내인지 체크해본다.
             ***********************************************/
            if ( ( sBucket < 0 || sBucket >= DBM_MAX_TRANS ) ) //, INDEX_ERROR );
            {
                DBM_ERR( "Undo Slot is invalid [%d]", sBucket );
                _THROW( ERR_DBM_INVALID_TX_BUCKET );
            }

        }



        /****************************************************
         * Transaction Header 주소
         ****************************************************/
        mTransID     = sBucket;
        mTransHeader = dbmRecoveryManager::mGetTxHead( sUserHeader, sBucket );


        /****************************************************
         * dbmLogManager 객체 생성
         * 이 Log Manager 객체는 TransManager, TableManager,
         * QueueManager, IndexManager 에게 전달하여 모두 같이 사용한다.
         ****************************************************/
        mLogMgr = new dbmLogManager( mTransHeader,
                                     (char*)sUndoHeader,
                                     mUndoSegMgr );
        if ( mLogMgr == NULL ) //, CREATE_LOGMGR_OBJ_FAIL );
        {
            DBM_ERR( "create logmgr obj fail. sRC(%d) errno(%d)", sRC, errno );
            _THROW( ERR_DBM_MEM_ALLOC );
        }

        /****************************************************
         * dbmDiskLogManager 객체 생성
         ****************************************************/
        if ( mDiskLoggingF > 0 )
        {

            sRC = mConfigMgr->mSearch( mInstName, "DISK_LOG_BUFFER_SIZE", sConfigVal );
            if ( sRC == 0 )
            {
                sLogBufferSize = atol ( sConfigVal ) ;

                sRC = mConfigMgr->mSearch( mInstName, "DISK_LOG_IO_TYPE", sConfigVal );

                if ( sRC == 0 )
                {
                    switch ( atol (sConfigVal ) )
                    {
                        case  0 :
                            sSyncOption = NO_SYNC ;
                            break;
                        case  1 :
                            sSyncOption = FSYNC ;
                            break;
                        case 2 :
                            sSyncOption = SYNC ;
                            break;
                        case 3 :
                            sSyncOption = DIRECT ;
                            break;
                        case 4 :
                            sSyncOption = DIRECT_SYNC;
                            break;
                        default :
                            sSyncOption = FSYNC ;
                            break;
                    } ;
                }
                else
                {
                    sSyncOption = FSYNC ;
                }


                sRC = mConfigMgr->mSearch ( mInstName, "DISK_LOG_COMPRESS" , sConfigVal ) ;
                if ( sRC != 0 )
                {
                    sIsCompressF = 0 ;
                }
                else
                {
                    sIsCompressF = atoi ( sConfigVal ) ;
                }

                if ( sLogBufferSize > 1024 * 1024  )  // 최소 1MB 는 선언되었어야 한다.
                {
#ifdef __linux__    //TODO: [OKT]  윈도포팅
                    if (sIsCompressF == 1 )
                    {
                        mTransLogger = new dbmCompressDiskLogger ( mTransID, &sUndoHeader->mAnchor, sLogBufferSize , sSyncOption) ;
                    }
                    else
                    {
                        mTransLogger = new dbmDiskLogger ( mTransID, &sUndoHeader->mAnchor, sLogBufferSize, sSyncOption ) ;
                    }

#endif /* __linux__ */
                    assert ( mTransLogger != NULL && "Malloc Failed ... \n");

                }
                else
                {

                    /*****************************************************
                     * 이 상황에서 에러가 발생하여 Return 되는 시점에서는
                     * 실제 mTransHeader 의 모든 맴버가 0 으로 세팅되어있다.
                     * 여기서 에러를 발생시키면 실제 freeHandle 을 수행하게 되는데,
                     * 이 과정에서 Recovery 를 수행하게 되고, 이때 0으로 초기화된
                     * 값들때문에 Hang 이 걸리게 된다.
                     *
                     * 이를 막기 위해서 여기서는 에러를 발생시킬때 -1 로 맴버들을
                     * 초기화해서 리턴해야 한다.
                     ***************************************************/
                    ((dbmTransHeader*)mTransHeader)->mLastAllocLogSlot   = -1;
                    ((dbmTransHeader*)mTransHeader)->mLastAllocImageSlot = -1;
                    ((dbmTransHeader*)mTransHeader)->mLogStartPos      = MK_POS(-1,-1);
                    ((dbmTransHeader*)mTransHeader)->mImageStartPos    = MK_POS(-1,-1);
                    ((dbmTransHeader*)mTransHeader)->mLogCurPos    = MK_POS(-1,-1);
                    ((dbmTransHeader*)mTransHeader)->mImageCurPos    = MK_POS(-1,-1);
                    ((dbmTransHeader*)mTransHeader)->mRecoveryStartPos    = MK_POS(-1,-1);
                    ((dbmTransHeader*)mTransHeader)->mLockRecoveryPos    = MK_POS(-1,-1);

                    DBM_ERR ("LOG_BUFFER_SIZE is too small : At least 10 Mbyte or higher.  [%s] ", mInstName ) ;
                    _PRT ( "Invalid configuration. check the alert log file to get more information. \n" ) ;
                    exit ( -1 ) ;

                }

            }
            else
            {
                    /*****************************************************
                     * 이 상황에서 에러가 발생하여 Return 되는 시점에서는
                     * 실제 mTransHeader 의 모든 맴버가 0 으로 세팅되어있다.
                     * 여기서 에러를 발생시키면 실제 freeHandle 을 수행하게 되는데,
                     * 이 과정에서 Recovery 를 수행하게 되고, 이때 0으로 초기화된
                     * 값들때문에 Hang 이 걸리게 된다.
                     *
                     * 이를 막기 위해서 여기서는 에러를 발생시킬때 -1 로 맴버들을
                     * 초기화해서 리턴해야 한다.
                     ***************************************************/
                ((dbmTransHeader*)mTransHeader)->mLastAllocLogSlot   = -1;
                ((dbmTransHeader*)mTransHeader)->mLastAllocImageSlot = -1;
                ((dbmTransHeader*)mTransHeader)->mLogStartPos      = MK_POS(-1,-1);
                ((dbmTransHeader*)mTransHeader)->mImageStartPos    = MK_POS(-1,-1);
                ((dbmTransHeader*)mTransHeader)->mLogCurPos    = MK_POS(-1,-1);
                ((dbmTransHeader*)mTransHeader)->mImageCurPos    = MK_POS(-1,-1);
                ((dbmTransHeader*)mTransHeader)->mRecoveryStartPos    = MK_POS(-1,-1);
                ((dbmTransHeader*)mTransHeader)->mLockRecoveryPos    = MK_POS(-1,-1);



                DBM_ERR ("Invalid LOG_BUFFER_SIZE for instance [%s]", mInstName ) ;
                _PRT ( "Invalid configuration. check the alert log file to get more information. \n" ) ;
                exit ( -1 ) ;
            }
        }


        /****************************************************
         * 죽었다 다시 뜬 경우라면 위쪽의 RecoverTrans 쪽에서
         * 복구할만큼 했을 것이고(버리는 Page 가 생기는건 포기),
         * dbmTransHeader 를 할당한 초기상태로 변경.
         ****************************************************/
        sSlotSize = mUndoSegMgr->GetSlotSize();

        mInitTransItem( sBucket,
                        (dbmTransHeader*)mTransHeader,
                        sSessID,
                        sSessInfo->mUserID,
                        sMyPID,
                        DBM_TX_ALLOC,
                        sSlotSize );

        if ( mDiskLoggingF )
        {
            ( (dbmTransHeader*) mTransHeader )->mDiskLoggingEnableF = 1;
        }


        /****************************************************
         * Logging 을 위한 slot 을 할당해둠.
         ****************************************************/
        memcpy_s(&sTmpTxHead, mTransHeader, sizeof(dbmTransHeader));

        sRC = dbmSegAllocSlot( mUndoSegMgr, &sAllocSlotID );
        _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT );

        sRC = mUndoSegMgr->Slot2Addr(sAllocSlotID, &sLogSlotH);
        _IF_THROW( sRC, ERR_DBM_SLOT2ADDR_FAIL );

        RTF_POINT( "TXMGR_INIT_TRAN_2" )

        dbmInitLogSlot( sLogSlotH, sAllocSlotID );

        sTmpTxHead.mLastAllocLogSlot = sAllocSlotID;
        sTmpTxHead.mLogStartPos      = MK_POS(sAllocSlotID,0);

        RTF_POINT( "TXMGR_INIT_TRAN_3" )


        /****************************************************
         * Image Logging 을 위한 slot 을 할당해둠.
         ****************************************************/
        sAllocSlotID = -1;

        sRC = dbmSegAllocSlot( mUndoSegMgr, &sAllocSlotID );
        _IF_THROW( sRC, ERR_DBM_ALLOC_SLOT );

        sRC = mUndoSegMgr->Slot2Addr(sAllocSlotID, &sImageSlotH);
        _IF_THROW( sRC, ERR_DBM_SLOT2ADDR_FAIL );

        dbmInitLogSlot( sImageSlotH, sAllocSlotID );

        RTF_POINT( "TXMGR_INIT_TRAN_4" )

        sTmpTxHead.mLastAllocImageSlot = sAllocSlotID;
        sTmpTxHead.mImageStartPos      = MK_POS(sAllocSlotID,0);

        memcpy_s(mTransHeader, &sTmpTxHead, sizeof(dbmTransHeader));

        RTF_POINT( "TXMGR_INIT_TRAN_5" )

        /****************************************************
         * 여기서 Dead Lock Manager 를 Initialize 한다
         *************************************************/

         mDeadLockManager = new dbmDeadLockManager (
                  (dbmTransTable*) mUndoSegMgr->GetUserHeader() ,
                   mTransID,
                   mLogMgr ) ;


        _IF_THROW( mDeadLockManager == NULL, ERR_DBM_MEM_ALLOC );

        mDeadLockManager->mUnsetTransHeader();


    }
    _CATCH
    {
        if ( _rc == ERR_DBM_INVALID_UNDO_NAME )
        {
            DBM_WARN( "undo(%s) not exist in dictionay.", aUndoName );
        }
        else if ( _rc == ERR_DBM_ATTACH_SHM_FAIL )
        {
            DBM_ERR( "attach undo seg(%s) fail.", aUndoName );
        }
        else if ( _rc == ERR_DBM_ALLOC_SLOT )
        {
            DBM_ERR( "alloc slot fail. (%s)", aUndoName );
        }
        else if ( _rc == ERR_DBM_SLOT2ADDR_FAIL )
        {
            DBM_ERR("slot to addr fail. (%s)", aUndoName );
        }

        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mInitTran */


/******************************************************************************
 * Name : mPrepareTable
 *     Table 관련 연산이나 함수를 수행할 수 있도록 table manager 객체를
 *     생성하는 작업을 수행한다.
 *     dictionary table 에서 table 정보를 검색하여 table manager 객체와
 *     Index manager 객체를 생성할 수 있도록 한다.
 *
 ******************************************************************************/
_VOID dbmTransManager::mPrepareTable( char* aTableName )
{
    dbmDicObject    sDicObject;
    dbmDicObject    sEventDicObject;
    dbmTableInfo*   sTableInfo;
    int             sTIdx = -1;
    int             sQueueIdx = -1;
    int             sOldUseIndex = -1;
    int             sNewUseIndex = -1;
    int             sIsFound = 0;
    char            sOldUseIndexName[DBM_NAME_LEN];
    int             sIdx = -1;
    int             sRC = -1;

    _TRY
    {

        sTableInfo = &sDicObject.mObj.mTableInfo;

        // 2014.12.09 -lim- #748 dbmPrepare 성능 개선을 위해 dictionary 뒤지는 것을 mFindTableInTx에서 없을때만. (위치이동)
#if 0
        /****************************************************
         * table 정보를 dictionary 로부터 조회한다.
         ****************************************************/
        sDicObject.mSQLType = DBM_CREATE_TABLE;
        strcpy_s ( sTableInfo->mTable.mInstName, mInstName );
        strcpy_s ( sTableInfo->mTable.mTableName, aTableName );

        sRC = mDic->mSelect ( &sDicObject );
        if ( sRC != 0 )
        {
            if ( sRC == ERR_DBM_NO_MATCH_RECORD )
            {
                DBM_INFO( "not found table(%s), search dic fail in mPrepare. rc(%d)", aTableName, sRC );
            }
            else
            {
                DBM_ERR( "search dic fail in mPrepare. table(%s) rc(%d)", aTableName, sRC );
            }
            _THROW( ERR_DBM_TABLE_NOT_IN_DICTIONARY );
        }
#endif

        /***********************************************
         * 사용자가 set index 로 지정해둔 use index 를
         * 저장했다가 unprepare->prepare  이후에 해당
         * index name 의 index 를 use index 로 다시 지정해둔다.
         ***********************************************/
        sRC = mFindTableInTx ( aTableName, &sTIdx );
        if ( likely( sRC == 0 ) ) // && sTIdx >= 0 )
        {
            /*********************************************
             * 여기 들어왔다는 건 테이블이 이미 Prepare 되어있다는 말임.
             * 여기서 내가 가진 Table Header 와 Shm 에 존재하는 Table Header
             * 의 DDL Count 를 비교하여 같으면 패스
             ********************************************/
            if ( mTable[sTIdx]->mGetTableHeader()->mDDLCount == mTableDDLCount[sTIdx] &&
                 mTable[sTIdx]->mGetTableID() == mTable[sTIdx]->mGetTableHeader()->mTableObj.mTableID )
            {
                return RC_SUCCESS;
            }

            if ( mTable[sTIdx]->mGetSetIndexF ( ) > 0 )
            {
                memset_s ( sOldUseIndexName, 0x00, DBM_NAME_LEN );
                sOldUseIndex = mTable[sTIdx]->mGetUseIndex ( );
                strcpy_s ( sOldUseIndexName, mTable[sTIdx]->mGetIndexMgrByIdx ( sOldUseIndex )->mGetIndexName ( ) );
            }
        }
        else
        {
            // prepare 처음이면 do nothing

            // 2014.11.18. -okt- 추가. 혹시 다른 타입이면.
            sRC = mFindQueueInTx ( aTableName, &sTIdx );
            if ( sRC == 0 ) // && sTIdx >= 0 )
            {
                /*********************************************
                 * 여기 들어왔다는 건 테이블이 이미 Prepare 되어있다는 말임.
                 * 여기서 내가 가진 Table Header 와 Shm 에 존재하는 Table Header
                 * 의 DDL Count 를 비교하여 같으면 패스
                 *
                 * Table ID 도 비교해야해
                 ********************************************/
                if ( mQueue[sTIdx]->mGetQueueHeader()->mDDLCount == mQueueDDLCount[sTIdx] &&
                     mQueue[sTIdx]->mGetQueueHeader()->mTableObj.mTableID == mQueue[sTIdx]->mGetQueueID ()  )
                {
                    return RC_SUCCESS;
                }
            }
            else
            {
                // prepare 처음이면 do nothing

                // 2014.11.18. -okt- 추가. 혹시 다른 타입이면.
                sRC = mFindListInTx ( aTableName, &sTIdx );
                if ( sRC == RC_SUCCESS && sTIdx >= 0 )
                {
                    /* prepare 된놈은 또할 필요 없다 */
                    if ( mList[sTIdx]->mGetListHeader()->mDDLCount == mListDDLCount[sTIdx] &&
                         mList[sTIdx]->mGetListHeader()->mTableObj.mTableID == mList[sTIdx]->mGetListID ()  )
                    {
                        return RC_SUCCESS;
                    }
                }
                else
                {
                    // prepare 처음이면 do nothing
                }
            }
        }

        // 2014.12.09 -lim- #748 dbmPrepare 성능 개선을 위해 dictionary 뒤지는 것을 mFindTableInTx에서 없을때만. (위치이동)
        {
            /****************************************************
             * table 정보를 dictionary 로부터 조회한다.
             ****************************************************/
            sDicObject.mSQLType = DBM_CREATE_TABLE;
            strcpy_s ( sTableInfo->mTable.mInstName, mInstName );
            strcpy_s ( sTableInfo->mTable.mTableName, aTableName );

            sRC = mDic->mSelect ( &sDicObject );
            if ( sRC != 0 )
            {
                if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                {
                    DBM_INFO( "not found table(%s), search dic fail in mPrepare. rc(%d)", aTableName, sRC );
                }
                else
                {
                    DBM_ERR( "search dic fail in mPrepare. table(%s) rc(%d)", aTableName, sRC );
                }
                _THROW( ERR_DBM_TABLE_NOT_IN_DICTIONARY );
            }
        }

        /****************************************************
         * Table/Queue/List Manager 객체 생성
         * 중간에 Index 상황이 변했을 수 있기 때문에
         * 최신의 정보를 가지고 다시 Prepare
         ****************************************************/
        if ( sTableInfo->mTable.mTableType == DBM_TBL_LIST )
        {
            _IF_THROW( mListCount >= DBM_MAX_TABLE_PER_TRANS,ERR_DBM_TOO_MANY_PREPARE_TABLE );

            sRC = mUnprepareTable( sTableInfo->mTable.mTableName, sTableInfo->mTable.mTableType );

            mList[mListCount] = new dbmListManager();

            _IF_THROW( mList[mListCount] == NULL, ERR_DBM_MEM_ALLOC );

            _CALL( mList[mListCount]->mInitList( mInstName,
                                                 sTableInfo->mTable.mTableName,
                                                 &sDicObject,
                                                 mLogMgr,
                                                 mLockMgr ) );

            mListDDLCount[mListCount] = ((dbmListHeader*)mList[mListCount]->mGetListHeader())->mDDLCount;
            _CALL( mList[mListCount]->mSetTransLogger ( mTransLogger) );

            mListCount++;
        }
        else if ( sTableInfo->mTable.mTableType == DBM_TBL_QUEUE )
        {
            _IF_THROW( mQueueCount >= DBM_MAX_TABLE_PER_TRANS, ERR_DBM_TOO_MANY_PREPARE_TABLE );

            sRC = mUnprepareTable ( sTableInfo->mTable.mTableName, sTableInfo->mTable.mTableType );
            mQueue[mQueueCount] = new dbmQueueManager ( );
            _IF_THROW ( mQueue[mQueueCount] == NULL, ERR_DBM_MEM_ALLOC );

            _CALL ( mQueue[mQueueCount]->mInitQueue ( mInstName,
                                                      sTableInfo->mTable.mTableName,
                                                      &sDicObject,
                                                      mLogMgr,
                                                      mLockMgr ) );
            mQueueDDLCount[mQueueCount] = ((dbmQueueHeader*)mQueue[mQueueCount]->mGetQueueHeader())->mDDLCount;
            _CALL( mQueue[mQueueCount]->mSetTransLogger ( mTransLogger) );
            mQueueCount++;
        }
        else // DBM_TBL_NORMAL or  DBM_TBL_DIRECT
        {
            _IF_THROW( mTableCount >= DBM_MAX_TABLE_PER_TRANS, ERR_DBM_TOO_MANY_PREPARE_TABLE );

            sRC = mUnprepareTable ( sTableInfo->mTable.mTableName, sTableInfo->mTable.mTableType );

            /****************************************************
             * Table 객체를 생성한 후 mInitTable 을 호출하여
             * Table Manager 가 Index Manager 를 생성하도록 한다.
             ****************************************************/
            mTable[mTableCount] = new dbmTableManager ( );
            _IF_THROW ( mTable[mTableCount] == NULL, ERR_DBM_MEM_ALLOC );

            _CALL ( mTable[mTableCount]->mInitTable ( mInstName,
                                                      sTableInfo->mTable.mTableName,
                                                      sTableInfo->mIndexCount,
                                                      sTableInfo->mIndex,
                                                      &sDicObject,
                                                      mLogMgr,
                                                      mLockMgr,
                                                      mDeadLockManager) );
            if ( sOldUseIndex >= 0 )
            {
                /***********************************************
                 * 저장된 old use index name 으로 index 를
                 * 찾아서 해당 index 로 use index 셋팅.
                 * 없어진 index 이면 그냥 default 0 으로.
                 ***********************************************/
                sRC = mFindIndexInTbl ( mTable[mTableCount], sOldUseIndexName, &sNewUseIndex );
                if ( sRC == 0 )
                {
                    mTable[mTableCount]->mSetUseIndex ( sNewUseIndex );
                    mTable[mTableCount]->mSetSetIndexF ( );
                }
                else
                {
                    // default index 0
                }
            }


            /***************************************************************
             * Table 을 Prepare 하고 보니 Trigger 가 존재했다면
             * 이걸 가지고 Queue Manager 를 생성한다. 근데 막 만들면 안대고
             * 동일한 Object 가 있는지 체크하고 만들어야한다.
             **************************************************************/
            if ( mTable[mTableCount]->mGetTableHeader ( )->mEventQueue[0] == '\0' )
            {
                // 할게 없다.
            }
            else
            {
                /********************************************************
                 * 변경상황을 로깅할 Queue 가 필요하다. 그냥 만들면 안되고 ,
                 * 먼저 해당 이름이 존재하는지 체크를 한담에 처리해야함.
                 *******************************************************/
retry :
                sRC = mFindQueueInTx ( mTable[mTableCount]->mGetTableHeader ( )->mEventQueue, &sIdx );
                if ( sRC == 0 && sIdx >= 0 )
                {
                    /********************************************************
                     * 찾았으므로 Table Manager 에게 내가 로깅할 Queue 를 알려준다.
                     *******************************************************/
                    mTable[mTableCount]->mSetTrigger ( mQueue[sIdx] );

                }
                else
                {
                    /********************************************************
                     * 못 찾았으므로 새로운 Queue 를 생성한다.
                     * Recursive 가 발생하는데, 뭐 한번이면 괜찮겠지
                     *******************************************************/
                    sRC = mPrepareTable ( mTable[mTableCount]->mGetTableHeader ( )->mEventQueue );

                    if ( sRC != RC_SUCCESS )
                    {
                        _THROW( ERR_DBM_TABLE_NOT_IN_DICTIONARY );
                    }
                    goto retry;
                }
            }

            /***********************************************
             * Table 을 모두 다 만들었으니 DDL Count
             **********************************************/
            mTableDDLCount[mTableCount] = ((dbmTableHeader*)mTable[mTableCount]->mGetTableHeader())->mDDLCount;
            mTableCount++;
        }

        DBM_DBG( "prepare table ok. [%s]", sTableInfo->mTable.mTableName );
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_TABLE_NOT_IN_DICTIONARY )
        {
            _CATCH_DBG;
        }
        else
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mPrepareTable */


/******************************************************************************
 * Name : mFinalTran
 *
 * Description
 *     Finalize( opposition of mInitTran )
 *     사용자가 호출하면 이 Transaction Manager 객체가 관리하던
 *     모든 자원을 반납하고 Transaction Header 및 Log Page 들도 반납한다.
 *     Transaction Manager 객체가 있는 환경에서 호출된다.
 *
 ******************************************************************************/
_VOID dbmTransManager::mFinalTran ( )
{
    _TRY
    {
        if ( mTransID < 0 )
        {
            _RETURN;
        }

        DBM_DBG( "final trans[%d] start.", mTransID );

        /***********************************************
         * Transaction 에 할당된 모든 slot 반납 및
         * Tx Header 초기화
         ***********************************************/
        if ( mTransHeader != NULL )
        {
            /*
             * 2014.12.14. -okt- 2014.09.21 여기서 오류처리 하면 안된다.
             *             ERR-1049] Invalid undo log. (err=25,tid=15381,l=1011)
             */
            //_CALL( mActNormalRollback ( ) );
            mActNormalRollback ( );

            _CALL( dbmLogManager::mFreeAllSlotList ( 0, mUndoSegMgr, (dbmTransHeader*) mTransHeader ) );
            _CALL( dbmRecoveryManager::mClearTransItem ( (dbmTransHeader*) mTransHeader ) );
        }

        _CALL( mFreeTransMgr ( ) );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


/******************************************************************************
 * Name : mAct
 *
 * Description
 *     Transaction End
 *
 * Argument
 *     aData   : input   : pointer to dbmDataObject
 *
 ******************************************************************************/
_VOID dbmTransManager::mAct( void* aHandle )
{
    int             sTIdx     = -1;
    int             sNeedPartialRollbackF = 0;
    long long       sBackupLogPos   = -1;
    long long       sBackupImagePos = -1;
    long long       sRollbackStartLogPos   = -1;
    long long       sRollbackStartImagePos = -1;
    dbmTransHeader* sTxHead = (dbmTransHeader*)mTransHeader;
    dbmDataObject*  sData   = NULL;
    dbmDicObject*   sDic    = NULL;
    int             bNeedPartialRollback = 0;
    int             sRowSize = 0;
    int             sQueueF = 0;
    dbmTransHeader* sTransHeader =  (dbmTransHeader*) mTransHeader;
    int             i;
    int             sRet;

    _TRY
    {
        _DASSERT( aHandle != NULL );
        sData = &((dbmInternalHandle*)aHandle)->mData;
        mData = sData;

        /***********************************************
         * Handle 의 옵션처리
         ***********************************************/
        if ( unlikely ( sData->mTransType == DBM_SET_OPTION || sData->mTransType == DBM_GET_OPTION ) )
        {
            return mActSessionOption ( sData , &sData->mOptionVal);
        }

        /***********************************************
         * DDL 처리 - Parsing 이 필요한 DDL
         ***********************************************/
        if ( unlikely ( sData->mTransType < 0 ) )
        {
            _IF_THROW( dbmParser::mParse( sData->mUserData, mParseObj ) , ERR_DBM_SQL_PARSE );
            if ( mParseObj->mSQLType >= DBM_DDL_TYPE )
            {
                return mActDDL( (void*)mParseObj );
            }
            else
            {
                _THROW( ERR_DBM_SQL_PARSE );
            }
        }


        /***********************************************
         * Prepare 된 Table/Queue 인지 검색.
         * (DBM_CLEAR_BIND 제외)
         ***********************************************/
        if ( likely( sData->mTransType < DBM_TRANS_TYPE ) )
        {
            if ( sData->mTransType == DBM_SELECT_ROWSIZE )
            {
                /***********************************************
                 * RowSize 는 Queue 이든 Table 이든 걸리는걸로.
                 ***********************************************/
                _rc = mFindTableInTx( sData->mTableName, &sTIdx );
                if ( unlikely( _rc ) ) //|| sTIdx < 0 ) // 2014.11.18. -okt- [perf] 상위단에서 조건검사 한번만 하자.
                {
                    _rc = mFindQueueInTx( sData->mTableName, &sTIdx );
                    _IF_THROW( _rc, ERR_DBM_TABLE_NOT_PREPARED );

                    sQueueF = 1;
                }
            }
            else
            {
                switch( sData->mTransType )
                {
                    case DBM_LIST_LPUSH:
                    case DBM_LIST_RPUSH:
                    case DBM_LIST_LPOP:
                    case DBM_LIST_RPOP:
                    case DBM_LIST_RANGE:
                        _rc = mFindListInTx( sData->mTableName, &sTIdx );
                        _IF_THROW( _rc || sTIdx < 0, ERR_DBM_TABLE_NOT_PREPARED );
                        break;

                    case DBM_ENQUE:
                    case DBM_DEQUE:
#ifdef _DEBUG
                    // 미구현
                    case DBM_DEQUE_MORE:
                    case DBM_DEQUE_ARRAY:
#endif
                        _rc = mFindQueueInTx( sData->mTableName, &sTIdx );
                        _IF_THROW( _rc, ERR_DBM_TABLE_NOT_PREPARED );
                        break;

                    default:
                        if ( sData->mTransType != DBM_CLEAR_BIND )
                        {
                            /***********************************************
                             * 사용자에 의한 변경 DML 이 Dictionary Table 에
                             * 발생할 경우 차단.
                             ***********************************************/
                            if ( sData->mTransType >= DBM_CHG_DML_TYPE )
                            {
#ifdef _DEBUG
                                if ( !strncmp_s ( sData->mTableName, SYS_DIC_PREFIX, strlen_s ( SYS_DIC_PREFIX ) ) )
#else
                                if ( sData->mTableName[0] == SYS_DIC_PREFIX_CHAR )   // (성능)
#endif
                                {
                                    _THROW( ERR_DBM_DML_DIC_TABLE );
                                }
                            }

                            _rc = mFindTableInTx( sData->mTableName, &sTIdx );
                            // 2014.11.18. -okt- [perf] 상위단에서 조건검사 한번만 하자.
                            _IF_THROW( _rc /* || sTIdx < 0 */, ERR_DBM_TABLE_NOT_PREPARED );
                        }
                        break;
                } /* switch */
            }
        }

        /* 2015.07.23 -shw- */
        /* 참고:
         * mBackupLogPos 값을 임의로 mBackupLogPos 넣어서 처리 했는데 이렇게 되면 파셜롤빽 
         * 처리 후 mLogCurPos에 해당 값을 넣게 된다. 그런데 이렇게 넣어도 문제가 되지 않는
         * 이유는 어차피 sTxHead->mLogCurPos -1일 때는 sTxHead->mLogStartPos 값을 넣어 해당값이
         * mLogStartPos 부터 시작 하지는 않지만 뭐 상관은 없다. 그리고 commit & rollback 처리 시
         * 초기화 된다. sTxHead->mLogCurPos 1일 때는 기존의 value가 그대로 동일하게 가기
         * 때문에 상관이 없다 Image 그대로 가기 때문에 문제가 없다. 여기서 잘못되면 나중에
         * 문제 발생 시 정말 찾기 힘들다. 아래와 같이 해도 되는 것인지 잘 판단해야 한다 */ 
        if ( sData->mTransType == DBM_DELETE || sData->mTransType == DBM_UPDATE ) 
        {
            if ( sData->mLogCheck == 1 && sData->mFirstLogCheck == 1 )
            {
                /***********************************************
                 * DML 실패 시 PartialRollback 기준으로 삼을 위치 백업.
                 ***********************************************/
                // 아래도 마찬가치로 현재 로그를 쓸려고 하는 시점자체가
                // 아직 아무런 Tx도 기록하지 않았기 때문에
                // 여기까지 롤백해버려야 함
                // 따라서, 의도한바라면 TxHead의 CurPos리커버리 해야 할 시점 아닐까
#if 0
                if ( sTxHead->mLogCurPos == -1 )
                {
                    /* Recovery 시 Backup  후부터 해당 Recovery 하기 때문에 
                     * -1 들어왔을 시 맞츄어 주기 위해 -1를 한다 */
                    /* partial rollback 처리 시 초기값이 원래는 -1였다. 이에 해당 LogCurPos를
                     * 초기화 해주지 않으면 mRollbackRecovery 처리 시 잘못된 LoccurPos을 가지고
                     * rollback를 해서 handle이 깨질수 있다 이에 user data를 mData에 넘겨 partial
                     * rollback 처리 시 해당 값을 체크 -1를 초기화를 해주도록 한다 */
                    sData->mBackupLogPos = sTxHead->mLogStartPos - 1;
                    sData->mPartialCheck = 1;
                }
                else
                {
                    sData->mBackupLogPos = sTxHead->mLogCurPos;
                }
#endif

                // 여기에 왔다는거는 이 트랜잭션이 Range 연산일꺼란거고
                // 그러니까 Partial Rollback이 필요한거고
                // 현 로그를 쓸 시점이 롤백을 해야 할 위치라고 가정하고 위를 다 주석으로 막고
                // 아래처럼 했다.
                sData->mPartialCheck = 1;
                sData->mBackupLogPos = sTxHead->mLogCurPos;
                sData->mBackupImagePos = sTxHead->mImageCurPos;
                DBM_INFO("PartialRollback Setting BackupLogPos[%d:%d]\n", SLOTID(sData->mBackupLogPos), OFFSET(sData->mBackupLogPos));
            }
        }

        /***********************************************
        * DML 실패 시 PartialRollback 기준으로 삼을 위치 백업.
        ***********************************************/
        // 새롭게 시작된 Transaction임을 의미하기 위해 
        // 최초 1회에만 SCN을 증가시키면서 그 번호를 간직하자.
        // 어따 쓰지는 않는다. mActCommit시점에 다시 SCN을 따서 쓸것임.
        if (sTxHead->mLogCurPos == -1)
        {
            mLogMgr->mGetSCN ( &sTxHead->mSCN );
        }

        sBackupLogPos   = sTxHead->mLogCurPos;
        sBackupImagePos = sTxHead->mImageCurPos;


        /*
         * TODO: [OKT] #886 dbmFetchNextGT 를 따라가면 bNeedPartialRollback 이 1이면 비교를 한번 더 탄다.
         *       소소한으로 셋팅한다.
         *       1) 나중에 BITAND 처리를 하던지.
         *       2) 변경에 대해서 MAX를 정해서. 재 배치를 하면 추가 개선 가능
         */
        // bNeedPartialRollback = 1;
        switch( sData->mTransType )
        {
            case DBM_LIST_LPUSH:
            case DBM_LIST_RPUSH:
            case DBM_LIST_LPOP:
            case DBM_LIST_RPOP:
            case DBM_INSERT:
            case DBM_DELETE:
            case DBM_UPDATE:
            case DBM_SELECT_FOR_UPDATE:
            case DBM_COMMIT:
            case DBM_DEFER_COMMIT:
            case DBM_DEFER_SYNC:
            case DBM_ROLLBACK:
            case DBM_UPDATE_COL:
            case DBM_ENQUE:
            case DBM_DEQUE:
            case DBM_SET_INDEX:
            case DBM_DROP_TABLE:
            case DBM_DROP_QUEUE:
            case DBM_DROP_SEQUENCE:
            case DBM_DROP_LIST:
            case DBM_DROP_INDEX:
            case DBM_TRUNCATE:
                bNeedPartialRollback = 1;
                break;

            default:
                NULL;
                break;
        } /* switch( sData->mTransType ) */

        switch( sData->mTransType )
        {
            case DBM_LIST_LPUSH:
                sNeedPartialRollbackF = 1;
                _CALL( mList[sTIdx]->mListLpush( mTransID, sData ) );
                break;

            case DBM_LIST_RPUSH:
                sNeedPartialRollbackF = 1;
                _CALL( mList[sTIdx]->mListRpush( mTransID, sData ) );
                break;

            case DBM_LIST_LPOP:
                sNeedPartialRollbackF = 1;
                _CALL( mList[sTIdx]->mListLpop( mTransID, sData ) );
                break;

            case DBM_LIST_RPOP:
                sNeedPartialRollbackF = 1;
                _CALL( mList[sTIdx]->mListRpop( mTransID, sData ) );
                break;

            case DBM_LIST_RANGE:
                sNeedPartialRollbackF = 1;
                _CALL( mList[sTIdx]->mListRange( mTransID, sData ) );
                break;
            case DBM_INSERT:
                sNeedPartialRollbackF = 1;
                _rc = mTable[sTIdx]->mInsert( mTransID,
                                              sData,
                                              sTxHead,
                                              &sRollbackStartLogPos,
                                              &sRollbackStartImagePos );

                /***********************************************
                 * Trigger 가 실패한 경우 Partial Rollback 따위 없음.
                 * 전 Transaction Rolback
                 ***********************************************/
                if ( _rc == ERR_DBM_TRIGGER_FAIL )
                {
                    _THROW (_rc) ;
                }

                /***********************************************
                 * Partial Rollback 을 시작할 위치 설정.
                 * Dup Error 등이 발생하면 Insert Key Log 는 Rollback
                 * 처리하면 안됨 - Delete Key 를 수행해버리기 때문에.
                 ***********************************************/
                if ( _rc != 0 )
                {
                    if ( sRollbackStartLogPos != -1 )
                    {
                        sTxHead->mLogCurPos = sRollbackStartLogPos;
                        sTxHead->mImageCurPos = sRollbackStartImagePos;
                    }
                    _THROW( _rc );
                }
                break;

            case DBM_DELETE:
                sNeedPartialRollbackF = 1;

                /* 2014.08.03 -shw- sRollbackStartLogPos,sRollbackStartImagePos 추가
                   (delete, update,selectforupdate,updatecol) */
                _rc = mTable[sTIdx]->mDelete( mTransID, sData, sTxHead, &sRollbackStartLogPos, &sRollbackStartImagePos );

                // 에러가 나면 롤백을 해야 함.
                // 그런데, Range처리는 정상완료임에도 리턴값을 DBM_NO_MATCH_RECORD로 줘야
                // 상위API에서 종료가 가능함. 아래의 코드는 그런 정상상황과 진짜오류상황을 구분하기 위함임.
                // 진짜오류인경우는 롤백시작위치를 key-operation log 상위로 앞당기는 것과 같다.
                if ( _rc != 0 )
                {
                    // 정상적으로 끝까지 순회를 한상태에서 나오는 경우임
                    // 그래서 상위 Range API로 동일하게 끝났음을 알리는 경우이기 때문에
                    // 롤백할게 없도록 셋팅해야 함
                    if ( _rc == ERR_DBM_NO_MATCH_RECORD )
                    {
                        sBackupLogPos = sTxHead->mLogCurPos;
                        sBackupImagePos = sTxHead->mImageCurPos;
                    }
                    // 뭔가 오류가 진짜 발생한 경우
                    else 
                    {
                        // Range처리인 경우는 최초에 얻어낸 로그시작위치까지 롤백을 해야 함
                        // 그렇지 않은 경우는 여기 오기 직전 Switch코드 앞단에서
                        // 이미 sBackupLogPos가 구해졌음으로 그 위치까지 롤백수행하면 됨
                        if ( sData->mLogCheck == 1)
                        {
                             sBackupLogPos = sData->mBackupLogPos;
                             sBackupImagePos = sData->mBackupImagePos;
                        }
                    }
                    DBM_INFO ("Delete Throw BackupLogPos[%d:%d], sRollbackStartLogPos[%d:%d]\n",
                                    SLOTID(sBackupLogPos), OFFSET(sBackupLogPos),
                                    SLOTID(sRollbackStartLogPos), OFFSET(sRollbackStartLogPos));
                    _THROW( _rc );
                }
                break;

            case DBM_UPDATE:
                sNeedPartialRollbackF = 1;

                _rc = mTable[sTIdx]->mUpdate( mTransID, sData, sTxHead, &sRollbackStartLogPos, &sRollbackStartImagePos );

                if ( _rc != 0 )
                {
                    // 정상적으로 끝까지 순회를 한상태에서 나오는 경우임
                    // 그래서 상위 Range API로 동일하게 끝났음을 알리는 경우이기 때문에
                    // 롤백할게 없도록 셋팅해야 함
                    if ( _rc == ERR_DBM_NO_MATCH_RECORD )
                    {
                        sBackupLogPos = sTxHead->mLogCurPos;
                        sBackupImagePos = sTxHead->mImageCurPos;
                    }
                    // 뭔가 오류가 진짜 발생한 경우
                    else 
                    {
                        // Update의 경우는 Delete와 달리 insert-key operation이 실패할 수 있다.
                        // 이 경우 insert_key_log는 로깅이 된 상태임으로
                        // 이 로그를 Skip해야 한다. (롤백해서 delete-key를 절대 하면 안된다.)
                        // 따라서, 이때에는 롤백시작점을 이동시켜야 함
                        if (sRollbackStartLogPos != -1)
                        {
                            sTxHead->mLogCurPos = sRollbackStartLogPos;
                            sTxHead->mImageCurPos = sRollbackStartImagePos;
                        }
                        // Range처리인 경우는 최초에 얻어낸 로그시작위치까지 롤백을 해야 함
                        // 그렇지 않은 경우는 여기 오기 직전 Switch코드 앞단에서
                        // 이미 sBackupLogPos가 구해졌음으로 그 위치까지 롤백수행하면 됨
                        if ( sData->mLogCheck == 1)
                        {
                             sBackupLogPos = sData->mBackupLogPos;
                             sBackupImagePos = sData->mBackupImagePos;
                        }
                    }
                    DBM_INFO ("Update Throw BackupLogPos[%d:%d], sRollbackStartLogPos[%d:%d]\n",
                                    SLOTID(sBackupLogPos), OFFSET(sBackupLogPos),
                                    SLOTID(sRollbackStartLogPos), OFFSET(sRollbackStartLogPos));
                    _THROW( _rc );
                }
 
                break;

            case DBM_SELECT_DIRTY:
                _CALL( mTable[sTIdx]->mSelect( mTransID, sData, DBM_DIRTY_ON ) );
                break;

            case DBM_SELECT:
                _CALL( mTable[sTIdx]->mSelect( mTransID, sData, DBM_DIRTY_OFF ) );
                break;

            case DBM_SELECT_FOR_UPDATE:     // 33
                sNeedPartialRollbackF = 1;

                _rc = mTable[sTIdx]->mSelectForUpdate( mTransID, sData, sTxHead, &sRollbackStartLogPos, &sRollbackStartImagePos );

                if ( _rc != 0 )
                {
                    if ( _rc == ERR_DBM_NO_MATCH_RECORD )
                    {
                        sBackupLogPos = sTxHead->mLogCurPos;
                        sBackupImagePos = sTxHead->mImageCurPos;
                    }
                    else
                    {
                        if ( sRollbackStartLogPos != -1 )
                        {

                            // fhan:non-unique index에서 2건 이상에 작업을 할 경우 롤백 포인트가 맞지 않아 주석처리함.
                            // 2015.07.16 -shw- 위에서 fhan이 아래의 sBackupLogPos, sBackupImagePos을 막았는데 막은 이유는
                            // PartialRollback 처리 시 백업해 놓은 이미지랑 같은면 rollback을 하지 않기 때문에 아래의 두부
                            // 분을 막았는데 이렇게 하다보니 ERR_DBM_NO_MATCH_RECORD 일 때에는 혹시 로깅한게 있을 수 도 있는
                            // 데 못하는 수가 발생 할 수 있다. 아래의 두부분을 사용 하더라. 그래서 ERR_DBM_NO_MATCH_RECORD
                            // 때에는 sBackupLogPos, sBackupImagePos를 사용 하도록 하였다.
                            /*
                            if ( _rc == ERR_DBM_NO_MATCH_RECORD )
                            {
                                sBackupLogPos = sRollbackStartLogPos;
                                sBackupImagePos = sRollbackStartImagePos;
                            }
                            */

                            sTxHead->mLogCurPos = sRollbackStartLogPos;
                            sTxHead->mImageCurPos = sRollbackStartImagePos;

                        }
                    }
                    _THROW( _rc );
                }
                break;

            case DBM_COMMIT:
                bNeedPartialRollback = 0;
                _CALL( mActCommit() );
                _RETURN;
                break;

            case DBM_DEFER_COMMIT:
                bNeedPartialRollback = 0;
                _CALL( mDeferCommit() );
                _RETURN;
                break;

            case DBM_DEFER_SYNC:
                bNeedPartialRollback = 0;
                _CALL( mDeferSync() );
                _RETURN;
                break;

            case DBM_ROLLBACK:
                bNeedPartialRollback = 0;
                _CALL( mActNormalRollback() );
                _RETURN;
                break;

            case DBM_CUR_CLOSE:
                _RETURN;
                break;

            case DBM_SELECT_ROWSIZE:
                if ( sQueueF == 1 )
                {
                    sRowSize = mQueue[sTIdx]->mGetMsgSize();
                }
                else
                {
                    sRowSize = mTable[sTIdx]->mGetRowSize();
                }
                *(int *)sData->mUserData = sRowSize;
                break;

            case DBM_SELECT_MAX:
                _CALL( mTable[sTIdx]->mSelectMax ( mTransID, sData ) );
                break;

            case DBM_SELECT_MIN:
                _CALL( mTable[sTIdx]->mSelectMin ( mTransID, sData ) );
                break;

            case DBM_SELECT_GT_DIRTY:
                /* 2014.04.30 -shw- index type 추가  */
                _CALL( mTable[sTIdx]->mSelectGT ( mTransID, sData, DBM_DIRTY_ON ) );
                break;

            case DBM_SELECT_GT:
                /* 2014.04.30 -shw- index type 추가  */
                _CALL( mTable[sTIdx]->mSelectGT ( mTransID, sData, DBM_DIRTY_OFF ) );
                break;

            case DBM_SELECT_LT_DIRTY:
                /* 2014.04.30 -shw- index type 추가  */
                _CALL( mTable[sTIdx]->mSelectLT ( mTransID, sData, DBM_DIRTY_ON ) );
                break;

            case DBM_SELECT_LT:
                /* 2014.04.30 -shw- index type 추가  */
                _CALL( mTable[sTIdx]->mSelectLT ( mTransID, sData, DBM_DIRTY_OFF ) );
                break;

                /* 2014.06.23 -shw- module 추가 */
            case DBM_FETCH:
                _CALL( mTable[sTIdx]->mFetch ( mTransID, sData ) )
                ;
                break;

            case DBM_FETCH_NEXT_GT:
                _CALL( mTable[sTIdx]->mFetchNextGT ( mTransID, sData ) );
                break;

            case DBM_FETCH_NEXT_LT:
                _CALL( mTable[sTIdx]->mFetchNextLT ( mTransID, sData ) );
                break;

            case DBM_FETCH_RANGE:
                _CALL( mTable[sTIdx]->mFetchRange( mTransID, sData ) );
                break;

            case DBM_BIND_COL:
                _CALL( mTable[sTIdx]->mBindCol( mTransID, sData ) );
                break;

            case DBM_UPDATE_COL:
                sNeedPartialRollbackF = 1;

                _rc = mTable[sTIdx]->mUpdateCol( mTransID, sData, sTxHead, &sRollbackStartLogPos, &sRollbackStartImagePos );
                if ( _rc != 0 )
                {
                    if ( _rc == ERR_DBM_NO_MATCH_RECORD )
                    {
                        //sBackupLogPos = sRollbackStartLogPos;
                        //sBackupImagePos = sRollbackStartImagePos;
                        sBackupLogPos = sTxHead->mLogCurPos;
                        sBackupImagePos = sTxHead->mImageCurPos;
                    }
                    else
                    {
                        if ( sRollbackStartLogPos != -1 )
                        {
                            sTxHead->mLogCurPos = sRollbackStartLogPos;
                            sTxHead->mImageCurPos = sRollbackStartImagePos;
                        }

                        if ( sData->mLogCheck == 1 )
                        {
                            sBackupLogPos = sData->mBackupLogPos;
                            sBackupImagePos = sData->mBackupImagePos;
                        }
                    }
                    DBM_INFO ("UpdateCol Throw BackupLogPos[%d:%d], sRollbackStartLogPos[%d:%d]\n",
                                    SLOTID(sBackupLogPos), OFFSET(sBackupLogPos),
                                    SLOTID(sRollbackStartLogPos), OFFSET(sRollbackStartLogPos));
                    _THROW( _rc );
                }

                break;

            case DBM_UPDATE_COL_GT:
                sNeedPartialRollbackF = 1;

                _rc = mTable[sTIdx]->mUpdateColGT( mTransID, sData, sTxHead, &sRollbackStartLogPos, &sRollbackStartImagePos );
                if ( _rc != 0 )
                {
                    if ( _rc == ERR_DBM_NO_MATCH_RECORD )
                    {
                        //sBackupLogPos = sRollbackStartLogPos;
                        //sBackupImagePos = sRollbackStartImagePos;
                        sBackupLogPos = sTxHead->mLogCurPos;
                        sBackupImagePos = sTxHead->mImageCurPos;
                    }
                    else
                    {
                        if ( sRollbackStartLogPos != -1 )
                        {
                            sTxHead->mLogCurPos = sRollbackStartLogPos;
                            sTxHead->mImageCurPos = sRollbackStartImagePos;
                        }

                        if ( sData->mLogCheck == 1 )
                        {
                            sBackupLogPos = sData->mBackupLogPos;
                            sBackupImagePos = sData->mBackupImagePos;
                        }
                    }
                    DBM_INFO ("UpdateColGT Throw BackupLogPos[%d:%d], sRollbackStartLogPos[%d:%d]\n",
                                    SLOTID(sBackupLogPos), OFFSET(sBackupLogPos),
                                    SLOTID(sRollbackStartLogPos), OFFSET(sRollbackStartLogPos));
                    _THROW( _rc );
                }

                break;

            case DBM_UPDATE_COL_LT:
                sNeedPartialRollbackF = 1;

                _rc = mTable[sTIdx]->mUpdateColLT( mTransID, sData, sTxHead, &sRollbackStartLogPos, &sRollbackStartImagePos );
                if ( _rc != 0 )
                {
                    if ( _rc == ERR_DBM_NO_MATCH_RECORD )
                    {
                        //sBackupLogPos = sRollbackStartLogPos;
                        //sBackupImagePos = sRollbackStartImagePos;
                        sBackupLogPos = sTxHead->mLogCurPos;
                        sBackupImagePos = sTxHead->mImageCurPos;
                    }
                    else
                    {
                        if ( sRollbackStartLogPos != -1 )
                        {
                            sTxHead->mLogCurPos = sRollbackStartLogPos;
                            sTxHead->mImageCurPos = sRollbackStartImagePos;
                        }

                        if ( sData->mLogCheck == 1 )
                        {
                            sBackupLogPos = sData->mBackupLogPos;
                            sBackupImagePos = sData->mBackupImagePos;
                        }
                    }
                    DBM_INFO ("UpdateColGT Throw BackupLogPos[%d:%d], sRollbackStartLogPos[%d:%d]\n",
                                    SLOTID(sBackupLogPos), OFFSET(sBackupLogPos),
                                    SLOTID(sRollbackStartLogPos), OFFSET(sRollbackStartLogPos));
                    _THROW( _rc );
                }

                break;

            case DBM_CLEAR_BIND:
                /* 모든 prepare table 의 bind col clear */
                for( i=0; i<mTableCount; i++ )
                {
                    _CALL( mTable[i]->mClearBind( mTransID, sData ) );
                }
                break;

            case DBM_ENQUE:
                sNeedPartialRollbackF = 1;
                _CALL( mQueue[sTIdx]->mEnque( mTransID, sData ) );
                break;

            case DBM_DEQUE:
                sNeedPartialRollbackF = 1;
                _CALL( mQueue[sTIdx]->mDeque( mTransID, sData ) );
                break;

                // 2014.12.14. -okt- 2014.09.21 미구현인듯 막음.
//            case DBM_DEQUE_MORE:
//                sNeedPartialRollbackF = 1;
//                _CALL( mQueue[sTIdx]->mDequeMore( mTransID, sData ) );
//                break;
//
//            case DBM_DEQUE_ARRAY:
//                sNeedPartialRollbackF = 1;
//                _CALL( mQueue[sTIdx]->mDequeArray( mTransID, sData ) );
//                break;

            case DBM_SET_INDEX:
                /***********************************************
                 * Use Index 를 변경.
                 ***********************************************/
                bNeedPartialRollback = 0;
                _CALL( mActSetIndex( sData ) );
                _RETURN;
                break;

            case DBM_GET_INDEX:
                /***********************************************
                 * Use Index 를 조회.
                 ***********************************************/
                bNeedPartialRollback = 0;
                _CALL( mActGetIndex( sData ) );
                _RETURN;
                break;

            /***********************************************
             * 아래 DDL 들은 dbmExecuteDDL 이 아닌
             * dbmDropTable, dbmDropQueue 와 같은 API 를
             * 사용할 경우 mTransType < 0 이 아니고
             * 명시적으로 들어오므로 위에서 분기되지 않고
             * 여기까지 와서 처리된다.
             ***********************************************/
            case DBM_DROP_TABLE:
            case DBM_DROP_QUEUE:
            case DBM_DROP_SEQUENCE:
            case DBM_DROP_LIST:
                bNeedPartialRollback = 0;


                //mParseObj->mSQLType = DBM_DROP_TABLE;
                mParseObj->mSQLType = sData->mTransType;

                cmnStrCpy ( mParseObj->mObj.mTableInfo.mTable.mTableName,
                            sData->mTableName,
                            sizeof(mParseObj->mObj.mTableInfo.mTable.mTableName) );

                _CALL( mActDDL( (void*)mParseObj ) );
                _RETURN;
                break;

            case DBM_DROP_INDEX:
                bNeedPartialRollback = 0;

                mParseObj->mSQLType = DBM_DROP_INDEX;
                cmnStrCpy ( mParseObj->mObj.mIndex.mIndexName,
                            sData->mTableName,
                            sizeof(mParseObj->mObj.mIndex.mIndexName) );

                _CALL( mActDDL( (void*)mParseObj ) );
                _RETURN;
                break;

            case DBM_TRUNCATE:
                bNeedPartialRollback = 0;

                mParseObj->mSQLType = DBM_TRUNCATE;
                cmnStrCpy ( mParseObj->mObj.mTableInfo.mTable.mTableName,
                            sData->mTableName,
                            sizeof(mParseObj->mObj.mTableInfo.mTable.mTableName) );

                _CALL( mActDDL( (void*)mParseObj ) );
                _RETURN;
                break;

            default:
                DBM_INFO( "Invalid transaction operation [%d]", sData->mTransType );
                _THROW( ERR_DBM_INVALID_OPERATION );
                break;
        } /* switch( sData->mTransType ) */
    }
    _CATCH
    {
        if ( unlikely (_rc  == ERR_DBM_DEADLOCK_DETECTED || _rc == ERR_DBM_TRIGGER_FAIL) )
        {
            this->mActNormalRollback();
        }


        if ( unlikely ( bNeedPartialRollback ) )
        {
            if ( _rc != ERR_DBM_NO_MATCH_RECORD )
            {
                if ( _rc != ERR_DBM_DUP_ERROR )
                {
                    DBM_WARN( "Operation(%d) result. NeedPartialRollbackFlag=%d, rc=%d", 
                                  sData->mTransType, sNeedPartialRollbackF, _rc );
                }
                if ( sNeedPartialRollbackF == 1 )
                {
                    
                    sRet = mActPartialRollback( sBackupLogPos, sBackupImagePos );
                    DBM_WARN ("mActPartialRollback BackupLogPos[%d:%d], BackupImagePos[%d:%d], ret=%d\n"
                              , SLOTID (sBackupLogPos), OFFSET (sBackupLogPos)
                              , SLOTID (sBackupImagePos), OFFSET (sBackupImagePos)
                              , sRet );
                         
                }
            }
            else
            {
                if ( sNeedPartialRollbackF == 1 )
                {
                    /* Not Found 일 때는 Row Lock Log 는 Rollback 안하도록 */
                    sTxHead->mLogCurPos   = sBackupLogPos;
                    sTxHead->mImageCurPos = sBackupImagePos;
                }
            }
        }

        if ( unlikely ( _rc != ERR_DBM_NO_MATCH_RECORD ) )
        {
            // #919 ERR_DBM_DUP_ERROR 인 경우 여기만 (I)로 찍고 나머지는 (D)
            DBM_INFO( "catch error. operation=%d rc=%d (err=%d,tid=%d,l=%d)", sData->mTransType, _rc, errno, gettid_s ( ), _line );
        }
    }
    _FINALLY
    _END
} /* mAct */


/******************************************************************************
 * Name : mActSetIndex
 *
 * Description
 *     Set Index
 *
 * Argument
 *     aData   : input   : pointer to dbmParseObject
 *
 ******************************************************************************/
_VOID dbmTransManager::mActSetIndex( void* aData )
{
    //dbmLogHeader*   sLogHead   = NULL;
    dbmDataObject*  sData = (dbmDataObject*)aData;
    dbmTableHeader* sTableHead = NULL;
    int             sTIdx = -1;
    int             sUseIndex;
    int             sRC;
    unsigned long long i;

    _TRY
    {
        sRC = mFindTableInTx ( sData->mTableName, &sTIdx );
        if ( sRC != RC_SUCCESS || sTIdx < 0 ) //, NOT_EXIST );
        {
            DBM_INFO( "Find Table(%s) fail. Prepare first.", sData->mTableName );
            _THROW( ERR_DBM_TABLE_NOT_PREPARED );
        }

        sTableHead = mTable[sTIdx]->mGetTableHeader ( );
        _IF_THROW( sTableHead->mTableObj.mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );

        /***********************************************
         * 다른 세션에서 DDL 등이 발생하여 Object ID 가
         * 달라졌을 수 있음.
         ***********************************************/
        if ( sTableHead->mTableObj.mTableID != mTable[sTIdx]->mGetTableID ( ) )
        {
            sRC = mUnprepareTable ( sTableHead->mTableObj.mTableName, sTableHead->mTableObj.mTableType );

            sRC = mPrepareTable ( sTableHead->mTableObj.mTableName );
            if ( sRC ) //, PREPARE_TABLE_FAIL );
            {
                DBM_ERR( "Prepare table fail during set index.[%s], rc=%d", sTableHead->mTableObj.mTableName, sRC );
                _THROW( ERR_DBM_TABLE_NOT_PREPARED );
            }
        }

        /***********************************************
         * 각종 에러 체크. meta 에서 안해서 여기서... 씨이...
         ***********************************************/
        _IF_THROW( sTableHead->mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );
        for ( i = 0; i < sTableHead->mIndexCount; i++ )
        {
            if ( !strcmp_s ( sTableHead->mIndex[i].mIndexName, sData->mUserData ) )
            {
                break;
            }
        }
        if ( i >= sTableHead->mIndexCount ) //, INDEX_NOT_EXIST );
        {
            DBM_INFO( "Find index(%s) in table(%s) manager fail.", sData->mUserData, sData->mTableName );
            _THROW( ERR_DBM_INDEX_NOT_PREPARED );
        }

        if ( sTableHead->mTableObj.mTableType == DBM_TBL_DIRECT ||
             sTableHead->mTableObj.mTableType == DBM_TBL_SEQUENCE )
        {
            /* direct table 은 무조건 첫번째가 Use Index */
            mTable[sTIdx]->mSetUseIndex ( 0 );
            _RETURN;
        }

        sRC = mFindIndexInTbl ( mTable[sTIdx], sData->mUserData, &sUseIndex );
        if ( sRC != 0 ) //, INDEX_NOT_EXIST );
        {
            DBM_INFO( "Find index(%s) in table(%s) manager fail.", sData->mUserData, sData->mTableName );
            _THROW( ERR_DBM_INDEX_NOT_PREPARED );
        }

        _CALL( mTable[sTIdx]->mSetUseIndex ( sUseIndex ) );
        _CALL( mTable[sTIdx]->mSetSetIndexF ( ) );
//        if ( ! sTableHead->mTableObj.mNoMemloggingF )
//        {
//            sRC = mLogMgr->mWriteMemLog( DBM_SET_INDEX_LOG,
//                                         mTransID,
//                                         sTableHead->mTableObj.mTableID,
//                                         sData->mUserData,
//                                         sData->mTableName,
//                                         NULL, // aRefRecord,
//                                         NULL,
//                                         0,
//                                         NULL,
//                                         NULL,
//                                         &sLogHead );
//            _IF_THROW( sRC, ERR_DBM_WRITE_LOG );
//        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mActSetIndex */


/******************************************************************************
 * Name : mActGetIndex
 *
 * Description
 *     Get Index
 *
 * Argument
 *     aData   : input   : pointer to dbmParseObject
 *
 ******************************************************************************/
_VOID dbmTransManager::mActGetIndex( void* aData )
{
    int             sIndexCount;
    int             sRC;
    int             sUseIndex;
    int             sTIdx = -1;
    dbmDataObject*  sData   = (dbmDataObject*)aData;
    dbmTableHeader* sTableHead = NULL;
    char            sOldUseIndexName[DBM_NAME_LEN];
    int             i;

    _TRY
    {
        sRC = mFindTableInTx ( sData->mTableName, &sTIdx );
        if ( sRC || sTIdx < 0 ) //, NOT_EXIST );
        {
            DBM_INFO( "Find Table(%s) fail. Prepare first. rc=%d", sData->mTableName, sRC );
            _THROW( ERR_DBM_TABLE_NOT_PREPARED );
        }

        sTableHead = mTable[sTIdx]->mGetTableHeader ( );

        _IF_THROW( sTableHead->mTableObj.mTableType == DBM_TBL_QUEUE, ERR_DBM_INVALID_TABLE_TYPE );
        _IF_THROW( sTableHead->mIndexCount <= 0, ERR_DBM_NO_INDEX_IN_TABLE );

        /***********************************************
         * Direct Table 은 무조건 첫번째 Index
         ***********************************************/
        if ( sTableHead->mTableObj.mTableType == DBM_TBL_DIRECT )
        {
            strcpy_s ( sData->mUserData, sTableHead->mIndex[0].mIndexName );
            _RETURN;
        }

        /***********************************************
         * 현재 Use Index 로 셋팅되어 있는 Index Name 을
         * 저장해둔다.
         * Reprepare Table 이후에 이 이름에 해당하는 Index로
         * Use Index 를 셋팅해두고 이를 리턴한다.
         ***********************************************/
        memset_s ( sOldUseIndexName, 0x00, DBM_NAME_LEN );

        sUseIndex = mTable[sTIdx]->mGetUseIndex ( );

        if ( mTable[sTIdx]->mGetIndexMgrByIdx(sUseIndex) == NULL ) //, INDEX_NOT_EXIST );
        {
            DBM_INFO( "Find index(%s) in table(%s) manager fail.", sData->mUserData, sData->mTableName );
            _THROW( ERR_DBM_INDEX_NOT_PREPARED );
        }

        strcpy_s ( sOldUseIndexName, mTable[sTIdx]->mGetIndexMgrByIdx ( sUseIndex )->mGetIndexName ( ) );

        /***********************************************
         * 다른 세션에서 DDL 등이 발생하여 Object ID 가
         * 달라졌을 수 있음.
         ***********************************************/
        if ( sTableHead->mTableObj.mTableID != mTable[sTIdx]->mGetTableID ( ) )
        {
            sRC = mUnprepareTable ( sTableHead->mTableObj.mTableName, sTableHead->mTableObj.mTableType );

            sRC = mPrepareTable ( sTableHead->mTableObj.mTableName );
            if ( sRC ) //, PREPARE_TABLE_FAIL );
            {
                DBM_ERR( "Prepare table fail during get index.[%s], rc=%d", sTableHead->mTableObj.mTableName, sRC );
                _THROW( ERR_DBM_TABLE_NOT_PREPARED );
            }

            /***********************************************
             * Prepare Table 한 이후에 다시 재구성된 Index 정보를
             * 이용하여 Get Index 를 처리한다.
             ***********************************************/
            sIndexCount = mTable[sTIdx]->mGetIndexCount ( );
            for ( i = 0; i < sIndexCount; i++ )
            {
                if ( !strcmp_s ( sOldUseIndexName, mTable[sTIdx]->mGetIndexMgrByIdx ( i )->mGetIndexName ( ) ) )
                {
                    break;
                }
            }
            /* 있던 Index Name 이 DDL 로 사라졌다. */
            _IF_THROW( i >= sIndexCount, ERR_DBM_INVALID_OBJECT );

            strcpy_s ( sData->mUserData, mTable[sTIdx]->mGetIndexMgrByIdx ( i )->mGetIndexName ( ) );
        }
        else
        {
            strcpy_s ( sData->mUserData, sOldUseIndexName );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mActGetIndex */


/******************************************************************************
 * Name : mActDDL
 *
 * Description
 *     Process DDL
 *
 * Argument
 *     aParse   : input   : pointer to dbmParseObject
 *
 ******************************************************************************/
_VOID dbmTransManager::mActDDL( void* aParse )
{
    int             sRC    = -1;
    dbmParseObject* sParse = (dbmParseObject*)aParse;

    _TRY
    {
        DBM_DBG2( "DDL Type [%d]", sParse->mSQLType );

#ifdef _DEBUG
        if ( !strncmp_s ( mInstName, SYS_DIC_PREFIX, strlen_s ( SYS_DIC_PREFIX ) ) )
#else
        if ( mInstName[0] == SYS_DIC_PREFIX_CHAR )   // (성능)
#endif
        {
            _THROW( ERR_DBM_OBJECT_DDL_IN_SYS_INST );
        }

        switch( sParse->mSQLType )
        {
            case DBM_TRUNCATE:
                _CALL( mActTruncate( sParse ) );
                break;

            case DBM_CREATE_TABLE:
            case DBM_CREATE_DIRECT_TABLE:
            case DBM_CREATE_QUEUE:
            case DBM_CREATE_SEQUENCE:
            case DBM_CREATE_LIST:
                _CALL( mActCreateTable( sParse ) );
                break;

            case DBM_CREATE_INDEX:
                _CALL( mActCreateIndex( sParse ) );
                break;

            case DBM_CREATE_TRIG:
                _CALL( mActCreateTrig( sParse ) );
                break;

            case DBM_DROP_TABLE:
            case DBM_DROP_QUEUE:
            case DBM_DROP_SEQUENCE:
            case DBM_DROP_LIST:
                _CALL( mActDropTable( sParse ) );
                break;

            case DBM_DROP_INDEX:
                _CALL( mActDropIndex( sParse ) );
                break;

            case DBM_ALTER_TABLE_DISKLOG :
                _CALL( mActAlterTableDiskLog ( sParse ) );
                break;

            case DBM_ALTER_TABLE_MEMLOG :
                _CALL( mActAlterTableMemLog ( sParse ) );
                break;

            case DBM_DROP_TRIG:
                _CALL( mActDropTrig( sParse ) );
                break;

            case DBM_CREATE_INST:
            case DBM_DROP_INST:
            case DBM_CREATE_USER:
            case DBM_DROP_USER:
            case DBM_CREATE_DATA:
            case DBM_DROP_DATA:
            default:
                //_RAISE( INVALID_OPER );
                {
                    DBM_INFO( "Invalid ddl operation [%d]", sParse->mSQLType );
                    _THROW( ERR_DBM_INVALID_OPERATION );
                }
                break;
        }
    }
    _CATCH
    {
        _CATCH_DBG; // 2014.10.22 -okt- 중복로그. 하위단에서 로그를 잘찍을거다.
    }
    _FINALLY
    _END
} /* mActDDL */


/******************************************************************************
 * Name : mActCreateTable
 *
 * Description
 *     Process Create Table DDL.
 *     Table(List, Queue) Segment 를 만들고 User Header 부분에 Table(List, Queue)
 *     Header 정보를 copy 해두는 것까지 수행한다.
 *     향후에 이 Table(List, Queue) Header 정보를 Table(List, Queue) Manager 가 이용한다.
 *
 * Argument
 *     aParse   : input   : pointer to dbmParseObject
 *
 ******************************************************************************/
_VOID dbmTransManager::mActCreateTable( void* aParse )
{
    int                 i;
    int                 sRC = -1;
    int*                sTBLType    = NULL;
    dbmParseObject*     sParse = (dbmParseObject*)aParse;
    dbmTableInfo*       sTableInfo = (dbmTableInfo*)&sParse->mObj.mTableInfo;
    dbmLogType          sLogType;
    dbmSegmentManager*  sTableSegMgr;
    dbmTableHeader*     sTableHeader = NULL;
    dbmQueueHeader*     sQueueHeader = NULL;
    dbmListHeader*      sListHeader  = NULL;
    dbmLogHeader*       sLogHead     = NULL;
    dbmDicObject        sDicObject;
    size_t              sSlotSize;
    long long           sUserInitSize   = 0;
    long long           sUserExtendSize = 0;
    long long           sUserMaxSize    = 0;
    char                sBuf[32];
    size_t              sUserHeaderSize = 0;
    dbmTransHeader*     sTxHead = (dbmTransHeader*)mTransHeader;
    dbmObjectDic*       sObjectDic = (dbmObjectDic *)&sDicObject.mObj;
    dbmTableObject*     sTBLObj     = NULL;



    _TRY
    {
        _IF_THROW( sParse->mObj.mTableInfo.mTable.mTableName[0] == '\0',
                   ERR_DBM_INVALID_OBJECT_NAME );

#ifdef _DEBUG
        if ( !strncmp_s ( sParse->mObj.mTableInfo.mTable.mTableName, SYS_DIC_PREFIX, strlen_s ( SYS_DIC_PREFIX ) ) )
#else
        if ( sParse->mObj.mTableInfo.mTable.mTableName[0] == SYS_DIC_PREFIX_CHAR )   // (성능)
#endif
        {
            _THROW( ERR_DBM_DDL_DIC_OBJECT );
        }

        if ( !strcmp_s( mInstName, sTableInfo->mTable.mTableName) )
        {
            _THROW( ERR_DBM_INVALID_OBJECT_NAME );
        }


        /* 2015.05.05 -shw-
         * : sequence 중복 관련 막음 */
        if ( sParse->mSQLType ==  DBM_CREATE_SEQUENCE )
        {

            memset_s( &sDicObject, 0x00, sizeof(sDicObject) );
            sDicObject.mSQLType = DBM_CREATE_TABLE;
            sTBLObj = ( dbmTableObject* )&sDicObject.mObj.mTableInfo.mTable;
            sTBLType = ( int* )&sTBLObj->mTableType;
            strncpy( sTBLObj->mInstName, SYS_INST_NAME, strlen_s(SYS_INST_NAME) );

            sRC = mDic->mGetFirst( &sDicObject );
            if ( sRC == RC_SUCCESS )
            {
                if( *sTBLType == DBM_TBL_SEQUENCE )
                {
                    DBM_INFO( "object already exists. tx(%d) object(%s).", mTransID, sTableInfo->mTable.mTableName );
                    _THROW( ERR_DBM_ALREADY_EXIST_IN_DIC );
                }

                while(1)
                {
                    sRC = mDic->mGetNext( &sDicObject );
                    if ( sRC == RC_SUCCESS )
                    {
                        if( *sTBLType == DBM_TBL_SEQUENCE )
                        {
                            DBM_INFO( "object already exists. tx(%d) object(%s).", mTransID, sTableInfo->mTable.mTableName );
                            _THROW( ERR_DBM_ALREADY_EXIST_IN_DIC );
                        }
                    }
                    else
                    {
                        break;
                    }
                }
            }
        }

        /***********************************************
         * object dictionary table 에 있는 이름이면 안됨.
         ***********************************************/
        memset_s( &sDicObject, 0x00, sizeof(sDicObject) );
        sDicObject.mSQLType = DBM_CREATE_OBJECT;

        strcpy_s( sObjectDic->mInstName, mInstName );
        strcpy_s( sObjectDic->mObjectName, sTableInfo->mTable.mTableName );

        sRC = mDic->mSelect ( &sDicObject );
        if ( sRC == 0 )
        {
            DBM_INFO( "object already exists. tx(%d) object(%s).", mTransID, sTableInfo->mTable.mTableName );
            _THROW( ERR_DBM_ALREADY_EXIST_IN_DIC );
        }
        _IF_THROW( sRC != ERR_DBM_NO_MATCH_RECORD, sRC /* SEARCH_FAIL */ );


        /***********************************************
         * dictionary 에 이미 있는 table 인지 확인.
         ***********************************************/
        memset_s( &sDicObject, 0x00, sizeof(sDicObject) );
        sDicObject.mSQLType = DBM_CREATE_TABLE;

        cmnStrCpyZ( sDicObject.mObj.mTableInfo.mTable.mInstName, mInstName );
        cmnStrCpyZ( sDicObject.mObj.mTableInfo.mTable.mTableName, sTableInfo->mTable.mTableName );

        sRC = mDic->mSelect ( &sDicObject );
        if ( sRC == 0 )
        {
            DBM_INFO( "table already exists. tx(%d) table(%s).", mTransID, sTableInfo->mTable.mTableName );
            _THROW( ERR_DBM_ALREADY_EXIST_IN_DIC );
        }
        _IF_THROW( sRC != ERR_DBM_NO_MATCH_RECORD, sRC /* SEARCH_FAIL */ );


        /***********************************************
         * Direct table 일 경우 컬럼 중 최소한 하나는 숫자형이어야 함.
         ***********************************************/
        if ( sParse->mSQLType == DBM_CREATE_DIRECT_TABLE )
        {
            for( i=0; i<sTableInfo->mColumn.mCount; i++ )
            {
                if ( (sTableInfo->mColumn.mCols[i].mColumnType == DBM_COLUMN_INT_TYPE)
                 || (sTableInfo->mColumn.mCols[i].mColumnType == DBM_COLUMN_LONG_TYPE)
                 || (sTableInfo->mColumn.mCols[i].mColumnType == DBM_COLUMN_SHORT_TYPE) )
                {
                    break;
                }
            }

            _IF_THROW( i>= sTableInfo->mColumn.mCount,
                       ERR_DBM_DIRECT_NO_NUM_COLUMN );
        }


        /* 2014.08.01 shw */
        /************************************************
         * Table Max_Size Check
         * **********************************************/
        if ( sParse->mSQLType == DBM_CREATE_TABLE )
        {
            for( i=0; i<sTableInfo->mColumn.mCount; i++)
            {
                _IF_THROW( sTableInfo->mColumn.mCols[i].mSize  > DBM_MAX_RECORD_SIZE,
                           ERR_DBM_INVALID_RECORD_SIZE);
            }
        }

        /************************************************
         * Queue Max_Size Check
         * **********************************************/
        if ( sParse->mSQLType == DBM_CREATE_QUEUE || sParse->mSQLType == DBM_CREATE_LIST )
        {
            _IF_THROW( sTableInfo->mTable.mRecordSize > DBM_MAX_RECORD_SIZE,
                       ERR_DBM_INVALID_RECORD_SIZE);
        }

        /***********************************************
         * init, extend, max size 검증.
         * ParseObject 에 만약 init size 와 exten, max size 가
         * 없으면 config 에서 default 값을 읽는다.
         ***********************************************/
        _CALL( mGetTableConfig( mConfigMgr,
                               mInstName,
                               &sUserInitSize,
                               &sUserExtendSize,
                               &sUserMaxSize,
                               &sTableInfo->mTable.mInitSize,
                               &sTableInfo->mTable.mExtendSize,
                               &sTableInfo->mTable.mMaxSize ) );

        /***********************************************
         * table 생성 시 init 이 max 보다 클 수는 없다.
         ***********************************************/
        if ( sTableInfo->mTable.mInitSize > sTableInfo->mTable.mMaxSize )
        {
           if ( sTableInfo->mTable.mInitSize > sTableInfo->mTable.mMaxSize )
            {
               // 사용자가 명시적으로 입력했는지 판단을 '소스기본값'이 아니고 설정에서 읽은 값으로 해야한다.
                if ( sUserInitSize == 0 )
                {
                    DBM_DBG( "object init size is bigger than max, reset init size. init[%ld -> %ld]",
                             sTableInfo->mTable.mInitSize, sTableInfo->mTable.mMaxSize );

                    sTableInfo->mTable.mInitSize = sTableInfo->mTable.mMaxSize;
                }
                else if ( sUserMaxSize == 0 )
                {
                    DBM_DBG( "object init size is bigger than max, reset max size. max[%ld -> %ld]",
                             sTableInfo->mTable.mMaxSize, sTableInfo->mTable.mInitSize );

                    sTableInfo->mTable.mMaxSize = sTableInfo->mTable.mInitSize;
                }
                else
                {
                    DBM_WARN( "invalid table size. init[%ld] max[%ld]",
                              sTableInfo->mTable.mInitSize, sTableInfo->mTable.mMaxSize );
                    _THROW( ERR_DBM_INVALID_TABLE_SIZE );
                }
            }
        }

        /***********************************************
         * 최대 extend 가 되면 max를 충족하는지 검사
         ***********************************************/
        if ( sTableInfo->mTable.mInitSize + sTableInfo->mTable.mExtendSize * ( MAX_SEGMENT_COUNT - 1 )
                < sTableInfo->mTable.mMaxSize )
        {
            DBM_INFO( "invalid table size. init[%ld] extend[%ld] max[%ld]",
                      sTableInfo->mTable.mInitSize,
                      sTableInfo->mTable.mExtendSize,
                      sTableInfo->mTable.mMaxSize );
            _THROW( ERR_DBM_INVALID_TABLE_SIZE );
        }

        /***********************************************
         * 진행 중이던 DML 들 Commit 시켜버림.
         ***********************************************/
        sRC = mActCommit ( );
        if ( sRC != 0 )
        {
            DBM_WARN( "commit dml of tx(%d) fail during create table(%s). rc=%d",
                      mTransID, sParse->mObj.mTableInfo.mTable.mTableName, sRC );
            _THROW( sRC );
        }

        /***********************************************
         * DDL Logging
         ***********************************************/
        /* 참고 : 2015.03.12
         * Sequence Table은 type이 CREATE TABLE logging 처리 하면 되기 때문에
         * log type은 따로 만들지 않는다 */
        if ( sParse->mSQLType == DBM_CREATE_LIST )
        {
            sLogType = DBM_DDL_CREATE_LIST_LOG;
        }
        else
        if ( sParse->mSQLType == DBM_CREATE_QUEUE )
        {
            sLogType = DBM_DDL_CREATE_QUEUE_LOG;
        }
        else
        {
            sLogType = DBM_DDL_CREATE_TABLE_LOG;
        }

        sRC = mLogMgr->mWriteMemLog( sLogType,
                                     mTransID,
                                     (int)-1,   /* table ID 아직 모름 */
                                     sParse->mObj.mTableInfo.mTable.mTableName,
                                     NULL, // sParse->mObj.mTableInfo.mTable.mTableName,
                                     -1,
                                     sParse->mSQL,
                                     strlen_s ( sParse->mSQL ) + 1 ,
                                     NULL,
                                     NULL,
                                     (char**)&sLogHead );
        if ( sRC != 0 )
        {
            DBM_ERR( "write log fail. log_type [%d]. rc=%d", sLogType, sRC );
            _THROW( ERR_DBM_WRITE_LOG );
        }

        RTF_POINT("TXMGR_CREATE_TABLE_0");


        /***********************************************
         * table segment 생성
         ***********************************************/
        if ( sParse->mSQLType == DBM_CREATE_LIST )
        {
            sSlotSize = sTableInfo->mTable.mRecordSize + sizeof(dbmListSlotHeader);
            sUserHeaderSize = (size_t) sizeof(dbmListHeader);
        }
        else
        if ( sParse->mSQLType == DBM_CREATE_QUEUE )
        {
            sSlotSize = sTableInfo->mTable.mRecordSize + sizeof(dbmQNodeHeader);
            sUserHeaderSize = (size_t) sizeof(dbmQueueHeader);
        }
        else
        {
            sSlotSize = sTableInfo->mTable.mRecordSize + sizeof(dbmRowHeader);
            sUserHeaderSize = (size_t) sizeof(dbmTableHeader);
        }

        sRC = dbmSegmentManager::Create( mInstName,
                                         sTableInfo->mTable.mTableName,
                                         sSlotSize,
                                         sTableInfo->mTable.mInitSize,
                                         sTableInfo->mTable.mExtendSize,
                                         sTableInfo->mTable.mMaxSize,
                                         sUserHeaderSize,
                                         &sTableSegMgr );
        if ( sRC || sTableSegMgr == NULL )
        {
            DBM_INFO( "create table[%s] segment fail.[%d]", sTableInfo->mTable.mTableName, sRC );
            _THROW( sRC );
        }

        RTF_POINT("TXMGR_CREATE_TABLE_1");


        memset_s ( sBuf, 0x00, sizeof( sBuf ) );

        if ( sParse->mSQLType == DBM_CREATE_LIST )
        {
            strcpy_s ( sBuf, "list" );
        }
        else
        if ( sParse->mSQLType == DBM_CREATE_QUEUE )
        {
            strcpy_s ( sBuf, "queue" );
        }
        else
        if ( sParse->mSQLType == DBM_CREATE_SEQUENCE )
        {
            strcpy_s ( sBuf, "sequence" );
        }
        else
        {
            strcpy_s ( sBuf, "table" );
        }

        DBM_INFO( "create %s(%s) segment. BUDDY: slot_size[%ld] init[%ld->%ld] extend[%ld->%ld] max[%ld->%ld]",
                          sBuf,
                          sTableInfo->mTable.mTableName, sSlotSize,
                          sUserInitSize,
                          sTableInfo->mTable.mInitSize,
                          sUserExtendSize,
                          sTableInfo->mTable.mExtendSize,
                          sUserMaxSize,
                          sTableInfo->mTable.mMaxSize );


        /***********************************************
         * dbmTableObject, dbmColumnSetObject 정보 중
         * Parser 에서 채우지 못한 부분 채운다.
         * ( ID 정보는 Dic Manager 에서 알아서 채워서 사용한다.
         *  Table ID 등의 채번도 Dic Manager 에서 한다. )
         ***********************************************/
        cmnStrCpyZ( sTableInfo->mTable.mInstName, mInstName );


        /***********************************************
         * Queue 일 경우 Message 컬럼 하나를 추가한다.
         * ( create queue 구문에는 column 관련 사항은 없어서
         *   직접 column 정보 하나를 채운다)
         ***********************************************/
        if ( sParse->mSQLType == DBM_CREATE_QUEUE || sParse->mSQLType == DBM_CREATE_LIST )
        {
            sTableInfo->mTable.mColumnCount = 1;
            sTableInfo->mColumn.mCount      = 1;
            sTableInfo->mColumn.mCols[0].mColumnType = DBM_COLUMN_CHAR_TYPE;
            strcpy_s( sTableInfo->mColumn.mCols[0].mColumnName, "message" );
            sTableInfo->mColumn.mCols[0].mSize       = sTableInfo->mTable.mRecordSize;
            sTableInfo->mColumn.mCols[0].mOffset     = 0;
            sTableInfo->mColumn.mCols[0].mPrecision  = 0;
            sTableInfo->mColumn.mCols[0].mScale      = 0;
            sTableInfo->mTable.mNologgingF = 0;
        }

        /***********************************************
         * Dictionary Manager 에게 Insert 요청.
         * Logging 은 Insert 내부가 Table 작업이므로 자동으로 될거임.
         * 복구 시에는 delete 해야 한다.
         ***********************************************/
        _CALL( mDic->mInsert ( sParse ) );

        /***********************************************
         * 위에서 dictionary 에 insert 한 후 죽었다면
         * 복구 과정에서 Segment 를 삭제할 것이므로
         * 실제로는 dictionary 에는 있는데 segment 는
         * 없는 상황이 될 수 있다.
         * 이는 Dictionary Tx 와 일반 Tx 가 별개이기 때문이다.
         *
         * 사용자가 실수로 특정 table segment 를 drop 한 경우도
         * 이 상황과 구별할 수 없다.
         *
         * 이 때의 정책 :
         *   사용자에게 create 할 때는 already exist 를 보내주고
         *   대신 drop 하면 dictionary 와 segment 를 확실히
         *   삭제를 잘해주도록 한다.
         ***********************************************/
        RTF_POINT("TXMGR_CREATE_TABLE_2");


        /***********************************************
         * Table Header 에 dbmTableInfo 정보를 한번에 copy 해둔다.
         * Table ID 등은 Dictionary Manager 가 위에서 채워준 것이다.
         * mInitCompleteF 를 1 로 셋팅하여 table header 초기화까지
         * 마쳤음을 표기한다.
         ***********************************************/
        sTableHeader = (dbmTableHeader*) sTableSegMgr->GetUserHeader ( );
        if ( sParse->mSQLType == DBM_CREATE_LIST )
        {
            /* columnet set:
             * columnt info를 위에서 set해 주어서 해당 size 제외한 만큼 copy 한다 */
            memcpy_s ( sTableHeader, sTableInfo, sizeof(dbmTableInfo) - sizeof(dbmColumnSetObject) );

            sListHeader = (dbmListHeader*) sTableHeader;

            sListHeader->mLock = -1;
            sListHeader->mDDLCount = 0;
            sListHeader->mInitCompleteF = 1;
            sListHeader->mRecoveryProcessF = 0;


            sListHeader->mListTotalCount = 0;
            //sListHeader->mListLeftCount  = 0;
            sListHeader->mListLeftLast   = -1;
            //sListHeader->mListRightStart = -1;
            sListHeader->mListRightLast  = -1;
            memset_s( sListHeader->mSegmentAllocCk, -1, sizeof(int) * MAX_SEGMENT_COUNT );
            sListHeader->mSegmentAllocCk[0] = 0;
        }
        else
        if ( sParse->mSQLType == DBM_CREATE_QUEUE )
        {
            memcpy_s ( sTableHeader, sTableInfo, sizeof(dbmTableInfo) - sizeof(dbmColumnSetObject) );

            sQueueHeader = (dbmQueueHeader*) sTableHeader;

            sQueueHeader->mLock     = -1;
            sQueueHeader->mLockEnq  = -1;
            sQueueHeader->mRFutex   = 0;
            sQueueHeader->mWFutex   = 0;
            sQueueHeader->mTableObj.mNologgingF = 0;

            RTF_POINT("TXMGR_CREATE_TABLE_3");

            sQueueHeader->mDeq = -1;
            sQueueHeader->mEnq = -1;
            sQueueHeader->mDDLCount = 0;

            sQueueHeader->mOldDeq = -1;
            sQueueHeader->mOldEnq = -1;

            sQueueHeader->mDDLCount = 0;

            sQueueHeader->mInitCompleteF = 1;

            RTF_POINT("TXMGR_CREATE_TABLE_4");

            sQueueHeader->mRecoveryProcessF = 0;
        }
        else
        {
            memcpy_s ( sTableHeader, sTableInfo, sizeof(dbmTableInfo) );
            sTableHeader->mDDLCount = 0;
            sTableHeader->mTableObj.mNologgingF = 0 ;

            RTF_POINT("TXMGR_CREATE_TABLE_5");

            sTableHeader->mInitCompleteF = 1;
        }

        /***********************************************
         * DDL 후에는 Table 다시 Prepare
         ***********************************************/
        sRC = mPrepareTable ( sTableInfo->mTable.mTableName );
        if ( sRC != 0 )
        {
            DBM_ERR( "Prepare table fail during creating table.[%s] rc=%d", sTableInfo->mTable.mTableName, sRC );
            _THROW( sRC );
        }

        RTF_POINT("TXMGR_CREATE_TABLE_6");


        /***********************************************
         * Logging 된 것을 commit 한다.
         ***********************************************/
        _CALL( mActCommit ( ) );


        /***********************************************
         * mActCommit 에서 Table Manager 가 필요할 수도 있어서
         * Prepare 했었는데 끝나면 가지고 있으면 안된다.
         * 계속 가지고 있으면 dbmCreateDDL 을 다른 테이블 이름으로
         * 많이 수행할 경우, 단순히 테이블 생성만 하고 싶은 경우에도
         * Prepare 된 테이블 갯수가 많아져서 Fail 이 발생하기 시작한다.
         * 사용한 Segment Manager 객체는 가지고 있을 필요없으니 해제한다.
         ***********************************************/
        sRC = mUnprepareTable ( sTableInfo->mTable.mTableName, sTableInfo->mTable.mTableType );


        /***********************************************
         * 사용한 Segment Manager 객체는 가지고 있을 필요없으니 해제한다.
         ***********************************************/
#ifndef USE_NEW_SHM_NODETACH
        sTableSegMgr->Detach ( );
#endif
        delete sTableSegMgr; sTableSegMgr = NULL;
    }
    _CATCH
    {
        _CATCH_WARN;

        //_EXCEPTION_END;
        {
            /***********************************************
             * Logging 된 것을 기준으로 Rollback 시키고 리턴.
             * Rollback 이 Fail 이면 ?
             ***********************************************/
            sRC = mActNormalRollback();
            if ( sRC != RC_SUCCESS )
            {
                DBM_ERR( "rollback fail. [%d]", sRC );
            }
        }
    }
    _FINALLY
    _END
} /* mActCreateTable */


/******************************************************************************
 * Name : mActCreateIndex
 *
 * Description
 *     Process Create Index DDL
 *     Index Segment 를 만들고 User Header 부분에 Index Header 정보를
 *     copy 해두는 것까지 수행한다.
 *     향후에 이 Index Header 정보를 이용하여 Index Manager 가 업무를 수행한다.
 *
 * Argument
 *     aParse   : input   : pointer to dbmParseObject
 *
 ******************************************************************************/
_VOID dbmTransManager::mActCreateIndex( void* aParse )
{
    dbmParseObject*     sParse        = (dbmParseObject*)aParse;
    dbmIndexObject*     sParseIndex   = (dbmIndexObject*)&sParse->mObj.mIndex;
    dbmDicObject        sDicSelect;
    dbmTableInfo*       sDicTableInfo = (dbmTableInfo*)&sDicSelect.mObj.mTableInfo;
    dbmLogType          sLogType;
    dbmSegmentManager*  sIndexSegMgr;
    dbmSegmentManager*  sTableSegMgr;
    dbmTableHeader*     sTableHeader;
    dbmIndexHeader*     sIndexHeader;
    dbmLogHeader*       sLogHead;
    dbmIndexObject*     sOneIndex = NULL;
    long long           sSlotSize;
    long long           sInitSlotCount;
    long long           sExtendSlotCount;
    int                 sKeySize = 0;
    int                 sNeedRollbackF = 0;
    dbmColumnType       sColumnType = DBM_COLUMN_TYPE_MAX;
    dbmObjectDic*       sObjectDic = (dbmObjectDic *)&sDicSelect.mObj;

    dbmTmpIndex         sTmpIndex;
    int                 sRC;
    unsigned long long  i, j;

    _TRY
    {
        DBM_INFO( "start to create index [%s]", sParse->mObj.mIndex.mIndexName );

        _IF_THROW( (sParseIndex->mIndexName[0] == '\0')
                || (sParseIndex->mTableName[0] == '\0'),
                ERR_DBM_INVALID_OBJECT_NAME );

    #ifdef _DEBUG
        if ( !strncmp_s( sParseIndex->mTableName, SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) )
    #else
        if ( sParseIndex->mTableName[0] == SYS_DIC_PREFIX_CHAR )   // (성능)
    #endif
        {
            _THROW( ERR_DBM_DDL_DIC_OBJECT );
        }


        /***********************************************
         * Index 컬럼은 최소한 하나는 되어야지.
         ***********************************************/
        if ( sParseIndex->mColumnCount <= 0 ) //, INVALID_ARGUMENT );
        {
            DBM_WARN( "no column is given for index[%s].", sParseIndex->mIndexName );
            _THROW( ERR_DBM_INVALID_ARGUENT );
        }


        /***********************************************
         * object dictionary table 에 있는 이름이면 안됨.
         ***********************************************/
        memset_s( &sDicSelect, 0x00, sizeof(sDicSelect) );
        sDicSelect.mSQLType = DBM_CREATE_OBJECT;

        /*
         * TODO: 2015.02.27 -okt- 엔텔스 NOCS 테이블에서 딱 32Byte 이름이 있다.
         *       SUNDB 는 128Byte, 우리는 DBM_NAME_LEN 정의로 되어 있는데, 이게 인덱스/테이블 이름 만이 아니고 여러군데 사용하고 있다.
         *
         * 1) sParseIndex->mIndexName[32] 컬럼의 바로 뒤가 dbmIndexType 숫자형이어서, NULL 종료가 우연히 되었다.
         * 2) cmnStrCpy 를 사용하면, 오류없이 짤라서 31Byte 만 처리할 것 이다.
         *    즉 'USG_TYPE_RATING_FAC_CANDIDATE_PK' 이름이 'USG_TYPE_RATING_FAC_CANDIDATE_P' 이렇게 될 것이다.
         * 3) DBM_NAME_LEN 에 대해서 정의를 세분하는 작업을 하면서, 64Byte 정도로 늘려주는게 좋겠다. (성능에 지장없다면, 아예 128Byte도)
         *    디스크 로깅 같은 것 할때, OBJECT_NAME 이 남는데. 이게 고정크기인지, 0x00 까지인지 등 확인필요.
         *
         */
        // 기존 strcpy 를 cmnStrCpyZ 으로 변경하여, 데이타가 짤리더라도 넘치지 않게 한다.
        cmnStrCpyZ( sObjectDic->mInstName, mInstName );
        cmnStrCpyZ( sObjectDic->mObjectName, sParseIndex->mIndexName );

        sRC = mDic->mSelect ( &sDicSelect );
        if ( sRC == 0 )
        {
            DBM_WARN( "duplicated object name. txid[%d] name[%s]", mTransID, sParseIndex->mIndexName );
            _THROW( ERR_DBM_ALREADY_EXIST_IN_DIC );
        }

        if ( sRC != ERR_DBM_NO_MATCH_RECORD ) //, SEARCH_DIC_FAIL );
        {
            DBM_WARN( "search table[%s] in dic for creating index[%s] fail.[%d]",
                      sParseIndex->mTableName, sParseIndex->mIndexName, sRC );
            if ( sRC == ERR_DBM_NO_MATCH_RECORD )
            {
                _THROW( ERR_DBM_TABLE_NOT_IN_DICTIONARY );
            }
            _THROW( sRC );
        }


        /***********************************************
         * Create Index 가 반드시 Prepare Table 이후에 할 수
         * 있는 것만은 아니기 때문에 Transaction Manager 가
         * 가진 Table Manager 객체를 통해 Table ID 를 알아내면 안되고,
         * 반드시 Dictionary Table 을 검색해야 한다.
         * Table 이 있는지를 확인하는 과정이다.
         ***********************************************/
        memset_s( &sDicSelect, 0x00, sizeof(sDicSelect) );

        sDicSelect.mSQLType = DBM_CREATE_TABLE;

        cmnStrCpyZ( sDicSelect.mObj.mTableInfo.mTable.mInstName, mInstName );
        cmnStrCpyZ( sDicSelect.mObj.mTableInfo.mTable.mTableName, sParse->mObj.mIndex.mTableName );

        /*
         * TOOD (OKT): 위의 오류처리 루틴과 중복되고, 길기까지 하다. "_CATCH( 이름 )" 이런식으로 만들수는 있는데. 장단 판단이 안되네..
         */
        sRC = mDic->mSelect( &sDicSelect );
        if ( sRC ) //, SEARCH_DIC_FAIL );
        {
            DBM_WARN( "search table[%s] in dic for creating index[%s] fail.[%d]",
                      sParseIndex->mTableName, sParseIndex->mIndexName, sRC );
            if ( sRC == ERR_DBM_NO_MATCH_RECORD )
            {
                _THROW( ERR_DBM_TABLE_NOT_IN_DICTIONARY );
            }
            _THROW( sRC );
        }


        /***********************************************
         * Table 당 최대 Index 갯수는 DBM_MAX_INDEX_PER_TABLE
         * Direct Table 은 하나의 Index 만을 가질 수 있다.
         ***********************************************/
        if ( sDicTableInfo->mIndexCount >= DBM_MAX_INDEX_PER_TABLE
                || ( sDicTableInfo->mTable.mTableType == DBM_TBL_DIRECT && sDicTableInfo->mIndexCount > 0 ) ) //, TOO_MANY_INDEX );
        {
            DBM_WARN( "index(%s) create fail. too many index for table(%s).",
                      sParseIndex->mIndexName, sParseIndex->mTableName );
            _THROW( ERR_DBM_TOO_MANY_INDEX );
        }

        /***********************************************
         * Direct Table 의 인덱스는 하나의 컬럼만을 가질 수 있다.
         ***********************************************/
        if ( sDicTableInfo->mTable.mTableType == DBM_TBL_DIRECT && sParseIndex->mColumnCount > 1 ) //, TOO_MANY_COLUMN );
        {
            DBM_WARN( "direct table(%s) index(%s) cannot have over one column.",
                      sParseIndex->mTableName, sParseIndex->mIndexName );
            _THROW( ERR_DBM_TOO_MANY_COLUMN );
        }

        /* 2014.07.28 -shw- direct table non unique type 지원하지 않는다 */
        if ( sDicTableInfo->mTable.mTableType == DBM_TBL_DIRECT && sParseIndex->mIsUniqueIndex == DBM_NON_UNIQUE ) //, NOT_SUPPORT_INDEX );
        {
            DBM_ERR( "Direct table does not support the non-unique index [%d][%d]",
                     sDicTableInfo->mTable.mTableType, sParseIndex->mIsUniqueIndex );
            _THROW( ERR_DBM_DIRECT_NON_UNIQUE_INDEX );
        }

        /***********************************************
         * Direct Table 의 인덱스는 숫자 컬럼만을 가질 수 있다.
         * (Double, Float 는 제외)
         * Parser 에서는 column type 을 셋팅 안해주기 때문에
         * dictionary 의 column 정보에서 type 을 얻어낸다.
         ***********************************************/
        if ( sDicTableInfo->mTable.mTableType == DBM_TBL_DIRECT )
        {
            sRC = dbmGetColumnType ( sDicTableInfo, sParseIndex->mKey[0].mColumnName, &sColumnType );

            if ( ( sColumnType != DBM_COLUMN_INT_TYPE )
                    && ( sColumnType != DBM_COLUMN_LONG_TYPE ) && ( sColumnType != DBM_COLUMN_SHORT_TYPE ) )
            {
                //_RAISE( INVALID_COLUMN_TYPE );
                DBM_WARN( "direct table(%s) index(%s) can have only numeric column.",
                          sParseIndex->mTableName, sParseIndex->mIndexName );
                _THROW( ERR_DBM_INVALID_COLUMN_TYPE );
            }
        }


        /***********************************************
         * Key 컬럼이름이 중복으로 들어오면 안된다.
         * (Parser 에서 해줘도 되는데...)
         ***********************************************/
        for ( i = 0; i < (unsigned long long) sParseIndex->mColumnCount; i++ )
        {
            for ( j = i + 1; j < (unsigned long long) sParseIndex->mColumnCount; j++ )
            {
                if ( !strcmp_s ( sParseIndex->mKey[i].mColumnName, sParseIndex->mKey[j].mColumnName ) )
                {
                    //_RAISE( DUP_COLUMN_KEY_NAME );
                    DBM_WARN( "index column name duplicated. tx(%d) index(%s).", mTransID, sParseIndex->mIndexName );
                    _THROW( ERR_DBM_DUP_COLUMN_KEY_NAME );
                }
            }
        }


        /***********************************************
         * 이미 같은 Key / Name 으로 Index 가 만들어져 있는지 검사.
         ***********************************************/
        for ( i = 0; i < sDicTableInfo->mIndexCount; i++ )
        {
            sOneIndex = (dbmIndexObject *) &sDicTableInfo->mIndex[i];

            if ( !strcmp_s ( sOneIndex->mIndexName, sParseIndex->mIndexName ) )
            {
                //_RAISE( DUP_INDEX_NAME );
                DBM_WARN( "index name dup. tx(%d) index(%s).", mTransID, sParseIndex->mIndexName );
                _THROW( ERR_DBM_CREATE_INDEX_DUP );
            }

            if ( sParseIndex->mColumnCount == sOneIndex->mColumnCount )
            {
                // 인덱스 개수가 아닌 컬럼 개수만큼 돌아야한다.
                //for ( j = 0; j < sDicTableInfo->mIndexCount; j++ )
                for ( j = 0; j < (unsigned long long)sParseIndex->mColumnCount; j++ )
                {
                    /* 컬럼타입과 컬럼이름이 하나라도 틀리면 Dup 아님 */
                    // 컬럼 타입은 굳이 비교하지 않아도 된다.
                    //if ( sParseIndex->mKey[j].mColumnType != sOneIndex->mKey[j].mColumnType
                    //        || strcmp_s ( sParseIndex->mKey[j].mColumnName, sOneIndex->mKey[j].mColumnName ) )
                    if ( strcmp_s ( sParseIndex->mKey[j].mColumnName, sOneIndex->mKey[j].mColumnName ) )
                    {
                        break;
                    }
                }

                // 인덱스 개수가 아닌 컬럼 개수보다 크면 에러 처리
                //if ( j >= sDicTableInfo->mIndexCount ) //, DUP_INDEX );
                if ( j >= (unsigned long long)sParseIndex->mColumnCount ) //, DUP_INDEX );
                {
                    DBM_WARN( "index which has the same columns already exist. tx(%d) index(%s).",
                              mTransID, sParseIndex->mIndexName );
                    _THROW( ERR_DBM_CREATE_INDEX_DUP );
                }
            }
        }


        /***********************************************
         * Index Key Size 를 구함.
         * create index 할 때 주어진 column name 이
         * table 에 존재하지 않으면 에러.
         ***********************************************/
        sRC = dbmGetIndexKeyColumnInfo( sParseIndex, sDicTableInfo, &sKeySize );
        if ( sRC || sKeySize <= 0 ) //, NO_COLUMN );
        {
            DBM_WARN( "index[%s] column not exists in table.", sParseIndex->mIndexName );
            _THROW( ERR_DBM_COLUMN_NOT_EXIST_IN_TABLE );
        }
        if ( sKeySize > DBM_INDEX_KEY_MAX_SIZE ) //, TOO_LONG_KEYSIZE );
        {
            DBM_WARN( "key size[%d] longer than DBM_INDEX_KEY_MAX_SIZE. index[%s]", sKeySize, sParseIndex->mIndexName );
            _THROW( ERR_DBM_TOO_LARGE_KEYSIZE );
        }

        sParseIndex->mKeySize = sKeySize;

        /* 2014.05.14 -shw- extra key size add (extra long 8 byte)*/
        /* Index Key Size는 실제 key size값만 들어가고 실제 extra는 생성 될 시에만 처리 하도록 한다 */
        /* 0 : unique type 1: non-unique type */
        if ( ! sParseIndex->mIsUniqueIndex )
        {
            sKeySize = sKeySize + 8;
        }

        /***********************************************
         * table header 에 있는 index 정보도 update 해야하기
         * 때문에 table segment 도 attach 해야 한다.
         ***********************************************/
        sRC = dbmSegmentManager::Attach ( mInstName, sParse->mObj.mIndex.mTableName, &sTableSegMgr );
        if ( sRC ) //, ATTACH_SEG_FAIL );
        {
            DBM_WARN( "attach table[%s] segment fail. [%d]", sParseIndex->mTableName, sRC );
            _THROW( ERR_DBM_ATTACH_SHM_FAIL );
        }

        sTableHeader = (dbmTableHeader*) sTableSegMgr->GetUserHeader ( );

        /***********************************************
         * Data 가 이미 들어있는 Table 에 대해서는 Index 를
         * 생성할 수 없다.
         * TODO. Direct Table 은 ?
         ***********************************************/
        if ( sTableSegMgr->GetAlloc ( ) > 0 ) //, DATA_EXIST );
        {
            DBM_WARN( "table[%s] has already data. txid[%d] index[%s]",
                      sParseIndex->mTableName, mTransID, sParseIndex->mIndexName );
            _THROW( ERR_DBM_CREATE_INDEX_WITH_DATA );
        }

        /************************************************
         * DDL 이 일어났으므로 Count 를 증가한다.
         ***********************************************/
        sTableHeader->mDDLCount++;

        /***********************************************
         * 진행 중이던 DML 들 Commit 시켜버림.
         * 위의 과정에서 Fail 이면 Commit 되지 않음.
         ***********************************************/
        _CALL( mActCommit ( ) );

        /***********************************************
         * DDL Logging
         * 나중 복구 시에는 만약 attach 해봐서 성공이면 drop 해버린다.
         ***********************************************/
        sLogType = DBM_DDL_CREATE_INDEX_LOG;
        sRC = mLogMgr->mWriteMemLog( sLogType,
                                     mTransID,
                                     -1,   /* not known yet */
                                     sParseIndex->mIndexName,
                                     sParseIndex->mTableName,
                                     -1,
                                     sParse->mSQL,
                                     strlen_s(sParse->mSQL) + 1,
                                     NULL,
                                     NULL,
                                     (char**)&sLogHead );
        if ( sRC ) //, WRITE_LOG_FAIL );
        {
            DBM_ERR( "write log fail. log_type [%d]", sLogType );
            _THROW( ERR_DBM_WRITE_LOG );
        }

        sNeedRollbackF = 1;

        /***********************************************
         * Direct Table 일 경우에는 물리적인 Index Segment를
         * 생성할 필요가 없다. (실제로 Index 를 사용하지도 않는다.)
         * 하지만, 마치 Index 가 있는 것처럼 Dictionary 와
         * Table Header 정보는 갱신시킨다.
         ***********************************************/
        if ( sTableHeader->mTableObj.mTableType == DBM_TBL_DIRECT )
        {
            cmnStrCpyZ( sParseIndex->mInstName, mInstName );

            sRC = mDic->mInsert ( sParse );
            if ( sRC ) //, INSERT_DIC_FAIL );
            {
                DBM_WARN( "insert index[%s] into dic fail.[%d]", sParseIndex->mIndexName, sRC );
                _THROW( sRC );
            }

            goto CREATE_IDXSEG_DONE;
        }


        /***********************************************
         * Index Segment 를 만든다.
         * index max count 는 그냥 table 의 max 까지 확장
         * 가능하도록 한다.
         ***********************************************/
        sSlotSize        = sizeof(dbmIndexNode) + (sKeySize * DBM_INDEX_DEGREE);
        sInitSlotCount   = CALC_IDX_SLOT_COUNT(sDicTableInfo->mTable.mInitSize);
        sExtendSlotCount = CALC_IDX_SLOT_COUNT(sDicTableInfo->mTable.mExtendSize);
        //sInitSlotCount   = sDicTableInfo->mTable.mInitSize;
        //sExtendSlotCount = sDicTableInfo->mTable.mExtendSize;

        sRC = dbmSegmentManager::Create( mInstName,
                                         sParseIndex->mIndexName,
                                         sSlotSize,
                                         sInitSlotCount,
                                         sExtendSlotCount,
                                         sDicTableInfo->mTable.mMaxSize,
                                         (size_t)sizeof(dbmIndexHeader),
                                         &sIndexSegMgr );
        if ( sRC || sIndexSegMgr == NULL ) //, CREATE_SEG_FAIL );
        {
            DBM_WARN( "create index[%s] segment fail. [%d]", sParseIndex->mIndexName, sRC );
            _THROW( ERR_DBM_CREATE_SHM_FAIL );
        }

        DBM_INFO( "create index segment. slot_size[%ld] init[%ld] extend[%ld] max[%ld]",
                            sSlotSize, sInitSlotCount, sExtendSlotCount, sDicTableInfo->mTable.mMaxSize );


        /***********************************************
         * Dictionary Manager 에게 Insert 요청
         ***********************************************/
        cmnStrCpyZ( sParseIndex->mInstName, mInstName );

        sRC = mDic->mInsert( sParse );
        if ( sRC ) //, INSERT_DIC_FAIL );
        {
            DBM_WARN( "insert index[%s] into dic fail.[%d]", sParseIndex->mIndexName, sRC );
            _THROW( sRC );
        }


        /***********************************************
         * Index Header 에 dbmIndexObject 정보를 한번에 copy 해둔다.
         * Init 이 완료되었음을 mInitCompleteF 에 표기한다.
         ***********************************************/
        sIndexHeader = (dbmIndexHeader*)sIndexSegMgr->GetUserHeader();

        memset_s( sIndexHeader, 0x00, sizeof(dbmIndexObject));
        memcpy_s( sIndexHeader, sParseIndex, sizeof(dbmIndexObject) );

        sIndexHeader->mLock          = -1;
        sIndexHeader->mPID           = gettid_s ();
        sIndexHeader->mRootAllocCk   = 0;
        sIndexHeader->mRootPid       = 0;
        sIndexHeader->mCurrStep      = 0;
        sIndexHeader->mInitCompleteF = 1;
        /***********************************************
         * 변경자 : wind * 변경일 : 15.10.27 * 참고 : #1011
         * 변경 내용 : extrakey 값의 초기화 및 증가를 인덱스 매니저 안에서 처리했었으나
         * 증가 작업을 인덱스 매니저보다 선행하는 테이블 매니저에게 이관하면서 초기화 또한
         * 선행하게 변경해야했다.
         ***********************************************/
        sIndexHeader->mExtra         = 0;

#ifndef USE_NEW_SHM_NODETACH
        sIndexSegMgr->Detach();
#endif
        delete_s( sIndexSegMgr );

CREATE_IDXSEG_DONE:

        /***********************************************
         * Table Header 에 신규 dbmIndexObject 정보를 copy 해둔다.
         * index count 랑 index object 정보를 한방에 copy 하기 위해
         * sTmpIndex 를 사용한다.
         ***********************************************/
        memcpy_s ( &sTmpIndex, &sTableHeader->mIndexCount, sizeof(dbmTmpIndex) );
        memcpy_s ( &sTmpIndex.mIndex[sTableHeader->mIndexCount], sParseIndex, sizeof(dbmIndexObject) );

        sTmpIndex.mIndexCount = sTableHeader->mIndexCount + 1;

        memcpy_s ( &sTableHeader->mIndexCount, &sTmpIndex, sizeof(dbmTmpIndex) );

        /***********************************************
         * Logging 된 것을 commit 한다.
         ***********************************************/
        _CALL( mActCommit ( ) );

        /***********************************************
         * DDL 이 발생하였으면 Table 은 새로이 Prepare 한다.
         ***********************************************/
        //sRC = mPrepareTable( sParseIndex->mTableName );
        //_IF_RAISE( sRC, PREPARE_TABLE_FAIL );

        DBM_INFO( "create index [%s] ok.", sParse->mObj.mIndex.mIndexName );

        /***********************************************
         * 사용한 Segment Manager 객체는 가지고 있을 필요없으니
         * 해제한다.
         ***********************************************/
#ifndef USE_NEW_SHM_NODETACH
        sTableSegMgr->Detach();
#endif
        delete_s( sTableSegMgr );
    }
    _CATCH
    {
        _CATCH_WARN2( sParseIndex->mIndexName );

        {
            int sRet;

            /***********************************************
             * Logging 된 것을 기준으로 Rollback 시키고 리턴.
             ***********************************************/
            if ( sNeedRollbackF == 1 )
            {
                sRet = mActNormalRollback ( );
                if ( sRet != RC_SUCCESS )
                {
                    DBM_ERR( "rollback fail. [%d]", sRet );
                }
            }
        }
    }
    _FINALLY
    _END
} /* mActCreateIndex */


/******************************************************************************
 * Name : mActCommit
 *
 * Description
 *     Process Commit.
 *     Transaction Log 를 처음(mLogStartRID)부터 끝(mLogCurRID)까지
 *     따라가면서 Log Type 별로 적절한 commit 처리를 수행한다.
 *     그리고, Lock 이 걸린 Row 들을 한꺼번에 풀어준다.
 *
 *     aDeferF 가 셋팅된 경우는 Loggging 처리는 하지 않는다.
 *
 ******************************************************************************/
// [성능] DISK INSERT Top-2 함수. 2014.11.17. -okt-
__thread dbmQueueManager** g_sEnqTranObjList_mActCommit = NULL;
_VOID dbmTransManager::mActCommitLib ( int aDeferF )
{
    long long           sSCN;
    char*               sCurImage = NULL;
    long long           sCurPos;
    dbmRowHeader*       sRefRow   = NULL;
    dbmListSlotHeader*  sListRow  = NULL;
    dbmLogHeader*       sCurLog   = NULL;
    dbmTransHeader*     sTxH      = (dbmTransHeader*)mTransHeader;
    dbmSegmentManager*  sSegMgr   = NULL;
    dbmIndexManager*    sIdxMgr   = NULL;
    dbmTableHeader*     sTHead    = NULL;
    dbmQueueHeader*     sQHead    = NULL;
    dbmListHeader*      sLHead    = NULL;
    dbmIndexHeader*     sIdxHead  = NULL;
    dbmTransLog         sTransLog ;
    long long           sTxEndLogPos;
    int                 sTableIdx;
    int                 sFound = 0;
    int                 sIsFound = 0 ;
    int                 sIsEnq = 0;
    int                 sIdx   = 0 ;

    int                 sEnqTransObjCount  = 0;
    dbmQueueManager**   sEnqTranObjList = NULL;
    //dbmQueueManager*    sEnqTranObjList[DBM_MAX_TABLE_PER_TRANS];
    //int                 sEventQueueCount = 0 ;
    //dbmQueueManager*    sEventQueue[DBM_MAX_TABLE_PER_TRANS] ;
    int                 sRC;

    _TRY
    {
        /***********************************************
         * 아무 로그도 없으면 할 일 없음.
         ***********************************************/
        if ( SLOTID ( sTxH->mLogCurPos ) == -1 || SLOTID ( sTxH->mLogStartPos ) == -1 ) //, NO_TRANS_LOG );
            _RETURN;

        if ( aDeferF )
        {
            if ( sTxH->mDeferStatus == DBM_TX_DEFER_COMMIT )
            {
                // dbmDeferSync 호출 없이 dbmDeferCommit 를 다시 호출.
                _THROW( ERR_DBM_DO_NOT_PUSH_LOG );
            }
        }

        /***********************************************
         * Lock 을 못풀고 죽었을 경우 Lock 복구를 위해 사용.
         ***********************************************/
        sTxH->mLockRecoveryPos = sTxH->mLogCurPos;

        /***********************************************
         * SCN 채번
         ***********************************************/
        mLogMgr->mGetSCN ( &sSCN );

        sTxH->mStatus = DBM_TX_COMMIT;
        if ( aDeferF )
        {
            sTxH->mDeferStatus = DBM_TX_DEFER_COMMIT;
        }

        // TransLogHeader에도 박아놔야 나중에 비교를 할 것이다.
        sTxH->mSCN = sSCN;

        RTF_POINT( "TXMGR_COMMIT_8" );

        /***********************************************
         * 첫번째 로그로 이동
         ***********************************************/
        sCurPos = sTxH->mLogStartPos;

#if 0
        sRC = dbmTransManager::mDumpTxLog( mInstName, mTransID );
        DBM_DBG( "Commit.... mDumpTxLog sRC [%d]", sRC);
#endif

        /* Anchor file Start Position set */
        if ( sTxH ->mDiskLoggingEnableF  )
        {
            _CALL( mTransLogger->mAnchor ( 1 ) );
        }

        /***********************************************
         * 모든 Log 를 차례로 방문하여 Log Type 별로
         * Commit 작업 수행
         ***********************************************/
        while ( 1 )
        {
            sRefRow   = NULL;
            sIdxMgr   = NULL;
            sSegMgr   = NULL;
            sCurImage = NULL;
            sTHead    = NULL;
            sQHead    = NULL;
            sIdxHead  = NULL;

            sRC = dbmRecoveryManager::mGetLogPtr ( mUndoSegMgr, sCurPos, &sCurLog );
            _IF_RAISE2( sRC, INVALID_LOG_START );

            RTF_POINT("TXMGR_COMMIT_1");


            /***********************************************
             * Commit 시에 CurPos 가 가리키는 로그가 valid 하지
             * 않다면 문제가 있는거다.
             * 복구 시라면 그럴 수 있겠지만...
             ***********************************************/
            _IF_RAISE2( sCurLog->mLogValidF != 1 , INVALID_LOG );

            switch ( sCurLog->mLogType )
            {
                case DBM_INSERT_SLOT_LOG:
                case DBM_UPDATE_SLOT_LOG:
                case DBM_UPDATE_KEY_LOG:
                case DBM_SELECT_FOR_UPDATE_LOG:
                    /***********************************************
                     * Row 의 SCN 만 변경해주면 된다.
                     ***********************************************/
                    sRC = dbmGetTableSegMgr ( this, sCurLog->mObjectName, &sSegMgr );
                    _DASSERT( sRC == 0 );

                    sTHead = (dbmTableHeader*) sSegMgr->GetUserHeader() ;
                    //TODO: 2014.11.14 -okt- [olsnr] sTHead->mTableObj.mTableID 주소가 이미 DROP 등으로 해제된 것을 감지할 방법없다
                    _IF_RAISE2( sCurLog->mObjectID != sTHead->mTableObj.mTableID, INVALID_OBJECT );

                    _CALL( sSegMgr->Slot2Addr ( sCurLog->mRefRecord, &sRefRow ) );
                    sRefRow->mSCN = sSCN;

                    _CALL( mHandleTransLog ( sCurLog, sSegMgr ) );
                    break;

                case DBM_ENQUE_LOG:
                {
                    sRC = dbmGetQueueSegMgr ( (dbmTransManager*) this,
                                               sCurLog->mObjectName,
                                               &sSegMgr ) ;
                    _DASSERT( sRC == 0 );

                    sQHead = (dbmQueueHeader*) sSegMgr->GetUserHeader() ;
                    //TODO: 2014.11.14 -okt- [CS] sQHead->mTableObj.mTableID 주소가 이미 DROP 등으로 해제된 것을 감지할 방법없다
                    _IF_RAISE2( sCurLog->mObjectID != sQHead->mTableObj.mTableID, INVALID_OBJECT );

                    if ( g_sEnqTranObjList_mActCommit == NULL )
                    {
                        g_sEnqTranObjList_mActCommit =
                            (dbmQueueManager**)malloc_s ( sizeof(dbmQueueManager*) * DBM_MAX_TABLE_PER_TRANS );
                    }
                    sEnqTranObjList = g_sEnqTranObjList_mActCommit;

                    /***********************************************
                     * Queue commit 은 별도로 처리
                     ***********************************************/
                    // 2014.11.18. -okt- mWriteMemLog 에서 mObjectName, mTableName 같은 경우는 mTableName에 NULL로깅.
                    //sRC = mFindQueueInTx( sCurLog->mTableName, &sTableIdx );
                    sRC = mFindQueueInTx( sCurLog->mObjectName, &sTableIdx );
                    _IF_RAISE2( sRC, INVALID_LOG );

                    for ( int i = 0 ; i < sEnqTransObjCount; i ++)
                    {
                        if (sEnqTranObjList[i] == mQueue[sTableIdx] )
                        {
                            sFound = 1;
                        }
                    }

                    if ( sFound  == 0 )
                    {
                        sEnqTranObjList[sEnqTransObjCount] = mQueue[sTableIdx] ;
                        sEnqTransObjCount ++;
                    }
                    sEnqTranObjList[sEnqTransObjCount] = NULL;

                    sRC = mQueue[sTableIdx] -> mBuildEnqueueLink ( sCurLog->mRefRecord ) ;
                    if ( sRC ) //, ENQUE_COMMIT_FAIL );
                    {
                        DBM_ERR( "enque commit fail (%d)", sRC );
                        _THROW( sRC );
                    }

                    _CALL( mHandleTransLog ( sCurLog, mQueue[sTableIdx]->mGetSegMgr() ) );
                    break;
                }

                case DBM_DELETE_SLOT_LOG:
#if 0
                    /***********************************************
                     * Segment Manager 에게 Record Slot 을 반납.
                     ***********************************************/
                    // [변경전] sCurLog->mTableName -> [변경후] sCurLog->mObjectName
                    sRC = dbmGetTableSegMgr ( this, sCurLog->mObjectName, &sSegMgr );
                    _IF_RAISE2( sRC, INVALID_LOG );

                    sTHead = (dbmTableHeader*)sSegMgr->GetUserHeader();
                    _IF_RAISE2( sCurLog->mObjectID != sTHead->mTableObj.mTableID,
                               INVALID_OBJECT );
                    sRC = dbmSegFreeSlot( sSegMgr, sCurLog->mRefRecord, 0 );
                    //_IF_RAISE( sRC, DBM_INDEX_FREE_SLOT_FAIL );
                    if ( sRC != 0 )
                    {
                        _DASSERT( 0 ); // 적절한 오류처리 확인할때까지 디버그에서는 죽자.
                        _IF_RAISE2( sRC, INVALID_OBJECT ); //DBM_INDEX_FREE_SLOT_FAIL );
                    }
#endif
                    break;

                case DBM_DELETE_INDEX_LOG:
                case DBM_DELETE_INDEX_LOG2:
                    /***********************************************
                     * Index Manager 에게 Delete Key 요청
                     ***********************************************/
                    sRC = dbmGetIndexMgrByObjID( (dbmTransManager*)this,
                                                 sCurLog->mTableName,
                                                 sCurLog->mObjectID,
                                                 &sIdxMgr );
                    _IF_RAISE2(sRC || sIdxMgr == NULL, INVALID_LOG );

                    sIdxHead = (dbmIndexHeader*)sIdxMgr->mGetIndexHeader () ;

                    _IF_RAISE2( sCurLog->mObjectID != sIdxHead->mIndex.mIndexID,
                                    INVALID_OBJECT );

                    sRC = dbmRecoveryManager::mGetImagePtr ( mUndoSegMgr, sCurLog->mImageLogPos, &sCurImage );
                    _IF_RAISE2( sRC, INVALID_LOG );

                    if ( sCurLog->mLogType == DBM_DELETE_INDEX_LOG2 )
                    {
                        sRC = sIdxMgr->mDeleteKey( sCurLog->mTransID, sCurImage, 1);
                    }
                    else
                    {
                        sRC = sIdxMgr->mDeleteKey( sCurLog->mTransID, sCurImage );
                    }
                    if ( sRC ) //, DELETE_KEY_FAIL );
                    {
                        DBM_ERR( "delete key fail. txid(%d) table(%s) index(%s)",
                                 mTransID, sCurLog->mTableName, sCurLog->mObjectName );
                    }

                    break;

                case DBM_DELETE_INDEX_LOG3:
                case DBM_DELETE_INDEX_LOG4:
                    /* :
                     * rollback 에서는 Insert 처리를 하지만 현재는 할계 없다 */

                    break;

                case DBM_DELETE_DATA_LOG:
                    // [변경전] sCurLog->mTableName -> [변경후] sCurLog->mObjectName
                    sRC = dbmGetTableSegMgr ( this, sCurLog->mObjectName, &sSegMgr );
                    _IF_RAISE2( sRC, INVALID_LOG );

                    sTHead = (dbmTableHeader*)sSegMgr->GetUserHeader();
                    _IF_RAISE2( sCurLog->mObjectID != sTHead->mTableObj.mTableID, INVALID_OBJECT );

                    _CALL( sSegMgr->Slot2Addr (sCurLog->mRefRecord, &sRefRow ) );
                    memset_s( (char*)sRefRow + sizeof( dbmRowHeader ), 0x00, sCurLog->mImageSize - sizeof(dbmRowHeader) );

                    sRefRow->mSCN = 0;

                    _CALL( mHandleTransLog ( sCurLog, sSegMgr ) );

                    break;


                case DBM_LIST_LPUSH_LOG:
                case DBM_LIST_RPUSH_LOG:
                    sRC = dbmGetListSegMgr( (dbmTransManager*) this,
                                             sCurLog->mObjectName,
                                             &sSegMgr);

                    _DASSERT( sRC == 0 );

                    sLHead = (dbmListHeader*) sSegMgr->GetUserHeader();
                    _IF_RAISE2( sCurLog->mObjectID != sLHead->mTableObj.mTableID, INVALID_OBJECT );

                    _CALL(sSegMgr->Slot2Addr( sCurLog->mRefRecord, &sListRow));

                    sListRow->mSCN = sSCN;

                    /* 아직 미구현 */
                    if ( sTxH->mDiskLoggingEnableF )
                    {
                        _CALL( mHandleTransLog( sCurLog, sSegMgr ) );
                    }

                    break;

                case DBM_LIST_LPOP_LOG:
                case DBM_LIST_RPOP_LOG:
                    sRC = dbmGetListSegMgr( (dbmTransManager*)this,
                                            sCurLog->mObjectName,
                                            &sSegMgr );
                    _IF_RAISE2(sRC || sSegMgr == NULL, INVALID_LOG );

                    sRC = sSegMgr->Slot2Addr( sCurLog->mRefRecord, &sListRow );

                    sListRow->mSCN = 0;

                    // disk 미구현
                    if ( sTxH->mDiskLoggingEnableF )
                    {
                        _CALL( mHandleTransLog ( sCurLog, sSegMgr ) );
                    }

                    break;

                case DBM_DEQUE_LOG:
                    /*
                     * Dequeue 시 아예 했으므로 할일이 없다.
                     */
                    //sRC = sSegMgr->FreeSlot ( sCurLog->mRefRecord )  ;
                    break;

                case DBM_TRUNCATE_LOG :
                case DBM_DDL_DROP_TABLE_LOG :
                case DBM_DDL_DROP_INDEX_LOG :
                case DBM_DDL_DROP_QUEUE_LOG:
                case DBM_DDL_DROP_TRIG_LOG:
                    _CALL( mHandleTransLog ( sCurLog, NULL ) );
                    break;

                case DBM_ALLOC_SLOT_LOG:
                case DBM_ALLOC_IDX_SLOT_LOG:
                case DBM_INSERT_INDEX_LOG:
                case DBM_INSERT_INDEX_LOG2:
                case DBM_LOCK_ROW_LOG:
                case DBM_DEFER_INSERT_LOG:
                case DBM_DEFER_UPDATE_LOG:
                case DBM_DDL_CREATE_TABLE_LOG:
                case DBM_DDL_CREATE_QUEUE_LOG:
                case DBM_DDL_CREATE_LIST_LOG:
                case DBM_DDL_CREATE_TRIG_LOG:
                case DBM_DDL_CREATE_INDEX_LOG:
                case DBM_SET_INDEX_LOG:
                    _CALL ( mHandleTransLog (sCurLog , NULL ));
                    break;

                case DBM_LOCK_LIST_LOG:
                case DBM_LIST_HEADER_LPUSH_LOG:
                case DBM_LIST_HEADER_LPOP_LOG:
                case DBM_LIST_HEADER_RPUSH_LOG:
                case DBM_LIST_HEADER_RPOP_LOG:
                    break;

                default:
                    _RAISE2( INVALID_LOG );
                    break;
            }


            RTF_POINT("TXMGR_COMMIT_2");

            sCurLog->mCommitCompleteF = 1;

            /***********************************************
             * 만약에 mCommitCompleteF 가 1이라고 하였을 때
             * 아
             ***********************************************/
            RTF_POINT("TXMGR_COMMIT_3");

            /***********************************************
             * Log 모두 commit 처리 완료.
             ***********************************************/
            if ( sCurPos == sTxH->mLogCurPos )
            {
               break;
            }

            /***********************************************
            * 다음 로그로 이동
             ***********************************************/
            sRC = mLogMgr->mLogMoveForward( mUndoSegMgr, sTxH, &sCurPos );
            _IF_RAISE2( sRC, INVALID_LOGSLOT_LIST );
        }


        /*********************************************************
         * 여기까지 온 건 Commit 이 완료된 상황으로 볼 수 있다.
         * Commit Log 를 추가로 기록하고,
         * Disk 에 Flush 를 수행한다.  만약 Log 를 기록할게 없다면
         * 그냥 Skip 을 수행한다.
         ********************************************************/
        if ( sTxH->mDiskLoggingEnableF && mTransLogger->mLogBufferIdx != 0  )
        //if ( sTxH->mDiskLoggingEnableF && mTransLogger->mHasItem()  )
        {

            /*** Commit Log 를 만들어낸다 **/
            sTransLog.mLogType = DBM_COMMIT_LOG ;
            sTransLog.mObjectID =  -1;
            sTransLog.mSlot = -1;
            sTransLog.mSCN = sSCN ;
            sTransLog.mImagePtr = NULL ;

            //TOOD: 2014.11.18. -okt- 전체 범위를 확인하는 예는 없다.
            //memset_s ( sTransLog.mObjectName, 0x00, DBM_NAME_LEN );
            sTransLog.mObjectName[0] = 0x00;

            sTransLog.mImageSize = 0 ;

            _CALL( mTransLogger->mWriteLog ( &sTransLog ) );    // 로그버퍼에 Commit Log 를 쓴다.

            if ( ! aDeferF )
            {
                _CALL( mTransLogger->mFlush ( ) );                  // Disk 로 쓴다.
                _CALL( mTransLogger->mSync ( ) );                   // Sync 한다.
            }
        }

        if ( sTxH->mDiskLoggingEnableF  )
        {
            /* Anchor file Start Position set */
            _CALL( mTransLogger->mAnchor ( 1 ) );
        }

        /***********************************************
         * 첫번째 로그로 이동
         ***********************************************/
        sCurPos = sTxH->mLogStartPos;


        /***********************************************
         * 로그 기록 위치 초기화.
         * 만약 mLogCurPos 만 초기화하고 mImageCurPos 는
         * 초기화하지 못하고 Down 되었다면, 복구 시에
         * mLogCurPos 가 초기화되었다면 mImageCurPos 도
         * 초기화해버린다.
         * mLogCurPos 와 mImageCurPos 초기화 후 Down 되었다면
         * 복구 시에 Lock 만 풀어주면 된다.
         ***********************************************/
        sTxEndLogPos            = sTxH->mLogCurPos;

        RTF_POINT("TXMGR_COMMIT_4");

        sTxH->mImageCurPos      = MK_POS(-1,-1);

        RTF_POINT("TXMGR_COMMIT_5");

        sTxH->mRecoveryStartPos = MK_POS(-1,-1);

        RTF_POINT("TXMGR_COMMIT_6");

        sTxH->mLogCurPos        = MK_POS(-1,-1);


        /***********************************************
         * 위에서 처리한 대로 Queue Commit Operation 을 수행한다.
         ***********************************************/
        for ( int i = 0; i < sEnqTransObjCount; i++ )
        {
            sRC = sEnqTranObjList[i]->mEnqCommitAll ( sCurLog->mTransID );
        }

        /***********************************************
         * Unlock Row
         * Lock 걸었던 Row 를 모두 풀어버린다.
         * 여기까지 왔다면 이미 mLogCurPos 는 초기화된 상태이고,
         * Commit 처리는 완료되었다고 할 수 있다.
         * 따라서, 여기서 죽으면 사용자는 Commit Succ 리턴을
         * 못받았어도 내부적으로는 Commit 이 된 것으로 간주한다.
         ***********************************************/
        while ( 1 )
        {
            sQHead = NULL;

            sRC = dbmRecoveryManager::mGetLogPtr ( mUndoSegMgr, sCurPos, &sCurLog );
            _IF_RAISE2( sRC, INVALID_LOG_START );

            if ( sCurLog->mLogValidF != 1 )
            {
                /* do nothing */
            }
            else
            {
                switch( sCurLog->mLogType )
                {
                    case DBM_LOCK_ROW_LOG:
                        // [변경전] sCurLog->mTableName -> [변경후] sCurLog->mObjectName
                        sRC = dbmGetTableSegMgr ( this, sCurLog->mObjectName, &sSegMgr ) ;
                        _DASSERT( sRC == 0 );

                        sTHead = (dbmTableHeader*) sSegMgr->GetUserHeader() ;
                        _IF_RAISE( sCurLog->mObjectID != sTHead->mTableObj.mTableID, INVALID_OBJECT );

                        _CALL( sSegMgr->Slot2Addr ( sCurLog->mRefRecord, &sRefRow ) );

                        RTF_POINT("TXMGR_COMMIT_7");

                        // Commit 상황에서 UnlockTry 가 실패할 경우는 없어야 한다.
                        sRC = mLockMgr->mAtomicUnlockTry( (char*)&(sRefRow->mLock), mTransID );
                        _ASSERT ( sRC == RC_SUCCESS );

                        break;

                    case DBM_LOCK_LIST_LOG:
                        sRC = dbmGetListSegMgr( (dbmTransManager*) this, sCurLog->mObjectName, &sSegMgr );
                        _DASSERT( sRC == 0 );

                        sLHead = (dbmListHeader*) sSegMgr->GetUserHeader();
                        _IF_RAISE( sCurLog->mObjectID != sLHead->mTableObj.mTableID, INVALID_OBJECT );

                        _CALL( sSegMgr->Slot2Addr( sCurLog->mRefRecord, &sListRow ) );

                        sRC = mLockMgr->mAtomicUnlockTry( (char*)&(sListRow->mLock), mTransID );

                        break;

                    case DBM_DELETE_SLOT_LOG:
                        /***********************************************
                         * Segment Manager 에게 Record Slot 을 반납.
                         ***********************************************/
                        // [변경전] sCurLog->mTableName -> [변경후] sCurLog->mObjectName
                        sRC = dbmGetTableSegMgr ( this, sCurLog->mObjectName, &sSegMgr );
                        _IF_RAISE2( sRC, INVALID_LOG );

                        sTHead = (dbmTableHeader*)sSegMgr->GetUserHeader();
                        _IF_RAISE2( sCurLog->mObjectID != sTHead->mTableObj.mTableID,
                                INVALID_OBJECT );
                        sRC = dbmSegFreeSlot( sSegMgr, sCurLog->mRefRecord, 0 );
                        //_IF_RAISE( sRC, DBM_INDEX_FREE_SLOT_FAIL );
                        if ( sRC != 0 )
                        {
                            _DASSERT( 0 ); // 적절한 오류처리 확인할때까지 디버그에서는 죽자.
                            _IF_RAISE2( sRC, INVALID_OBJECT ); //DBM_INDEX_FREE_SLOT_FAIL );
                        }
                        break;

                    default:
                        break;
                }
            }

            /***********************************************
             * Log 모두 처리 완료.
             ***********************************************/
            if ( sCurPos == sTxEndLogPos )
                break;

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            sRC = mLogMgr->mLogMoveForward( mUndoSegMgr, sTxH, &sCurPos );
            _IF_RAISE2( sRC, INVALID_LOGSLOT_LIST );
        }

        RTF_POINT("TXMGR_COMMIT_9");

        sTxH->mLockRecoveryPos = MK_POS(-1,-1);

    }
    _CATCH
    {
        _BEGIN_SUB_CATCH
        {
            /*
             * 2014.12.14. -okt- 기존 _IF_RAISE를 사용하지 않고, 굳이 이렇게 무리하게 변경하는 것은 _cmn_errno를 설정하여 문제추적을 위해 gdb watch를 걸기 위함이 크다.
             *             [주의] _rc에 최종 오류코드를 넣는 것은 _END에서의 약속이다.
             */
            _SUB_CATCH( INVALID_LOG_START )
            {
                dbmRecoveryManager::mDumpTxHeader( mTransHeader );
                _rc = ERR_DBM_INVALID_LOG;
            }
            _SUB_CATCH( INVALID_LOG )
            {
                dbmRecoveryManager::mDumpTxHeader( (char*)sTxH );
                if ( sCurLog != NULL )
                {
                    DBM_ERR( "invalid log. type[%d]", sCurLog->mLogType );
                    dbmLogManager::mDumpLog( (char*)sCurLog );
                }
                _rc = ERR_DBM_INVALID_LOG;
            }
            _SUB_CATCH( INVALID_LOGSLOT_LIST )
            {
#ifdef _DEBUG
                //sRC = dbmTransManager::mDumpAllSlotList( mInstName, mTransID );
#endif
                _rc = ERR_DBM_INVALID_LOG;
            }
            _SUB_CATCH( INVALID_OBJECT )
            {
                DBM_ERR( "Invalid object(DDL executed). (%s)", sCurLog->mObjectName );
                _rc = ERR_DBM_INVALID_OBJECT;
            }

        }
        _END_SUB_CATCH

        _CATCH_WARN;
    }
    _FINALLY
    {
        sTxH->mSCN = -1;
    }
    _END
} /* mActCommitLib */

_VOID dbmTransManager::mActCommit( void )
{
    return mActCommitLib( 0 );
}

_VOID dbmTransManager::mDeferCommit( void )
{
    return mActCommitLib( 1 );
}

/******************************************************************************
 * Name : mDeferSync
 *
 * Description
 *     Defer Commit 처리 된 Loggging 영역을 disk write 처리 한다.
 *
 ******************************************************************************/
_VOID dbmTransManager::mDeferSync( void )
{
    dbmTransHeader* sTxH = (dbmTransHeader*) mTransHeader;

    _TRY
    {
        /* defer commit 상태일때만 처리 할 수 있다 */
        if ( sTxH->mDeferStatus != DBM_TX_DEFER_COMMIT )
        {
            _THROW(ERR_DBM_DO_NOT_PUSH_LOG);
        }

        if ( sTxH->mDiskLoggingEnableF && mTransLogger->mLogBufferIdx != 0  )
        //if ( sTxH->mDiskLoggingEnableF && mTransLogger->mHasItem()  )
        {
            _CALL( mTransLogger->mFlush ( ) );                  // Disk 로 쓴다.
            _CALL( mTransLogger->mSync ( ) );                   // Sync 한다.
            /* Anchor file Start Position set */
            _CALL( mTransLogger->mAnchor ( 1 ) );
        }


        /* commit 상태를 변경하여 준다 */
        sTxH->mDeferStatus = DBM_TX_DEFER_FREE;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END

} /* mDeferSync */


/******************************************************************************
 * Name : mActNormalRollback
 *
 * Description
 *     normal rollback processing.
 *     정상적으로 기동 상태에서만 호출되는 Rollback 함수로 모든 Undo Log 를
 *     Rollback 한다.
 *
 ******************************************************************************/
_VOID dbmTransManager::mActNormalRollback( void )
{
    return mDoRollback(-1, -1);
}


/******************************************************************************
 * Name : mActPartialRollback
 *
 * Description
 *     DML 수행 중 에러가 발생했을 때 그 DML 만 Rollback 하고 싶을 경우,
 *     또는, Undo Log 의 특정 Position 까지만 Rollback 하고 싶은 경우 사용한다.
 *     즉, DML 수행전의 마지막 로그 기록 위치를 저장해두고, 해당 위치 다음까지만
 *     Rollback 을 수행할 경우 사용한다.
 *
 * Argument
 *     aBackupLogPos   : input   : DML 수행전에 Backup 해둔 Log Position
 *     aBackupImagePos : input   : DML 수행전에 Backup 해둔 Image Log Position
 *
 ******************************************************************************/
_VOID dbmTransManager::mActPartialRollback ( long long aBackupLogPos , long long aBackupImagePos )
{
    dbmTransHeader* sTxH = (dbmTransHeader*)mTransHeader;

    _TRY
    {
        if ( aBackupLogPos == sTxH->mLogCurPos )
        {
            /***********************************************
             * DML 등의 작업 수행 직전에 백업해둔 Log Position 과
             * 달라진 것이 없어서 Rollback 한 것이 없음.
             ***********************************************/
            DBM_INFO ("aBackupLogPos == sTxH->mLogCurPos , No log Partial Rollback.\n");
            _RETURN;
        }

        _CALL( mDoRollback(aBackupLogPos, aBackupImagePos) );
    }
    _CATCH
    _FINALLY
    _END
}


/******************************************************************************
 * Name : mDoRollback
 *
 * Description
 *     mActNormalRollback 과 mActPartialRollback 함수에서 공통으로 사용하는 함수.
 *     aRollbackLogPos 가 0 보다 클 경우는 특정 Log Position 까지만 Rollback을
 *     수행하고, -1 이면 모든 Undo Log 를 Rollback 한다.
 *
 ******************************************************************************/
_VOID dbmTransManager::mDoRollback ( long long aBackupLogPos , long long aBackupImagePos )
{
    long long           sCurPos;
    int                 sRowSize;
    char*               sImage   = NULL;
    dbmLogHeader*       sCurLog  = NULL;
    dbmRowHeader*       sRefRow  = NULL;
    dbmListSlotHeader*  sListRow = NULL;
    dbmTransHeader*     sTxH     = (dbmTransHeader*)mTransHeader;
    dbmIndexManager*    sIdxMgr  = NULL;
    dbmSegmentManager*  sTblSegMgr = NULL;
    dbmSegmentManager*  sIdxSegMgr = NULL;
    dbmSegmentManager*  sListSegMgr = NULL;
    dbmLogSlotHeader*   sLogSlotH = NULL;
    dbmDicObject        sDicObject;
    dbmTableInfo*       sTableInfo = NULL;
    dbmTableHeader*     sTableHeader = NULL;
    dbmQueueHeader*     sQueueHeader = NULL;
    dbmIndexHeader*     sIndexHeader = NULL;
    dbmListHeader*      sListHeader  = NULL;

    long long           sRollbackLogPos = MK_POS(-1,-1);
    int                 sFirstDeq  = 0;
    int                 sTableIdx  = -1;
    int                 sTableType = 0;
    int                 sDeqF      = 0 ;
    int                 sQueueIdx  = 0 ;
    char                sDeqRollbackF[DBM_MAX_TABLE_PER_TRANS] ;
    int                 sRC;
    unsigned long long  i;

    _TRY
    {
        /***********************************************
         * 아무 로그도 없으면 할 일 없음.
         ***********************************************/
        if ( aBackupLogPos > 0 )
        {
            _IF_RAISE2( SLOTID(aBackupLogPos) == -1, NO_TRANS_LOG );
        }

        _IF_RAISE2( SLOTID(sTxH->mLogCurPos)   == -1, NO_TRANS_LOG );
        _IF_RAISE2( SLOTID(sTxH->mLogStartPos) == -1, NO_TRANS_LOG );


        /***********************************************
         * Lock 을 못풀고 죽었을 경우 Lock 복구를 위해 사용.
         ***********************************************/
        sTxH->mLockRecoveryPos = sTxH->mLogCurPos;

        sTxH->mStatus = DBM_TX_ROLLBACK;

        RTF_POINT("TXMGR_NORMAL_ROLLBACK_1");

        /***********************************************
         * 마지막 Rollback Log 의 Position 을 구한다.
         * aBackupLogPos 는 Rollback 대상이 아니다.
         * aBackupLogPos 의 바로 다음에 기록된 Log 까지가
         * Rollback 대상이다.
         * 전체 Rollback 처리를 할 때는 StartPos 를 만날때까지
         * 수행하면 되므로 RollbackLogPos 는 불필요.
         ***********************************************/
        if ( aBackupLogPos > 0 )
        {
            if ( OFFSET(aBackupLogPos) == sTxH->mLogCntPerSlot )
            {
                /***********************************************
                 * Slot 의 마지막 로그일 경우에는 다음 Slot 의
                 * 첫번째 Offset 을 Rollback 마지막 Pos 로 잡는다.
                 ***********************************************/
                _CALL( mUndoSegMgr->Slot2Addr( SLOTID(aBackupLogPos), &sLogSlotH ) );
                if ( sLogSlotH->mNext >= 0 )
                {
                    sRollbackLogPos = MK_POS( sLogSlotH->mNext, 0 );
                }
                else
                {
                    _RAISE2( NO_TRANS_LOG );
                }
            }
            else
            {
                sRollbackLogPos = aBackupLogPos + 1;
            }
        }
        DBM_INFO ("sRollbackLogPos [%d:%d]\n", SLOTID(sRollbackLogPos), OFFSET(sRollbackLogPos));


        /***********************************************
         * 로그 Slot 들에 대해 역으로 List 로 연결해줌.
         * 평상 시에는 성능 상 dbmLogSlotHeader 의 mNext 만 연결.
         ***********************************************/
        if ( aBackupLogPos > 0 )
        {
            sRC = dbmRecoveryManager::mLinkReverseList ( mUndoSegMgr, sTxH, SLOTID ( aBackupLogPos ) );
        }
        else
        {
            sRC = dbmRecoveryManager::mLinkReverseList ( mUndoSegMgr, sTxH, -1 );
        }
        if ( sRC ) //, LINK_REVERSE_FAIL );
        {
            dbmRecoveryManager::mDumpTxHeader( mTransHeader );
            _THROW( ERR_DBM_INVALID_LOG );
        }


        /***********************************************
         * 마지막 로그로 이동
         ***********************************************/
        sCurPos = sTxH->mLogCurPos;

        /***********************************************
         * 모든 Log 를 차례로 방문하여 Log Type 별로
         * Rollback 작업 수행
         ***********************************************/
        while ( 1 )
        {
            sRefRow    = NULL;
            sCurLog    = NULL;
            sImage     = NULL;
            sIdxMgr    = NULL;
            sTblSegMgr = NULL;
            sIdxSegMgr = NULL;
            sTableInfo = NULL;
            sTableIdx  = -1;
            sTableHeader = NULL;
            sQueueHeader = NULL;
            sIndexHeader = NULL;

            sRC = dbmRecoveryManager::mGetLogPtr ( mUndoSegMgr, sCurPos, &sCurLog );
            assert ( sRC == RC_SUCCESS /* && sCurLog != NULL */ );

            /*
             _IF_RAISE2( sRC || sCurLog == NULL, INVALID_LOG );
             */

            RTF_POINT( "TXMGR_NORMAL_ROLLBACK_2" );

#if 0
            dbmLogManager::mDumpLog( (char*)sCurLog, sCurPos );
#endif
            //DBM_INFO ("Rollback sCurPos[%d:%d]\n", SLOTID(sCurPos), OFFSET(sCurPos));

            if ( ( sCurLog->mRollbackCompleteF == 1 ) || ( sCurLog->mLogValidF != 1 ) )
            {
                /* do nothing */
                DBM_INFO ("Rollback Skip sCurPos[%d:%d]\n", SLOTID(sCurPos), OFFSET(sCurPos));
            }
            else
            {
                // 2014.12.14. -okt- 오류 체크가 빠진부분이 있지만. 의도적으로 보인다. 다만 의도적인 것은 주석을 남기면 좋겠다.
                DBM_DBG( "Recovery log type [%ld:%ld] [%s] [%s] [%lld]", 
                                            SLOTID ( sCurPos ), OFFSET ( sCurPos)
                                            , LogType2Str(sCurLog->mLogType)
                                            , sCurLog->mObjectName
                                            , sCurLog->mRefRecord
                       );
                switch( sCurLog->mLogType )
                {
                    case DBM_ALLOC_SLOT_LOG:

                        /************************************************
                         * 기존의 ALLOC_SLOT_LOG 는 Table 전용이었는데, 이제 Queue 도
                         * 동일한 ALLOC_SLOT_LOG 를 남긴다. 그렇기 때문에 여기서 Object Header를
                         * 읽어서 해당 타입으로 검사해야한다.
                         ***********************************************/
                        sRC = dbmGetQueueSegMgr ( (dbmTransManager*) this, sCurLog->mObjectName, &sTblSegMgr );
                        if ( sRC == 0 )
                        {
                            /***********************************************
                             * Queue 일때 Free Slot 을 한다.
                             ***********************************************/
                            sQueueHeader = (dbmQueueHeader*) sTblSegMgr->GetUserHeader ( );
                            _IF_RAISE2( sCurLog->mObjectID != sQueueHeader->mTableObj.mTableID, SKIP );

                            sRC = dbmSegFreeSlot ( sTblSegMgr, sCurLog->mRefRecord, 0 );
                        }
                        else
                        {
                            /***********************************************
                             * Table 일때 Free Slot 을 한다.
                             ***********************************************/

                            // [변경전] sCurLog->mTableName -> [변경후] sCurLog->mObjectName
                            sRC = dbmGetTableSegMgr ( this, sCurLog->mObjectName, &sTblSegMgr );
                            _IF_RAISE2( sRC, INVALID_LOG );

                            sTableHeader = (dbmTableHeader*) sTblSegMgr->GetUserHeader ( );
                            _IF_RAISE2( sCurLog->mObjectID != sTableHeader->mTableObj.mTableID, SKIP );

                            _CALL( dbmSegFreeSlot ( sTblSegMgr, sCurLog->mRefRecord, 0 ) );
                        }

                        break;

                    case DBM_ALLOC_IDX_SLOT_LOG:
                        /***********************************************
                         * free 는 delete key 에서 수행하도록 수정
                         ***********************************************/
                        break;

                    case DBM_INSERT_SLOT_LOG:
                        /***********************************************
                         * insert 한 row 를 초기화해버린다.
                         ***********************************************/
                        // [변경전] sCurLog->mTableName -> [변경후] sCurLog->mObjectName
                        sRC = dbmGetTableSegMgr ( this, sCurLog->mObjectName, &sTblSegMgr );
                        _DASSERT( sRC == 0 );

                        sTableHeader = (dbmTableHeader*) sTblSegMgr->GetUserHeader ( );
                        _IF_RAISE2( sCurLog->mObjectID != sTableHeader->mTableObj.mTableID, SKIP );

                        _CALL( sTblSegMgr->Slot2Addr ( sCurLog->mRefRecord, &sRefRow ) );
                        sRowSize = sRefRow->mRowSize;
                        memset_s ( (char*) sRefRow + sizeof(dbmRowHeader), 0x00, sRowSize );

                        sRefRow->mSCN     = 0;
                        sRefRow->mRowSize = 0;
                        break;


                    case DBM_ENQUE_LOG:
                        /***********************************************
                         * enque log 기록한 것 밖에 한일이 없으므로
                         * 할일이 없으나, commit 중에 enque 를 수행한 것이
                         * 있을 수 있으므로 이를 고려해야 함.
                         ***********************************************/
                        break;

                    case DBM_DEQUE_LOG:
                        /***********************************************
                         * 기존 구현은 Dequeue Rollback 시 Recovery Manager를 통한
                         * Rollback 을 구현했으나, 정상 Rollback 인 경우 이미 Transaction Manager
                         * 안에서 모든 객체들이 준비되어있고, 굳이 로그에서 이전 이미지를  읽지 않아도 데이터들을
                         * 모두 복구할 수 있다.
                         *
                         * 위 말은 다 무시할 것. Dequeue 할때 FreeSlot 을 해버리기 때문에 복구 불가.
                         ***********************************************/
                        // 2014.11.18. -okt- mWriteMemLog 에서 mObjectName, mTableName 같은 경우는 mTableName에 NULL로깅.
                        //sRC = mFindQueueInTx ( sCurLog->mTableName, &sQueueIdx );
                        sRC = mFindQueueInTx ( sCurLog->mObjectName, &sQueueIdx );
                        assert ( sRC == RC_SUCCESS && "Queue 를 못찾았다");

                        sTblSegMgr = mGetQueueMgr(sQueueIdx)->mGetSegMgr();

                        sQueueHeader = (dbmQueueHeader*) sTblSegMgr->GetUserHeader() ;
                        _IF_RAISE2( sCurLog->mObjectID != sQueueHeader->mTableObj.mTableID, SKIP );

                        sDeqF = 1 ;

                        /***********************************************
                         * Image Log 를 통해 Row Image 를 복구한다.
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _RAISE2( INVALID_LOG );
                            }
                        }

                        sRefRow = (dbmRowHeader*)sCurLog->mRefPtr;

                        sRC = dbmRecoveryManager::mGetImagePtr ( mUndoSegMgr, sCurLog->mImageLogPos, &sImage );
                        _IF_RAISE2( sRC, INVALID_LOG );

                        sRowSize = sCurLog->mImageSize;

                        mQueue[sQueueIdx]->mDeqRollback ( sImage, sRowSize );
                        if ( sDeqF == 0 )
                        {
                            memset_s ( sDeqRollbackF, 0x00, mQueueCount );
                        }

                        sDeqRollbackF[sQueueIdx] = 1;

                        break;
                    case DBM_DELETE_DATA_LOG:
                    case DBM_UPDATE_SLOT_LOG:
                    case DBM_UPDATE_KEY_LOG:
                    case DBM_SELECT_FOR_UPDATE_LOG:
                        /***********************************************
                         * Image Log 를 통해 Row Image 를 복구한다.
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _RAISE2( INVALID_LOG );
                            }
                        }

                        // [변경전] sCurLog->mTableName -> [변경후] sCurLog->mObjectName
                        sRC = dbmGetTableSegMgr ( this, sCurLog->mObjectName, &sTblSegMgr );
                        if ( sRC != 0 )
                        {
                            DBM_ERR( "dbmGetTableSegMgr Fail. rc=%d, sTblSegMgr=%p, sCurLog=%p, object=%s, flag=%d",
                                     sRC, sTblSegMgr, sCurLog, sCurLog->mObjectName, sCurLog->mImageLogValidF );
                            _DASSERT( 0 );
                        }

                        sTableHeader = (dbmTableHeader*) sTblSegMgr->GetUserHeader() ;
                        _IF_RAISE2( sCurLog->mObjectID != sTableHeader->mTableObj.mTableID, SKIP );

                        _CALL( sTblSegMgr->Slot2Addr ( sCurLog->mRefRecord, &sRefRow ) );

                        sRC = dbmRecoveryManager::mGetImagePtr ( mUndoSegMgr, sCurLog->mImageLogPos, &sImage );
                        _IF_RAISE2( sRC, INVALID_LOG );

                        sRowSize = sCurLog->mImageSize;

                        //  2014.12.14. -okt- 다른 곳에서는 sRowSize가 dbmRowHeader를 제외한 나머지 용도로 사용되나. 여기에서만 아니어서, 소스 실수 여지가 있다.
                        _DASSERT( sRowSize > (int)sizeof(dbmRowHeader) );

                        // 2014.12.14. -okt- (성능) mDoRollback - 의미상 보면 밑의 라인과 중복된다.
                        //            제거해도 될것으로 보이나. 롤백부분이고 memcpy가 부분적일수있으므로 일단 둔다.
                        memset_s ( (char*) sRefRow + sizeof(dbmRowHeader), 0x00, sRowSize - sizeof(dbmRowHeader) );
                        memcpy_s ( sRefRow, sImage, sRowSize );
                        break;

                    case DBM_LIST_LPUSH_LOG:
                    case DBM_LIST_RPUSH_LOG:
                        sRC = dbmGetListSegMgr( (dbmTransManager*) this, sCurLog->mObjectName, &sListSegMgr);
                        _DASSERT( sRC == 0 );

                        sListHeader = (dbmListHeader*) sListSegMgr->GetUserHeader();
                        _IF_RAISE2( sCurLog->mObjectID != sListHeader->mTableObj.mTableID, SKIP );

                        _CALL(sListSegMgr->ListSlot2Addr( sCurLog->mRefRecord, &sListRow ));

                        sRowSize = sListRow->mRowSize;
                        memset_s ( (char*) sListRow + sizeof(dbmListSlotHeader), 0x00, sRowSize );

                        sListRow->mSCN = 0;
                        sListRow->mRowSize = 0;

                        break;

                    case DBM_LIST_LPOP_LOG:
                    case DBM_LIST_RPOP_LOG:
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _RAISE2( INVALID_LOG );
                            }
                        }

                        sRC = dbmGetListSegMgr( (dbmTransManager*) this, sCurLog->mObjectName, &sListSegMgr );
                        if ( sRC != 0 )
                        {
                            DBM_ERR( "dbmGetListSegMgr Fail. rc=%d, sListSegMgr=%p, sCurLog=%p, object=%s, flag=%d",
                                     sRC, sListSegMgr, sCurLog, sCurLog->mObjectName, sCurLog->mImageLogValidF );
                            _DASSERT( 0 );
                        }

                        sListHeader = (dbmListHeader*) sListSegMgr->GetUserHeader();
                        _IF_RAISE2( sCurLog->mObjectID != sListHeader->mTableObj.mTableID, SKIP );

                        _CALL( sListSegMgr->Slot2Addr( sCurLog->mRefRecord, &sListRow ) );

                        sRC = dbmRecoveryManager::mGetImagePtr( mUndoSegMgr, sCurLog->mImageLogPos, &sImage );
                        _IF_RAISE2( sRC, INVALID_LOG );

                        sRowSize = sCurLog->mImageSize;

                        _DASSERT( sRowSize > (int)sizeof(dbmListSlotHeader) );

                        /* Row 초기화 처리 */
                        memset_s( (char*) sListRow + sizeof(dbmListSlotHeader), 0x00, sRowSize - sizeof(dbmListSlotHeader) );
                        /* 전의 UNDO 이미지 저장해 뒀던거 다 카피해라 */
                        memcpy_s( sListRow, sImage, sRowSize );

                        break;

                    case DBM_INSERT_INDEX_LOG:
                    case DBM_INSERT_INDEX_LOG2:
                        /***********************************************
                         * ImageLog 에 저장된 key 를 이용하여 Delete Key를 수행
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _RAISE2( INVALID_LOG );
                            }
                        }

                        sRC = dbmGetIndexMgrByObjID( (dbmTransManager*)this,
                                                     sCurLog->mTableName,
                                                     sCurLog->mObjectID,
                                                     &sIdxMgr );
                        _IF_RAISE2(sRC || sIdxMgr == NULL, INVALID_LOG );

                        sRC = dbmRecoveryManager::mGetImagePtr ( mUndoSegMgr, sCurLog->mImageLogPos, &sImage );
                        _IF_RAISE2( sRC, INVALID_LOG );

                        if ( sCurLog->mLogType == DBM_INSERT_INDEX_LOG2 )
                        {
                            sRC = sIdxMgr->mDeleteKey( sCurLog->mTransID, sImage, 1);
                        }
                        else
                        {
                            sRC = sIdxMgr->mDeleteKey( sCurLog->mTransID, sImage );
                        }

                        if (sRC)
                        {
                            DBM_ERR ("insertKey rollback fail rc=%d, table=%s, index=%s, ref=%lld\n"
                                    , sRC, sCurLog->mTableName, sCurLog->mObjectName, sCurLog->mRefRecord);
                            /* 빼는게 맞는 건가 모르겠다 */
                            //_IF_RAISE2( sRC, INVALID_LOG );
                        }

                        break;

                    case DBM_DELETE_INDEX_LOG:
                    case DBM_DELETE_INDEX_LOG2:
                    case DBM_DELETE_INDEX_LOG3:
                    case DBM_DELETE_INDEX_LOG4:
                        /***********************************************
                         * image log 에 저장된 key 를 이용하여 Insert Key를
                         * 수행한다. 마지막 로그가 아니고 중간로그인데
                         * Image 가 valid 하지 않으면 에러다.
                         ***********************************************/
                        if ( sCurLog->mImageLogValidF != 1 )
                        {
                            if ( sCurPos == sTxH->mLogCurPos )
                            {
                                break;
                            }
                            else
                            {
                                _RAISE2( INVALID_LOG );
                            }
                        }

                        /***********************************************
                         * commit 과정에서 delete key 가 이미 수행된 것에
                         * 대해서만 delete key 를 하면 된다.
                         * 모두 다 delete key 를 하면 dup 이 날 것이므로.
                         ***********************************************/
                        if ( sCurLog->mCommitCompleteF == 1             || 
                             sCurLog->mLogType == DBM_DELETE_INDEX_LOG3 ||
                             sCurLog->mLogType == DBM_DELETE_INDEX_LOG4   )
                        {
                            sRC = dbmGetIndexMgrByObjID( (dbmTransManager*)this,
                                                         sCurLog->mTableName,
                                                         sCurLog->mObjectID,
                                                         &sIdxMgr );
                            _IF_RAISE2(sRC || sIdxMgr == NULL, INVALID_LOG );

                            sRC = dbmRecoveryManager::mGetImagePtr ( mUndoSegMgr, sCurLog->mImageLogPos, &sImage );
                            _IF_RAISE2( sRC, INVALID_LOG );

                            sRC = sIdxMgr->mInsertKey( sCurLog->mTransID, sImage, sCurLog->mRefRecord );
                            if ( sRC ) //, INSERT_KEY_FAIL );
                            {
                                DBM_ERR ("deleteKey Rollback Fail rc=%d, table=%s, index=%s, Slot=%lld\n"
                                        , sRC, sCurLog->mTableName, sCurLog->mObjectName, sCurLog->mRefRecord);
                                /* 빼는게 맞는 건가 모르겠다 */
                                //_IF_RAISE2( sRC, INVALID_LOG );
                            }
                        }

                        break;

                    case DBM_DDL_CREATE_TABLE_LOG:
                    case DBM_DDL_CREATE_QUEUE_LOG:
                    case DBM_DDL_CREATE_LIST_LOG:
                        /***********************************************
                         * 1. Segment 를 Drop (DDL Flag = 1 세팅)
                         * 2. Dictionary 에서 삭제
                         *    Prepare 되었을 리는 없으므로 Unprepare 과정은 불필요.
                         ***********************************************/
                        sRC = dbmSegmentManager::Attach ( mInstName, sCurLog->mObjectName, &sTblSegMgr );
                        if ( sRC == 0 )
                        {
                            sTableHeader = (dbmTableHeader*)sTblSegMgr->GetUserHeader();
                            /* 2014.10.07 -shw- list headr로 변환하지 않아도 된다.
                             * 어차피 mTableID -1를 해주는 건데 아래 로직은 불필요하다.
                             * TableHeader->mTableObj.mTableType == DBM_TBL_LIST
                             * sListHeader = (dbmListHeader*)sTableHeader;
                             * sListHeader->mTableObj.mTableID = -1; */
                            if ( sTableHeader->mTableObj.mTableType == DBM_TBL_QUEUE )
                            {
                                sQueueHeader = (dbmQueueHeader*)sTableHeader;
                                sQueueHeader->mTableObj.mTableID = -1;
                            }
                            else
                            {
                                sTableHeader->mTableObj.mTableID = -1;
                            }

                            sRC = sTblSegMgr->Drop();
                        }

                        sTableInfo = &sDicObject.mObj.mTableInfo;

                        sDicObject.mSQLType = DBM_DROP_TABLE;
                        cmnStrCpyZ( sTableInfo->mTable.mInstName, mInstName );
                        cmnStrCpyZ( sTableInfo->mTable.mTableName, sCurLog->mObjectName );

                        sRC = mDic->mDelete( &sDicObject );
                        break;

                    case DBM_DDL_CREATE_INDEX_LOG:
                    case DBM_DDL_DROP_INDEX_LOG:
                        /***********************************************
                         * Index 의 흔적을 깔끔히 없애는게 목적.
                         *   1. Segment 를 Drop
                         *   2. Dictionary 에서 삭제
                         *   3. update table header
                         *   4. table manager 의 index 객체 삭제.
                         ***********************************************/
                        sRC = dbmSegmentManager::Attach ( mInstName, sCurLog->mObjectName, &sIdxSegMgr );
                        if ( sRC == 0 )
                        {
                            sIndexHeader = (dbmIndexHeader*)sIdxSegMgr->GetUserHeader();
                            sIndexHeader->mIndex.mIndexID = -1;

                            sRC = sIdxSegMgr->Drop();
                        }

                        sDicObject.mSQLType = DBM_DROP_INDEX;
                        cmnStrCpyZ ( sDicObject.mObj.mIndex.mInstName, mInstName );
                        cmnStrCpyZ ( sDicObject.mObj.mIndex.mIndexName, sCurLog->mObjectName );

                        sRC = mDic->mDelete( &sDicObject );

                        sRC = dbmRecoveryManager::mDropIndexFromTableHeader ( mInstName, sCurLog->mTableName, sCurLog->mObjectName );

                        sRC = mFindTableInTx( sCurLog->mTableName, &sTableIdx );
                        if ( sRC == 0 && sTableIdx >= 0 )
                        {
                            sRC = mGetTableMgr ( sTableIdx )->mRemoveIdxMgr ( sCurLog->mObjectName );
                        }
                        break;

                    case DBM_DDL_DROP_TABLE_LOG:
                        /***********************************************
                         * Drop Table 을 Rollback 해봐야 데이터 살릴 수
                         * 있는 것도 아니고... 그냥 Rollback 에서도
                         * 확실한 Drop 을 해버림.
                         *   1. Segment 를 Drop
                         *   2. Dictionary 에서 삭제
                         *   3. Unprepare table
                         ***********************************************/
                        sRC = dbmSegmentManager::Attach ( mInstName, sCurLog->mObjectName, &sTblSegMgr );
                        if ( sRC == 0 )
                        {
                            sTableHeader = (dbmTableHeader*)sTblSegMgr->GetUserHeader();
                            sTableHeader->mTableObj.mTableID = -1;
                            sTableType = sTableHeader->mTableObj.mTableType;

                            sRC = sTblSegMgr->Drop();
                        }

                        sTableInfo = &sDicObject.mObj.mTableInfo;

                        sDicObject.mSQLType = DBM_DROP_TABLE;
                        cmnStrCpyZ ( sTableInfo->mTable.mInstName, mInstName );
                        cmnStrCpyZ ( sTableInfo->mTable.mTableName, sCurLog->mObjectName );

                        sRC = mDic->mDelete( &sDicObject );

                        sRC = mUnprepareTable( sTableInfo->mTable.mTableName, sTableType );
                        break;

                    case DBM_DDL_CREATE_TRIG_LOG:
                    case DBM_DDL_DROP_TRIG_LOG:
                        sRC = dbmSegmentManager::Attach ( mInstName, sCurLog->mTableName, &sTblSegMgr );
                        if ( sRC == 0 )
                        {
                            sTableHeader = (dbmTableHeader*)sTblSegMgr->GetUserHeader();
                            //TODO: [OKT] 2015.02.27 기존코드가 안죽고 돌았지만. 그럼 memset 빼도 된다는 의미일듯, 확인요
                            //memset_s( &sTableHeader->mEventQueue, 0x00, DBM_NAME_LEN );
                            memset_s( sTableHeader->mEventQueue, 0x00, DBM_NAME_LEN );
                        }

                        sDicObject.mSQLType = DBM_DROP_TRIG;

                        cmnStrCpyZ( sDicObject.mObj.mEvent.mInstName, mInstName );
                        cmnStrCpyZ( sDicObject.mObj.mEvent.mEventSrc, sCurLog->mTableName );

                        sRC = mDic->mDelete( &sDicObject );
                        break;

                    case DBM_TRUNCATE_LOG:
                        /***********************************************
                         * 1. truncate segment 완료.
                         * 2. Table 의 모든 Index Header 초기화.
                         * 3. Table Header 초기화.
                         ***********************************************/
                        sRC = dbmSegmentManager::Attach ( mInstName, sCurLog->mObjectName, &sTblSegMgr );
                        if ( sRC == 0 )
                        {
                            sTableHeader = (dbmTableHeader*)sTblSegMgr->GetUserHeader();
                            dbmInitTableHeader( sTableHeader );

                            for(i=0; i<sTableHeader->mIndexCount; i++)
                            {
                                sIdxSegMgr = NULL;

                                sRC = dbmSegmentManager::Attach( mInstName,
                                                                 sTableHeader->mIndex[i].mIndexName,
                                                                 &sIdxSegMgr );
                                if ( sRC == 0 )
                                {
                                    sIdxSegMgr->Truncate();

                                    sIndexHeader = (dbmIndexHeader*)sIdxSegMgr->GetUserHeader();
                                    dbmInitIndexHeader ( sIndexHeader );

#ifndef USE_NEW_SHM_NODETACH
                                    sIdxSegMgr->Detach();
#endif
                                    delete_s( sIdxSegMgr );
                                }
                            }

                            sTblSegMgr->Truncate ( );
#ifndef USE_NEW_SHM_NODETACH
                            sRC = sTblSegMgr->Detach();
#endif
                            delete_s( sTblSegMgr );
                        }
                        break;

                    case DBM_DELETE_SLOT_LOG:
                    case DBM_LOCK_ROW_LOG:
                    case DBM_LOCK_LIST_LOG:
                    case DBM_DEFER_INSERT_LOG:
                    case DBM_DEFER_UPDATE_LOG:
                    case DBM_SET_INDEX_LOG:
                        /* do nothing */
                        break;

                    case DBM_LIST_HEADER_LPUSH_LOG:
                        sRC =  dbmSegmentManager::AttachList( mInstName,
                                                              sCurLog->mObjectName,
                                                              &sListSegMgr);
                        if ( sRC == 0 && sListSegMgr != NULL )
                        {


                            sListHeader = (dbmListHeader*) sListSegMgr->GetUserHeader();
                            dbmTableObject* sTableObj = &sListHeader->mTableObj;

                            /* 제일 처음에 할당 된 LPUSH 값이면 초기값은 -1이니 -1로 해주어야 한다. */
                            if ( sListHeader->mListLeftLast == sTableObj->mMaxSize-1 &&
                                sListHeader->mListTotalCount == 1 )
                            {
                                sListHeader->mListLeftLast  = -1;
                            }
                            else
                            if ( sListHeader->mListLeftLast == sTableObj->mMaxSize-1 &&
                                sListHeader->mListTotalCount > 1 )
                            {
                                /* round robin 형식이기 때문에 마지막 값에 rollback이 있을 때기존게 있다면
                                 * LPUSH 형식으로 마지막 0 값으로 position을 이동 한다 */
                                sListHeader->mListLeftLast = 0;
                            }
                            else
                            {
                                sListHeader->mListLeftLast++;
                            }

                            sListHeader->mListTotalCount = sListHeader->mListTotalCount - 1;

                            _CALL( sListSegMgr->ListFreeAlloc() );
                        }

                        break;

                    case DBM_LIST_HEADER_RPUSH_LOG:
                        sRC =  dbmSegmentManager::AttachList( mInstName,
                                                              sCurLog->mObjectName,
                                                              &sListSegMgr);
                        if ( sRC == 0 && sListSegMgr != NULL )
                        {


                            sListHeader = (dbmListHeader*) sListSegMgr->GetUserHeader();
                            dbmTableObject* sTableObj = &sListHeader->mTableObj;

                            /* 제일 처음에 할당 된 RPUSH 값이면 초기값은 -1이니 -1로 해주어야 한다. */
                            if ( sListHeader->mListRightLast == 0  && sListHeader->mListTotalCount == 1 )
                            {
                                sListHeader->mListRightLast  = -1;
                            }
                            if ( sListHeader->mListRightLast == 0 && sListHeader->mListTotalCount > 1 )
                            {
                                sListHeader->mListRightLast = sTableObj->mMaxSize-1;
                            }
                            else
                            {
                                sListHeader->mListRightLast--;
                            }

                            sListHeader->mListTotalCount = sListHeader->mListTotalCount - 1;

                            _CALL( sListSegMgr->ListFreeAlloc() );
                        }

                        break;

                    case DBM_LIST_HEADER_LPOP_LOG:
                        sRC =  dbmSegmentManager::AttachList( mInstName,
                                                              sCurLog->mObjectName,
                                                              &sListSegMgr);
                        if ( sRC == 0 && sListSegMgr != NULL )
                        {
                            sListHeader = (dbmListHeader*) sListSegMgr->GetUserHeader();
                            dbmTableObject* sTableObj = &sListHeader->mTableObj;


                            /* left하여 하나 빼갔다가 롤백하는 거니 원상 복구해 주자 */
                            /* 99 LPOP 처리 한후 Recovery 하면 -1에서 원상 복구 */
                            if ( sListHeader->mListLeftLast == -1 && sListHeader->mListTotalCount < 1 )
                            {
                                /* 처음이라는 것이니 MAX에서 -1을 하자 */
                                sListHeader->mListLeftLast  = sTableObj->mMaxSize-1;
                            }
                            else
                            {
                                /* count가 1건 이상일거고 mListLeftLast ==0 이라고 하면 MAX로복구해 준다. */
                                /* 99 MAX LPOP -> 0으로 변경 Recover MAX-1 99로 변경 */
                                if ( sListHeader->mListLeftLast == 0 && sListHeader->mListTotalCount > 0 )
                                {
                                    sListHeader->mListLeftLast = sTableObj->mMaxSize-1;
                                }
                                else
                                {
                                    sListHeader->mListLeftLast--;
                                }

                            }

                            mvpAtomicInc32(&sListHeader->mListTotalCount);

                            _CALL( sListSegMgr->ListSetAlloc() );
                        }

                        break;

                    case DBM_LIST_HEADER_RPOP_LOG:
                        sRC =  dbmSegmentManager::AttachList( mInstName,
                                                              sCurLog->mObjectName,
                                                              &sListSegMgr);
                        if ( sRC == 0 && sListSegMgr != NULL )
                        {
                            sListHeader = (dbmListHeader*) sListSegMgr->GetUserHeader();
                            dbmTableObject* sTableObj = &sListHeader->mTableObj;

                            /* left하여 하나 빼갔다가 롤백하는 거니 원상 복구해 주자 */
                            /* 99 -> 98 */
                            if ( sListHeader->mListRightLast == -1 && sListHeader->mListTotalCount < 1 )
                            {
                                /* 처음이라는 것이니 MAX에서 -1을 하자 */
                                sListHeader->mListRightLast  = 0;
                            }
                            else
                            {
                                if ( sListHeader->mListRightLast == sTableObj->mMaxSize-1 &&
                                    sListHeader->mListTotalCount > 0 )
                                {
                                    sListHeader->mListRightLast = 0;
                                }
                                else
                                {
                                    sListHeader->mListRightLast++;
                                }
                            }

                            mvpAtomicInc32(&sListHeader->mListTotalCount);

                            _CALL( sListSegMgr->ListSetAlloc() );
                        }

                        break;

                    default:
                        DBM_ERR( "invalid log type [%d]", sCurLog->mLogType );
                        _RAISE2( INVALID_LOG );
                        break;
                }

                RTF_POINT("TXMGR_NORMAL_ROLLBACK_3");

                _LABEL( SKIP );
                sCurLog->mRollbackCompleteF = 1;

                RTF_POINT("TXMGR_NORMAL_ROLLBACK_4");
            }

            /***********************************************
             * 목표위치까지 Log 모두 rollback 처리 완료.
             ***********************************************/
            if ( aBackupLogPos > 0 )
            {
                if ( sCurPos == sRollbackLogPos )
                {
                    break;
                }
            }
            else
            {
                if ( sCurPos == sTxH->mLogStartPos )
                {
                    break;
                }
            }

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            sRC = mLogMgr->mLogMoveBackward( mUndoSegMgr, sTxH, &sCurPos );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG ); //INVALID_LOGSLOT_LIST );
        }


        /***********************************************
         * 마지막 로그로 다시 이동
         ***********************************************/
        sCurPos = sTxH->mLogCurPos;

        RTF_POINT("TXMGR_NORMAL_ROLLBACK_5");


        /***********************************************
         * 로그 기록 위치 초기화.
         ***********************************************/
        if ( aBackupLogPos > 0 )
        {
            //if ( mData->mPartialCheck == 1 )
            {
                /* Range 처리 관련 되어 aBackupLogPos를 이용하여 Recovery한 후 sTxH->mImageCurPos 원래 -1이였기
                 * 때문에 기존 값으로 돌려 준다 */
                //sTxH->mImageCurPos      = MK_POS(-1,-1);
                sTxH->mImageCurPos      = aBackupImagePos;
                RTF_POINT("TXMGR_NORMAL_ROLLBACK_6");
                sTxH->mRecoveryStartPos = MK_POS(-1,-1);
            }
            //else
            //{
            //    sTxH->mImageCurPos      = aBackupImagePos;
            //    RTF_POINT("TXMGR_NORMAL_ROLLBACK_6");
            //    sTxH->mRecoveryStartPos = MK_POS(-1,-1);
            //}
        }
        else
        {
            sTxH->mImageCurPos      = MK_POS(-1,-1);
            RTF_POINT("TXMGR_NORMAL_ROLLBACK_6");
            sTxH->mRecoveryStartPos = MK_POS(-1,-1);
        }

        RTF_POINT("TXMGR_NORMAL_ROLLBACK_7");


        /***********************************************
         * Dequeue 에 대한 완료처리를 수행한다.
         ***********************************************/
        if ( sDeqF )
        {
            for ( int i = 0 ; i < mQueueCount ; i ++)
            {
                if ( sDeqRollbackF[i])
                {
                    sRC = mQueue[i]->mDeqRollbackComplete(mTransID);
                }
            }
        }


        /***********************************************
         * Unlock Row
         * Lock 걸었던 Row 를 모두 풀어버린다.
         ***********************************************/
        while(1)
        {
            sRC = dbmRecoveryManager::mGetLogPtr ( mUndoSegMgr, sCurPos, &sCurLog );
            _IF_RAISE2( sRC, INVALID_LOG );

            if ( sCurLog->mLogValidF != 1 )
            {
                /* do nothing */
            }
            else
            {
                switch( sCurLog->mLogType )
                {
                    case DBM_LOCK_ROW_LOG:
                        // [변경] sCurLog->mTableName -> sCurLog->mObjectName
                        sRC = dbmGetTableSegMgr ( this, sCurLog->mObjectName, &sTblSegMgr );
                        _DASSERT( sRC == 0 );

                        sTableHeader = (dbmTableHeader*) sTblSegMgr->GetUserHeader() ;
                        if ( sCurLog->mObjectID != sTableHeader->mTableObj.mTableID )
                            goto SKIP_LOCK_ROW;

                        _CALL( sTblSegMgr->Slot2Addr ( sCurLog->mRefRecord, &sRefRow ) );

                        // Rollback 상황에서 UnlockTry 가 실패할 경우는 없어야 한다.
                        mLockMgr->mAtomicUnlockTry( (char*)&(sRefRow->mLock), mTransID );
                        assert ( sRC == RC_SUCCESS );

                        RTF_POINT("TXMGR_NORMAL_ROLLBACK_8");
                        break;

                    case DBM_LOCK_LIST_LOG:
                        sRC = dbmGetListSegMgr ( (dbmTransManager*) this, sCurLog->mObjectName, &sListSegMgr );
                        _DASSERT( sRC == 0 );

                        sListHeader = (dbmListHeader*) sListSegMgr->GetUserHeader();

                        if ( sCurLog->mObjectID != sListHeader->mTableObj.mTableID )
                            goto SKIP_LOCK_ROW;

                        _CALL( sListSegMgr->Slot2Addr( sCurLog->mRefRecord, &sListRow ) );
                        mLockMgr->mAtomicUnlockTry( (char*)&(sListRow->mLock), mTransID );

                        break;

                    default:
                        break;
                }
            }

SKIP_LOCK_ROW:
            /***********************************************
             * Log 모두 unlock 처리 완료.
             ***********************************************/
            if ( aBackupLogPos > 0 )
            {
                if ( sCurPos == sRollbackLogPos )
                {
                    break;
                }
            }
            else
            {
                if ( sCurPos == sTxH->mLogStartPos )
                {
                    break;
                }
            }


            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            sRC = mLogMgr->mLogMoveBackward( mUndoSegMgr, sTxH, &sCurPos );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG); //INVALID_LOGSLOT_LIST );
        }


        RTF_POINT("TXMGR_NORMAL_ROLLBACK_9");

        sTxH->mLockRecoveryPos = MK_POS(-1,-1);

        RTF_POINT("TXMGR_NORMAL_ROLLBACK_10");

        /***********************************************
         * mLogCurPos 가 모든 복구의 기준점.
         ***********************************************/
        if ( aBackupLogPos > 0 )
        {
            /* Range 처리 관련 되어 aBackupLogPos를 이용하여 Recovery한 후 sTxH->mLogCurPos 원래 -1이였기
             * 때문에 기존 값으로 돌려 준다 */
            if ( mData->mPartialCheck == 1 )
            {
                //sTxH->mLogCurPos = MK_POS(-1,-1);
                sTxH->mLogCurPos = aBackupLogPos;
                mData->mPartialCheck = -1;
            }
            else
            {
                sTxH->mLogCurPos = aBackupLogPos;
            }
        }
        else
        {
            sTxH->mLogCurPos = MK_POS(-1,-1);
        }
    }
    _CATCH
    {
        _BEGIN_SUB_CATCH
        {
            _SUB_CATCH( NO_TRANS_LOG )
            {
                /* 사용자가 아무 변경 안하고 바로 Rollback */
                _RETURN;
            }
            _SUB_CATCH( INVALID_LOG )
            {
                dbmRecoveryManager::mDumpTxHeader( mTransHeader );
                _rc = ERR_DBM_INVALID_LOG;
            }
        }
        _END_SUB_CATCH

        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mDoRollback */



/******************************************************************************
 * Name : mFindTableInTx
 *
 * Description
 *     check if transaction manager has this table.
 *
 * Argument
 *     aTableName   : input   : table name to check
 *
 ******************************************************************************/
_VOID dbmTransManager::mFindTableInTx( char* aTableName, int* aTableIdx )
{
    int     i;

    /*
     * 2014.12.14. -okt- (성능) 테이블 개수가 늘어나면 성능 부담이 있을듯. 이걸 TRIE 방식으로 바꾸면 나을지도.
     *             아니면 개수 N개 이상일때만.. 이던지. PREFETCH 도 가능.
     *             1. mTable[i]->mGetTableName() 를 직접 접근으로 (빈도높다. 함수진입비용)
     *             1. 왜 INSERT는 3번 불림 ( strcmp 진입만 )
     */
    for ( i = 0; i < mTableCount; i++ )
    {
        if ( *(short*)(mTable[i]->mTableName) == *(short*)aTableName && strcmp_s ( mTable[i]->mTableName, aTableName ) == 0 )
        {
            *aTableIdx = i;
            return( RC_SUCCESS );
        }
    }

#ifdef _DEBUG
    /*
     * 2014.12.14. -okt- 가끔 여기서 죽는다. 추적로그 추가 ( 2014.09.21 )
     *      mDoRollback 3807 dbmGetTableSegMgr Fail. rc=-1, sTblSegMgr=(nil), sCurLog=0x7ff6c1697808, object=paul00000000_table_1, flag=1
     *      매번 prepare에서 Queue이어도 진입하기 때문에. 삭제되거나 DBM_TRC로 변경되어야한다.
     */
    DBM_DBG( "mFindTableInTx not found. mTableCount=%d, aTableName=%s", mTableCount, aTableName );
    for ( i = 0; i < mTableCount; i++ )
    {
        DBM_TRC( "mTable[%d]=%s", i, mTable[i]->mTableName );
    }
#endif

    return( RC_FAILURE );
}


/******************************************************************************
 * Name : mFindListInTx
 *
 * Description
 *     check if transaction manager has this table.
 *
 * Argument
 *     aQueueName   : input   : table name to check
 *
 ******************************************************************************/
_VOID dbmTransManager::mFindListInTx( char* aListName, int* aListIdx )
{
    _TRY
    {
        for( int i = 0; i < mListCount; i++ )
        {
            if ( strcmp_s( mList[i]->mGetListName(), aListName ) == 0 )
            {
                *aListIdx = i;

                return( RC_SUCCESS );
            }
        }

        _THROW(RC_FAILURE);

    }
    _CATCH
    _FINALLY
    _END
}


/******************************************************************************
 * Name : mFindQueueInTx
 *
 * Description
 *     check if transaction manager has this table.
 *
 * Argument
 *     aQueueName   : input   : table name to check
 *
 ******************************************************************************/
_VOID dbmTransManager::mFindQueueInTx( char* aQueueName, int* aQueueIdx )
{
    for ( int i = 0; i < mQueueCount; i++ )
    {
        if ( strcmp_s ( mQueue[i]->mGetQueueName ( ), aQueueName ) == 0 )
        {
            *aQueueIdx = i;
            return( RC_SUCCESS );
        }
    }

    // 못찾음
    return( RC_FAILURE );   // 이건 성능일수도 있고, 짧으므로 TryCatch 사용안하고, _VOID 만 사용.
}


/******************************************************************************
 * Name : mFindIndexInTbl
 *
 * Description
 *     check if table has index name.
 *
 * Argument
 *     aTableName   : input   : table name to check
 *
 ******************************************************************************/
_VOID dbmTransManager::mFindIndexInTbl ( dbmTableManager* aTable , char* aIndexName , int* aIdx )
{
    char    sIndexName[DBM_NAME_LEN];
    int     i;

    _TRY
    {
        for ( i = 0; i < aTable->mGetIndexCount ( ); i++ )
        {
            memset_s( sIndexName, 0x00, DBM_NAME_LEN );
            strcpy_s( sIndexName, aTable->mGetIndexMgrByIdx(i)->mGetIndexName() );

            if ( ! strcmp_s( sIndexName, aIndexName ) )
            {
                *aIdx = i;
                break;
            }
        }

        if ( i >= aTable->mGetIndexCount() )
        {
            return( RC_FAILURE );
        }
    }
    _CATCH
    _FINALLY
    _END
} /* mFindIndexInTbl */


/******************************************************************************
 * Name : mDumpTxTable
 *
 * Description
 *     Transaction Table 의 현재 상태를 dump 로 보여줌.
 *
 ******************************************************************************/
_VOID dbmTransManager::mDumpTxTable( dbmTransTable* aTransTable )
{
    int     i;

    DBM_WARN( "[Dump Transaction Table]" );

    for ( i = 0; i < DBM_MAX_TRANS; i++ )
    {
        dbmRecoveryManager::mDumpTxHeader ( dbmRecoveryManager::mGetTxHead ( (char*) aTransTable, i ) );
    }

    return RC_SUCCESS;
}


/******************************************************************************
 * Name : mDumpTxTable
 *
 * Description
 *     Transaction Table 의 현재 상태를 dump 로 보여줌.
 *
 ******************************************************************************/
_VOID dbmTransManager::mDumpTxTable ( char* aUndoName , int aStartIdx , int aEndIdx )
{
    dbmSegmentManager*  sSegMgr     = NULL;
    dbmTransTable*      sTransTable = NULL;
    int     sStartIdx = -1;
    int     sEndIdx = -1;
    int     sRC;
    int     i;

    _TRY
    {
        _CALL( dbmSegmentManager::Attach( aUndoName, aUndoName, &sSegMgr ) );

        sTransTable = (dbmTransTable*)sSegMgr->GetUserHeader();

        DBM_ERR( "[Dump Transaction Table]" );

        if ( aStartIdx >= 0 )
        {
            sStartIdx = aStartIdx;
            sEndIdx   = aEndIdx;
        }
        else
        {
            sStartIdx = 0;
            sEndIdx   = DBM_MAX_TRANS;
        }

        for ( i = sStartIdx; i < sEndIdx; i++ )
        {
            dbmRecoveryManager::mDumpTxHeader ( dbmRecoveryManager::mGetTxHead ( (char*) sTransTable, i ) );
        }
    }
    _CATCH
    _FINALLY
    _END
}


_VOID dbmTransManager::mActCreateTrig(void* aParse)
{
    dbmLogType          sLogType;
    dbmParseObject*     sParse = (dbmParseObject*)aParse;
    dbmEventObject*     sEvent = (dbmEventObject*)&sParse->mObj.mEvent;
    dbmSegmentManager*  sTableSegMgr;
    dbmTableHeader*     sTableHeader;
    dbmDicObject        sDicObject;
    dbmLogHeader*       sLogHead;
    dbmObjectDic*       sObjectDic = (dbmObjectDic *)&sDicObject.mObj;
    int                 sRC;

    _TRY
    {
        DBM_DBG( "start to create trigger [%s]", sParse->mObj.mEvent.mTriggerName );

        _IF_THROW( sParse->mObj.mEvent.mTriggerName[0] == '\0', ERR_DBM_INVALID_OBJECT_NAME );

#ifdef _DEBUG
        if ( !strncmp_s ( sParse->mObj.mEvent.mEventSrc, SYS_DIC_PREFIX, strlen_s ( SYS_DIC_PREFIX ) ) )
#else
        if ( sParse->mObj.mEvent.mEventSrc[0] == SYS_DIC_PREFIX_CHAR )   // (성능)
#endif
        {
            _THROW( ERR_DBM_DDL_DIC_OBJECT );
        }


        /***********************************************
         * trigger 이름이 다른 object 이름과 이름이 겹치면 안됨.
         ***********************************************/
        memset_s( &sDicObject, 0x00, sizeof(sDicObject) );
        sDicObject.mSQLType = DBM_CREATE_OBJECT;

        strcpy_s( sObjectDic->mInstName, mInstName );
        strcpy_s( sObjectDic->mObjectName, sParse->mObj.mEvent.mTriggerName);

        sRC = mDic->mSelect ( &sDicObject );
        if ( sRC == 0 )
        {
            _THROW( ERR_DBM_ALREADY_EXIST_IN_DIC );
        }
        _IF_THROW( sRC != ERR_DBM_NO_MATCH_RECORD, sRC ); //DIC_OPER_FAIL );


        /***********************************************
         * 중복된 트리거 확인 ($sys_trigger)
         ***********************************************/
        memset_s( &sDicObject, 0x00, sizeof(dbmDicObject) );
        sDicObject.mSQLType = DBM_CREATE_TRIG;

        cmnStrCpyZ ( sDicObject.mObj.mTableInfo.mTable.mInstName, mInstName );
        cmnStrCpyZ ( sDicObject.mObj.mEvent.mTriggerName, sEvent->mTriggerName );

        sRC = mDic->mSelect( &sDicObject );
        if ( sRC == 0 ) //, EVENT_ALREADY_SET );
        {
            DBM_WARN( "trigger[%s] already exists.", sEvent->mTriggerName );
            _THROW( ERR_DBM_EVENT_ALREADY_SET );
        }

        _IF_THROW( sRC != ERR_DBM_NO_MATCH_RECORD, sRC ); //DIC_OPER_FAIL );


        /***********************************************
         * dictionary 에 존재하는 table 인지 확인.
         ***********************************************/
        memset_s( &sDicObject, 0x00, sizeof(dbmDicObject) );
        sDicObject.mSQLType = DBM_CREATE_TABLE;

        strncpy( sDicObject.mObj.mTableInfo.mTable.mInstName,
                 mInstName,
                 DBM_NAME_LEN );

        strncpy( sDicObject.mObj.mTableInfo.mTable.mTableName,
                 sEvent->mEventSrc,
                 DBM_NAME_LEN );

        sRC = mDic->mSelect( &sDicObject );
        if ( sRC != 0 ) //, DIC_OPER_FAIL );
        {
            if ( sRC == ERR_DBM_NO_MATCH_RECORD ) //, SOURCE_NOT_EXIST );
            {
                DBM_WARN( "search table[%s] in dic for creating trigger fail.[%d]", sEvent->mEventSrc, sRC );
                if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                {
                    _THROW( ERR_DBM_TABLE_NOT_IN_DICTIONARY );
                }
            }

            _THROW( sRC );
        }


        /***********************************************
         * Event Source 는 Table, Direct Table 만 지원됨.
         ***********************************************/
        if ( sDicObject.mObj.mTableInfo.mTable.mTableType != DBM_TBL_NORMAL
                && sDicObject.mObj.mTableInfo.mTable.mTableType != DBM_TBL_DIRECT )
        {
            //_RAISE2(INVALID_SRC_TABLE_TYPE);
            DBM_WARN( "trigger can be created with table source only." );
            _THROW( ERR_DBM_INVALID_TABLE_TYPE );
        }


        /***********************************************
         * dictionary 에 존재하는 queue 인지 확인.
         ***********************************************/
        memset_s( &sDicObject, 0x00, sizeof(dbmDicObject) );
        sDicObject.mSQLType = DBM_CREATE_TABLE;

        cmnStrCpyZ ( sDicObject.mObj.mTableInfo.mTable.mInstName, mInstName );
        cmnStrCpyZ ( sDicObject.mObj.mTableInfo.mTable.mTableName, sEvent->mEventTrg );

        sRC = mDic->mSelect( &sDicObject );
        if ( sRC != 0 ) //, DIC_OPER_FAIL );
        {
            if ( sRC == ERR_DBM_NO_MATCH_RECORD ) //, TARGET_NOT_EXIST );
            {
                DBM_WARN( "search queue[%s] in dic for creating trigger fail.[%d]", sEvent->mEventTrg, sRC );
                if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                {
                    _THROW( ERR_DBM_TABLE_NOT_IN_DICTIONARY );
                }
            }

            _THROW( sRC );
        }


        /***********************************************
         * Event Target 는 Queue 만 지원.
         ***********************************************/
        if ( sDicObject.mObj.mTableInfo.mTable.mTableType != DBM_TBL_QUEUE )
        {
            DBM_WARN( "trigger can be created with queue target only." );
            _THROW( ERR_DBM_INVALID_TABLE_TYPE );
        }


        /***********************************************
         * table header에 trigger 정보를 update 해야하기
         * 때문에 table segment를 attach 해야 한다.
         ***********************************************/
        sRC = dbmSegmentManager::Attach ( mInstName, sEvent->mEventSrc, &sTableSegMgr );
        if ( unlikely( sRC ) ) //, ATTACH_SEG_FAIL );
        {
            DBM_WARN( "attach table[%s] segment fail. [%d]", sEvent->mEventSrc, sRC );
            _THROW( ERR_DBM_ATTACH_SHM_FAIL );
        }

        sTableHeader = (dbmTableHeader*)sTableSegMgr->GetUserHeader();


        /***********************************************
         * 진행중이던 DML Commit
         * 아래 과정에서 실패를 해도 이전 DML 은 Commit
         * 되어 버리지만 일단 이렇게 Go.
         ***********************************************/
        sRC = mActCommit();
        if ( sRC ) //, DML_COMMIT_FAIL );
        {
            DBM_WARN( "commit dml of tx(%d) fail during create trigger(%s).", mTransID, sEvent->mEventSrc );
            _THROW( sRC );
        }


        /***********************************************
         * DDL Logging
         ***********************************************/
        sLogType = DBM_DDL_CREATE_TRIG_LOG;

        _CALL( mLogMgr->mWriteMemLog( sLogType,
                                     mTransID,
                                     (int)-1,
                                     sEvent->mTriggerName,
                                     sEvent->mEventSrc,
                                     -1,
                                     sParse->mSQL,
                                     strlen_s(sParse->mSQL) + 1 , // for null character
                                     NULL,
                                     NULL,
                                     (char**)&sLogHead ) );


        /***********************************************
         * Dictionary Manager 에게 Insert 요청
         * Parser 에게 받은 정보가 dictionary 에 넣을 모든 정보이므로
         * 그냥 그대로 넘겨주면 된다. (instance name 만 추가)
         * (trigger name, event src, event target)
         ***********************************************/
        cmnStrCpyZ( sEvent->mInstName, mInstName );

        _CALL( mDic->mInsert( sParse ) );
        //_IF_RAISE2( sRC != 0, DIC_OPER_FAIL );

        memcpy_s( sTableHeader->mEventQueue, sEvent->mEventTrg, DBM_NAME_LEN );


        /***********************************************
         * DDL 이 일어났다.
         **********************************************/
        sTableHeader->mDDLCount ++ ;


        /***********************************************
         * Commit
         **********************************************/
        sRC = mActCommit();
        if ( sRC ) //, DML_COMMIT_FAIL );
        {
            DBM_WARN( "commit dml of tx(%d) fail during create trigger(%s).", mTransID, sEvent->mEventSrc );
            _THROW( sRC );
        }


        /***********************************************
         * Manager 객체 해제
         ***********************************************/
#ifndef USE_NEW_SHM_NODETACH
        sTableSegMgr->Detach();
#endif
        delete_s( sTableSegMgr );
    }
    _CATCH
    {
        _CATCH_WARN;
        {
            mActNormalRollback () ;
        }
    }
    _FINALLY
    _END
} /* mActCreateTrig */


_VOID dbmTransManager::mActDropTable ( void* aParse )
{
    dbmParseObject*     sParse = (dbmParseObject*)aParse;
    dbmTableInfo*       sTableInfo = (dbmTableInfo*)&sParse->mObj.mTableInfo;
    dbmLogType          sLogType;
    dbmDicObject        sDicObject;
    dbmTableInfo*       sDicTable    = (dbmTableInfo*)&sDicObject.mObj.mTableInfo;
    dbmTableHeader*     sTableHeader = NULL;
    dbmQueueHeader*     sQueueHeader = NULL;
    dbmListHeader*      sListHeader  = NULL;
    dbmLogHeader*       sLogHead     = NULL;
    dbmSegmentManager*  sSegMgr      = NULL;
    int                 sSearchRC;
    dbmEventDic*        sEventDic    = (dbmEventDic *)&sDicObject.mObj;
    int                 sRC = -1;
    unsigned long long  i;
    int                 sNeedRollbackF = 0 ;

    _TRY
    {
        DBM_INFO( "drop table[%s] start. type[%d] undo[%s]",
                  sTableInfo->mTable.mTableName, sParse->mSQLType, mInstName );

        _IF_THROW( sTableInfo->mTable.mTableName[0] == '\0', ERR_DBM_INVALID_OBJECT_NAME );

        _IF_THROW( !strcmp_s(sTableInfo->mTable.mTableName, mInstName), ERR_DBM_INVALID_OBJECT_NAME );



#ifdef _DEBUG
        if ( !strncmp_s ( sTableInfo->mTable.mTableName, SYS_DIC_PREFIX, strlen_s ( SYS_DIC_PREFIX ) ) )
#else
        if ( sTableInfo->mTable.mTableName[0] == SYS_DIC_PREFIX_CHAR )   // (성능)
#endif
        {
            _THROW( ERR_DBM_DDL_DIC_OBJECT );
        }


        /****************************************************
         * table 정보를 dictionary 로부터 조회한다.
         * (아래에서 index segment 를 drop 하기 위해 index 정보 필요)
         ****************************************************/
        sDicObject.mSQLType = DBM_CREATE_TABLE;

        strcpy_s( sDicTable->mTable.mInstName, mInstName );
        strcpy_s( sDicTable->mTable.mTableName, sTableInfo->mTable.mTableName );
        sDicTable->mIndexCount = 0;     // 2014.12.14. -okt- 존재하지 않는 테이블을 drop 할때 release에서 문제됨. (2014/07/09)

        sSearchRC = sRC = mDic->mSelect( &sDicObject );
        if ( sRC != RC_SUCCESS )
        {
            /****************************************************
             * 먼가 문제가 있는 상황이니 이건 Rollback 해야함.
             ****************************************************/

            sNeedRollbackF = 1;

            /****************************************************
             * Dictionary 에는 없지만 Segment 는 남아있는 경우를
             * 위해서 Dic 에 없어도 Drop 전체 과정을 태운다.
             ****************************************************/
            if ( sRC != ERR_DBM_NO_MATCH_RECORD )
            {
                DBM_INFO( "table[%s] search fail in dic [%d]", sTableInfo->mTable.mTableName, sRC );
                if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                {
                    _THROW( ERR_DBM_TABLE_NOT_IN_DICTIONARY );
                }

                _THROW( sRC );
            }
        }

        /* 2014.10.29 -shw- list type check */
        /* list type을 drop table로 삭제하면 안된다 */
        if ( sParse->mSQLType != DBM_DROP_LIST )
        {
            _IF_THROW( sDicTable->mTable.mTableType == DBM_TBL_LIST , ERR_DBM_INVALID_TABLE_TYPE );
        }


        /***********************************************
         * 진행중이던 DML Commit
         * 아래 과정에서 실패를 해도 이전 DML 은 Commit
         * 되어 버리지만 일단 이렇게 Go.
         ***********************************************/
        sRC = mActCommit();
        if ( sRC ) //, DML_COMMIT_FAIL );
        {
            DBM_WARN( "commit dml of tx(%d) fail during drop table(%s).", mTransID, sTableInfo->mTable.mTableName );
            _THROW( sRC );
        }


        /***********************************************
         * DDL Logging
         * 복구 시에는 만약 attach 해봐서 성공이면 drop 해버린다.
         ***********************************************/

        // Dic 조회가 실패한경우 DDL Log 를 남기면 이후 수행되면서 commit 이
        // 아예 남기지 않는다.
        if ( sNeedRollbackF == 0 )
        {
            sLogType = DBM_DDL_DROP_TABLE_LOG;
            sRC = mLogMgr->mWriteMemLog( sLogType,
                    mTransID,
                    sTableInfo->mTable.mTableID,
                    sTableInfo->mTable.mTableName,
                    NULL, // sTableInfo->mTable.mTableName,
                    -1,
                    NULL,
                    0,
                    NULL,
                    NULL,
                    (char**)&sLogHead );
            if ( sRC ) //, WRITE_LOG_FAIL );
            {
                DBM_ERR( "write log fail. log_type [%d]", sLogType );
                _THROW( ERR_DBM_WRITE_LOG );
            }

            RTF_POINT("TXMGR_DROP_TABLE_0");
        }


        /****************************************************
         * DDL Flag 를 셋팅하여 다른 DML 들이 이 값이 1 이면
         * 실패하도록 한다.
         ****************************************************/
        if ( sParse->mSQLType == DBM_DROP_LIST )
        {
            sRC = dbmSegmentManager::AttachList ( mInstName, sTableInfo->mTable.mTableName, &sSegMgr );
        }
        else
        {
            sRC = dbmSegmentManager::Attach ( mInstName, sTableInfo->mTable.mTableName, &sSegMgr );
        }

        if ( sRC == RC_SUCCESS && sSegMgr != NULL )
        {
            if ( sDicTable->mTable.mTableType == DBM_TBL_LIST )
            {
                sListHeader = (dbmListHeader*)sSegMgr->GetUserHeader();
                sListHeader->mTableObj.mTableID = -1;
                sListHeader->mDDLCount++;
            }
            else
            if ( sDicTable->mTable.mTableType == DBM_TBL_QUEUE )
            {
                sQueueHeader = (dbmQueueHeader*)sSegMgr->GetUserHeader();
                sQueueHeader->mTableObj.mTableID = -1;
                sQueueHeader->mDDLCount++;
            }
            else
            {
                sTableHeader = (dbmTableHeader*)sSegMgr->GetUserHeader();
                sTableHeader->mTableObj.mTableID = -1;
                sTableHeader->mEventQueue[0] = '\0';
                sTableHeader->mDDLCount++;
            }
        }

        RTF_POINT("TXMGR_DROP_TABLE_1");


        /****************************************************
         * 이미 DML 등을 사용하고 있던 handle 을 그대로 사용할
         * 경우도 있으므로 Table Unprepare.
         ****************************************************/
        sRC = mUnprepareTable( sTableInfo->mTable.mTableName,
                               sDicTable->mTable.mTableType );


        /***********************************************
         * Table Segment 를 Drop 한다.
         * 실패해도 그냥 무시.
         ***********************************************/
        if ( sSegMgr != NULL )
        {
            if ( sDicTable->mTable.mTableType != DBM_TBL_LIST )
            {
                sSegMgr->Drop();
                delete_s( sSegMgr );
            }
            else
            {
                sSegMgr->DropList();
                delete_s( sSegMgr );
            }
        }

        RTF_POINT("TXMGR_DROP_TABLE_2");


        /***********************************************
         * Index Segment 를 Drop 한다.
         * 2014.10.22 -okt- 실패해도 그냥 무시에 대한 약속을 (void)로 한다.
         ***********************************************/
        for ( i = 0; i < sDicTable->mIndexCount; i++ )
        {
            //sRC = dbmSegmentManager::Drop( mInstName, sDicTable->mIndex[i].mIndexName );
            (void) dbmSegmentManager::Drop( mInstName, sDicTable->mIndex[i].mIndexName );
        }

        RTF_POINT("TXMGR_DROP_TABLE_3");


        /***********************************************
         * 1. table header 의 queue 를 null 로 변경해줌 (위에서).
         * 2. trigger 를 disable 시킴.
         *    EventSrc 가 Drop 하려는 Table 이름과 같은 경우만
         *    처리해주면 됨.
         *    $sys_trig table 의 0 번 index 가 inst_nam 과
         *    event_source 를 key 컬럼으로 가지고 있으므로
         *    아래의 정보만 넘겨주고 조회할 수 있음.
         ***********************************************/
        memset_s( &sDicObject, 0x00, sizeof(sDicObject) );

        sDicObject.mSQLType = DBM_CREATE_TRIG;
        strcpy( sEventDic->mInstName, mInstName );
        strcpy( sEventDic->mEventSrc, sTableInfo->mTable.mTableName );

        sRC = mDic->mSelect( &sDicObject );
        if ( sRC == 0 )
        {
            sprintf( sEventDic->mEnableFlag, "%s", "DISABLE");

            sRC = mDic->mUpdate( &sDicObject );
        }


        /***********************************************
         * Dictionary Manager 에게 Delete 요청.
         * (index 정보까지 delete 됨)
         ***********************************************/
        cmnStrCpyZ( sTableInfo->mTable.mInstName, mInstName );
        sRC = mDic->mDelete( sParse );

        RTF_POINT("TXMGR_DROP_TABLE_4");


        /***********************************************
         * Logging 된 것을 commit 한다.
         ***********************************************/
        sRC = mActCommit();
        if ( sRC ) //, COMMIT_FAIL );
        {
            DBM_ERR( "commit fail. rc[%d]", sRC );
            _THROW( sRC );
        }


        DBM_INFO( "drop table[%s] end. undo[%s]", sTableInfo->mTable.mTableName, mInstName );


        /***********************************************
         * Dic 에는 없었어도 Drop 과정이기 때문에 Segment 를
         * 삭제하는 과정을 탄 경우, 삭제작업은 수행하고
         * 사용자에 대한 리턴은 Not Found 로 한다.
         ***********************************************/
        if ( sSearchRC == ERR_DBM_NO_MATCH_RECORD )
        {
            return( ERR_DBM_TABLE_NOT_IN_DICTIONARY ); // 의도적
        }
    }
    _CATCH
    {
        _CATCH_WARN;

        {
            int     sRet;

            /***********************************************
             * Logging 된 것을 기준으로 Rollback 시키고 리턴.
             * Rollback 이 Fail 이면 ?
             ***********************************************/
            sRet = mActNormalRollback();
            if ( sRet != RC_SUCCESS )
            {
                DBM_ERR( "rollback fail. [%d]", sRet );
            }
        }
    }
    _FINALLY
    _END
} /* mActDropTable */


_VOID dbmTransManager::mActAlterTableDiskLog ( void* aParse )
{
    dbmParseObject*     sParse = (dbmParseObject*)aParse;
    dbmDicObject        sDicObject;
    dbmTableInfo*       sParseTableInfo = (dbmTableInfo*)&sParse->mObj.mTableInfo;
    dbmTableInfo*       sDicTableInfo   = (dbmTableInfo*)&sDicObject.mObj.mTableInfo;
    dbmTableHeader*     sTableHeader    = NULL;
    dbmQueueHeader*     sQueueHeader    = NULL;
    dbmSegmentManager*  sSegMgr         = NULL;
    dbmListHeader*      sListHeader     = NULL;
    unsigned long long  i;

    _TRY
    {
        DBM_WARN( "alter table disk logging. table[%s] inst[%s] flag[%d]",
                  sParseTableInfo->mTable.mTableName, mInstName, sParseTableInfo->mTable.mNologgingF );

        /****************************************************
         * table 의 모든 정보를 dictionary 로부터 조회해둔다.
         ****************************************************/
        sDicObject.mSQLType = DBM_CREATE_TABLE;

        strcpy_s( sDicTableInfo->mTable.mInstName, mInstName );
        strcpy_s( sDicTableInfo->mTable.mTableName, sParseTableInfo->mTable.mTableName );

        _rc = mDic->mSelect( &sDicObject );
        _IF_RAISE2( _rc != RC_SUCCESS, SEARCH_DIC_FAIL );


        /*****************************************************
         * 테이블 인지 큐인지 체크
         ****************************************************/
        if ( sDicObject.mObj.mTableInfo.mTable.mTableType ==  DBM_TBL_LIST  )
        {
            _rc = dbmSegmentManager::Attach ( mInstName, sDicTableInfo->mTable.mTableName, &sSegMgr ) ;
            _IF_RAISE2 ( _rc, ATTACH_FAIL ) ;
            sListHeader = (dbmListHeader*)sSegMgr->GetUserHeader () ;
            sListHeader->mTableObj.mNologgingF = sParseTableInfo->mTable.mNologgingF;
            delete_s( sSegMgr );
        }
        else
        if ( sDicObject.mObj.mTableInfo.mTable.mTableType ==  DBM_TBL_QUEUE  )
        {
            _rc = dbmSegmentManager::Attach ( mInstName, sDicTableInfo->mTable.mTableName, &sSegMgr ) ;
            _IF_RAISE2 ( _rc, ATTACH_FAIL ) ;
            sQueueHeader = (dbmQueueHeader*)sSegMgr->GetUserHeader () ;
            sQueueHeader->mTableObj.mNologgingF = sParseTableInfo->mTable.mNologgingF;
            delete_s( sSegMgr );
        }
        else
        {
            _rc = dbmSegmentManager::Attach ( mInstName, sDicTableInfo->mTable.mTableName, &sSegMgr ) ;
            _IF_RAISE2 ( _rc, ATTACH_FAIL ) ;
            sTableHeader = (dbmTableHeader*)sSegMgr->GetUserHeader () ;
            sTableHeader->mTableObj.mNologgingF = sParseTableInfo->mTable.mNologgingF;
            delete_s( sSegMgr );
        }

        /********************************************************
         * Dictionary UPDATE
         ********************************************************/
        _rc = mDic->mSetDiskNoLogging ( &sDicObject ,  sParseTableInfo->mTable.mNologgingF ) ;
        _IF_RAISE2( _rc != RC_SUCCESS, SEARCH_DIC_FAIL );
    }
    _CATCH
    {
        _BEGIN_SUB_CATCH
        {
            _SUB_CATCH( ATTACH_FAIL )
            {
                DBM_ERR( "Fail to attach [%s], rc=%d", sDicTableInfo->mTable.mTableName, _rc ) ;
                _rc = RC_FAILURE;
            }
            _SUB_CATCH( SEARCH_DIC_FAIL )
            {
                DBM_ERR( "search table[%s] from dic. rc(%d)", sParseTableInfo->mTable.mTableName, _rc );
                if ( _rc == ERR_DBM_NO_MATCH_RECORD )
                {
                    _rc = ERR_DBM_TABLE_NOT_IN_DICTIONARY;
                }
            }
        }
        _END_SUB_CATCH

        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mActAlterTableDiskLog */


_VOID dbmTransManager::mActAlterTableMemLog ( void* aParse )
{
    dbmParseObject*     sParse = (dbmParseObject*)aParse;
    dbmDicObject        sDicObject;
    dbmTableInfo*       sParseTableInfo = (dbmTableInfo*)&sParse->mObj.mTableInfo;
    dbmTableInfo*       sDicTableInfo   = (dbmTableInfo*)&sDicObject.mObj.mTableInfo;
    dbmIndexObject*     sDicIndex       = (dbmIndexObject*)&sDicObject.mObj.mIndex;
    dbmTableHeader*     sTableHeader    = NULL;
    dbmSegmentManager*  sSegMgr         = NULL;
    int                 sTIdx = -1;
    int                 sRC = -1;
    unsigned long long  i;

    _TRY
    {
        DBM_WARN( "alter table memory logging. table[%s] inst[%s] flag[%d]",
                            sParseTableInfo->mTable.mTableName, mInstName,
                            sParseTableInfo->mTable.mNoMemloggingF );


        /****************************************************
         * table 의 모든 정보를 dictionary 로부터 조회해둔다.
         ****************************************************/
        sDicObject.mSQLType = DBM_CREATE_TABLE;

        strcpy_s( sDicTableInfo->mTable.mInstName, mInstName );
        strcpy_s( sDicTableInfo->mTable.mTableName, sParseTableInfo->mTable.mTableName );

        sRC = mDic->mSelect( &sDicObject );
        if ( sRC )
        {
            DBM_ERR( "search table[%s] from dic. rc(%d)", sParseTableInfo->mTable.mTableName, sRC );
            if ( sRC == ERR_DBM_NO_MATCH_RECORD )
            {
                _THROW( ERR_DBM_TABLE_NOT_IN_DICTIONARY );
            }

            _THROW( sRC );
        }


        sRC = mPrepareTable( sParseTableInfo->mTable.mTableName );
        _IF_THROW( sRC != 0, ERR_DBM_TABLE_NOT_PREPARED );

        sRC = mFindTableInTx( sParseTableInfo->mTable.mTableName, &sTIdx );
        _IF_THROW( sRC != 0, ERR_DBM_TABLE_NOT_PREPARED );

        /*****************************************************
         * table 의 no memory logging flag 갱신
         ****************************************************/
        if ( sDicObject.mObj.mTableInfo.mTable.mTableType == DBM_TBL_QUEUE )
        {
            _THROW( ERR_DBM_MUST_MEMLOG_FOR_QUEUE );
        }

        sRC = dbmSegmentManager::Attach ( mInstName, sDicTableInfo->mTable.mTableName, &sSegMgr );
        if ( sRC ) //, ATTACH_FAIL );
        {
            DBM_ERR ("Fail to attach [%s], rc=%d", sDicTableInfo->mTable.mTableName, sRC );
            _THROW( RC_FAILURE );
        }

        sTableHeader = (dbmTableHeader*) sSegMgr->GetUserHeader ( );
        sTableHeader->mTableObj.mNoMemloggingF = sParseTableInfo->mTable.mNoMemloggingF;

        delete_s( sSegMgr );


        /********************************************************
         * Dictionary UPDATE
         ********************************************************/
        sRC = mDic->mSetMemNoLogging ( &sDicObject, sParseTableInfo->mTable.mNoMemloggingF ) ;
        if ( sRC )
        {
            DBM_ERR( "search table[%s] from dic. rc(%d)", sParseTableInfo->mTable.mTableName, sRC );
            if ( sRC == ERR_DBM_NO_MATCH_RECORD )
            {
                _THROW( ERR_DBM_TABLE_NOT_IN_DICTIONARY );
            }

            _THROW( sRC );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mActAlterTableMemLog */


/******************************************************************************
 * Name : mActTruncate
 *
 * Description
 *   table truncation.
 *   TODO. dictionary 의 table id 가 수정되어야할 것 같다.
 *         (table header 의 id 도 수정해주어야 함)
 *         자신의 Table Manager 객체의 Table ID 도 수정.
 *         -> 다른 Trans 의 Table Manager 객체의 Table ID 가
 *            Table Header 의 것과 틀리면 Truncate 된 것으로 인지가능.
 *
 ******************************************************************************/
_VOID dbmTransManager::mActTruncate ( void* aParse )
{
    dbmParseObject*     sParse = (dbmParseObject*)aParse;
    dbmDicObject        sDicObject;
    dbmTableInfo*       sParseTableInfo = (dbmTableInfo*)&sParse->mObj.mTableInfo;
    dbmTableInfo*       sDicTableInfo   = (dbmTableInfo*)&sDicObject.mObj.mTableInfo;
    dbmIndexObject*     sDicIndex       = (dbmIndexObject*)&sDicObject.mObj.mIndex;
    dbmTableHeader*     sTableHeader    = NULL;
    dbmQueueHeader*     sQueueHeader    = NULL;
    dbmListHeader*      sListHeader     = NULL;
    dbmIndexHeader*     sIndexHeader    = NULL;
    dbmLogType          sLogType;
    dbmLogHeader*       sLogHead        = NULL;
    dbmSegmentManager*  sSegMgr         = NULL;
    int                 sTIdx = -1;
    int                 sRC = -1;
    unsigned long long  i;

    _TRY
    {
        DBM_INFO( "truncate table[%s] start. undo[%s]", sParseTableInfo->mTable.mTableName, mInstName );

        _IF_THROW( sParseTableInfo->mTable.mTableName[0] == '\0', ERR_DBM_INVALID_OBJECT_NAME );

#ifdef _DEBUG
        if ( !strncmp_s ( sParseTableInfo->mTable.mTableName, SYS_DIC_PREFIX, strlen_s ( SYS_DIC_PREFIX ) ) )
#else
        if ( sParseTableInfo->mTable.mTableName[0] == SYS_DIC_PREFIX_CHAR )   // (성능)
#endif
        {
            _THROW( ERR_DBM_DDL_DIC_OBJECT );
        }


        cmnStrCpyZ ( sParseTableInfo->mTable.mInstName, mInstName );
        memset_s ( &sDicObject, 0x00, sizeof(dbmDicObject) );


        /****************************************************
         * table 의 모든 정보를 dictionary 로부터 조회해둔다.
         * 이는 table 의 모든 index drop 및 table/index
         * 재생성 시 필요하다.
         ****************************************************/
        sDicObject.mSQLType = DBM_CREATE_TABLE;

        strcpy_s( sDicTableInfo->mTable.mInstName, mInstName );
        strcpy_s( sDicTableInfo->mTable.mTableName, sParseTableInfo->mTable.mTableName );

        sRC = mDic->mSelect( &sDicObject );
        if ( sRC != 0 ) //, SEARCH_DIC_FAIL );
        {
            DBM_ERR( "search table[%s] from dic. rc(%d)", sParseTableInfo->mTable.mTableName, sRC );
            if ( sRC == ERR_DBM_NO_MATCH_RECORD )
            {
                _THROW( ERR_DBM_TABLE_NOT_IN_DICTIONARY );
            }

            _THROW( sRC );
        }

        /* 2015.03.18 -shw- sequence truncate 처리 할 수 없다 */
        _IF_THROW ( sDicTableInfo->mTable.mTableType == DBM_TBL_SEQUENCE, ERR_DBM_SEQ_NOT_TRUNCATE );


        /****************************************************
         * 기존에 진행중이던 Transaction 은 Commit 해버린다.
         ****************************************************/
        sRC = mActCommit();
        if ( sRC ) //, DML_COMMIT_FAIL );
        {
            DBM_WARN( "commit dml of tx(%d) fail during truncate table(%s).", mTransID, sParseTableInfo->mTable.mTableName );
            _THROW( sRC );
        }


        /****************************************************
         * TableID 를 Update 한다.
         * Update 후의 dbmTableInfo 정보가 sDicObject 에
         * 담겨서 리턴된다.
         ****************************************************/
        sRC = mDic->mUpdateTableID( &sDicObject );
        if ( sRC != 0 ) //, UPDATE_DIC_FAIL );
        {
            DBM_ERR( "update table[%s] from dic. rc(%d)", sParseTableInfo->mTable.mTableName, sRC );
            if ( sRC == ERR_DBM_NO_MATCH_RECORD )
            {
                _THROW( ERR_DBM_TABLE_NOT_IN_DICTIONARY );
            }

            _THROW( sRC );
        }

        RTF_POINT( "TXMGR_TRUNCATE_0" )


        if ( sDicTableInfo->mTable.mTableType == DBM_TBL_LIST )
        {
            sRC = mFindListInTx( sParseTableInfo->mTable.mTableName, &sTIdx );
            if ( sTIdx >= 0 )
            {
                mList[sTIdx]->mSetTableID( sDicTableInfo->mTable.mTableID );
            }
        }
        else
        {
            /****************************************************
             * Prepare 된 Table 이라면 TableID 를 Update 한다.
             ****************************************************/
            sRC = mFindTableInTx( sParseTableInfo->mTable.mTableName, &sTIdx );
            if ( sTIdx >= 0 )
            {
                mTable[sTIdx]->mSetTableID( sDicTableInfo->mTable.mTableID );
            }
        }


        /***********************************************
         * DDL Logging
         *  - 사실 truncate 를 통해 데이터를 복구할 수는 없고,
         *    대신 truncate 를 여러번 수행했을 때 문제없이
         *    재수행될 수 있도록 한다.
         *    그러기 위해서는 Dictionary 정보가 완전 완료 전까지는
         *    원 상태로 남아있어야 한다.
         ***********************************************/
        sLogType = DBM_TRUNCATE_LOG;
        sRC = mLogMgr->mWriteMemLog( sLogType,
                                     mTransID,
                                     sDicTableInfo->mTable.mTableID, /* new table ID */
                                     sParseTableInfo->mTable.mTableName,
                                     mInstName,  /* rollback recovery 시 필요 */
                                     -1,
                                     NULL,
                                     0,
                                     NULL,
                                     NULL,
                                     (char**)&sLogHead );
        if ( sRC ) //, WRITE_LOG_FAIL );
        {
            DBM_ERR( "write log fail. log_type [%d]", sLogType );
            sRC = ERR_DBM_WRITE_LOG;
        }

        RTF_POINT( "TXMGR_TRUNCATE_1" )


        /***********************************************
         * Index Segment 를 Truncate 한다.
         * Index Segment 은 Normal Table 만 존재한다.
         ***********************************************/
        if ( sDicTableInfo->mTable.mTableType != DBM_TBL_QUEUE &&
             sDicTableInfo->mTable.mTableType != DBM_TBL_LIST    )
        {
            for ( i = 0; i < sDicTableInfo->mIndexCount; i++ )
            {
                sSegMgr = NULL;
                sDicIndex = &sDicTableInfo->mIndex[i];

                sRC = dbmSegmentManager::Attach ( mInstName, sDicIndex->mIndexName, &sSegMgr );
                if ( sRC == 0 )
                {
                    sRC = sSegMgr->Truncate ( );

                    RTF_POINT( "TXMGR_TRUNCATE_2" )

                    sIndexHeader = (dbmIndexHeader*) sSegMgr->GetUserHeader ( );

                    memcpy_s ( sIndexHeader, sDicIndex, sizeof(dbmIndexObject) );
                    dbmInitIndexHeader ( sIndexHeader );

                    RTF_POINT( "TXMGR_TRUNCATE_3" )

#ifndef USE_NEW_SHM_NODETACH
                    sRC = sSegMgr->Detach();
#endif
                    delete_s( sSegMgr );
                }
            }
        }


        /***********************************************
         * Table Segment 를 Truncate 한다.
         * Table/Queue Header 를 초기화한다.
         ***********************************************/
        sSegMgr = NULL;

        if ( sDicTableInfo->mTable.mTableType == DBM_TBL_LIST )
        {
            sRC = dbmSegmentManager::AttachList( mInstName, sDicTableInfo->mTable.mTableName, &sSegMgr );
            if ( sRC == 0 )
            {
                _DASSERT ( sSegMgr != NULL );
                sRC = sSegMgr->TruncateList();
            }
        }
        else
        {
            sRC = dbmSegmentManager::Attach( mInstName, sDicTableInfo->mTable.mTableName, &sSegMgr );
            if ( sRC == 0 )
            {
                _DASSERT ( sSegMgr != NULL );
                sRC = sSegMgr->Truncate();
            }
        }

        RTF_POINT( "TXMGR_TRUNCATE_4" )

        if ( sDicTableInfo->mTable.mTableType == DBM_TBL_LIST )
        {
            sListHeader = (dbmListHeader*)sSegMgr->GetUserHeader();
            memcpy_s( sListHeader,
                      sDicTableInfo,
                      sizeof(dbmTableInfo)-sizeof(dbmColumnSetObject) );

            RTF_POINT( "TXMGR_TRUNCATE_7" )

            dbmInitListHeader( sListHeader );
        }
        else
        if ( sDicTableInfo->mTable.mTableType == DBM_TBL_QUEUE )
        {
            sQueueHeader = (dbmQueueHeader*)sSegMgr->GetUserHeader();
            memcpy_s( sQueueHeader,
                      sDicTableInfo,
                      sizeof(dbmTableInfo)-sizeof(dbmColumnSetObject) );

            RTF_POINT( "TXMGR_TRUNCATE_5" )

            dbmInitQueueHeader( sQueueHeader );
        }
        else
        {
            sTableHeader = (dbmTableHeader*)sSegMgr->GetUserHeader();
            memcpy_s( sTableHeader, sDicTableInfo, sizeof(dbmTableInfo) );

            RTF_POINT( "TXMGR_TRUNCATE_6" )

            dbmInitTableHeader( sTableHeader );
        }

#ifndef USE_NEW_SHM_NODETACH
        sRC = sSegMgr->Detach();
#endif
        delete_s( sSegMgr );


        /***********************************************
         * Logging 된 것을 commit 한다.
         ***********************************************/
        _CALL( mActCommit() );

        DBM_DBG( "truncate table[%s] end. undo[%s]", sDicTableInfo->mTable.mTableName, mInstName );
    }
    _CATCH
    {
        _CATCH_WARN;

        {
            int     sRet;

            /***********************************************
             * Logging 된 것을 기준으로 Rollback 시키고 리턴.
             * Rollback 이 Fail 이면 ?
             ***********************************************/
            sRet = mActNormalRollback();
            if ( sRet != RC_SUCCESS )
            {
                DBM_ERR( "rollback fail. [%d]", sRet );
            }
        }
    }
    _FINALLY
    _END
} /* mActTruncate */


_VOID dbmTransManager::mActDropIndex ( void* aParse )
{
    dbmDicObject        sDicObject;
    dbmParseObject*     sParse = (dbmParseObject*)aParse;
    dbmIndexObject*     sParseIndex  = (dbmIndexObject*)&sParse->mObj.mIndex;
    dbmLogType          sLogType;
    dbmLogHeader*       sLogHead     = NULL;
    dbmIndexHeader*     sIndexHeader = NULL;
    dbmSegmentManager*  sSegMgr      = NULL;
    int                 sRC = -1;

    _TRY
    {
        _IF_THROW( sParseIndex->mIndexName[0] == '\0', ERR_DBM_INVALID_OBJECT_NAME );

#ifdef _DEBUG
        if ( !strncmp_s ( sParseIndex->mIndexName, SYS_DIC_PREFIX, strlen_s ( SYS_DIC_PREFIX ) ) )
#else
        if ( sParseIndex->mIndexName[0] == SYS_DIC_PREFIX_CHAR )   // (성능)
#endif
        {
            _THROW( ERR_DBM_DDL_DIC_OBJECT );
        }

        /***********************************************
         * 존재하는 Index 인지를 확인.
         ***********************************************/
        sDicObject.mSQLType = DBM_CREATE_INDEX;

        cmnStrCpyZ( sDicObject.mObj.mIndex.mInstName, mInstName );
        cmnStrCpyZ( sDicObject.mObj.mIndex.mIndexName, sParseIndex->mIndexName );

        sRC = mDic->mSelect ( &sDicObject );
        if ( sRC ) //, SEARCH_INDEX_FAIL );
        {
            DBM_WARN( "search dic fail. txid(%d) index_name(%s)", mTransID, sParseIndex->mIndexName );
            if ( sRC == ERR_DBM_NO_MATCH_RECORD )
            {
                _THROW( ERR_DBM_INDEX_NOT_IN_DICTIONARY );
            }
            _THROW( sRC );
        }

        /***********************************************
         * 진행중이던 DML Commit
         ***********************************************/
        _CALL( mActCommit() );


        /***********************************************
         * DDL Logging
         * 복구 시에는 만약 attach 해봐서 성공이면 drop 해버린다.
         ***********************************************/
        sLogType = DBM_DDL_DROP_INDEX_LOG;
        sRC = mLogMgr->mWriteMemLog( sLogType,
                                     mTransID,
                                     sDicObject.mObj.mIndex.mIndexID,
                                     sParseIndex->mIndexName,
                                     sDicObject.mObj.mIndex.mTableName,
                                     -1,
                                     NULL,
                                     0,
                                     NULL,
                                     NULL,
                                     (char**)&sLogHead );
        if ( sRC ) //, WRITE_LOG_FAIL );
        {
            DBM_ERR( "write log fail. log_type [%d]", sLogType );
            _THROW( ERR_DBM_WRITE_LOG );
        }

        /***********************************************
         * IndexHeader 에 DDL Flag 를 1 로 셋팅.
         ***********************************************/
        sRC = dbmSegmentManager::Attach ( mInstName, sParseIndex->mIndexName, &sSegMgr );
        if ( sRC == 0 )
        {
            _DASSERT ( sSegMgr != NULL );
            sIndexHeader = (dbmIndexHeader*) sSegMgr->GetUserHeader ( );
            sIndexHeader->mIndex.mIndexID = -1;

#ifndef USE_NEW_SHM_NODETACH
            sSegMgr->Detach();
#endif
            delete_s( sSegMgr );
        }


        /***********************************************
         * Segment 를 Drop 한다.
         * 실패해도 그냥 무시.
         ***********************************************/
        (void) dbmSegmentManager::Drop( mInstName, sParse->mObj.mIndex.mIndexName );


        /***********************************************
         * Dictionary Manager 에게 Delete 요청.
         * (이미 table 이 drop 되었다면 index 정보도
         *  delete 되어서 not found 뜰 것이다)
         ***********************************************/
        cmnStrCpyZ( sParseIndex->mInstName, mInstName );
        sRC = mDic->mDelete( sParse );


        /***********************************************
         * Table Header 에서 Index 정보 삭제.
         ***********************************************/
        _CALL( dbmRecoveryManager::mDropIndexFromTableHeader( mInstName,
                                                             sDicObject.mObj.mIndex.mTableName,
                                                             sParseIndex->mIndexName ) );

        /************************************************
         * DDL 이 발생했으므로 해당 Table Header 에 DDL count 추가
         ***********************************************/

        sRC = dbmSegmentManager::Attach ( mInstName, sParseIndex->mTableName, &sSegMgr );
        if ( sRC == 0 )
        {
            _DASSERT ( sSegMgr != NULL );
            ( (dbmTableHeader*) sSegMgr->GetUserHeader ( ) )->mDDLCount++;
#ifndef USE_NEW_SHM_NODETACH
            sSegMgr->Detach();
#endif
            delete_s( sSegMgr );
        }

        /***********************************************
         * DDL 후에는 Table 다시 Prepare
         ***********************************************/
        sRC = mPrepareTable ( sDicObject.mObj.mIndex.mTableName );
        if ( sRC ) //, PREPARE_TABLE_FAIL );
        {
            DBM_ERR( "Prepare table fail during drop index.[%s]", sDicObject.mObj.mIndex.mTableName );
            _THROW( ERR_DBM_TABLE_NOT_PREPARED );
        }


        /***********************************************
         * Logging 된 것을 commit 한다.
         ***********************************************/
        _CALL( mActCommit() );

        DBM_INFO( "drop index[%s] success. rc(%d)", sParseIndex->mIndexName, sRC );
    }
    _CATCH
    {
        _CATCH_WARN;

        {
            int     sRet;

            /***********************************************
             * Logging 된 것을 기준으로 Rollback 시키고 리턴.
             * Rollback 이 Fail 이면 ?
             ***********************************************/
            sRet = mActNormalRollback();
            if ( sRet != RC_SUCCESS )
            {
                DBM_ERR( "rollback fail. [%d]", sRet );
            }
        }
    }
    _FINALLY
    _END
} /* mActDropIndex */


/******************************************************************************
 * Name : mGetSessID
 *
 * Description
 *     Session ID 채번
 *
 * Argument
 *     aLSN        : output   : 채번된 LSN
 *
 ******************************************************************************/
_VOID dbmTransManager::mGetSessID ( dbmUndoHeader* aUndoHeader , long long* aSessID )
{
    *aSessID = mvpAtomicInc64( &aUndoHeader->mSessID );

    return RC_SUCCESS;
}


_VOID dbmTransManager::mActDropTrig(void* aParse)
{
    dbmLogType          sLogType;
    dbmLogHeader*       sLogHead;
    dbmParseObject*     sParse = (dbmParseObject*)aParse;
    dbmEventObject*     sEvent = (dbmEventObject*)&sParse->mObj.mEvent;
    dbmSegmentManager*  sTableSegMgr = NULL;
    dbmTableHeader*     sTableHeader = NULL;
    dbmDicObject        sDicObject;
    char                sDicIndexName[DBM_NAME_LEN];
    char                sEventSrc[DBM_NAME_LEN];
    int                 sRC;

    _TRY
    {
        DBM_WARN( "start to drop trigger [%s]", sParse->mObj.mEvent.mTriggerName );

        _IF_THROW( sParse->mObj.mEvent.mTriggerName[0] == '\0', ERR_DBM_INVALID_OBJECT_NAME );

#ifdef _DEBUG
        if ( !strncmp_s ( sParse->mObj.mEvent.mTriggerName,
                          SYS_DIC_PREFIX, strlen_s ( SYS_DIC_PREFIX ) ) )
#else
        if ( sParse->mObj.mEvent.mTriggerName[0] == SYS_DIC_PREFIX_CHAR )   // (성능)
#endif
        {
            _THROW( ERR_DBM_DDL_DIC_OBJECT );
        }

        /***********************************************
         * 트리거 존재 확인 및 Event Source 이름 획득
         * Event Source Table 의 이름을 알아내야만
         * 아래쪽에서 Table Header 의 정보 변경 가능.
         ***********************************************/
        memset_s ( &sDicObject, 0x00, sizeof(dbmDicObject) );

        sDicObject.mSQLType = DBM_CREATE_TRIG;

        cmnStrCpyZ ( sDicObject.mObj.mEvent.mInstName, mInstName );
        cmnStrCpyZ ( sDicObject.mObj.mEvent.mTriggerName, sEvent->mTriggerName );

        /* inst_name 과 trigger_name 을 key 컬럼으로 하는 인덱스로 set index */
        sprintf ( sDicIndexName, "%s_1", dbmDicIndexName[DBM_DIC_TBL_TRIGGER] );
        sRC = mDic->mSetIndex ( dbmDicTableName[DBM_DIC_TBL_TRIGGER], sDicIndexName );

        sRC = mDic->mSelect ( &sDicObject );

        /* set index 원복 */
        sprintf ( sDicIndexName, "%s_0", dbmDicIndexName[DBM_DIC_TBL_TRIGGER] );
        mDic->mSetIndex ( dbmDicTableName[DBM_DIC_TBL_TRIGGER], sDicIndexName );

        _IF_THROW( sRC != 0, sRC ); //DIC_OPER_FAIL );

        /* table 이름은 아래에서 써먹음. */
        strcpy_s ( sEventSrc, sDicObject.mObj.mEvent.mEventSrc );

        /***********************************************
         * event src 가 dictionary 에 존재하는 table 인지 확인.
         * 사실 무슨 이유던지간에 Dic 에 존재하지 않아도
         * 이 순간에는 상관없다.
         * 어차피 Trigger Drop 과정이니까 table header 의
         * event queue 정보만 update 해줄 수 있으면 된다.
         ***********************************************/
        memset_s ( &sDicObject, 0x00, sizeof(dbmDicObject) );

        sDicObject.mSQLType = DBM_CREATE_TABLE;

        cmnStrCpyZ ( sDicObject.mObj.mTableInfo.mTable.mInstName, mInstName );
        cmnStrCpyZ ( sDicObject.mObj.mTableInfo.mTable.mTableName, sEventSrc );

        sRC = mDic->mSelect ( &sDicObject );

        /***********************************************
         * table header에 trigger 정보를 update 해야하기
         * 때문에 table segment를 attach 해야 한다.
         * 이미 drop 된 table 이면 attach 안될 수도 있다.
         ***********************************************/
        sRC = dbmSegmentManager::Attach ( mInstName, sEventSrc, &sTableSegMgr );
        if ( sRC == 0 )
        {
            sTableHeader = (dbmTableHeader*) sTableSegMgr->GetUserHeader ( );
        }

        /***********************************************
         * 진행중이던 DML Commit
         * 아래 과정에서 실패를 해도 이전 DML 은 Commit
         * 되어 버리지만 일단 이렇게 Go.
         ***********************************************/
        sRC = mActCommit ( );
        if ( sRC )
        {
            DBM_WARN( "commit dml of tx(%d) fail during drop trigger(%s).", mTransID, sEvent->mEventSrc );
            _THROW( sRC );
        }


        /***********************************************
         * DDL Logging
         ***********************************************/
        sLogType = DBM_DDL_DROP_TRIG_LOG;

        _CALL( mLogMgr->mWriteMemLog( sLogType,
                                     mTransID,
                                     (int)-1,
                                     sEvent->mTriggerName,
                                     sEventSrc,
                                     -1,
                                     NULL,
                                     0,
                                     NULL,
                                     NULL,
                                     (char**)&sLogHead ) );
        //_IF_RAISE( sRC != 0, WRITE_LOG );

        /***********************************************
         * table header 정보 변경
         * dictionary 에서 trigger 삭제.
         ***********************************************/
        if ( sTableHeader != NULL )
        {
            memset_s ( sTableHeader->mEventQueue, 0x00, DBM_NAME_LEN );
        }

        memset_s ( &sDicObject, 0x00, sizeof(dbmDicObject) );
        sDicObject.mSQLType = DBM_DROP_TRIG;

        cmnStrCpyZ ( sDicObject.mObj.mEvent.mInstName, mInstName );
        cmnStrCpyZ ( sDicObject.mObj.mEvent.mTriggerName, sParse->mObj.mEvent.mTriggerName );
        cmnStrCpyZ ( sDicObject.mObj.mEvent.mEventSrc, sEventSrc );

        sRC = mDic->mDelete ( &sDicObject );

        /***********************************************
         * Commit
         **********************************************/
        sRC = mActCommit ( );
        sRC = mActCommit ( );
        if ( sRC )
        {
            DBM_WARN( "commit dml of tx(%d) fail during drop trigger(%s).", mTransID, sEvent->mEventSrc );
            _THROW( sRC );
        }

        /***********************************************
         * 사용한 Segment Manager 객체는 가지고 있을 필요없으니
         * 해제한다.
         ***********************************************/
        if ( sTableSegMgr != NULL )
        {
#ifndef USE_NEW_SHM_NODETACH
            sTableSegMgr->Detach();
#endif
            delete_s( sTableSegMgr );
        }
    }
    _CATCH
    {
        _CATCH_WARN;

        if ( sTableSegMgr != NULL )
        {
#ifndef USE_NEW_SHM_NODETACH
            sTableSegMgr->Detach();
#endif
            delete_s( sTableSegMgr );
        }
    }
    _FINALLY
    _END
} /* mActDropTrig */


int dbmTransManager::mGetConfig( dbmConfig*     aConfigMgr,
                                 char*          aUndoName,
                                 const char*    aItemName )
{
    char    sConfigVal[64];
    int     sVal;
    int     sRC;

    memset_s( sConfigVal, 0x00, sizeof(sConfigVal) );

    /***********************************************
     * aUndoName 에 없으면 COMMON 에서 찾음
     ***********************************************/
    sRC = aConfigMgr->mSearch( aUndoName, aItemName, sConfigVal );
    if ( sRC || (sConfigVal[0] == 0x00) )
    {
        sRC = aConfigMgr->mSearch( "COMMON", aItemName, sConfigVal );
        if ( sRC || sConfigVal[0] == 0x00 ) //, SEARCH_CFG_FAIL );
        {
            return -1;
        }

        DBM_INFO( "get config from [%s]. [%s] [%s]", "COMMON", aItemName, sConfigVal );

        return (sVal = atoi( sConfigVal ));
    }

    DBM_INFO( "get config from [%s]. [%s] [%s]", aUndoName, aItemName, sConfigVal );

    return (sVal = atoi( sConfigVal ));
}

_VOID dbmTransManager::mDumpTxLog ( char* aUndoName , int aTxID, int aFlag )
{
    dbmLogHeader*       sCurLog = NULL;
    dbmTransHeader*     sTxH    = NULL;
    dbmSegmentManager*  sSegMgr = NULL;
    long long           sCurPos;
    long long           sLogCurPos;
    int                 sRC;

    _TRY
    {
        sRC = dbmSegmentManager::Attach ( aUndoName, aUndoName, &sSegMgr );
        _IF_THROW( sRC, ERR_DBM_SEGMENT_ATTACH_FAIL );

        sTxH = (dbmTransHeader*) dbmRecoveryManager::mGetTxHead ( sSegMgr->GetUserHeader ( ), aTxID );

        /***********************************************
         * 로그 없음
         ***********************************************/
        if ( SLOTID ( sTxH->mLogCurPos ) == -1
                || SLOTID ( sTxH->mLogStartPos ) == -1
                || sTxH->mStatus == DBM_TX_FREE ) //, NO_TRANS_LOG );
        {
            _PRT( "no trans[%d] log\n", aTxID);
            _RETURN;
        }

        /***********************************************
         * dbmTransHeader 정보부터 찍음
         ***********************************************/
        dbmRecoveryManager::mDumpTxHeader ( (char*) sTxH, aFlag );

        /***********************************************
         * 첫번째 로그로 이동
         ***********************************************/
        sCurPos = sTxH->mLogStartPos;
        sLogCurPos = sTxH->mLogCurPos;

        while ( 1 )
        {
            sRC = dbmRecoveryManager::mGetLogPtr ( sSegMgr, sCurPos, &sCurLog );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG ); //INVALID_LOG_POS );

            dbmLogManager::mDumpLog ( (char*) sCurLog, sCurPos );

            if ( sCurPos >= sLogCurPos)
            {
                break;
            }

            /***********************************************
             * 다음 로그로 이동
             ***********************************************/
            sRC = dbmLogManager::mLogMoveForward ( sSegMgr, sTxH, &sCurPos );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG ); //INVALID_LOGSLOT_LIST );
        }

#ifndef USE_NEW_SHM_NODETACH
        sSegMgr->Detach();
#endif
        delete_s( sSegMgr );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mDumpTxLog */


_VOID dbmTransManager::mDumpAllSlotList( char*    aUndoName,
                                         int      aTxID )
{
    dbmTransHeader*     sTxH    = NULL;
    dbmSegmentManager*  sSegMgr = NULL;
    int                 sRC;

    _TRY
    {
        sRC = dbmSegmentManager::Attach ( aUndoName, aUndoName, &sSegMgr );
        _IF_THROW( sRC, ERR_DBM_SEGMENT_ATTACH_FAIL );

        sTxH = (dbmTransHeader*) dbmRecoveryManager::mGetTxHead ( sSegMgr->GetUserHeader ( ), aTxID );

        /***********************************************
         * log slot list
         ***********************************************/
        if ( SLOTID(sTxH->mLastAllocLogSlot) == -1 )
        {
            _RETURN;
        }

        sRC = mDumpSlotList( "log",
                             sSegMgr,
                             SLOTID(sTxH->mLogStartPos),
                             SLOTID(sTxH->mLogCurPos) );
        _IF_THROW( sRC, ERR_DBM_INVALID_LOG ); //SLOT_LIST_FAIL );


        /***********************************************
         * image slot list
         ***********************************************/
        if ( SLOTID ( sTxH->mLastAllocImageSlot ) == -1 )
        {
            _RETURN;
        }

        sRC = mDumpSlotList( "image",
                             sSegMgr,
                             SLOTID(sTxH->mImageStartPos),
                             SLOTID(sTxH->mImageCurPos) );
        _IF_THROW( sRC, ERR_DBM_INVALID_LOG ); //SLOT_LIST_FAIL );

#ifndef USE_NEW_SHM_NODETACH
        sSegMgr->Detach();
#endif
        delete_s( sSegMgr );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mDumpAllSlotList */


_VOID dbmTransManager::mDumpSlotList( const char*       aStr,
                                    dbmSegmentManager*  aSegMgr,
                                    long long           aStartSlot,
                                    long long           aLastSlot )
{
    dbmLogSlotHeader*   sLogSlotH;
    long long sCurSlot;
    char    sBuf[16];
    char    sSumBuf[MAX_SIZE_PER_LOG];
    int     sRC;

    _TRY
    {
        sCurSlot = aStartSlot;

        memset_s ( sSumBuf, 0x00, sizeof( sSumBuf ) );
        sprintf ( sSumBuf, ">> %s slot list : ", aStr );

        while ( 1 )
        {
            memset_s ( sBuf, 0x00, sizeof( sBuf ) );
            sprintf ( sBuf, "[%lld] -> ", sCurSlot );

            if ( strlen_s ( sSumBuf ) + ( strlen_s ( sBuf ) ) >= sizeof( sSumBuf ) )
            {
                strcat ( sSumBuf, "lack buf" );
                break;
            }

            strcat ( sSumBuf, sBuf );

            sRC = aSegMgr->Slot2Addr ( sCurSlot, &sLogSlotH );
            _IF_THROW( sRC, ERR_DBM_INVALID_LOG );

            if ( ( sCurSlot == aLastSlot ) || ( sLogSlotH->mNext == -1 ) )
            {
                break;
            }

            sCurSlot = sLogSlotH->mNext;
        }

        DBM_DBG( "%s", sSumBuf );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mDumpSlotList */


_VOID dbmTransManager::mGetTableConfig( dbmConfig* aConfigMgr,
                                      char*        aUndoName,
                                      long long*   aUserInitSize,
                                      long long*   aUserExtendSize,
                                      long long*   aUserMaxSize,
                                      long long*   aInitSize,
                                      long long*   aExtendSize,
                                      long long*   aMaxSize )
{
    int     sRC;

    _TRY
    {
        if ( *aInitSize <= 0 )
        {
            sRC = mGetConfig ( aConfigMgr, aUndoName, "TABLE_INIT_ROWS" );
            if ( sRC < 0 )
            {
                *aInitSize = TABLE_INIT_ROWS_DEFS;
            }
            else
            {
                //*aInitSize = cmnGetBuddy(sRC);
                *aInitSize = sRC;
            }
        }
        else
        {
            *aUserInitSize = *aInitSize;
            //*aInitSize = cmnGetBuddy(*aInitSize);
        }

        if ( *aExtendSize <= 0 )
        {
            sRC = mGetConfig ( aConfigMgr, aUndoName, "TABLE_EXTEND_ROWS" );
            if ( sRC < 0 )
            {
                *aExtendSize = TABLE_EXTEND_ROWS_DEFS;
            }
            else
            {
                *aExtendSize = cmnGetBuddy(sRC);
            }
        }
        else
        {
            *aUserExtendSize = cmnGetBuddy( *aExtendSize );
        }

        if ( *aMaxSize <= 0 )
        {
            sRC = mGetConfig ( aConfigMgr, aUndoName, "TABLE_MAX_ROWS" );
            if ( sRC < 0 )
            {
                *aMaxSize = TABLE_MAX_ROWS_DEFS;
            }
            else
            {
                //*aMaxSize = cmnGetBuddy(sRC);
                *aMaxSize = sRC;
            }
        }
        else
        {
            *aUserMaxSize = *aMaxSize;
            //*aMaxSize = cmnGetBuddy(*aMaxSize);
        }
    }
    _CATCH
    _FINALLY
    _END
} /* mGetTableConfig */


int dbmGetIndexKeyColumnInfo ( dbmIndexObject* aParseIndex , dbmTableInfo* aDicTableInfo , int* aKeySize )
{
    int     i, j;

    _TRY
    {
        *aKeySize = 0;

        for ( i = 0; i < aParseIndex->mColumnCount; i++ )
        {
            for ( j = 0; j < aDicTableInfo->mColumn.mCount; j++ )
            {
                if ( strcmp_s ( aParseIndex->mKey[i].mColumnName, aDicTableInfo->mColumn.mCols[j].mColumnName ) == 0 )
                {
                    memcpy_s ( &aParseIndex->mKey[i], &aDicTableInfo->mColumn.mCols[j], sizeof(dbmColumnObject) );
                    *aKeySize += aDicTableInfo->mColumn.mCols[j].mSize;
                    break;
                }
            }

            if ( j >= aDicTableInfo->mColumn.mCount )
            {
                _THROW( RC_FAILURE );
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}

_VOID dbmGetColumnType ( dbmTableInfo* aDicTableInfo , char* aColumnName , dbmColumnType* aColumnType )
{
    int     i;

    _TRY
    {
        for ( i = 0; i < aDicTableInfo->mColumn.mCount; i++ )
        {
            if ( strcmp_s ( aColumnName, aDicTableInfo->mColumn.mCols[i].mColumnName ) == 0 )
            {
                *aColumnType = aDicTableInfo->mColumn.mCols[i].mColumnType;
                _RETURN;
            }
        }

        _THROW( -1 );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}

#if 0 // 2014.11.18. -okt- 미사용.
_VOID dbmGetRefRowPtr ( dbmTransManager* aTxMgr , char* aTableName , long long aRowSlot , dbmRowHeader** aRow )
{
    dbmSegmentManager*  sSegMgr = NULL;
    int                 sObjectIdx;

    _TRY
    {
        _CALL( aTxMgr->mFindTableInTx( aTableName, &sObjectIdx ) );
        sSegMgr = aTxMgr->mGetTableMgr(sObjectIdx)->mGetSegMgr();

        _CALL( sSegMgr->Slot2Addr( aRowSlot, aRow ) );
        //_IF_RAISE(sRC || aRow == NULL, FIND_FAIL );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}
#endif


_VOID dbmGetIndexMgrByObjID ( dbmTransManager* aTxMgr , char* aTableName , int aIndexID , dbmIndexManager** aIndexMgr )
{
    int     sObjectIdx;
    int     sRC;

    sRC = aTxMgr->mFindTableInTx ( aTableName, &sObjectIdx );
    if ( unlikely( sRC ) )
        return sRC;

    *aIndexMgr = aTxMgr->mGetTableMgr ( sObjectIdx )->mGetIndexMgrByObjID ( aIndexID );

    return 0; // 짧은 성능 함수 Try .. Catch 안함.
}


_VOID dbmGetTableSegMgr ( dbmTransManager* aTxMgr , char* aTableName , dbmSegmentManager** aSegMgr )
{
    int     sObjectIdx = -1;
    int     sRC;

    sRC = aTxMgr->mFindTableInTx( aTableName, &sObjectIdx );
    if ( unlikely( sRC ) )
        return sRC;

    *aSegMgr = aTxMgr->mGetTableMgr(sObjectIdx)->mGetSegMgr();
#ifdef _DEBUG
    if ( *aSegMgr == NULL )
    {
        DBM_WARN( "TxMgr->mGetTableMgr(%d)->mGetSegMgr Fail.", sObjectIdx );
        return( -1 );
    }
#endif

    return 0; // 짧은 성능 함수 Try .. Catch 안함.
}


_VOID dbmGetQueueSegMgr ( dbmTransManager* aTxMgr , char* aQueueName , dbmSegmentManager** aSegMgr )
{
    int     sObjectIdx;
    int     sRC;

    sRC = aTxMgr->mFindQueueInTx( aQueueName, &sObjectIdx );
    if ( unlikely( sRC ) )
        return sRC;

    *aSegMgr = aTxMgr->mGetQueueMgr(sObjectIdx)->mGetSegMgr();

    return 0; // 짧은 성능 함수 Try .. Catch 안함.
}

_VOID dbmGetListSegMgr ( dbmTransManager* aTxMgr , char* aListName , dbmSegmentManager** aSegMgr )
{
    int     sObjectIdx;
    int     sRC;

    sRC = aTxMgr->mFindListInTx( aListName, &sObjectIdx );
    if ( unlikely( sRC ) )
        return sRC;

    *aSegMgr = aTxMgr->mGetListMgr(sObjectIdx)->mGetSegMgr();

    return 0; // 짧은 성능 함수 Try .. Catch 안함.
}


_VOID dbmGetIndexSegMgrByObjID ( dbmTransManager* aTxMgr , char* aTableName , int aIndexID , dbmSegmentManager** aSegMgr )
{
    dbmIndexManager* sIdxMgr = NULL;
    int     sObjectIdx;

    _TRY
    {
        _CALL( aTxMgr->mFindTableInTx( aTableName, &sObjectIdx ) );

        sIdxMgr = aTxMgr->mGetTableMgr ( sObjectIdx )->mGetIndexMgrByObjID ( aIndexID );
        _IF_THROW( sIdxMgr == NULL, -1 );
        *aSegMgr = sIdxMgr->mGetSegMgr ( );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_BOOL dbmIsFirstEnqueLog ( dbmSegmentManager* aUndoSegMgr , dbmTransHeader* aTxH , long long aEndPos , int aObjectID )
{
    long long       sCurPos;
    dbmLogHeader*   sCurLog = NULL;

    _TRY
    {
        sCurPos = aTxH->mLogStartPos;
        while(1)
        {
            _CALL ( dbmRecoveryManager::mGetLogPtr( aUndoSegMgr, sCurPos, &sCurLog ) );

            if ( sCurLog->mLogValidF == 1 )
            {
                switch( sCurLog->mLogType )
                {
                    case DBM_ENQUE_LOG:
                        if ( sCurLog->mObjectID == aObjectID )
                        {
                            /***********************************************
                             * 현재 로그 기준으로 딱 한번 match 일 경우가 최초임.
                             * 그 외는 모두 최초가 아니므로 0 리턴.
                             ***********************************************/
                            return true;
                        }
                        break;

                    default:
                        break;
                }
            }

            if ( sCurPos == aEndPos )
                break;

            _CALL ( dbmLogManager::mLogMoveForward( aUndoSegMgr, aTxH, &sCurPos ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        //_TRY .. _CATCH에서 bool 처리 예제.
        if ( _rc != 0 )
        {
            return FALSE;
        }
    }
    _ENDBOOL
    //return false;
} /* dbmIsFirstEnqueLog */


_VOID dbmTransManager::mUnprepareTable ( char* aTableName , int aTableType )
{
    int     sObjectIdx = -1;
    int     sRC;

    _TRY
    {
        if ( aTableType == DBM_TBL_LIST )
        {
            if ( mListCount > 0 )
            {
                sRC = mFindListInTx( aTableName, &sObjectIdx );
                if ( sRC == 0 && sObjectIdx >= 0 )
                {
                    delete_s( mList[sObjectIdx] );

                    if ( mListCount > ( sObjectIdx + 1 ) )
                    {
                        /* delete 했으니까 그만큼 이동해라 */
                        memmove_s( &mList[sObjectIdx],
                                   &mList[sObjectIdx + 1],
                                   sizeof( mList[sObjectIdx] ) * ( mListCount - ( sObjectIdx + 1 ) ) );

                        memmove_s( &mListDDLCount[sObjectIdx],
                                   &mListDDLCount[sObjectIdx + 1],
                                   sizeof( mListDDLCount[sObjectIdx] ) * ( mListCount - ( sObjectIdx + 1 ) ) );

                        mList[mListCount -1] = NULL;
                    }

                    --mListCount;

                    DBM_DBG( "unprepared queue[%s] manager object. idx[%d] mQueueCount[%d]",
                              aTableName, sObjectIdx, mQueueCount );
                }
            }
        }
        else
        if ( aTableType == DBM_TBL_QUEUE )
        {
            if ( mQueueCount > 0 )
            {
                sRC = mFindQueueInTx ( aTableName, &sObjectIdx );
                if ( sRC == 0 && sObjectIdx >= 0 )
                {
                    delete_s( mQueue[sObjectIdx] );

                    if ( mQueueCount > ( sObjectIdx + 1 ) )
                    {
                        memmove_s ( &mQueue[sObjectIdx],
                                    &mQueue[sObjectIdx + 1], sizeof( mQueue[sObjectIdx] ) * ( mQueueCount - ( sObjectIdx + 1 ) ) );

                        memmove_s ( &mQueueDDLCount[sObjectIdx],
                                    &mQueueDDLCount[sObjectIdx + 1], sizeof( mQueueDDLCount[sObjectIdx] ) * ( mQueueCount - ( sObjectIdx + 1 ) ) );

                        mQueue[mQueueCount - 1] = NULL;
                    }

                    --mQueueCount;

                    DBM_DBG( "unprepared queue[%s] manager object. idx[%d] mQueueCount[%d]", aTableName, sObjectIdx, mQueueCount );
                }
            }
        }
        else
        {
            if ( mTableCount > 0 )
            {
                sRC = mFindTableInTx ( aTableName, &sObjectIdx );
                if ( sRC == 0 && sObjectIdx >= 0 )
                {
                    delete_s( mTable[sObjectIdx] );

                    if ( mTableCount > ( sObjectIdx + 1 ) )
                    {
                        memmove_s ( &mTable[sObjectIdx],
                                    &mTable[sObjectIdx + 1], sizeof( mTable[sObjectIdx] ) * ( mTableCount - ( sObjectIdx + 1 ) ) );

                        memmove_s ( &mTableDDLCount[sObjectIdx],
                                    &mTableDDLCount[sObjectIdx + 1], sizeof( mTableDDLCount[sObjectIdx] ) * ( mTableCount - ( sObjectIdx + 1 ) ) );

                        mTable[mTableCount - 1] = NULL;
                    }

                    --mTableCount;

                    DBM_DBG( "unprepared table[%s] manager object. idx[%d] mTableCount[%d]", aTableName, sObjectIdx, mTableCount );
                }
            }
        }
    }
    _CATCH
    {
        //_CATCH_WARN;
    }
    _FINALLY
    _END
} /* mUnprepareTable */


/************************************************************************
 * Handle 의 변수를 보고 처리한다.
 ************************************************************************/
_VOID dbmTransManager::mActSessionOption ( dbmDataObject* aData , int* aValue )
{
    dbmTransHeader* sTransHeader = (dbmTransHeader*) mTransHeader;

    _TRY
    {
        if ( aData->mTransType == DBM_SET_OPTION )
        {
            switch ( aData->mOption )
            {
                case DBM_O_DISK_LOG_ENABLE:
                    sTransHeader->mDiskLoggingEnableF = *aValue;
                    break;

                case DBM_O_DISK_LOG_IO_TYPE:
                    //TOOD (OKT): 미구현으로 보임
                    break;
            }

            _RETURN;
        }

        if ( aData->mTransType == DBM_GET_OPTION )
        {
            switch ( aData->mOption )
            {
                case DBM_O_DISK_LOG_ENABLE:
                    *aValue = sTransHeader->mDiskLoggingEnableF;
                    break;
                case DBM_O_DISK_LOG_IO_TYPE:
                    break;
            }

            _RETURN;
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


/************************************************************************
 * 로그를 하나씩 까서 Log Block 형태로 변환
 ************************************************************************/
_VOID dbmTransManager::mHandleTransLog ( dbmLogHeader* aLog , dbmSegmentManager* aObjectSeg )
{
    dbmRowHeader*   sRowHeader;
    dbmQNodeHeader* sQNodeHeader;
    dbmTransLog     sMyLog; // 80 byte
//    dbmSegmentManager* sSegMgr = NULL;
    int     sIdx = -1;
    int     sRC;

    _TRY
    {
        /***************************************************************
         * Logger 가 없다면 No logging 이다
         **************************************************************/
        if ( ((dbmTransHeader*)mTransHeader)->mDiskLoggingEnableF == 0 )
        {
            _RETURN;
        }

        /***************************************************************
         * 처리대상 로그 타입인지 확인
         **************************************************************/
        switch ( aLog->mLogType )
        {
            case DBM_INSERT_SLOT_LOG:
            case DBM_UPDATE_SLOT_LOG:
            case DBM_UPDATE_KEY_LOG:
            case DBM_DELETE_DATA_LOG:
            case DBM_ENQUE_LOG:
            case DBM_DDL_CREATE_LIST_LOG :
            case DBM_DDL_CREATE_QUEUE_LOG:
            case DBM_DDL_CREATE_TABLE_LOG:
            case DBM_DDL_CREATE_INDEX_LOG:
            case DBM_DDL_CREATE_TRIG_LOG:
            case DBM_DDL_DROP_QUEUE_LOG:
            case DBM_DDL_DROP_TABLE_LOG:
            case DBM_DDL_DROP_INDEX_LOG:
            case DBM_DDL_DROP_TRIG_LOG:
            case DBM_TRUNCATE_LOG:
            case DBM_SET_INDEX_LOG:
                break;

            default:
                _RETURN;
                break;
        }

        /***************************************************************
         * Truncate 일 경우는 Table 이 Prepare 되지 않은 상황일 수 있따.
         * 이 경우는 걍 prepare 해준다.
         **************************************************************/
        if ( aLog->mLogType == DBM_TRUNCATE_LOG )
        {
            _CALL( mPrepareTable ( aLog->mObjectName ) );
        }

        /***************************************************************
         * 대상 Object 의 Header 를 검사해서 NologgingF가 1 이라면 무시
         * 이건 로깅 대상 Object 가 아님
         **************************************************************/
        switch ( aLog->mLogType )
        {
            // 이 로그들은 Object 헤더를 통해 Nologging 여부를 알아낼 필요가 없는 로그이고,
            // 걍 전체 로깅을 하면 되는 애들이다.
            case DBM_DDL_CREATE_INDEX_LOG:
            case DBM_DDL_CREATE_TRIG_LOG:
            case DBM_DDL_DROP_TABLE_LOG:
            case DBM_DDL_DROP_INDEX_LOG:
            case DBM_SET_INDEX_LOG:
                break;

            default:
                sRC = mFindTableInTx ( aLog->mObjectName, &sIdx );
                if ( likely( sRC == 0 ) )
                {
                    if ( mTable[sIdx]->mGetTableHeader ( )->mTableObj.mNologgingF )
                    {
                        _RETURN;
                    }
                }
                else
                {
                    sRC = mFindQueueInTx ( aLog->mObjectName, &sIdx );
                    if ( sRC == 0 )
                    {
                        if ( mQueue[sIdx]->mGetQueueHeader ( )->mTableObj.mNologgingF )
                        {
                            _RETURN;
                        }
                    }
                    else
                    {
                        sRC = mFindListInTx ( aLog->mObjectName, &sIdx );
                        if ( sRC == 0 )
                        {
                            if ( mList[sIdx]->mGetListHeader ( )->mTableObj.mNologgingF )
                            {
                                _RETURN;
                            }
                        }
                        else
                        {
                            _THROW( ERR_DBM_TABLE_NOT_PREPARED );
                        }
                    }
                }
                break;
        }

        sMyLog.mLogType = aLog->mLogType;
        switch ( aLog->mLogType )
        {
            case DBM_INSERT_SLOT_LOG :
            case DBM_UPDATE_SLOT_LOG :
            case DBM_UPDATE_KEY_LOG :
                _CALL( aObjectSeg->Slot2Addr ( aLog->mRefRecord, &sRowHeader ) );

                sMyLog.mObjectID    = aLog->mObjectID;
                sMyLog.mSlot        = aLog->mRefRecord;
                strcpy_s ( sMyLog.mObjectName, aLog->mObjectName );
                sMyLog.mImagePtr    = (char*) sRowHeader + sizeof(dbmRowHeader);
                sMyLog.mImageSize   = aLog->mImageSize - sizeof(dbmRowHeader);
                sMyLog.mSCN         = aLog->mSCN;

                _CALL( mTransLogger->mWriteLog ( &sMyLog ) );
                break;

            case DBM_DELETE_DATA_LOG :
                sMyLog.mObjectID    = aLog->mObjectID;
                sMyLog.mSlot        = aLog->mRefRecord;
                strcpy_s ( sMyLog.mObjectName, aLog->mObjectName );

                _CALL( dbmRecoveryManager::mGetImagePtr ( mUndoSegMgr, aLog->mImageLogPos, &sMyLog.mImagePtr ) );

                sMyLog.mImagePtr += sizeof(dbmRowHeader);
                sMyLog.mImageSize = aLog->mImageSize - sizeof(dbmRowHeader);
                sMyLog.mSCN = aLog->mSCN;
                _CALL( mTransLogger->mWriteLog ( &sMyLog ) );
                break;

            case DBM_ENQUE_LOG:
                _CALL( aObjectSeg->Slot2Addr ( aLog->mRefRecord, &sQNodeHeader ) );

                sMyLog.mObjectID    = aLog->mObjectID;
                sMyLog.mSlot        = aLog->mRefRecord;
                strcpy_s ( sMyLog.mObjectName, aLog->mObjectName );
                sMyLog.mImagePtr    = (char*) sQNodeHeader + sizeof(dbmQNodeHeader);
                sMyLog.mImageSize   = sQNodeHeader->mDataSize;
                sMyLog.mSCN         = sQNodeHeader->mSCN;

                _CALL( mTransLogger->mWriteLog ( &sMyLog ) );
                break;

            case DBM_TRUNCATE_LOG :
                sMyLog.mObjectID    = aLog->mObjectID;
                strcpy_s (sMyLog.mObjectName, aLog->mObjectName);
                sMyLog.mSlot        = -1;
                sMyLog.mImagePtr    = NULL ;
                sMyLog.mImageSize   = 0;
                sMyLog.mSCN         = -1;
                _CALL ( mTransLogger->mWriteLog ( &sMyLog ))  ;
                break;

            case DBM_DDL_CREATE_TABLE_LOG :
            case DBM_DDL_CREATE_LIST_LOG  :
            case DBM_DDL_CREATE_QUEUE_LOG :
            case DBM_DDL_CREATE_TRIG_LOG :
                _CALL( dbmRecoveryManager::mGetImagePtr ( mUndoSegMgr, aLog->mImageLogPos, &sMyLog.mImagePtr ) );
                sMyLog.mObjectID = aLog->mObjectID ;
                sMyLog.mSlot = -1;
                strcpy_s ( sMyLog.mObjectName, aLog->mObjectName );
                sMyLog.mImageSize = strlen_s ( sMyLog.mImagePtr ) + 1;
                sMyLog.mSCN = aLog->mSCN ;
                _CALL( mTransLogger->mWriteLog ( &sMyLog ) );
                break;

            case DBM_DDL_CREATE_INDEX_LOG :
                _CALL( dbmRecoveryManager::mGetImagePtr ( mUndoSegMgr, aLog->mImageLogPos, &sMyLog.mImagePtr ) );
                sMyLog.mObjectID = aLog->mObjectID ;
                sMyLog.mSlot = -1;
                strcpy_s ( sMyLog.mObjectName, aLog->mTableName );
                sMyLog.mImageSize = strlen_s ( sMyLog.mImagePtr ) + 1;
                sMyLog.mSCN = aLog->mSCN ;
                _CALL( mTransLogger->mWriteLog ( &sMyLog ) );
                break;

            case DBM_DDL_DROP_TABLE_LOG :
            case DBM_DDL_DROP_QUEUE_LOG :
            case DBM_DDL_DROP_TRIG_LOG:
            case DBM_DDL_DROP_INDEX_LOG:
                sMyLog.mObjectID    = aLog->mObjectID;
                strcpy_s (sMyLog.mObjectName, aLog->mObjectName);
                sMyLog.mSlot        = -1;
                sMyLog.mImagePtr    = NULL ;
                sMyLog.mImageSize   = 0;
                sMyLog.mSCN         = -1;
                _CALL ( mTransLogger->mWriteLog ( &sMyLog ))  ;
                break;

            case DBM_SET_INDEX_LOG:
                //sMyLog.mObjectID    = aLog->mObjectID;
                //strcpy_s (sMyLog.mTableName, aLog->mTableName);
                //strcpy_s (sMyLog.mObjectName, aLog->mObjectName);
                //sMyLog.mSlot        = -1;
                //sMyLog.mImagePtr    = NULL ;
                //sMyLog.mImageSize   = 0;
                //sMyLog.mSCN         = -1;
                //_CALL ( mTransLogger->mWriteLog ( &sMyLog ))  ;
                break;

            default:
                break;
        }

    }
    _CATCH
    {
#ifdef _DEBUG
        _CATCH_WARN;
#else
        _CATCH_DBG;
#endif
    }
    _FINALLY
    _END
} /* mHandleTransLog */

