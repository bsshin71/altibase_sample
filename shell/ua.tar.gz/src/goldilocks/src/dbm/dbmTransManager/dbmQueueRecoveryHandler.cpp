#include "dbmQueueRecoveryHandler.h"


dbmQueueRecoveryHandler::dbmQueueRecoveryHandler ( )
{

    memset_s ( mQueueNames, 0x00, DBM_NAME_LEN * DBM_MAX_TABLE_PER_TRANS );
    memset_s ( mLast, 0x00, DBM_MAX_TABLE_PER_TRANS * sizeof(dbmQNodeHeader*) );
    memset_s ( mFirst, 0x00, DBM_MAX_TABLE_PER_TRANS * sizeof(dbmQNodeHeader*) );
    mQueueIdx = 0;

    mTransLogger = NULL;
}

dbmQueueRecoveryHandler::~dbmQueueRecoveryHandler ( )
{
}


_VOID dbmQueueRecoveryHandler::mHandleDequeLog ( char* aInstName , dbmLogHeader* aCurLog , char* aRecoveryImage )
{
    dbmQNodeHeader* sQNodeHeader = NULL ;
    dbmQueueHeader* sQueueHeader = NULL;
    dbmTransLog     sTransLog;
    long long sSlotID;
    int     sLogCount = 0 ;
    long long sLSN ;

    int     sRC;
    int     sIdx;

    _TRY
    {
        sRC = mFindQueueIdx ( aCurLog->mObjectName, &sIdx );
        if ( sIdx == -1 )
        {
            /*************************************************************
             *  이름을 저장한다.
             ************************************************************/
            memcpy_s ( mQueueNames[mQueueIdx], aCurLog->mObjectName, DBM_NAME_LEN );
            /*************************************************************
             *  이름을 저장한다.
             ************************************************************/

            // TODO: [OKT] 2015.03.09 컴파일 워닝 만이 아니고. 죽는 코드임. 확인요.
            //mTxID[sIdx] = aCurLog->mTransID; // array subscript is below array bounds [-Warray-bounds]

            /*************************************************************
             * 기존에 없었던 Queue 이름이므로 Segment 를 Attach 한다.
             ************************************************************/
            _CALL( dbmSegmentManager::Attach ( aInstName, aCurLog->mObjectName, &mSegMgr[mQueueIdx] ) );
            sIdx = mQueueIdx;
            mQueueIdx++;
        }

        /*************************************************************
         *  여기서 Queue 의 헤더를 보고 Table ID 가 같은지 검사한다.
         ************************************************************/

        sQueueHeader = (dbmQueueHeader*) mSegMgr[sIdx]->GetUserHeader ( );
        if ( sQueueHeader->mTableObj.mTableID != aCurLog->mObjectID )
        {
            _RETURN;
        }

        /***************************************************************
         * 지금 부터 일어나는 모든 DEQUEUE 를 막는다.
         **************************************************************/
        sQueueHeader->mRecoveryProcessF = 1;

        /***************************************************************
         * Attach 할  Segment 를 찾았으니 Alloc Slot 을 수행한다.
         * 이때 Alloc Slot 시점에 공간이 부족하다면 무한대기한다.
         **************************************************************/
        while ( 1 )
        {

            sRC = dbmSegAllocSlot ( mSegMgr[sIdx], &sSlotID );
            if ( sRC )
            {
                if ( sRC == ERR_DBM_NO_SPACE )
                {
                    _CALL( mSegMgr[sIdx]->Extend ( ) );
                    //_IF_RAISE ( sRC , RECOVERY_EXTEND_FAIL );
                    continue;
                }

                _THROW( sRC );  // ALLOC_SLOT_FAIL ) ;
            }
            break;
        }

        /***************************************************************
         * Slot 을 할당 받았으니 실제 주소를 얻어와서 복사한다.
         **************************************************************/
        _CALL( mSegMgr[sIdx]->Slot2Addr ( sSlotID, &sQNodeHeader ) );

        sQNodeHeader->mNext = -1;
        sQNodeHeader->mLock = -1;
        sQNodeHeader->mDataSize = aCurLog->mImageSize;
        sQNodeHeader->mMySlot = sSlotID;
        sQNodeHeader->mSCN = aCurLog->mSCN;

        memcpy_s ( (char*) sQNodeHeader + sizeof(dbmQNodeHeader), aRecoveryImage, sQNodeHeader->mDataSize );

        /***************************************************************
         *  기존에 할당된 슬롯주소와 연결을 수행한다.
         **************************************************************/

        if ( mLast[sIdx] == NULL ) /** 첫번째로 Enqueue 된 경우 **/
        {
            mLast[sIdx] = sQNodeHeader;
            mFirst[sIdx] = sQNodeHeader;
        }
        else
        {
            sQNodeHeader->mNext = mFirst[sIdx]->mMySlot;
            mFirst[sIdx] = sQNodeHeader;
        }

        /***************************************************************
         * Disk Log 를 남긴다. 나 Enque 되었음.
         **************************************************************/
        if ( mTransLogger != NULL )
        {

            if ( sQueueHeader->mTableObj.mNologgingF == 0 )
            {
                sTransLog.mLogType = DBM_ENQUE_LOG;
                sTransLog.mObjectID = sQueueHeader->mTableObj.mTableID;
                sTransLog.mSlot = aCurLog->mRefRecord;
                strncpy ( sTransLog.mObjectName, aCurLog->mObjectName, DBM_NAME_LEN );
                sTransLog.mImagePtr = aRecoveryImage;
                sTransLog.mImageSize = sQNodeHeader->mDataSize;
                sTransLog.mSCN = aCurLog->mSCN;

                _CALL( mTransLogger->mWriteLog ( &sTransLog ) );
                //_IF_RAISE ( sRC, FAIL_TO_WRITE_LOG );
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mHandleDequeLog */


_VOID dbmQueueRecoveryHandler::mComplete ()
{
    dbmQueueHeader* sQueueHeader;
    int     sOldTx;
    int     sRC;
    int     i;

    _TRY
    {
        for ( i = 0; i < mQueueIdx; i++ )
        {

            sQueueHeader = (dbmQueueHeader*) mSegMgr[i]->GetUserHeader ( );

            if ( sQueueHeader->mRecoveryProcessF == 1 )
            {
                /******************************************************************
                 * 리스트를 헤더값으로 바꾼다.
                 * 여기서 리스트가 NULL 일 수 있따. ( 이미 Drop 된 Object 의 Log )
                 * 그래서 체크해야한다.
                 *****************************************************************/
                if ( mLast[i] != NULL )
                {
                    mLast[i]->mNext = sQueueHeader->mDeq;
                    // 백업을 위해서 mDeq 값을 복사해놓는다.
                    sQueueHeader->mOldDeq = sQueueHeader->mDeq;
                    sQueueHeader->mDeq = mFirst[i]->mMySlot;
                    sQueueHeader->mRecoveryProcessF = 0;
                }
            }
        } /* for */
    }
    _CATCH
    {
        //_CATCH_WARN;
    }
    _FINALLY
    _END
}

/******************************************************************
 * 할당된 자원을 해제한다. delete 되기 전에 호출되어야 한다.
 *****************************************************************/

_VOID dbmQueueRecoveryHandler::mFinalize ( )
{
    //int sRC;

    for ( int i = 0 ; i < mQueueIdx ; i ++ )
    {
#ifndef USE_NEW_SHM_NODETACH
        (void) mSegMgr[i]->Detach ( ) ;
#endif
        delete_s( mSegMgr[i] );
    }

    return RC_SUCCESS;
}

_VOID dbmQueueRecoveryHandler::mFindQueueIdx ( char* aQueueName, int* aIdx )
{
    for ( int i = 0 ; i < mQueueIdx  ; i ++ )
    {
        if ( strcmp_s ( aQueueName, mQueueNames [i] ) == 0 )
        {
            *aIdx = i ;
            return RC_SUCCESS ;
        }
    }

    *aIdx = -1;

    return RC_FAILURE ;
}
