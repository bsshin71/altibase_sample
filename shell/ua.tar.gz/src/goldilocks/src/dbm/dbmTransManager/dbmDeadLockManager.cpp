/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
 *   dbmDeadLock 의 멤버함수들을 구현한다.
 ******************************************************************************/
#include "dbmHeader.h"
#include "dbmDeadLockManager.h"

dbmDeadLockManager::dbmDeadLockManager ( dbmTransTable* aStartHeader , int aMyTransID , dbmLogManager* aLogManager )
{
    mTransStartAddr = aStartHeader;
    mMyTransID      =   aMyTransID;
    mLogMgr         = aLogManager;
    mMyTransHeader  = (dbmTransHeader*)dbmLogManager::mGetTxHead( mTransStartAddr, aMyTransID );
}


dbmDeadLockManager :: ~dbmDeadLockManager ()
{
}

_VOID dbmDeadLockManager::mSetDeadLockMgr ( dbmTransTable* aStartHeader , int aMyTransID , dbmLogManager* aLogManager )
{
    mTransStartAddr = aStartHeader;
    mMyTransID      =   aMyTransID;
    mLogMgr         = aLogManager;
    mMyTransHeader  = (dbmTransHeader*)dbmLogManager::mGetTxHead( mTransStartAddr, aMyTransID );

    return 0;
}

_VOID dbmDeadLockManager::mCheckDeadLock ( int aWaitObjectID , int aWaitSlotID , int aWaitForTx )
{
    dbmTransHeader* sTransHeader = NULL;
    int     sIsCircuitF = -1 ;  // 0 혹은 1로 검사하는데 0으로 초기값주면 안된다.
    int     sLockedF    = 0;
    int     sLastWaitTxID = -1;
    int     sRC;

    _TRY
    {
        /**********************************************************
         * 먼저 내 Tx Header 에 현재 Lock Wait 이라는 상태를 기록
         * 뭔 기다리고 있는지도 같이 기록함.
         *********************************************************/
        _CALL( mSetMyTransHeader ( aWaitObjectID, aWaitSlotID, aWaitForTx ) );

        /**********************************************************
         * aWaitForTx ID 를 통해서 Circuit 여부를 체크한다.
         *********************************************************/
        _CALL( mCheckIsCircuit ( &sIsCircuitF, &sLastWaitTxID ) );

        /**********************************************************
         * aIsCircuitF 가 0 이라면 Circuit 이 아니고, 이 경우는 DeadLock
         * 이 발생할 수 없다. 리턴한다.
         *********************************************************/
        if ( sIsCircuitF == 0 )
        {
            _RETURN;
        }

        /**********************************************************
         * 자 이제 Circuit 이 발생했고, 나의 TransID 를 기다리고 있는
         * 놈도 알아냈다. 이제는 그놈이 기다리고 있는 Lock 이 내가 이미
         * 잡았는지 체크해야한다.
         *********************************************************/

        sTransHeader = mGetTransHeader ( sLastWaitTxID );

        sRC = mLogMgr->mFindLockedRecord ( mMyTransID, sTransHeader->mWaitForObjectID, sTransHeader->mWaitForSlotID, &sLockedF );

        if ( sLockedF == 1 )
        {
            _THROW( ERR_DBM_DEADLOCK_DETECTED );  // 상위단에서 이걸 검사한다.
        }

    }
    _CATCH
    {
        // 검사하는 함수로  어떤 경우도 오류가 아니다.
        //_CATCH_WARN;
    }
    _FINALLY
    _END        // 성공의 개념이 아니고 NO DEADLOCK 의미
} /* mCheckDeadLock */


_VOID dbmDeadLockManager::mSetMyTransHeader ( int aWaitObjectID , int aWaitSlotID , int aWaitForTx )
{
    mMyTransHeader->mWaitForTransID = aWaitForTx;
    mMyTransHeader->mWaitForObjectID = aWaitObjectID;
    mMyTransHeader->mWaitForSlotID = aWaitSlotID;

    return 0;
}

_VOID dbmDeadLockManager::mCheckIsCircuit ( int* aIsCircuitF , int* aLastWaitTxID )
{
    dbmTransHeader* sTransHeader = NULL;
    int     sNextTransID = -1 ;
    int     sBeforeTransID = -1;

    _TRY
    {
        if ( mMyTransHeader->mWaitForTransID == -1 )
        {
            *aIsCircuitF = 0;
            *aLastWaitTxID = -1;
            _RETURN;
        }

        sTransHeader = mGetTransHeader ( mMyTransID );
        _DASSERT( sTransHeader != NULL );

        /**********************************************************
         * 나의 aWaitForTx 가 가지고 있는 aWaitForTX 를 쫒아간다.
         * 이때 이 값이 나로 귀결된다면 이건 Circuit 상황이다.
         *********************************************************/

        while ( sTransHeader->mWaitForTransID != -1 )
        {
            /*****************************************************
             * 현재 상황은 Circuit 상황이다.
             ****************************************************/
            if ( sTransHeader->mWaitForTransID == mMyTransID )
            {
                *aLastWaitTxID = sTransHeader->mWaitForTransID;
                *aIsCircuitF = 1;
                _RETURN;
            }

            /*****************************************************
             * 다음으로 이동한다.
             ****************************************************/
            sTransHeader = mGetTransHeader ( sTransHeader->mWaitForTransID );
            _DASSERT( sTransHeader != NULL );
        }

        *aIsCircuitF = 0;
        *aLastWaitTxID = -1;
    }
    _CATCH
    {
        //_CATCH_WARN;  // 실패하는 경우가 없다.
    }
    _FINALLY
    _END
}

_VOID dbmDeadLockManager::mUnsetTransHeader ( )
{
    return mSetMyTransHeader ( -1, -1, -1 );
}
