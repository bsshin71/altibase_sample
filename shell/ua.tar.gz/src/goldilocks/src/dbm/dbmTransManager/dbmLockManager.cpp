/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
 ******************************************************************************/
#include "dbmHeader.h"
#include "dbmLockManager.h"

/*
 * [주의] 2014.09.22 (OKT)
 *
 * Lock 관련 함수들은 '최대의' 성능 함수로. 개념적으로 _VOID 형태이고 TRY .. _CATCH 를 적용가능한 경우에도
 * 초기화 등의 비성능 구간을 제외하고는 모두 _TRY .. _CATCH를 사용하지 않는다. ( 단 리턴은 의미를 나타내기 위해 _VOID로 )
 *
 * 이는 unlikely 처리등을 작성자가 잘 해주어야 함을 의미함.
 */

int   dbmLockManager::__mLockInfoSize = 0;
char* dbmLockManager::__mLockInfo     = NULL;


LockCount g_cnt_lock = { 0, 0, 0, 0, 0,   0, 0, 0, 0, 0,   0 };


#if 0

$1 = {mInitLock = 3, mAtomicLockTry = 0, mAtomicUnlockTry = 100, mSpinLock = 202, mSpinUnlock = 100, mLock = 100, mUnlock = 0, mTableLock = 0, mTableUnlock = 0, mLockPID = 3, mCheckLockPID = 0}
$1 = {mInitLock = 5, mAtomicLockTry = 0, mAtomicUnlockTry = 100, mSpinLock = 402, mSpinUnlock = 100, mLock = 100, mUnlock = 0, mTableLock = 0, mTableUnlock = 0, mLockPID = 5, mCheckLockPID = 0}
$1 = {mInitLock = 5, mAtomicLockTry = 0, mAtomicUnlockTry = 300, mSpinLock = 606, mSpinUnlock = 100, mLock = 300, mUnlock = 0, mTableLock = 0, mTableUnlock = 0, mLockPID = 5, mCheckLockPID = 0}

#endif

_VOID dbmLockManager::mInitLock ( int aSize , char* aLockInfo )
{
    _TRY
    {
        __mLockInfoSize = aSize;
        __mLockInfo     = aLockInfo;
    }
    _CATCH
    _FINALLY
    _END
}


/******************************************************************************
 * Name : mAtomicLockTry
 *
 * Description
 *     atomic lock 을 한번만 시도 후 결과 리턴
 *
 * Argument
 *     aLock        : input   : lock value
 *     aSetVal      : input   : lock value 를 교체할 신규 값
 *     aCheckVal    : input   : lock value 에 저장된 것과 compare 할 값
 *
 ******************************************************************************/
_VOID dbmLockManager::mAtomicLockTry( char* aLockVal, int aSetVal, int aCheckVal )
{
#ifdef _DEBUG
    atomic_inc ( &g_cnt_lock.mAtomicLockTry );
#endif
    int     sOldVal;

    /***********************************************
     * aLockVal 이 aCheckVal 이면 aSetVal 로 교체를 시도한다.
     * 교체가 성공하면 sOldVal = aCheckVal 로 리턴된다. ( Lock 성공 )
     ***********************************************/
    sOldVal = mvpAtomicCas32( aLockVal, aSetVal, aCheckVal );
    if ( sOldVal == aCheckVal )
    {
        return RC_SUCCESS;
    }
    else
    {
        return RC_FAILURE;
    }
}


/******************************************************************************
 * Name : mAtomicUnlock
 *
 * Description
 *     atomic unlock 을 한번만 시도 후 결과 리턴
 *
 * Argument
 *     aLock        : input   : lock value
 *     aSetVal      : input   : lock value 를 교체할 신규 값
 *     aCheckVal    : input   : lock value 에 저장된 것과 compare 할 값
 *
 ******************************************************************************/
_VOID dbmLockManager::mAtomicUnlockTry( char* aLockVal, int aCheckVal )
{
#ifdef _DEBUG
    atomic_inc ( &g_cnt_lock.mAtomicUnlockTry );
#endif
    int     sOldVal;

    sOldVal = mvpAtomicCas32( aLockVal, -1, aCheckVal );
    if ( sOldVal == aCheckVal )
    {
        return RC_SUCCESS;
    }
    else
    {
        //DBM_WARN ( " mAtomicUnlockTry Error. [%d][%d] \n", sOldVal, aCheckVal );

        if( sOldVal == -1 )
        {
            return RC_SUCCESS;
        }
        else
        {
            // aLockVal 에는 aCheckVal 과 다른 0 보다 큰 값이 있다.
            // 누군가 내가 이번에 해제하려는 Row 의 Tx 와 다른 값으로 세팅해둔 상태라는 얘기임.
            // 그 누군가는 현재 살아있는 놈인지 아닌지 알 수는 없음.
            // 적절한 Error Code 가 없어서 ERR_DBM_UNLOCK 로 일단 설정하여 리턴.
            // 이는 호출하는 쪽에서 에러를 구분하여 챙겨야 함.
            // sh perf.sh 수행 시 aLockVal[-502426688] aCheckVal[5]  위와 같은 상황이
            // 올 수 있다. 일단 막음.

            DBM_WARN( "aLockVal[%d] aCheckVal[%d] \n", *(int*)aLockVal, aCheckVal );

            return RC_SUCCESS;
            //return ERR_DBM_UNLOCK;
        }

        // 여기는 contention 때문에 진짜 cas 연산이 실패한 경우 
        return RC_FAILURE;
    }
}


//#define _DEBUG_TXID     6             // 특정 TXID에서 락이 자꾸 꼬일때 디버그.
#ifdef _DEBUG_TXID
define _DEBUG_TXID2    9
#endif

/******************************************************************************
 * Name : mSpinLock
 *
 * Description
 *     Lock 잡을 때까지 Spin
 *
 * Argument
 *     aLock        : input   : lock value
 *     aFutex       : input   : futex wait 에서 사용할 futex value
 *     aMyTxID      : input   : my ID (어떤 ID 든 상관없다.)
 *
 ******************************************************************************/
_VOID dbmLockManager::mSpinLock ( volatile void* aLock , volatile int* aFutex , int aMyID )
{
#ifdef _DEBUG
    atomic_inc ( &g_cnt_lock.mSpinLock );
#endif
    int     sOldID;
    int     sOldPID;
    int     sSpin = 0;
    int     retryCnt = 0;

    while (1)
    {
        sSpin++;

        /***********************************************
         * Lock을 잡으려고 시도한다.
         *  - aLock 변수에 들어 있는 값이 -1 이면
         *    aMyID 로 변경한 후 이전 값인 -1 을 리턴하고,
         *  - aLock 변수에 들어 있는 값이 -1 이 아니면
         *    aMyID 로 변경하지는 못하고 이전 값을 리턴한다.
        ***********************************************/
        //sOldID = *(int*)aLock;

        sOldID = mvpAtomicCas32 ( aLock, aMyID, -1 );
        if ( sOldID == -1 || sOldID == aMyID )
        {
            /*
             * 2014.11.24 -shw- mlockinfo tid 값이 -1이면 죽어 있다 보고 aMyID를 aLock
             * 정보로 가져 올 수 있기 때문에 sOldID 와 aMyID를 같은 값이 올 수 있다
             */
#if 0 //def _DEBUG
            if ( sOldID == aMyID )
            {
                _DASSERT( 0 ); // 2014.09.18 (OKT_L0) #609 중복락 처리일때 죽자. (임시코드)
            }
#endif
            /***********************************************
             * 원래값이 -1 이거나 내 값(aMyID)과 같을 때 성공
            ***********************************************/
            break;
        }

#if 0
        if ( likely( sOldID == -1 ) )
        {
            sOldID = mvpAtomicCas32 ( aLock, aMyID, -1 );
            if ( sOldID == -1 || sOldID == aMyID )
            {
                /***********************************************
                 * 원래값이 -1 이거나 내 값(aMyID)과 같을 때 성공
                ***********************************************/
                break;
            }
        }
        else if ( sOldID == aMyID )
        {
            _DASSERT( 0 );      // 2014.09.18 (OKT_L0) #609 중복락 처리일때 죽자. (임시코드)
            break;
        }
#endif

        /***********************************************
         * kill 시스템콜 횟수를 줄이기 위해,
         * cpu 개수 만큼, busy retry.
        ***********************************************/
        if ( retryCnt < _cmn_sys_ncpu )
        {
            retryCnt++;
            //cmnNanoSleep( 10 );
            cmnNanoSleep( 20 );         // 이게 수치가 가장 좋다. (dev3)
            //cmnNanoSleep( 40 );
            //cmnNanoSleep( 100 );
            //cpu_relax();
            //pthread_yield_s();
            continue;
        }
        else
        {
            retryCnt = 0;
        }

        /***********************************************
         * 이전에 잡은놈의 PID를 체크해본다.
         * (그러기 위해서는 lock manager 생성 시 저장해둔
         *  user lock info 영역에 있는 PID 값에 접근해야 한다.
         *  이 user lock info 영역은 ID 로 PID 를 가져올 수 있는
         *  어떤 영역이다.)
        ***********************************************/
        sOldPID = mvpAtomicGet32 ( (int *) ( __mLockInfo + __mLockInfoSize * sOldID ) );



        /* 2014.11.24 -shw- sOldPID -1이 올 수 있다. 올 수 있는 경우는 FinalTrans 또는 InitTrans일때
         * 올 수 있다. 이 때에에는 -1이여도 lock을 처리 하고 타는 경우이므로 실제 -1 값이 올 수 없다.
         * 여지껏 올수 있었던 이유는 dictionary의 mLockInfo 값을 static global로 써서 여서 올 수 있었
         * 으며 이는 버그로 bug-717 에서 dictionary bug로 해당  케이스를 참고 바란다 */
        //if ( sOldPID == 0 || ( tkill_s ( sOldPID, 0 ) && errno == ESRCH ) )
        if ( ( sOldPID == 0 || sOldPID == -1 ) || ( tkill_s ( sOldPID, 0 ) && errno == ESRCH ) )
        {
            /***********************************************
             * 죽은 놈이니 그냥 aMyID 값으로 갈아치자.
            ***********************************************/
            mvpAtomicCas32 ( aLock, aMyID, sOldID );
            continue;
        }
        else
        {
            retryCnt = 0;
            pthread_yield_s ();
        }

        /***********************************************
         * try횟수가 오버하면 좀 쉬자.
        ***********************************************/
        if ( sSpin >= DBM_SPIN_COUNT && aFutex != NULL )
        {
            //cmnWaitFutex ( aFutex, FUTEX_WAIT_TIME );
            cmnWaitFutex2 ( aFutex );
            sSpin = 0;
        }
    } /* while */

#ifdef _DEBUG_TXID
    if ( aMyID >= _DEBUG_TXID && aMyID <= _DEBUG_TXID2 )
    {
        DBM_DBG( ">>   mSpinLock OK. [aMyID=%d, aLock=%p,%2d, LockPID=%d] (err=%d,tid=%d)",
                 aMyID, aLock, *(int*)aLock, *(int *) ( __mLockInfo + __mLockInfoSize * aMyID ), errno, gettid_s() );
    }
#endif

    return RC_SUCCESS;
} /* mSpinLock */


/******************************************************************************
 * Name : mSpinUnlock
 *
 * Description
 *
 * Argument
 *     aLock        : input   : lock value
 *     aFutex       : input   : futex wait 에서 사용할 futex value
 *     aMyTxID      : input   : my ID (어떤 ID 든)
 *
 ******************************************************************************/
_VOID dbmLockManager::mSpinUnlock ( volatile void* aLock , volatile int* aFutex , int aMyID )
{
#ifdef _DEBUG
    atomic_inc ( &g_cnt_lock.mSpinUnlock );
#endif
    int sOldID;

    /***********************************************
     * 자기가 건 lock 도 아니고 초기값도 아님.
     * 다른놈이 spin lock 한것은 풀지 못함.
    ***********************************************/
    if ( mvpAtomicGet32 ( aLock ) != aMyID )
    {
#ifdef _DEBUG
        DBM_ERR( "[FATAL] SpinUnlock error [aMyID=%d, aLock=%p,%d, LockPID=%d] (err=%d,tid=%d)",
                 aMyID, aLock, mvpAtomicGet32(aLock),
                 *(int *) ( __mLockInfo + __mLockInfoSize * mvpAtomicGet32(aLock) ), errno, gettid_s() );
        _DASSERT( 0 );      // 2014.09.18 (OKT_L0) #609 중복락 처리일때 죽자. (임시코드)
#endif

        if ( mvpAtomicGet32(aLock) != -1 )
        {
            DBM_ERR( "[FATAL] SpinUnlock error [aMyID=%d, aLock=%p,%d, LockPID=%d] (err=%d,tid=%d)",
                     aMyID, aLock, mvpAtomicGet32(aLock),
                     *(int *) ( __mLockInfo + __mLockInfoSize * mvpAtomicGet32(aLock) ), errno, gettid_s() );

            return RC_FAILURE;
        }
        else
        {
            return RC_SUCCESS;
        }
    }

    /***********************************************
     *  - aLock 변수에 들어 있는 값이 aMyID 이면
     *    -1 로 변경한 후 이 전값인 aMyID 를 리턴하고,
     *  - aLock 변수에 들어 있는 값이 aMyID 가 아니면
     *    그냥 그 값을 리턴한다.
    ***********************************************/
retry:
    sOldID = mvpAtomicCas32 ( aLock, -1, aMyID );
    if ( sOldID == -1 || sOldID == aMyID )
    {
        /***********************************************
         * 원래 값이 -1 이거나 aMyID 일 때만 성공
        ***********************************************/
    }
    else
    {
        /***********************************************
         * 자기가 건 lock 이거나 -1 인데 cas 실패이면
         * 다시 시도
        ***********************************************/
        goto retry;
    }

    if ( aFutex != NULL )
    {
        //cmnSignalFutex ( aFutex );
        cmnSignalFutex2 ( aFutex );
    }


#ifdef _DEBUG_TXID
    if ( aMyID >= _DEBUG_TXID && aMyID <= _DEBUG_TXID2 )
    {
        DBM_DBG( ">> mSpinUnlock OK. [aMyID=%d, aLock=%p,%2d, LockPID=%d] (err=%d,tid=%d)",
                 aMyID, aLock, *(int*)aLock, *(int *) ( __mLockInfo + __mLockInfoSize * aMyID ), errno, gettid_s() );
    }
#endif

    return RC_SUCCESS;
} /* mSpinUnlock */


/******************************************************************************
 * Name : mLockPid
 *
 * Description
 *     특정 lock value 를 이용하여 lock 을 시도하고 만약 다른 Process 가
 *     Lock 을 걸어둔 상태이면 해당 Process 가 살아있는지를 검사하여,
 *     죽었으면 자신의 Pid 로 갈아치고 살아있으면 lock 실패가 된다.
 *
 * Argument
 *     aLock        : input   : lock value
 *     aSetPid      : input   : lock value 를 교체할 신규 pid 값
 *     aPidRelacedF : output  : 이전 lock value 에 다른 pid 가 있었으나
 *                              신규 pid 로 교체성공했다. (복구에 이용 )
 *
 ******************************************************************************/
_VOID dbmLockManager::mLockPID ( char* aLockVal , int aSetPid , int* aPidReplacedF )
{
#ifdef _DEBUG
    atomic_inc ( &g_cnt_lock.mLockPID );
#endif
    int     sRC;
    int     sOldPID;

    _TRY
    {
        /***********************************************
         * aLockVal 이 0 이면 aSetPid 로 교체를 시도한다.
         * 교체가 성공하면 sOldPID = 0 으로 리턴된다. ( Lock 성공 )
         *
         * [주의]
         * 통상 -1 을 락해제의 기준으로 하지만. 0을 기준으로한다.
         * SHM상에 TxHeader 블럭이 생성시 0으로 초기화되기 때문
         ***********************************************/
        sOldPID = mvpAtomicCas32( aLockVal, aSetPid, 0 );
        if ( sOldPID == -1 )
        {
            sOldPID = mvpAtomicCas32( aLockVal, aSetPid, -1 );
        }

        if ( sOldPID == 0 || sOldPID == -1 || sOldPID == aSetPid )
        {
            /***********************************************
             * lock success.
             ***********************************************/
        }
        else
        {
            /************************************************
             * aLockVal 이 0 이 아니어서 kill 로 살아있는 놈인지 검사한다.
             *
             * 1. 락이 누가 잡았다가 풀었거나 ( = -1 )
             * 2. tkill() 에서 해당 thread 가 죽었거나.
             ************************************************/
            if ( tkill_s( sOldPID, 0 ) && errno == ESRCH )
            {
                /************************************************
                 * 죽은 놈이었다.
                 ************************************************/
                if ( mvpAtomicCas32( aLockVal, aSetPid, sOldPID ) == sOldPID )
                {
                    /************************************************
                     * aSetPid 로 교체 성공했다. ( lock success )
                     ************************************************/
                    *aPidReplacedF = 1;
                }
                else
                {
                    /************************************************
                     * 왜 그런지는 모르겠으나 aSetPid 로 교체를 못했다.
                     ************************************************/
                    _THROW( RC_FAILURE ); //LOCK_FAIL );
                }
            }
            else
            {
                /************************************************
                 * 살아있는 놈이었으므로 Lock 은 실패다.
                 * 다른 LockVal 로 다시 시도해봐라.
                 ************************************************/
                _THROW( ERR_DBM_LOCK_ROW_BY_OTHER_ALIVE_PROC );
            }
        }
    }
    _CATCH
    {
        //_CATCH_TRC;  // 정상에서 실패할수 있다. 안찍는다.
    }
    _FINALLY
    _END
} /* mLockPID */


/******************************************************************************
 * Name : mLock
 *
 * Description
 *
 * Argument
 *     aLock        : input   : lock value
 *     aTxTable     : input   : ptr to dbmTransTable
 *     aMyID        : input   : my transaction ID
 *     aPirReplaced : output  : Transaction PID
 *
 ******************************************************************************/
_VOID dbmLockManager::mLock ( volatile void* aLock , int aMyID , int* aPidReplacedF , int* aPirReplaced )
{
#ifdef _DEBUG
    atomic_inc ( &g_cnt_lock.mLock );
#endif
    int                 sOldID;
    int                 sOldPID;
    int                 sPidTryCheck;

    sOldID = -1;

    int retryCnt = 0;
    int tid = gettid_s();
    while (1)
    {
        /***********************************************
         * Lock을 잡으려고 시도한다.
         *  - aLock 변수에 들어 있는 값이 -1 이면
         *    aMyID 로 변경한 후 이전 값인 -1 을 리턴하고,
         *  - aLock 변수에 들어 있는 값이 -1 이 아니면
         *    그냥 그 값을 리턴한다.
        ***********************************************/
        sOldID = mvpAtomicCas32 ( aLock, aMyID, -1 );
        if ( sOldID == -1 || sOldID == aMyID )
        {
            /***********************************************
             * -1 이면 aMyID 로 교체되어 성공.
             * aOldTxID = aMyID 는 자기가 잡은거니까 성공.
            ***********************************************/
            break;
        }

        if ( retryCnt < _cmn_sys_ncpu )
        {
            retryCnt++;
            pthread_yield_s();
            continue;
        }
        else
        {
            retryCnt = 0;
        }

        /***********************************************
         * 다른놈이 Lock 을 잡고 있으니, 그 TxId 를 가지고
         * dbmTransHeader 에 있는 PID 를 찔러본다.
        ***********************************************/
        sOldPID = mvpAtomicGet32 ( (int *) ( __mLockInfo + __mLockInfoSize * sOldID ) );

        /* 2014.04.22 -shw- pid 0으로 초기화 되는 부분은 pid 교체 처리 */
        if ( sOldPID == 0 || sOldPID == tid )
        {
            mvpAtomicCas32 ( aLock, aMyID, sOldID );
            continue;
        }

        /* 2014.07.08 -shw- Transaction pid 반환하여 위의 코드를 가지고
         * 동시성 관련 처리를 한다 */
        *aPirReplaced = sOldPID;

        //if ( sOldPID == -1 || ( tkill_s ( sOldPID, 0 ) && errno == ESRCH ) )
        if ( tkill_s ( sOldPID, 0 ) && errno == ESRCH )
        {

            /***********************************************
             * 찔러봤더니 죽은 놈이더라.
             * 그래서, 내 pid 로 교체해본다.
            ***********************************************/
            if ( sOldPID == mvpAtomicCas32 ( ( __mLockInfo + __mLockInfoSize * sOldID ), tid, sOldPID ) )
            {
                *aPidReplacedF = 1; /* pid 교체 성공 */
            }
            else
            {
                *aPidReplacedF = 0; /* pid 교체 실패 */
            }

            return ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC;
        }
        else
        {
            /***********************************************
             * 찔러봤더니 산 놈이더라.
            ***********************************************/
            return ERR_DBM_LOCK_ROW_BY_OTHER_ALIVE_PROC;
        }
    } /* while */

    return RC_SUCCESS;
}


/******************************************************************************
 * Name : mUnlock
 *
 * Description
 *     unlock 을 시도 후 결과 리턴
 *
 * Argument
 *     aLock        : input   : lock value
 *     aSetVal      : input   : lock value 를 교체할 신규 값
 *     aCheckVal    : input   : lock value 에 저장된 것과 compare 할 값
 *
 ******************************************************************************/
_VOID dbmLockManager::mUnlock( volatile void* aLockVal, int aCheckVal )
{
#ifdef _DEBUG
    atomic_inc ( &g_cnt_lock.mUnlock );
#endif
    int     sOldVal;

    sOldVal = mvpAtomicCas32( aLockVal, -1, aCheckVal );
    if ( sOldVal == aCheckVal )
    {
        return RC_SUCCESS;
    }
    else
    {
        return RC_FAILURE;
    }
}


/******************************************************************************
 * Name : mTableLock
 *
 * Description
 *      table lock 을 걸고 싶을 때 사용. (현재 queue 에서 사용)
 *
 * Argument
 *     aLock        : input   : lock value
 *     aTransID     : input   : transaction ID
 *     aTLogH       : input   : trace log handle
 *
 ******************************************************************************/
_VOID dbmLockManager::mTableLock ( volatile void* aLock , int aTransID , int* aOldTx )
{
#ifdef _DEBUG
    atomic_inc ( &g_cnt_lock.mTableLock );
#endif
    int     sRC;
    int     sPidReplacedF = 0;
    int     sPidTryCheck = 0;
    int     sOldPID = 0;
    int     sOldTxID;
    int     sPirReplaced = 0;

    _TRY
    {
retry:
        *aOldTx = mvpAtomicGet32( aLock );

        sRC = dbmLockManager::mLock( aLock,
                                     aTransID,
                                     &sPidReplacedF,
                                     &sPirReplaced );

        if ( (sRC == ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC) && (sPidReplacedF == 1) )
        {
            /***********************************************
             * 다른 process 에 의해 lock 이 걸린 후 해당
             * process 는 down 되었다.
             * my pid 로 대체되고 lock 이 걸렸지만 이전 놈의
             * Transaction 은 강제 Rollback 시켜야 한다.
             * Recovery Manager 함수를 static 으로 불러야하는데
             * 여기서 직접 부를 수는 없다.
             * 리턴받는 놈이 recovery rollback 수행
             ***********************************************/

            _THROW( ERR_DBM_ABNORMAL_ROLLBACK );
        }
        else if ( (sRC == ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC) && (sPidReplacedF == 0) )
        {
            /***********************************************
             * 다른 process 에 의해 lock 이 걸린 후 해당
             * process 는 down 되었다.
             * my pid 로 대체하려고 했는데 무슨 이유인지 실패했다.
             ***********************************************/
            pthread_yield_s();
            goto retry;
        }
        else if ( sRC == ERR_DBM_LOCK_ROW_BY_OTHER_ALIVE_PROC )
        {
            /***********************************************
             * 다른 process 에 의해 lock 이 걸린 상태인데
             * 그 process 는 아직 살아있다.
             * 그게 내 process 일 수도 있지만, TxID 는 다른놈이다.
             ***********************************************/
            /*
             * TODO. deadlock processing -> fail return
             * 일단 dead lock 이 아니라고 가정하고 retry.
             */

            /* 동시성 제어 관련 PID가 -1경우 해당 값을 retry 하도록 수정 한다 */
            /* 2014.07.08 -shw */
            if ( sPirReplaced == -1 )
            {
                sOldTxID = mvpAtomicGet32( aLock );

                if ( sPidTryCheck == 10000 )
                {
                    mvpAtomicCas32 ( aLock, aTransID, sOldTxID );
                }
                sPidTryCheck++;
            }

            pthread_yield_s();
            goto retry;
        }
        else
        {
            if ( sRC != 0 )
                _DASSERT( 0 );  // 이런 유형은 없다.

            /*
             * success. do nothing.
             */
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mTableLock */


_VOID dbmLockManager::mTableUnlock ( volatile void* aLock , int aTransID )
{
#ifdef _DEBUG
    atomic_inc ( &g_cnt_lock.mTableUnlock );
#endif
    return dbmLockManager::mUnlock( aLock, aTransID );
}

/******************************************************************************
 * Name : mCheckLockPID
 *
 * Description
 *     aLock 을 잡고 있는 Process 가 살아있나 죽어있나를 체크.
 *
 * Argument
 *     aLock        : input   : lock value
 *     aTxTable     : input   : ptr to dbmTransTable
 *     aMyID        : input   : my transaction ID
 *
 ******************************************************************************/
int dbmLockManager::mCheckLockPID ( int aOldID )
{
#ifdef _DEBUG
    atomic_inc ( &g_cnt_lock.mCheckLockPID );
#endif
    int                 sOldPID;

    sOldPID = mvpAtomicGet32((int *)(__mLockInfo + __mLockInfoSize * aOldID));
    // 0 혹은 -1 일수있다.
    if ( sOldPID > 0 )
    {
        if ( tkill_s( sOldPID, 0 ) && errno == ESRCH )
        {
            return ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC;
        }
        else
        {
            return ERR_DBM_LOCK_ROW_BY_OTHER_ALIVE_PROC;
        }
    }

    return RC_FAILURE;
}

/******************************************************************************
 * Name : mRecoverCheckLockPID
 *
 * Description
 * aLock 을 잡고 있는 Process 가 살아있나 죽어있나를 체크.
 * 하나의 sesssion에서 lock을  잡고 죽었을 경우 mRecoverCheckLockPID 통하여 해당 프로세서가 
 * 죽었는지 살았는지 체크를 한다. mRecoverCheckLockPID 통하여 해당 프로세서가 죽었을 경우
 * ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC 값을 반환하여 mRecoverTrans 통한 Recovery를  수행 하는
 * 데 이 때 여러개의 session에서 동일한 row을 보아 위의 펑션을 통하여 ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC 
 * 값을 리턴 받았을 때 동시에 여러개의 session에서 동일 row에 대하여 Recovery를 할 수  있다.  
 * 이에 mRecoverCheckLockPID() 함수를 하나 다로 만들어  ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC로 
 * 처리 될 경우 해당 TransHeader에 현재의 PID를 삽입하여 다른 Transaction이 해당 row을 보려고 
 * tkill 하였을 때 정상 적으로 살아 있다고 체크하게 하여 동시에 session이 들어와도 하나의 
 * session에서만 recovery를 할 수 있도록 한다. 
 *
 * Argument
 *     aLock        : input   : lock value
 *     aTxTable     : input   : ptr to dbmTransTable
 *     aMyID        : input   : my transaction ID
 *
 ******************************************************************************/
int dbmLockManager::mRecoverCheckLockPID( int aOldID, int aMyTxID )
{
#ifdef _DEBUG
    atomic_inc ( &g_cnt_lock.mCheckLockPID );
#endif
    int sOldPID;
    int sMyPID;                
    int sOldVal;

    sOldPID = mvpAtomicGet32((int *)(__mLockInfo + __mLockInfoSize * aOldID));
    // 0 혹은 -1 일수있다.
    if ( sOldPID > 0 )
    {
        if ( tkill_s( sOldPID, 0 ) && errno == ESRCH )
        {
            /* 현재 내 PID 가져온다 */
            sMyPID = mvpAtomicGet32((int *)(__mLockInfo + __mLockInfoSize * aMyTxID )); 

            /* 다른 놈이 보지 못하도록 PID를 추가 한다 */
            //*(int *)(__mLockInfo + __mLockInfoSize * aOldID) = sMyPID;

            sOldVal = mvpAtomicCas32( (__mLockInfo + __mLockInfoSize * aOldID), sMyPID, sOldPID );
            if( sOldVal == sOldPID )
            {
                return ERR_DBM_LOCK_ROW_BY_OTHER_DEAD_PROC;
            }
            else
            {
                return ERR_DBM_LOCK_ROW_BY_OTHER_ALIVE_PROC;
            }
        }
        else
        {
            return ERR_DBM_LOCK_ROW_BY_OTHER_ALIVE_PROC;
        }
    }

    return RC_FAILURE;
}

