/*
 * dbmServer.cpp
 *
 *  Created on: Mar 4, 2014
 *      Author: paul
 */

/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/
#include "dbmHeader.h"
#include "dbmServer.h"

#ifdef _BSD_SOURCE
#define USE_ONEXIT
#endif

#ifndef __linux__	//TODO: [OKT]  윈도포팅

#define	SIGHUP	1	/* hangup */
#define	SIGQUIT	3	/* quit */
#define	SIGTRAP	5	/* trace trap (not reset when caught) */
#define SIGIOT  6   /* IOT instruction */
#define	SIGEMT	7	/* EMT instruction */
#define	SIGKILL	9	/* kill (cannot be caught or ignored) */
#define	SIGBUS	10	/* bus error */
#define	SIGSYS	12	/* bad argument to system call */
#define	SIGPIPE	13	/* write on a pipe with no one to read it */
#define	SIGTSTP	18	/* write on a pipe with no one to read it */

#endif


////////////////////////////////////////////////////////////////////////////////
// 내부 함수: 자동으로 호출되며 사용자가 직접 호출할 수 없음.
////////////////////////////////////////////////////////////////////////////////
int             _dbm_argc = 0;
const char**    _dbm_argv = NULL;
int             _dbm_scn_ascending = 0;

// 내부 함수 선언 ( static 으로 선언하면 이상해진다 ?? )

#ifdef USE_ONEXIT
static void _dbm_exit ( int status, void* arg );
#else
static void _dbm_exit ( void );
#endif

static void _dbm_usage ( );
static void _dbm_sigHandler ( int sig );
static _VOID _dbm_sig_init ( );
static _VOID _dbm_config_init ( );
static _VOID _dbm_err_init ( );
//static _VOID _dbm_numa_init ( );
static _VOID _dbm_mem_init ( );
static _VOID _dbm_log_init ( );
static _VOID _dbm_timer_init ( );
static _VOID _dbm_init ( );
static _VOID _dbm_test ( );


/**
 * TODO: cmnAtmain - __attribute__((constructor))
 *
 * 1. 설정로딩
 * 2. 로그 초기화
 * 3. 모니터링 쓰레드 초기화
 * 4. ..
 *
 * @BUGBUG
 *  gdb로 추적할때 _dbm_main 쪽이 -O0임에도 라인이 안맞음
 */

__attribute__((constructor))
_VOID _dbm_main ( int argc , const char** argv )
{
    char* pChar = NULL;

    _TRY
    {
#ifdef __linux__

#if ! __GNUC_PREREQ (4, 7)
#warning "gcc version check warning, must be 4.7.x or greater to enable full dbm construct functionality"
#else
//        _dbm_argc = argc;
//        _dbm_argv = argv;
//
//        /**
//         * [매뉴얼]
//         * glibc-2.12-1.80.el6_3.6.x86_64 버전에서는 비정상 종료 ( argc, argv 를 전달받지 못함 )
//         * glibc-2.12-1.132.el6.x86_64 에서 정상 동작 확인.
//         */
//        if ( _dbm_getArg ( "-dbm_help" ) != NULL )
//        {
//            _dbm_usage ( );
//        }
#endif

#endif /* __linux__ */

        if ( getenv ( ENV_DBM_TRCLOG_ECHO ) != NULL )
        {
            _cmn_log_echo = atoi ( getenv ( ENV_DBM_TRCLOG_ECHO ) );
        }

        // Failover 테스트를 위한 RTF_POINT에 진입하면 성능 비용이 크다. 이를 환경변수로 제어가능하게.
        pChar = getenv( ENV_DBM_RTF_ON );
        if ( pChar != NULL )
        {
            if ( atoi(pChar) != 0 )
            {
                _cmn_use_rtf = 1;
            }
        }

        // 허걱 태원님 자리에서 gdb로 붙으면 아래가 NULL이 나옴 ( SecureCRT 차인지 분석안함 )
#ifdef __linux__	//TODO: [OKT]  윈도포팅
        pChar = getenv( "_" );
        if ( pChar != NULL )
        {
            // 2014.12.14. -okt- gcc 4.7.x 이상에서만 argc, argv가 잘동작하는듯한 느낌. "_" 로 대체한다.
            //char* pChar = basename ( (char*)argv[0] );
            pChar = basename ( getenv( "_" ) );

            // 화면출력 모듈은 _dbm_echo 를 disable 해서 화면을 깨끗하게 한다.
            if ( cmnLogGetAppType( pChar ) < 2 )
            {
                _cmn_log_echo = 0;
            }
        }
#else
        _cmn_log_echo = 0;
#endif /* __linux__ */

        pChar = getenv ( ENV_DBM_FILE_MODE );
        if ( pChar != NULL )
        {
            _cmn_file_mode = 0;

            // 8진수 값이다.
            for ( int i = strlen_s( pChar ) - 1, k = 0; i >= 0; i--, k++ )
            {
                if ( pChar[i] < '0' || pChar[i] > '7' )
                {
                    // 잘못된 값이다. 그냥 오류없이 원복한다.
                    _cmn_file_mode = DBM_FILE_MODE;
                    break;
                }
                _cmn_file_mode += ( pChar[i] - '0' ) * pow( 8, k );
            }
        }

        pChar = getenv ( ENV_DBM_SHM_PREFIX );
        if ( pChar != NULL )
        {
            _cmn_shm_prefix = pChar;
        }

        if ( getenv ( ENV_DBM_SCN_ASCENDING ) != NULL )
        {
            _dbm_scn_ascending = atoi ( getenv ( ENV_DBM_SCN_ASCENDING ) );
        }

#ifndef _DEBUG
        /*
         *  [패키징] 릴리즈 배포판에는. 사용자가 원하지 않을 수도 있는 동작을 가능하면 하지 않는다.
         *          Sync 모드에서는 현재로는 atexit 처리가 필요없다. ( 2014/07/13 )
         */
        if ( cmnLogManager::m_nLogSyncFlag == 0 )
#endif
        {
#ifdef USE_ONEXIT
            _CALL( on_exit ( _dbm_exit , NULL ) );
#else
            _CALL ( atexit ( _dbm_exit ) );
#endif
        }


        _CALL ( _dbm_init ( ) );

        // timer test
        //_CALL ( _dbm_test ( ) );
    }
    _CATCH
    {
        _CATCH_ERR;
        exit ( EXIT_FAILURE );
    }
    _FINALLY
    {
        /*
         * 2014.12.14. -okt- _dbm_main 에서 argv 문제.
         * InitGoogleTest ( &argc, argv )
         * 처럼 dbm 자체의 옵션을 가져오고, 해당 옵션을 지운다.
         *
         * 문제) metaManager: unrecognized option '--dbm_help'
         * 해결) GTEST와는 달리 argc가 포인터로 넘어온게 아니므로, 방법을 모르겠다. 일단 우리 유틸을 수정하고,
         *      인자로는 안되고, 설정이나 환경변수 필요함. ( 꼭 인자도 필요하면, LD_PRELOAD는 가능할듯 )
         */
    }
    _END
} /* _dbm_main */


#ifdef USE_ONEXIT
void _dbm_exit (  int status, void* arg )
#else
void _dbm_exit ( void )
#endif
{
    // _dbm_main에서 구동한 모듈들에 대한 종료처리. (순서 의존성 주의)
    {
        cmnLogManager::destroy();
    }

    //TODO: 2014.12.14. -okt- 2014/07/08, _OKT_TRC_CALLER 를 사용할때 맴의 문제인지, 마지막에 여기서. malloc_consolidate() 행..
#if defined(_DEBUG) && !defined(_OKT_TRC_CALLER)
    if ( cmnLogGetAppType( cmnLogManager::service_name ) > 0 )
    {
#ifdef USE_ONEXIT
        DBM_SYS_F ( "************** '%d' process end (err=%d,rc=%d) *******************"  , getpid_s(), errno, status );
#else
        DBM_SYS_F ( "************** '%d' process end (err=%d) *******************"  , getpid_s(), errno );
#endif
    }
#endif
}


_VOID _dbm_init ( )
{
    char*   pChar = NULL;
    int     sRC;

    _TRY
    {
#if 1 //ndef _DEBUG
        pChar = getenv ( ENV_DBM_USE_SIGNAL_HANDLER );
        if ( pChar == NULL || pChar[0] != '0' )
#endif
        {
            _CALL ( _dbm_sig_init ( ) );
        }

        // 초기화작업 ( 데몬까지는 아니지만, 마치 데몬처럼 )
        _CALL ( _dbm_config_init (  ) );
        _CALL ( _dbm_err_init (  ) );


        /*
         *  2014.12.14. -okt- [성능] _dbm_setaffinity 미사용.
         *  우리가 만든 모든 쓰레드는 cpuset 를 지정할 수 있다.
         *
         *  또한 여기서 main-thread (지금자신)에 대해 cpuset을 우리가 지정한 것을 피해서, 아니면 잘 조합해서
         *  배치할 수도 있기 때문에.
         *  업무에서 직접 생성하는 thread 일지라도, 업무에서 명시적으로 cpu-set을 지정하지 않는 경우는 우리가
         *  제어할 수 있다.
         *  이 제어를 할때 조심할 것은 외부명령 (taskset 혹은 OS설정) 으로 이미 cpuset이 제어되어서 들어온 경우
         *  고려를 해주어야한다.
         *
         *  당연한 얘기지만 cpuset 지정할때 hyper번호와 core-id 관계는 읽어와서 정해야함.
         */
        // 2014.11.24 -okt- NUMA 적용.
        //_CALL ( _dbm_setaffinity ( ) );
        (void) _dbm_numa_init ( ); // CPU 설정실패해도. 무시한다.


        /*
         *  2014.12.14. -okt- cmnLogManager::m_nLogSyncFlag 중복설정.
         * cmnLogManager() 생성에서 수행되지만.
         * 현재는 로그 전용인 메모리관리자를 사용하지 않기 위해서. 여기서 중복 체크
         */
        pChar = getenv ( ENV_DBM_TRCLOG_ASYNC_ENABLE );
        if ( pChar != NULL )
        {
            if ( atoi( pChar ) != 0 )
            {
                cmnLogManager::m_nLogSyncFlag = 0;
            }
        }

        if ( cmnLogManager::m_nLogSyncFlag == 0 )
        {
            _CALL ( _dbm_mem_init (  ) );
        }
        _CALL ( _dbm_log_init (  ) );           //TODO: 2014.12.14. -okt- 로그파일명 등을 여기서 생성하지만, 사용자가 나중에 사용자가 변경가능 해야함.

//      _CALL ( _dbm_timer_init (  ) );         // Timer쓰레드, 여기서 안 만들고 실제 사용할때 만들어도 될듯.
//      _CALL ( _dbm_mon_init (  ) );           // 모니터링쓰레드 ( 일단은 Timer쓰레드랑 통합해도 될듯 )
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


void _dbm_usage ()
{
#ifdef __linux__	//TODO: [OKT]  윈도포팅

	printf ( "\n" );
//  printf ( "usage: %s --dbm_name=<job_name> ..\n", basename ( _dbm_argv[0] ) );
    char* pChar = getenv( "_" );
    if ( pChar != NULL )
    {
        _PRT ( "usage: %s --dbm_name=<job_name> ..\n", basename ( getenv( "_" ) ) );
    }
    else
    {
        _PRT ( "usage: %s --dbm_name=<job_name> ..\n", "NONE" );
    }

    printf ( "  --dbm_xx                : dbm internal opt\n" );
    printf ( "  --dbm_help              : this help\n" );
    printf ( "  --dbm_name=<job_name>   :\n" );
    printf ( "\n" );
    printf ( "\n" );

#endif /* __linux__ */

    // 숨겨진 메인으므로 여기서 종료할수 없다.
    exit ( 0 );
}


void _dbm_sigHandler ( int sig )
{
    _TRY
    {
        _cmn_signo = sig;

        // '-1' 인 경우는 임계영역에 있을 수 있있다. 이때는 그냥 리턴한다. 임계영역 나올때 raise할거다.
        if ( _cmn_signo_r == -1 )
        {
            _cmn_signo_r = sig;
#ifdef _DEBUG
            _PRT ( "(W) Signal(%d) recieved from critical section, so return again..\n\n", sig );
            // 내부에서 발생하면 최초 시점을 로그로 하나 찍어둔다.
            cmnCallStack ( sig );
#endif
            return; // 의도적
        }

        // _cmn_signo 이 설정되고 나서, 내부 함수들이 임계영역에서 나올때까지. 기다려준다.
        usleep( 100 * 1000 );

        // 2014.12.14. -okt- 시그널 처리 함수에는 중복 호출 방지와 fprintf 등 안전하지 않은 함수 사용금지 혹은 뒷부분 배치. 필요.
        // 2014.12.14. -okt- CallStack에서 라인번호를 얻을려면, /proc/<pid>/maps 내용을 함께 기록해두어야한다. addr2line
#ifdef _DEBUG
        _PRT ( "(E) _dbm_main [Signal %02d handler] Start..\n\n", sig );
#endif

        fflush ( stdout );
        fflush ( stderr );

        switch ( sig )
        {
            /*
             * TODO: 2014.11.24 -okt- 임계영역 시그널 처리
             * SIGINT는 처리하면 안된다.
             *      1. metaManager에서 Ctr+C에 반응해야함.
             *      2. strace를 걸수없게 된다. (재현안됨)
             *      3. libedit 랑 쫑나는 것인지. 아래 풀고, metaManager에서 SIGINT하면 화면에 타이핑이 안보인다.
             */
            case SIGINT:
                //raise ( sig );    // 이걸풀면 무한루프이다.
                _EXIT ( sig );
                break;

            case SIGTERM:
            //case SIGKILL:
            {
                signal ( sig, SIG_DFL );
                raise ( sig );
                break;
            }

            // 비정상종료
            case SIGABRT:
            case SIGSEGV:
            case SIGBUS:
            case SIGILL:
            case SIGFPE:
            {
                // 서로 다른 시그널이 왔을때, 처음 것만 처리된다. (어짜피 죽으니깐)
                static int bFirst = 1;
                if ( ! bFirst )
                {
                    signal ( sig, SIG_DFL );
                    sleep ( 10 );
                    raise ( sig );
                    break;
                }
                else
                {
                    bFirst = 0;
                    if ( sig == SIGABRT )
                    {
                        signal ( sig, SIG_IGN );
                    }

                    cmnCallStack ( sig );
                }

                signal ( sig, SIG_DFL );
                raise ( sig );
                break;
            }

            default:
                // 모르는게 들어왔다. 죽자.
                _DASSERT( 0 );
                break;
        }
    }
    _CATCH
    _FINALLY
    {
        // 도달하지 않는다.
        _DASSERT( 0 );
        _cmn_signo = 0;
    }
    _ENDVOID
}

/**
 * @TODO
 *  원래는 _dbm_main CONSTRUCT에서 변수 셋팅이 되어야 하나 컴파일러 4.7 이상에서만 동작함.
 *  이 부분은 정책결정에 따라 없애아할 듯
 *  그래도 일단 남겨두는 이유는 우리가 argc, argv를 가로챌수 있으면 할수 있는게 많아지기 때문임.
 *
 *  그래서 4.4 컴파일러에서 임시로 사용가능한 아래 함수를 열어두가, 사용해보고 나서, 장단에 대한 의견을 모으고자 함.
 */
_VOID _dbm_setArg ( int* pArgc, char** ppArgv )
{
    _TRY
    {
        if ( _dbm_argv != NULL )
        {
            _PRT ( "[임시구현] _dbm_argc, _dbm_argv already initialized." );
            _THROW ( -1 );
        }

        _dbm_argc = *pArgc;
        _dbm_argv = (const char**)ppArgv;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/*
 * @return
 *      원래는 char* 가 아니고 const char* 로 리턴하는게 맞다. 그러나, 사용성에서 불편해서
 *      getenv() 처럼 그냥 char* 로 변경.
 */
static char* _dbm_getArg_ ( const char* name )
{
    int     i;
    char    sName[32];
    int     sLen;
    int     sWithVal = 0;

    _TRY
    {
        if ( _dbm_argv == NULL )
            _THROW ( -1 );

        if ( name == NULL )
            return NULL;

        _DASSERT ( _dbm_argc > 0 );                     // gcc 4.7 이하에서는 쓰레기값.
        _DASSERT ( name != NULL && strlen_s(name) != 0 );

        cmnStrCpy ( sName, name, sizeof( sName ) );
        sLen = strlen_s ( sName );

        //  Character ':' 처리
        //      ':' 로 끝나면 value 값 있음
        //      ':' 로 끝나지 않으면  value 값 없음.
        //--------------------------------------------------------------
        // 검색 문자열이 ':' 포함으로 들어오면 "-key val" 을 검색하는 것이고 아니면 "-key" 유무를 검색
        if (sName[sLen-1] == ':')
        {
            sLen--;
            sName[sLen] = 0;
            sWithVal = 1;
        }

        for ( i = 1; i<_dbm_argc; i++ )
        {
            if ( _dbm_argv[i][0] != '-' || _dbm_argv[i][1] != sName[0] ) // 성능을 위해 앞에 1 byte 검사
                continue;

            if ( strcmp_s ( _dbm_argv[i] + 1, sName ) != 0 )
                continue;
            // 여기까지 오면 "-key"를 찾은 것임.

            // "-key" 유무만 체크하는 경우 자신을 리턴
            if ( sWithVal == 0 )
                return (char*)_dbm_argv[i];

            // "-key val" 순서가 아닌 경우 (오류)
            if ( i + 1  >= _dbm_argc || _dbm_argv[i+1][0] == '-')
                return NULL;

            return (char*)_dbm_argv[i+1];
        }

        return NULL;
    }
    _CATCH
    _FINALLY
    _ENDNULL
}

char* _dbm_getArg ( const char* name, const char* long_name )
{
    char    sName[32] = { '-', };
    char*   pChar = NULL;

    pChar = _dbm_getArg_( name );
    if ( pChar == NULL && long_name != NULL )
    {
        cmnStrCpy( &sName[1], long_name, strlen_s(long_name) + 1 );
        pChar = _dbm_getArg_( sName );
    }

    return pChar;
}


_VOID _dbm_sig_init ( )
{
    _TRY
    {
        _TEST_THROW( SIG_ERR != signal( SIGINT  , _dbm_sigHandler ), -1 ); // 공통에서 막으면 metaMgr 등에서 Ctrl+C 안됨
        _TEST_THROW( SIG_ERR != signal( SIGTERM , _dbm_sigHandler ), -1 );
//      _TEST_THROW( SIG_ERR != signal( SIGKILL , _dbm_sigHandler ), -1 ); // 불가능.
//      _TEST_THROW( SIG_ERR != signal( SIGSTOP , _dbm_sigHandler ), -1 ); // 불가능.

        _TEST_THROW( SIG_ERR != signal( SIGABRT , _dbm_sigHandler ), -1 );
        _TEST_THROW( SIG_ERR != signal( SIGSEGV , _dbm_sigHandler ), -1 );

#ifdef __linux__
        _TEST_THROW( SIG_ERR != signal( SIGBUS  , _dbm_sigHandler ), -1 );
#endif
        _TEST_THROW( SIG_ERR != signal( SIGILL  , _dbm_sigHandler ), -1 );
        _TEST_THROW( SIG_ERR != signal( SIGFPE  , _dbm_sigHandler ), -1 );

        /**********************************
         * 읽다가 Broken날 수있으니 SIGPIPE는 무시
         **********************************/
        /**
         * 2014.12.14. -okt- SIGPIPE 를 일부만 막을 수도 있다. 전체를 막았을때 부작용은?
         * send ( fd, buf, len, MSG_NOSIGNAL );
         */
        //signal ( SIGPIPE, SIG_IGN );
        // odiff 처럼 fork 혹은 system(..)을 사용하는 모듈에서는 결과같을 얻기 위해 SIGCHLD를 받아야한다.
        //signal ( SIGCHLD, SIG_IGN );

        // 2014.11.24 -okt- SUNDB와 시그널 처리 맞춘다.
        signal ( SIGTSTP, SIG_IGN ); // Ctrl + 'Z'
        signal ( SIGPIPE, SIG_IGN ); // 소켓 send 나, 스크립트에서 파이프('|') 처리시 발생가능
    }
    _CATCH
    {
        // 이 구간에서는 로그를 찍을 수 없다. 화면 출력한다.
        _CATCH_PRT;
    }
    _FINALLY
    _END
}

/*
 * NUMA 설정을 위한 장비 정보를 조회 ( nmon 참고 )
 */

#define CPU_DIE_NUM     16  // vbox에서 정보가 이상해서.
#define CORE_PER_CPU    16
#define THR_PER_CORE    2   // x86 은 현재 2개, vbox에서는 1일수있다.

typedef struct cpu_one
{
    int     processor;      // os 측면에서 논리 cpu 번호
    int     core_id;        // cpu 소켓 내에서 0 ~ n 까지 번호.
    int     physical_id;    // 동일하면 cpu socket 이 동일함
    int     online;         // 미사용, 혹시 root 에서 schedule 에서 빼놓은 CPU 일수도 있다.
} cpu_one;

typedef struct cpu_info
{
    cpu_one cpu[ CPU_DIE_NUM * CORE_PER_CPU * THR_PER_CORE ];
    int     cpu_die_num ;   // 소켓수
    int     core_per_cpu;   // CPU 소켓당 코어수
    int     thr_per_core;   // HyperThread 수
    int     ncpu;           // HyperThread 수
} cpu_info;

cpu_info    _cmn_cpu;

/*
 * 관련 파일
 *      /sys/devices/system/cpu/online
 *      /proc/cpuinfo
 */
_VOID _dbm_cpuinfo ( int aFlag )
{
    FILE*   pop;
    char    sDel[] = ":";
    char    sBuf[4096];
    char*   sTemp;
    int     sLen;
    int     i;

    _TRY
    {
        memset_s( &_cmn_cpu, 0x00, sizeof(cpu_info) );

        pop = popen ( "/bin/cat /proc/cpuinfo 2>/dev/null", "r" );
        if ( pop == NULL )
        {
            _PRT( "/proc/cpuinfo open fail. (err=%d,tid=%d)\n", errno, gettid_s() );
        }
        else
        {
            int     x;
            int     ix = -1;
            // 쭉 읽으면 processor 번호 순서로 읽힐 것이다. physical_id 순서는 섞일수도 있다.
            for ( i = 0; i < 2048 && ( fgets ( sBuf, sizeof(sBuf), pop ) != NULL ); i++ )
            {
                /* 2048=sanity check only */
                sLen = strlen_s ( sBuf );
                if ( sLen > (int)sizeof(sBuf) )
                {
                    sLen = sizeof(sBuf);
                }

                if ( sBuf[sLen - 1] == '\n' ) /*strip off the newline */
                    sBuf[sLen - 1] = 0;

                // 1. '이름'을 찾는다.
                sTemp = strtok( sBuf, sDel );
                if ( sTemp == NULL )
                {
                    continue;
                }

//#define strcmp_tk(a,b)  strncmp( a, b, sizeof(b) - 1 )
#define strcmp_tk(a,b)  memcmp( a, b, sizeof(b) - 1 )

                // 2. 찾은 '이름'에 해당되는 값을 찾는다.
                if ( ! strcmp_tk( sTemp, "processor\t" ) )
                {
                    ix++;
                    _cmn_cpu.cpu[ix].processor = atoi ( strtok( NULL, sDel ) );
                }
                else if ( ! strcmp_tk( sTemp, "core id\t" ) )
                {
                    x = atoi ( strtok( NULL, sDel ) );
                    _cmn_cpu.cpu[ix].core_id = x;

                    if ( x == 0 )
                    {
                        _cmn_cpu.cpu_die_num++;

                        // "physical id : 2" 뒷쪽에 "core id"가 위치하므로 여기서 검사.
                        if ( _cmn_cpu.cpu[ix].physical_id == 0 )
                        {
                            _cmn_cpu.thr_per_core++;
                        }
                    }
                }
                else if ( ! strcmp_tk( sTemp, "physical id\t" ) )
                {
                    x = atoi ( strtok( NULL, sDel ) );
                    _cmn_cpu.cpu[ix].physical_id = x;
                }
                else
                {
                    //_PRT( "strtok=[%s]\n", sTemp );

                    if ( _cmn_cpu.core_per_cpu == 0 )
                    {
                        if ( ! strcmp_tk( sTemp, "cpu cores\t" ) )
                        {
                            _cmn_cpu.core_per_cpu = atoi ( strtok ( NULL, sDel ) );
                        }
                    }
                }
            } /* for */

            pclose ( pop );

#ifdef __linux__	//TODO: [OKT]  윈도포팅
            _cmn_cpu.cpu_die_num = _cmn_cpu.cpu_die_num / _cmn_cpu.thr_per_core;
            _cmn_cpu.ncpu = sysconf ( _SC_NPROCESSORS_ONLN );

            _DASSERT( ix + 1 == _cmn_cpu.ncpu ); // 오프라인된 CPU가 있으면 죽을 것임.
#else
            _cmn_cpu.cpu_die_num = 1;
            _cmn_cpu.ncpu = 8; // 하드코딩
#endif /* __linux__ */

            if ( aFlag != 0 )
            {
                int sNodePre = -1;
                for ( i = 0; i < _cmn_cpu.ncpu; i++ )
                {
                    if ( sNodePre != _cmn_cpu.cpu[i].physical_id )
                    {
                        _PRT( "\n" );
                    }

                    if ( i == 0 )
                    {
                        _PRT( "\t # of socket\t: %d\n", _cmn_cpu.cpu_die_num );
                        _PRT( "\t core_per_cpu\t: %d\n", _cmn_cpu.core_per_cpu );
                        _PRT( "\t thr_per_core\t: %d\n", _cmn_cpu.thr_per_core );
                        _PRT( "\n" );
                    }

                    _PRT( "\t processor (%2d), core_id (%d), physical_id (%d)\n",
                          _cmn_cpu.cpu[i].processor, _cmn_cpu.cpu[i].core_id, _cmn_cpu.cpu[i].physical_id );

                    sNodePre = _cmn_cpu.cpu[i].physical_id;
                }
                //_EXIT(1);
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


_VOID _dbm_config_init ()
{
    char*   pChar;

    _TRY
    {
#ifdef __linux__	//TODO: [OKT]  윈도포팅
    	_cmn_sys_pagesize      = sysconf(_SC_PAGE_SIZE);
        _cmn_sys_physmemsize   = sysconf(_SC_PHYS_PAGES) * _cmn_sys_pagesize;     // 시스템 메모리의 전체 페이지 갯수를 리턴
        _cmn_sys_avphysmemsize = sysconf(_SC_AVPHYS_PAGES) * _cmn_sys_pagesize;   // 사용가능한 물리 메모리 용량을 리턴

        _cmn_sys_ncpu = sysconf( _SC_NPROCESSORS_ONLN ) / 2 ; // SMT가 켜저있다고 보고 나누기 2

        pChar = getenv ( "_" );
        if ( pChar != NULL )
        {
            cmnStrCpy( _cmn_cmd_name, basename ( pChar ), sizeof(_cmn_cmd_name) );
        }
        else
        {
            // unknown 으로 설정안하고, $USER로.
            cmnStrCpy( _cmn_cmd_name, getenv ( "USER" ), sizeof(_cmn_cmd_name) );
        }

        _CALL( _dbm_cpuinfo ( ) );
#else
        // warning: integer overflow in expression [-Woverflow]
    	_cmn_sys_pagesize      = 4096;
        _cmn_sys_physmemsize   = 32 * 1024 * 1024 * 1024LL;
        _cmn_sys_avphysmemsize = 16 * 1024 * 1024 * 1024LL;
        _cmn_sys_ncpu = 4;

        cmnStrCpy( _cmn_cmd_name, getenv ( "USERNAME" ), sizeof(_cmn_cmd_name) );
        //_CALL( _dbm_cpuinfo ( ) );
#endif /* __linux__ */
    }
    _CATCH
    {
        _CATCH_PRT;
    }
    _FINALLY
    _END
}


_VOID _dbm_err_init ()
{
    return cmnErrorManager::init ( );
}


/*
 * 2014.11.24 -okt-
 * 통상적으로 2 소켓이상에서 (혹은 1소켓이더라도 Busy Polling이 필요한 극한상황에서) 효과가 있으며,
 *
 * 1. CPU 지정 ( core 별, 혹은 numa node 별 ) - 이건 선호지정은 불가하며, 그냥 고정으로 알고 있음.
 * 2. 메모리 지정, 이건 선호지정이 가능함.
 * 3. HugePage 메모리 지정
 * 4. 네트웍 (NIC) , 혹은 SCSI 카드 위치 등에 따른 배치, PCI Controller 도 CPU에 내장임. (요즘은)
 * 5. 꺼꾸로 아무런 지정을 하지 않고, 테이블을 생성할때, 메모리 위치를 지정하면 최고일 수도 있음, OS가 많이 똑똑해진 느낌.
 * 6. (참고) 이거 설정할때, /proc/interrupts 도 참고 ( 효과 직접 본 적은 없음 )
 *
 * 이런식인데.. 사실 해당업무 장비 잡고 손으로 하는게 최고임. 쩝;
 */
#ifdef __linux__	//TODO: [OKT]  윈도포팅

_VOID _dbm_numa_init ( int aNumaNode )
{
    cpu_set_t* sCpuSet;
    size_t  sSize;
    int     sCpuNum = _cmn_cpu.ncpu;
    char    sDel[] = ",";
    char*   pChar = NULL;
    char    sBuf[4096];
    char*   sTemp = NULL;
    int     sCpu[ CPU_DIE_NUM * CORE_PER_CPU * THR_PER_CORE ];
    int     sCpuX[ 8 ];                 // 이중화 전용 CPU, 3개면 충분.
    int     sTokCnt = 0;
    int     sTokCntX = 0;
    int     i;
    int     x;


    _TRY
    {
        _DASSERT( _cmn_cmd_name[0] != 0x00 ); // 앞단에서 호출되어 있어야한다.
        memset_s ( sCpu, -1, sizeof(sCpu) );

        if ( ! strcmp_tk( _cmn_cmd_name, "olsnr" ) )
        {
            pChar = getenv( ENV_DBM_NUMA_SET_CS );
        }
        /*
         * dbmImp 를 굳이 따로 설정을 빼는 것은, 이것으로 인해서. 테이블 초기데이타의 메모리 위치를
         * 결정가능할 것으로 보기 때문임.
         */
        else if ( ! strcmp_tk( _cmn_cmd_name, "dbmImp" ) )
        {
            pChar = getenv( ENV_DBM_NUMA_SET_IMP );
        }
        else if ( ! strcmp_tk( _cmn_cmd_name, "dbmReplSender" ) )
        {
            pChar = getenv( ENV_DBM_NUMA_SET_REPL_SEND );
        }
        else if ( ! strcmp_tk( _cmn_cmd_name, "dbmReplReceiver" ) )
        {
            pChar = getenv( ENV_DBM_NUMA_SET_REPL_RECV );
        }
        /*
         * metaManager 는 운영중 가끔 들어가는데. 이 때문에 성능이 튈 수 있다.
         * 이를 CPU를 0번 (안사용한다면)에 고정하여 느리게하면, 좀더 쾌적한 운영이 가능할지도.
         */
        else if ( ! strcmp_tk( _cmn_cmd_name, "metaManager" ) )
        {
            pChar = getenv( ENV_DBM_NUMA_SET_MSQL );
        }

        if ( aNumaNode == -1 ) // 사용자가 C 소스에서 직접 지정하는 경우
        {
            if ( pChar == NULL )
            {
                pChar = getenv( ENV_DBM_NUMA_SET ); // 디폴트, 이것도 없으면 배치않함.
            }
        }

        if ( pChar != NULL )
        {
            // [주의] 복사를 해서 사용하지 않고, pChar 를 직접 사용하면, getenv 내부 버퍼가 깨진다.
            cmnStrCpy( sBuf, pChar, sizeof(sBuf) );

            sTemp = strtok( sBuf, sDel );
            for ( i = 0; sTemp != NULL; i++ )
            {
                sCpu[i] = atoi( sTemp );
                sTemp = strtok( NULL, sDel );
            }
            sTokCnt = i;
        }

        // 이중화가 사용하는 CPU를 대상에서 제외한다.
        {
            pChar = getenv( ENV_DBM_NUMA_SET_REPL_SEND );
            if ( pChar != NULL )
            {
                cmnStrCpy( sBuf, pChar, sizeof(sBuf) );

                sTemp = strtok( sBuf, sDel );
                for ( i = 0; sTemp != NULL; i++ )
                {
                    sCpuX[i] = atoi( sTemp );
                    sTemp = strtok( NULL, sDel );
                }
                sTokCntX = i;
            }

            pChar = getenv( ENV_DBM_NUMA_SET_REPL_RECV );
            if ( pChar != NULL )
            {
                cmnStrCpy( sBuf, pChar, sizeof(sBuf) );

                sTemp = strtok( sBuf, sDel );
                for ( i = sTokCntX; sTemp != NULL; i++ )
                {
                    sCpuX[i] = atoi( sTemp );
                    sTemp = strtok( NULL, sDel );
                }
                sTokCntX = i;
            }
        }

        //TODO: 2014.11.24 -okt- (새기능) 외부에서 사용자가 강제로 taskset 같은 것으로 지정했으면 그게 먹어야한다.
        // 해야함. 그런데 0번 core 하나에만 고정이면 예외적으로 무시할까?

        //TODO: 환경변수 없으면 조건 추가.
//        if ( 0x01 && sTokCnt == 0 )
//        {
//            _RETURN;    //TODO: 2014.11.24 -okt- 막으면 2소켓에서 자동배치가 활성화됨.
//
//            // 너무 적은 개수면 자동 배치 안한다.
//            //if ( _cmn_cpu.ncpu <= 4 ) _RETURN;
//
//            // (1) NUMA 장비아니면 배치하지 말자.
//            // (2) 4U 장비를 자동 배치하기는 어렵다. (설정으로만)
//            if ( _cmn_cpu.cpu_die_num != 2 ) _RETURN;
//        }

        sCpuSet = CPU_ALLOC( sCpuNum );
        if ( sCpuSet == NULL )
        {
            _THROW ( -1 );
        }

        sSize = CPU_ALLOC_SIZE( sCpuNum );
        CPU_ZERO_S( sSize, sCpuSet );

        if ( sTokCnt > 0 ) // 수동배치
        {
            for ( i = 0; i < sTokCnt; i++ )
            {
                for ( x = 0; x < sCpuNum; x++ )
                {
                    if ( sCpu[i] == x )
                    {
                        CPU_SET_S( x, sSize, sCpuSet );
                        break;
                    }
                }
                _DASSERT( x != sCpuNum ); // 설정받은 값이 범위에 없다.
            }
        }
        else if ( aNumaNode != -1
                || getenv( ENV_DBM_NUMA_NODE ) != NULL
                || getenv( ENV_DBM_LATENCY ) != NULL    // 현재는 위의 설정과 동일하나, 우리가 뭘하는지 안보여줄려고 할때.
                ) // 자동배치
        {
            if ( _cmn_cpu.cpu_die_num == 1 || /* vbox */ _cmn_cpu.core_per_cpu == 1 )
            {
                /*
                 * 여기에 진입하면 통상적으로 성능이 더 느려질 것이다.
                 * 그러나, 다른 모든 task 프로세스 ( sshd 등 )을 0번 CPU에 배치한 상황에서는 장점이 있을거다.
                 */
                //for ( x = 0; x < sCpuNum; x++ )
                for ( x = 1; x < sCpuNum; x++ ) // 0번 빼고 배치
                {
                    CPU_SET_S( x, sSize, sCpuSet );
                    //DBM_ECHO( "cpu_set = %d", x );
                }
            }
            else if ( _cmn_cpu.cpu_die_num == 2 )
            {
                int sNodeNo = 1;

                if ( aNumaNode == -1 )
                {
                    pChar = getenv( ENV_DBM_NUMA_NODE );
                    if ( pChar == NULL )
                    {
                        pChar = getenv( ENV_DBM_LATENCY );
                    }
                    if ( atoi(pChar) <= _cmn_cpu.cpu_die_num - 1 )
                    {
                        sNodeNo = atoi(pChar);
                    }
                }
                else
                {
                    sNodeNo = aNumaNode;
                }

                //TODO: 2014.11.24 -okt- 이중화 설정이 있으면, 이중화 쪽 CPU는 빼야한다.
                // 해야함.

                for ( x = 0; x < sCpuNum; x++ )
                {
                    // 이중화가 예약하여, 제외할 CPU 검사
                    for ( int k = 0; k < sTokCntX; k++ )
                    {
                        //if ( _cmn_cpu.cpu[x].processor == sCpuX[k] )
                        if ( x == sCpuX[k] ) // 동일함.
                        {
                            continue;
                        }
                    }

                    /*
                     * 1번 소켓에 NIC 혹은 디스크가 물려있다고 보고 (경우의수가 높으므로)
                     * 2번 소켓으로 CPU를 사용한다. ( 오히려 1번이 나을지도 ㅠㅠ )
                     *
                     * 그러나. numa node 당 메모리 량을 보고 결정하는 것도.. 있으면 좋겠다.
                     */
                    if ( _cmn_cpu.cpu[x].physical_id == sNodeNo )
                    {
                        CPU_SET_S( x, sSize, sCpuSet );
                        //DBM_ECHO( "cpu_set = %d", x );
                    }
                }
            }
            else
            {
                //_DASSERT( 0 ); // 미구현, 죽을까.
            }
        }
        else
        {
            // 설정이 없다. 빠져나간다.
            _RETURN;
        }

        _CALL ( cmnSetCpuAffinity ( pthread_self_s(), sCpuSet ) );
    }
    _CATCH
    {
#ifdef _DEBUG
        _CATCH_PRT;
#endif
    }
    _FINALLY
    _END
}

#else
_VOID _dbm_numa_init ( int aNumaNode )
{
	return 0;
}
    // TODO: [OKT]  윈도포팅
#endif /* __linux__ */



_VOID _dbm_mem_init ()
{
#ifdef __linux__	//TODO: [OKT]  윈도포팅
	return cmnMemManager::init ( );
#else
	return 0;
#endif /* __linux__ */
}

_VOID _dbm_log_init ()
{
    return cmnLogManager::init ( );
}


_VOID _dbm_timer_init ()
{
    return cmnTimerManager::init ( );
}

//#undef _OKT_TIMER
#ifdef _OKT_TIMER
static _VOID _dbm_timer_test ( void* arg )
{
    static int sCallCnt = 0;

    _TRY
    {
        if ( arg != NULL ) _DASSERT(0);  // dummy for no-build-warning

        DBM_ECHO ( "[TIMER] (1) user callback Start (%d)\n", ++sCallCnt );
    }
    _CATCH
    {
        _CATCH_PRT;
    }
    _FINALLY
    _END
}

//static _VOID _dbm_timer_test2 ( void* arg )
//{
//    static int sCallCnt2 = 0;
//
//    _TRY
//    {
//        if ( arg != NULL ) _DASSERT(0);  // dummy for no-build-warning
//
//        DBM_ECHO ( "[TIMER] (2) user callback Start (%d)\n", ++sCallCnt2 );
//    }
//    _CATCH
//    {
//        _CATCH_PRT;
//    }
//    _FINALLY
//    _END
//}
#endif


#include "cmnMonitor.h"


// 2014.12.14. -okt- 정식구현되면 dbmDefine.h 으로 이동
#define ENV_DBM_TIMER_ON                "_DBM_TIMER_ON"     /* for monitoring */


_VOID _dbm_test ()
{
    _TRY
    {
        if ( cmnTimerManager::instance == NULL )
            _RETURN;

#ifdef _OKT_TIMER
        int     timerid;

        // 2014.12.14. -okt-  '_' 로 시작되는 환경변수는 임시성, 혹은 내부용이다. ex) _DBM_TIMER_ON
        char* pEnv = getenv ( ENV_DBM_TIMER_ON );
        if ( pEnv != NULL )
        {
            _CALL ( cmnTimerAdd ( 100, _dbm_timer_test, &timerid ) );
//            _CALL ( cmnTimerAdd ( 1000, _dbm_timer_test2, &timerid ) );
//            _CALL ( cmnTimerAdd ( 100, _dbm_monitor_cb, &timerid ) );

            /**
             * [no-main testcase]
             * touch x.cpp
             * g++ x.cpp -nostartfiles -L$DBM_HOME/lib/debug -ldbm
             * $ gdb a.out
             * (gdb) b _dbm_main
             *
             */
            DBM_ECHO ( ">> _dbm_test End. Normal exit at 10 sec\n" );
            sleep ( 10 );
            exit ( 0 );
        }
#endif
    }
    _CATCH
    {
        _CATCH_PRT;
    }
    _FINALLY
    _END
}
