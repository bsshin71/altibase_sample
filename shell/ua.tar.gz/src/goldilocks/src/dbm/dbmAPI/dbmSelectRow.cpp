/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *     Error Message Management Class
 *******************************************************************************/
#include "dbmHeader.h"
#include "dbmInternalHandle.h"

__thread long long gSeqStat = -1;

extern _VOID dbmExecRowLib ( dbmHandle*   aHandle,
                             const char*  aTable,
                             void*        aUserData,
                             int          aTransType,
                             int          aQSizeOrTimeOut = -99,
                             int          aEQCnt = 0 ,
                             int*         aCount = NULL,
                             long long*   aSeq = NULL,
                             void*        aUserData2 = NULL );

extern _VOID dbmRemoteExecRowLib ( dbmHandle*    aHandle,
                                   const char*   aTable,
                                   void*         aUserData,
                                   int           aTransType,
                                   int           aQSizeOrTimeOut = -99,
                                   int           aEQCnt = 0,
                                   int*          aCount = NULL,
                                   long long*    aSeq = NULL,
                                   void*         aUserData2 = NULL );

/*
extern _VOID dbmExecInternalLib ( dbmHandle*      aHandle,
                                const char*     aTable,
                                void*           aData,
                                void*           aDataTwo,
                                int             aTransType,
                                int*            aCount = NULL,
                                long long*      aSeq   = NULL );
                                */

/********************************************************************
 * ID : dbmExecExternLib (USER 공통함수)
 ********************************************************************/
__thread char* g_dbmExecInternalLib_aData = NULL; // #845 FTS 시에 사용할 버퍼.
_VOID dbmExecInternalLib ( dbmHandle*      aHandle,
                           const char*     aTable,
                           void*           aData,
                           void*           aDataTwo,
                           int             aTransType,
                           int*            aCount,
                           long long*      aSeq )
{
    dbmInternalHandle*  pHandle         = NULL;
    dbmColumnObject*    sDicColObj      = NULL;
    dbmTableInfo*       sDicTBLInfo     = NULL;
    dbmIndexObject*     sDicIDXObj;
    void*   sData;
    char    sTmpData[DBM_MAX_RECORD_SIZE];
    int     sCount = 0;
    int     sCheck = 0;
    int     sRC;
    int     sSeq   = 0;
    int     i;
    int     sSize  = 0;

    _TRY
    {
        _DASSERT( aHandle != NULL );
        _DASSERT( aTable != NULL );
        //_DASSERT( aData != NULL );        // FTS일때 가능하다.
        //_DASSERT( aDataTwo != NULL );     // BT에서만
        //_DASSERT( aCount != NULL );       // Count에서만

        /****************************************
         * 내부 변수로 맵핑
        ****************************************/
        pHandle = (dbmInternalHandle*)aHandle->mHandle;

        //if ( strlen_s( (char*)aData ) == 0 )
        if ( unlikely( aData == NULL ) )
        {
            if ( g_dbmExecInternalLib_aData == NULL )
            {
                g_dbmExecInternalLib_aData = (char*)malloc( DBM_MAX_RECORD_SIZE );
            }

            /*
             * #845 aData에 NULL 포인트가 입력되면, FTS 처리한다.
             * column min set :
             * 사용자가 null 값으로 값을 주었다면 min value로 기준으로 count를 구한다
             */
            sCheck = 1;

            sData = g_dbmExecInternalLib_aData;
        }
        else
        {
            sData = aData;
        }

        /* data check :
         * DBM_SELECT_COUNT_BT type에 대하여 aDataTwo value가 null이면 오류 */
        if ( ( aTransType == DBM_SELECT_COUNT_BT || aTransType == DBM_SELECT_COUNT_BT_DIRTY || aTransType == DBM_UPDATE_RANGE_BT || aTransType == DBM_DELETE_RANGE_BT )
                && ( strlen_s((char*)aDataTwo) == 0 || strlen_s((char*)sData) == 0 ) )
        {
            _DASSERT( aDataTwo != NULL );
            _THROW( ERR_DBM_INVALID_DATA_NULL );
        }

        if( aTransType != DBM_SEQ_NEXTVAL && aTransType != DBM_SEQ_CURRVAL )
        {
            _CALL( dbmExecDic ( pHandle, aTable, sData, &sDicIDXObj, &sDicTBLInfo, sCheck, NULL, (int*)0, aHandle ) );
        }

        /* 2015.07.23 -shw- */
        /* Range BT, LT 관련 되서 해당 Type을 Data Object에서 구분하여 처리를
         * 하기 위하여 해당 Trans Type 이면 mLogCheck Value 1값을 채워 구분하도록
         * 한다 */
        if ( aTransType == DBM_UPDATE_RANGE_GT || aTransType == DBM_UPDATE_RANGE_LT ||
             aTransType == DBM_UPDATE_RANGE_BT || aTransType == DBM_DELETE_RANGE_GT ||
             aTransType == DBM_DELETE_RANGE_LT || aTransType == DBM_DELETE_RANGE_BT )
        {
            pHandle->mData.mLogCheck = 1;
            pHandle->mData.mFirstLogCheck = 1;
        }

        /* updaet 처리 시 필요한 array variable */
        /* offset 만큼 처리 하므로 초기화 필요 없음 */
        //char sTmpData[sDicTBLInfo->mTable.mRecordSize];

        /* update & delete data value check */
        if ( aTransType == DBM_UPDATE_RANGE_GT ||
            aTransType == DBM_UPDATE_RANGE_LT ||
            aTransType == DBM_UPDATE_RANGE_BT ||
            aTransType == DBM_DELETE_RANGE_GT ||
            aTransType == DBM_DELETE_RANGE_LT ||
            aTransType == DBM_DELETE_RANGE_BT )
        {
            /* update 처리 이면 updaet 적용 data copy해 놓는다 */
            if ( aTransType == DBM_UPDATE_RANGE_GT ||
                aTransType == DBM_UPDATE_RANGE_LT  ||
                aTransType == DBM_UPDATE_RANGE_BT )
            {
                //char sTmpData[sDicTBLInfo->mTable.mRecordSize];

                memcpy_s(sTmpData, sData, sDicTBLInfo->mTable.mRecordSize);
            }

        }

        switch( aTransType )
        {
            case DBM_UPDATE_RANGE_GT:

                /* select GT :
                 * update 하려는 data가 있는지 검색 한다 */
                _CALL( dbmSelectRowGT( aHandle, aTable, sData ) );

                /* update :
                 * data가 있다고 하니 update 처리 한다 */
                while(1)
                {
                    /* key 값을 제외하고 처리 하려는 놈을 buffer에 copy 한다 */
                    _CALL( dbmExecUpdate( sData, sTmpData, sDicTBLInfo, sDicIDXObj ) );

                    /* data sTmpData copy 하였으니 다시 가져와자 */
                    memcpy_s(sData, sTmpData, sDicTBLInfo->mTable.mRecordSize);

                    _CALL( dbmUpdateRow( aHandle, aTable, sData ) );

                    pHandle->mData.mFirstLogCheck = -1;

                    /* update check:
                     * update data가 좀더 있는지 Gt를 이용하여 체크해 본다 */
                    sRC = dbmSelectRowGT( aHandle, aTable, sData );
                    if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        break;
                    }
                    _IF_THROW(sRC,sRC);
                }

                break;

            case DBM_UPDATE_RANGE_LT:

                /* select LT :
                 * update 하려는 data가 있는지 검색 한다 */
                _CALL( dbmSelectRowLT( aHandle, aTable, sData ) );

                /* update :
                 * data가 있다고 하니 update 처리 한다 */
                while(1)
                {
                    /* key 값을 제외하고 처리 하려는 놈을 buffer에 copy 한다 */
                    _CALL( dbmExecUpdate( sData, sTmpData, sDicTBLInfo, sDicIDXObj ) );


                    /* data sTmpData copy 하였으니 다시 가져와자 */
                    memcpy_s(sData, sTmpData, sDicTBLInfo->mTable.mRecordSize);

                    _CALL( dbmUpdateRow( aHandle, aTable, sData ) );

                    pHandle->mData.mFirstLogCheck = -1;

                    /* update check:
                     * update data가 좀더 있는지 Gt를 이용하여 체크해 본다 */
                    sRC = dbmSelectRowLT( aHandle, aTable, sData );
                    if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        break;
                    }
                    _IF_THROW(sRC,sRC);
                }

                break;

            case DBM_UPDATE_RANGE_BT:

                /* select BT :
                 * update 하려는 data가 있는지 검색 한다 */
                _CALL( dbmSelectRow( aHandle, aTable, sData ) );

                /* update :
                 * data가 있다고 하니 update 처리 한다 */
                while(1)
                {
                    sRC = dbmExecDataCheck( sData, aDataTwo, sDicIDXObj);
                    /* data가 큰놈이 왔으니 빠져 나와자 */
                    if ( sRC == RC_FAILURE)
                    {
                        break;
                    }

                    /* key 값을 제외하고 처리 하려는 놈을 buffer에 copy 한다 */
                    _CALL( dbmExecUpdate( sData, sTmpData, sDicTBLInfo, sDicIDXObj ) );

                    /* data sTmpData copy 하였으니 다시 가져와자 */
                    memcpy_s(sData, sTmpData, sDicTBLInfo->mTable.mRecordSize);


                    _CALL( dbmUpdateRow( aHandle, aTable, sData ) );

                    pHandle->mData.mFirstLogCheck = -1;

                    /* update check:
                     * update data가 좀더 있는지 Gt를 이용하여 체크해 본다 */
                    sRC = dbmSelectRowGT( aHandle, aTable, sData );
                    if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        break;
                    }
                    _IF_THROW(sRC,sRC);
                }

                break;

            case DBM_DELETE_RANGE_GT:

                /* select GT :
                 * delete 하려는 data가 있는지 검색 한다 */
                _CALL( dbmSelectRowGT( aHandle, aTable, sData ) );

                /* delete :
                 * data가 있다고 하니 delete 처리 한다 */
                //int tmp = 0;
                while(1)
                {
                    _CALL( dbmDeleteRow( aHandle, aTable, sData ) );
                    pHandle->mData.mFirstLogCheck = -1;

                    /* delete check:
                     * delete data가 좀더 있는지 Gt를 이용하여 체크해 본다 */
                    sRC = dbmSelectRowGT( aHandle, aTable, sData );
                    if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        break;
                    }
                    _IF_THROW(sRC,sRC);
                }

                break;

            case DBM_DELETE_RANGE_LT:

                /* select LT :
                 * delete 하려는 data가 있는지 검색 한다 */
                _CALL( dbmSelectRowLT( aHandle, aTable, sData ) );

                /* delete :
                 * data가 있다고 하니 delete 처리 한다 */
                while(1)
                {
                    _CALL( dbmDeleteRow( aHandle, aTable, sData ) );

                    pHandle->mData.mFirstLogCheck = -1;

                    /* delete check:
                     * delete data가 좀더 있는지 Gt를 이용하여 체크해 본다 */
                    sRC = dbmSelectRowLT( aHandle, aTable, sData );
                    if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        break;
                    }
                    _IF_THROW(sRC,sRC);
                }

                break;

            case DBM_DELETE_RANGE_BT:

                /* select BT :
                 * delete 하려는 data가 있는지 검색 한다 */
                _CALL( dbmSelectRow( aHandle, aTable, sData ) );

                /* delete :
                 * data가 있다고 하니 delete 처리 한다 */
                while(1)
                {
                    sRC = dbmExecDataCheck( sData, aDataTwo, sDicIDXObj);
                    /* data가 큰놈이 왔으니 빠져 나와자 */
                    if ( sRC == RC_FAILURE)
                    {
                        break;
                    }

                    _CALL( dbmDeleteRow( aHandle, aTable, sData ) );

                    pHandle->mData.mFirstLogCheck = -1;

                    /* delete check:
                     * delete data가 좀더 있는지 Gt를 이용하여 체크해 본다 */
                    sRC = dbmSelectRowGT( aHandle, aTable, sData );
                    if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        break;
                    }
                    _IF_THROW(sRC,sRC);
                }

                break;

            case DBM_SEQ_NEXTVAL:

                //DBM_SELECT_FOR_UPDATE
                // GT를 사용하면 안된다. lock를 잡고 commit 단계까기 기다려야
                // 하기 때문이다. 아.. bind data만들기 귀찮다. 어차피 sequence
                // 스키마는 고정 되어있으니 해당 값을로 점프한다. 욕하지 마삼.
                //sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_GT );
                //_IF_THROW( sRC != RC_SUCCESS, sRC );

                sSeq = 1;

                memcpy_s( (char*)sData + 36, &sSeq, sizeof(int) );

                sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_FOR_UPDATE );
                _IF_THROW( sRC != RC_SUCCESS, sRC );


                /* cycle no cycle check */
                if ( *(long*)(sData) >= *(long*)((char*)sData+16) )
                {
                    if( !memcmp_s ( (char*)sData + 32, "Y", 1 ) )
                    {
                        /* cycle 처리 */
                        /* cycle 처리니까 제일처음 minvalue값으로 돌아가야 한다 */
                        memcpy_s ( sData, (char*)sData+24, sizeof(long) );
                    }
                    else
                    {
                        /* no cycle 처리 */
                        _THROW(ERR_DBM_SEQ_NO_CYCLE_FAIL);
                    }
                }

                //*aSeq = *(long long*)(sData) + 1;
                *aSeq = *(long*)(sData) + *(int*)((char*)sData+sizeof(long));

                /* min value check */
                _IF_THROW ( *aSeq < *(long*)((char*)sData+24) , ERR_DBM_SEQ_MIN_VALUE_FAIL );

                memcpy_s ( sData, aSeq, sizeof(long long) );

                dbmExecRowLib ( aHandle, aTable, sData, DBM_UPDATE );
                _IF_THROW( sRC != RC_SUCCESS, sRC );

                /* nextval 처리 체크 */
                /* 함정 : commit 처리는 metaManager에서 마지막에 한다.
                 * 물론 내부적으로 commit 처리 하게 되어 있지만 장애나
                 * 기타 사항으로 commit 처리 가 되지 않았을 때에 gSeqStat
                 * 가 nextval 처리 된 session으로 보이므로 session이 끊어
                 * 지지 않았다면 currval하였을 때 현재 최대 값을 보여주지
                 * 못할 수도 있다 */
                gSeqStat = *aSeq;

                _CALL ( dbmCommit(aHandle) );

                break;

            case DBM_SEQ_CURRVAL:

                if ( gSeqStat == -1 )
                {
                    _THROW( ERR_DBM_SEQ_CURR_NOT_DEFIND );
                }

#if 0 // [성능] 조회할 필요가 없다. currval 현재 nextval 시점의 최고 값을 주면 된다.
                sSeq = 1;

                memcpy_s( sData+36, &sSeq, sizeof(int) );

                sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_FOR_UPDATE );
                _IF_THROW( sRC != RC_SUCCESS, sRC );

                *aSeq = *(long long*)(sData);
#endif
                *aSeq = gSeqStat;

                break;

            case DBM_SELECT_COUNT:
            case DBM_SELECT_COUNT_DIRTY:

                /* 조건값에 관련된 count value 출력 */
                if ( sCheck == 0 )
                {
                    if( aTransType == DBM_SELECT_COUNT )
                    {
                        sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT );
                    }
                    else
                    {
                        sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_DIRTY );
                    }
                    if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        *aCount = sCount;
                        break;
                    }
                    _IF_THROW( sRC != RC_SUCCESS, sRC);

#if 0
                    // bug-911에서와 같이 setindex와 상관없이 동작하기 때문에 실 데이터의 수를 세는 것으로 변경한다.
                    if ( sDicIDXObj->mIsUniqueIndex )
                    {
                        /* data가 있다는 것이나 한건 증가하자 */
                        sCount++;
                        *aCount = sCount;
                    }
                    else
                    {
                        while(true)
                        {
                            sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_FETCH );
                            if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                            {
                                *aCount = sCount;
                                break;
                            }
                            _IF_THROW( sRC != RC_SUCCESS, sRC);

                            sCount++;

                            *aCount = sCount;
                        }
                    }
#endif
                    while(true)
                    {
                        sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_FETCH );
                        if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                        {
                            *aCount = sCount;
                            break;
                        }
                        _IF_THROW( sRC != RC_SUCCESS, sRC);

                        sCount++;
                        *aCount = sCount;
                    }
                }
                else
                {
                    if( aTransType == DBM_SELECT_COUNT )
                    {
                        sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_GT );
                    }
                    else
                    {
                        sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_GT_DIRTY );
                    }
                    if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        *aCount = sCount;
                        break;
                    }

                    _IF_THROW( sRC != RC_SUCCESS, sRC );

                    while(true)
                    {
#if 0
                    // bug-911에서와 같이 setindex와 상관없이 동작하기 때문에 실 데이터의 수를 세는 것으로 변경한다.
                        if ( sDicIDXObj->mIsUniqueIndex )
                        {
                            /* data가 있다는 것이나 한건 증가하자 */
                            sCount++;
                            *aCount = sCount;

                            sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_GT );
                            if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                            {
                                break;
                            }

                            _IF_THROW( sRC != RC_SUCCESS, sRC);
                        }
                        else
                        {
                            sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_FETCH_NEXT_GT );
                            if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                            {
                                break;
                            }
                            _IF_THROW( sRC != RC_SUCCESS, sRC);

                            /* data가 있다는 것이나 한건 증가하자 */
                            sCount++;
                            *aCount = sCount;
                        }
#endif
                        /* data가 있다는 것이나 한건 증가하자 */
                        sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_FETCH_NEXT_GT );
                        if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                        {
                            break;
                        }
                        _IF_THROW( sRC != RC_SUCCESS, sRC);

                        sCount++;
                        *aCount = sCount;
                    }
                }

                break;

            case DBM_SELECT_COUNT_GT:
            case DBM_SELECT_COUNT_GT_DIRTY:

                if( aTransType == DBM_SELECT_COUNT_GT )
                {
                    sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_GT );
                }
                else
                {
                    sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_GT_DIRTY );
                }
                if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                {
                    *aCount = sCount;
                    break;
                }
                _IF_THROW( sRC != RC_SUCCESS, sRC);

                while(true)
                {
                    /* data가 있다는 것이나 한건 증가하자 */
                    sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_FETCH_NEXT_GT );
                    if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        break;
                    }
                    _IF_THROW( sRC != RC_SUCCESS, sRC);

                    sCount++;
                    *aCount = sCount;
                }

                break;

            case DBM_SELECT_COUNT_LT:
            case DBM_SELECT_COUNT_LT_DIRTY:

                if( aTransType == DBM_SELECT_COUNT_LT )
                {
                    sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_LT );
                }
                else
                {
                    sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_LT_DIRTY );
                }
                if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                {
                    *aCount = sCount;
                    break;
                }
                _IF_THROW( sRC != RC_SUCCESS, sRC);

                while(true)
                {

                    sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_FETCH_NEXT_LT );
                    if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        break;
                    }
                    _IF_THROW( sRC != RC_SUCCESS, sRC);

                    /* data가 있다는 것이나 한건 증가하자 */
                    sCount++;
                    *aCount = sCount;
                }

                break;

            case DBM_SELECT_COUNT_BT:
            case DBM_SELECT_COUNT_BT_DIRTY:

                if( aTransType == DBM_SELECT_COUNT_BT )
                {
                    sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT );
                }
                else
                {
                    sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_DIRTY );
                }
                if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                {
                    *aCount = sCount;
                    break;
                }
                _IF_THROW( sRC != RC_SUCCESS, sRC);

                while(true)
                {
                    sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_FETCH );
                    if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        *aCount = sCount;
                        break;
                    }
                    _IF_THROW( sRC != RC_SUCCESS, sRC);

                    sCount++;
                    *aCount = sCount;
                }

                if( aTransType == DBM_SELECT_COUNT_BT )
                {
                    sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_GT );
                }
                else
                {
                    sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_SELECT_GT_DIRTY );
                }
                if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                {
                    *aCount = sCount;
                    break;
                }

                while(true)
                {

                    sRC = dbmExecRowLib ( aHandle, aTable, sData, DBM_FETCH_NEXT_GT );
                    if ( sRC == ERR_DBM_NO_MATCH_RECORD )
                    {
                        break;
                    }
                    _IF_THROW( sRC != RC_SUCCESS, sRC);

                    sRC = dbmExecDataCheck( sData, aDataTwo, sDicIDXObj );
                    /* data가 큰놈이 왔으니 빠져 나와자 */
                    if ( sRC == RC_FAILURE)
                    {
                        break;
                    }

                    /* data가 있다는 것이나 한건 증가하자 */
                    sCount++;
                    *aCount = sCount;
                }

                break;

            dafault:
                _CALL(ERR_DBM_INVALID_DATATYPE);
                break;
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        pHandle->mData.mLogCheck = -1;
        pHandle->mData.mFirstLogCheck = -1;
    }
    _END
} /* dbmExecInternalLib */

_VOID dbmExecUpdateLib ( dbmHandle*      aHandle,
                         const char*     aTable,
                         void*           aData,
                         int             aTransType,
                         int*            aColBindCheck )
{
    char                sIndexName[DBM_NAME_LEN];
    char                sColunmName[DBM_MAX_COLUMN][DBM_NAME_LEN];
    int                 sFilterCount = 0;

    dbmInternalHandle*  pHandle         = NULL;
    dbmColumnObject*    sDicColObj      = NULL;
    dbmTableInfo*       sDicTBLInfo     = NULL;
    dbmIndexObject*     sDicIDXObj;

    _TRY
    {
        _DASSERT( aHandle != NULL );
        _DASSERT( aTable != NULL );
        _DASSERT( aData != NULL );

        /****************************************
         * 내부 변수로 맵핑
        ****************************************/
        pHandle = (dbmInternalHandle*)aHandle->mHandle;

        /* data check :
         * DBM_SELECT_COUNT_BT type에 대하여 aDataTwo value가 null이면 오류 */
        if ( aTransType != DBM_UPDATE )
        {
            _THROW( ERR_DBM_INVALID_DATA_NULL );
        }

        /* GetIndex :
         * index name 가지고 와서 해당 columnt bind 하기 위하여 현재 index name 가져온다 */
        //memset_s ( sIndexName, 0x00, DBM_NAME_LEN );
        /* memset을 해야 할까... 쓰레기 값이 들어 올수 있는데 memset size가 너무크다 */
        /* dbmExecDic 안에서 size만큼만 memeset 하자 */
        memset_s ( sColunmName, 0x00, sizeof(sColunmName) );
#if 0
        /* Table Type Check DirectTable, Sequenct Table 타지 말아야 한다 */
        /* sCheck 2: 지정된 Index로 해당 Dic info set */
        _CALL( dbmExecDic ( pHandle, aTable, sIndexName, &sDicIDXObj, &sDicTBLInfo, 3, sColunmName, &sFilterCount ) );
        if ( sFilterCount == -1 )
        {
            *aColBindCheck = 1;

            _RETURN;
        }
#endif

#if 0
        /* Index Name 구한다 */
        _CALL( dbmGetIndex ( aHandle, aTable, sIndexName ) );
#endif
        /* sCheck 2: 지정된 Index로 해당 Dic info set */
        _CALL( dbmExecDic ( pHandle, aTable, sIndexName, &sDicIDXObj, &sDicTBLInfo, 2, sColunmName, &sFilterCount, aHandle ) );
        //_CALL( dbmExecDic ( pHandle, aTable, sIndexName, &sDicIDXObj, &sDicTBLInfo, 2 ) );

        /* Table Type Check DirectTable, Sequenct Table 타지 말아야 한다 */
        if ( sFilterCount == -1 ) 
        {
            *aColBindCheck = 1; 

            _RETURN;
        }

        /* index가 하나이면 dbmRowUpdate 타도록 한다 */
        if ( sDicTBLInfo->mIndexCount <= 1 )
        {
            *aColBindCheck = 1;

            _RETURN;
        }
        /* BindCol 하여 Update 처리를 한다 */
        _CALL( dbmExecColBind ( aHandle, aTable, aData, sDicIDXObj, sDicTBLInfo, sColunmName, sFilterCount ) );


    }_CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END

} /* End of dbmExecInternalLib() */


/********************************************************************
 * ID : dbmExecRowLib (공통함수)
 ********************************************************************/
_VOID dbmExecRowLib ( dbmHandle*    aHandle,
                      const char*   aTable,
                      void*         aUserData,
                      int           aTransType,
                      int           aQSizeOrTimeOut,
                      int           aEQCnt,
                      int*          aCount,
                      long long*    aSeq,
                      void*         aUserData2 )
{
    dbmInternalHandle* pHandle = (dbmInternalHandle*)aHandle->mHandle;

    _TRY
    {
        /*
         * TODO: 2014.11.24. -okt- 시그널이 발생한 상태이다. 내부 critical section 으로 진입하지 말고 기다린다.
         */
        while ( unlikely ( _cmn_signo != 0 ) )
        {
            usleep( 1000 );
        }
        _cmn_signo_r = -1; // 임계영역 진입을 표시

#ifndef _DBM_PERF
        /****************************************
         * Water Mark가 다르면 걍 리턴해라.
        ****************************************/
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            DBM_ERR ( "invalide magic number (%ld)", aHandle->mMark );
            _THROW( ERR_DBM_INVALID_HANDLE );
        }

        if (
             (pHandle->mData.mSearchWay == DBM_SELECT_GT && aTransType == DBM_FETCH_NEXT_LT) ||
             (pHandle->mData.mSearchWay == DBM_SELECT_LT && aTransType == DBM_FETCH_NEXT_GT) ||
             (pHandle->mData.mSearchWay == DBM_SELECT_GT_DIRTY && aTransType == DBM_FETCH_NEXT_LT) ||
             (pHandle->mData.mSearchWay == DBM_SELECT_LT_DIRTY && aTransType == DBM_FETCH_NEXT_GT)
           )
        {
             _THROW( ERR_DBM_INVALID_SEARCH_WAY );
        }
#endif

        /****************************************
         * Remote Connection 일 경우 별도 처리한다.
        ****************************************/
        if ( unlikely ( pHandle->mRemote != NULL
#ifdef _DEBUG
                && pHandle->mRemote->mSockFd > 0
#endif
        ) )
        {
            _CALL( dbmRemoteExecRowLib( aHandle,
                                        aTable,
                                        aUserData,
                                        aTransType,
                                        aQSizeOrTimeOut,
                                        aEQCnt,
                                        aCount,
                                        aSeq,
                                        aUserData2 ) );
            _RETURN;
        }



        /****************************************
         * DBM_UPDATE_RANGE_GT 일 경우 별도 처리
        ****************************************/
        if( aTransType == DBM_UPDATE_RANGE_GT || aTransType == DBM_UPDATE_RANGE_LT
                || aTransType == DBM_UPDATE_RANGE_BT
                || aTransType == DBM_DELETE_RANGE_GT || aTransType == DBM_DELETE_RANGE_LT
                || aTransType == DBM_DELETE_RANGE_BT
                || aTransType == DBM_SELECT_COUNT || aTransType == DBM_SELECT_COUNT_BT
                || aTransType == DBM_SELECT_COUNT_GT || aTransType == DBM_SELECT_COUNT_LT
                || aTransType == DBM_SELECT_COUNT_DIRTY || aTransType == DBM_SELECT_COUNT_BT_DIRTY
                || aTransType == DBM_SELECT_COUNT_GT_DIRTY || aTransType == DBM_SELECT_COUNT_LT_DIRTY
                || aTransType == DBM_SEQ_NEXTVAL || aTransType == DBM_SEQ_CURRVAL
                )
        {
            _CALL( dbmExecInternalLib ( aHandle, aTable, aUserData, aUserData2, aTransType, aCount, aSeq ) );
            _RETURN;
        }

        /****************************************
         * DataObject 맵핑.
        ****************************************/
//        memset_s( &pHandle->mData, 0x00, sizeof( pHandle->mData ) );
        {
            dbmDataObject* X = &pHandle->mData;
//          X->mTransType   = DBM_NOT_DEFINED;
//          X->mTableName[0]= '\0';
            X->mUserData    = NULL;
            //X->mUserEndData = NULL;
            X->mColName     = NULL;
            X->mDataSize    = 0;
            //X->mSCN         = 0;
            X->mTimeout     = 0;
        }

        /*
         * 2014.12.14. -okt- [성능] I/U/S 모든 경우에 반드시 방생하는 비용으로. 제거할 수 없을까? ( 2014/07/09 )
         *             sqlite 도입하고 statement 개념을 추가하면 해결될 것으로 예상.
         */
        if ( likely( aTable != NULL ) )
        {
            memcpy_s ( pHandle->mData.mTableName, aTable, strlen_s( aTable ) + 1 );
        }

        pHandle->mData.mTransType = (dbmTransType)aTransType;

        // 2015.02.03 by lim272
        // Fetch 방향을 일단 저장해둔다.
        // OpenCursorGT, LT도 결국 SELECT_LT/GT로 들어오고 있음.
        // 따라서, 아래 2개만 저장해둔다.
        if ( aTransType == DBM_SELECT_GT       || aTransType == DBM_SELECT_LT ||
             aTransType == DBM_SELECT_GT_DIRTY || aTransType == DBM_SELECT_LT_DIRTY )
        {
             pHandle->mData.mSearchWay = (dbmTransType)aTransType;
        }

        if ( aUserData != NULL )
        {
            //TODO: 내부 mUserData 도 void* 로 하면 장단은?
            pHandle->mData.mUserData  = (char*)aUserData;
        }

        // 이렇게 조건 분기하는 비용이 클까? 아니면 함수를 함친 code cache miss 비용이 이득일까?
        if ( unlikely( aQSizeOrTimeOut != -99 ) )
        {
            if ( aTransType == DBM_DEQUE )
            {
                pHandle->mData.mTimeout   = aQSizeOrTimeOut;
            }
            else
            {
                // insert, enque,
                pHandle->mData.mDataSize   = aQSizeOrTimeOut;
            }
        }

        /* 2014.04.30 -shw- selct index type 추가 */
        /*
         * TODO: [OKT] 2015.03.07 이렇게 변수로 셋팅을 했는데 굳이 인자로 넘겨야하나?
         */
        pHandle->mData.mEQCnt = aEQCnt;

        /****************************************
         * mAct 호출.
        ****************************************/
        _CALL( pHandle->mTrans->mAct ( pHandle ) );

        /* non unique delete, update count move */
        /* 2014.07.28 -shw- */
        if ( unlikely ( pHandle->mData.mTransType == DBM_DELETE
                || pHandle->mData.mTransType == DBM_UPDATE
                || pHandle->mData.mTransType == DBM_UPDATE_COL )
        )
        {
            if ( aCount != NULL )
            {
                *aCount = pHandle->mData.mIndexCount;
            }
        }
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_DUP_ERROR )
        {
            _CATCH_DBG;
        }
        else if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            if ( pHandle != NULL )
            {
                _CATCH_ERR2 ( pHandle->mData.mTableName );
            }
            else
            {
                _CATCH_ERR;
            }
        }
    }
    _FINALLY
    {
        /*
         * TODO: 2014.11.24. -okt- 시그널이 발생한 상태이다. 내부 critical section 으로 진입하지 말고 기다린다.
         */
        if ( _cmn_signo_r != -1 ) // 임계영역 안에서 시그널을 받았다.
        {
            raise( _cmn_signo_r );
        }
        else
        {
            _cmn_signo_r = 0;
        }
    }
    _END
} /* dbmExecRowLib */


/********************************************************************
 * ID : dbmRemoteExecRowLib (Remote 공통함수)
 ********************************************************************/
_VOID dbmRemoteExecRowLib ( dbmHandle*    aHandle,
                            const char*   aTable,
                            void*         aUserData,
                            int           aTransType,
                            int           aQSizeOrTimeOut,
                            int           aEQCnt,
                            int*          aCount,
                            long long*    aSeq,
                            void*         aUserData2 )
{
    int                 i = 0;
    dbmInternalHandle*  sInternalH  = NULL;
    dbmRemoteHandle*    sRemoteH    = NULL;
    int                 sRealSize;
    int                 sUserDataSize;

    _TRY
    {
        sInternalH = (dbmInternalHandle*)aHandle->mHandle;
        sRemoteH   = (dbmRemoteHandle*)sInternalH->mRemote;

        /****************************************
         * Listener 로 Request Msg 전송
        ****************************************/
        {
            dbmMsgBody* X = &sRemoteH->mMsg.mBody.mMsgBody;

            X->mUserData[0] = 0x00;     // converting to non-pointer type ‘char’ from NULL [-Wconversion-null]
            //X->mUserEndData = NULL;
            X->mColName[0]  = 0x00;
            X->mDataSize    = 0;
            //X->mSCN         = 0;
            X->mTimeout     = 0;
        }

        sRemoteH->mMsg.mMsgType = (dbmTransType)aTransType;
        strcpy_s( sRemoteH->mMsg.mInstName, sInternalH->mInstanceName );
        if ( aTable != NULL )
        {
            strcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mTableName, aTable );

            /****************************************
             * Remote Handle(dbmRemoteHandle)내에 저장된
             * RowSize 정보를 이용하여 딱 그만큼만 copy
            ****************************************/
            for( i=0; i<sRemoteH->mTableCount; i++ )
            {
                if ( !strcmp_s( aTable, sRemoteH->mTable[i].mTableName) )
                {
                    break;
                }
            }

            //_IF_THROW( i>= sRemoteH->mTableCount, ERR_DBM_TABLE_NOT_PREPARED );

            if ( aUserData != NULL )
            {
                memcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mUserData,
                          aUserData,
                          sRemoteH->mTable[i].mRowSize );
                sRemoteH->mMsg.mBody.mMsgBody.mUserDataIsNULL = (1 << 0);
            }
            else
            {
                sRemoteH->mMsg.mBody.mMsgBody.mUserDataIsNULL = (0 << 0);
            }

            if ( aUserData2 != NULL )
            {
                memcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mUserData2,
                          aUserData2,
                          sRemoteH->mTable[i].mRowSize );
                sRemoteH->mMsg.mBody.mMsgBody.mUserDataIsNULL |= (1 << 1);

                sRemoteH->mMsg.mMsgSize = sizeof(dbmRemoteMsg)
                    - (DBM_MAX_RECORD_SIZE - sRemoteH->mTable[i].mRowSize);
            }
            else
            {
                sRemoteH->mMsg.mMsgSize = sizeof(dbmRemoteMsg)
                    - ((DBM_MAX_RECORD_SIZE * 2) - sRemoteH->mTable[i].mRowSize);
            }

        }

        if ( aQSizeOrTimeOut != -99 )
        {
            if ( aTransType == DBM_DEQUE )
            {
                sRemoteH->mMsg.mBody.mMsgBody.mTimeout = aQSizeOrTimeOut;
            }
            else
            {
                /* insert, enque */
                sRemoteH->mMsg.mBody.mMsgBody.mDataSize = aQSizeOrTimeOut;
            }
        }
        else
        {
        }

        // 2015.03.07 -okt- IF 처리 필요없음
        sRemoteH->mMsg.mBody.mMsgBody.mEQCnt = aEQCnt;

        _rc = cmnTcpSend( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          sRemoteH->mMsg.mMsgSize,
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_SEND_FAIL );


        /****************************************
         * Listener 로부터의 응답 처리
        ****************************************/
        memset_s( &sRemoteH->mMsg, 0x00, sizeof(dbmRemoteMsg) );

        _rc = cmnTcpRecv( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          0,   /* recv timeout */
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_RECV_FAIL );

        _IF_THROW( sRemoteH->mMsg.mBody.mMsgBody.mRC != RC_SUCCESS,
                   sRemoteH->mMsg.mBody.mMsgBody.mRC );

        if ( aUserData != NULL )
        {
            memcpy_s( aUserData,
                    sRemoteH->mMsg.mBody.mMsgBody.mUserData,
                    sRemoteH->mTable[i].mRowSize );
        }

        if( aCount != NULL )
        {
            *aCount = sRemoteH->mMsg.mBody.mMsgBody.mCount;
        }

        if( aSeq != NULL )
        {
            *aSeq = sRemoteH->mMsg.mBody.mMsgBody.mSeq;
        }
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_DUP_ERROR )
        {
            _CATCH_DBG;
        }
        else if ( _rc != ERR_DBM_NO_MATCH_RECORD )
        {
            if ( sInternalH != NULL )
            {
                _CATCH_ERR2 ( sInternalH->mData.mTableName );
            }
            else
            {
                _CATCH_ERR;
            }
        }
    }
    _FINALLY
    _END
}


/********************************************************************
 * ID : dbmSelectRow 등 dbmExecRowLib 를 호출하는 Wrapper함수
 ********************************************************************/

int dbmInsertRow ( dbmHandle* aHandle , const char* aTable , void* aData , int aSize )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_INSERT, aSize );
}

int dbmUpdateRow ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_UPDATE );
}

int dbmMetaUpdateRow ( dbmHandle* aHandle , const char* aTable , void* aData, int* aCount )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_UPDATE, -99, 0, aCount );
}

int dbmUpdateRangeGT ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, NULL, DBM_UPDATE_RANGE_GT, NULL );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_UPDATE_RANGE_GT );
}

int dbmUpdateRangeLT ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, NULL, DBM_UPDATE_RANGE_LT, NULL );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_UPDATE_RANGE_LT );
}

int dbmUpdateRangeBT ( dbmHandle* aHandle , const char* aTable , void* aData , void* aDataTwo )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, aDataTwo, DBM_UPDATE_RANGE_BT, NULL );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_UPDATE_RANGE_BT, -99, 0, NULL, NULL, aDataTwo );
}

int dbmDeleteRangeGT ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, NULL, DBM_DELETE_RANGE_GT, NULL );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_DELETE_RANGE_GT );
}

int dbmDeleteRangeLT ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, NULL, DBM_DELETE_RANGE_LT, NULL );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_DELETE_RANGE_LT );
}

int dbmDeleteRangeBT ( dbmHandle* aHandle , const char* aTable , void* aData, void* aDataTwo )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, aDataTwo, DBM_DELETE_RANGE_BT, NULL );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_DELETE_RANGE_BT, -99, 0, NULL, NULL, aDataTwo );
}

int dbmDeleteRow ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_DELETE );
}

int dbmMetaDeleteRow ( dbmHandle* aHandle , const char* aTable , void* aData, int* aCount )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_DELETE, -99, 0, aCount );
}

int dbmSelectMax ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_MAX );
}

int dbmSelectMin ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_MIN );
}

int dbmSelectRow ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT );
}

int dbmGetRowSize ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_ROWSIZE );
}

/* 2014.04.30 aEQCnt 추가 -shw */
int dbmSelectRowLT ( dbmHandle* aHandle , const char* aTable , void* aData , int aEQCnt )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_LT, -99, aEQCnt );
}

/* 2014.04.30 aEQCnt 추가 -shw */
int dbmSelectRowGT ( dbmHandle* aHandle , const char* aTable , void* aData , int aEQCnt )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_GT, -99, aEQCnt );
}

int dbmSelectForUpdateRow ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_FOR_UPDATE );
}

/* 2014.06.23 module 추가 -shw- */
int dbmFetchRow ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_FETCH );
}

/* 2014.07.29 aEQCnt 추가 -shw */
int dbmFetchNextGT ( dbmHandle* aHandle , const char* aTable , void* aData , int aEQCnt )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_FETCH_NEXT_GT, -99, aEQCnt );
}

/* 2014.07.29 aEQCnt 추가 -shw */
int dbmFetchNextLT ( dbmHandle* aHandle , const char* aTable , void* aData , int aEQCnt )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_FETCH_NEXT_LT, -99, aEQCnt );
}

int dbmOpenCursor_Ex ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_DIRTY );
}

int dbmOpenCursorGT_Ex ( dbmHandle* aHandle , const char* aTable , void* aData , int aEQCnt )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_GT_DIRTY, -99, aEQCnt );
}

int dbmOpenCursorLT_Ex ( dbmHandle* aHandle , const char* aTable , void* aData , int aEQCnt )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_LT_DIRTY, -99, aEQCnt );
}


/* 2014.07.14 module 추가 -shw- */
int dbmOpenCursor ( dbmHandle* aHandle , const char* aTable , void* aData )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT );
}

int dbmOpenCursorGT ( dbmHandle* aHandle , const char* aTable , void* aData , int aEQCnt )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_GT, -99, aEQCnt );
}

int dbmOpenCursorLT ( dbmHandle* aHandle , const char* aTable , void* aData , int aEQCnt )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_LT, -99, aEQCnt );
}

int dbmCloseCursor ( dbmHandle* aHandle )
{
    return dbmExecRowLib ( aHandle, NULL, NULL, DBM_CUR_CLOSE );
}

int dbmSelectCount ( dbmHandle* aHandle , const char* aTable , void* aData , int* aCount )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, NULL, DBM_SELECT_COUNT, aCount );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_COUNT, -99, 0, aCount );
}

int dbmSelectCountGT ( dbmHandle* aHandle , const char* aTable , void* aData , int* aCount )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, NULL,  DBM_SELECT_COUNT_GT, aCount );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_COUNT_GT, -99, 0, aCount );
}

int dbmSelectCountLT ( dbmHandle* aHandle , const char* aTable , void* aData , int* aCount )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, NULL, DBM_SELECT_COUNT_LT, aCount );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_COUNT_LT, -99, 0, aCount );
}

//int dbmSelectCountGE ( dbmHandle* aHandle , const char* aTable , void* aData , int* aCount )
//{
//     return dbmExecInternalLib ( aHandle, aTable, aData, NULL,  DBM_SELECT_COUNT_GE, aCount );
//}
//
//int dbmSelectCountLE ( dbmHandle* aHandle , const char* aTable , void* aData , int* aCount )
//{
//     return dbmExecInternalLib ( aHandle, aTable, aData, NULL, DBM_SELECT_COUNT_LE, aCount );
//}

int dbmSelectCountBT ( dbmHandle* aHandle , const char* aTable , void* aData , void* aDataTwo, int* aCount )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, aDataTwo, DBM_SELECT_COUNT_BT, aCount );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_COUNT_BT, -99, 0, aCount, NULL, aDataTwo );
}

int dbmSelectCount_Ex ( dbmHandle* aHandle , const char* aTable , void* aData , int* aCount )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, NULL, DBM_SELECT_COUNT, aCount );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_COUNT_DIRTY, -99, 0, aCount );
}

int dbmSelectCountGT_Ex ( dbmHandle* aHandle , const char* aTable , void* aData , int* aCount )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, NULL,  DBM_SELECT_COUNT_GT, aCount );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_COUNT_GT_DIRTY, -99, 0, aCount );
}

int dbmSelectCountLT_Ex ( dbmHandle* aHandle , const char* aTable , void* aData , int* aCount )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, NULL, DBM_SELECT_COUNT_LT, aCount );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_COUNT_LT_DIRTY, -99, 0, aCount );
}

int dbmSelectCountBT_Ex ( dbmHandle* aHandle , const char* aTable , void* aData , void* aDataTwo, int* aCount )
{
    // return dbmExecInternalLib ( aHandle, aTable, aData, aDataTwo, DBM_SELECT_COUNT_BT, aCount );
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_SELECT_COUNT_BT_DIRTY, -99, 0, aCount, NULL, aDataTwo );
}

int dbmSeqNextVal ( dbmHandle* aHandle , const char* aTable , long long* aSeq )
{
    // return dbmExecInternalLib ( aHandle, aTable, NULL , NULL, DBM_SEQ_NEXTVAL , NULL, aSeq );
    return dbmExecRowLib ( aHandle, aTable, NULL, DBM_SEQ_NEXTVAL, -99, 0, NULL, aSeq );
}

int dbmSeqCurrVal ( dbmHandle* aHandle , const char* aTable , long long* aSeq )
{
    // return dbmExecInternalLib ( aHandle, aTable, NULL, NULL, DBM_SEQ_CURRVAL , NULL, aSeq );
    return dbmExecRowLib ( aHandle, aTable, NULL, DBM_SEQ_CURRVAL, -99, 0, NULL, aSeq );
}

int dbmCommit ( dbmHandle* aHandle )
{
    return dbmExecRowLib ( aHandle, NULL, NULL, DBM_COMMIT );
}

/*
 * 2014.12.14. -okt- 삼성증권 PoC 복구 테스트를 할때, A 제품이나, SUNDB는 데이타 유실이 발생했는데 골디락스는 없었다.
 * 테스트 조건은 NoSYNC (Async)인데. 이건 좋게 생각할 게 아니고 우리가 성능을 까먹고 있다는 의미가 된다.
 * 기존 Defer함수를 순차 호출하면 되나, 아래함수를 별도로 추가한다.
 */
int dbmAsyncCommit ( dbmHandle* aHandle )
{
    int sRC;

    sRC = dbmExecRowLib ( aHandle, NULL, NULL, DBM_DEFER_COMMIT );
    if ( sRC == 0 )
    {
        return dbmExecRowLib ( aHandle, NULL, NULL, DBM_DEFER_SYNC );
    }

    return sRC;
}

int dbmDeferCommit ( dbmHandle* aHandle )
{
    return dbmExecRowLib ( aHandle, NULL, NULL, DBM_DEFER_COMMIT );
}

int dbmDeferSync ( dbmHandle* aHandle )
{
    return dbmExecRowLib ( aHandle, NULL, NULL, DBM_DEFER_SYNC );
}

int dbmRollback ( dbmHandle* aHandle )
{
    return dbmExecRowLib ( aHandle, NULL, NULL, DBM_ROLLBACK );
}

int dbmEnqueue ( dbmHandle* aHandle , const char* aTable , void* aData , int aDataSize )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_ENQUE, aDataSize );
}

int dbmDequeue ( dbmHandle* aHandle , const char* aTable , void* aData , int aTimeOut )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_DEQUE, aTimeOut );
}

int dbmListLpush ( dbmHandle* aHandle , const char* aTable , void* aData , int aDataSize )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_LIST_LPUSH, aDataSize );
}

int dbmListRpush ( dbmHandle* aHandle , const char* aTable , void* aData , int aDataSize )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_LIST_RPUSH, aDataSize );
}

int dbmListLpop ( dbmHandle* aHandle , const char* aTable , void* aData , int aDataSize )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_LIST_LPOP, aDataSize );
}

int dbmListRpop ( dbmHandle* aHandle , const char* aTable , void* aData , int aDataSize )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_LIST_RPOP, aDataSize );
}

int dbmListRange ( dbmHandle* aHandle , const char* aTable , void* aData , int aDataSize )
{
    return dbmExecRowLib ( aHandle, aTable, aData, DBM_LIST_RANGE, aDataSize );
}


/********************************************************************
 * ID : dbmUpdateRowByCols
 ********************************************************************/
int dbmUpdateRowByCols ( dbmHandle* aHandle , const char* aTable )
{
    return dbmExecRowLib ( aHandle, aTable, NULL, DBM_UPDATE_COL );
}

int dbmUpdateRowByColsGT ( dbmHandle* aHandle , const char* aTable )
{
    return dbmExecRowLib ( aHandle, aTable, NULL, DBM_UPDATE_COL_GT );
}

int dbmUpdateRowByColsLT ( dbmHandle* aHandle , const char* aTable )
{
    return dbmExecRowLib ( aHandle, aTable, NULL, DBM_UPDATE_COL_LT );
}

int dbmMetaUpdateRowByCols ( dbmHandle* aHandle , const char* aTable , int* aCount )
{
    return dbmExecRowLib ( aHandle, aTable, NULL, DBM_UPDATE_COL , -99, 0, aCount );
}

/********************************************************************
 * ID : dbmColBind
 ********************************************************************/
_VOID dbmColBind ( dbmHandle*   aHandle,
                   const char*  aTable,
                   const char*  aColName,
                   void*        aUserData,
                   int          aColSize )
{
    dbmInternalHandle* pHandle = NULL;

    _TRY
    {
        pHandle = (dbmInternalHandle*)aHandle->mHandle;

        // Water Mark가 다르면 걍 리턴해라.
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            DBM_ERR ( "invalide magic number (%ld)", aHandle->mMark );
            _THROW( ERR_DBM_INVALID_HANDLE );
        }


        /****************************************
         * Remote Connection 일 경우 별도 처리한다.
        ****************************************/
        if ( pHandle->mRemote != NULL && pHandle->mRemote->mSockFd > 0 )
        {
            _CALL( dbmRemoteColBind( aHandle, aTable, aColName, aUserData, aColSize ) );
            _RETURN;
        }


        /****************************************
         * DataObject 맵핑.
        ****************************************/
        memset_s( &pHandle->mData, 0x00, sizeof( pHandle->mData ) );
        memcpy_s ( pHandle->mData.mTableName, aTable, strlen_s ( aTable ) + 1 );
        pHandle->mData.mTransType = DBM_BIND_COL;
        pHandle->mData.mColName   = (char*)aColName;
        pHandle->mData.mUserData  = (char*)aUserData;
        pHandle->mData.mDataSize  = aColSize;

        /****************************************
         * mAct 호출.
        ****************************************/
        _CALL( pHandle->mTrans->mAct ( pHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
//        if ( pHandle != NULL )
//        {
//            pHandle->mError->mErrCode = _rc;
//        }
    }
    _END
}


_VOID dbmRemoteColBind ( dbmHandle*   aHandle,
                         const char*  aTable,
                         const char*  aColName,
                         void*        aUserData,
                         int          aColSize )
{
    dbmInternalHandle*  sInternalH  = NULL;
    dbmRemoteHandle*    sRemoteH    = NULL;
    int                 sRealSize;
    int                 sUserDataSize;

    _TRY
    {
        sInternalH = (dbmInternalHandle*)aHandle->mHandle;
        sRemoteH   = (dbmRemoteHandle*)sInternalH->mRemote;

        /****************************************
         * Listener 로 Request Msg 전송
        ****************************************/
        {
            dbmMsgBody* X = &sRemoteH->mMsg.mBody.mMsgBody;

            X->mUserData[0] = 0x00;
            //X->mUserEndData = NULL;
            X->mColName[0]  = 0x00;
            X->mDataSize    = 0;
            //X->mSCN         = 0;
            X->mTimeout     = 0;
        }

        sRemoteH->mMsg.mMsgSize = sizeof(dbmRemoteMsg);
        sRemoteH->mMsg.mMsgType = DBM_BIND_COL;
        strcpy_s( sRemoteH->mMsg.mInstName, sInternalH->mInstanceName );
        strcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mTableName, aTable );
        strcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mColName, aColName );
        memcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mUserData, aUserData, aColSize );
        sRemoteH->mMsg.mBody.mMsgBody.mDataSize = aColSize;

        _rc = cmnTcpSend( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          sRemoteH->mMsg.mMsgSize,
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_SEND_FAIL );


        /****************************************
         * Listener 로부터의 응답 처리
        ****************************************/
        _rc = cmnTcpRecv( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          0,   /* recv timeout */
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_RECV_FAIL );

        _IF_THROW( sRemoteH->mMsg.mBody.mMsgBody.mRC != RC_SUCCESS,
                   sRemoteH->mMsg.mBody.mMsgBody.mRC );
    }

    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
//        if ( sInternalH != NULL )
//        {
//            sInternalH->mError->mErrCode = _rc;
//        }
    }
    _END
}

/********************************************************************
 * ID : dbmClearBind
 ********************************************************************/
_VOID dbmClearBind (dbmHandle* aHandle)
{
    dbmInternalHandle* pHandle = NULL;

    _TRY
    {
        pHandle = (dbmInternalHandle*)aHandle->mHandle;

        // Water Mark가 다르면 걍 리턴해라.
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            DBM_ERR ( "invalide magic number (%ld)", aHandle->mMark );
            _THROW( ERR_DBM_INVALID_HANDLE );
        }


        /****************************************
         * Remote Connection 일 경우 별도 처리한다.
        ****************************************/
        if ( pHandle->mRemote != NULL && pHandle->mRemote->mSockFd > 0 )
        {
            _CALL( dbmRemoteClearBind( aHandle ) );
            _RETURN;
        }


        /****************************************
         * DataObject 맵핑.
        ****************************************/
        memset_s (&pHandle->mData, 0x00, sizeof(pHandle->mData));
        pHandle->mData.mTransType = DBM_CLEAR_BIND;

        /****************************************
         * mAct 호출.
        ****************************************/
        _CALL( pHandle->mTrans->mAct ( pHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
//        if ( pHandle != NULL )
//        {
//            pHandle->mError->mErrCode = _rc;
//        }
    }
    _END
}


_VOID dbmRemoteClearBind (dbmHandle* aHandle)
{
    dbmInternalHandle*  sInternalH  = NULL;
    dbmRemoteHandle*    sRemoteH    = NULL;
    int                 sRealSize;
    int                 sUserDataSize;

    _TRY
    {
        sInternalH = (dbmInternalHandle*)aHandle->mHandle;
        sRemoteH   = (dbmRemoteHandle*)sInternalH->mRemote;

        /****************************************
         * Listener 로 Request Msg 전송
        ****************************************/
        {
            dbmMsgBody* X = &sRemoteH->mMsg.mBody.mMsgBody;

            X->mUserData[0] = 0x00;
            //X->mUserEndData = NULL;
            X->mColName[0]  = 0x00;
            X->mDataSize    = 0;
            //X->mSCN         = 0;
            X->mTimeout     = 0;
        }

        sRemoteH->mMsg.mMsgSize = sizeof(dbmRemoteMsg);
        sRemoteH->mMsg.mMsgType = DBM_CLEAR_BIND;
        strcpy_s( sRemoteH->mMsg.mInstName, sInternalH->mInstanceName );

        _rc = cmnTcpSend( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          sRemoteH->mMsg.mMsgSize,
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_SEND_FAIL );


        /****************************************
         * Listener 로부터의 응답 처리
        ****************************************/
        _rc = cmnTcpRecv( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          0,   /* recv timeout */
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_RECV_FAIL );

        _IF_THROW( sRemoteH->mMsg.mBody.mMsgBody.mRC != RC_SUCCESS,
                   sRemoteH->mMsg.mBody.mMsgBody.mRC );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
//        if ( sInternalH != NULL )
//        {
//            sInternalH->mError->mErrCode = _rc;
//        }
    }
    _END
}

/********************************************************************
* ID : dbmExecDic
********************************************************************/
_VOID dbmExecDic( dbmInternalHandle* aInterHandle, const char* aTable, void* aData, dbmIndexObject** aDicIDXObj,
                  dbmTableInfo** aDicTBLInfo, int aCheck, char (*aColumnFilterName)[DBM_NAME_LEN], int* aFilterCount, dbmHandle* aHandle )
{
    dbmColumnObject*    sDicColObj      = NULL;
    dbmTableInfo*       sDicTBLInfo     = NULL;
    dbmTableObject*     sDicTBLObj      = NULL;
    dbmDicObject        sDicObj;
    dbmIndexObject*     sDicIDXObj      = NULL;

    int     i,j;
    int     sUndoExist = 0;
    int     sIDXInd;
    char*   sInstName = NULL;
    int     sRC;
    int     sSetNo = 0;
    char    sIndexName[DBM_NAME_LEN];

    _TRY
    {
        _DASSERT( aInterHandle != NULL );
        //_DASSERT( aHandle->mTrans != NULL );

        memset_s ( &sDicObj, 0x00, sizeof( sDicObj ) );

        sDicTBLInfo     = (dbmTableInfo*)&sDicObj.mObj.mTableInfo;
        sDicTBLObj      = (dbmTableObject*)&sDicObj.mObj.mTableInfo.mTable;

        /*
         * TODO: 2014.11.14 -okt- CS 테스트 에서 aHandle->mTrans 가 NULL 발생한다.
         *       etc.sh ( mSelectCount )
         */
        //sInstName = aHandle->mTrans->mGetUndoName();
        sInstName = aInterHandle->mInstanceName;

        dbmDictionary* sDic;
        sDic = new dbmDictionary();
        _IF_THROW( sDic == NULL, ERR_DBM_MEM_ALLOC );

        sRC = sDic->mAttach();
        if ( sRC != 0 ) //, DIC_PREPARE_FAIL );
        {
            DBM_ERR( "Dic Prepare fail. rc=%d (err=%d)", sRC, errno );
            delete_s( sDic );
            _THROW( ERR_DBM_DICTIONARY_NOT_PREPARED );
        }

        sDicObj.mSQLType = DBM_CREATE_INST;
        sRC = sDic->mGetFirst( &sDicObj );
        _IF_THROW( sRC, ERR_DBM_INVALID_UNDO_NAME );

        if ( !strcmp_s ( sDicObj.mObj.mInstance.mInstanceName, sInstName ) )
        {
            sUndoExist = 1;
        }

        while(1)
        {
            sDicObj.mSQLType = DBM_CREATE_INST;

            sRC = sDic->mGetNext( &sDicObj );
            if ( sRC ) break;

            if ( !strncmp_s( sDicObj.mObj.mInstance.mInstanceName, sInstName, strlen_s(sInstName)) )
            {
                sUndoExist = 1;
                break;
            }
        }

        _IF_THROW( sUndoExist == 0, ERR_DBM_INVALID_UNDO_NAME );

        /* index type 구하기 위하여 dic 구해온다 */
#if 0
        strncpy( sDicTBLObj->mInstName, sInstName, strlen_s(sInstName));
        strncpy( sDicTBLObj->mTableName, aTable, strlen_s(aTable));
#else
        strncpy( sDicTBLObj->mInstName, sInstName, sizeof(sDicTBLObj->mInstName) );
        strncpy( sDicTBLObj->mTableName, aTable, sizeof(sDicTBLObj->mTableName) );
#endif
        sDicObj.mSQLType = DBM_CREATE_TABLE;

        _CALL( sDic->mSelect(&sDicObj) );

        /* aCheck 2: input Index name 으로 Index  지정 */
        if ( aCheck == 2 )
        {
            if ( sDicTBLObj->mTableType == DBM_TBL_DIRECT || 
                 sDicTBLObj->mTableType == DBM_TBL_SEQUENCE )
            {
                *aFilterCount = -1;
                delete_s( sDic );
                _RETURN;
            }
            /* key colunt name copy 한다 */
            for ( i = 0 ; i < (int)sDicTBLInfo->mIndexCount; i++ )
            {
                sDicIDXObj = (dbmIndexObject*)&sDicTBLInfo->mIndex[i];

                for ( j = 0; j < sDicIDXObj->mColumnCount; j++ )
                {
                    strncpy_s( aColumnFilterName[sSetNo], sDicIDXObj->mKey[j].mColumnName, sDicIDXObj->mKey[j].mSize ); 

                    sSetNo++;
                }
            }

            /* Index Name 구한다 */
            memset_s ( sIndexName, 0x00, DBM_NAME_LEN );

            _CALL( dbmGetIndex ( aHandle, aTable, (char*)aData ) );

            /* 현재 Index name 구한다 */
            for ( i = 0 ; i < (int)sDicTBLInfo->mIndexCount; i++ )
            {
                if ( !strcmp_s ( (char*)aData, (char*)(dbmIndexObject*)&sDicTBLInfo->mIndex[i].mIndexName ) )
                {
                    sDicIDXObj = (dbmIndexObject*)&sDicTBLInfo->mIndex[i];

                    break;
                }
            }

            *aFilterCount = sSetNo;
        }
        else
        {
            //무조건 0번 인덱스를 주는 것에서 현재 인덱스를 주는 것으로 변경
            //sDicIDXObj = (dbmIndexObject*)&sDicTBLInfo->mIndex[0];
            memset_s ( sIndexName, 0x00, DBM_NAME_LEN );
            _CALL( dbmGetIndex ( aHandle, aTable, (char*)sIndexName ) );
            for ( i = 0 ; i < (int)sDicTBLInfo->mIndexCount; i++ )
            {
                if ( !strcmp_s ( (char*)sIndexName, sDicTBLInfo->mIndex[i].mIndexName ) )
                {
                    sDicIDXObj = (dbmIndexObject*)&sDicTBLInfo->mIndex[i];
                    break;
                }
            }
            //TODO:wind 인덱스를 못 찾는 경우가 생기지 않으려나?
            //if( sDicIDXObj == NULL )
        }

        if ( aCheck == 1 )
        {
            sRC = dbmExecInterColumn ( aInterHandle , aTable, aData, sDicIDXObj, sDicTBLObj );
        }

        /* index pointer 넘겨준다 */
        *aDicIDXObj = sDicIDXObj;
        *aDicTBLInfo = sDicTBLInfo;

        delete_s( sDic );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}



/********************************************************************
* ID : dbmExecInterColumn
********************************************************************/
_VOID dbmExecInterColumn( dbmInternalHandle* aHandle,
                          const char* aTable,
                          void* aData,
                          dbmIndexObject* aDicIDXObj,
                          dbmTableObject* aDicTBLObj )
{
    int     sRC;
    int     sIDXInd = 0;

    dbmColumnObject* sDicColObj = NULL;

    _TRY
    {
        for( sIDXInd = 0; sIDXInd < aDicIDXObj->mColumnCount; sIDXInd++ )
        {
            sDicColObj = (dbmColumnObject*)&aDicIDXObj->mKey[sIDXInd];

            if ( aDicTBLObj->mTableType == DBM_TBL_DIRECT )
            {
                sRC = dbmExecBindData( sDicColObj, NULL, aData, 1 );
                _CALL(sRC);
            }
            else
            {
                sRC = dbmExecBindData( sDicColObj, NULL, aData, 0 );
                _CALL(sRC);
            }
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/********************************************************************
* ID : dbmExecColBind
********************************************************************/
_VOID dbmExecColBind ( dbmHandle* aHandle ,
                       const char* aTable,
                       void* aData,
                       dbmIndexObject* aDicIDXObj,
                       dbmTableInfo* aDicTBLInfo,
                       char (*aColumnFilterName)[DBM_NAME_LEN],
                       int sFilterCount )
{
    int     i,j;
    int     sTBLInd = 0;
    int     sColBindCnt = 0;

    dbmColumnObject* sDicColObj = NULL;

    _TRY
    {
        dbmClearBind ( aHandle );

        for( sTBLInd = 0; sTBLInd < aDicTBLInfo->mColumn.mCount; sTBLInd++ )
        {
            sDicColObj = (dbmColumnObject *)&aDicTBLInfo->mColumn.mCols[sTBLInd];

            /* ColBind 처리를 한다 */
            /* update record by column binding */
            for ( i = 0; i < sFilterCount; i++ )
            {
                /* :fieter -> columname x */
                if ( strncmp_s( sDicColObj->mColumnName, aColumnFilterName[i], sDicColObj->mSize ) )
                {
                    /* dbmColBind 처리 */
                    //memcpy_s ( sBindCols->mData + sBindCols->mOffset[j], sData->mUserData, sData->mDataSize );
                    //rc = dbmColBind ( aHandle, aTable, sDicColObj->mColumnName, &data.ename, sDicColObj->mSize );
                    //_CALL( dbmColBind ( aHandle, aTable, sDicColObj->mColumnName, aData+sDicColObj->mOffset, sDicColObj->mSize ) );
                    sColBindCnt++;

                }
                else
                {
                    /* Index Column name 같은가 */
                    for ( j = 0;  j < aDicIDXObj->mColumnCount; j++ )
                    {
                        /* dbmColBind 처리 */
                        if ( !strncmp_s( aDicIDXObj->mKey[j].mColumnName, sDicColObj->mColumnName, sDicColObj->mSize ) )
                        {
                            _CALL( dbmColBind ( aHandle, aTable, sDicColObj->mColumnName, (char*)aData+sDicColObj->mOffset, sDicColObj->mSize ) );

                            break;
                        }
                    }

                    /* index_1 :c1 index_c2 :c2*/
                    /* c1이 key이고 현재 c2 index_c2라고 했을 때 c1 index_1은 binding을 하면 안된다 */
                    /* 같은 name 비교하여 바인딩을 하던 안하던 할거는 없다 
                     * key에 있는 놈이니 binding을 하면 안된다.. 빠져 나와라 */
                    break;
                }
            }

            if( sFilterCount == sColBindCnt )
            {
                _CALL( dbmColBind ( aHandle, aTable, sDicColObj->mColumnName, (char*)aData+sDicColObj->mOffset, sDicColObj->mSize ) ); 
            }

            sColBindCnt = 0;
        }

        /* update binding */
        _CALL( dbmUpdateRowByCols ( aHandle, aTable ) );

    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/********************************************************************
* ID : dbmExecBindData
********************************************************************/
_VOID dbmExecBindData( dbmColumnObject* aDicColObj , char* aBindData , void* aData, int aDirectF )
{

    long long sLongData   = 0;
    float   sFloatData  = 0;
    double  sDoubleData = 0;
    short   sShortData  = 0;
    int     sIntData    = 0;
    int     sColSize    = 0;

    _TRY
    {
        if ( aBindData == NULL )
        {
            switch( aDicColObj->mColumnType )
            {
                case DBM_COLUMN_CHAR_TYPE:
                    sColSize = aDicColObj->mSize;
                    /*
                     * #869 2015.02.26 -okt- [불가피 BUGBUG] 문자열 타입에 대한 최소표시로서 첫 1바이트를 0x00 처리
                     *      이는 사용자가 CHAR(N) 타입에 이진 데이타를 넣을 수도 있다는 점에서.
                     *      구멍이 있는 로직이나. 통상의 DBMS에서 최소값의 기준으로 쓸만한 NULL 개념을 넣을 수 없는 골디2에서 불가피
                     */
                    ((char*)aData + aDicColObj->mOffset)[0] = 0x00;
                    break;

                case DBM_COLUMN_LONG_TYPE:
                    sLongData = aDirectF==1?-1:LONG_MIN;
                    sColSize = sizeof( long long );
                    memcpy_s( (char*)aData + aDicColObj->mOffset, &sLongData, sColSize );
                    break;

                case DBM_COLUMN_INT_TYPE:
                    sIntData = aDirectF==1?-1:INT_MIN;
                    sColSize = sizeof( int );
                    memcpy_s( (char*)aData + aDicColObj->mOffset, &sIntData, sColSize );
                    break;

                case DBM_COLUMN_SHORT_TYPE:
                    sShortData = aDirectF==1?-1:SHRT_MIN;
                    sColSize = sizeof( short );
                    memcpy_s( (char*)aData + aDicColObj->mOffset, &sShortData, sColSize );
                    break;

                case DBM_COLUMN_DOUBLE_TYPE:
                    sDoubleData = DBL_MIN;
                    sColSize = sizeof( double );
                    memcpy_s( (char*)aData + aDicColObj->mOffset, &sDoubleData, sColSize );
                    break;

                case DBM_COLUMN_FLOAT_TYPE:
                    sFloatData = FLT_MIN;
                    sColSize = sizeof( float );
                    memcpy_s( (char*)aData + aDicColObj->mOffset, &sFloatData, sColSize );
                    break;

                default:
                    DBM_ERR( "%s -- '%s'\n", dbmGetError(ERR_DBM_INVALID_COLUMN_TYPE), aDicColObj->mColumnName );
                    _CALL(ERR_DBM_INVALID_COLUMN_TYPE);

                    break;
            }
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/********************************************************************
* ID : dbmExecDataCheck
********************************************************************/
_VOID dbmExecDataCheck( void* aData, void* aDataTwo, dbmIndexObject* aDicIDXObj )
{
    char    sKeyData[DBM_INDEX_KEY_MAX_SIZE];
    char*   sKey;
    char    sKeyData2[DBM_INDEX_KEY_MAX_SIZE];
    char*   sKey2;
    int     sKeyOffset;
    int     sRC;
    int     i;

    _TRY
    {

        sKeyOffset = 0;
        /* sKey Make : offset 값으로 정확히 가져오기 때문에 memset 필요없다 */
        //memset_s(sKeyData, 0x00, sizeof(sKeyData));
        //memset_s(sKeyData2, 0x00, sizeof(sKeyData2));
        sKey = (char*)&sKeyData;
        sKey2 = (char*)&sKeyData2;

        for( i = 0; i < aDicIDXObj->mColumnCount; i++ )
        {
            /* sKey copy */
            memcpy_s( sKey + sKeyOffset, (char*)aData + aDicIDXObj->mKey[i].mOffset, aDicIDXObj->mKey[i].mSize );
            memcpy_s( sKey2 + sKeyOffset, (char*)aDataTwo + aDicIDXObj->mKey[i].mOffset, aDicIDXObj->mKey[i].mSize );


            switch( aDicIDXObj->mKey[i].mColumnType )
            {
                case DBM_COLUMN_CHAR_TYPE:
                    sRC = memcmp_s ( sKey + sKeyOffset, sKey2 + sKeyOffset, aDicIDXObj->mKey[i].mSize );
                    if (sRC > 0)
                    {
                        _THROW(RC_FAILURE);
                    }

                    break;

                case DBM_COLUMN_SHORT_TYPE:
                    if ( *(short*)sKey + sKeyOffset > *(short*)sKey2 + sKeyOffset )
                    {
                        _THROW(RC_FAILURE);
                    }

                    break;


                case DBM_COLUMN_INT_TYPE:
                    if ( *(int*)sKey + sKeyOffset > *(int*)sKey2 + sKeyOffset )
                    {
                        _THROW(RC_FAILURE);
                    }

                    break;


                case DBM_COLUMN_LONG_TYPE:
                    if ( *(long long*)sKey + sKeyOffset > *(long long*)sKey2 + sKeyOffset )
                    {
                        _THROW(RC_FAILURE);
                    }

                    break;

                default:
                    _THROW(ERR_DBM_INVALID_COLUMN_TYPE);
            }

            sKeyOffset += aDicIDXObj->mKey[i].mSize;
        }

    }
    _CATCH
    {
        // #911 BT 조건을 체크하기위한 확인 함수이다. RC_FAILURE는 실패가 아닌 NOT_FOUND 의미임.
#ifdef _DEBUG
        _CATCH_TRC;
#else
        _CATCH_DBG;
#endif
    }
    _FINALLY
    _END
} /* dbmExecDataCheck */


/********************************************************************
* ID : dbmExecUpdate
********************************************************************/
_VOID dbmExecUpdate( void* aData, void* aTmpTable, dbmTableInfo* aDicTBLInfo, dbmIndexObject* aDicIDXObj )
{
    int     sCond;
    int     i,j,k,l;
    int     sRC;

    _TRY
    {
        for( i = 0; i < (int)aDicTBLInfo->mIndexCount; i++ )
        {
            for( j = 0; j < aDicTBLInfo->mIndex[i].mColumnCount; j++ )
            {
                if( i == 0 )
                {
                    memcpy_s( (char*)aTmpTable + aDicTBLInfo->mIndex[i].mKey[j].mOffset,
                            (char*)aData + aDicTBLInfo->mIndex[i].mKey[j].mOffset,
                            aDicTBLInfo->mIndex[i].mKey[j].mSize );
                }
                else
                {
                    for( k = 0; k < i; k++ )
                    {
                        sCond = FALSE;
                        for( l = 0; l < aDicTBLInfo->mIndex[k].mColumnCount; l++ )
                        {
                            if( aDicTBLInfo->mIndex[i].mKey[j].mOffset == aDicTBLInfo->mIndex[k].mKey[l].mOffset )
                            {
                                sCond = TRUE;
                                break;
                            }
                        }
                        if( sCond != TRUE )
                        {
                            memcpy_s( (char*)aTmpTable + aDicTBLInfo->mIndex[i].mKey[j].mOffset,
                                    (char*)aData + aDicTBLInfo->mIndex[i].mKey[j].mOffset,
                                    aDicTBLInfo->mIndex[i].mKey[j].mSize );
                        }
                    }
                }
            }
        }
#if 0
        for( j = 0; j < aDicIDXObj->mColumnCount; j++ )
        {
            switch( aDicIDXObj->mKey[j].mColumnType )
            {
                case DBM_COLUMN_CHAR_TYPE:
                    memcpy_s( (char*)aTmpTable + aDicIDXObj->mKey[i].mOffset, (char*)aData + aDicIDXObj->mKey[i].mOffset, aDicIDXObj->mKey[i].mSize );

                    break;

                case DBM_COLUMN_SHORT_TYPE:
                    *(short*)((char*)aTmpTable + aDicIDXObj->mKey[i].mOffset) = *(short*)((char*)aData + aDicIDXObj->mKey[i].mOffset);

                    break;

                case DBM_COLUMN_INT_TYPE:
                    *(int*)((char*)aTmpTable + aDicIDXObj->mKey[i].mOffset) = *(int*)((char*)aData + aDicIDXObj->mKey[i].mOffset);

                    break;


                case DBM_COLUMN_LONG_TYPE:
                    *(long long*)((char*)aTmpTable + aDicIDXObj->mKey[i].mOffset) = *(long long*)((char*)aData + aDicIDXObj->mKey[i].mOffset);

                    break;

                default:
                    _THROW(ERR_DBM_INVALID_COLUMN_TYPE);
            }
        }
#endif
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}
