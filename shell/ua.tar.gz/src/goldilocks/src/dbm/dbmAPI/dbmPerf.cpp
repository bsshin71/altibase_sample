
#include "dbmHeader.h"
#include "dbmPerf.h"


#define SKIP_COUNT 0

std::map<std::string, dbmPerfLog> dbmPerf::gPerf;


void dbmPerf::dbmPerfInit()
{
    gPerf.clear();
}


void dbmPerf::dbmPerfStart ( char *aFunc )
{
#ifdef __PERF__
    std::map<std::string, dbmPerfLog>::iterator sPerf;

    dbmPerfLog sLog;

    sPerf = gPerf.find (aFunc);
    if (sPerf == gPerf.end())
    {
        memset_s(&sLog, 0x00, sizeof(dbmPerfLog));
        sLog.mCount = sLog.mSumOfElap = 0;
        clock_gettime_s(CLOCK_REALTIME, &sLog.mStart);
        gPerf.insert (map<string, dbmPerfLog>::value_type(aFunc, sLog));
    }
    else
    {
        clock_gettime_s(CLOCK_REALTIME, &sPerf->second.mStart);
    }
#else
    // -Wempty-body 때문에 괄호필요.
    if ( aFunc == NULL )
    {
        _DASSERT ( 0 ); // dummy for no-build-warning
    }
#endif
}


void dbmPerf::dbmPerfEnd(char *aFunc)
{
#ifdef __PERF__
    std::map<std::string, dbmPerfLog>::iterator sPerf;
    dbmPerfLog sLog;
    double sElap;

    sPerf = gPerf.find (aFunc);
    if (sPerf == gPerf.end())
    {
        // nothing to do
    }
    else
    {
        clock_gettime_s(CLOCK_REALTIME, &sPerf->second.mEnd);
        sElap = (sPerf->second.mEnd.tv_sec + sPerf->second.mEnd.tv_nsec/1000000000.0) -
                (sPerf->second.mStart.tv_sec + sPerf->second.mStart.tv_nsec/1000000000.0);
        sPerf->second.mCount++;
        if (sPerf->second.mCount > SKIP_COUNT)
        {
            sPerf->second.mSumOfElap = sPerf->second.mSumOfElap + sElap;
        }
    }
#else
    if ( aFunc == NULL )
    {
        _DASSERT ( 0 ); // dummy for no-build-warning
    }
#endif
}

void dbmPerf::dbmPrintAll()
{
    std::map<std::string, dbmPerfLog>::iterator sPerf;

    for (sPerf = gPerf.begin(); sPerf != gPerf.end(); sPerf++)
    {
        fprintf(stdout, "Name <%-32.32s> :: Count <%10lld> , Elap <%13.9f>, Avg <%13.9f\n",
                        sPerf->first.c_str(),
                        sPerf->second.mCount,
                        sPerf->second.mSumOfElap,
                        (double)(sPerf->second.mSumOfElap / abs((sPerf->second.mCount-SKIP_COUNT)))
                        );
    }
}
