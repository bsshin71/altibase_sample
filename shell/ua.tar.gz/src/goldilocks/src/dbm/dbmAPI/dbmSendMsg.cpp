/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *******************************************************************************/
#include "dbmHeader.h"


/********************************************************************
 * ID : dbmSendMsg
 ********************************************************************/
_VOID dbmSendMsg ( dbmHandle* aHandle , char* aTopic, char* aUserData, int aSize, int aTTL)
{
    dbmInternalHandle* pHandle = NULL;
    momTopicKey     sTopic;
    momTopicData    sData;
    long long       sMsgID;

    _TRY
    {
        pHandle = (dbmInternalHandle *)aHandle->mHandle;

        // Water Mark가 다르면 걍 리턴해라.
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            DBM_ERR ( "invalide magic number (%ld)", aHandle->mMark );
            _THROW( ERR_DBM_INVALID_HANDLE );
        }

        /****************************************
         * topic Master를 prepare한다.
        ****************************************/
        _CALL( dbmPrepareTable (aHandle, MOM_TOPIC_MASTER) );
        _CALL( dbmPrepareTable (aHandle, MOM_EVENT_FOR_DIS) );

        /****************************************
         * aTopic을 prepare한다.
        ****************************************/
        _CALL( dbmPrepareTable (aHandle, aTopic) );

        /****************************************
         * Msg채번을 수행한다.
        ****************************************/
        memset_s (&sTopic, 0x00, sizeof(momTopicKey));
        strcpy_s (sTopic.mTopic, aTopic);

        _rc = dbmSelectForUpdateRow (aHandle, MOM_TOPIC_MASTER, &sTopic);
        if ( _rc != 0 )
        {
            _PRT( "Select fail (%s)\n", sTopic.mTopic );
            _THROW( _rc );
        }

        sTopic.mMsgID = sTopic.mMsgID + 1;
        sMsgID = sTopic.mMsgID;

        _CALL( dbmUpdateRow (aHandle, MOM_TOPIC_MASTER, &sTopic) );

        /****************************************
         * Master성 테이블에 넣어봐.
        ****************************************/
        memset_s (&sData, 0x00, 16);
        sData.mMsgID = sMsgID;
        sData.mSize  = aSize;
        memcpy_s (sData.mData, aUserData, aSize);

        _CALL( dbmInsertRow (aHandle, aTopic, (char*)&sData, (aSize + 16)) );

        /****************************************
         * 분배하는 놈에게 알려줘.
        ****************************************/
        _CALL( dbmEnqueue (aHandle, MOM_EVENT_FOR_DIS, (char*)&sTopic, sizeof(momTopicKey)) );

        /****************************************
         * 여기서 커밋해부려?? <== 요게 애매하당.
        ****************************************/
        _CALL( dbmCommit (aHandle) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
//        if ( pHandle != NULL )
//        {
//            pHandle->mError->mErrCode = _rc;
//        }
    }
    _END
}
