/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *     Error Message Management Class
 *******************************************************************************/
#include "dbmHeader.h"


/**
 * @brief   dbmGetError
 *
 * @param aCode     [IN] error code
 * @param aMsg      [OUT] error string
 * @return          aMsg ( 사용편의를 위해 OUT 결과 문자열의 주소를 반환
 *
 * @note            오류코드 관련 처리를 한군데서 하므로, common 모듈이지만, dbmXX 접두어를 부여.
 */
char* dbmGetError ( int aCode, char* aMsg )
{
    return cmnGetError( aCode, aMsg );
}

void dbmVersion ( )
{
    printf("REVISION = %s\n", __STR_REVISION);
    printf("BUILD_TIME = %s\n", __STR_BUILDTIME);
}

void dbmVersion ( char* aRev, char* aTime )
{
    strncpy_s( aRev, __STR_REVISION, 10);
    strncpy_s( aTime, __STR_BUILDTIME, 20);
}

/********************************************************************
 * ID : dbmGetErrorByHandle
 ********************************************************************/
//void dbmGetErrorByHandle ( dbmHandle* aHandle, char* aErrMsg )
//{
//    dbmInternalHandle *pHandle = NULL;
//
//    _TRY
//    {
//        if ( aHandle->mMark == DBM_HANDLE_MARK )
//        {
//            pHandle = (dbmInternalHandle*) aHandle->mHandle;
//            if ( pHandle != NULL )
//            {
//                pHandle->mError->mGetMessage ( aErrMsg );
//            }
//        }
//        else
//        {
//            sprintf ( aErrMsg, "This Handle is not valid. rc=%d (errno=%d)\n", _cmn_errno, errno );
//        }
//    }
//    _CATCH
//    _FINALLY
//    _ENDVOID
//}
