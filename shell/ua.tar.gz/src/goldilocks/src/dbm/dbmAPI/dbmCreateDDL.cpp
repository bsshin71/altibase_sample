/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *     DDL, PrepareTable 등 일회성 API
 *******************************************************************************/
#include "dbmHeader.h"
#include "dbmInternalHandle.h"

/******************************************************************************
 * static functions
******************************************************************************/
static int dbmDropTableLib ( dbmHandle* aHandle, const char* aTable, dbmTransType aTransType );


/********************************************************************
 * ID : dbmExecuteDDL
 ********************************************************************/
_VOID dbmExecuteDDL ( dbmHandle* aHandle, const char* aSQL )
{
    dbmInternalHandle* pHandle = NULL;

    _TRY
    {
        pHandle = (dbmInternalHandle*)aHandle->mHandle;

        // Water Mark가 다르면 걍 리턴해라.
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            DBM_ERR ( "invalide magic number (%ld)", aHandle->mMark );
            _THROW( ERR_DBM_INVALID_HANDLE );
        }

        if( pHandle->mRemote != NULL && pHandle->mRemote->mSockFd > 0 )
        {
            _CALL( dbmRemoteCreateDDL( aHandle, aSQL ) );
            _RETURN;
        }

        /****************************************
         * DataObject 맵핑.
        ****************************************/
        memset_s (&pHandle->mData, 0x00, sizeof(pHandle->mData));
        pHandle->mData.mTransType = DBM_NOT_DEFINED;
        pHandle->mData.mUserData  = (char*)aSQL;
        pHandle->mData.mDataSize  = strlen_s(aSQL);

        /****************************************
         * mAct 호출.
        ****************************************/
        DBM_WARN( "SQL : %s", aSQL );
        _CALL( pHandle->mTrans->mAct ( pHandle ) );
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_TABLE_NOT_IN_DICTIONARY || _rc == ERR_DBM_ALREADY_EXIST_IN_DIC )
        {
            _CATCH_INFO;
        }
        else
        {
            DBM_WARN( "DDL Error: aSQL=[%s]", aSQL );
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
}


_VOID dbmRemoteCreateDDL ( dbmHandle* aHandle, const char* aSQL )
{
    dbmInternalHandle*  sInternalH  = NULL;
    dbmRemoteHandle*    sRemoteH    = NULL;
    int                 sRealSize;
    int                 sUserDataSize;

    _TRY
    {
        sInternalH = (dbmInternalHandle*)aHandle->mHandle;
        sRemoteH   = (dbmRemoteHandle*)sInternalH->mRemote;

        /****************************************
         * Listener 로 Request Msg 전송
        ****************************************/
        memset_s (&sRemoteH->mMsg, 0x00, sizeof(dbmRemoteMsg));

        sRemoteH->mMsg.mMsgSize = sizeof(dbmRemoteMsg);
        sRemoteH->mMsg.mMsgType = DBM_NOT_DEFINED;
        strcpy_s( sRemoteH->mMsg.mInstName, sInternalH->mInstanceName );
        strncpy_s( sRemoteH->mMsg.mBody.mMsgBody.mUserData,
                  aSQL,
                  sUserDataSize = strlen_s(aSQL) );
        sRemoteH->mMsg.mBody.mMsgBody.mDataSize = sUserDataSize;

        _rc = cmnTcpSend( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          sRemoteH->mMsg.mMsgSize,
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_SEND_FAIL );


        /****************************************
         * Listener 로부터의 응답 처리
        ****************************************/
        _rc = cmnTcpRecv( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          0,   /* recv timeout */
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_RECV_FAIL );

        _IF_THROW( sRemoteH->mMsg.mBody.mMsgBody.mRC != RC_SUCCESS,
                   sRemoteH->mMsg.mBody.mMsgBody.mRC );
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_TABLE_NOT_IN_DICTIONARY || _rc == ERR_DBM_ALREADY_EXIST_IN_DIC )
        {
            _CATCH_INFO;
        }
        else
        {
            DBM_INFO( "SQL : %s", aSQL );
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
}


_VOID dbmRemoteGetHandleOption ( dbmHandle* aHandle, dbmHandleOption aOption, int *aValue )
{
    dbmInternalHandle*  sInternalH  = NULL;
    dbmRemoteHandle*    sRemoteH    = NULL;
    int                 sRealSize;
    int                 sUserDataSize;

    _TRY
    {
        sInternalH = (dbmInternalHandle*)aHandle->mHandle;
        sRemoteH   = (dbmRemoteHandle*)sInternalH->mRemote;

        /****************************************
         * Listener 로 Request Msg 전송
        ****************************************/
        memset_s (&sRemoteH->mMsg, 0x00, sizeof(dbmRemoteMsg));

        sRemoteH->mMsg.mMsgSize = sizeof(dbmRemoteMsg);
        sRemoteH->mMsg.mBody.mMsgBody.mOption = aOption ;


        _rc = cmnTcpSend( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          sRemoteH->mMsg.mMsgSize,
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_SEND_FAIL );


        /****************************************
         * Listener 로부터의 응답 처리
        ****************************************/
        _rc = cmnTcpRecv( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          0,   /* recv timeout */
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_RECV_FAIL );

        _IF_THROW( sRemoteH->mMsg.mBody.mMsgBody.mRC != RC_SUCCESS,
                   sRemoteH->mMsg.mBody.mMsgBody.mRC );

        *aValue = sRemoteH->mMsg.mBody.mMsgBody.mOptionVal;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/********************************************************************
 * ID : dbmGetOption
 ********************************************************************/
_VOID dbmGetHandleOption (dbmHandle* aHandle, dbmHandleOption aOption, int* aValue )
{
    dbmInternalHandle* pHandle = NULL;

    _TRY
    {
        pHandle = (dbmInternalHandle*)aHandle->mHandle;

        // Water Mark가 다르면 걍 리턴해라.
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            DBM_ERR ( "invalide magic number (%ld)", aHandle->mMark );
            _THROW( ERR_DBM_INVALID_HANDLE );
        }

        if( pHandle->mRemote != NULL && pHandle->mRemote->mSockFd > 0 )
        {
            _CALL( dbmRemoteGetHandleOption ( aHandle, aOption , aValue )  );
            _RETURN;
        }

        /****************************************
         * DataObject 맵핑.
        ****************************************/
        memset_s ( &pHandle->mData, 0x00, sizeof( pHandle->mData ) );
        pHandle->mData.mOption = aOption ;
        pHandle->mData.mTransType = DBM_GET_OPTION;

        /****************************************
         * mAct 호출.
        ****************************************/
        _CALL( pHandle->mTrans->mAct ( pHandle ) );
        *aValue = pHandle->mData.mOptionVal;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmRemoteSetHandleOption ( dbmHandle* aHandle, dbmHandleOption aOption, int aValue )
{
    dbmInternalHandle*  sInternalH  = NULL;
    dbmRemoteHandle*    sRemoteH    = NULL;
    int                 sRealSize;
    int                 sUserDataSize;

    _TRY
    {
        sInternalH = (dbmInternalHandle*)aHandle->mHandle;
        sRemoteH   = (dbmRemoteHandle*)sInternalH->mRemote;

        /****************************************
         * Listener 로 Request Msg 전송
        ****************************************/
        memset_s (&sRemoteH->mMsg, 0x00, sizeof(dbmRemoteMsg));

        sRemoteH->mMsg.mMsgSize = sizeof(dbmRemoteMsg);
        sRemoteH->mMsg.mBody.mMsgBody.mOption = aOption ;
        sRemoteH->mMsg.mBody.mMsgBody.mOptionVal = aValue ;


        _rc = cmnTcpSend( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          sRemoteH->mMsg.mMsgSize,
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_SEND_FAIL );


        /****************************************
         * Listener 로부터의 응답 처리
        ****************************************/
        _rc = cmnTcpRecv( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          0,   /* recv timeout */
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_RECV_FAIL );

        _IF_THROW( sRemoteH->mMsg.mBody.mMsgBody.mRC != RC_SUCCESS,
                   sRemoteH->mMsg.mBody.mMsgBody.mRC );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/********************************************************************
 * ID : dbmSetHandleOption
 ********************************************************************/
_VOID dbmSetHandleOption (dbmHandle* aHandle, dbmHandleOption aOption, int aValue )
{
    dbmInternalHandle* pHandle = NULL;

    _TRY
    {
        pHandle = (dbmInternalHandle*)aHandle->mHandle;

        // Water Mark가 다르면 걍 리턴해라.
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            DBM_ERR ( "invalide magic number (%ld)", aHandle->mMark );
            _THROW( ERR_DBM_INVALID_HANDLE );
        }

        if( pHandle->mRemote != NULL && pHandle->mRemote->mSockFd > 0 )
        {
            _CALL( dbmRemoteSetHandleOption( aHandle, aOption, aValue ) );
            _RETURN;
        }

        /****************************************
         * DataObject 맵핑.
        ****************************************/
        memset_s ( &pHandle->mData, 0x00, sizeof( pHandle->mData ) );
        pHandle->mData.mOption = aOption ;
        pHandle->mData.mTransType = DBM_SET_OPTION;
        pHandle->mData.mOptionVal = aValue;

        /****************************************
         * mAct 호출.
        ****************************************/
        _CALL( pHandle->mTrans->mAct ( pHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/********************************************************************
 * ID : dbmDropTable
 ********************************************************************/

/*
 * #914 중복함수 통함.
 * 2015.04.07 기준으로 볼때, 현재의 사용예로는, 아래처럼 xxLib 함수를 안 만들고
 * 예를 들면,
 * #define dbmDropIndex dbmDropTable
 * 이런식으로 할 수도 있지만. 외부 노출 함수이므로, 고객 소스 전체 컴파일 이슈도 있고.
 * 앞으로, 구분 처리할 요건이 생기면 '재 컴파일없이' 대응이 안되므로, 아래 같이 처리.
 *
 * 이와는 다르게, dbmRemoteDropQueue 함수등은 내부함수이므로, dbmRemoteDropTable하나로 그냥 통합해버림.
 * 나중에 필요하면 xxLib로 다시 만들면 됨.
 *
 * TODO:
 * !! 참고로, dbmDropList를 노출하게되면, 이건 dbmDropTable과 호환이 안될 것으로 보임. (현소스기준)
 *    구현시 가능하다면. dbmDropList도 dbmDropTable을 호출해도 무방하게 작성해야지 일관성이 있을듯.
 * !! dbmDropSeq는 만들게 되면. dbmDropTable 호출해도 무방함.
 *
 * ---->
 * 위와 같이 적을려고 하다가, dbmTruncate() 함수와의 이름 일관성 문제도 있고.
 * 이번 기회가 아니면 못 바꿀것 같아서. dbmDrop() 함수를 새로 만들고 #define 으로 결정함.
 */
int dbmDrop ( dbmHandle* aHandle, const char* aTable )
{
    return dbmDropTableLib( aHandle, aTable, DBM_DROP_TABLE );
}

#if 0
int dbmDropTable ( dbmHandle* aHandle, const char* aTable )
{
    return dbmDropTableLib( aHandle, aTable, DBM_DROP_TABLE );
}

int dbmDropIndex ( dbmHandle* aHandle, const char* aTable )
{
    return dbmDropTableLib( aHandle, aTable, DBM_DROP_INDEX );
}

int dbmDropQueue ( dbmHandle* aHandle, const char* aTable )
{
    return dbmDropTableLib( aHandle, aTable, DBM_DROP_QUEUE );
}

int dbmDropSeq ( dbmHandle* aHandle, const char* aTable )
{
    return dbmDropTableLib( aHandle, aTable, DBM_DROP_SEQUENCE );
}

//int dbmDropList ( dbmHandle* aHandle, const char* aTable )
//{
//    return dbmDropTableLib( aHandle, aTable, DBM_DROP_LIST );
//}
#endif

int dbmDropTableLib ( dbmHandle* aHandle, const char* aTable, dbmTransType aTransType )
{
    dbmInternalHandle* pHandle = NULL;

    _TRY
    {
        pHandle = (dbmInternalHandle*)aHandle->mHandle;

        // Water Mark가 다르면 걍 리턴해라.
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            DBM_ERR ( "invalide magic number (%ld)", aHandle->mMark );
            _THROW( ERR_DBM_INVALID_HANDLE );
        }

        // #618 dbmTransManager::mActDropTable 에서 검사하고 있으나, 여기서 먼저 체크.
        _IF_THROW( aTable[0] == '\0', ERR_DBM_INVALID_OBJECT_NAME );

        if( pHandle->mRemote != NULL && pHandle->mRemote->mSockFd > 0 )
        {
            _CALL( dbmRemoteDropTable( aHandle, aTable ) );
            _RETURN;
        }

        /****************************************
         * DataObject 맵핑.
        ****************************************/
        memset_s ( &pHandle->mData, 0x00, sizeof( pHandle->mData ) );
        memcpy_s ( pHandle->mData.mTableName, aTable, strlen_s ( aTable ) + 1 );
        // DBM_DROP_TABLE, DBM_DROP_QUEUE, DBM_DROP_INDEX
        pHandle->mData.mTransType = aTransType;

        /****************************************
         * mAct 호출.
        ****************************************/
        _CALL( pHandle->mTrans->mAct ( pHandle ) );
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_TABLE_NOT_IN_DICTIONARY )
        {
            _CATCH_INFO;
        }
        else
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
}


_VOID dbmRemoteDropTable ( dbmHandle* aHandle, const char* aTable )
{
    dbmInternalHandle*  sInternalH  = NULL;
    dbmRemoteHandle*    sRemoteH    = NULL;
    int                 sRealSize;
    int                 sUserDataSize;

    _TRY
    {
        sInternalH = (dbmInternalHandle*)aHandle->mHandle;
        sRemoteH   = (dbmRemoteHandle*)sInternalH->mRemote;

        /****************************************
         * Listener 로 Request Msg 전송
        ****************************************/
        memset_s (&sRemoteH->mMsg, 0x00, sizeof(dbmRemoteMsg));

        sRemoteH->mMsg.mMsgSize = sizeof(dbmRemoteMsg);

        /*
         * TODO: 2015.04.07 -okt-
         * #914 mMsgType 은 olsnr의 dbmProcCommand()에서, DBM_INIT_HANDLE인지 여부만 검사함.
         * 때문에 함수 통합 가능
         */
        sRemoteH->mMsg.mMsgType = DBM_DROP_TABLE;
        //sRemoteH->mMsg.mMsgType = DBM_DROP_QUEUE;
        //sRemoteH->mMsg.mMsgType = DBM_DROP_INDEX;

        strcpy_s( sRemoteH->mMsg.mInstName, sInternalH->mInstanceName );
        strcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mTableName, aTable );
        sRemoteH->mMsg.mBody.mMsgBody.mUserData[0] = '\0';
        sRemoteH->mMsg.mBody.mMsgBody.mDataSize = 0;

        _rc = cmnTcpSend( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          sRemoteH->mMsg.mMsgSize,
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_SEND_FAIL );


        /****************************************
         * Listener 로부터의 응답 처리
        ****************************************/
        _rc = cmnTcpRecv( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          0,   /* recv timeout */
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_RECV_FAIL );

        _IF_THROW( sRemoteH->mMsg.mBody.mMsgBody.mRC != RC_SUCCESS,
                   sRemoteH->mMsg.mBody.mMsgBody.mRC );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/********************************************************************
 * ID : dbmTruncate
 ********************************************************************/
int dbmTruncate ( dbmHandle* aHandle, const char* aTable )
{
    dbmInternalHandle* pHandle = NULL;

    _TRY
    {
        pHandle = (dbmInternalHandle*)aHandle->mHandle;

        // Water Mark가 다르면 걍 리턴해라.
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            DBM_ERR ( "invalide magic number (%ld)", aHandle->mMark );
            _THROW( ERR_DBM_INVALID_HANDLE );
        }

        if( pHandle->mRemote != NULL && pHandle->mRemote->mSockFd > 0 )
        {
            _CALL( dbmRemoteTruncate( aHandle, aTable ) );
            _RETURN;
        }

        /****************************************
         * DataObject 맵핑.
        ****************************************/
        memset_s( &pHandle->mData, 0x00, sizeof( pHandle->mData ) );
        memcpy_s ( pHandle->mData.mTableName, aTable, strlen_s ( aTable ) + 1 );
        pHandle->mData.mTransType = DBM_TRUNCATE;

        /****************************************
         * mAct 호출.
        ****************************************/
        DBM_WARN( "SQL : truncate table %s;", aTable );
        _CALL( pHandle->mTrans->mAct ( pHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmRemoteTruncate ( dbmHandle* aHandle, const char* aTable )
{
    dbmInternalHandle*  sInternalH  = NULL;
    dbmRemoteHandle*    sRemoteH    = NULL;
    int                 sRealSize;
    int                 sUserDataSize;

    _TRY
    {
        sInternalH = (dbmInternalHandle*)aHandle->mHandle;
        sRemoteH   = (dbmRemoteHandle*)sInternalH->mRemote;

        /****************************************
         * Listener 로 Request Msg 전송
        ****************************************/
        memset_s (&sRemoteH->mMsg, 0x00, sizeof(dbmRemoteMsg));

        sRemoteH->mMsg.mMsgSize = sizeof(dbmRemoteMsg);
        sRemoteH->mMsg.mMsgType = DBM_TRUNCATE;
        strcpy_s( sRemoteH->mMsg.mInstName, sInternalH->mInstanceName );
        strcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mTableName, aTable );
        sRemoteH->mMsg.mBody.mMsgBody.mUserData[0] = '\0';
        sRemoteH->mMsg.mBody.mMsgBody.mDataSize = 0;

        _rc = cmnTcpSend( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          sRemoteH->mMsg.mMsgSize,
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_SEND_FAIL );


        /****************************************
         * Listener 로부터의 응답 처리
        ****************************************/
        _rc = cmnTcpRecv( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          0,   /* recv timeout */
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_RECV_FAIL );

        _IF_THROW( sRemoteH->mMsg.mBody.mMsgBody.mRC != RC_SUCCESS,
                   sRemoteH->mMsg.mBody.mMsgBody.mRC );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/********************************************************************
 * ID : dbmGetIndex
 ********************************************************************/
int dbmGetIndex ( dbmHandle* aHandle, const char* aTable, char* aIndexName )
{
    dbmInternalHandle* pHandle = NULL;

    _TRY
    {
        pHandle = (dbmInternalHandle*)aHandle->mHandle;

        // Water Mark가 다르면 걍 리턴해라.
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            DBM_ERR ( "invalide magic number (%ld)", aHandle->mMark );
            _THROW( ERR_DBM_INVALID_HANDLE );
        }

        if( pHandle->mRemote != NULL && pHandle->mRemote->mSockFd > 0 )
        {
            _CALL( dbmRemoteGetIndex( aHandle, aTable, aIndexName ) );
            _RETURN;
        }


        /****************************************
         * DataObject 맵핑.
        ****************************************/
        memset_s( &pHandle->mData, 0x00, sizeof( pHandle->mData ) );
        memcpy_s ( pHandle->mData.mTableName, aTable, strlen_s ( aTable ) + 1 );
        pHandle->mData.mTransType = DBM_GET_INDEX;
        pHandle->mData.mUserData  = aIndexName;

        /****************************************
         * mAct 호출.
        ****************************************/
        _CALL( pHandle->mTrans->mAct ( pHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
} /* dbmGetIndex */


_VOID dbmRemoteGetIndex ( dbmHandle* aHandle, const char* aTable, char* aIndexName )
{
    dbmInternalHandle*  sInternalH  = NULL;
    dbmRemoteHandle*    sRemoteH    = NULL;
    int                 sRealSize;
    int                 sUserDataSize;

    _TRY
    {
        sInternalH = (dbmInternalHandle*)aHandle->mHandle;
        sRemoteH   = (dbmRemoteHandle*)sInternalH->mRemote;

        /****************************************
         * Listener 로 Request Msg 전송
        ****************************************/
        memset_s (&sRemoteH->mMsg, 0x00, sizeof(dbmRemoteMsg));

        sRemoteH->mMsg.mMsgSize = sizeof(dbmRemoteMsg);
        sRemoteH->mMsg.mMsgType = DBM_GET_INDEX;
        strcpy_s( sRemoteH->mMsg.mInstName, sInternalH->mInstanceName );
        strcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mTableName, aTable );
        strcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mUserData, aIndexName );
        sRemoteH->mMsg.mBody.mMsgBody.mDataSize = strlen_s(aIndexName);

        _rc = cmnTcpSend( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          sRemoteH->mMsg.mMsgSize,
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_SEND_FAIL );


        /****************************************
         * Listener 로부터의 응답 처리
        ****************************************/
        _rc = cmnTcpRecv( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          0,   /* recv timeout */
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_RECV_FAIL );

        _IF_THROW( sRemoteH->mMsg.mBody.mMsgBody.mRC != RC_SUCCESS,
                   sRemoteH->mMsg.mBody.mMsgBody.mRC );

        strcpy_s( aIndexName, sRemoteH->mMsg.mBody.mMsgBody.mUserData );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
} /* dbmRemoteGetIndex */


/********************************************************************
 * ID : dbmSetIndex
 ********************************************************************/
int dbmSetIndex ( dbmHandle* aHandle, const char* aTable, const char* aIndexName )
{
    dbmInternalHandle* pHandle = NULL;

    _TRY
    {
        pHandle = (dbmInternalHandle*)aHandle->mHandle;

        // Water Mark가 다르면 걍 리턴해라.
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            DBM_ERR ( "invalide magic number (%ld)", aHandle->mMark );
            _THROW( ERR_DBM_INVALID_HANDLE );
        }

        if( pHandle->mRemote != NULL && pHandle->mRemote->mSockFd > 0 )
        {
            _CALL( dbmRemoteSetIndex( aHandle, aTable, aIndexName ) );
            _RETURN;
        }

        /****************************************
         * DataObject 맵핑.
        ****************************************/
        memset_s( &pHandle->mData, 0x00, sizeof( pHandle->mData ) );
        memcpy_s ( pHandle->mData.mTableName, aTable, strlen_s ( aTable ) + 1 );
        pHandle->mData.mTransType = DBM_SET_INDEX;
        pHandle->mData.mUserData  = (char*)aIndexName;

        /****************************************
         * mAct 호출.
        ****************************************/
        _CALL( pHandle->mTrans->mAct ( pHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmRemoteSetIndex ( dbmHandle* aHandle, const char* aTable, const char* aIndexName )
{
    dbmInternalHandle*  sInternalH  = NULL;
    dbmRemoteHandle*    sRemoteH    = NULL;
    int                 sRealSize;
    int                 sUserDataSize;

    _TRY
    {
        sInternalH = (dbmInternalHandle*)aHandle->mHandle;
        sRemoteH   = (dbmRemoteHandle*)sInternalH->mRemote;

        /****************************************
         * Listener 로 Request Msg 전송
        ****************************************/
        memset_s (&sRemoteH->mMsg, 0x00, sizeof(dbmRemoteMsg));

        sRemoteH->mMsg.mMsgSize = sizeof(dbmRemoteMsg);
        sRemoteH->mMsg.mMsgType = DBM_SET_INDEX;
        strcpy_s( sRemoteH->mMsg.mInstName, sInternalH->mInstanceName );
        strcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mTableName, aTable );
        strcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mUserData, aIndexName);
        sRemoteH->mMsg.mBody.mMsgBody.mDataSize = strlen_s(aIndexName);

        _rc = cmnTcpSend( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          sRemoteH->mMsg.mMsgSize,
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_SEND_FAIL );


        /****************************************
         * Listener 로부터의 응답 처리
        ****************************************/
        _rc = cmnTcpRecv( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          0,   /* recv timeout */
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_RECV_FAIL );

        _IF_THROW( sRemoteH->mMsg.mBody.mMsgBody.mRC != RC_SUCCESS,
                   sRemoteH->mMsg.mBody.mMsgBody.mRC );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/********************************************************************
 * ID : dbmPrepareTable
 ********************************************************************/
int dbmPrepareTable ( dbmHandle* aHandle, const char* aTable )
{
    dbmInternalHandle* pHandle = NULL;

    _TRY
    {
        pHandle = (dbmInternalHandle*)aHandle->mHandle;

        // Water Mark가 다르면 걍 리턴해라.
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            DBM_ERR ( "invalide magic number (%ld)", aHandle->mMark );
            _THROW( ERR_DBM_INVALID_HANDLE );
        }

        if( pHandle->mRemote != NULL && pHandle->mRemote->mSockFd > 0 )
        {
            _CALL( dbmRemotePrepareTable( aHandle, aTable ) );
            _RETURN;
        }

        /****************************************
         * Prepare 호출.
        ****************************************/
        _CALL( pHandle->mTrans->mPrepareTable ( (char*)aTable ) );
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_TABLE_NOT_IN_DICTIONARY )
        {
            _CATCH_DBG2( aTable );
        }
        else
        {
            _CATCH_WARN2( aTable );
        }
    }
    _FINALLY
    _END
}

_VOID dbmRemotePrepareTable ( dbmHandle* aHandle, const char* aTable )
{
    int                 i;
    int                 sMallocedCount = 0;
    int                 sFirstNotAlloced = -1;
    dbmInternalHandle*  sInternalH  = NULL;
    dbmRemoteHandle*    sRemoteH    = NULL;
    int                 sRealSize;
    int                 sUserDataSize;

    _TRY
    {
        sInternalH = (dbmInternalHandle*)aHandle->mHandle;
        sRemoteH   = (dbmRemoteHandle*)sInternalH->mRemote;

        /****************************************
         * Listener 로 Request Msg 전송
        ****************************************/
        memset_s (&sRemoteH->mMsg, 0x00, sizeof(dbmRemoteMsg));

        sRemoteH->mMsg.mMsgSize = sizeof(dbmRemoteMsg);
        sRemoteH->mMsg.mMsgType = DBM_PREPARE_TABLE;
        strcpy_s( sRemoteH->mMsg.mInstName, sInternalH->mInstanceName );
        strcpy_s( sRemoteH->mMsg.mBody.mMsgBody.mTableName, aTable );

        _rc = cmnTcpSend( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          sRemoteH->mMsg.mMsgSize,
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_SEND_FAIL );


        /****************************************
         * Listener 로부터의 응답 처리
        ****************************************/
        _rc = cmnTcpRecv( sRemoteH->mSockFd,
                          (char*)&sRemoteH->mMsg,
                          0,   /* recv timeout */
                          (int*)&sRealSize );

        _IF_THROW( _rc != RC_SUCCESS, ERR_DBM_REMOTE_DATA_RECV_FAIL );

        _IF_THROW( sRemoteH->mMsg.mBody.mMsgBody.mRC != RC_SUCCESS,
                   sRemoteH->mMsg.mBody.mMsgBody.mRC );


        /****************************************
         * 성공일 경우 listener 로부터 수신한 RowSize 정보를
         * Handle 내에 저장해둔다.
        ****************************************/
        for(i=0; i<sRemoteH->mTableCount; i++)
        {
            if( !strcmp(sRemoteH->mMsg.mBody.mMsgBody.mTableName,
                        sRemoteH->mTable[i].mTableName)
             || sRemoteH->mTable[i].mTableName[0] == '\0' )
            {
                sRemoteH->mTable[i].mRowSize = *(int*)sRemoteH->mMsg.mBody.mMsgBody.mUserData;
                break;
            }
        }

        if( i >= sRemoteH->mTableCount )
        {
            _IF_THROW( i>= DBM_MAX_TABLE_PER_TRANS, ERR_DBM_EXCEED_TABLE_PER_TX );

            sRemoteH->mTable[i+1].mRowSize = *(int*)sRemoteH->mMsg.mBody.mMsgBody.mUserData;
            strcpy_s( sRemoteH->mTable[i+1].mTableName, sRemoteH->mMsg.mBody.mMsgBody.mTableName );
            sRemoteH->mTableCount++;
        }
    }
    _CATCH
    {
        _CATCH_ERR2( aTable );
    }
    _FINALLY
    _END
}
