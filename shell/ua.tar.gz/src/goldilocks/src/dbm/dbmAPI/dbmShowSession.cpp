/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *     Error Message Management Class
 *******************************************************************************/
#include "dbmHeader.h"

#define sEnum2Str(a) #a

/******************************************************************************
 * Name : LogType2Str
 *
 * Description : 로그 타입을 화면에 출력하기 위해 enum으로 정의된 타입을 영문으로 돌려준다.
 *
 ******************************************************************************/
char* LogType2Str( dbmLogType aLogType )
{
    switch( aLogType )
    {
        case DBM_ALLOC_SLOT_LOG :
            return ( char* )sEnum2Str( DBM_ALLOC_SLOT );
        case DBM_ALLOC_IDX_SLOT_LOG :
            return ( char* )sEnum2Str( DBM_ALLOC_IDX_SLOT );
        case DBM_FREE_SLOT_LOG :
            return ( char* )sEnum2Str( DBM_FREE_SLOT );
        case DBM_INSERT_SLOT_LOG :
            return ( char* )sEnum2Str( DBM_INSERT_SLOT );
        case DBM_UPDATE_SLOT_LOG :
            return ( char* )sEnum2Str( DBM_UPDATE_SLOT );
        case DBM_UPDATE_KEY_LOG :
            return ( char* )sEnum2Str( DBM_UPDATE_KEY );
        case DBM_DELETE_SLOT_LOG :
            return ( char* )sEnum2Str( DBM_DELETE_SLOT );
        case DBM_INSERT_INDEX_LOG :
            return ( char* )sEnum2Str( DBM_INSERT_INDEX );
        case DBM_INSERT_INDEX_LOG2 :
            return ( char* )sEnum2Str( DBM_INSERT_INDEX );
        case DBM_DELETE_INDEX_LOG :
            return ( char* )sEnum2Str( DBM_DELETE_INDEX );
        case DBM_DELETE_INDEX_LOG2 :
            return ( char* )sEnum2Str( DBM_DELETE_INDEX2 );
        case DBM_DELETE_DATA_LOG :
            return ( char* )sEnum2Str( DBM_DELETE_DATA );
        case DBM_SELECT_FOR_UPDATE_LOG:
            return ( char* )sEnum2Str( DBM_SELECT_FOR_UPDATE );
        case DBM_TRUNCATE_LOG :
            return ( char* )sEnum2Str( DBM_TRUNCATE );
        case DBM_ENQUE_LOG :
            return ( char* )sEnum2Str( DBM_ENQUE );
        case DBM_DEQUE_LOG :
            return ( char* )sEnum2Str( DBM_DEQUE );
        case DBM_DDL_CREATE_QUEUE_LOG :
            return ( char* )sEnum2Str( DBM_DDL_CREATE_QUE );
        case DBM_DDL_CREATE_LIST_LOG :
            return ( char* )sEnum2Str( DBM_DDL_LIST_QUE );
        case DBM_DDL_CREATE_TABLE_LOG :
            return ( char* )sEnum2Str( DBM_DDL_CREATE_TABLE );
        case DBM_DDL_CREATE_DIRECT_LOG:
            return ( char* )sEnum2Str( DBM_DDL_CREATE_DIRECT );
        case DBM_DDL_DROP_TABLE_LOG :
            return ( char* )sEnum2Str( DBM_DDL_DROP_TABLE );
        case DBM_DDL_CREATE_INDEX_LOG :
            return ( char* )sEnum2Str( DBM_DDL_CREATE_INDEX );
        case DBM_DDL_DROP_INDEX_LOG :
            return ( char* )sEnum2Str( DBM_DDL_DROP_INDEX );
        case DBM_DDL_DROP_TRIG_LOG :
            return ( char* )sEnum2Str( DBM_DDL_DROP_TRIG );
        case DBM_DDL_CREATE_TRIG_LOG :
            return ( char* )sEnum2Str( DBM_DDL_CREATE_TRIG );
        case DBM_DDL_DROP_USER_LOG :
            return ( char* )sEnum2Str( DBM_DDL_DROP_USER );
        case DBM_LOCK_ROW_LOG :
            return ( char* )sEnum2Str( DBM_LOCK_ROW );
        case DBM_DEFER_INSERT_LOG :
            return ( char* )sEnum2Str( DBM_DEFER_INSERT );
        case DBM_DEFER_UPDATE_LOG :
            return ( char* )sEnum2Str( DBM_DEFER_UPDATE );
        case DBM_BEGIN_TX_LOG :
            return ( char* )sEnum2Str( DBM_BEGIN_TX );
        case DBM_REPL_COMMIT_LOG :
            return ( char* )sEnum2Str( DBM_REPL_COMMIT );
        case DBM_REPL_ROLLBACK_LOG :
            return ( char* )sEnum2Str( DBM_REPL_ROLLBACK );
        case DBM_COMMIT_LOG :
            return ( char* )sEnum2Str( DBM_COMMIT );
        case DBM_ROLLBACK_LOG :
            return ( char* )sEnum2Str( DBM_ROLLBACK );
        case DBM_COMMIT_ACK_LOG :
            return ( char* )sEnum2Str( DBM_COMMIT_ACK );
        case DBM_CLEAR_DEFER_LOG :
            return ( char* )sEnum2Str( DBM_CLEAR_DEFER );
        case DBM_DEQUE_CONFIRM_LOG :
            return ( char* )sEnum2Str( DBM_DEQUE_CONFIRM );
        case DBM_DUMMY_ACK_LOG :
            return ( char* )sEnum2Str( DBM_DUMMY_ACK );
        case DBM_SET_INDEX_LOG :
            return ( char* )sEnum2Str( DBM_SET_INDEX );
        default:
            return ( char* )sEnum2Str( OTHER );
    }
}

/******************************************************************************
 * Name : dbmPrintSession
 *
 * Description : 지정한 UNDO에 붙은 세션의 상태를 출력한다. (metaMgr 전용)
 *
 ******************************************************************************/
_VOID dbmPrintSession ( dbmSegmentManager* aUndoMgr, dbmTransHeader* aTXH, int aSID )
{
    char                sType[32];
    dbmLogHeader*       sLogPos     = NULL;
    long long           sCurPos;
    long long           sLogCurPos;
    int                 sSN         = 0;
    int                 sPID        = 0;
    int                 sRet        = 0;

    _TRY
    {
        /**************************************************************
         * 출력하는 동안 해당 세션의 상태가 전이되어 세션의 mLogCurPos 값이 바뀔 수 있기 때문에 미리 받아둔다.
         * 후에 이 값을 기준으로 처리를 마무리 한다.
         **************************************************************/
        sLogCurPos = mvpAtomicGet64( &aTXH->mLogCurPos );
        //printf("LogCurPos : %ld\n", sLogCurPos );
        //if ( aTXH->mStatus != DBM_TX_FREE && sLogCurPos != -1 )
        /**************************************************************
         * 세션의 PID를 알기 때문에 세션이 살았는지 죽었는지 알 수 있다.
         * 표시해줄까?
         **************************************************************/
        sPID = mvpAtomicGet32( &aTXH->mPID );

        /**************************************************************
         * 세션의 상태를 출력한다.
         **************************************************************/
        _PRT( "[ SID : %4lld  PID    : %-6d  ", aTXH->mSessionID, sPID );
        memset_s( sType, 0x00, sizeof(sType) );
        switch( aTXH->mStatus )
        {
            case DBM_TX_FREE:
                strncpy( sType, "DBM_TX_FREE", sizeof("DBM_TX_FREE") );
                break;
            case DBM_TX_ALLOC:
                strncpy( sType, "DBM_TX_ALLOC", sizeof("DBM_TX_ALLOC") );
                break;
            case DBM_TX_LOG_WAIT:
                strncpy( sType, "DBM_TX_LOG_WAIT", sizeof("DBM_TX_LOG_WAIT") );
                break;
            case DBM_TX_LOGGING:
                strncpy( sType, "DBM_TX_LOGGING", sizeof("DBM_TX_LOGGING") );
                break;
            case DBM_TX_COMMIT:
                strncpy( sType, "DBM_TX_COMMIT", sizeof("DBM_TX_COMMIT") );
                break;
            case DBM_TX_ROLLBACK:
                strncpy( sType, "DBM_TX_ROLLBACK", sizeof("DBM_TX_ROLLBACK") );
                break;
            default:
                strncpy( sType, "OTHER", sizeof("OTHER") );
                break;
        }
        _PRT( "STATUS : %-16s ", sType );
        _PRT( "WAIT_FOR_TX : %6d " , aTXH->mWaitForTransID ) ;

        if ( tkill_s(sPID, 0) && errno == ESRCH )
        {
            _PRT( "(DEACTIVE) ]\n");
        }
        else
        {
            _PRT( "(ACTIVE)   ]\n");
        }

        if ( (aTXH->mLogCurPos >> 32) == -1 || (aTXH->mLogStartPos >> 32) == -1 )
        {
            _RETURN;
        }

        /**************************************************************
         * 무한대기 상태를 방지하기 위한 코드
         **************************************************************/
        if ( sLogCurPos == -1 )
        {
            //printf("LogCurPos : %ld\n", sLogCurPos );
            _RETURN;
        }

        sCurPos = aTXH->mLogStartPos;
        while(1)
        {
            sRet = dbmRecoveryManager::mGetLogPtr( aUndoMgr, sCurPos, &sLogPos );
            if ( unlikely( sRet ) ) // 2014.11.18. -okt- 중복검사 제거.
            {
                dbmRecoveryManager::mDumpTxHeader( (char *)aTXH );
                DBM_ERR("ERR-%d] Invalid undo log.", ERR_DBM_INVALID_LOG);
                continue;
            }

            //printf( "rollback : %d, valid : %d", sLogPos->mRollbackCompleteF, sLogPos->mLogValidF );
            if ( sLogPos->mRollbackCompleteF == 1 || sLogPos->mLogValidF != 1 )
                //if ( sLogPos->mLogValidF != 1 )
            {
                //dbmRecoveryManager::mDumpTxHeader( (char *)aTXH );
                //DBM_ERR("ERR-%d] Invalid undo log.", ERR_DBM_INVALID_LOG);
                continue;
            }

            memset_s( sType, 0x00, sizeof(sType) );
            strncpy( sType, LogType2Str(sLogPos->mLogType), strlen_s(LogType2Str(sLogPos->mLogType)) );
            _PRT( "  +SN : %4d  OBJECT : %-*s  LOG_TYPE : %-*s SLOT_ID : %lld\n", sSN, DBM_NAME_LEN + 1, sLogPos->mObjectName, DBM_NAME_LEN + 1, sType, sLogPos->mRefRecord );

            //printf( "CurPos : %ld, LogCurPos : %ld, HeaderLogCurPos : %ld\n", sCurPos, sLogCurPos, aTXH->mLogCurPos );
            if ( sCurPos == sLogCurPos )
            {
                _PRT( "\n" );
                break;
            }

            sRet = dbmLogManager::mLogMoveForward( aUndoMgr, aTXH, &sCurPos );
            if ( sRet )
            {
                //dbmRecoveryManager::mDumpTxHeader( (char *)aTXH, aLogHandle );
                DBM_ERR( "ERR-%d] Invalid undo log slot list.", ERR_DBM_INVALID_LOG_SLOT_LIST );
                continue;
            }
            sSN++;
        }
    }
    _CATCH
    _FINALLY
    _END
}

/******************************************************************************
 * Name : dbmShowSession
 *
 * Description : 지정한 UNDO에 붙은 세션의 상태를 출력한다. (metaMgr 전용)
 *
 ******************************************************************************/
_VOID dbmShowSession ( char* aUndoName, int aSID )
{
    dbmSegmentManager*  sUndoMgr    = NULL;
    dbmTransTable*      sTBL        = NULL;
    dbmTransHeader*     sTXH        = NULL;
    int                 sActSessCnt = 0;
    int                 i           = 0;

    _TRY
    {
        /**************************************************************
         * UNDO에 붙는다.
         **************************************************************/
        _CALL( dbmSegmentManager::Attach( aUndoName, aUndoName, &sUndoMgr ) );
        //_IF_RAISE( sRet || sUndoMgr == NULL, UNDOSEG_ATTACH_FAIL );

        sTBL = ( dbmTransTable* )sUndoMgr->GetUserHeader();
        if ( sTBL == NULL ) //, UNDOSEG_ATTACH_FAIL );
        {
            DBM_ERR( "attach undo seg(%s) fail. errno(%d)", aUndoName, errno);
            _THROW( ERR_DBM_ATTACH_SHM_FAIL );
        }

        if( aSID == -1 )
        {
            /**************************************************************
             * 최대 트랜잭션 개수만큼 돌면서 동작중인 놈을 확인하고 출력한다.
             **************************************************************/
            for( i = 0; i < DBM_MAX_TRANS ; i++ )
            {
                sTXH= &sTBL->mItem[i];
                if ( sTXH->mStatus != DBM_TX_FREE )
                {
                    sActSessCnt++;
                    dbmPrintSession( sUndoMgr, sTXH, i );
                }
            }

            if ( sActSessCnt == 0 )
            {
                _PRT( "no session attached to current instance(%s).\n", aUndoName );
            }
        }
        else
        {
            sTXH= &sTBL->mItem[aSID];
            if ( sTXH->mStatus != DBM_TX_FREE )
            {
                dbmPrintSession( sUndoMgr, sTXH, aSID );
            }
            else
            {
                _PRT( "no session log in current instance(%s).\n", aUndoName );
            }
        }

        delete_s( sUndoMgr );   // 이런게 _FINALLY 에 들어갈만한 예제다.
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* dbmShowSession */
