/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *     Error Message Management Class
 *******************************************************************************/
#include "dbmHeader.h"

/********************************************************************
 * ID : dbmInitHandleRepl
 ********************************************************************/
_VOID dbmInitHandleRepl ( dbmHandle* aHandle , const char* aUndoName )
{
    dbmInternalHandle * pHandle = NULL;
    static char sTestRemotePortPre[8] = { 0, };
    char*   sTestRemotePort = NULL;
    int     sRC;

    _TRY
    {
retry:

        // 2014.12.14. -okt- [valgrind] Conditional jump or move depends on uninitialised value(s) [PID: 25976]
        //                   방법은 dbmInitHandle 개념을 dbmAllocHandle 개념으로 바꿔야함. 굳이하자면..
        if( aHandle->mMark == DBM_HANDLE_MARK ) // 핸들 유효성 (MAGIC_NUMBER) 체크
        {
            return( ERR_DBM_INIT_HANDLE_FAIL ); // 여기서는 _THROW( ERR_DBM_INIT_HANDLE_FAIL ) 하면 안된다.
        }


        /****************************************************
         * 사용할 Handle을 할당한다.
         ****************************************************/
        aHandle->mHandle = malloc_s ( sizeof(dbmInternalHandle) );

        // TODO: 2개 쓰레드가 동시에 같은 핸들 변수도 진입할수 있다. ( 사용자 실수이지만 debug 버전이라도 감지 가능하면 좋다.. 무시 )
        // Handle Mark를 표기한다.
        aHandle->mMark = DBM_HANDLE_MARK;
        aHandle->mDummy = 0xFF;

        // 이하코드에서 좀 편하게 쓰기 위해 맵핑.
        pHandle = (dbmInternalHandle*) aHandle->mHandle;
        memset_s ( pHandle, 0x00, sizeof(dbmInternalHandle) );

        // 에러Code용
        // TODO: may can be remove..
        pHandle->mError = new cmnErrorManager ( );


        /****************************************************
         * Handle내에 UndoName을 일단 갖고 간다.
         ****************************************************/
        if ( aUndoName != NULL )
        {
            cmnStrCpy ( pHandle->mInstanceName, aUndoName, sizeof(pHandle->mInstanceName) );
        }
        else
        {
            cmnStrCpy ( pHandle->mInstanceName, DBM_DEFAULT_UNDO_NAME, sizeof(pHandle->mInstanceName) );
        }

        _CALL( dbmInitSess ( pHandle, DBM_REPL_CONNECT ) );       // Sess Object
        _CALL( dbmLoadConfig ( pHandle ) );     // Configuration Loading
        _CALL( dbmInitTrans ( pHandle ) );      // Undo Name셋팅.
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_INVALID_UNDO_NAME )
        {
            _CATCH_WARN2( pHandle->mInstanceName );
        }
        else
        {
            _CATCH_ERR2( pHandle->mInstanceName );
        }

        if ( aHandle->mHandle != NULL )
        {
//            ((dbmInternalHandle*)aHandle->mHandle)->mError->mErrCode = ERR_DBM_INIT_HANDLE_FAIL;
//            if( pHandle->mError->mErrCode != ERR_DBM_USER_HANDLE_ALREADY_ALLOC )
            {
                dbmFreeHandle ( aHandle );
            }
        }

        return ERR_DBM_INIT_HANDLE_FAIL;
    }
    _FINALLY
    _END
} /* dbmInitHandle */

/********************************************************************
 * ID : dbmInitHandle
 ********************************************************************/
_VOID dbmInitHandle ( dbmHandle* aHandle , const char* aUndoName )
{
    dbmInternalHandle * pHandle = NULL;
    static char sTestRemotePortPre[8] = { 0, };
    char*   sTestRemotePort = NULL;
    int     sRC;

    _TRY
    {
retry:
        /****************************************************
         * Remote C/S Test 를 위해서 환경변수를 설정했으면
         * 자동으로 dbmConnect 를 실행하는 모드로...
         * -> TestCase 들마다 전부 dbmConnect 를 고려하는 것이
         *    너무 귀찮아서...
         * -> 어차피 Local 에서 Testcase 를 돌려야하고 Port 만
         *    설정하도록...
         ****************************************************/
        if ( unlikely( sTestRemotePortPre[0] == 0 && ( sTestRemotePort = getenv( ENV_DBM_TEST_REMOTE_PORT ) ) != NULL ) )
        {
            char* sTestRemoteIP = "127.0.0.1";

            if ( getenv( ENV_DBM_TEST_REMOTE_IP ) != NULL )
            {
                sTestRemoteIP = getenv( ENV_DBM_TEST_REMOTE_IP );
            }

            sRC = dbmConnect ( aHandle, aUndoName, aUndoName, sTestRemoteIP, sTestRemotePort );
            if ( sRC == 0 )
            {
                _RETURN;
            }
            else
            {
                // 2014.10.20 -okt- 테스트 편의상 동일 장비이면 initdb를 metaManager에서 수행할 수 있도록
                // TODO: 2014.11.14 -okt- 릴리즈모드에서도 테스트 (임시성)
#if 1 //def _DEBUG
                if ( getenv( ENV_DBM_TEST_REMOTE_PORT ) != NULL )
                {
                    if ( sRC == ERR_DBM_INIT_HANDLE_FAIL )
                    {
                        // 혹시 나중에 unset, setenv를 해줄 필요가 생길까봐 임시변수에 값을 저장
                        cmnStrCpy( sTestRemotePortPre, getenv( ENV_DBM_TEST_REMOTE_PORT ), sizeof(sTestRemotePortPre) );
                        DBM_ERR( "dbmConnect Fail. retry. (%s)\n", getenv ( "_" ) );
                        goto retry;
                    }
                }
#endif
                _THROW( sRC );
            }
        }


        // 2014.12.14. -okt- [valgrind] Conditional jump or move depends on uninitialised value(s) [PID: 25976]
        //                   방법은 dbmInitHandle 개념을 dbmAllocHandle 개념으로 바꿔야함. 굳이하자면..
        if( aHandle->mMark == DBM_HANDLE_MARK ) // 핸들 유효성 (MAGIC_NUMBER) 체크
        {
            return( ERR_DBM_INIT_HANDLE_FAIL ); // 여기서는 _THROW( ERR_DBM_INIT_HANDLE_FAIL ) 하면 안된다.
        }


        /****************************************************
         * 사용할 Handle을 할당한다.
         ****************************************************/
        aHandle->mHandle = malloc_s ( sizeof(dbmInternalHandle) );

        // TODO: 2개 쓰레드가 동시에 같은 핸들 변수도 진입할수 있다. ( 사용자 실수이지만 debug 버전이라도 감지 가능하면 좋다.. 무시 )
        // Handle Mark를 표기한다.
        aHandle->mMark = DBM_HANDLE_MARK;
        aHandle->mDummy = 0xFF;

        // 이하코드에서 좀 편하게 쓰기 위해 맵핑.
        pHandle = (dbmInternalHandle*) aHandle->mHandle;
        memset_s ( pHandle, 0x00, sizeof(dbmInternalHandle) );

        // 에러Code용
        // TODO: may can be remove..
        pHandle->mError = new cmnErrorManager ( );


        /****************************************************
         * Handle내에 UndoName을 일단 갖고 간다.
         ****************************************************/
        if ( aUndoName != NULL )
        {
            cmnStrCpy ( pHandle->mInstanceName, aUndoName, sizeof(pHandle->mInstanceName) );
        }
        else
        {
            cmnStrCpy ( pHandle->mInstanceName, DBM_DEFAULT_UNDO_NAME, sizeof(pHandle->mInstanceName) );
        }

        _CALL( dbmInitSess ( pHandle, DBM_LOCAL_CONNECT ) );       // Sess Object
        _CALL( dbmLoadConfig ( pHandle ) );     // Configuration Loading
        _CALL( dbmInitTrans ( pHandle ) );      // Undo Name셋팅.
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_INVALID_UNDO_NAME )
        {
            _CATCH_WARN2( pHandle->mInstanceName );
        }
        else
        {
            _CATCH_ERR2( pHandle->mInstanceName );
        }

        if ( aHandle->mHandle != NULL )
        {
//            ((dbmInternalHandle*)aHandle->mHandle)->mError->mErrCode = ERR_DBM_INIT_HANDLE_FAIL;
//            if( pHandle->mError->mErrCode != ERR_DBM_USER_HANDLE_ALREADY_ALLOC )
            {
                dbmFreeHandle ( aHandle );
            }
        }

        return ERR_DBM_INIT_HANDLE_FAIL;
    }
    _FINALLY
    _END
} /* dbmInitHandle */


/********************************************************************
 * ID : dbmFreeHandle
 ********************************************************************/
_VOID dbmFreeHandle ( dbmHandle* aHandle )
{
    int     i;
    dbmInternalHandle* pHandle = NULL;

    _TRY
    {
        // Water Mark가 다르면 걍 리턴해라.
        if ( unlikely ( aHandle->mMark != DBM_HANDLE_MARK ) )
        {
            _rc = RC_SUCCESS;
            _RETURN;
        }

        /****************************************
         * 내부 변수로 맵핑
        ****************************************/
        pHandle = (dbmInternalHandle*)aHandle->mHandle;
        if ( pHandle->mTrans != NULL )
        {
            _CALL( pHandle->mTrans->mFinalTran() );
        }

        /****************************************
         * 로그 열렸으면 닫아라.
        ****************************************/
        if ( pHandle->mDic != NULL )
        {
            delete_s( pHandle->mDic );
        }

        if ( pHandle->mConf != NULL )
        {
            delete_s( pHandle->mConf );
        }

        if ( pHandle->mTrans != NULL )
        {
            delete_s( pHandle->mTrans );
        }

        if ( pHandle->mBindParam != NULL )
        {
            free_s( pHandle->mBindParam );
        }

        if ( pHandle->mError != NULL )
        {
            delete_s( pHandle->mError );
        }

        if ( pHandle->mRemote != NULL )
        {
            if( pHandle->mRemote->mSockFd > 0 )
            {
                cmnTcpClose( pHandle->mRemote->mSockFd );
            }

            free_s( pHandle->mRemote );
        }

        free_s( aHandle->mHandle );

#if 1
        aHandle->mMark = DBM_NOT_USED;
        aHandle->mDummy = 0xFF;
        aHandle->mHandle = NULL;
#else
        // TODO: [OKT] extended initializer lists only available with -std=c++11 or -std=gnu++11 [enabled by default]
        *aHandle = DBM_HANDLE_INITIALIZER;
#endif
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/********************************************************************
 * ID : dbmInitSess
 ********************************************************************/
_VOID dbmInitSess ( dbmInternalHandle* aHandle,
                    dbmConnType        aConnType )
{
    _TRY
    {
//        aHandle->mDic = new dbmDictionary();
//        _IF_THROW( aHandle->mDic == NULL, RC_FAILURE );
//
//        _CALL( aHandle->mDic->mAttach () );

        aHandle->mBindParam = (char*) malloc_s ( DBM_MAX_RECORD_SIZE );
        _IF_THROW( aHandle->mBindParam == NULL, -1 /* MALLOC_PARAM_FAIL */ );

#if 1
        aHandle->mSess.mSessionID = 1;
#else
        aHandle->mSess.mSessionID = DBM_NOT_USED;
#endif
        aHandle->mSess.mPID       = gettid_s ();
        aHandle->mSess.mConnType  = aConnType;
        gettimeofday ( &aHandle->mSess.mConnectTime, NULL );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/********************************************************************
 * ID : dbmInitTrans
 ********************************************************************/
_VOID dbmInitTrans (dbmInternalHandle* aHandle)
{
    _TRY
    {
        /***************************************
         * Trans 객체 생성
         ***************************************/
        aHandle->mTrans = new dbmTransManager ( );
        _IF_THROW( aHandle->mTrans == NULL, -1 );

        /***************************************
         * 최초 1번만 호출한다.
         ***************************************/
        _CALL( aHandle->mTrans->mInitTran ( aHandle->mInstanceName, &aHandle->mSess, aHandle->mConf ) );
    }
    _CATCH
    {
//        _CATCH_WARN2( aHandle->mInstanceName );
    }
    _FINALLY
    _END
}


/********************************************************************
 * ID : dbmLoadConfig
 ********************************************************************/
_VOID dbmLoadConfig ( dbmInternalHandle* aHandle )
{
    _TRY
    {
        /*************************************************
         * Configuration Class init
        *************************************************/
        aHandle->mConf = new dbmConfig();
        _IF_THROW( aHandle->mConf == NULL, -1 );

        /*************************************************
         * COMMON Load
        *************************************************/
        _CALL( aHandle->mConf->mLoad (DBM_COMMON_SECTION) );

        /*************************************************
         * User Load
        *************************************************/
        _CALL( aHandle->mConf->mLoad (aHandle->mInstanceName) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmConnect ( dbmHandle*   aHandle,
                   const char*  aInstName,  // instance name
                   const char*  aUser,      // instance name 과 같이 준다
                   const char*  aIP,
                   const char*  aPort )
{
    dbmInternalHandle* pHandle = NULL;
    int     sSockFd = -1;
    int     sMsgSize  = 0;
    int     sRealSize = 0;
    int     sConnectRetryCount = 0;
    int     sRC;

    _TRY
    {
#if defined(__MINGW32__) || defined(__MINGW64__)
    	WSADATA wsaData;
    	sRC = WSAStartup(MAKEWORD(2,2), &wsaData);
#endif
        _IF_THROW( aInstName == NULL, ERR_DBM_INVALID_ARGUENT );
        _IF_THROW( aIP == NULL,       ERR_DBM_INVALID_ARGUENT );
        _IF_THROW( aPort == NULL,     ERR_DBM_INVALID_ARGUENT );

        if( aHandle->mMark == DBM_HANDLE_MARK )
        {
            return( ERR_DBM_INIT_HANDLE_FAIL ); // 여기서는 _THROW( ERR_DBM_INIT_HANDLE_FAIL ) 하면 안된다.
        }


        /****************************************************
         * Listner 쪽으로 Connect.
         ****************************************************/
        //TODO: 2014.11.17 -okt- Tcpconnect 옵션 하드코딩. 최소 DEFINE으로
        //_rc = cmnTcpConnect( &sSockFd, (char*)aIP, atoi(aPort), 0, 3, 4096*2 );
        _rc = cmnTcpConnect( &sSockFd, (char*)aIP, atoi(aPort), 0 ); //, 4096*2, 3 );
        if( _rc != 0 )
        {
            DBM_WARN( "Remote Connect Fail. ip[%s] port[%s] _rc[%d] err[%s]",
                    aIP, aPort, _rc, strerror(errno));
            _THROW( ERR_DBM_REMOTE_CONNECT_FAIL );
        }

        DBM_INFO( "Remote Connect. ip[%s] port[%s]", aIP, aPort);


        /****************************************************
         * 사용할 Handle을 할당한다.
         ****************************************************/
        aHandle->mHandle = malloc_s ( sizeof(dbmInternalHandle) );

        aHandle->mMark = DBM_HANDLE_MARK;
        aHandle->mDummy = 0xFF;

        pHandle = (dbmInternalHandle*) aHandle->mHandle;
        memset_s ( pHandle, 0x00, sizeof(dbmInternalHandle) );

        pHandle->mRemote = (dbmRemoteHandle*)malloc_s(sizeof(dbmRemoteHandle));
        _IF_THROW( pHandle->mRemote == NULL, ERR_DBM_MEM_ALLOC );

        pHandle->mRemote->mSockFd     = sSockFd;
        pHandle->mRemote->mTableCount = 0;
        memset_s ( pHandle->mRemote->mTable, 0x00, sizeof(dbmRemoteTableInfo) * DBM_MAX_TABLE_PER_TRANS );

        pHandle->mError = new cmnErrorManager ( );


        /****************************************************
         * Handle내에 UndoName을 일단 갖고 간다.
         ****************************************************/
        if ( aInstName != NULL )
        {
            cmnStrCpy ( pHandle->mInstanceName,
                        aInstName,
                        sizeof(pHandle->mInstanceName) );
        }
        else
        {
            cmnStrCpy ( pHandle->mInstanceName,
                        DBM_DEFAULT_UNDO_NAME,
                        sizeof(pHandle->mInstanceName) );
        }

        /****************************************************
         * InitHandle 과 다른 점이라면 InitTrans 를 하지 않는다는 것이다.
         * InitTrans 는 Server 쪽의 Listener 가 해야할 일이다.
         ****************************************************/
        _CALL( dbmInitSess ( pHandle, DBM_REMOTE_CONNECT ) );
        _CALL( dbmLoadConfig ( pHandle ) );


        /****************************************************
         * Listener 쪽으로 InitHandle 메시지 송신
         ****************************************************/
        sMsgSize = sizeof(dbmRemoteMsg) - sizeof(dbmMsgBody);
        memset_s( &pHandle->mRemote->mMsg, 0x00, sMsgSize );

        pHandle->mRemote->mMsg.mMsgSize = sMsgSize;
        pHandle->mRemote->mMsg.mMsgType = DBM_INIT_HANDLE;
        strcpy_s( pHandle->mRemote->mMsg.mInstName, aInstName );

        _CALL( cmnTcpSend( pHandle->mRemote->mSockFd,
                           (char*)&pHandle->mRemote->mMsg,
                           pHandle->mRemote->mMsg.mMsgSize,
                           (int*)&sRealSize ) );

        DBM_DBG( "Send Remote Init Handle Request. InstName[%s]", aInstName );


        /****************************************************
         * 응답 수신
         ****************************************************/
        _CALL( cmnTcpRecv( pHandle->mRemote->mSockFd,
                           (char*)&pHandle->mRemote->mMsg,
                           0,   /* recv timeout */
                           (int*)&sRealSize ) );
        _IF_THROW( pHandle->mRemote->mMsg.mBody.mInitMsgBody.mRC,
                   ERR_DBM_INIT_HANDLE_FAIL );

        DBM_DBG( "Remote Init Handle OK. InstName[%s]", aInstName );
    }
    _CATCH
    {
        if ( aHandle->mHandle != NULL )
        {
//            ((dbmInternalHandle*)aHandle->mHandle)->mError->mErrCode = ERR_DBM_INIT_HANDLE_FAIL;
//            if( pHandle->mError->mErrCode != ERR_DBM_USER_HANDLE_ALREADY_ALLOC )
            {
                dbmFreeHandle ( aHandle );
            }
        }

        _CATCH_ERR2( pHandle->mInstanceName );

        return( ERR_DBM_INIT_HANDLE_FAIL );
    }
    _FINALLY
    _END
} /* dbmConnect */
