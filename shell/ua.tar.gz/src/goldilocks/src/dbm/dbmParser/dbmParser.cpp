/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/******************************************************************************
 * $Id$*
 * Description :
 *     Parser 구현
 ******************************************************************************/
//#include "dbmHeader.h"

//#include "dbmDicManager.h"
#include "dbmParser.h"

#define DBM_NULL (char*)""
//#define _DEBUG2

// 이름이 너무 일반적이어서 충돌이 나므로, namespace 사용

namespace ns_dbmParser
{
#if 1 //def __linux__    //TODO: [OKT] 윈도포팅

// 쓰레드 변수를 사용하지 않으면, 예를 들어 2개의 다른 쓰레드에서 2개의 DDL을 동시 수행 못함.
__thread dbmParseObject sObject;
__thread dbmDataSet*    sDataSet    = NULL;
__thread dbmDataSet*    sDataSet2   = NULL;
__thread char*  sToken[1024];
__thread int    sColCount = 0;
__thread int    sColOffset = 0;
//__thread int    sMaxAlign = 0;

__thread int    xi = 0;
__thread int    xj = 0;

#else

//TODO: [OKT] 윈도포팅, 윈도환경에서 gdb 추적이 잘안되어서, 추적용 임시 코드
dbmParseObject sObject;
dbmDataSet*    sDataSet    = NULL;
dbmDataSet*    sDataSet2   = NULL;
char*  sToken[1024];
int    sColCount = 0;
int    sColOffset = 0;
//int    sMaxAlign = 0;

int    xi = 0;
int    xj = 0;

#endif /* __linux__ */
}

using namespace ns_dbmParser;

/******************************************************************************
 * Name : dbmCalcOffset
 *
 * Description
 *     calculate offset
 *
 * Argument
 *     aSize        : input   :
 *     aCurrOffset  : input   :
 *
 * Return
 *     offset
 *
 ******************************************************************************/
int dbmParser::mCalcOffset( int aAlign, int aStartOffset )
{
    return (aStartOffset + aAlign - 1 ) & ~(aAlign -1 ) ;
}

/******************************************************************************
 * Name : dbmCalcRecordSize
 *
 * Description
 *     calculate record size
 *
 * Argument
 *     aOffset      : input   :
 *     aSize        : input   :
 *
 * Return
 *     record size
 *
 ******************************************************************************/
/*
int dbmParser::mCalcRecordSize( int aOffset, int aSize, int aAlign )
{
    return aOffset + aSize;
}
*/

/******************************************************************************
 * Name : dbmCalcAlign
 *
 * Description
 *     calculate align
 *
 * Argument
 *     aAlign       : input   :
 *     aSize        : input   :
 *
 * Return
 *     align
 *
 ******************************************************************************/
int dbmParser::mCalcAlign( int aAlign, int aSize )
{
    /*
    if ( sMaxAlign < aAlign )
    {
        sMaxAlign = aAlign ;
    }
    return aSize;
    */
    if ( aAlign > aSize )
    {
        return aAlign;
    }
    return aSize;
}

/******************************************************************************
 * Name : mPasrse
 *
 * Description
 *     parse sql
 *
 * Argument
 *     aSQL         : input   : SQL
 *     aObject      : output  : parsing 결과가 저장된 parse object 구조체
 *
 * Return
 *
 ******************************************************************************/
_VOID dbmParser::mParse( char* aSQL, dbmParseObject* aObject )
{
    char*           sTokenBk        = NULL;
    char*           sTokenDup[1024];
    char*           sSQL            = NULL;
    char*           sTokenPos       = NULL;
    char*           sTokenPosTmp    = NULL;
    char*           sPos            = NULL;
    char*           sPos2           = NULL;
    char            sDel[]          = " (),;\"\t\n";
    char            sDel2[]         = "\'";
    char            sDel3[]         = "=";
    char*           sTokenTr        = NULL;
    char*           sTokenTmp       = NULL;
    char*           sTokenSeq       = NULL;
    int             sTokenDupCnt    = 0;
    int             sCommentFlag    = 0;
    int             sCommentFlag2   = 0;
    int             xl              = 0;
    int             sRet            = 0;

    // 전역변수이므로 여기서 초기화 추가.
    sDataSet = NULL;
    sDataSet2 = NULL;
    sColCount = 0;
    sColOffset = 0;
//    sMaxAlign = 0;
    xi = xj = 0;

    _TRY
    {
        sSQL = strdup( aSQL );
#ifdef _DEBUG2
        _PRT( "DEBUG] input SQL : %s\n", sSQL);
#endif

        _IF_THROW  ( strlen_s ( sSQL ) + 1 > DBM_MAX_SQL_LEN , ERR_DBM_SQL_TOO_LONG) ;
        memset_s( &sObject, 0x00, sizeof( sObject ) );
        cmnStrCpy ( sObject.mSQL , sSQL, sizeof( sObject.mSQL )  ) ;


        //memset_s( sToken, 0x00, sizeof( sToken ) );
        /**************************************************************
         * 전달받은 SQL 문자열을 sDel에 정의된 것을 기준으로 자른다.
         **************************************************************/
        if( sTokenBk != NULL )
        {
            free( sTokenBk );
            sTokenBk = NULL;
        }
        sTokenBk = strdup( sSQL );
        sToken[xi] = strtok_r_s( sSQL, sDel, &sTokenPos );
        _IF_THROW( sToken[0] == NULL, ERR_DBM_SQL_PARSE );

        for ( xi = 0; sToken[xi] != NULL; xi++ )
        {
            if ( memcmp_s ( sToken[xi], "\'", 1 ) == 0 && sCommentFlag == 0 )
            {
#ifdef _DEBUG2
                _PRT( "DEBUG] FOUND QUOTATION_MARK!\n" );
                _PRT( "DEBUG] TOKEN  : [%s]\n", sToken[xi] );
                _PRT( "DEBUG] BACKUP : [%s]\n", sTokenBk );
#endif
                //sTokenDup[sTokenDupCnt] = strdup( sTokenBk );
                sPos = strchr( sTokenBk, '\'' );
                sPos2 = strchr( sPos + 1, '\'' );
                _IF_THROW( sPos2 == NULL, ERR_DBM_UNCLOSED_QUOTATION_MARK );
find_quotation:
                if( *(sPos2 - 1) == '\\' )
                {
#ifdef _DEBUG2
                    _PRT( "DEBUG] FOUND MATCHED QUOTATION_MARK, BUT DATA!\n" );
#endif
                    sPos2 = strchr( sPos2 + 1, '\'' );
                    goto find_quotation;
                }
                //_IF_THROW( sPos2 - sPos == 1, ERR_DBM_TWICE_QUOTATION_MARK );
                if( sPos2 - sPos == 1 )
                {
                    //sToken[xi] = 0x00;
                    sToken[xi] = strdup( DBM_NULL );
                }
                else
                {
                    sTokenDup[sTokenDupCnt] = (char*)malloc_s( strlen_s(sPos) + 1 );
                    memset_s( sTokenDup[sTokenDupCnt] + strlen_s(sPos), 0x00, 1 );
                    strncpy( sTokenDup[sTokenDupCnt], sPos, strlen_s(sPos) );
                    sToken[xi] = strtok_r_s( sTokenDup[sTokenDupCnt], sDel2, &sTokenPos );
                    //strncpy( sTokenDup[sTokenDupCnt], sPos + 1, sPos2 - ( sPos + 1 ) );
                    //sToken[xi] = strdup(sTokenDup[sTokenDupCnt]);
                    sTokenDupCnt++;
                }
#ifdef _DEBUG2
                _PRT( "TOKEN  : [%s]\n", sToken[xi] );
#endif
            }
            else
            {

            sTokenTmp = strdup(sToken[xi]);
            //sTokenTr = strtok_r_s( sToken[xi], sDel3, &sTokenPosTmp );
            sTokenTr = strtok_r_s( sTokenTmp, sDel3, &sTokenPosTmp );

            /* 2014.08.05 c=1 조건처리 -shw */
            /* NULL 하고 다르다는 것은 Parser 결과 값중에 c1=2 위와 같은 값이 들어 왔다는 것이다. */
            if ( sTokenPosTmp != NULL
                    && strlen_s( sTokenPosTmp ) > 0
#ifndef __linux__
/*
 * TODO: [OKT] 윈도포팅, strtok_r_s 의 동작이 윈도에서 다르다. ㅠㅠ
 *             랩퍼함수를 만들어야하는데, 동작이해가 정확하지 않아서, 미룬다.
 *
(gdb) p sTokenPosTmp
$1 = 0x0
(gdb) wa sTokenPosTmp
Hardware watchpoint 5: sTokenPosTmp
(gdb) p sTokenTmp
$2 = 0x0
(gdb) n
179                 sTokenTr = strtok_r_s( sTokenTmp, sDel3, &sTokenPosTmp );
(gdb) p sTokenTmp
$3 = 0x1ef0f30 "create"
(gdb) n
183                 if( sTokenPosTmp != NULL && strlen_s( sTokenPosTmp ) > 0 )
(gdb) p sTokenTmp
$4 = 0x1ef0f30 "create"
(gdb) p sTokenPosTmp
$5 = 0x1ef0f30 "create"
(gdb) p sDel3
$6 = "="
 */
                    && sTokenPosTmp != sTokenTr
#endif
                    )
            {
                sToken[xi] = strdup(sTokenTmp);
                xi++;
                sToken[xi] = sDel3;
                xi++;
                sToken[xi] = strdup(sTokenPosTmp);

                sTokenTr = NULL;
                sTokenPosTmp = NULL;
                sTokenTmp = NULL;
            }
            }

            /**************************************************************
             * 계속 자른다. 자르기 전에 따옴표 처리를 위해 복사 해 둔다.
             **************************************************************/
            //strncpy( sTokenBk, sTokenPos, strlen_s( sTokenPos ) );
            //memset_s( sTokenBk + strlen_s( sTokenPos ), 0x00, 1 );
            if( sTokenBk != NULL )
            {
                free( sTokenBk );
                sTokenBk = NULL;
            }
            sTokenBk = strdup( sTokenPos );

            /* 2014.08.05 -shw- sCommentFlag2 라는 flag 두어 주석 값이 처음올시 처리 하게 하였다 */
            if( sCommentFlag2 == 2 )
            {
                sToken[xi] = strtok_r_s( NULL, sDel, &sTokenPos );
                sCommentFlag2 = 0;
                xi--;
            }
            else
            {
                sToken[xi+1] = strtok_r_s( NULL, sDel, &sTokenPos );
            }

            if ( sToken[xi+1] != NULL && xi >= 0 )
            {
                // 2014.12.14. -okt- [미구현-1] sDel 에를 들면 공백이 없으면, 인식되지 않을듯.
                if ( TOKEN_EQ( sToken[xi + 1], "*/" ) && sCommentFlag == 1 )
                {
                    sCommentFlag = 0;
                    xi--;

                    /* 제일 처음부터 주석이 온다면 xi 0부터 다시 값을 가져오기 위하여 -1을 한번 더한다 */
                    if( sCommentFlag2 == 1 )
                    {
                        /* check flag 2로 바꾸어서 위에서 처음부터 값을 다시 가져오도록 한다 */
                        sCommentFlag2 = 2;
                    }
                }
                else if ( TOKEN_EQ( sToken[xi + 1], "/*" ) || sCommentFlag == 1 )
                {
                    sCommentFlag = 1;
                    xi--;
                }
                else if ( TOKEN_EQ( sToken[xi], "/*" ) )
                {
                    sCommentFlag = 1;
                    sCommentFlag2 = 1;
                    xi--;
                }

                //TODO:fhan hint 기능을 구현한 부분인데 현재로는 필요가 없어 막아둔다.
//                else if ( TOKEN_EQ( sToken[xi + 1], "/*+") || sCommentFlag == 1 )
//                {
//                    if ( TOKEN_EQ_IC( sToken[xj], "select" ) )
//                    {
//                        sToken[xi+1] = strtok_r_s( NULL, sDel, &sTokenPos );
//                        if ( TOKEN_EQ_IC( sToken[xi + 1], "index" ) )
//                        {
//                            sToken[xi+1] = strtok_r_s( NULL, sDel, &sTokenPos );
//                            if ( TOKEN_EQ( sToken[xi + 1], "*/" ) )
//                            {
//                            }
//                            else
//                            {
//                                memcpy_s( sObject.mObj.mTableInfo.mTable.mIndexName[0], sToken[xi+1], strlen_s( sToken[xi+1] ) );
//                            }
//                        }
//
//                        sCommentFlag = 1;
//                        xi--;
//                    }
//                    else
//                    {
//                        sCommentFlag = 1;
//                        xi--;
//                    }
//                }
            }
        }

#ifdef _DEBUG2
        for ( int j = 0; j < xi; j++ )
        {
            _PRT( "DEBUG] %d Token : %s\n", j, sToken[j] );
        }
#endif

        /**************************************************************
         * 문법을 분석함. 일단은 유형만 분석.
         * 테스트를 위한 코드이기 때문에 유효성 검사는 하지 않음.
         **************************************************************/
        if ( xi < 2 )
        {
            if ( TOKEN_EQ_IC( sToken[xj], "commit" ) )
            {
                sObject.mSQLType = DBM_COMMIT;
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "rollback" ) )
            {
                sObject.mSQLType = DBM_ROLLBACK;
                _RETURN;
            }
            else
            {
                DBM_DBG ( "not enough argument(s) for '%s' clause\n", sToken[0] );
                _THROW( ERR_DBM_NOT_ENOUGH_ARG );
            }
        }
        else
        {
            if ( TOKEN_EQ_IC( sToken[xj], "select" ) )
            {
                sTokenSeq = sToken[xj+1] + ( strlen ( sToken[xj+1] ) - 7 );

                if ( TOKEN_EQ_IC ( sTokenSeq, "currval" ) )
                {
                    sObject.mSQLType = DBM_SEQ_CURRVAL;

                    sObject.mObj.mDataSet = aObject->mObj.mDataSet;

                    _CALL( mSequenceDML( ) );

                    _RETURN;
                }
                else
                if ( TOKEN_EQ_IC ( sTokenSeq, "nextval" ) )
                {
                    sObject.mSQLType = DBM_SEQ_NEXTVAL;

                    sObject.mObj.mDataSet = aObject->mObj.mDataSet;

                    _CALL( mSequenceDML( ) );

                    _RETURN;

                }
                else
                {
                    sObject.mSQLType = DBM_SELECT;

                    sObject.mObj.mDataSet   = aObject->mObj.mDataSet;     // [OKT] 내부처리를 밖으로.
                    sObject.mDataSet2  = aObject->mDataSet2;     // [OKT] 내부처리를 밖으로.
                    _CALL( mSelectDML( ) );
                    _RETURN;
                }
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "insert" ) )
            {
                sObject.mSQLType = DBM_INSERT;

                sObject.mObj.mDataSet = aObject->mObj.mDataSet;     // [OKT] 내부처리를 밖으로.
                _CALL( mInsertDML( ) );
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "delete" ) )
            {
                sObject.mSQLType = DBM_DELETE;

                sObject.mObj.mDataSet = aObject->mObj.mDataSet;     // [OKT] 내부처리를 밖으로.
                sObject.mDataSet2  = aObject->mDataSet2;     // [OKT] 내부처리를 밖으로.
                _CALL( mDeleteDML( ) );
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "update" ) )
            {
                sObject.mSQLType = DBM_UPDATE;

                sObject.mObj.mDataSet = aObject->mObj.mDataSet;     // [OKT] 내부처리를 밖으로.
                sObject.mDataSet2  = aObject->mDataSet2;     // [OKT] 내부처리를 밖으로.
                _CALL( mUpdateDML( ) );
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "enqueue" ) )
            {
                sObject.mSQLType = DBM_ENQUE;

                sObject.mObj.mDataSet = aObject->mObj.mDataSet;     // [OKT] 내부처리를 밖으로.
                _CALL( mEnqueueDML( ) );
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "dequeue" ) )
            {
                sObject.mSQLType = DBM_DEQUE;

                _CALL( mDequeueDML( ) );
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken [xj], "alter" ) )
            {
                _CALL ( mAlterDDL () ) ;
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "lpush" ) )
            {
                sObject.mSQLType = DBM_LIST_LPUSH;

                sObject.mObj.mDataSet = aObject->mObj.mDataSet;
                _CALL( mListPushDML( ) );
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "rpush" ) )
            {
                sObject.mSQLType = DBM_LIST_RPUSH;

                sObject.mObj.mDataSet = aObject->mObj.mDataSet;
                _CALL( mListPushDML( ) );
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "lpop" ) )
            {
                sObject.mSQLType = DBM_LIST_LPOP;

                sObject.mObj.mDataSet = aObject->mObj.mDataSet;
                _CALL( mListPopDML( ) );
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "rpop" ) )
            {
                sObject.mSQLType = DBM_LIST_RPOP;

                sObject.mObj.mDataSet = aObject->mObj.mDataSet;
                _CALL( mListPopDML( ) );
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "range" ) )
            {
                sObject.mSQLType = DBM_LIST_RANGE;

                sObject.mObj.mDataSet = aObject->mObj.mDataSet;
                //_CALL( mListDML( ) ); --> 아직 미구현.
                _RETURN;
            }


            else if ( TOKEN_EQ_IC( sToken[xj], "truncate" ) )
            {
                xj++;
                if ( TOKEN_EQ_IC( sToken[xj], "table" ) ||
                     TOKEN_EQ_IC( sToken[xj], "queue" ) ||
                     TOKEN_EQ_IC( sToken[xj], "list"  )   )
                {
                    sObject.mSQLType = DBM_TRUNCATE;
                }
                else
                {
                    sObject.mSQLType = DBM_NOT_DEFINED;
                    _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                }

                _CALL( mTruncateDDL( ) );
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "create" ) )
            {
                xj++;
                /**************************************************************
                 * DBM_CREATE_USER, DBM_CREATE_TRIG는 미구현
                 **************************************************************/
                if ( TOKEN_EQ_IC( sToken[xj], "undo" ) || TOKEN_EQ_IC( sToken[xj], "instance" ) )
                {
                    sObject.mSQLType = DBM_CREATE_INST;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "table" ) )
                {
                    sObject.mSQLType = DBM_CREATE_TABLE;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "direct" ) )
                {
                    if ( xi < 3 )
                    {
#ifdef _DEBUG2
                        fprintf ( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
                        _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                    }
                    else
                    {
                        xj++;
                        if ( TOKEN_EQ_IC( sToken[xj], "table" ) )
                        {
                            sObject.mSQLType = DBM_CREATE_DIRECT_TABLE;
                        }
                        else
                        {
                            sObject.mSQLType = DBM_NOT_DEFINED;
                            _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                        }
                    }
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "sequence" ) )
                {
                    sObject.mSQLType = DBM_CREATE_SEQUENCE;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "queue" ) )
                {
                    sObject.mSQLType = DBM_CREATE_QUEUE;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "list" ) )
                {
                    sObject.mSQLType = DBM_CREATE_LIST;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "index" ) )
                {
                    sObject.mSQLType = DBM_CREATE_INDEX;
                    sObject.mObj.mIndex.mIsUniqueIndex = DBM_UNIQUE;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "unique" ) )
                {
                    if ( xi < 3 )
                    {
#ifdef _DEBUG2
                        fprintf ( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
                        _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                    }
                    else
                    {
                        xj++;
                        if ( TOKEN_EQ_IC( sToken[xj], "index" ) )
                        {
                            sObject.mSQLType = DBM_CREATE_INDEX;
                            sObject.mObj.mIndex.mIsUniqueIndex = DBM_UNIQUE;
                        }
                        else
                        {
                            sObject.mSQLType = DBM_NOT_DEFINED;
                            _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                        }
                    }
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "non" ) )
                {
                    if ( xi < 4 )
                    {
#ifdef _DEBUG2
                        fprintf ( stderr, "not enough argument(s) for '%s %s %s' clause\n", sToken[0], sToken[1], sToken[2] );
#endif
                        _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                    }
                    else
                    {
                        if ( TOKEN_EQ_IC( sToken[xj+1], "unique" ) && TOKEN_EQ_IC( sToken[xj+2], "index" ) )
                        {
                            sObject.mSQLType = DBM_CREATE_INDEX;
                            sObject.mObj.mIndex.mIsUniqueIndex = DBM_NON_UNIQUE;
                            xj = xj + 2;
                        }
                        else
                        {
                            sObject.mSQLType = DBM_NOT_DEFINED;
                            _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                        }
                    }
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "trigger" ) )
                {
                    sObject.mSQLType = DBM_CREATE_TRIG;
                }
                else
                {
                    sObject.mSQLType = DBM_NOT_DEFINED;

                    DBM_ERR( "[Unknown CMD] %p,%p [%s,%d,%d](%x)", sToken, &xj, sToken[xj], xj, xi, sToken );
                    DBM_ERR( "[Unknown CMD] %p,%p [%s,%d,%d](%x)", sToken, &xj, sToken[xj-1], xj, xi, sToken );
                    DBM_ERR( "[Unknown CMD] %p,%p [%s,%d,%d](%x)", sToken, &xj, sToken[xj+1], xj, xi, sToken );
                    _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                }

                _CALL( mCreateDDL( ) );
                _RETURN;
            }
            else if ( TOKEN_EQ_IC( sToken[xj], "drop" ) )
            {
                xj++;
                /**************************************************************
                 * DBM_DROP_USER 는 미구현
                 **************************************************************/
                if ( TOKEN_EQ_IC( sToken[xj], "undo" ) || TOKEN_EQ_IC( sToken[xj], "instance" ) )
                {
                    sObject.mSQLType = DBM_DROP_INST;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "data" ) )
                {
                    sObject.mSQLType = DBM_DROP_DATA;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "table" ) )
                {
                    sObject.mSQLType = DBM_DROP_TABLE;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "queue" ) )
                {
                    sObject.mSQLType = DBM_DROP_QUEUE;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "list" ) )
                {
                    sObject.mSQLType = DBM_DROP_LIST;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "sequence" ) )
                {
                    sObject.mSQLType = DBM_DROP_SEQUENCE;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "index" ) )
                {
                    sObject.mSQLType = DBM_DROP_INDEX;
                }
                else if ( TOKEN_EQ_IC( sToken[xj], "trigger" ) )
                {
                    sObject.mSQLType = DBM_DROP_TRIG;
                }
                else
                {
                    sObject.mSQLType = DBM_NOT_DEFINED;
                    _THROW( ERR_DBM_NOT_SUPPORT_SQL );
                }

                _CALL( mDropDDL( ) );
                _RETURN;
            }
            else
            {
                _THROW( ERR_DBM_NOT_SUPPORT_SQL );
            }
        }
    }
    _CATCH
    {
        // 위에서도 찍었고. 호출한쪽에서 오류찍을거다.
#ifndef __linux__
        _CATCH_DBG;
#endif /* __linux__ */

        switch ( _rc )
        {
//#if 1 //def _DEBUG2
#ifdef _DEBUG2
            case ERR_DBM_UNCLOSED_QUOTATION_MARK:
                _PRT( "DEBUG] Unclosed quotation mark.\n" );
                break;

            case ERR_DBM_TWICE_QUOTATION_MARK:
                _PRT( "DEBUG] Twice quotation mark in a row.\n" );
                break;

            case ERR_DBM_NOT_ALPHA:
                _PRT( "DEBUG] object name must start with alphabet\n" );
                break;

            case ERR_DBM_NOT_DIGIT:
                _PRT( "DEBUG] object size, precision and scale must be digit\n" );
                break;

            case ERR_DBM_SQL_TOO_LONG :
                _PRT( "DEBUG] Input SQL lenth is bigger than DBM_SQL_MAX_LEN[%d]\n", DBM_MAX_SQL_LEN );
                break;

            case ERR_DBM_SIZE_IS_ZERO:
                _PRT( "DEBUG] size must be larger than zero\n" );
                break;

            case ERR_DBM_DUP_COLUMN:
                switch( sObject.mSQLType )
                {
                    case DBM_CREATE_TABLE:
                    case DBM_CREATE_DIRECT_TABLE:
                    _PRT( "DEBUG] duplicate column name[%s:%s]\n", sObject.mObj.mTableInfo.mColumn.mCols[xl].mColumnName, sToken[xj] );
                    break;
                    case DBM_CREATE_INDEX:
                    _PRT( "DEBUG] duplicate column name[%s:%s]\n", sObject.mObj.mIndex.mKey[xl].mColumnName, sToken[xj] );
                    break;
                    case DBM_INSERT:
                    case DBM_DELETE:
                    case DBM_UPDATE:
                    case DBM_SELECT:
                    _PRT( "DEBUG] duplicate column name[%s:%s]\n", sDataSet->mCols[xl].mColumnName, sToken[xj] );
                    break;
                    default:
                    _PRT( "DEBUG] duplicate column name\n" );
                    break;
                }
                break;

            case ERR_DBM_TOO_LARGE_INIT:
                switch( sObject.mSQLType )
                {
                    case DBM_CREATE_INST:
                    case DBM_CREATE_DATA:
                    _PRT( "DEBUG] init larger than max[%lld:%lld]\n", sObject.mObj.mInstance.mInitSize, sObject.mObj.mInstance.mMaxSize );
                    break;
                    case DBM_CREATE_TABLE:
                    case DBM_CREATE_DIRECT_TABLE:
                    case DBM_CREATE_QUEUE:
                    case DBM_CREATE_INDEX:
                    _PRT( "DEBUG] init larger than max[%lld:%lld]\n", sObject.mObj.mTableInfo.mTable.mInitSize, sObject.mObj.mTableInfo.mTable.mMaxSize );
                    break;
                    default:
                    _PRT( "DEBUG] not define SQL type [%d]\n", sObject.mSQLType );
                    break;
                }
                break;

            case ERR_DBM_TOO_LARGE_SCALE:
                _PRT( "DEBUG] scale larger than precision[%d:%d]\n"
                    , sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale, sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision );
                break;

#endif
            default:
                // dummy for compile
                break;
        }
    }
    _FINALLY
    {
        memcpy_s ( aObject, &sObject, sizeof(dbmParseObject) );
        free_s ( sSQL );        // strdup 에 의해 생성된 자원 해제.
        for( xi=0; xi < sTokenDupCnt; xi++ )
        {
            free_s( sTokenDup[xi] ); sTokenDup[xi] = NULL;
        }
    }
    _END
} /* mParse */

_VOID dbmParser::mTruncateDDL( )
{
    _TRY
    {
        xj++;
        switch( sObject.mSQLType )
        {
            case DBM_TRUNCATE:
                if ( xi < 3 )
                {
#ifdef _DEBUG2
                    fprintf ( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
                    _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                }
                /**************************************************************
                 * 객체 이름은 알파벳으로 시작해야한다.
                 **************************************************************/
                if( isalpha( sToken[xj][0] ) == 0 )
                {
                    _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
                }

                _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
                memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );
#ifdef _DEBUG2
                _PRT( "DEBUG] regen SQL : truncate table %s;\n", sObject.mObj.mTableInfo.mTable.mTableName );
#endif
                break;
            default:
                _THROW( ERR_DBM_NOT_DEFINE_SQLTYPE );
                break;
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mTruncateDDL */


_VOID dbmParser::mCreateDDL( )
{
    int     sAlign  = 0;
    int     sRet    = 0;

    _TRY
    {
        xj++;
        switch( sObject.mSQLType )
        {
            case DBM_CREATE_INST:
                if ( xi < 3 )
                {
#ifdef _DEBUG2
                    fprintf( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
                    _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                }

                _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_INST_NAME_TOO_LONG );

                /**************************************************************
                 * 객체 이름은 알파벳으로 시작해야한다.
                 **************************************************************/
                //bug-330 undo 명은 숫자로 시작할 수 있어야한다.
                //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                memcpy_s( sObject.mObj.mInstance.mInstanceName, sToken[xj], strlen_s( sToken[xj] ) );

                /**************************************************************
                 * 옵션이 부족할 때를 대비해 기본값으로 넣어준다.
                 * 정식버전에는 config에서 읽어오지만 지금은 일단 내 임의로 세팅해준다.
                 * config에서 읽어오는 것을 유저딴에서 처리한다.
                sObject.mObj.mInstance.mInitSize = ( long long )4;        //1024K
                sObject.mObj.mInstance.mExtendSize = cmnGetBuddy( 2 );       //512K
                sObject.mObj.mInstance.mMaxSize = ( long long )400;     //100M
                 **************************************************************/
                /**************************************************************
                 * 먼지 모르겠다; 일단
                 **************************************************************/
                sObject.mObj.mInstance.mMaxSegNo = 1;
                /**************************************************************
                 * 위의 항목이 입력된다면 엎어친다.
                 **************************************************************/
#ifdef _DEBUG2
                _PRT( "DEBUG] xj = [%d], xi = [%d]\n", xj, xi );
#endif
                for ( xj = xj + 1; xj + 1 < xi; xj += 2 )
                {
                    if ( TOKEN_EQ_IC( sToken[xj], "init" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mInstance.mInitSize = atol( sToken[xj+1] );
                        _IF_THROW( sObject.mObj.mInstance.mInitSize == 0, ERR_DBM_SIZE_IS_ZERO );
                        _IF_THROW( sObject.mObj.mInstance.mMaxSize > 0
                            && sObject.mObj.mInstance.mInitSize > sObject.mObj.mInstance.mMaxSize, ERR_DBM_TOO_LARGE_INIT );
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "extend" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mInstance.mExtendSize = cmnGetBuddy( atol( sToken[xj+1] ) );
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "max" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mInstance.mMaxSize = atol( sToken[xj+1] );
                        _IF_THROW( sObject.mObj.mInstance.mInitSize > sObject.mObj.mInstance.mMaxSize, ERR_DBM_TOO_LARGE_INIT );
                    }
                    else
                    {
                        _THROW( ERR_DBM_SQL_PARSE );
                    }
                }
#ifdef _DEBUG2
                _PRT( "DEBUG] regen SQL : create undo %s init %lld extend %lld max %lld;\n",
                        sObject.mObj.mInstance.mInstanceName,
                        sObject.mObj.mInstance.mInitSize,
                        sObject.mObj.mInstance.mExtendSize,
                        sObject.mObj.mInstance.mMaxSize );
#endif
                break;

            case DBM_CREATE_TABLE:
                if ( xi < 5 )
                {
#ifdef _DEBUG2
                    fprintf( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
                    _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                }
                /**************************************************************
                 * 객체 이름은 알파벳으로 시작해야한다.
                 **************************************************************/
                //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                if( isalpha( sToken[xj][0] ) == 0 )
                {
                    _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
                }

                _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );

                memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );
                sObject.mObj.mTableInfo.mTable.mTableType = DBM_TBL_NORMAL;
                //PID 제거에 따른 임시 주석 처리
                //dbmInitPID( &sObject.mObj.mTableInfo.mTable.mHdrPID );
#ifdef _DEBUG2
                _PRT( "DEBUG] j = [%d], i = [%d]\n", xj, xi );
#endif
                for ( xj = xj + 1; xj < xi; xj++ )
                {
#ifdef _DEBUG2
                    _PRT( "DEBUG] j = [%d], i = [%d]\n", xj, xi );
#endif
                    //TODO:fhan mColumnID를 지정해 줘야하나?
                    //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnID = sColCount;
                    if ( TOKEN_EQ_IC( sToken[xj], "init" ) || TOKEN_EQ_IC( sToken[xj], "extend" ) || TOKEN_EQ_IC( sToken[xj], "max" ) )
                        break;

                    if ( xj + 1 >= xi )
                    {
#ifdef _DEBUG2
                        fprintf( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
                        _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                    }
                    /**************************************************************
                     * 같은 컬럼이 있는지 확인한다.
                     **************************************************************/
                    for ( int i = 0; i < sColCount; i++ )
                    {
                        if ( TOKEN_EQ( sObject.mObj.mTableInfo.mColumn.mCols[i].mColumnName, sToken[xj] ) )
                        {
                            _THROW( ERR_DBM_DUP_COLUMN );
                        }
                    }
                    /**************************************************************
                     * 객체 이름은 알파벳으로 시작해야한다.
                     **************************************************************/
                    _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                    _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_COLUMN_NAME_TOO_LONG );

                    memcpy_s( sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );

                    xj++;

                    if ( TOKEN_EQ_IC( sToken[xj], "char" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_CHAR_TYPE;
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                            xj++;
                            sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = atoi( sToken[xj] );
                            _IF_THROW( sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize == 0, ERR_DBM_SIZE_IS_ZERO );
                            sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                            //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[j] );
                            //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale = 0;
                            sAlign = mCalcAlign( sAlign, 1 );
                            //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, atoi( sToken[xj] ), sAlign );
                            //sObject.mObj.mTableInfo.mTable.mRecordSize = sColOffset + sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize;
                            if ( xj+1 < xi )
                            {
                                sRet = cmnIsDigit( sToken[xj+1] );
                                if ( sRet == TRUE )
                                {
                                    xj++;
                                }
                            }
                        }
                        else
                        {
#ifdef _DEBUG2
                            fprintf( stderr, "not enough argument(s) for %s datatype\n", sToken[xj] );
#endif
                            _THROW( ERR_DBM_NOT_ENOUGH_DATATYPE_ARG );
                        }
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "int" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_INT_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 4;
                        sColOffset = mCalcOffset( 4, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 4 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 4, sAlign );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = sColOffset + sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize;
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            if ( sRet == TRUE )
                            {
                                xj++;
                                //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[j] );
                                if ( xj+1 < xi )
                                {
                                    sRet = cmnIsDigit( sToken[xj+1] );
                                    if ( sRet == TRUE )
                                    {
                                        xj++;
                                        //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = atoi( sToken[j] );
                                    }
                                }
                            }
                        }

                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "long" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_LONG_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 8;
                        sColOffset = mCalcOffset( 8, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 8 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 8, sAlign );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = sColOffset + sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize;
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            if ( sRet == TRUE )
                            {
                                xj++;
                                //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[j] );
                                if ( xj+1 < xi )
                                {
                                    sRet = cmnIsDigit( sToken[xj+1] );
                                    if ( sRet == TRUE )
                                    {
                                        xj++;
                                        //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = atoi( sToken[j] );
                                    }
                                }
                            }
                        }
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "double" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_DOUBLE_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 8;
                        sColOffset = mCalcOffset( 8, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 8 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 8, sAlign );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = sColOffset + sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = 16;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale = 16;
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            if ( sRet == TRUE )
                            {
                                xj++;
                                sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[xj] );
                                if ( xj+1 < xi )
                                {
                                    sRet = cmnIsDigit( sToken[xj+1] );
                                    if ( sRet == TRUE )
                                    {
                                        xj++;
                                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale = atoi( sToken[xj] );
                                        _IF_THROW( sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale > sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision, ERR_DBM_TOO_LARGE_SCALE );
                                    }
                                }
                            }
                        }
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "float" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_FLOAT_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 4;
                        sColOffset = mCalcOffset( 4, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 4 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 4, sAlign );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = sColOffset + sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = 10;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale = 10;
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            if ( sRet == TRUE )
                            {
                                xj++;
                                sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[xj] );
                                if ( xj+1 < xi )
                                {
                                    sRet = cmnIsDigit( sToken[xj+1] );
                                    if ( sRet == TRUE )
                                    {
                                        xj++;
                                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale = atoi( sToken[xj] );
                                        _IF_THROW( sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale > sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision, ERR_DBM_TOO_LARGE_SCALE );
                                    }
                                }
                            }
                        }
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "short" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_SHORT_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 2;
                        sColOffset = mCalcOffset( 2, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 2 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 2, sAlign );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = sColOffset + sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize;
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            if ( sRet == TRUE )
                            {
                                xj++;
                                //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[j] );
                                if ( xj+1 < xi )
                                {
                                    sRet = cmnIsDigit( sToken[xj+1] );
                                    if ( sRet == TRUE )
                                    {
                                        xj++;
                                        //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = atoi( sToken[j] );
                                    }
                                }
                            }
                        }
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "date" ) )
                    {
                        //오프셋, 크기 계산 등에서 기준값을 주는데 이를 define으로 관리해야 좋을것 같다.
                        //date 타입의 경우 8과 16을 적절히 써야한다.
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_DATE_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 16;
                        sColOffset = mCalcOffset( 8, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 8 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 16, sAlign );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = sColOffset + sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize;
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            if ( sRet == TRUE )
                            {
                                xj++;
                                //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[j] );
                                if ( xj+1 < xi )
                                {
                                    sRet = cmnIsDigit( sToken[xj+1] );
                                    if ( sRet == TRUE )
                                    {
                                        xj++;
                                        //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = atoi( sToken[j] );
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        _THROW( ERR_DBM_INVALID_DATATYPE );
                    }
                    sColOffset += sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize;
                    sColCount++;
                }

                /**************************************************************
                 * 전체 테이블 사이즈의 가장 큰 자료형의 Align 으로 검사
                 *************************************************************/
                /*
                if ( sMaxAlign > 0 &&  sObject.mObj.mTableInfo.mTable.mRecordSize % sMaxAlign  > 0 )
                {
                    sObject.mObj.mTableInfo.mTable.mRecordSize =
                        ((sObject.mObj.mTableInfo.mTable.mRecordSize / sMaxAlign) + 1 ) * sMaxAlign;
                }
                */
                if ( sAlign > 0 && sColOffset % sAlign > 0 )
                {
                    sObject.mObj.mTableInfo.mTable.mRecordSize =
                        ( (sColOffset / sAlign) + 1 ) * sAlign;
                }
                else
                {
                    sObject.mObj.mTableInfo.mTable.mRecordSize = sColOffset;
                }

                //_PRT( "align [%d], recore size [%d]\n", sAlign, sObject.mObj.mTableInfo.mTable.mRecordSize );
                /**************************************************************
                 * 컬럼 개수를 기입해 주는데 두개나 있네?
                 **************************************************************/
                sObject.mObj.mTableInfo.mTable.mColumnCount = sColCount;
                sObject.mObj.mTableInfo.mColumn.mCount = sColCount;
                for ( ; xj + 1 < xi; xj += 2 )
                {
                    if ( TOKEN_EQ_IC( sToken[xj], "init" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mTableInfo.mTable.mInitSize = atol( sToken[xj+1] );
                        _IF_THROW( sObject.mObj.mTableInfo.mTable.mInitSize == 0, ERR_DBM_SIZE_IS_ZERO );
                        _IF_THROW( sObject.mObj.mTableInfo.mTable.mMaxSize > 0
                            && sObject.mObj.mTableInfo.mTable.mInitSize > sObject.mObj.mTableInfo.mTable.mMaxSize, ERR_DBM_TOO_LARGE_INIT );
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "extend" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mTableInfo.mTable.mExtendSize = cmnGetBuddy( atol( sToken[xj+1] ) );
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "max" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mTableInfo.mTable.mMaxSize = atol( sToken[xj+1] );
                        _IF_THROW( sObject.mObj.mTableInfo.mTable.mInitSize > sObject.mObj.mTableInfo.mTable.mMaxSize, ERR_DBM_TOO_LARGE_INIT );
                    }
                    else
                    {
                        _THROW( ERR_DBM_SQL_PARSE );
                    }
                }
#ifdef _DEBUG2
                _PRT( "DEBUG] regen SQL : create table %s ", sObject.mObj.mTableInfo.mTable.mTableName );
                for ( int i = 0; i < sObject.mObj.mTableInfo.mTable.mColumnCount; i++ )
                {
                    if ( i > 0 )
                    {
                        _PRT( ", " );
                    }
                    _PRT( "%s", sObject.mObj.mTableInfo.mColumn.mCols[i].mColumnName );
                    switch( sObject.mObj.mTableInfo.mColumn.mCols[i].mColumnType )
                    {
                        case DBM_COLUMN_CHAR_TYPE:
                            _PRT( " char %d", sObject.mObj.mTableInfo.mColumn.mCols[i].mSize );
                            break;
                        case DBM_COLUMN_INT_TYPE:
                            _PRT( " int %d %d", sObject.mObj.mTableInfo.mColumn.mCols[i].mPrecision, sObject.mObj.mTableInfo.mColumn.mCols[i].mSize );
                            break;
                        case DBM_COLUMN_LONG_TYPE:
                            _PRT( " long %d %d", sObject.mObj.mTableInfo.mColumn.mCols[i].mPrecision, sObject.mObj.mTableInfo.mColumn.mCols[i].mSize );
                            break;
                        case DBM_COLUMN_DOUBLE_TYPE:
                            _PRT( " double %d %d", sObject.mObj.mTableInfo.mColumn.mCols[i].mPrecision, sObject.mObj.mTableInfo.mColumn.mCols[i].mSize );
                            break;
                        case DBM_COLUMN_FLOAT_TYPE:
                            _PRT( " float %d %d", sObject.mObj.mTableInfo.mColumn.mCols[i].mPrecision, sObject.mObj.mTableInfo.mColumn.mCols[i].mSize );
                            break;
                        case DBM_COLUMN_SHORT_TYPE:
                            _PRT( " short %d %d", sObject.mObj.mTableInfo.mColumn.mCols[i].mPrecision, sObject.mObj.mTableInfo.mColumn.mCols[i].mSize );
                            break;
                        case DBM_COLUMN_DATE_TYPE:
                            _PRT( " date" );
                            break;
                        default:
                            break;
                    }
                    _PRT( "(%d)", sObject.mObj.mTableInfo.mColumn.mCols[i].mOffset );
                }
                if ( sObject.mObj.mTableInfo.mTable.mInitSize != 0 ) _PRT( " init %lld", sObject.mObj.mTableInfo.mTable.mInitSize );
                if ( sObject.mObj.mTableInfo.mTable.mExtendSize != 0 ) _PRT( " extend %lld", sObject.mObj.mTableInfo.mTable.mExtendSize );
                if ( sObject.mObj.mTableInfo.mTable.mMaxSize != 0 ) _PRT( " max %lld", sObject.mObj.mTableInfo.mTable.mMaxSize );
                _PRT( ";\n" );
#endif
                break;
            case DBM_CREATE_DIRECT_TABLE:
                if ( xi < 6 )
                {
#ifdef _DEBUG2
                    fprintf( stderr, "not enough argument(s) for '%s %s %s' clause\n", sToken[0], sToken[1], sToken[2] );
#endif
                    _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                }
                /**************************************************************
                 * 객체 이름은 알파벳으로 시작해야한다.
                 **************************************************************/
                //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                if( isalpha( sToken[xj][0] ) == 0 )
                {
                    _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
                }

                _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );

                memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );
                sObject.mObj.mTableInfo.mTable.mTableType = DBM_TBL_DIRECT;
                //PID 제거에 따른 임시 주석 처리
                //dbmInitPID( &sObject.mObj.mTableInfo.mTable.mHdrPID );
                for ( xj = xj + 1; xj < xi; xj++ )
                {
                    //TODO:fhan mColumnID를 지정해 줘야하나?
                    //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnID = sColCount;
                    if ( TOKEN_EQ_IC( sToken[xj], "init" ) || TOKEN_EQ_IC( sToken[xj], "extend" ) || TOKEN_EQ_IC( sToken[xj], "max" ) )
                        break;

                    if ( xj + 1 >= xi )
                    {
#ifdef _DEBUG2
                        fprintf( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
                        _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                    }
                    /**************************************************************
                     * 같은 컬럼이 있는지 확인한다.
                     **************************************************************/
                    for ( int i = 0; i < sColCount; i++ )
                    {
                        if ( TOKEN_EQ( sObject.mObj.mTableInfo.mColumn.mCols[i].mColumnName, sToken[xj] ) )
                        {
                            _THROW( ERR_DBM_DUP_COLUMN );
                        }
                    }
                    /**************************************************************
                     * 객체 이름은 알파벳으로 시작해야한다.
                     **************************************************************/
                    _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                    _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_COLUMN_NAME_TOO_LONG );

                    memcpy_s( sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );

                    xj++;

                    if ( TOKEN_EQ_IC( sToken[xj], "char" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_CHAR_TYPE;
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                            xj++;
                            sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = atoi( sToken[xj] );
                            _IF_THROW( sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize == 0, ERR_DBM_SIZE_IS_ZERO );
                            sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                            //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[j] );
                            //sObject.mObj.mTableInfo.mTable.mRecordSize = ( ((sColOffset + atoi(sToken[j])) / 8) + 1 ) * 8;
                            //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale = 0;
                            sAlign = mCalcAlign( sAlign, 1 );
                            //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, atoi( sToken[xj] ), sAlign );
                            if ( xj+1 < xi )
                            {
                                sRet = cmnIsDigit( sToken[xj+1] );
                                if ( sRet == TRUE )
                                {
                                    xj++;
                                }
                            }
                        }
                        else
                        {
#ifdef _DEBUG2
                            fprintf( stderr, "not enough argument(s) for %s datatype\n", sToken[xj] );
#endif
                            _THROW( ERR_DBM_NOT_ENOUGH_DATATYPE_ARG );
                        }
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "int" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_INT_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 4;
                        sColOffset = mCalcOffset( 4, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 4 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 4, sAlign );
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            if ( sRet == TRUE )
                            {
                                xj++;
                                //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[j] );
                                if ( xj+1 < xi )
                                {
                                    sRet = cmnIsDigit( sToken[xj+1] );
                                    if ( sRet == TRUE )
                                    {
                                        xj++;
                                        //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = atoi( sToken[j] );
                                    }
                                }
                            }
                        }

                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "long" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_LONG_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 8;
                        sColOffset = mCalcOffset( 8, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 8 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 8, sAlign );
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            if ( sRet == TRUE )
                            {
                                xj++;
                                //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[j] );
                                if ( xj+1 < xi )
                                {
                                    sRet = cmnIsDigit( sToken[xj+1] );
                                    if ( sRet == TRUE )
                                    {
                                        xj++;
                                        //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = atoi( sToken[j] );
                                    }
                                }
                            }
                        }
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "double" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_DOUBLE_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 8;
                        sColOffset = mCalcOffset( 8, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 8 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 8, sAlign );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = 16;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale = 16;
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            if ( sRet == TRUE )
                            {
                                xj++;
                                sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[xj] );
                                if ( xj+1 < xi )
                                {
                                    sRet = cmnIsDigit( sToken[xj+1] );
                                    if ( sRet == TRUE )
                                    {
                                        xj++;
                                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale = atoi( sToken[xj] );
                                        _IF_THROW( sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale > sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision, ERR_DBM_TOO_LARGE_SCALE );
                                    }
                                }
                            }
                        }
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "float" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_FLOAT_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 4;
                        sColOffset = mCalcOffset( 4, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 4 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 4, sAlign );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = 10;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale = 10;
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            if ( sRet == TRUE )
                            {
                                xj++;
                                sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[xj] );
                                if ( xj+1 < xi )
                                {
                                    sRet = cmnIsDigit( sToken[xj+1] );
                                    if ( sRet == TRUE )
                                    {
                                        xj++;
                                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale = atoi( sToken[xj] );
                                        _IF_THROW( sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mScale > sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision, ERR_DBM_TOO_LARGE_SCALE );
                                    }
                                }
                            }
                        }
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "short" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_SHORT_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 2;
                        sColOffset = mCalcOffset( 2, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 2 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 2, sAlign );
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            if ( sRet == TRUE )
                            {
                                xj++;
                                //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[j] );
                                if ( xj+1 < xi )
                                {
                                    sRet = cmnIsDigit( sToken[xj+1] );
                                    if ( sRet == TRUE )
                                    {
                                        xj++;
                                        //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = atoi( sToken[j] );
                                    }
                                }
                            }
                        }
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "date" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_DATE_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 16;
                        sColOffset = mCalcOffset( 16, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 16 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 16, sAlign );
                        if ( xj+1 < xi )
                        {
                            sRet = cmnIsDigit( sToken[xj+1] );
                            if ( sRet == TRUE )
                            {
                                xj++;
                                //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mPrecision = atoi( sToken[j] );
                                if ( xj+1 < xi )
                                {
                                    sRet = cmnIsDigit( sToken[xj+1] );
                                    if ( sRet == TRUE )
                                    {
                                        xj++;
                                        //sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = atoi( sToken[j] );
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        _THROW( ERR_DBM_INVALID_DATATYPE );
                    }
                    sColOffset += sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize;
                    sColCount++;
                }



                /**************************************************************
                 * 전체 테이블 사이즈의 가장 큰 자료형의 Align 으로 검사
                 *************************************************************/
                /*
                if ( sMaxAlign > 0 && sObject.mObj.mTableInfo.mTable.mRecordSize % sMaxAlign  > 0 )
                {
                    sObject.mObj.mTableInfo.mTable.mRecordSize =
                        ((sObject.mObj.mTableInfo.mTable.mRecordSize / sMaxAlign) + 1 ) * sMaxAlign;

                }
                */
                if ( sAlign > 0 && sColOffset % sAlign > 0 )
                {
                    sObject.mObj.mTableInfo.mTable.mRecordSize =
                        ( (sColOffset / sAlign) + 1 ) * sAlign;
                }
                else
                {
                    sObject.mObj.mTableInfo.mTable.mRecordSize = sColOffset;
                }

                /**************************************************************
                 * 컬럼 개수를 기입해 주는데 두개나 있네?
                 **************************************************************/
                sObject.mObj.mTableInfo.mTable.mColumnCount = sColCount;
                sObject.mObj.mTableInfo.mColumn.mCount = sColCount;
                for ( ; xj + 1 < xi; xj += 2 )
                {
                    if ( TOKEN_EQ_IC( sToken[xj], "init" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mTableInfo.mTable.mInitSize = atol( sToken[xj+1] );
                        _IF_THROW( sObject.mObj.mTableInfo.mTable.mInitSize == 0, ERR_DBM_SIZE_IS_ZERO );
                        _IF_THROW( sObject.mObj.mTableInfo.mTable.mMaxSize > 0
                            && sObject.mObj.mTableInfo.mTable.mInitSize > sObject.mObj.mTableInfo.mTable.mMaxSize, ERR_DBM_TOO_LARGE_INIT );
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "extend" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mTableInfo.mTable.mExtendSize = cmnGetBuddy( atol( sToken[xj+1] ) );
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "max" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mTableInfo.mTable.mMaxSize = atol( sToken[xj+1] );
                        _IF_THROW( sObject.mObj.mTableInfo.mTable.mInitSize > sObject.mObj.mTableInfo.mTable.mMaxSize, ERR_DBM_TOO_LARGE_INIT );
                    }
                    else
                    {
                        _THROW( ERR_DBM_SQL_PARSE );
                    }
                }
#ifdef _DEBUG2
                _PRT( "DEBUG] regen SQL : create direct table %s ", sObject.mObj.mTableInfo.mTable.mTableName );
                for ( int i = 0; i < sObject.mObj.mTableInfo.mTable.mColumnCount; i++ )
                {
                    if ( i > 0 )
                    {
                        _PRT( ", " );
                    }
                    _PRT( "%s", sObject.mObj.mTableInfo.mColumn.mCols[i].mColumnName );
                    switch( sObject.mObj.mTableInfo.mColumn.mCols[i].mColumnType )
                    {
                        case DBM_COLUMN_CHAR_TYPE:
                            _PRT( " char %d", sObject.mObj.mTableInfo.mColumn.mCols[i].mSize );
                            break;
                        case DBM_COLUMN_INT_TYPE:
                            _PRT( " int %d %d", sObject.mObj.mTableInfo.mColumn.mCols[i].mPrecision, sObject.mObj.mTableInfo.mColumn.mCols[i].mSize );
                            break;
                        case DBM_COLUMN_LONG_TYPE:
                            _PRT( " long %d %d", sObject.mObj.mTableInfo.mColumn.mCols[i].mPrecision, sObject.mObj.mTableInfo.mColumn.mCols[i].mSize );
                            break;
                        case DBM_COLUMN_DOUBLE_TYPE:
                            _PRT( " double %d %d", sObject.mObj.mTableInfo.mColumn.mCols[i].mPrecision, sObject.mObj.mTableInfo.mColumn.mCols[i].mSize );
                            break;
                        case DBM_COLUMN_FLOAT_TYPE:
                            _PRT( " float %d %d", sObject.mObj.mTableInfo.mColumn.mCols[i].mPrecision, sObject.mObj.mTableInfo.mColumn.mCols[i].mSize );
                            break;
                        case DBM_COLUMN_SHORT_TYPE:
                            _PRT( " short %d %d", sObject.mObj.mTableInfo.mColumn.mCols[i].mPrecision, sObject.mObj.mTableInfo.mColumn.mCols[i].mSize );
                            break;
                        case DBM_COLUMN_DATE_TYPE:
                            _PRT( " date" );
                            break;
                        default:
                            break;
                    }
                    _PRT( "(%d)", sObject.mObj.mTableInfo.mColumn.mCols[i].mOffset );
                }
                if ( sObject.mObj.mTableInfo.mTable.mInitSize != 0 ) _PRT( " init %lld", sObject.mObj.mTableInfo.mTable.mInitSize );
                if ( sObject.mObj.mTableInfo.mTable.mExtendSize != 0 ) _PRT( " extend %lld", sObject.mObj.mTableInfo.mTable.mExtendSize );
                if ( sObject.mObj.mTableInfo.mTable.mMaxSize != 0 ) _PRT( " max %lld", sObject.mObj.mTableInfo.mTable.mMaxSize );
                _PRT( ";\n" );
#endif
                break;
            case DBM_CREATE_QUEUE:
                if ( xi < 5 )
                {
#ifdef _DEBUG2
                    fprintf( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
                    _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                }
                /**************************************************************
                 * 객체 이름은 알파벳으로 시작해야한다.
                 **************************************************************/
                //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                if( isalpha( sToken[xj][0] ) == 0 )
                {
                    _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
                }

                _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );

                memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );

                sObject.mObj.mTableInfo.mTable.mTableType = DBM_TBL_QUEUE;

                xj++;

                if ( TOKEN_EQ_IC( sToken[xj], "msgsize" ) )
                {
                    sRet = cmnIsDigit( sToken[xj+1] );
                    _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                    xj++;
                    sObject.mObj.mTableInfo.mTable.mRecordSize = atoi( sToken[xj] );
                    _IF_THROW( sObject.mObj.mTableInfo.mTable.mRecordSize == 0, ERR_DBM_SIZE_IS_ZERO );
                    //sObject.mObj.mTableInfo.mColumn.mCols[0].mSize = atoi( sToken[j] );
                    //sObject.mObj.mTableInfo.mTable.mRecordSize = dbmCalcRecordSize( 0, atoi(sToken[j] ) );
                }
                else
                {
                    _THROW( ERR_DBM_SQL_PARSE );
                }
                for ( xj = xj + 1; xj + 1 < xi; xj += 2 )
                {
                    /*
                    if ( TOKEN_EQ_IC( sToken[j], "timeout" ) )
                    {
                        sObject.mObj.mTableInfo.mTable.mTimeOut = atoi( sToken[j+1] );
                    }
                    */
                    if ( TOKEN_EQ_IC( sToken[xj], "init" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mTableInfo.mTable.mInitSize = atol( sToken[xj+1] );
                        _IF_THROW( sObject.mObj.mTableInfo.mTable.mInitSize == 0, ERR_DBM_SIZE_IS_ZERO );
                        _IF_THROW( sObject.mObj.mTableInfo.mTable.mMaxSize > 0
                            && sObject.mObj.mTableInfo.mTable.mInitSize > sObject.mObj.mTableInfo.mTable.mMaxSize, ERR_DBM_TOO_LARGE_INIT );
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "extend" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mTableInfo.mTable.mExtendSize = cmnGetBuddy( atol( sToken[xj+1] ) );
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "max" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mTableInfo.mTable.mMaxSize = atol( sToken[xj+1] );
                        _IF_THROW( sObject.mObj.mTableInfo.mTable.mInitSize > sObject.mObj.mTableInfo.mTable.mMaxSize, ERR_DBM_TOO_LARGE_INIT );
                    }
                    else
                    {
                        _THROW( ERR_DBM_SQL_PARSE );
                    }
                }
                break;

                /* 2014.10.7 -shw- list 추가 */
            case DBM_CREATE_LIST:
                if ( xi < 5 )
                {
                    _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                }

                /**************************************************************
                 * 객체 이름은 알파벳으로 시작해야한다.
                 **************************************************************/
                if( isalpha( sToken[xj][0] ) == 0 )
                {
                    _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
                }

                _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );

                /* table name copy :
                 * create list l1(xj) msgsize 300 */
                memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );

                sObject.mObj.mTableInfo.mTable.mTableType = DBM_TBL_LIST;

                xj++;

                if ( TOKEN_EQ_IC( sToken[xj], "msgsize" ) )
                {
                    sRet = cmnIsDigit( sToken[xj+1] );
                    _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                    xj++;
                    sObject.mObj.mTableInfo.mTable.mRecordSize = atoi( sToken[xj] );
                    _IF_THROW( sObject.mObj.mTableInfo.mTable.mRecordSize == 0, ERR_DBM_SIZE_IS_ZERO );
                }
                else
                {
                    _THROW( ERR_DBM_SQL_PARSE );
                }



                for ( xj = xj + 1; xj + 1 < xi; xj += 2 )
                {
                    if ( TOKEN_EQ_IC( sToken[xj], "init" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mTableInfo.mTable.mInitSize = atol( sToken[xj+1] );
                        _IF_THROW( sObject.mObj.mTableInfo.mTable.mInitSize == 0, ERR_DBM_SIZE_IS_ZERO );
                        _IF_THROW( sObject.mObj.mTableInfo.mTable.mMaxSize > 0
                            && sObject.mObj.mTableInfo.mTable.mInitSize > sObject.mObj.mTableInfo.mTable.mMaxSize, ERR_DBM_TOO_LARGE_INIT );
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "extend" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mTableInfo.mTable.mExtendSize = cmnGetBuddy( atol( sToken[xj+1] ) );
                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "max" ) )
                    {
                        sRet = cmnIsDigit( sToken[xj+1] );
                        _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                        sObject.mObj.mTableInfo.mTable.mMaxSize = atol( sToken[xj+1] );
                        _IF_THROW( sObject.mObj.mTableInfo.mTable.mInitSize > sObject.mObj.mTableInfo.mTable.mMaxSize, ERR_DBM_TOO_LARGE_INIT );
                    }
                    else
                    {
                        _THROW( ERR_DBM_SQL_PARSE );
                    }
                }

                break;

                /* 2015.03.12 -shw- sequence table parser 추가 */
            case DBM_CREATE_SEQUENCE:

                if ( xi < 3 )
                {
#ifdef _DEBUG2
                    fprintf( stderr, "not enough argument(s) for '%s %s %s' clause\n", sToken[0], sToken[1], sToken[2] );
#endif
                    _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                }

                /**************************************************************
                 * 객체 이름은 알파벳으로 시작해야한다.
                 **************************************************************/
                if( isalpha( sToken[xj][0] ) == 0 )
                {
                    _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
                }

                _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );

                memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );
                sObject.mObj.mTableInfo.mTable.mTableType = DBM_TBL_SEQUENCE;


                for ( xj = xj + 1; xj < xi; xj++ )
                {
                    if ( xj >= xi )
                    {
#ifdef _DEBUG2
                        fprintf( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
                        _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                    }

                    /**************************************************************
                     * 같은 컬럼이 있는지 확인한다.
                     **************************************************************/
                    for ( int i = 0; i < sColCount; i++ )
                    {
                        if ( TOKEN_EQ( sObject.mObj.mTableInfo.mColumn.mCols[i].mColumnName, sToken[xj] ) )
                        {
                            _THROW( ERR_DBM_DUP_COLUMN );
                        }
                    }

                    /**************************************************************
                     * 객체 이름은 알파벳으로 시작해야한다.
                     **************************************************************/
                    _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                    _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_COLUMN_NAME_TOO_LONG );

                    if( TOKEN_EQ_IC( sToken[xj], "no" ) )
                    {
                        memcpy_s( sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnName, sToken[xj+1], strlen_s( sToken[xj+1] ) );
                    }
                    else
                    {
                        memcpy_s( sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );
                    }

                    if ( TOKEN_EQ_IC( sToken[xj], "increment" ) )
                    {
                        /* by 증가 값 */
                        xj++;

                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_INT_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 4;
                        sColOffset = mCalcOffset( 4, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 4 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 4, sAlign );

                        /* value 증가 값 */
                        xj++;

                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "start" ) )
                    {
                        /* by 증가 값 */
                        xj++;

                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_LONG_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 8;
                        sColOffset = mCalcOffset( 8, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 8 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 8, sAlign );

                        /* value 증가 값 */
                        xj++;

                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "maxvalue" ) )
                    {

                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_LONG_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 8;
                        sColOffset = mCalcOffset( 8, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 8 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 8, sAlign );

                        /* value 증가 값 */
                        xj++;

                    }
                    else if ( TOKEN_EQ_IC( sToken[xj], "minvalue" ) )
                    {

                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_LONG_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 8;
                        sColOffset = mCalcOffset( 8, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 8 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 8, sAlign );

                        /* value 증가 값 */
                        xj++;

                    }
                    else
                    if ( TOKEN_EQ_IC( sToken[xj], "cycle" ) || TOKEN_EQ_IC( sToken[xj], "no" ) )
                    {
                        /* no cycle  증가 */
                        if ( TOKEN_EQ_IC( sToken[xj], "no" ) )
                        {
                            xj++;
                        }

                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_CHAR_TYPE;
                            //sRet = cmnIsDigit( sToken[xj+1] );
                            //_IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );

                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 1;
                        _IF_THROW( sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize == 0, ERR_DBM_SIZE_IS_ZERO );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 1 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 1 , sAlign );

#if 0
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_INT_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 4;
                        sColOffset = mCalcOffset( 4, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 4 );
                        sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 4, sAlign );
#endif
                    }
                    else
                    if ( TOKEN_EQ_IC( sToken[xj], "key" ) )
                    {
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mColumnType = DBM_COLUMN_INT_TYPE;
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize = 4;
                        sColOffset = mCalcOffset( 4, sColOffset );
                        sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mOffset = sColOffset;
                        sAlign = mCalcAlign( sAlign, 4 );
                        //sObject.mObj.mTableInfo.mTable.mRecordSize = mCalcRecordSize( sColOffset, 4, sAlign );

                        /* value 증가 값 */
                        xj++;

                    }
                    else
                    {
                        _THROW( ERR_DBM_INVALID_DATATYPE );
                    }

                    sColOffset += sObject.mObj.mTableInfo.mColumn.mCols[sColCount].mSize;
                    sColCount++;
                }



                /**************************************************************
                 * 전체 테이블 사이즈의 가장 큰 자료형의 Align 으로 검사
                 *************************************************************/
                /*
                if ( sMaxAlign > 0 && sObject.mObj.mTableInfo.mTable.mRecordSize % sMaxAlign  > 0 )
                {
                    sObject.mObj.mTableInfo.mTable.mRecordSize =
                        ((sObject.mObj.mTableInfo.mTable.mRecordSize / sMaxAlign) + 1 ) * sMaxAlign;

                }
                */
                if ( sAlign > 0 && sColOffset % sAlign > 0 )
                {
                    sObject.mObj.mTableInfo.mTable.mRecordSize =
                        ( (sColOffset / sAlign) + 1 ) * sAlign;
                }
                else
                {
                    sObject.mObj.mTableInfo.mTable.mRecordSize = sColOffset;
                }

                //_PRT( "align [%d], recore size [%d]\n", sAlign, sObject.mObj.mTableInfo.mTable.mRecordSize );
                /**************************************************************
                 * 컬럼 개수를 기입해 주는데 두개나 있네?
                 **************************************************************/
                sObject.mObj.mTableInfo.mTable.mColumnCount = sColCount;
                sObject.mObj.mTableInfo.mColumn.mCount = sColCount;
                break;

            case DBM_CREATE_INDEX:
                /**************************************************************
                 * 인자가 충분한지 검사한다.
                 **************************************************************/
                //if ( j+4 < 6 )
                if ( xi - xj < 4 )
                {
#ifdef _DEBUG2
                    fprintf( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
                    _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                }
                /**************************************************************
                 * 객체 이름은 알파벳으로 시작해야한다.
                 **************************************************************/
                //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                if( isalpha( sToken[xj][0] ) == 0 )
                {
                    _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
                }

                _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );

                //memcpy_s( sObject.mObj.mIndex.mIndexName, sToken[xj], strlen_s( sToken[xj] ) );
                cmnStrCpyZ( sObject.mObj.mIndex.mIndexName, sToken[xj] );

                //PID 제거에 따른 임시 주석 처리
                //dbmInitPID( &sObject.mObj.mIndex.mHdrPID );
                if ( TOKEN_EQ_IC( sToken[xj+1], "on" ) )
                {
                    xj = xj+2;
                    /**************************************************************
                     * 객체 이름은 알파벳으로 시작해야한다.
                     **************************************************************/
                    //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                    if( isalpha( sToken[xj][0] ) == 0 )
                    {
                        _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
                    }

                    _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
                    memcpy_s( sObject.mObj.mIndex.mTableName, sToken[xj], strlen_s( sToken[xj] ) );

                    /**************************************************************
                     * TODO: 색인 종류는 어떻게 입력받는지 모르겠어서 고정함.
                     **************************************************************/
                    sObject.mObj.mIndex.mIndexType = DBM_INDEX_BTREE;

                    if ( xj+1 < xi )
                    {
                        for ( xj = xj+1; xj < xi; xj++ )
                        {
                            /*
                            if ( TOKEN_EQ_IC( sToken[j], "init" ) || TOKEN_EQ_IC( sToken[j], "extend" ) || TOKEN_EQ_IC( sToken[j], "max" ) )
                                break;
                             */

                            /**************************************************************
                             * 같은 컬럼이 있는지 확인한다.
                             **************************************************************/
                            for ( int i = 0; i < sColCount; i++ )
                            {
                                if ( TOKEN_EQ( sObject.mObj.mIndex.mKey[i].mColumnName, sToken[xj] ) )
                                {
                                    _THROW( ERR_DBM_DUP_COLUMN );
                                }
                            }
                            /**************************************************************
                             * 객체 이름은 알파벳으로 시작해야한다.
                             **************************************************************/
                            _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                            _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_COLUMN_NAME_TOO_LONG );

                            memcpy_s( sObject.mObj.mIndex.mKey[sColCount].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );

                            sColCount++;
                        }
                        sObject.mObj.mIndex.mColumnCount = sColCount;

                        // #824 2015.02.24 -okt- 인덱스 컬럼개수 6개에서 32개로 늘림. - mCreateDDL() 성능함수 아니고 단순 검사임.
                        _IF_THROW( sObject.mObj.mIndex.mColumnCount > DBM_MAX_COLUMN_PER_INDEX,
                                   ERR_DBM_TOO_MANY_KEY_COLUMN );
                    }
                    if ( sObject.mObj.mIndex.mColumnCount == 0 )
                    {
                        _THROW( ERR_DBM_COLUMN_NOT_SPECIFY );
                    }
                    /*
                    for ( ; j + 1 < i; j = j + 2 )
                    {
                        if ( TOKEN_EQ_IC( sToken[j], "init" ) )
                        {
                            sRet = cmnIsDigit( sToken[j+1] );
                            _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                            sObject.mObj.mTableInfo.mTable.mInitSize = atol( sToken[j+1] );
                        }
                        else if ( TOKEN_EQ_IC( sToken[j], "extend" ) )
                        {
                            sRet = cmnIsDigit( sToken[j+1] );
                            _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                            sObject.mObj.mTableInfo.mTable.mExtendSize = cmnGetBuddy( atol( sToken[j+1] ) );
                        }
                        else if ( TOKEN_EQ_IC( sToken[j], "max" ) )
                        {
                            sRet = cmnIsDigit( sToken[j+1] );
                            _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                            sObject.mObj.mTableInfo.mTable.mMaxSize = atol( sToken[j+1] );
                            _IF_THROW( sObject.mObj.mTableInfo.mTable.mInitSize > sObject.mObj.mTableInfo.mTable.mMaxSize, ERR_DBM_TOO_LARGE_INIT );
                        }
                        else
                        {
                            fprintf( stderr, "invalid arg -- '%s'\n", sToken[j] );
                            _THROW( ERR_DBM_SQL_PARSE );
                        }
                    }
                    */
                }
                else
                {
                    _THROW( ERR_DBM_SQL_PARSE );
                }
#ifdef _DEBUG2
                _PRT( "DEBUG] regen SQL : create index %s on %s(", sObject.mObj.mIndex.mIndexName, sObject.mObj.mIndex.mTableName );
                for ( int i = 0; i < sColCount; i++ )
                {
                    if ( i > 0 )
                    {
                        _PRT( ", " );
                    }
                    _PRT( "%s", sObject.mObj.mIndex.mKey[i].mColumnName );
                }
                _PRT( ");\n" );
#endif
                break;
            case DBM_CREATE_TRIG:
                if ( xi < 5 )
                {
#ifdef _DEBUG2
                    fprintf( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
                    _THROW( ERR_DBM_NOT_ENOUGH_ARG );
                }

                /**************************************************************
                 * 객체 이름은 알파벳으로 시작해야한다.
                 **************************************************************/
                //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                if( isalpha( sToken[xj][0] ) == 0 )
                {
                    _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
                }

                _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
                memcpy_s( sObject.mObj.mEvent.mTriggerName, sToken[xj], strlen_s( sToken[xj] ) );

                xj++;

                _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
                memcpy_s( sObject.mObj.mEvent.mEventSrc, sToken[xj], strlen_s( sToken[xj] ) );

                xj++;

                _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
                memcpy_s( sObject.mObj.mEvent.mEventTrg, sToken[xj], strlen_s( sToken[xj] ) );
                break;

            default:
                _THROW( ERR_DBM_NOT_DEFINE_SQLTYPE );
                break;
        }
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_NOT_ALPHA )
        {
            _CATCH_INFO;
        }
        else
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mCreateDDL */

_VOID dbmParser::mDropDDL( )
{
    _TRY
    {
        xj++;
        if ( xi < 3 )
        {
#ifdef _DEBUG2
            fprintf( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
            _THROW( ERR_DBM_NOT_ENOUGH_ARG );
        }
        /**************************************************************
         * 객체 이름은 알파벳으로 시작해야한다.
         **************************************************************/
        //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
        if( isalpha( sToken[xj][0] ) == 0 )
        {
            _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
        }
        _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );

        switch( sObject.mSQLType )
        {
            case DBM_DROP_INST:
                memcpy_s( sObject.mObj.mInstance.mInstanceName, sToken[xj], strlen_s( sToken[xj] ) );
                break;

            case DBM_DROP_TABLE:
            case DBM_DROP_QUEUE:
            case DBM_DROP_SEQUENCE:
            case DBM_DROP_LIST:     //TODO: [OKT] 확인안됨
                memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );
                break;

            case DBM_DROP_INDEX:
                // TODO: [BUGBUG] NOCS 프로젝트에서 INDEX 이름이 32를 넘는게 있어서. 임시로 수정한 코드임. ( 2015.04.08 -okt )
                //       NOCS 테스트도 돌려야하므로, 원복은 안되고 DBM_NAME_LEN을 영향도 보고 늘려야함.
                //memcpy_s( sObject.mObj.mIndex.mIndexName, sToken[xj], strlen_s( sToken[xj] ) );
                cmnStrCpyZ( sObject.mObj.mIndex.mIndexName, sToken[xj] );
                break;

            case DBM_DROP_TRIG:
                memcpy_s( sObject.mObj.mEvent.mTriggerName, sToken[xj], strlen_s( sToken[xj] ) );
                break;

            default:
                _THROW( ERR_DBM_NOT_DEFINE_SQLTYPE );
                break;
        }

#ifdef _DEBUG2
        switch( sObject.mSQLType )
        {
            case DBM_DROP_INST:
                _PRT( "DEBUG] regen SQL : drop undo %s;\n", sObject.mObj.mInstance.mInstanceName );
                break;

            case DBM_DROP_TABLE:
            case DBM_DROP_QUEUE:
            case DBM_DROP_SEQUENCE:
            case DBM_DROP_LIST:
                _PRT( "DEBUG] regen SQL : drop table %s;\n", sObject.mObj.mTableInfo.mTable.mTableName );
                break;

            case DBM_DROP_INDEX:
                _PRT( "DEBUG] regen SQL : drop index %s;\n", sObject.mObj.mTableInfo.mTable.mTableName );
                break;

            case DBM_DROP_TRIG:
                _PRT( "DEBUG] regen SQL : drop trigger %s;\n", sObject.mObj.mEvent.mTriggerName );
                break;

            default:
                NULL;
                break;
        }
#endif
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mDropDDL */


_VOID dbmParser::mDeleteDML( )
{
    int     k       = 0;
    int     i       = 0;
    int     j       = 0;
    int     m       = 0;
    int     sCheck  = 0;
    int     sCheck2 = 0;


    _TRY
    {
        if ( xi < 3 )
        {
#ifdef _DEBUG2
            fprintf( stderr, "not enough argument(s) for '%s' clause\n", sToken[0] );
#endif
            _THROW( ERR_DBM_NOT_ENOUGH_ARG );
        }
        xj++;
        if ( TOKEN_NE_IC( sToken[xj], "from" ) )
        {
            _THROW( ERR_DBM_SQL_PARSE );
        }
        xj++;
        /**************************************************************
         * 객체 이름은 알파벳으로 시작해야한다.
         **************************************************************/
        //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
        if( isalpha( sToken[xj][0] ) == 0 )
        {
            _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
        }

        _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
        memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );

//        sObject.mObj.mDataSet = aObject->mObj.mDataSet;

        sDataSet    = (dbmDataSet*)sObject.mObj.mDataSet;
        sDataSet2   = (dbmDataSet*)sObject.mDataSet2;


        /* between check :
         * 2014.09.15 -shw-
         * 구문중에 between 구문이 있는지 체크해 본다 */
        for( i=xj+1; i<xi; i++ )
        {
            if( TOKEN_EQ_IC( sToken[i], "between" ) || TOKEN_EQ_IC( sToken[i], "BETWEEN" ) )
            {
                sDataSet->mCount3 = 3;
                break;
            }
        }

        xj++;

        if ( xj < xi && sDataSet->mCount3 != 3 )
        {
            if ( TOKEN_NE_IC( sToken[xj], "where" ) )
            {
                _THROW( ERR_DBM_SQL_PARSE );
            }
            for ( xj += 1; xj < xi; xj += 3 )
            {
                _IF_THROW( xj + 3 > xi, ERR_DBM_SQL_PARSE );
                /**************************************************************
                 * 같은 컬럼이 있는지 확인한다.
                 **************************************************************/
                if ( sDataSet->mCount > 0 )
                {
                    if ( TOKEN_EQ_IC( sToken[xj], "and" ) )
                    {
                        xj++;
                    }

                    for ( int i = 0; i < sDataSet->mCount; i++ )
                    {
                        if ( TOKEN_EQ( sDataSet->mCols[i].mColumnName, sToken[xj] ) )
                        {
                            _THROW( ERR_DBM_DUP_COLUMN );
                        }
                    }
                }
                /**************************************************************
                 * 객체 이름은 알파벳으로 시작해야한다.
                 **************************************************************/
                _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                strncpy( sDataSet->mCols[k].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );
                if ( TOKEN_EQ( sToken[xj + 1], "=" ) && strlen_s( sToken[xj + 1] ) == 1 )
                {
                    sDataSet->mCols[k].mSign = DBM_EQ;
                }
                else if ( TOKEN_EQ( sToken[xj + 1], "!=" ) )
                {
                    sDataSet->mCols[k].mSign = DBM_NE;
                }
                else if ( TOKEN_EQ( sToken[xj + 1], "<" ) )
                {
                    sDataSet->mCols[k].mSign = DBM_LT;
                }
                else if ( TOKEN_EQ( sToken[xj + 1], "<=" ) )
                {
                    sDataSet->mCols[k].mSign = DBM_LE;
                }
                else if ( TOKEN_EQ( sToken[xj + 1], "=<" ) )
                {
                    sDataSet->mCols[k].mSign = DBM_LE;
                }
                else if ( TOKEN_EQ( sToken[xj + 1], ">" ) )
                {
                    sDataSet->mCols[k].mSign = DBM_GT;
                }
                else if ( TOKEN_EQ( sToken[xj + 1], ">=" ) )
                {
                    sDataSet->mCols[k].mSign = DBM_GE;
                }
                else if ( TOKEN_EQ( sToken[xj + 1], "=>" ) )
                {
                    sDataSet->mCols[k].mSign = DBM_GE;
                }
                else
                {
                    _THROW( ERR_DBM_NOT_SUPPORT_SIGN );
                }

                strncpy( sDataSet->mCols[k].mData, sToken[xj + 2], strlen_s( sToken[xj + 2] ) );
                sDataSet->mCount++;
                k++;
            }
        }

        if ( xj < xi && sDataSet->mCount3 == 3 )
        {
            if ( TOKEN_NE_IC( sToken[xj], "where" ) )
            {
                _THROW( ERR_DBM_SQL_PARSE );
            }

            for ( xj += 1 ; xj < xi; xj++ )
            {
                if( (TOKEN_NE_IC( sToken[xj], "between") && TOKEN_NE_IC( sToken[xj], "BETWEEN")) && sCheck != 1 )
                {
                    _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                    strncpy( sDataSet->mCols[k].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );
                    sDataSet->mCols[k].mSign = DBM_BT;
                    sDataSet->mCount++;
                    k++;
                    continue;
                }

                if( TOKEN_EQ_IC( sToken[xj], "between") || TOKEN_EQ_IC( sToken[xj], "BETWEEN") )
                {
                    sCheck = 1;
                    xj++;
                }

                if ( sDataSet->mCount > 0 )
                {
                    if ( TOKEN_EQ_IC( sToken[xj], "and" ) )
                    {
                        xj++;
                        sCheck2 = 1;
                    }
                }

                if( sCheck2 == 0 )
                {
                    strncpy( sDataSet->mCols[j].mData, sToken[xj], strlen_s(sToken[xj]) );
                    j++;
                }
                else
                {
                    strncpy( sDataSet2->mCols[m].mData, sToken[xj], strlen_s(sToken[xj]) );
                    m++;
                }
            }
        }

        _IF_THROW( xj < xi, ERR_DBM_SQL_PARSE );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mDeleteDML */

_VOID dbmParser::mUpdateDML( )
{
    int     k       = 0;
    int     i       = 0;
    int     j       = 0;
    int     m       = 0;
    int     sCheck  = 0;
    int     sCheck2 = 0;

    _TRY
    {
        if ( xi < 6 )
        {
#ifdef _DEBUG2
            fprintf( stderr, "not enough argument(s) for '%s' clause\n", sToken[0] );
#endif
            _THROW( ERR_DBM_NOT_ENOUGH_ARG );
        }

        xj++;
        /**************************************************************
         * 객체 이름은 알파벳으로 시작해야한다.
         **************************************************************/
        //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
        if( isalpha( sToken[xj][0] ) == 0 )
        {
            _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
        }

        _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
        memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );
        xj++;
        if ( TOKEN_NE_IC( sToken[xj], "set" ) )
        {
            _THROW( ERR_DBM_SQL_PARSE );
        }

//        sObject.mObj.mDataSet = aObject->mObj.mDataSet;

        sDataSet = (dbmDataSet*)sObject.mObj.mDataSet;
        sDataSet2= (dbmDataSet*)sObject.mDataSet2;


        /* between check :
         * 2014.09.15 -shw-
         * 구문중에 between 구문이 있는지 체크해 본다 */
        for( i=xj+1; i<xi; i++ )
        {
            if( TOKEN_EQ_IC( sToken[i], "between" ) || TOKEN_EQ_IC( sToken[i], "BETWEEN" ) )
            {
                sDataSet->mCount3 = 3;
                break;
            }
        }


        for ( xj += 1 ; xj < xi; xj += 3 )
        {
            if ( TOKEN_EQ_IC( sToken[xj], "where" )
                    && xj != 3 )
            {
                break;
            }
            _IF_THROW( xj + 3 > xi, ERR_DBM_SQL_PARSE );
            /**************************************************************
             * 같은 컬럼이 있는지 확인한다.
             **************************************************************/
            for ( int i = 0; i < sDataSet->mCount; i++ )
            {
                if ( TOKEN_EQ( sDataSet->mCols[i].mColumnName, sToken[xj] ) )
                {
                    _THROW( ERR_DBM_DUP_COLUMN );
                }
            }
            /**************************************************************
             * 객체 이름은 알파벳으로 시작해야한다.
             **************************************************************/
            _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
            _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_COLUMN_NAME_TOO_LONG );

            strncpy( sDataSet->mCols[k].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );

            /* 2014.09.17 -shw- range update 관련되어 >,<,between 추가 */
            if ( TOKEN_EQ( sToken[xj + 1], "=" ) )
            {
                sDataSet->mCols[k].mSign = DBM_EQ;
            }
            else
            {
                _THROW( ERR_DBM_SQL_PARSE );
            }

            strncpy( sDataSet->mCols[k].mData, sToken[xj + 2], strlen_s( sToken[xj + 2] ) );
            sDataSet->mCount++;
            k++;
        }

        if ( xj < xi && sDataSet->mCount3 != 3 )
        {
            i = 0; // 초기값 처리

            if ( TOKEN_NE_IC( sToken[xj], "where" ) )
            {
                _THROW( ERR_DBM_SQL_PARSE );
            }
            for ( xj += 1 ; xj < xi; xj += 3 )
            {
                _IF_THROW( xj + 3 > xi, ERR_DBM_SQL_PARSE );
                /**************************************************************
                 * 같은 컬럼이 있는지 확인한다.
                 **************************************************************/
                if ( sDataSet->mCount > 0 )
                {
                    if ( TOKEN_EQ_IC( sToken[xj], "and" ) )
                    {
                        xj++;
                    }
                    for ( int i = sDataSet->mCount; i < sDataSet->mCount + sDataSet->mCount2; i++ )
                    {
                        if ( TOKEN_EQ( sDataSet->mCols[i].mColumnName, sToken[xj] ) )
                        {
                            _THROW( ERR_DBM_DUP_COLUMN );
                        }
                    }
                }
                /**************************************************************
                 * 객체 이름은 알파벳으로 시작해야한다.
                 **************************************************************/
                _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_COLUMN_NAME_TOO_LONG );

                strncpy( sDataSet->mCols[k].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );
                if ( TOKEN_EQ( sToken[xj + 1], "=" ) && strlen_s( sToken[xj + 1] ) == 1 )
                {
                    sDataSet->mCols[k].mSign = DBM_EQ;
                }
                else if ( TOKEN_EQ( sToken[xj + 1], "!=" ) )
                {
                    sDataSet->mCols[k].mSign = DBM_NE;
                }
                else if ( TOKEN_EQ( sToken[xj + 1], "<" ) )
                {
                    /* range update : 2014.09.17 -shw-
                     * update 에서 < > .. 등호 조건은 지원하지 않아 현재의 부등호 조건들은
                     * 필요 없어 부등호 조건에서는 k가 별 위미  없지만 형식을 맞추기 위해
                     * i값을 주어 처리 하도록 하였다. 0번째의 flge로 등호 조건의 값을 체크
                     * 하기 때문이다 */
                    sDataSet->mCols[k].mSign = DBM_LT;
                    sDataSet->mCols[i].mSign = DBM_LT;
                }
                else if ( TOKEN_EQ( sToken[xj + 1], "<=" ) )
                {
                    sDataSet->mCols[k].mSign = DBM_LE;
                }
                else if ( TOKEN_EQ( sToken[xj + 1], ">" ) )
                {
                    sDataSet->mCols[k].mSign = DBM_GT;
                    sDataSet->mCols[i].mSign = DBM_GT;
                }
                else if ( TOKEN_EQ( sToken[xj + 1], ">=" ) )
                {
                    sDataSet->mCols[k].mSign = DBM_GE;
                }
                else
                {
                    _THROW( ERR_DBM_NOT_SUPPORT_SIGN );
                }

                strncpy( sDataSet->mCols[k].mData, sToken[xj + 2], strlen_s( sToken[xj + 2] ) );
                sDataSet->mCount2++;
                k++;
                i++;
            }
        }

        if ( xj < xi && sDataSet->mCount3 == 3 )
        {
            /* columnn move 관련 imsi 변수로 처리 한다 */
            m = k;

            if ( TOKEN_NE_IC( sToken[xj], "where" ) )
            {
                _THROW( ERR_DBM_SQL_PARSE );
            }

            for ( xj += 1 ; xj < xi; xj++ )
            {
                if( (TOKEN_NE_IC( sToken[xj], "between") && TOKEN_NE_IC( sToken[xj], "BETWEEN")) && sCheck != 1 )
                {
                    /* c1 c2 between 에서 c1, c2 처리 */
                    _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );

                    strncpy( sDataSet->mCols[k].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );

                    /* 0으로 한번 넣는 이유는 0번째 값을 이용하여 type 체크를 하기 때문이다 */
                    sDataSet->mCols[0].mSign = DBM_BT;
                    sDataSet->mCols[m].mSign = DBM_BT;

                    sDataSet->mCount2++;

                    m++;

                    continue;
                }

                if( TOKEN_EQ_IC( sToken[xj], "between") || TOKEN_EQ_IC( sToken[xj], "BETWEEN") )
                {
                    sCheck = 1;
                    xj++;
                }

                if ( sDataSet->mCount2 > 0 )
                {
                    if ( TOKEN_EQ_IC( sToken[xj], "and" ) )
                    {
                        xj++;
                        sCheck2 = 1;
                    }
                }

                if( sCheck2 == 0 )
                {
                    strncpy( sDataSet->mCols[k].mData, sToken[xj], strlen_s(sToken[xj]) );
                    k++;
                }
                else
                {
                    strncpy( sDataSet2->mCols[j].mData, sToken[xj], strlen_s(sToken[xj]) );
                    j++;
                }
            }
        }

        _IF_THROW( xj < xi, ERR_DBM_SQL_PARSE );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mUpdateDML */


_VOID dbmParser::mSelectDML( )
{
    char*   sPos    = NULL;
    int     k       = 0;
    int     sRet    = 0;
    int     i       = 0;
    int     j       = 0;
    int     m       = 0;
    int     sCheck  = 0;
    int     sCheck2 = 0;

    _TRY
    {
        if ( xi < 3 )
        {
#ifdef _DEBUG2
            fprintf( stderr, "not enough argument(s) for '%s' clause\n", sToken[0] );
#endif
            _THROW( ERR_DBM_NOT_ENOUGH_ARG );
        }
        //j++;

//        sObject.mObj.mDataSet = aObject->mObj.mDataSet;

        sDataSet    = (dbmDataSet*)sObject.mObj.mDataSet;
        sDataSet2   = (dbmDataSet*)sObject.mDataSet2;

        for ( xj += 1; xj < xi; xj++ )
        {
            /**************************************************************
             * '*' 지원. '*'를 별도로 처리해주면 좋은데,
             * 그냥 break해도 의도한 데로 동작하게 된다.
             **************************************************************/
            if ( TOKEN_EQ( sToken[xj], "*" ) && xj == 1 )
            {
                xj++;
                break;
            }
            //if ( TOKEN_EQ_IC( sToken[j], "from" ) && j != 1 )
            if ( TOKEN_EQ_IC( sToken[xj], "from" ) )
            {
                break;
            }

            /* 2014.09.15 -shw- select count 관련 column이 올 필요가 없기 때문에
             * break 빠져 나오도록 수정 한다 */
            if( TOKEN_EQ_IC( sToken[xj], "count") && xj == 1 )
            {
                /* select , count , (1-*), from, t1 */
                /* 2로 하는 이오눈 xj에서 +2하여 1,from 가져오기 위하여 */
                xj = xj + 2;

                /* mCount3 값을 1로 주어 해당 처리 type이 count라는 것을 알려준다 */
                sDataSet->mCount3 = 1;

                break;
            }

            /**************************************************************
             * 객체 이름은 알파벳으로 시작해야한다.
             **************************************************************/
            _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
            strncpy( sDataSet->mCols[k].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );
            sDataSet->mCount++;
            k++;
        }
        _IF_THROW( xj+1 >= xi, ERR_DBM_NOT_ENOUGH_ARG );
        if ( TOKEN_NE_IC( sToken[xj], "from" ) )
        {
            _THROW( ERR_DBM_SQL_PARSE );
        }
        xj++;
        /**************************************************************
         * 객체 이름은 알파벳으로 시작해야한다.select table_name, table_name from \$sys_table where inst_name = 'xx'
         **************************************************************/
        //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
        if( isalpha( sToken[xj][0] ) == 0 )
        {
            _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
        }

        sPos = strchr( sToken[xj], '.' );
        if( sPos == NULL )
        {
            _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
            memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );
        }
        else
        {
            memcpy_s( sObject.mObj.mTableInfo.mTable.mInstName, sToken[xj], sPos - sToken[xj] );
            _IF_THROW( strlen_s(sPos+1) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
            memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sPos + 1, strlen_s( sPos + 1 ) );
        }
        xj++;

        /* count 참고 : sDataSet->mCount3
         * 0 : count value x
         * 1 : count full scan
         * 2 : count 조건 검색
         * 3 : between 조건 검색
         * 4 : sequence value (여기에서 사용하는 것은 아니고
         *     utPrintSelectHeader 및 화면 출력시 해당 조건
         *     값을 가지고 처리 하도록 한다.
         */

        /* between check :
         * 2014.09.15 -shw-
         * 구문중에 between 구문이 있는지 체크해 본다 */
        for( i=xj+1; i<xi; i++ )
        {
            if( TOKEN_EQ_IC( sToken[i], "between" ) || TOKEN_EQ_IC( sToken[i], "BETWEEN" ) )
            {
                sDataSet->mCount3 = 3;
                break;
            }
        }


        if ( xj < xi && sDataSet->mCount3 != 3 )
        {
            if ( TOKEN_EQ_IC( sToken[xj], "where" ) )
            {
                _IF_THROW( (xi - xj + 1) / 3 < 1, ERR_DBM_NOT_ENOUGH_ARG );

                /* count value에서 조건값이 있는 것인지를 SET 한다. value 2이면 조건값 있음 */
                if( sDataSet->mCount3 == 1 )
                {
                    sDataSet->mCount3 = 2;
                }

                for ( xj += 1 ; xj < xi; xj += 3 )
                {
                    /**************************************************************
                     * limit 절을 지원.
                     **************************************************************/
                    if ( sDataSet->mCount2 > 0 && TOKEN_EQ_IC( sToken[xj], "limit" ) )
                    {
                        break;
                    }

                    _IF_THROW( xj + 3 > xi, ERR_DBM_SQL_PARSE );
                    /**************************************************************
                     * 같은 컬럼이 있는지 확인한다.
                     **************************************************************/
                    if ( sDataSet->mCount2 > 0 )
                    {
                        if ( TOKEN_EQ_IC( sToken[xj], "and" ) )
                        {
                            xj++;
                        }

                        /*
                         * 컬럼 중복 가능
                         *
                         * select table_name, table_name from $sys_table where inst_name = 'demo' and table_name = 't1';
                         */
//                        for ( int i = 0; i < sDataSet->mCount2; i++ )
//                        {
//                            if ( TOKEN_EQ( sDataSet->mCols[i].mColumnName, sToken[xj] ) )
//                            {
//                                _THROW( ERR_DBM_DUP_COLUMN );
//                            }
//                        }
                    }
                    /**************************************************************
                     * 객체 이름은 알파벳으로 시작해야한다.
                     **************************************************************/
                    _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                    strncpy( sDataSet->mCols[k].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );
                    if ( TOKEN_EQ( sToken[xj + 1], "=" ) && strlen_s( sToken[xj + 1] ) == 1 )
                    {
                        if( sDataSet->mCount3 == 2 )
                        {
                            sDataSet->mCols[k].mSign = DBM_CT;
                        }
                        else
                        {
                            sDataSet->mCols[k].mSign = DBM_EQ;
                        }
                    }
                    else if ( TOKEN_EQ( sToken[xj + 1], "!=" ) )
                    {
                        /* count 조건 :
                         * 2014.09.15 -shw-
                         * count 조건은 = , < , >  위의 3가지 타입만 지원한다 */
                        if( sDataSet->mCount3 == 2 )
                        {
                            _THROW(ERR_UTL_NOT_SUPPORT_SQLTYPE);
                        }

                        sDataSet->mCols[k].mSign = DBM_NE;
                    }
                    else if ( TOKEN_EQ( sToken[xj + 1], "<" ) )
                    {
                        if( sDataSet->mCount3 == 2 )
                        {
                            sDataSet->mCols[k].mSign = DBM_CT_LT;
                        }
                        else
                        {
                            sDataSet->mCols[k].mSign = DBM_LT;
                        }
                    }
                    else if ( TOKEN_EQ( sToken[xj + 1], "<=" ) )
                    {
                        if( sDataSet->mCount3 == 2 )
                        {
                            _THROW(ERR_UTL_NOT_SUPPORT_SQLTYPE);
                        }

                        sDataSet->mCols[k].mSign = DBM_LE;
                    }
                    else if ( TOKEN_EQ( sToken[xj + 1], "=<" ) )
                    {
                        if( sDataSet->mCount3 == 2 )
                        {
                            _THROW(ERR_UTL_NOT_SUPPORT_SQLTYPE);
                        }

                        sDataSet->mCols[k].mSign = DBM_LE;
                    }
                    else if ( TOKEN_EQ( sToken[xj + 1], ">" ) )
                    {
                        if( sDataSet->mCount3 == 2 )
                        {
                            sDataSet->mCols[k].mSign = DBM_CT_GT;
                        }
                        else
                        {
                            sDataSet->mCols[k].mSign = DBM_GT;
                        }
                    }
                    else if ( TOKEN_EQ( sToken[xj + 1], ">=" ) )
                    {
                        if( sDataSet->mCount3 == 2 )
                        {
                            _THROW(ERR_UTL_NOT_SUPPORT_SQLTYPE);
                        }

                        sDataSet->mCols[k].mSign = DBM_GE;
                    }
                    else if ( TOKEN_EQ( sToken[xj + 1], "=>" ) )
                    {
                        if( sDataSet->mCount3 == 2 )
                        {
                            _THROW(ERR_UTL_NOT_SUPPORT_SQLTYPE);
                        }

                        sDataSet->mCols[k].mSign = DBM_GE;
                    }
                    else
                    {
                        _THROW( ERR_DBM_NOT_SUPPORT_SIGN );
                    }

                    strncpy( sDataSet->mCols[k].mData, sToken[xj + 2], strlen_s( sToken[xj + 2] ) );
                    sDataSet->mCount2++;
                    k++;

                } // for ( xj += 1 ; xj < xi; xj += 3 )

            } // if ( TOKEN_EQ_IC( sToken[xj], "where" ) )

        } // if ( xj < xi )

        /* between 처리 */
        if ( xj < xi && sDataSet->mCount3 == 3 )
        {
            if ( TOKEN_EQ_IC( sToken[xj], "where" ) )
            {
                _IF_THROW( (xi - xj + 1) / 3 < 1, ERR_DBM_NOT_ENOUGH_ARG );

                for ( xj += 1 ; xj < xi; xj++ )
                {

                    if( (TOKEN_NE_IC( sToken[xj], "between") && TOKEN_NE_IC( sToken[xj], "BETWEEN")) && sCheck != 1 )
                    {
                        _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );

                        strncpy( sDataSet->mCols[k].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );

                        sDataSet->mCols[k].mSign = DBM_BT;

                        sDataSet->mCount2++;

                        k++;

                        continue;
                    }

                    if( TOKEN_EQ_IC( sToken[xj], "between") || TOKEN_EQ_IC( sToken[xj], "BETWEEN") )
                    {
                        sCheck = 1;

                        xj++;
                    }

                    /**************************************************************
                     * 같은 컬럼이 있는지 확인한다.
                     **************************************************************/
                    if ( sDataSet->mCount2 > 0 )
                    {
                        if ( TOKEN_EQ_IC( sToken[xj], "and" ) )
                        {
                            xj++;
                            sCheck2 = 1;
                        }
                    }

                    if( sCheck2 == 0 )
                    {
                        strncpy( sDataSet->mCols[j].mData, sToken[xj], strlen_s(sToken[xj]) );
                        j++;
                    }
                    else
                    {
                        strncpy( sDataSet2->mCols[m].mData, sToken[xj], strlen_s(sToken[xj]) );
                        m++;
                    }

                } /* End of for() */
            } /* End of IF() */
        } /* End of IF() */


        if ( xj < xi )
        {
            /**************************************************************
             * limit 절을 지원.
             **************************************************************/
            //if ( xj + 1 < xi && sDataSet->mCount2 > 0 && TOKEN_EQ_IC( sToken[xj], "limit" ) )
            if ( TOKEN_EQ_IC( sToken[xj], "limit" ) )
            {
                _IF_THROW( xj + 1 >= xi, ERR_DBM_NOT_ENOUGH_ARG );

                sRet = cmnIsDigit( sToken[xj+1] );
                _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );

                // limit 2 offset 10;
                if ( xj + 1 + 2 <= xi && TOKEN_EQ_IC( sToken[xj+2], "offset" ) )
                {
                    sRet = cmnIsDigit( sToken[xj+3] );
                    _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );

                    sDataSet->mLimit = atoi(sToken[xj+1]);
                    sDataSet->mLimitOffset = atoi(sToken[xj+3]);
                    xj += 4;
                }
                // limit 10, 2;
                else if ( xj + 1 + 1 <= xi && ( cmnIsDigit( sToken[xj+2] ) == TRUE ) )
                {
                    sDataSet->mLimitOffset = atoi(sToken[xj+1]);
                    sDataSet->mLimit = atoi(sToken[xj+2]);
                    xj += 3;
                }
                // limit 10;
                else
                {
                    sDataSet->mLimitOffset = 1;
                    sDataSet->mLimit = atoi(sToken[xj+1]);
                    xj += 2;
                }
            }
        }

        _IF_THROW( xj < xi, ERR_DBM_SQL_PARSE );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mSelectDML */

_VOID dbmParser::mSequenceDML()
{
    int     k = 0;
    char    sDel[] = ".";
    char*   sTokenPar = NULL;
    char*   sTokenPos = NULL;


    _TRY
    {
        xj++;

        if ( xi < 4 )
        {
            _THROW( ERR_DBM_NOT_ENOUGH_ARG );
        }

        /**************************************************************
         * 객체 이름은 알파벳으로 시작해야한다.
         **************************************************************/
        if( isalpha( sToken[xj][0] ) == 0 )
        {
            _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
        }

        _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );

        sTokenPar = strtok_r_s ( sToken[xj], sDel, &sTokenPos );
        memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sTokenPar, strlen_s( sTokenPar ) );

        sDataSet = (dbmDataSet*)sObject.mObj.mDataSet;

        if ( sDataSet->mCount == 0 )
        {
            strncpy( sDataSet->mCols[k].mColumnName, "key", 3 );
            sDataSet->mCols[k].mSign = DBM_EQ;
            strncpy( sDataSet->mCols[k].mData, "1" , 1 );
            sDataSet->mCount++;
        }
        else
        {
            _THROW( ERR_DBM_NOT_ENOUGH_VALUE );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mSequenceDML() */

_VOID dbmParser::mInsertDML( )
{
    int     k = 0;

    _TRY
    {
        xj++;
        if ( xi < 5 )
        {
#ifdef _DEBUG2
            fprintf( stderr, "not enough argument(s) for '%s %s' clause\n", sToken[0], sToken[1] );
#endif
            _THROW( ERR_DBM_NOT_ENOUGH_ARG );
        }

        if ( TOKEN_NE_IC( sToken[xj], "into" ) )
        {
            _THROW( ERR_DBM_SQL_PARSE );
        }
        xj++;

        /**************************************************************
         * 객체 이름은 알파벳으로 시작해야한다.
         **************************************************************/
        //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
        if( isalpha( sToken[xj][0] ) == 0 )
        {
            _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
        }

        _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
        memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );

//        sObject.mObj.mDataSet = aObject->mObj.mDataSet;

        sDataSet = (dbmDataSet*)sObject.mObj.mDataSet;
        for ( xj = xj + 1; xj < xi; xj++ )
        {
            if ( TOKEN_EQ_IC( sToken[xj], "values" ) )
            {
                break;
            }
            else
            {
                /**************************************************************
                 * 같은 컬럼이 있는지 확인한다.
                 **************************************************************/
                for ( int i = 0; i < sDataSet->mCount; i++ )
                {
                    if ( TOKEN_EQ( sDataSet->mCols[i].mColumnName, sToken[xj] ) )
                    {
                        _THROW( ERR_DBM_DUP_COLUMN );
                    }
                }
                /**************************************************************
                 * 객체 이름은 알파벳으로 시작해야한다.
                 **************************************************************/
                _IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
                strncpy( sDataSet->mCols[k].mColumnName, sToken[xj], strlen_s( sToken[xj] ) );
                sDataSet->mCount++;
                k++;
            }
        }
        xj++;
#ifdef _DEBUG2
        _PRT( "TOKEN : [%d], [%d], [%s]\n", xi, xj, sToken[xj] );
        _PRT( "TARGET CLAUSE : [%d]\n", sDataSet->mCount );
#endif
        if ( sDataSet->mCount == 0 )
        {
            for ( k = 0; xj < xi; xj++ )
            {
#ifdef _DEBUG2
        _PRT( "TOKEN : [%d], [%d], [%s]\n", xi, xj, sToken[xj] );
#endif
                if( TOKEN_EQ_IC( sToken[xj], "to_date" ) )
                {
                    _IF_THROW( xi - xj < 3, ERR_DBM_NOT_ENOUGH_ARG );
                    _IF_THROW( strlen_s(sToken[xj+1]) != strlen_s(sToken[xj+2]), ERR_DBM_INVALID_ARGUENT );
                    strncpy( sDataSet->mCols[k].mData, sToken[xj+1], strlen_s( sToken[xj+1] ) );
                    sDataSet->mCols[k].mDateFlag = 1;
                    strncpy( sDataSet->mDateForm[sDataSet->mDateFormCount], sToken[xj+2], strlen_s( sToken[xj+2] ) );
#ifdef _DEBUG2
                    _PRT( "DEBUG] TO_DATE FOUND [%s], [%s]\n", sDataSet->mCols[k].mData, sDataSet->mDateForm[sDataSet->mDateFormCount] );
#endif
                    sDataSet->mCount++;
                    sDataSet->mDateFormCount++;
                    k++;
                    xj += 2;
                }
                else
                {
                    strncpy( sDataSet->mCols[k].mData, sToken[xj], strlen_s( sToken[xj] ) );
                    sDataSet->mCount++;
                    k++;
                }
            }
        }
        else if ( sDataSet->mCount <= xi - xj )
        {
            for ( k = 0; xj < xi; xj++ )
            {
#ifdef _DEBUG2
        _PRT( "TOKEN : [%d], [%d], [%s]\n", xi, xj, sToken[xj] );
#endif
                if( TOKEN_EQ_IC( sToken[xj], "to_date" ) )
                {
                    _IF_THROW( xi - xj < 3, ERR_DBM_NOT_ENOUGH_ARG );
                    _IF_THROW( strlen_s(sToken[xj+1]) != strlen_s(sToken[xj+2]), ERR_DBM_INVALID_ARGUENT );
                    strncpy( sDataSet->mCols[k].mData, sToken[xj+1], strlen_s( sToken[xj+1] ) );
                    sDataSet->mCols[k].mDateFlag = 1;
                    strncpy( sDataSet->mDateForm[sDataSet->mDateFormCount], sToken[xj+2], strlen_s( sToken[xj+2] ) );
#ifdef _DEBUG2
                    _PRT( "DEBUG] TO_DATE FOUND [%s], [%s]\n", sDataSet->mCols[k].mData, sDataSet->mDateForm[sDataSet->mDateFormCount] );
#endif
                    sDataSet->mDateFormCount++;
                    k++;
                    xj += 2;
                }
                else
                {
                    strncpy( sDataSet->mCols[k].mData, sToken[xj], strlen_s( sToken[xj] ) );
                    k++;
                }
            }
        }
        else
        {
#ifdef _DEBUG2
            fprintf( stderr, "not enough insert value(s) (%d:%d)\n", sDataSet->mCount, xi - xj );
#endif
            _THROW( ERR_DBM_NOT_ENOUGH_VALUE );
        }
#ifdef _DEBUG2
        _PRT( "DEBUG] INSERT TOKEN COUNT [%d:%d]\n", k, sDataSet->mCount );
#endif
        //아래 조건 확인이 들어가면서 위에서 확인하는 부분은 필요없어졌다.
        _IF_THROW( k < sDataSet->mCount, ERR_DBM_NOT_ENOUGH_VALUE );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mInsertDML */

_VOID dbmParser::mListPushDML()
{
    int     k = 0;

    _TRY
    {
        xj++;
        if ( xi < 3 )
        {
            _THROW( ERR_DBM_NOT_ENOUGH_ARG );
        }

        /**************************************************************
         * 객체 이름은 알파벳으로 시작해야한다.
         **************************************************************/
        if( isalpha( sToken[xj][0] ) == 0 )
        {
            _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
        }

        _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
        memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );

        sDataSet = (dbmDataSet*)sObject.mObj.mDataSet;

        xj++;

        if ( sDataSet->mCount == 0 )
        {
            for ( k = 0; xj < xi; xj++ )
            {
                strncpy( sDataSet->mCols[k].mData, sToken[xj], strlen_s( sToken[xj] ) );
                sDataSet->mCount++;
                k++;
            }
        }
        else
        {
            _THROW( ERR_DBM_NOT_ENOUGH_VALUE );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mListPushDML() */

_VOID dbmParser::mListPopDML()
{
    int     k = 0;

    _TRY
    {
        xj++;
        if ( xi < 2 || xi >= 3 )
        {
            _THROW( ERR_DBM_NOT_ENOUGH_ARG );
        }

        /**************************************************************
         * 객체 이름은 알파벳으로 시작해야한다.
         **************************************************************/
        if( isalpha( sToken[xj][0] ) == 0 )
        {
            _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
        }

        _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
        memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );

        sDataSet = (dbmDataSet*)sObject.mObj.mDataSet;

#if 0 //POP은 데이터가 없다.
        xj++;

        if ( sDataSet->mCount == 0 )
        {
            for ( k = 0; xj < xi; xj++ )
            {
                strncpy( sDataSet->mCols[k].mData, sToken[xj], strlen_s( sToken[xj] ) );
                sDataSet->mCount++;
                k++;
            }
        }
        else
        {
            _THROW( ERR_DBM_NOT_ENOUGH_VALUE );
        }
#endif

    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mListPopDML() */



_VOID dbmParser::mEnqueueDML( )
{
    return mInsertDML( );
}


_VOID dbmParser::mAlterDDL ()
{

    int     sRet = 0;

    _TRY
    {
        if ( xi < 4 )
        {
#ifdef _DEBUG2
            fprintf( stderr, "not enough argument(s) for '%s' clause\n", sToken[0] );
#endif
            _THROW( ERR_DBM_NOT_ENOUGH_ARG );
        }

        xj++;
        if ( TOKEN_NE_IC( sToken[xj], "table" ) )
        {
            _THROW( ERR_DBM_SQL_PARSE );
        }

        xj++;
        /**************************************************************
         * 객체 이름은 알파벳으로 시작해야한다.
         **************************************************************/
        //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
        if( isalpha( sToken[xj][0] ) == 0 )
        {
            _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
        }

        _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
        memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );
#ifdef _DEBUG2
        _PRT( "DEBUG] j = [%d], xi = [%d]\n", xj, xi );
#endif
        xj ++ ;

        if ( TOKEN_EQ_IC(sToken[xj], "nologging" ))
        {
            sObject.mSQLType = DBM_ALTER_TABLE_DISKLOG;
            sObject.mObj.mTableInfo.mTable.mNologgingF = 1 ;
        }

        if ( TOKEN_EQ_IC(sToken[xj], "logging" ))
        {
            sObject.mSQLType = DBM_ALTER_TABLE_DISKLOG;
            sObject.mObj.mTableInfo.mTable.mNologgingF = 0 ;
        }

        if ( TOKEN_EQ_IC(sToken[xj], "mem" ) ||  TOKEN_EQ_IC(sToken[xj], "memory" ))
        {
            xj++;

            if ( TOKEN_EQ_IC(sToken[xj], "nologging" ))
            {
                sObject.mSQLType = DBM_ALTER_TABLE_MEMLOG;
                sObject.mObj.mTableInfo.mTable.mNoMemloggingF = 1 ;
            }

            if ( TOKEN_EQ_IC(sToken[xj], "logging" ))
            {
                sObject.mSQLType = DBM_ALTER_TABLE_MEMLOG;
                sObject.mObj.mTableInfo.mTable.mNoMemloggingF = 0 ;
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}

_VOID dbmParser::mDequeueDML( )
{
    int     sRet = 0;

    _TRY
    {
        if ( xi < 3 )
        {
#ifdef _DEBUG2
            fprintf( stderr, "not enough argument(s) for '%s' clause\n", sToken[0] );
#endif
            _THROW( ERR_DBM_NOT_ENOUGH_ARG );
        }
        xj++;
        if ( TOKEN_NE_IC( sToken[xj], "from" ) )
        {
            _THROW( ERR_DBM_SQL_PARSE );
        }
        xj++;
        /**************************************************************
         * 객체 이름은 알파벳으로 시작해야한다.
         **************************************************************/
        //_IF_THROW( isalpha( sToken[xj][0] ) == 0, ERR_DBM_NOT_ALPHA );
        if( isalpha( sToken[xj][0] ) == 0 )
        {
            _IF_THROW( memcmp_s(sToken[xj], SYS_DIC_PREFIX, strlen_s(SYS_DIC_PREFIX)) != 0, ERR_DBM_NOT_ALPHA );
        }

        _IF_THROW( strlen_s(sToken[xj]) >= DBM_NAME_LEN, ERR_DBM_OBJ_NAME_TOO_LONG );
        memcpy_s( sObject.mObj.mTableInfo.mTable.mTableName, sToken[xj], strlen_s( sToken[xj] ) );
#ifdef _DEBUG2
        _PRT( "DEBUG] j = [%d], xi = [%d]\n", xj, xi );
#endif
        for ( xj = xj + 1; xj + 1 < xi; xj += 2 )
        {
            if ( TOKEN_EQ_IC( sToken[xj], "timeout" ) )
            {
                sRet = cmnIsDigit( sToken[xj+1] );
                _IF_THROW( sRet != TRUE, ERR_DBM_NOT_DIGIT );
                sObject.mObj.mTableInfo.mTable.mTimeOut = atoi( sToken[xj+1] );
            }
            else
            {
                _THROW( ERR_DBM_SQL_PARSE );
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mDequeueDML */



