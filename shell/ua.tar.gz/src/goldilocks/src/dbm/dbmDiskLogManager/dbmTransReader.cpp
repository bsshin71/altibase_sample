#include "dbmTransReader.h"


// 2014.09.23 (OKT) 미사용 함수에서 워닝 관리 귀찮아서 막음.
//dbmTransReader::dbmTransReader ( )
//{
//    mLogBuffer          = NULL;
//    mLastLSN            = 0;
//    mLogBufferIdx       = 0;
//    mMyLogBufferIdx     = 0;
//}

dbmTransReader::~dbmTransReader ( )
{
    free_s ( mLogBuffer );
}

dbmTransReader::dbmTransReader ( long long aLogBufferSize )
{
    mLogBuffer = (char*) malloc_s ( aLogBufferSize );

    mLogBufferIdx   = 0;
    mMyLogBufferIdx = 0;
    mLogBufferSize  = aLogBufferSize;
    mLastLSN        = 0;

    assert( mLogBuffer != NULL && "Log Buffer Alloc Failed !!" );
}
