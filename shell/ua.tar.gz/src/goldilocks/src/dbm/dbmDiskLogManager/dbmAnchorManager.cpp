/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    Log Anchor와 관련된 코드를 작성.
*******************************************************************************/
#include "dbmHeader.h"
#include "dbmAnchorManager.h"


/********************************************************************
 * ID : dbmAnchorManager
 *
 * Description
 *   생성자
 *
 * Arguments
 *
 * Return
 *
  *******************************************************************/
dbmAnchorManager::dbmAnchorManager (dbmLogAnchor *aLogAnchorPtr,
                                    dbmConfig    *aConfig,
                                    char         *aUndoName)
{
    strcpy_s (mInstanceName,  aUndoName );
    mLogAnchor = aLogAnchorPtr;
    mConfig =  aConfig;
}

dbmAnchorManager :: ~dbmAnchorManager ()
{

}


/********************************************************************
 * ID : dbmAnchorManager
 *
 * Description
 *   Undo 영역 생성시 logAnchor 관련 영역을 초기화  ,
 *   초기화 방법은 Config 에 설정된 대로
 *
 * Arguments
 *
 * Return
 *
  *******************************************************************/
int dbmAnchorManager :: mInitialize  ( )
{
    int    sRC;
    char   sDummy [DBM_FILE_NAME_LENGTH];
    char   sFileName [DBM_FILE_NAME_LENGTH];
    long long sLogFileSize;


    /* 초기화 */
    memset_s ( mLogAnchor , 0x00 , sizeof (dbmLogAnchor ) ) ;



    /*****************************************************************
     * Config 에서 찾아와서 Undo 에 존재하는 Loganchor  박는다.
     ****************************************************************/
    sRC = mConfig->mLoad (DBM_COMMON_SECTION);
    sRC = mConfig->mLoad (mInstanceName);



    /****************************************************************
     * Config 에 존재하는 값을 Log Anchor 에 넣어준다. .
     *
     * 여기서 굳이 IO 타입을 읽어서 처리하긴 해야하는데...
     ***************************************************************/

    /***************************************************************
     * DISK Logging Enable 인지만 먼저 판단해서 No Disk Logging 이면
     * 다음 걸 읽을 필요가 없다.
     ***************************************************************/
    sRC = mConfig->mSearch ( mInstanceName, "DISK_LOG_ENABLE" , sDummy ) ;
//    _IF_RAISE ( sRC , DISK_LOG_ENABLE_FAIL );

    if ( atoi (sDummy) == 0 || sRC != RC_SUCCESS )
    {
        return RC_SUCCESS;
    }


    /****************************************************************
     * 1. DISK_LOG_DIR 를 읽어온다.
     ***************************************************************/
    sRC = mConfig->mSearch ( mInstanceName, "DISK_LOG_DIR", sDummy ) ;
    _IF_RAISE ( sRC , LOG_DIR_SEARCH_FAIL ) ;

    if ( sDummy[0] == '?' && sDummy[1] == '/' )
    {
        snprintf ( sFileName, DBM_FILE_NAME_LENGTH, "%s/%s", getenv( ENV_DBM_HOME ), sDummy+2 ) ;
    }
    else if ( sDummy[0] == '~' && sDummy[1] == '/' )
    {
        snprintf ( sFileName, DBM_FILE_NAME_LENGTH, "%s/%s", getenv( "HOME" ), sDummy+2 ) ;
    }
    else
    {
        sprintf (sFileName, "%s", sDummy);
    }

    /****************************************************************
     * LOG_FILE_SIZE 를 읽어온다.
     ***************************************************************/
    sRC = mConfig->mSearch ( mInstanceName, "DISK_LOG_FILE_SIZE", sDummy ) ;
    _IF_RAISE ( sRC , LOG_FILE_SIZE_SEARCH_FAIL ) ;

    sLogFileSize = atol (sDummy) ;
    _IF_RAISE ( sLogFileSize < 1024  * 1024 , INVALID_LOG_FILE_SIZE) ;


    /****************************************************************
     * 여기까지 통과했으면 Undo 에 영역에 복사한다.
     ***************************************************************/
    memset_s ( mLogAnchor, 0x00, sizeof ( dbmLogAnchor )) ;


    /****************************************************************
     * 로그 파일에 헤더가 존재한다. 이 사이즈만큼 추가시킨다.
     ***************************************************************/
    for ( int i = 0 ; i < DBM_MAX_TRANS ; i ++)
    {
        mLogAnchor->mTxAnchor[i].mLastFileSize = sizeof ( dbmLogFileHeader );
        mLogAnchor->mTxAnchor[i].mLastSyncSize = sizeof ( dbmLogFileHeader );
    }


    strncpy ( mLogAnchor->mLogDest , sFileName, DBM_FILE_NAME_LENGTH ) ;
    strncpy ( mLogAnchor->mInstanceName, mInstanceName, DBM_NAME_LEN );
    mLogAnchor->mLogFileSize  = sLogFileSize;
    mLogAnchor->mLoggerEnableF = 1;

    memset_s ( sDummy, 0x00, sizeof(sDummy) );  // 2014.11.18 -okt- 사용안하는 코드같아서 그냥둠. 사용하면 제거시도.
    sRC = mConfig->mSearch ( mInstanceName, "REPL_ENABLE" , sDummy ) ;

    if ( atoi(sDummy) == 0 || sRC != RC_SUCCESS )
    {
        mLogAnchor->mReplEnableF = 0;
    }
    else
    {
        mLogAnchor->mReplEnableF = 1;
    }


    memset_s ( sDummy, 0x00, sizeof(sDummy) );
    sRC = mConfig->mSearch ( mInstanceName, "REPL_MEMORY_ENABLE" , sDummy ) ;

    if ( atoi(sDummy) == 0 || sRC != RC_SUCCESS )
    {
        mLogAnchor->mReplMemoryEnableF = 0;
    }
    else
    {
        mLogAnchor->mReplMemoryEnableF = 1;
    }

    sRC = RC_SUCCESS;
    return sRC;

    _EXCEPTION ( DISK_LOG_ENABLE_FAIL )
    {
        DBM_ERR ( "Could not find DISK_LOG_ENABLE in dbm.cfg \n");
        sRC = RC_FAILURE;
    }
    _EXCEPTION ( LOG_DIR_SEARCH_FAIL )
    {
        DBM_ERR ( "Could not find DISK_LOG_DIR in dbm.cfg \n");
        sRC = RC_FAILURE;

    }
    _EXCEPTION ( LOG_FILE_SIZE_SEARCH_FAIL )
    {
        DBM_ERR ( "Could not find LOG_FILE_SIZE in dbm.cfg \n");
        sRC = RC_FAILURE;
    }

    _EXCEPTION ( INVALID_LOG_FILE_SIZE )
    {
        DBM_ERR ( "LOG_FILE_SIZE is not valid. \n");
        sRC = RC_FAILURE;
    }
    _EXCEPTION_END;

    return sRC;
}



