#include "dbmDiskReader.h"


char* dbmDiskReader::mGetUndoName ( )
{
    return mLogAnchor.mInstanceName;
}

dbmDiskReader::dbmDiskReader ( long long aLogBufferSize , char* aLogDestDir , char* aUndoName, int aReplOption )
        : dbmTransReader ( aLogBufferSize )
{
    strcpy_s ( mLogDestDir , aLogDestDir );
    strcpy_s ( mInstanceName , aUndoName );
    mIsAnchorLoadF = 0;
    memset_s ( mFileNames, 0x00 , DBM_MAX_TRANS * DBM_FILE_NAME_LEN ) ;

    mGetLoadAnchor (mInstanceName, aReplOption) ;

    mLogFileReader = new dbmLogFileReader ( (char*)mFileNames, mFileTranCount ) ;
}


dbmDiskReader::~dbmDiskReader ( )
{
    if ( mLogFileReader != NULL )
    {
        delete_s( mLogFileReader );
    }
}


/**********************************************************
 * Disk 에서 로그파일을 열어서 읽어들인다.
 ********************************************************/
int dbmDiskReader::mLoadLogBuffer ( long long aLSN )
{
    int sRC;

    while ( 1 )
    {
        sRC = mLogFileReader->mGetLogByLSN ( aLSN, mLogBuffer, &mLogBufferIdx, &mLSN );

        if ( sRC == ENOENT )
        {
            return sRC;
        }
        else if ( mLSN < aLSN )
        {
            continue;
        }
        else
        {
            //DBM_INFO ("mLoadLogBufer = %ld\n", mLSN);
            return RC_SUCCESS;      // 1140 ( ERR_DBM_INVALID_DISK_BLOCK_SEQUENCE ) 인데 성공리턴
        }
    }

    return RC_SUCCESS ;
}


/**********************************************************
 * 사용자가 지정한 로그 Dir 에 존재하는 모든 Tx ID 를 읽어내어
 * mTxFiles Map 에 저장할까하다가 걍 Anchor 를 보고 넣는다.
 ********************************************************/

int    dbmDiskReader::mFillFiles ()
{
    int     sRC;
    int     j = 0;



    for (int i = 0 ; i < DBM_MAX_TRANS ; i ++)
    {
        if ( mLogAnchor.mTxAnchor[i].mAlloc )
        {
            sprintf (mFileNames[j] , "%s/%s.tx.%d",
                     mLogDestDir,
                     mLogAnchor.mInstanceName,
                     i ) ;
            j++;
        }
    }

    return RC_SUCCESS ;
}


/************************************************
 * 읽어들인 Log anchor 를 보정한다. 보정하는 이유는
 * 중간에 새로운 세션이 끼어들었을때 로그앵커에
 * 해당 부분이 반영되지 않았음을 감지하기 위함이다.
 ************************************************/
int dbmDiskReader::mAdjustLogAnchor ( int aReplOption  )
{
    char    sFileName [ DBM_FILE_NAME_LENGTH  ] ;
    int     sRC;
    int     i;

    /// 로그 앵커를 전부 뒤진다.
    for ( i = 0 ; i < DBM_MAX_TRANS ; i ++ )
    {

        /*** 1 인 것은 이미 추가되어있으니 0 인것들을 고른다. */
        if ( mLogAnchor.mTxAnchor[i].mAlloc == 0 )
        {

            sprintf (sFileName, "%s/%s.tx.%d.0", mLogDestDir,  mLogAnchor.mInstanceName,  i ) ;
            sRC = access (sFileName, R_OK ) ;
            if ( sRC != RC_SUCCESS  )
            {
                DBM_DBG ("Access File [%s] sRC [%d]\n", sFileName, sRC ) ;
                continue;
            }
            else  // 성공했으면 파일을 보정한다.
            {
                mLogAnchor.mTxAnchor[i].mAlloc = 1;
            }
        }
    }


    // 만약 A-A 구조라면 0번화 1번은 버린다.

    if ( aReplOption == 1 )
    {
        mLogAnchor.mTxAnchor[0].mAlloc = 0 ;
        mLogAnchor.mTxAnchor[1].mAlloc = 0 ;
    }

    return RC_SUCCESS;
}


/**********************************************************
 * 사용자가 지정한 Log Dest Dir 에서 로그 엥커를 찾는다.
 * 로그 엥커 이름은 DBM_LOG_ANCHOR_NAME 으로 Define 되어있다.
 ********************************************************/
int  dbmDiskReader::mGetLoadAnchor (char* aUndoName, int aReplOption)
{
    dbmLogAnchor sLogAnchor[10]; // 33880 * 10 byte
    char         sFileName[DBM_FILE_NAME_LEN];
    int          sFD;
    int          sIdx = 0;
    int          sRC = -1;
    int          sIdx2 =  0;

    long long    sSyncCount  = 0 ;
    //int        sMode = -1;
    int          i;

    _TRY
    {
        /**********************************************************
         * 만약에 mIsAnchorLoadF 가 1 이라면 이미 Load 된거니 더 하지마라.
         ********************************************************/
        if (mIsAnchorLoadF )
        {
            _RETURN;
        }

        //sMode = umask(0x00);        // 777 모드로 오픈하기 위해 umask 필요.

        /********************************************************
         * Anchor 가 없다면 파일을 통해서 읽어온다.
         *******************************************************/
        for ( i = 0 ; i < 10 ; i ++ )
        {
            sprintf ( sFileName, "%s/%s.%s.%d", mLogDestDir, mInstanceName, DBM_LOG_ANCHOR_NAME, i ) ;
            sFD = open ( sFileName, O_RDONLY );

            if ( sFD < 2 )
            {
                if ( errno == ENOENT )
                {
                   continue;
                }

                //_IF_RAISE ( 1, LOG_ANCHOR_READ_FAIL );
                {
                    DBM_WARN( "Can not find log anchor [%s] : errno [%d]", sFileName, errno );
                    _THROW( -1 );
                }
            }

            /*****************************************************
             * Anchor 를 읽어본다.
             ****************************************************/
            sRC = read_s ( sFD, &sLogAnchor[sIdx], sizeof(dbmLogAnchor) );
            close_s( sFD );

            if ( sRC == sizeof(dbmLogAnchor) )
            {
                sIdx ++;
            }
            else
            {
                //_IF_RAISE ( 1, LOG_ANCHOR_READ_FAIL2 );
                {
                    DBM_WARN( "reading from log anchor [%s] : errno [%d]", sFileName, errno );
                    _THROW( -1 );
                }
            }
        }

        /*************************************************************
         * 만약 Anchor 를 찾지 못했으면 실패
         ***********************************************************/
        if ( sIdx  == 0 ) //, FATAL_ERROR ) ;
        {
            DBM_ERR ( "Unable to open log anchor. Check undo name and log directory.") ;
            _PRT ( "Unable to open log anchor. Check undo name and log directory. \n") ;
            _EXIT ( -1 ) ;
        }

        /***********************************************************
         * Anchor 를 읽었으면 해당 Anchor 중에 가장 마지막에 Sync 된
         * 놈을 찾는다.
         * ********************************************************/

        for ( i = 0 ; i < sIdx ; i ++)
        {
            if ( sLogAnchor[i].mSyncCount > sSyncCount )
            {
                sSyncCount = sLogAnchor[i].mSyncCount;
                sIdx2 =  i;
            }
        }

         /***********************************************************
         * 찾았다.
         * ********************************************************/
        memcpy_s ( &mLogAnchor, &sLogAnchor[sIdx2] , sizeof (dbmLogAnchor) );

        mAdjustLogAnchor (aReplOption ) ;
        mFillFiles () ;
        mIsAnchorLoadF = 1;
        mFileTranCount = 0 ;

        for ( i =0  ; i < DBM_MAX_TRANS ; i ++ )
        {
            if ( mLogAnchor.mTxAnchor[i].mAlloc )
            {
                mFileTranCount ++ ;
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    {
//        if ( sMode != -1 )
//        {
//            (void) umask ( sMode );     // 기존 umask 설정으로 원복.
//        }
    }
    _END
}


int dbmDiskReader::mReadLog ( dbmTransLog ** aLog, char ** aImage, long long aLSN )
{
    int sRC;

     
    if  ( mMyLogBufferIdx >= mLogBufferIdx || mMyLogBufferIdx == 0  )
    {
        /**********************************************
         * 다 꺼내줬다 -1 을 리턴한다.
         *********************************************/
        sRC = mLoadLogBuffer (aLSN) ;
        mMyLogBufferIdx = 0 ;

        if ( sRC  )
        {
            return sRC;
        }
    }

     /*************************************************
     * 굳이 또 memory copy 를 할 필요는 없어보인다. 주소만 넘긴다.
     * **********************************************/
    *aLog = (dbmTransLog*)(mLogBuffer + mMyLogBufferIdx);
    *aImage = mLogBuffer + mMyLogBufferIdx + sizeof (dbmTransLog) , (*aLog)->mImageSize  ;

    (*aLog)->mLSN = mLSN ;
    //DBM_INFO ("aLSN=%ld mReadLog mLSN = %ld\n", aLSN, mLSN);
    /*************************************************
     * 읽은 로그는 전진
     * **********************************************/
    mMyLogBufferIdx += sizeof (dbmTransLog ) + (*aLog)->mImageSize ;
    return RC_SUCCESS;
}


/************************************************************
 * 파일을 열어서 해당 데이터를 Queuing 을 수행한다.
 **********************************************************/
int dbmLogFileReader::mFillQueue (int aIdx, long long aStartLSN )
{
    dbmLogBlockHeader* sLogBlockHeader;
    queuedLogBlock sQueueBlock [ DBM_FILE_READ_BLOCK_COUNT];
    char    sFileName[DBM_FILE_NAME_LEN];
    union
    {
        dbmLogFileHeader sLogFileHeader;
        char sDummy[DBM_LOG_BLOCK_SIZE];
    };
    int     sMode = -1;
    int     sRC = 0;

    _TRY
    {
retry :
        mMyFileSeq [aIdx] ++;

        sprintf (sFileName, "%s.%d" , mFileNames + (DBM_FILE_NAME_LEN * aIdx ), mMyFileSeq[aIdx]) ;

        if ( mFDs [aIdx] > 2 )
        {
            close (mFDs[aIdx]);
        }


        errno = 0 ;
        mFDs[aIdx] = open ( sFileName, O_RDONLY );
        if ( mFDs[aIdx] < 2 && errno != ENOENT ) //, FILE_OPEN_ERROR ) ;
        {
            DBM_ERR ("File Open Error [%s] : errno [%d] \n") ;
            _THROW( RC_FAILURE );
        }

        if ( errno == ENOENT )
        {
            mIsDone [aIdx] = 1;
            //return ENOENT;
            _THROW( ENOENT );
        }

        /*
         * 2014.12.14. -okt- Disk Log 공간 과다.
         * O_DIRECT 에서는 512 Byte 기록이므로, 무조건 해당크기를 읽도록 수정
         */
#if 0
        sRC = read ( mFDs[aIdx], &sLogFileHeader, sizeof(dbmLogFileHeader) );
        if ( sLogFileHeader.mEndLSN <= aStartLSN && sLogFileHeader.mEndLSN != 0 )
        {
            goto retry ;
        }
#else
        sRC = read ( mFDs[aIdx] , &sLogFileHeader , DBM_LOG_BLOCK_SIZE ) ;
        if ( sRC != DBM_LOG_BLOCK_SIZE )
        {
            goto retry ;
        }
        else
        {
            if ( sLogFileHeader.mEndLSN <= aStartLSN && sLogFileHeader.mEndLSN != 0 )
            {
                goto retry ;
            }
        }
#endif

        /*** 해당 파일을 열었다면 끝까지 읽어서 Queue 에 저장한다. **/
        while ( true )
        {
            sRC = read ( mFDs[aIdx] , &sQueueBlock , DBM_LOG_BLOCK_SIZE * DBM_FILE_READ_BLOCK_COUNT  ) ;

            if ( errno != 0 )
            {
                return RC_SUCCESS;
            }


            if ( sRC == DBM_FILE_READ_BLOCK_COUNT * DBM_LOG_BLOCK_SIZE  )
            {
                for (  int  i = 0 ; i < DBM_FILE_READ_BLOCK_COUNT  ; i ++ )
                {

                    sLogBlockHeader = (dbmLogBlockHeader*)sQueueBlock[i].data;
                    if ( sLogBlockHeader->mLSN != -1 )
                    {
                        mBlockBuffer [ aIdx ].push_back ( sQueueBlock[i]) ;
                    }
                    else
                    {
                        return RC_SUCCESS;

                    }

                }
            }
            else
            {

                for ( int i = 0 ; i < sRC / DBM_LOG_BLOCK_SIZE ; i ++ )
                {
                    sLogBlockHeader = (dbmLogBlockHeader*)sQueueBlock[i].data;
                    if ( sLogBlockHeader->mLSN != -1 )
                    {
                        mBlockBuffer [ aIdx ].push_back ( sQueueBlock[i]) ;
                    }
                    else
                    {
                        return RC_SUCCESS ;

                    }


                }
                return RC_SUCCESS;

            }

        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


void dbmLogFileReader::mCheckIsDone ( int *aIsDone )
{
    int sFlag = 1 ;

    for ( int i = 0 ; i < mFileTransCount ; i ++)
    {
        if ( mIsDone[i] == 0 )
        {
            sFlag = 0 ;
        }
    }
    *aIsDone = sFlag;
}


// liblz4.so.1 에 대한 의존성 분리를 위해, dlopen으로 로딩한다.
// [코딩규칙 권고] dlopen으로 코딩을 할때는 함수이름이나 so 핸들 이름에 __를 붙인다.
int ( *__LZ4_decompress_safe ) ( const char* source, char* dest, int inputSize, int maxOutputSize ) = NULL;

int dbmLogFileReader::mGetLogByLSN ( long long aStartLSN, char* aBuf , int *aBufSize, long long* aLSN)
{
    int sRC;

    int sCurrentIdx;
    dbmLogBlockHeader *sHeader;
    int sIsDoneF = 0;

    int sIsCompressF = 0 ;

    int sTempLength = 0 ;
    int sLength = 0 ;

    /************************************************************
     * 전체 파일에서 첫번째 block 을 모두 읽어 들인다.
     ***********************************************************/

    for ( int i = 0 ; i < mFileTransCount ; i ++ )
    {
        if ( mBlockBuffer[i].empty() && mIsDone [i] == 0 )
        {
            sRC = this->mFillQueue ( i, aStartLSN ) ;

            mCheckIsDone ( & sIsDoneF ) ;

            if ( sRC == ENOENT && sIsDoneF )
            {
                return sRC;
            }
        }

        mFirstBlock[i] = mBlockBuffer[i].front () ;
    }

    sCurrentIdx = dbmFindMinLSN ( ) ;

    sHeader = (dbmLogBlockHeader*) mFirstBlock[sCurrentIdx].data ;

    sTempLength = sHeader->mTranTotalSize ;
    sLength = sHeader->mTranTotalSize;

    *aBufSize = sTempLength;

    *aLSN = sHeader->mLSN ;


    /************************************
     * 헤더를 까보면 몇개 필요할지 알수 있따.
     * **********************************/
    for ( int i = 0 ; i < sHeader-> mTotalBlockNo ; i ++ )
    {
        //sHeader = (dbmLogBlockHeader*) mFirstBlock[sCurrentIdx].data ;

        sIsCompressF = sHeader -> mIsCompressF ;
        //*aLSN = sHeader->mLSN ;

        if ( sHeader->mCurrentBlockNo != i + 1 )
        {
            return ERR_DBM_INVALID_DISK_BLOCK_SEQUENCE;
        }


        if ( sIsCompressF == 0 ) // 비압축 로그
        {
            if ( sTempLength < (int)(DBM_LOG_BLOCK_SIZE - sizeof (dbmLogBlockHeader ))  )
            {
                memcpy_s ( aBuf + ( i * (DBM_LOG_BLOCK_SIZE - sizeof (dbmLogBlockHeader))) ,
                        mFirstBlock[sCurrentIdx].data + sizeof (dbmLogBlockHeader) ,
                        sTempLength );

                sTempLength = 0 ;
            }
            else
            {
                memcpy_s ( aBuf + ( i * (DBM_LOG_BLOCK_SIZE - sizeof (dbmLogBlockHeader))) ,
                        mFirstBlock[sCurrentIdx].data + sizeof (dbmLogBlockHeader) ,
                        (DBM_LOG_BLOCK_SIZE - sizeof (dbmLogBlockHeader)));

                sTempLength -= (DBM_LOG_BLOCK_SIZE - sizeof ( dbmLogBlockHeader ) ) ;
            }
        }
        else // 압축로그
        {
            if ( mCompressTempBuffer == NULL )
            {
                mCompressTempBuffer = (char*)malloc_s ( 10 * 1024 * 1024 ) ;
                assert (mCompressTempBuffer != NULL ) ;
            }

            if ( sTempLength < (int)(DBM_LOG_BLOCK_SIZE - sizeof (dbmLogBlockHeader ))  )
            {
                memcpy_s ( mCompressTempBuffer + ( i * (DBM_LOG_BLOCK_SIZE - sizeof (dbmLogBlockHeader))) ,
                        mFirstBlock[sCurrentIdx].data + sizeof (dbmLogBlockHeader) ,
                        sTempLength );

                sTempLength = 0 ;
            }
            else
            {
                memcpy_s ( mCompressTempBuffer + ( i * (DBM_LOG_BLOCK_SIZE - sizeof (dbmLogBlockHeader))) ,
                        mFirstBlock[sCurrentIdx].data + sizeof (dbmLogBlockHeader) ,
                        (DBM_LOG_BLOCK_SIZE - sizeof (dbmLogBlockHeader)));

                sTempLength -= (DBM_LOG_BLOCK_SIZE - sizeof ( dbmLogBlockHeader ) ) ;
            }
        }


        /****** Queue 에서 블록 하나 날리고 ******/
        mBlockBuffer[sCurrentIdx].pop_front () ;

        /****** Queue 에서 다음 블록은 가지고 온다. ****/
        mFirstBlock[sCurrentIdx] = mBlockBuffer[sCurrentIdx].front () ;
    }

    if ( sIsCompressF  )
    {
        if ( unlikely( __LZ4_decompress_safe == NULL ) )
        {
            int sRC;

            if ( unlikely( __liblz4_so == NULL ) )
            {
                sRC = cmnDlopen( "liblz4.so", &__liblz4_so );
                assert ( sRC == 0 && "Compress library dlopen Fail !" );
            }

            sRC = cmnDlsym ( __liblz4_so, "LZ4_decompress_safe", (void**)&__LZ4_decompress_safe );
            assert ( sRC == 0 && "dlsym Fail (LZ4_decompress_safe)" );
        }

        __LZ4_decompress_safe ( mCompressTempBuffer, aBuf , sLength,  1024 * 1024 * 100  ) ;
    }

    return RC_SUCCESS ;

}


/*****************************************************************
 * 여러가지 파일 중에 가장 작은 놈을 찾아낸다.
 ****************************************************************/
int dbmLogFileReader::dbmFindMinLSN ( )
{
    dbmLogBlockHeader *sHeader;
    long long sLSN = LONG_MAX;
    int     sIdx = -1;
    int     i;

    for ( i = 0; i < mFileTransCount; i++ )
    {
        if ( mIsDone[i] == 1 )
        {
            continue;
        }
        sHeader = (dbmLogBlockHeader*) &mFirstBlock[i];

        if ( sLSN > sHeader->mLSN )
        {
            sLSN = sHeader->mLSN;
            sIdx = i;
        }
    }

    return sIdx;
}
