#include "dbmTransLogger.h"

/*******************************************************************************
 * Constructor
 ******************************************************************************/

// 2014.09.23 (OKT) 미사용 함수에서 워닝 관리 귀찮아서 막음.
//dbmTransLogger::dbmTransLogger ( )
//{
//    mLogBuffer = NULL ;
//    mLogBufferIdx = 0 ;
//}


/*******************************************************************************
 * 로그 버퍼가 할당된 경우 이를 해제한다.
 ******************************************************************************/
dbmTransLogger::~dbmTransLogger ( )
{
    free_s ( mLogBuffer ) ;
}


/*******************************************************************************
 *  로그 버퍼를 할당 받는다.
 ******************************************************************************/
dbmTransLogger::dbmTransLogger ( int aTxID , long long aLogBufferSize )
{
    mLogBuffer = (char*)malloc_s ( aLogBufferSize ) ;
    assert ( mLogBuffer != NULL && "LOG_BUFFER_MALLOC_FAIL" );

    mLogBufferIdx       = 0 ;
    mTxID               = aTxID;
    mLogBufferSize      = aLogBufferSize;

}


/*******************************************************************************
 * dbmTransLog 주어진 값을 LogBuffer 에 복사를 하겠다.
 ******************************************************************************/
_VOID dbmTransLogger::mWriteLog ( dbmTransLog* aLog )
{
    _TRY
    {
        if ( mLogBufferIdx + (int)sizeof(dbmTransLog) + aLog->mImageSize > mLogBufferSize )
        {
            _THROW( ERR_DBM_LOG_BUFFER_FULL );
        }

        /*************************************************************************
         * 로그 버퍼에 차곡 차곡 복사
         ************************************************************************/
        memcpy_s ( mLogBuffer + mLogBufferIdx, aLog, sizeof(dbmTransLog) );
        mLogBufferIdx += sizeof (dbmTransLog ) ;

        if ( aLog -> mImageSize > 0 )
        {
            memcpy_s ( mLogBuffer + mLogBufferIdx, aLog->mImagePtr, aLog->mImageSize );
            mLogBufferIdx += aLog->mImageSize;
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}
