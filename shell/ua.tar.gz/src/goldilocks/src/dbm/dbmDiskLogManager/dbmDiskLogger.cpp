
#include "dbmDiskLogger.h"
#include "dbmHeader.h"


// 2014.11.18. -okt- liblz4.so.1 에 대한 의존성 분리를 위해, dlopen으로 로딩한다.
void* __liblz4_so = NULL;
int ( *__LZ4_compress ) ( const char* source, char* dest, int inputSize ) = NULL;


#ifdef __linux__

/*
 *  2014.12.14. -okt- 2014.09.23 - 디폴트 생성자를 안만들면 문제가 있을까? 컴파일 워닝제거를 위해 막아봄.
 */
//dbmDiskLogger::dbmDiskLogger ()  : dbmTransLogger ()
//{
//    assert ( 1 && " MUST NOT BE CALLED !");
//}


dbmDiskLogger::dbmDiskLogger ( int aTxID, dbmLogAnchor* aLogAnchor, long long aLogBufferSize, dbmDiskSyncOption aSyncOpt)
    : dbmTransLogger (aTxID, aLogBufferSize)
{
   mAlignedBuf = (char*) memalign_s ( DBM_LOG_BLOCK_SIZE, DBM_LOG_BLOCK_SIZE) ;
   assert ( mAlignedBuf != NULL && "Malloc Fail") ;

   mLogAnchor = aLogAnchor;
   mMyFileSize = 0;
   mSyncBytes = 0 ;

   mSyncOpt = aSyncOpt;
   if ( BITAND( getSyncOpt(), O_DIRECT ) )
   {
       mDirectF = 1;
   }
   else
   {
       mDirectF = 0;
   }

   mFD          = -1;
   mHeaderFD    = -1;
   mReplFD      = -1;
}

#if 0 // 죽은코드
/*** Log 가 다 쓰여졌으니 Commit Log 를 남긴다. */
int dbmDiskLogger::mCommitSync ( )
{
    int     sRC;
    dbmLogBlockHeader       sBlockHeader;
    dbmTransLog             sTransLog;
    long long               sLSN ;


    sTransLog.mLogType = DBM_COMMIT_LOG;
    sTransLog.mObjectID = -1;
    sTransLog.mSlot = -1;
    sTransLog.mSCN = -1;
    bzero_s ( sTransLog.mObjectName, DBM_NAME_LEN ) ;
    sTransLog.mImageSize = 0 ;


    sLSN = mvpAtomicInc64 ( &mLogAnchor->mLoggerLSN );
    sBlockHeader.mLSN = sLSN ;
    sBlockHeader.mTotalBlockNo = 1;
    sBlockHeader.mCurrentBlockNo = 1;
    sBlockHeader.mTranTotalSize = 0 ;
    sBlockHeader.mIsCompressF = 0 ;
    // 2014.12.14. -okt- 용도는 무엇일까? - mWriteTime
    gettimeofday ( &sBlockHeader.mWriteTime, NULL ) ;


    bzero_s ( mAlignedBuf, DBM_LOG_BLOCK_SIZE );
    memcpy_s ( mAlignedBuf ,  &sBlockHeader,  sizeof ( dbmLogBlockHeader )) ;
    memcpy_s ( mAlignedBuf + sizeof (dbmLogBlockHeader) , &sTransLog, sizeof ( dbmTransLog ) );

    sRC = write_s ( mFD, mAlignedBuf, DBM_LOG_BLOCK_SIZE ) ;
    if ( sRC != DBM_LOG_BLOCK_SIZE )
    {
        DBM_ERR ( "Try to write [%d] but failed errno [%d]\n", mFD, errno ) ;
        sRC = RC_FAILURE;
    }
    else
    {
       return fsync ( mFD ) ;
    }
    return sRC;


    return RC_SUCCESS ;
}
#endif


dbmDiskLogger::~dbmDiskLogger ( )
{
    close_s( mFD );
    close_s( mHeaderFD );

    free_s( mAlignedBuf );
}


int dbmDiskLogger::getSyncOpt ( )
{
    int sOption;

    switch ( mSyncOpt )
    {
        case NO_SYNC:
            sOption = O_APPEND | O_WRONLY | O_CREAT;
            break;

        case FSYNC:
            sOption = O_APPEND | O_WRONLY | O_CREAT;
            break;

        case SYNC:
            sOption = O_WRONLY | O_APPEND | O_DSYNC | O_CREAT;
            break;

        case DIRECT:
            sOption = O_WRONLY | O_APPEND | O_DIRECT | O_CREAT;
            break;

        case DIRECT_SYNC:
            sOption = O_WRONLY | O_APPEND | O_DIRECT | O_CREAT | O_DSYNC;
            break;

        default:
            sOption = O_APPEND | O_WRONLY | O_CREAT;
    }
    return sOption;
}


/***************************************************
 * 파일이 스위칭 될때 로그 헤더를 Write 한다.
 **************************************************/
_VOID dbmDiskLogger::mWriteLogFileHeader ( )
{
    dbmLogFileHeader sLogFileHeader;
    int     sRC = -1;

    _TRY
    {
        sLogFileHeader.mEndLSN = 0;

        /*
         * 2014.12.14. -okt- 512Byte Align은 O_DIRECT에서만 필요하다.
         * 이를 사이즈나, 레코드 길이가 적은 테이블에서의 성능을 위해 다르게 가져갈 수는 있지만.
         * 코드가 지저분해진다.
         */
//        if ( mDirectF )
        {
            //bzero_s ( mAlignedBuf, DBM_LOG_BLOCK_SIZE );
            memcpy_s( mAlignedBuf, &sLogFileHeader, sizeof(dbmLogFileHeader) );
            mAlignedBuf[ sizeof(dbmLogFileHeader) ] = 0x00;
            sRC = write_s ( mFD, mAlignedBuf, DBM_LOG_BLOCK_SIZE );
            if ( sRC == DBM_LOG_BLOCK_SIZE )
            {
                mMyFileSize += DBM_LOG_BLOCK_SIZE;
                _RETURN;
            }
        }
//        else
//        {
//            sRC = write_s ( mFD, &sLogFileHeader, sizeof(dbmLogFileHeader) );
//            if ( sRC == sizeof(dbmLogFileHeader) )
//            {
//                mMyFileSize += sizeof(dbmLogFileHeader);
//                _RETURN;
//            }
//        }

        // TODO: 2014.12.14. -okt- 디스크 풀 등의, 오류처리 추가요
        //_DASSERT( 0 );
    }
    _CATCH
    _FINALLY
    _END
}


/***************************************************
 * 파일이 Switching 되는 시점에 로그 파일 헤더를 업데이트
 **************************************************/
_VOID dbmDiskLogger::mUpdateLogFileHeader ( long long aMarkLSN )
{
    dbmLogFileHeader sLogFileHeader;
    //int     sOpenOpt = getSyncOpt ();
    int     sRC = -1;

    _TRY
    {
        sLogFileHeader.mEndLSN = aMarkLSN ;

        // 2014.12.14. -okt- mHeaderFD 는 O_DIRECT로 열지 않았기때문에 EINVAL 문제없을거다.
        sRC = write_s ( mHeaderFD, &sLogFileHeader, sizeof(dbmLogFileHeader) );
        // 2014.12.14. -okt- mWriteEOF 에서는 오류리턴, 여기는 로그도 안남기고 그냥 죽고. 제품에 assert는 빼야한 (확인요)
        assert( sRC == sizeof(dbmLogFileHeader) );
    }
    _CATCH
    _FINALLY
    _END
}



/*******************************************************************************
 * 현재 Directory 에 존재하는지 판단해서 Switch Log를 하겠다.
 ******************************************************************************/
_VOID dbmDiskLogger::mSwitchFile ( )
{
    struct  stat sFileStat;
    char    sFileName[DBM_FILE_NAME_LEN];
    char    sReplFileName[DBM_FILE_NAME_LEN];
    int     sOpenOpt = getSyncOpt ();
    int     sMode = -1;
    int     sRC;

    _TRY
    {
        /*** 신규로 파일이 필요한 상황이다. **/
        if ( unlikely( mFD == -1 ) )
        {
            sMode = umask(0x00);        // 777 모드로 오픈하기 위해 umask 필요.

            /*********************************************************
             * 파일 이름은 이게 될껀데
             ********************************************************/
            sprintf (sFileName, "%s/%s.tx.%d.%d",
                     mLogAnchor->mLogDest ,
                     mLogAnchor->mInstanceName,
                     mTxID,
                     mLogAnchor->mTxAnchor[mTxID].mCurFileNo);

            /********************************************************
             * 파일을 걍 연다. 이 시점에서 파일 크기가 좀 넘어가는건
             * 걍 넘어간다.
             *******************************************************/
            sRC = stat ( sFileName, &sFileStat ) ;
            if ( sRC && errno != ENOENT ) // , FILE_STAT_ERROR ) ;
            {
                DBM_ERR ( "Filestat [%s]  Error errno [%d]", sFileName, errno ) ;
                _THROW( RC_FAILURE );
            }

            if ( errno == ENOENT )
            {
                mMyFileSize = 0 ;
            }
            else
            {
                mMyFileSize = sFileStat.st_size;
            }

            mFD = open ( sFileName, sOpenOpt, _cmn_file_mode );
            if ( mFD == -1 ) //, FILE_CREATE_FAIL ) ;
            {
                DBM_ERR ( "Try to create [%d] but failed errno [%d]", sFileName, errno ) ;
                _THROW( RC_FAILURE );
            }

            mHeaderFD = open ( sFileName, O_WRONLY, _cmn_file_mode );
            if ( mHeaderFD == -1 ) // , FILE_CREATE_FAIL ) ;
            {
                DBM_ERR ( "Filestat [%s]  Error errno [%d]", sFileName, errno ) ;
                _THROW( RC_FAILURE );
            }

            if ( mMyFileSize == 0 )
            {
                _CALL( mWriteLogFileHeader ( ) );
            }

            _CALL( mFlushAnchor () );

            if( mLogAnchor->mReplEnableF == 1 )
            {
                /* Replication File open 처리 */
                //sprintf ( sReplFileName, "%s/%s.repl.seq", mLogAnchor->mLogDest, mLogAnchor->mInstanceName );
                /* 2014.12.11 -shw- transaction 성능 관련 shared memory 박음 */
                if ( getenv( ENV_DBM_SHM_PREFIX ) == NULL )
                {
                    sprintf ( sReplFileName, "/dev/shm/%s/%s.repl.seq",
                        mLogAnchor->mInstanceName, mLogAnchor->mInstanceName );
                }
                else
                {
                    sprintf ( sReplFileName, "/dev/shm/%s/%s/%s.repl.seq",
                        getenv( ENV_DBM_SHM_PREFIX ), mLogAnchor->mInstanceName, mLogAnchor->mInstanceName );
                }

                mReplFD = open ( sReplFileName, O_RDWR | O_CREAT , _cmn_file_mode ) ;
                if ( mReplFD == -1 ) //, FILE_CREATE_FAIL ) ;
                {
                    DBM_ERR ( "Try to create [%d] but failed errno [%d]", sFileName, errno ) ;
                    _THROW( RC_FAILURE );
                }
            }

            _RETURN;
        }


        /*** 현재 크기를 넘어섰다. ***/
        if ( mMyFileSize > mLogAnchor->mLogFileSize )
        {
            /*** 현재 파일을 닫고 새로운 파일을 준비한다. **/
            _CALL( mUpdateLogFileHeader ( mLastLSN ) );
            _CALL( mWriteEOF ( ) );
            close_s ( mFD ) ;
            close_s ( mHeaderFD ) ;

            mLogAnchor->mTxAnchor[mTxID].mCurFileNo ++;
            sprintf (sFileName, "%s/%s.tx.%d.%d",
                     mLogAnchor->mLogDest ,
                     mLogAnchor->mInstanceName,
                     mTxID,
                     mLogAnchor->mTxAnchor[mTxID].mCurFileNo);

            mFD = open ( sFileName, sOpenOpt |O_EXCL, _cmn_file_mode ) ;
            if ( unlikely( mFD == -1 ) ) //, FILE_CREATE_FAIL ) ;
            {
                DBM_ERR ( "Try to create [%d] but failed errno [%d]", sFileName, errno ) ;
                _THROW( RC_FAILURE );
            }

            mHeaderFD = open ( sFileName, O_WRONLY, _cmn_file_mode ) ;
            if ( unlikely( mHeaderFD == -1 ) ) //, FILE_CREATE_FAIL ) ;
            {
                DBM_ERR ( "Try to create [%d] but failed errno [%d]", sFileName, errno ) ;
                _THROW( RC_FAILURE );
            }

            mMyFileSize =  0;
            _CALL( mWriteLogFileHeader () );
            mLogAnchor->mTxAnchor[mTxID].mLastFileSize = mMyFileSize;
            _CALL( mFlushAnchor () );
            //_RETURN;
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    {
        if ( sMode != -1 )
        {
            (void) umask ( sMode );     // 기존 umask 설정으로 원복.
        }
    }
    _END
} /* mSwitchFile */


/******************************************************************************
 * Log File 에 대해서 Switching 하기 때문에 해당 파일에 EOF 를 기록한다.
 * 해당 EOF 는 dbmBlock 을 그대로 넣는데, LSN 을 -1로 세팅된 부분을 EOF 로
 * 하기로 한다.
 ******************************************************************************/
_VOID dbmDiskLogger::mWriteEOF ( )
{
    dbmLogBlockHeader   sBlockHeader;
    int     sRC = -1;

    _TRY
    {
        sBlockHeader.mLSN = -1;
        sBlockHeader.mTotalBlockNo = 1;
        sBlockHeader.mTranTotalSize = 0;
        sBlockHeader.mIsCompressF = 0;
        gettimeofday ( &sBlockHeader.mWriteTime, NULL );

        sBlockHeader.mCurrentBlockNo = 1;

//        if ( mDirectF )
        {
            //TOOD: 2014.11.18. -okt- 없앨수는 있을것 같다. 그러나, 이건 복구와, 이중화와, dump_xx 와 모두 검증 필요.
#ifndef _DEBUG
            bzero_s ( mAlignedBuf, DBM_LOG_BLOCK_SIZE );
            memcpy_s( mAlignedBuf, &sBlockHeader, sizeof(dbmLogBlockHeader) );
#else
            //bzero_s ( mAlignedBuf, DBM_LOG_BLOCK_SIZE );
            memcpy_s( mAlignedBuf, &sBlockHeader, sizeof(dbmLogBlockHeader) );
            mAlignedBuf[ sizeof(dbmLogBlockHeader) ] = 0x00;
#endif

            sRC = write_s ( mFD, mAlignedBuf, DBM_LOG_BLOCK_SIZE );
            if ( unlikely( sRC != DBM_LOG_BLOCK_SIZE ) )
            {
                DBM_ERR ( "Try to write [%d] but failed errno [%d]\n", mFD, errno );
                _THROW( RC_FAILURE );
            }
        }
//        else
//        {
//            sRC = write_s ( mFD, &sBlockHeader, sizeof(dbmLogBlockHeader) );
//            if ( unlikely( sRC != sizeof(dbmLogBlockHeader) ) )
//            {
//                DBM_ERR ( "Try to write [%d] but failed errno [%d]\n", mFD, errno );
//                _THROW( RC_FAILURE );
//            }
//        }
    }
    _CATCH
    _FINALLY
    _END
}

/*******************************************************************************
 * Shared Memory 에 존재하는 Log Anchor 를 Disk 에 Flush 한다.
 * 이 함수는 Log 의 Switch 시점에 이루어진다.
 ******************************************************************************/
_VOID dbmDiskLogger::mFlushAnchor ( )
{
    dbmLogAnchor  sLogAnchor;
    char          sFileName[DBM_FILE_NAME_LENGTH];
    int           sFD = -1;

    int           sLastFileSequence  = 0;
    int           sMode = -1;
    int           sRC = -1;

    _TRY
    {
        sMode = umask(0x00);        // 777 모드로 오픈하기 위해 umask 필요.

retry :
        sLastFileSequence = mLogAnchor->mLastFileSequence;

        /* 만들어낼 파일의 이름을 생성함 */
        sprintf ( sFileName, "%s/%s.%s.%d", mLogAnchor->mLogDest, mLogAnchor->mInstanceName, DBM_LOG_ANCHOR_NAME, sLastFileSequence );

        /* 파일을 만들어낸다. */
        sFD = open ( sFileName, O_WRONLY | O_CREAT | O_SYNC, _cmn_file_mode );
        _IF_THROW( sFD < 2, -1 /* FILE_WRITE_ERROR */);

        gettimeofday ( &mLogAnchor->mLastSyncTime, NULL );

        /* 현재의 Log Anchor 를 Disk 로 내린다. */
        sRC = write_s ( sFD, mLogAnchor, sizeof(dbmLogAnchor) );
        _IF_THROW( sRC != sizeof(dbmLogAnchor), -1 /* FILE_WRITE_ERROR */);

        /* 2014.09.25 -shw- 현재 Anchor file 3개가 필요 없다 하나만 필요하기 때문에
         * 하나만 두도록 하고 나중에 필요하면 열도록 한다 */
#if 0
        if ( sLastFileSequence  ==  mLogAnchor->mLastFileSequence )
        {
            mvpAtomicInc32 ( &mLogAnchor->mLastFileSequence ) ;

            if ( mLogAnchor->mLastFileSequence % 3  == 0 )
            {
                mLogAnchor->mLastFileSequence = 0 ;
            }

            _RETURN;
        }
        else
        {
            goto retry ;
        }
#endif

    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    {
        close_s( sFD );
        if ( sMode != -1 )
        {
            (void) umask ( sMode );     // 기존 umask 설정으로 원복.
        }
    }
    _END
} /* mFlushAnchor */


_VOID dbmDiskLogger::mSync ( )
{
    _TRY
    {
        if ( mSyncOpt == FSYNC )
        {
            //_CALL( fsync ( mFD ) );
            _CALL( fdatasync ( mFD ) );

            if( mLogAnchor->mReplEnableF == 1 )
            {
                _CALL( fdatasync ( mReplFD ) ); // 2014.11.21. -okt- 추가.
            }
        }

        /**** 마지막으로 Sync 된 위치를 표기한다 */
        mLogAnchor->mTxAnchor[mTxID].mLastSyncSize += mSyncBytes;
        mSyncBytes = 0;
    }
    _CATCH
    {
        // TODO: 2014.12.14. -okt- fsync 가 실패했다. "디스크FULL' 등의 오류 체크 보강요. ( 2014.09.22 )
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


_VOID dbmDiskLogger::mAnchor ( int aFlagF )
{
    /**** 마지막으로 Sync 된 위치를 표기한다 */
    mLogAnchor->mTxAnchor[mTxID].mStat = aFlagF;
    return 0;
}


/*******************************************************************************
 * Log Buffer 에 쌓인 값을 차례대로 Write하겠다
 ******************************************************************************/
// [성능] DISK INSERT Top-4 함수. 2014.11.17. -okt-
_VOID dbmDiskLogger::mFlush ( )
{
    dbmReplSeqInfo      sReplSeqInfo;
    dbmLogBlockHeader   sBlockHeader;
    int     sTotalBlockCount = 0;
    int     sBlockSize =  DBM_LOG_BLOCK_SIZE - sizeof(dbmLogBlockHeader) ; // 512 - 40 byte
    long long sMagicNo = (long long)(1365678123409192L);
    long long sLSN = -1;
    int     sRC = -1;
    int     i;

    _TRY
    {
        /***********************************************************************
         * 쓸게 없으면 Write 할 필요가 없다.
         **********************************************************************/
        if ( mLogBufferIdx == 0 )
        {
            _RETURN;
        }

        mLogAnchor->mTxAnchor[mTxID].mAlloc = 1;
        _CALL( mSwitchFile () );
        //_IF_THROW( sRC , RC_FAILURE ); //FILE_SWITCH_ERR) ;


        /***********************************************************************
         * 현재 로그 버퍼를 통해서 몇개가 쓰여져야하는지 판단한다.
         **********************************************************************/
        if ( mLogBufferIdx % sBlockSize != 0 )
        {
            sTotalBlockCount = ( mLogBufferIdx / sBlockSize )  + 1;
        }
        else
        {
            sTotalBlockCount = mLogBufferIdx / sBlockSize ;
        }

        /***********************************************************************
         * Log anchor 를 통해서 LSN 을 딴다.
         **********************************************************************/
        sLSN = mvpAtomicInc64 ( &mLogAnchor->mLoggerLSN );
        //DBM_INFO ("sLSN = %ld\n", sLSN);

        /***********************************************************************
         * Log Block 형태로 Disk 로 쓴다.
         **********************************************************************/
        sBlockHeader.mLSN = sLSN ;
        sBlockHeader.mTotalBlockNo = sTotalBlockCount;
        sBlockHeader.mTranTotalSize = mLogBufferIdx ;
        sBlockHeader.mIsCompressF = 0 ;
        sBlockHeader.mMagicNo = DBM_DISK_WATER_MARK;
        gettimeofday ( &sBlockHeader.mWriteTime, NULL ) ;

        /***********************************************************************
        * replication sequence file create
        **********************************************************************/
        //memset_s ( &sReplSeqInfo, 0x00, sizeof(dbmReplSeqInfo) );
        sReplSeqInfo.sTxID = mTxID;
        sReplSeqInfo.sLSN = sLSN;
        sReplSeqInfo.sCurFileNo = mLogAnchor->mTxAnchor[mTxID].mCurFileNo;
        sReplSeqInfo.sTotalBlockNo = sBlockHeader.mTotalBlockNo;
        sReplSeqInfo.sTranTotalSize = sBlockHeader.mTranTotalSize;
        sReplSeqInfo.sSeq = sLSN;
        sReplSeqInfo.sMagicNo = sMagicNo;


        // 2014.11.20 -okt- memset 제거. (1.1)
        sBlockHeader.mCurrentBlockNo = 0 + 1;
        memcpy_s ( mAlignedBuf, &sBlockHeader, sizeof(dbmLogBlockHeader) );

        for ( i = 0; i < sTotalBlockCount; i++ )
        {
            // 2014.11.20 -okt- memset 제거. (1.2)
            //memset_s ( mAlignedBuf, 0x00, DBM_LOG_BLOCK_SIZE );
            //sBlockHeader.mCurrentBlockNo = i + 1;
            //memcpy_s ( mAlignedBuf, &sBlockHeader, sizeof(dbmLogBlockHeader) );
            ( (dbmLogBlockHeader*)mAlignedBuf )->mCurrentBlockNo = i + 1;

            // #1030 수정을 위해 다음과 같이한다.
            // 로그는 <blockheader><log>..를 연속적으로 쓰고 있다.
            // 단, 이 <log>는 짤려서 몇개의 Block에 나뉘어 기록될 수 도 있다.
            // 차후에 비정상리커버리시점에 commit로그 탐색을 위해 blockheader에 magicno를 달았는데
            // 모든 Block이 이걸 설정해서 해도 뒤에서 부터 탐색해서 읽을때 
            // 매번 magicno가 발견될테니 이를 방지하기 위해 최초 1번만 셋팅한다.
            // 아주 비정상적으로 쓰리게값이 우연히 일치한다면 이는 망하라는 하늘의 뜻이다.
            // 더 좋은 방법이 있다면 적용하라.
            // 최초의 로그에만 블럭헤더의 MagicNo를 셋팅합시당.
            if (i > 0)
            {
                ( (dbmLogBlockHeader*)mAlignedBuf )->mMagicNo = 0;
            }

            memcpy_s ( mAlignedBuf + sizeof(dbmLogBlockHeader), mLogBuffer + ( i * sBlockSize ), sBlockSize );

            //if ( mReplFD > 0 ) // 2014.11.20. -okt- 성능, 이렇게 바꾸고 싶은데, 값이 0이다. (gdb)
            if ( mLogAnchor->mReplEnableF == 1 )
            {
                // 40Byte pwrite
                sRC = pwrite ( mReplFD, &sReplSeqInfo, sizeof(dbmReplSeqInfo), sizeof(dbmReplSeqInfo) * sLSN );
                if ( sRC != sizeof(dbmReplSeqInfo) ) //, WRITE_FAIL );
                {
                    DBM_ERR ( "Try to write [%d] but failed errno [%d]", mFD, errno );
                    _THROW( RC_FAILURE );
                }
            }

            sRC = write_s ( mFD, mAlignedBuf, DBM_LOG_BLOCK_SIZE );
            if ( unlikely( sRC != DBM_LOG_BLOCK_SIZE ) ) // , WRITE_FAIL ) ;
            {
                DBM_ERR ( "Try to write [%d] but failed errno [%d]", mFD, errno );
                _THROW( RC_FAILURE );
            }

            mLogAnchor->mTxAnchor[mTxID].mStat = 0; // mAnchor( 0 ) 동일

            mMyFileSize += DBM_LOG_BLOCK_SIZE;
            /*** Log Anchor 에  업데이트 메모리 잡이니 뭐 그리 안느릴듯 */
            mLogAnchor->mTxAnchor[mTxID].mLastFileSize += DBM_LOG_BLOCK_SIZE;
        } /* for */

        mSyncBytes = DBM_LOG_BLOCK_SIZE * sTotalBlockCount  ;

        /***********************************************************************
         *  다 썼으니 이제  Log Buffer 를 초기화 시킴.
         **********************************************************************/
        mLogBufferIdx = 0 ;
        mLastLSN = sLSN ;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
} /* dbmDiskLogger::mFlush */


dbmCompressDiskLogger::dbmCompressDiskLogger ( int aTxID , dbmLogAnchor* aLogAnchor , long long aLogBufferSize , dbmDiskSyncOption aOption
                                               ) : dbmDiskLogger (aTxID, aLogAnchor, aLogBufferSize, aOption)
{
    int     sRC;

    _TRY
    {
        mCompressBytes = 0;
        mLogBufferSize = aLogBufferSize;
        mOutputBuffer = (char*) memalign_s ( aLogBufferSize ) ;

        assert ( mOutputBuffer != NULL && "Memory Alloc Fail !" );

        if ( __liblz4_so == NULL )
        {
            sRC = cmnDlopen( "liblz4.so", &__liblz4_so );
            assert ( sRC == 0 && "Compress library dlopen Fail !" );

            sRC = cmnDlsym ( __liblz4_so, "LZ4_compress", (void**)&__LZ4_compress );
            assert ( sRC == 0 && "dlsym Fail (LZ4_compress)" );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    //_END  // 생성자에서는 NO RETURN.
}


_BOOL dbmCompressDiskLogger::mCompress ()
{
    int sBytes;

    sBytes = __LZ4_compress ( mLogBuffer, mOutputBuffer, mLogBufferIdx );

    if ( sBytes != -1 && sBytes < mLogBufferIdx )
    {
        mCompressBytes = sBytes;
        //DBM_WARN ( "Original : %d  Compressed : %d Compress Ratio : %00.00f\n", mLogBufferIdx, sBytes, (float) sBytes / (float )mLogBufferIdx ) ;
        return TRUE ;
    }

    // 압축함수에서 실패하거나, 압축된 결과 사이즈가 더 클때.
    return FALSE;
}


_VOID dbmCompressDiskLogger::mFlush ( )
{
    dbmLogBlockHeader   sBlockHeader;
    dbmReplSeqInfo      sReplSeqInfo;

    int     sTotalBlockCount = 0;
    int     sBlockSize = DBM_LOG_BLOCK_SIZE - sizeof ( dbmLogBlockHeader ) ;
    long long sLSN = -1;
    int     sCompressF = FALSE;
    long long sMagicNo = (long long)(1365678123409192L);
    int     sRC ;

    _TRY
    {
        /***********************************************************************
         * 쓸게 없으면 Write 할 필요가 없다.
         **********************************************************************/
        if ( mLogBufferIdx == 0 )
        {
            _RETURN;
        }

        mLogAnchor->mTxAnchor[mTxID].mAlloc = 1;
        _CALL( mSwitchFile ( ) );
        //_IF_RAISE ( sRC , FILE_SWITCH_ERR);

        /***********************************************************************
         * Compress 를 수행하고 성공이면
         **********************************************************************/
        sCompressF = mCompress ( );

        /***********************************************************************
         * 현재 로그 버퍼를 통해서 몇개가 쓰여져야하는지 판단한다.
         **********************************************************************/

        if ( sCompressF )
        {
            if ( mCompressBytes % sBlockSize == 0 )
            {
                sTotalBlockCount = mCompressBytes / sBlockSize;
            }
            else
            {
                sTotalBlockCount = ( mCompressBytes / sBlockSize ) + 1;
            }

        }
        else
        {
            if ( mLogBufferIdx % sBlockSize == 0 )
            {
                sTotalBlockCount = mLogBufferIdx / sBlockSize;
            }
            else
            {
                sTotalBlockCount = ( mLogBufferIdx / sBlockSize ) + 1;
            }

        }

        /***********************************************************************
         * Log anchor 를 통해서 LSN 을 딴다.
         **********************************************************************/

        sLSN = mvpAtomicInc64 ( &mLogAnchor->mLoggerLSN );

        /***********************************************************************
         * Log Block 형태로  Disk 로 쓴다.
         **********************************************************************/
        sBlockHeader.mLSN = sLSN;
        sBlockHeader.mTotalBlockNo = sTotalBlockCount;
        sBlockHeader.mTranTotalSize = sCompressF ? mCompressBytes : mLogBufferIdx;
        sBlockHeader.mIsCompressF = sCompressF;
        gettimeofday ( &sBlockHeader.mWriteTime, NULL );

        /***********************************************************************
         * replication sequence file create
         **********************************************************************/
        //memset_s ( &sReplSeqInfo, 0x00, sizeof(dbmReplSeqInfo) );
        sReplSeqInfo.sTxID = mTxID;
        sReplSeqInfo.sLSN = sLSN;
        sReplSeqInfo.sCurFileNo = 0;    // 2014.11.18. -okt- memset 제거하면서 추가.
        sReplSeqInfo.sTotalBlockNo = sBlockHeader.mTotalBlockNo;
        sReplSeqInfo.sTranTotalSize = sBlockHeader.mTranTotalSize;
        sReplSeqInfo.sSeq = sLSN;
        sReplSeqInfo.sMagicNo = sMagicNo;

        for ( int i = 0; i < sTotalBlockCount; i++ )
        {
            sBlockHeader.mCurrentBlockNo = i + 1;
            memcpy_s ( mAlignedBuf, &sBlockHeader, sizeof(dbmLogBlockHeader) );

            if ( sCompressF )
            {
                memcpy_s ( mAlignedBuf + sizeof(dbmLogBlockHeader), mOutputBuffer + ( i * sBlockSize ), sBlockSize );
            }
            else
            {
                memcpy_s ( mAlignedBuf + sizeof(dbmLogBlockHeader), mLogBuffer + ( i * sBlockSize ), sBlockSize );
            }

            if ( mLogAnchor->mReplEnableF == 1 )
            {
                /* 속도가 조금 걸리면 밖으로 빼자 하지만 못쓰고 죽으면 어떻게 하지 */
                sRC = pwrite ( mReplFD, &sReplSeqInfo, sizeof(dbmReplSeqInfo), sizeof(dbmReplSeqInfo) * sLSN );
                if ( sRC != sizeof(dbmReplSeqInfo) ) //, WRITE_FAIL );
                {
                    DBM_ERR ( "Try to write [%d] but failed. rc=%d, (err=%d)", mReplFD, sRC, errno ) ;
                    _THROW( RC_FAILURE );
                }
            }

            sRC = write_s ( mFD, mAlignedBuf, DBM_LOG_BLOCK_SIZE );
            if ( sRC != DBM_LOG_BLOCK_SIZE ) //, WRITE_FAIL );
            {
                DBM_ERR ( "Try to write [%d] but failed. rc=%d, (err=%d)", mFD, sRC, errno ) ;
                _THROW( RC_FAILURE );
            }

            mMyFileSize += DBM_LOG_BLOCK_SIZE;
            /*** Log Anchor 에  업데이트 메모리 잡이니 뭐 그리 안느릴듯 */
            mLogAnchor->mTxAnchor[mTxID].mLastFileSize += DBM_LOG_BLOCK_SIZE;
        }

        mSyncBytes = DBM_LOG_BLOCK_SIZE * sTotalBlockCount;
        /***********************************************************************
         *  다 썼으니 이제  Log Buffer 를 초기화 시킴.
         **********************************************************************/

        mLogBufferIdx = 0;
        mCompressBytes = 0;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* dbmCompressDiskLogger::mFlush */

#endif /* __linux__ */
