/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   space manager
 ******************************************************************************/
#include "dbmSegmentManager.h"
#include "dbmHeader.h"


#ifdef USE_NEW_SHM
#define cmnShmCreate        cmnShmCreate_s
#define cmnShmDrop          cmnShmDrop_s
#define cmnShmAttach        cmnShmAttach_s
#define cmnShmDetach        cmnShmDetach_s
#else
#define cmnShmCreate        cmnPShmCreate
#define cmnShmDrop          cmnPShmDrop
#define cmnShmAttach        cmnPShmAttach
#define cmnShmDetach        cmnPShmDetach
#endif

#ifdef DBM_SLOT_TRACE
int         dbmSegmentManager::mEnvCheckFlag = -1;
cmnStlMap*  dbmSegmentManager::mSlotTraceMap = NULL;
#endif


dbmSegmentManager::dbmSegmentManager ( )
{
    mHeader = NULL;
    mSlotSize = -1;
    mUserHeaderSize = -1;
    mSegmentCount = -1;

    // 사용하지 않는 디폴트 생성자, 호출하면 죽이자.
    _DASSERT ( 0 );
}

dbmSegmentManager::~dbmSegmentManager ( )
{
#ifdef DBM_SLOT_TRACE
    if ( mSlotTraceMap != NULL )
    {
        //delete_s( mSlotTraceMap );    // 싱글톤이다. 제거하면 안됨
    }
#endif

//    DBM_DBG( "소멸자 (%s)", this->mObjectName );
//    //TODO: 소멸자에서 detach하면 깔끔할것 같은데. 이렇게 하면 죽는다 --; 이유는 ?
//    {
//        if ( mHeader != NULL )
//        {
//            this->Detach();
//            mHeader = NULL;
//        }
//    }
}

/***
 * Create 에서 호출하는 Constructor
 */
dbmSegmentManager::dbmSegmentManager ( dbmSegmentHeader* aSegmentHeader )
{
    memset_s ( mObjectName, 0x00, MAX_SEGMENT_NAME_LENGTH );
    memset_s ( mInstName, 0x00, DBM_NAME_LEN );
    memset_s ( mStartAddress, 0x00, sizeof(char*) * MAX_SEGMENT_COUNT );
    mSegmentCount = 0;

    strncpy_s( mObjectName, aSegmentHeader->mSegmentName, strlen_s(aSegmentHeader->mSegmentName) );
    strncpy_s( mInstName, aSegmentHeader->mInstName, strlen_s(aSegmentHeader->mInstName) );

    mSlotSize = 0;
    mUserHeaderSize = 0;
    mHeader = NULL;

#ifdef DBM_SLOT_TRACE
    if ( mEnvCheckFlag == -1 )
    {
        char* pChar = NULL;
        pChar = getenv( ENV_DBM_SEGMGR_DBLFREE_CHECK );
        if ( pChar == NULL )
        {
            mEnvCheckFlag = 0;
        }
        else
        {
            mEnvCheckFlag = 1;
        }
    }

    if ( mEnvCheckFlag == 1 && mSlotTraceMap == NULL )
    {
        mSlotTraceMap = new cmnStlMap( 100 );
    }
#endif
}

/* List Attach 할 때만 호출 한다 */
dbmSegmentManager::dbmSegmentManager ( dbmSegmentHeader* aSegmentHeader,
                                       int               aSegmentCount,
                                       char**            aStartAddr,
                                       size_t            aSlotSize,
                                       size_t            aUserHeaderSize,
                                       int               aTmp )
{
    memset_s ( mObjectName, 0x00, MAX_SEGMENT_NAME_LENGTH );
    memset_s ( mInstName, 0x00, DBM_NAME_LEN );
    memset_s ( mStartAddress, 0x00, sizeof(char*) * MAX_SEGMENT_COUNT );
    mSegmentCount = aSegmentCount;

    for( int i = 0; i < MAX_SEGMENT_COUNT; i++ )
    {
        if( aSegmentHeader->mSegmentAlloc[i] != -1 )
        {
            this->mStartAddress[i] = aStartAddr[i];
        }
    }


    mSlotSize = aSlotSize;
    mUserHeaderSize = aUserHeaderSize;

    strncpy_s ( mObjectName, aSegmentHeader->mSegmentName, strlen_s(aSegmentHeader->mSegmentName) );
    strncpy_s ( mInstName, aSegmentHeader->mInstName, strlen_s(aSegmentHeader->mInstName) );
    mHeader = (dbmSegmentHeader *) aStartAddr[0];

#ifdef DBM_SLOT_TRACE
    if ( mEnvCheckFlag == -1 )
    {
        char* pChar = NULL;
        pChar = getenv( ENV_DBM_SEGMGR_DBLFREE_CHECK );
        if ( pChar == NULL )
        {
            mEnvCheckFlag = 0;
        }
        else
        {
            mEnvCheckFlag = 1;
        }
    }

    if ( mEnvCheckFlag == 1 && mSlotTraceMap == NULL )
    {
        mSlotTraceMap = new cmnStlMap( 100 );
    }
#endif
}


/***
 * Attach 에서 호출하는 Constructor
 * ********************************************/
dbmSegmentManager::dbmSegmentManager ( dbmSegmentHeader* aSegmentHeader,
                                       int               aSegmentCount,
                                       char**            aStartAddr,
                                       size_t            aSlotSize,
                                       size_t            aUserHeaderSize )
{
    memset_s ( mObjectName, 0x00, MAX_SEGMENT_NAME_LENGTH );
    memset_s ( mInstName, 0x00, DBM_NAME_LEN );
    memset_s ( mStartAddress, 0x00, sizeof(char*) * MAX_SEGMENT_COUNT );
    mSegmentCount = aSegmentCount;
    for ( int i = 0; i < aSegmentCount; i++ )
    {
        this->mStartAddress[i] = aStartAddr[i];
    }

    mSlotSize = aSlotSize;
    mUserHeaderSize = aUserHeaderSize;

    strncpy_s ( mObjectName, aSegmentHeader->mSegmentName, strlen_s(aSegmentHeader->mSegmentName) );
    strncpy_s ( mInstName, aSegmentHeader->mInstName, strlen_s(aSegmentHeader->mInstName) );
    mHeader = (dbmSegmentHeader *) aStartAddr[0];

#ifdef DBM_SLOT_TRACE
    if ( mEnvCheckFlag == -1 )
    {
        char* pChar = NULL;
        pChar = getenv( ENV_DBM_SEGMGR_DBLFREE_CHECK );
        if ( pChar == NULL )
        {
            mEnvCheckFlag = 0;
        }
        else
        {
            mEnvCheckFlag = 1;
        }
    }

    if ( mEnvCheckFlag == 1 && mSlotTraceMap == NULL )
    {
        mSlotTraceMap = new cmnStlMap( 100 );
    }
#endif
}


/**
 * Description
 *
 *   이름을 통해 Create 를 수행하고, Attach 를 수행한 후 객체를 리턴한다.
 *   본 함수 이후 생성된 객체를 통해서 별도의 Attach 과정없이 바로 사용할 수 있다,
 *
 *
 * Argument
 *   @aObjectName      : 해당 Object 의 이름
 *   @aSlotSize        : 본 Segment 의 slot 크기
 *   @aInitSlotcount   : 최초 생성할 Slot 의 갯수
 *   @aExtendSlotCount : Extend 시 추가할 Slot 의 갯수
 *   @aMaxSlotCount    : 최대로 늘어날 수 있는 Slot 의 갯수
 *   @aUserHeaderSize  : 외부에서 사용할 Header 의 사이즈 ( 예 Transaction Header )
 *   @aLogHandle       : Logging 용 Log handle
 *   @aReturnObject    : 생성될 Object 의 Instance
 *
 *
 * Return
 *    0 이면 Success
 *    그외이면 모두 Fail
 *
 *    자세한 에러로그는  전달한 aLogHandle 에 기록한다.
 *
 */
_VOID dbmSegmentManager::Create ( char*     aInstName,
                                  char*     aObjectName,
                                  size_t    aSlotSize,
                                  long long aInitSlotCount,
                                  long long aExtendSlotCount,
                                  long long aMaxSlotCount,
                                  size_t    aUserHeaderSize,
                                  dbmSegmentManager** aReturnObject )

{
    dbmSegmentHeader    sSegmentHeader;
    dbmSegmentManager*  sRtnObject = NULL;

    _TRY
    {
        memset_s ( &sSegmentHeader, 0x00, sizeof (dbmSegmentHeader)) ;

        _IF_THROW( aInstName == NULL, ERR_DBM_INVALID_INST_NAME );

        /* Header 를 세팅한다. */
        strncpy_s( sSegmentHeader.mSegmentName, aObjectName, strlen_s(aObjectName) );
        strncpy_s( sSegmentHeader.mInstName, aInstName, strlen_s(aInstName) );

        sSegmentHeader.mLock = -1;
        sSegmentHeader.mSegmentCount = 1;
        sSegmentHeader.mSlotSize = aSlotSize;
        sSegmentHeader.mInitSlotCount =  aInitSlotCount;

#ifdef _DEBUG
        if ( ! cmnIsPowerNum( aExtendSlotCount ) )
        {
            _DASSERT( 0 );
        }
#endif
        sSegmentHeader.mExtendSlotCount = aExtendSlotCount ;
        // 2014.11.21 -okt- 지수를 따로 관리하여, Slot2Addr에서 나누기연산 제거
        sSegmentHeader.mExtendSlotPower = (long long)log2((double)aExtendSlotCount);

        sSegmentHeader.mMaxSlotCount =  aMaxSlotCount;
        sSegmentHeader.mUserHeaderSize = aUserHeaderSize;
        sSegmentHeader.mNextExtendNo = 1;

        memset_s( sSegmentHeader.mSegmentAlloc, -1, sizeof(int) * MAX_SEGMENT_COUNT );
        sSegmentHeader.mSegmentAlloc[0] = 0;


        sRtnObject = new dbmSegmentManager ( &sSegmentHeader ) ;
        _IF_THROW ( sRtnObject == NULL , ERR_DBM_MEM_ALLOC ) ;

        _CALL( sRtnObject->CreateAndInitSegment (
                                     aObjectName,
                                     0,
                                     aSlotSize,
                                     sSegmentHeader.mInitSlotCount,
                                     &sSegmentHeader ) );

        *aReturnObject = sRtnObject;
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_SHM_ALREADY_EXIST )
            _CATCH_WARN;
    }
    _FINALLY
    _END
}


// Attach 할  파일의 이름을 만들어낸다.
_VOID dbmSegmentManager::getFileName ( char* aInstName, char* aObjectName , int aSegmentNo , char* aReturnFile )
{
    /*
     * TODO: 2015.01.25 -okt- glibc 2.18.90-13. 버전 이후 /dev/shm 이하에 디렉토리 구조를 만들수 없게됨
     *
     *       (참고)
     *       http://stackoverflow.com/questions/23145458/shm-open-fails-with-einval-when-creating-shared-memory-in-subdirectory-of-dev
     *       https://sourceware.org/bugzilla/show_bug.cgi?id=16274 해결되어야, 기존 방식으로 가능함
     *       Fedora는 glibc가 낮은 버전이고 ( gcc는 더 높으나) ubuntu ( mint 17 )에서만 문제가 됨
     *       정확히는 GLIBC 버전을 확인해야하나, 방법을 모르므로 GCC버전으로 검사
     */
#ifdef __linux__    //TODO: [OKT] 윈도포팅

#if __GNUC_PREREQ (4, 8)
    if ( _cmn_shm_prefix != NULL )
    {
        sprintf ( aReturnFile, "-%s-%s-%s_%03d", _cmn_shm_prefix, aInstName, aObjectName, aSegmentNo );
    }
    else
    {
        sprintf ( aReturnFile, "-%s-%s_%03d", aInstName, aObjectName, aSegmentNo );
    }
#else
    if ( _cmn_shm_prefix != NULL )
    {
        sprintf ( aReturnFile, "/%s/%s/%s_%03d", _cmn_shm_prefix, aInstName, aObjectName, aSegmentNo );
    }
    else
    {
        sprintf ( aReturnFile, "/%s/%s_%03d", aInstName, aObjectName, aSegmentNo );
    }
#endif

#else

    //TODO: [OKT] 윈도포팅, 파일이름에 '-'를 처리 못하는 것 같다. (현재 실패원인은 아니지만 그냥둔다 )
    sprintf ( aReturnFile, "C:\\dbm_home\\dic\\_%s_%s_%03d", aInstName, aObjectName, aSegmentNo );

#endif /* __linux__ */

    return 0;
}


/*
 *  Shared memory 를 만들어서 Initialize 해 놓는다.
 *  이건 create 및 extend 시 사용한다.
 */
_VOID dbmSegmentManager::CreateAndInitSegment ( char*   aObjectName,
                                                int     aCurrentSegmentNo,
                                                size_t  aSlotSize,
                                                long long aSlotCount,
                                                dbmSegmentHeader* aHeader)
{
    size_t  sSize ;
    char    sFileName [MAX_SEGMENT_NAME_LENGTH];
    char*   sStartAddr = NULL;
    long long sStartSlotNo ;
    char*   sDataAddress;
    dbmSegmentHeader  sHeader ;

    long long* sStartSlot = NULL;

    _TRY
    {
        if ( aCurrentSegmentNo == 0 )
        {
            sSize = sizeof(dbmSegmentHeader) + sizeof(long long) * ( aSlotCount + 1 )
                    + aSlotSize * aSlotCount + aHeader->mUserHeaderSize;
        }
        else
        {
            sSize = sizeof(dbmSegmentHeader) + sizeof(long long) * ( aSlotCount + 1 )
                    + aSlotSize * aSlotCount;
        }

        memcpy_s ( &sHeader, aHeader, sizeof(dbmSegmentHeader) );

        /**** Header 의 값중 Segment Local 단계에서 사용할
         *    Slot Manage 관련 정보들을 세팅한다. */

        /*** 헤더값을 여기서 세팅하면 안댄다 */
        sHeader.mAlloc = 0;
        sHeader.mFree = aSlotCount;
        strncpy_s ( sHeader.mMagicString, MAGIC_STRING, sizeof ( sHeader.mMagicString ) );

        dbmSegmentManager::getFileName ( mInstName, aObjectName, aCurrentSegmentNo, sFileName );

        _rc = cmnShmCreate ( sFileName, sSize, (void**)&sStartAddr );
        if ( _rc != 0 )
        {
            //[BUGBUG] 여기서 로그를 찍고 errno를 검사하면 errno가 로그 출력과정에서 다시 reset된다.
            //DBM_INFO( "Creating [%s]  Size [%ld] with RC[%d] (err=%d,tid=%d)", sFileName, sSize, _rc, errno, gettid_s() );
            if ( errno == EEXIST )
            {
                _THROW( ERR_DBM_SHM_ALREADY_EXIST );
            }
            else
            {
                _THROW( ERR_DBM_INVALID_SHM_OPER_FAIL );
            }
        }

        if ( aCurrentSegmentNo == 0 )
        {
            sStartSlot = (long long*) ( sStartAddr + sizeof(dbmSegmentHeader) + aHeader->mUserHeaderSize );
        }
        else
        {
            sStartSlot = (long long*) ( sStartAddr + sizeof(dbmSegmentHeader) );
        }

        //DBM_INFO("Copying to [%x] from sHeader", sStartAddr ) ;
        /* 헤더가 필요하니 헤더를 세팅한다 */
        memset_s ( sStartAddr, 0x00, sSize );
        memcpy_s ( sStartAddr, &sHeader, sizeof(dbmSegmentHeader) );

        // 이번에 할당할 Slot 번호는  뭘까 ? */
        if ( aCurrentSegmentNo == 0 )
        {
            sStartSlotNo = 0;
        }
        else
        {
            sStartSlotNo = aHeader->mInitSlotCount + ( aCurrentSegmentNo - 1 ) * aHeader->mExtendSlotCount;
        }

        for ( int i = 0; i < ( aSlotCount + 1 ); i++ )
        {
            if ( i < aSlotCount )
            {
                sStartSlot[i] = sStartSlotNo + i;

            }
            else
            {
                sStartSlot[i] = -1;
            }
        }

        /* 어느 성깔 있으신 분께서, Cache miss 의 영향도를 파악하기위해
         * 전체 Segment 를 memset_s 하라고 함. */
        sDataAddress = (char*) sStartSlot + sizeof(long long) * ( aSlotCount + 1 );
        memset_s ( sDataAddress, 0xff, aSlotSize * aSlotCount );

        mStartAddress[aCurrentSegmentNo] = sStartAddr;
        mSegmentCount++;
        strncpy_s ( mObjectName, aObjectName, strlen_s(aObjectName) );
        mUserHeaderSize = aHeader->mUserHeaderSize;
        mSlotSize = aHeader->mSlotSize;

        /** Header 참조비용을 줄이기 위해서 ***/

        if ( aCurrentSegmentNo == 0 )
        {
            mHeader = (dbmSegmentHeader *) mStartAddress[0];
        }
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_SHM_ALREADY_EXIST || _rc == ERR_DBM_INVALID_SHM_OPER_FAIL )
        {
            DBM_INFO( "Creating [%s]  Size [%ld] with RC[%d] (err=%d,tid=%d)"
                    , sFileName, sSize, _rc, errno, gettid_s() );
        }
        else
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* CreateAndInitSegment */


/**
 * Description
 *
 *  이름을 통해 Attach 를 수행하고, Attach 를 수행한 후 객체를 리턴한다.(List 객체)
 *
 * Argument
 *   @aObjectName      : 해당 Object 의 이름
 *   @aSlotSize        : 본 Segment 의 slot 크기
 *   @aInitSlotcount   : 최초 생성할 Slot 의 갯수
 *   @aExtendSlotCount : Extend 시 추가할 Slot 의 갯수
 *   @aMaxSlotCount    : 최대로 늘어날 수 있는 Slot 의 갯수
 *   @aLogHandle       : Logging 용 Log handle
 *   @aReturnObject    : 생성될 Object 의 Instance
 **
 * Return
 *    0 이면 Success
 *    그외이면 모두 Fail.
 *
 *    자세한 에러로그는  전달한 aLogHandle 에 기록한다.
 *
 */
_VOID dbmSegmentManager::AttachList ( char* aInstName, char* aObjectName , dbmSegmentManager** aReturnObject )
{
    dbmSegmentHeader    sHeader;
    void*               sAddr = NULL;
    char                sFileName[MAX_SEGMENT_NAME_LENGTH] ;
    int                 sSlotCount ;
    dbmSegmentManager*  sSegmentManager = NULL;
    size_t              sSize;

    char*               sStartAddr[MAX_SEGMENT_COUNT];

    _TRY
    {
        /*** 주어진 이름을 통해  0 번 Segment 에 붙어보고, Header Page 를 얻어낸다. */
        getFileName ( aInstName, aObjectName, 0, sFileName ) ;

        _rc = cmnShmAttach ( sFileName, sizeof(dbmSegmentHeader), &sAddr );
        _IF_THROW ( _rc , ERR_DBM_ATTACH_SHM_FAIL ) ;     // 원래 소스를 정확하게 살리면, 이런식으로.

        //memset_s ( &sHeader, 0x00, sizeof(sHeader) );
        memcpy_s ( &sHeader, sAddr, sizeof(dbmSegmentHeader) );
        strncpy_s( sHeader.mInstName, aInstName, strlen_s(aInstName) );

#ifndef USE_NEW_SHM
        _rc = cmnShmDetach ( &sAddr, sizeof(dbmSegmentHeader) );
        _IF_THROW ( _rc , ERR_DBM_DETACH_SHM_FAIL ) ;
#endif

        /*** 여기서 해당 파일을  읽은 것이 segmentManager 에서 생성한 파일인지 확인**/
        if ( strncmp_s ( sHeader.mMagicString , MAGIC_STRING, strlen_s (MAGIC_STRING)) )
        {
            // [주의] 이런거 찍다가 죽을수도 있다. 깨진키니깐. 때문에 _DBG 모드에서만 찍는다.
            DBM_DBG ( "invalid magic key [%s != %s]", sHeader.mMagicString , MAGIC_STRING );
            _THROW ( ERR_DBM_ATTACH_SHM_FAIL ) ;
        }


        /** 해당 헤더를 가지고 왔으니 붙여주겠다 */
        //for ( int i = 0; i < sHeader.mSegmentCount; i++ )
        for( int i = 0; i < MAX_SEGMENT_COUNT; i++ )
        {
            if( sHeader.mSegmentAlloc[i] != -1 )
            {
                getFileName ( aInstName, aObjectName, i, sFileName );
                sSlotCount = i == 0 ? sHeader.mInitSlotCount : sHeader.mExtendSlotCount;

                if ( i == 0 )
                {
                    sSize = sizeof (dbmSegmentHeader ) +
                        sizeof(long long) * (sSlotCount+1)  +
                        sHeader.mUserHeaderSize +
                        sHeader.mSlotSize * sSlotCount ;
                }
                else
                {
                    sSize = sizeof (dbmSegmentHeader ) +
                        sizeof(long long) * (sSlotCount +1 ) +
                        sHeader.mSlotSize * sSlotCount ;
                }

                _IF_THROW( cmnShmAttach ( sFileName, sSize, (void**)&sStartAddr[i] ),
                           ERR_DBM_ATTACH_SHM_FAIL );
            }
        }

        /* 해당 헤더를 다 만들어줬으니 객체를 만들어서 리턴한다.
         * 이때 해당 멤버의 값을 세팅해서 넘겨야함
         */
        sSegmentManager = new dbmSegmentManager ( &sHeader,
                                                  sHeader.mSegmentCount,
                                                  sStartAddr,
                                                  sHeader.mSlotSize,
                                                  sHeader.mUserHeaderSize,
                                                  0 );
        _IF_THROW( sSegmentManager == NULL, ERR_DBM_MEM_ALLOC );

        *aReturnObject = sSegmentManager;
    }
    _CATCH
    {
        /*
         * 테이블이 없는데 drop 을 하면 ERR_DBM_ATTACH_SHM_FAIL 발생.
         * 때문에 WARN으로 찍는 것은 이상함.
         */
        _CATCH_INFO2( sFileName );
    }
    _FINALLY
    _END
}



/**
 * Description
 *
 *  이름을 통해 Attach 를 수행하고, Attach 를 수행한 후 객체를 리턴한다.
 *
 * Argument
 *   @aObjectName      : 해당 Object 의 이름
 *   @aSlotSize        : 본 Segment 의 slot 크기
 *   @aInitSlotcount   : 최초 생성할 Slot 의 갯수
 *   @aExtendSlotCount : Extend 시 추가할 Slot 의 갯수
 *   @aMaxSlotCount    : 최대로 늘어날 수 있는 Slot 의 갯수
 *   @aLogHandle       : Logging 용 Log handle
 *   @aReturnObject    : 생성될 Object 의 Instance
 **
 * Return
 *    0 이면 Success
 *    그외이면 모두 Fail.
 *
 *    자세한 에러로그는  전달한 aLogHandle 에 기록한다.
 *
 */
_VOID dbmSegmentManager::Attach ( char* aInstName, char* aObjectName , dbmSegmentManager** aReturnObject )
{
    dbmSegmentHeader    sHeader;
    dbmSegmentManager*  sSegmentManager = NULL;
    char*               sStartAddr[MAX_SEGMENT_COUNT];
    void*               sAddr = NULL;
    char                sFileName[MAX_SEGMENT_NAME_LENGTH] ;
    int                 sSlotCount ;
    size_t              sSize;
    int                 i;

    _TRY
    {
        /*** 주어진 이름을 통해  0 번 Segment 에 붙어보고, Header Page 를 얻어낸다. */
        getFileName ( aInstName, aObjectName, 0, sFileName ) ;

        _rc = cmnShmAttach ( sFileName, sizeof(dbmSegmentHeader), &sAddr );
        _IF_THROW ( _rc , ERR_DBM_ATTACH_SHM_FAIL ) ;     // 원래 소스를 정확하게 살리면, 이런식으로.

        //memset_s ( &sHeader, 0x00, sizeof(sHeader) );
        memcpy_s ( &sHeader, sAddr, sizeof(dbmSegmentHeader) );
        strncpy_s( sHeader.mInstName, aInstName, strlen_s(aInstName) );

#ifndef USE_NEW_SHM
        _rc = cmnShmDetach ( &sAddr, sizeof(dbmSegmentHeader) );
        _IF_THROW ( _rc , ERR_DBM_DETACH_SHM_FAIL ) ;
#endif

        /*** 여기서 해당 파일을  읽은 것이 segmentManager 에서 생성한 파일인지 확인**/
        if ( strncmp_s ( sHeader.mMagicString , MAGIC_STRING, strlen_s (MAGIC_STRING)) )
        {
            // [주의] 이런거 찍다가 죽을수도 있다. 깨진키니깐. 때문에 _DBG 모드에서만 찍는다.
            DBM_DBG ( "invalid magic key [%s != %s]", sHeader.mMagicString , MAGIC_STRING );
            _THROW ( ERR_DBM_ATTACH_SHM_FAIL ) ;
        }


        /** 해당 헤더를 가지고 왔으니 붙여주겠다 */
        for ( i = 0; i < sHeader.mSegmentCount; i++ )
        {
            getFileName ( aInstName, aObjectName, i, sFileName );
            sSlotCount = i == 0 ? sHeader.mInitSlotCount : sHeader.mExtendSlotCount;

            if ( i == 0 )
            {
                sSize = sizeof(dbmSegmentHeader) + sizeof(long long) * ( sSlotCount + 1 )
                        + sHeader.mUserHeaderSize + sHeader.mSlotSize * sSlotCount;
            }
            else
            {
                sSize = sizeof(dbmSegmentHeader) + sizeof(long long) * ( sSlotCount + 1 )
                        + sHeader.mSlotSize * sSlotCount;
            }

            _IF_THROW( cmnShmAttach ( sFileName, sSize, (void**)&sStartAddr[i] ),
                       ERR_DBM_ATTACH_SHM_FAIL );
        }

        /* 해당 헤더를 다 만들어줬으니 객체를 만들어서 리턴한다.
         * 이때 해당 멤버의 값을 세팅해서 넘겨야함
         */
        sSegmentManager = new dbmSegmentManager ( &sHeader,
                                                  sHeader.mSegmentCount,
                                                  sStartAddr,
                                                  sHeader.mSlotSize,
                                                  sHeader.mUserHeaderSize
                                                  );
        _IF_THROW( sSegmentManager == NULL, ERR_DBM_MEM_ALLOC );

        *aReturnObject = sSegmentManager;
    }
    _CATCH
    {
        /*
         * 테이블이 없는데 drop 을 하면 ERR_DBM_ATTACH_SHM_FAIL 발생.
         * 때문에 WARN으로 찍는 것은 이상함.
         */
        _CATCH_INFO2( sFileName );
    }
    _FINALLY
    _END
}


/*
 * 현재 주어진 aSegment 에 대해서 Extend 를 수행한다.
 *
 * 만약 다른놈이 Extend 중이라면 해당 Extend 가 완료될떄까지 기다리고,
 * 리턴한다.
 *
 */
_VOID dbmSegmentManager::ExtendUntilSuccess ( int aSegmentNo )
{
    char    sFileName[MAX_SEGMENT_NAME_LENGTH];

    _TRY
    {
        getFileName ( mInstName, mHeader->mSegmentName, aSegmentNo, sFileName );

        /** 만약에 aSegmentNo 로 만들 것이 존재하는 경우는 만들다가 죽은 경우라
         *  가정할 수 있다. 이 함수내에는 무조건 1개의 Thread만 진입 가능하기 때문
         *  그러므로 , 기존에 파일이 이미 만들어져있다면 지워줘야해 */

//        /** 이 함수는 걍 콜하고 리턴값은 무시하자. 왜냐하면 성공이든 실패이든 있으면
//         * 지워졌을꺼다 */
//      cmnShmDrop ( sFileName ) ;

        DBM_TRC( "Start.. Extending to %03d segment, [%s] (err=%d,tid=%d)", aSegmentNo, sFileName, errno, gettid_s() ) ;

        _CALL( CreateAndInitSegment ( mHeader->mSegmentName,
                aSegmentNo,
                mHeader->mSlotSize,
                mHeader->mExtendSlotCount,
                mHeader ) );

        DBM_TRC("  End.. Extending to %03d segment, [%s] (err=%d,tid=%d)", aSegmentNo, sFileName, errno, gettid_s() ) ;

        /** 여기서 성공적으로 만들어졌다면, SegmentNo 를 증가  */
        mvpAtomicInc32 ( &mHeader->mNextExtendNo ) ;
        mvpAtomicInc32 ( &mHeader->mSegmentCount ) ;

        /* 2014.10.20 -shw- list에서는 segemnt가 순서대로 할당 되지 않아 헤더를 보고 어디가
         * 할 당 되어 있는지를 파악하기 위해 extend 처리 시 해당 sgement할당 no를 set 처리 한다
         *  이놈은 첫번째 segment header의 값의 포인터 이다. */
        mHeader->mSegmentAlloc[aSegmentNo] = aSegmentNo;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/*
 * Slot2Addr에서 매번 호출되는 성능함수이다. 살살만지자.
 */
_VOID dbmSegmentManager::ListCheckShmAttach ( int aSegmentNo )
{
    // (성능) 변수선언보다 앞에 위치한다.
    // 2014.12.14. -okt- 추후 매크로화 하여, 이부분을 제거 할 수 있다.
    if (  mStartAddress[aSegmentNo] != NULL ) return 0;

    _TRY
    {
        //if (  mStartAddress[aSegmentNo] != NULL ) _RETURN;

        char        sFileName[MAX_SEGMENT_NAME_LENGTH] ;
        size_t      sSize;
        int         sRC;

         if ( aSegmentNo != 0 )
        {
            sSize = mHeader->mExtendSlotCount * mHeader->mSlotSize + sizeof(dbmSegmentHeader)
                    + ( ( 1 + mHeader->mExtendSlotCount ) * sizeof(long long) );
        }
        else
        {
            sSize = mHeader->mInitSlotCount * mHeader->mSlotSize + sizeof(dbmSegmentHeader)
                    + ( ( 1 + mHeader->mInitSlotCount ) * sizeof(long long) );
        }

        /* 여기서는 해당 SegmentNo 위치에 Attach 를  수행하여본다 */
        getFileName ( mInstName, mHeader->mSegmentName, aSegmentNo, sFileName );
        sRC = cmnShmAttach ( sFileName, sSize, (void**)&mStartAddress[aSegmentNo] );
        if ( sRC != 0 )
        {
            DBM_ERR( "Fail to Attach [%s] with size [%ld] :  rc=%d (err=%d,tid=%d)\n"
                    , sFileName, sSize, sRC, errno, gettid_s ( ) );
            _THROW( ERR_DBM_ATTACH_SHM_FAIL );
        }

        mvpAtomicInc32 ( &mSegmentCount );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/*
 * Slot2Addr에서 매번 호출되는 성능함수이다. 살살만지자.
 */
_VOID dbmSegmentManager::CheckShmAttach ( int aSegmentNo )
{
    // (성능) 변수선언보다 앞에 위치한다.
    // 2014.12.14. -okt- 추후 매크로화 하여, 이부분을 제거 할 수 있다.
    if (  mStartAddress[aSegmentNo] != NULL ) return 0;

    _TRY
    {
        //if (  mStartAddress[aSegmentNo] != NULL ) _RETURN;

        char        sFileName[MAX_SEGMENT_NAME_LENGTH] ;
        size_t      sSize;
        int         sRC;


        if (  unlikely ( aSegmentNo >= mvpAtomicGet32( &mHeader->mSegmentCount ) ) )
        {
            // 22:11:31.504221-C-[CheckShmAttach : 524] Attach Requested : [46850909] but Total SegmentCount [1]
            DBM_ERR ( "Attach Requested : [%d] but Total SegmentCount [%d] (",
                     aSegmentNo, mHeader->mSegmentCount ) ;
            _THROW ( ERR_DBM_INVALID_OPERATION );
        }

         if ( aSegmentNo != 0 )
        {
            sSize = mHeader->mExtendSlotCount * mHeader->mSlotSize + sizeof(dbmSegmentHeader)
                    + ( ( 1 + mHeader->mExtendSlotCount ) * sizeof(long long) );
        }
        else
        {
            sSize = mHeader->mInitSlotCount * mHeader->mSlotSize + sizeof(dbmSegmentHeader)
                    + ( ( 1 + mHeader->mInitSlotCount ) * sizeof(long long) );
        }

        /* 여기서는 해당 SegmentNo 위치에 Attach 를  수행하여본다 */
        getFileName ( mInstName, mHeader->mSegmentName, aSegmentNo, sFileName );
        sRC = cmnShmAttach ( sFileName, sSize, (void**)&mStartAddress[aSegmentNo] );
        if ( sRC != 0 )
        {
            DBM_ERR( "Fail to Attach [%s] with size [%ld] :  rc=%d (err=%d,tid=%d)\n"
                    , sFileName, sSize, sRC, errno, gettid_s ( ) );
            _THROW( ERR_DBM_ATTACH_SHM_FAIL );
        }

        mvpAtomicInc32 ( &mSegmentCount );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}



/**
 * Description
 *
 *  해당 Segment 에서 가용한 Slot 을 리턴한다.
 *
 * Argument
 *   @aReturnSlot      : 해당 주어진 Slot의 리턴값
 *
 * Return
 *    0 이면 성공, 그외에는 오류
 *    자세한 에러로그는  전달한 aLogHandle 에 기록한다.
 *
 */
#ifdef DBM_SLOT_TRACE
_VOID dbmSegmentManager::AllocSlot ( long long* aReturnSlot, const char* aFile, const char* aFunc, int aLine )
#else
_VOID dbmSegmentManager::AllocSlot ( long long* aReturnSlot )
#endif
{
    long long sSlot = -1;
    long long sSize = 0;
    int     i;

    _TRY
    {
        //TODO: 2014.10.14 -okt- 확장할때만 검사하면 될것 같다.
        //_IF_THROW( this->mSegmentCount >= MAX_SEGMENT_COUNT, ERR_DBM_NO_SPACE );

        do
        {
            for ( i = 0; i < mHeader->mSegmentCount; i++ )
            {
                //TODO: 2014.10.14 -okt- (성능) 좀 분리하면 빨라질까? 나중에.
                sSize = i == 0 ? mHeader->mInitSlotCount : mHeader->mExtendSlotCount;

                _rc =  AllocSlot ( i , sSize, &sSlot ) ;
                if ( likely( _rc == RC_SUCCESS ) )
                {
                    *aReturnSlot = sSlot;
                    _RETURN;
                }
                else if ( _rc == ERR_DBM_NO_SPACE )
                {
                    // 다음 Segment를 시도한다.
                    continue;
                }
                else
                {
                    /**  이경우는 Shared Memory 가 FULL 났거나,
                     * 문제가 발생한 경우이다.  사용자에게 error 를 리턴*/
                    _THROW ( _rc ) ;
                }
            }

            /** 여기까지 왔으면 그래도 못찾은거임.  여기서 Extend 할것인지 말것인지 결정해야함 */
            if ( mHeader->mInitSlotCount + mHeader->mSegmentCount * mHeader->mExtendSlotCount > mHeader->mMaxSlotCount )
            {
                /** 이경우는 MAX 에 찬것이기 떄문에 Extend 하면 안된다 */
                DBM_WARN ( "Maximum Slot count reached. current [%ld] nextExtend[%ld] limit [%ld]",
                         mHeader->mInitSlotCount + ( mHeader->mSegmentCount - 1 ) * mHeader->mExtendSlotCount,
                         mHeader->mExtendSlotCount,
                         mHeader->mMaxSlotCount );
                _THROW( ERR_DBM_NO_SPACE );
            }

            /* 여기까지 왔다면 Extend를 해야할 타임이다 */
            //TODO: 2014.11.26. -okt- #470 아래로 회피,
            //_IF_THROW( this->mSegmentCount >= MAX_SEGMENT_COUNT, ERR_DBM_NO_SPACE );
            _IF_THROW( mHeader->mSegmentCount >= MAX_SEGMENT_COUNT, ERR_DBM_NO_SPACE );

            /*** 여기서 Extend 할 SegmentNo 를 넘겨서 Extend 를 수행한다 */
            // 2014.10.02 -okt- 루프안의 변수선언이나. 통상적으로 진입하지 않는 위치이므로, 장점이 있다.
            int sLoopCnt = 0;
            int sPreLock = -1;
            do
            {
                _rc = dbmLockSegment ( );
                if ( _rc == RC_SUCCESS )
                {
                    _rc = ExtendUntilSuccess ( mHeader->mNextExtendNo );
                    if ( _rc != 0 )
                    {
                        dbmUnlockSegment () ;
                        _THROW( _rc );
                    }

                    dbmUnlockSegment ( );
                    break;
                }
                else
                {
                    //  Lock 이 풀릴떄까지 기다린다.
                    if ( mHeader->mLock == -1 )
                    {
                        //TODO:  2014.12.14. -okt- 락이 풀렸으면 누군가 확장을 했다는 의미이고, 그럼 왜 쉬지?? ( 2014/07/25 )
                        if ( sLoopCnt > ( _cmn_sys_ncpu << 8 ) )    // 별 의미없는 임계 상수
                        {
                            // extend 로 인한 대기 정보를 튜닝 정보로 노출 가능하다.
                            DBM_DBG( "[MON] Wait Info - Segment Extend [Re,%d,Lock,%d] (err=%d,tid=%d)", sLoopCnt, sPreLock, errno, gettid_s() );
                        }
                        //cmnUSleep ( 1000 );
                        break;
                    }
                }

                sLoopCnt++;
                sPreLock = mHeader->mLock;
                pthread_yield_s();
            } while ( true );

            _rc = AllocSlot ( i, sSize, &sSlot );
            if ( _rc == RC_SUCCESS )
            {
               *aReturnSlot = sSlot;
//               DBM_TRC ( "AllocSlot retry OK. [i,%d,S,%d,L,%d] (err=%d,tid=%d)", i, sSlot, mHeader->mLock, errno, gettid_s() );
               _RETURN;
            }
        } while  ( true );
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_NO_SPACE )
        {
            /*** 이래도 없으면 뭔가 문제다. 걍 오류를 리턴한다 ***/
            DBM_WARN ( "Too many Segment : current [%d] Max [%d]", this->mSegmentCount, MAX_SEGMENT_COUNT ) ;
        }
        else
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    {
#ifdef DBM_SLOT_TRACE
        if ( _rc == 0 && mSlotTraceMap != NULL ) // 1012 ( ERR_DBM_NO_SPACE )
        {
            mSlotTraceMap->mErase( this->mObjectName, aReturnSlot );
        }
#endif
    }
    _END
} /* AllocSlot */


/*
 * 주어진 Segment 번호에서 Free Slot 을 찾아 리턴한다.
 *
 * 2014.10.14 -okt- 정상적인 경우도 ERR_DBM_NO_SPACE 가 발생하여 전역변수인 _cmn_errno에 쓰기가 발생한다. 때문에 _TRY 사용하지 않음.
 */
_VOID dbmSegmentManager::AllocSlot ( int aSegmentNo , long long aSlotCount , long long* aReturnSlot )
{
    dbmSegmentHeader* sHeader ;
    long long* sAlloc;
    long long sSlotNo;
    long long sInd;
    int     sRC;

    /* 주어진 Segment 에 Attach 가 되었는지 체크해서 Attach 를 수행한다. */
    sRC = CheckShmAttach ( aSegmentNo ) ;
    if ( sRC != 0 )
    {
        DBM_ERR( "Attaching [%d] Segment failed : rc=%d, (err=%d,tid=%d)", aSegmentNo, sRC, errno, gettid_s() );
        return( ERR_DBM_INVALID_SHM_OPER_FAIL );
    }


    /** Header 값을 세팅 **/
    sHeader = (dbmSegmentHeader*) mStartAddress[aSegmentNo];

    /*** 현재 Slot Segment 의 주소를 얻어낸다. **/
    if ( aSegmentNo == 0 )
    {
        sAlloc = (long long*) ( mStartAddress[aSegmentNo] + sizeof(dbmSegmentHeader) + mUserHeaderSize );
    }
    else
    {
        sAlloc = (long long*) ( mStartAddress[aSegmentNo] + sizeof(dbmSegmentHeader) );
    }

    /* 현재 가용한 공간이 존재하는지에 대해서 파악을 하자.
     * 만약 Header의 Alloc 과 Free 가 같다면 이건 꽉 찬거다 */

//  _IF_THROW( mvpAtomicGet64 ( &sHeader->mAlloc ) > mvpAtomicGet64 ( &sHeader->mFree ), ERR_DBM_NO_SPACE );

    while ( true )
    {
        sSlotNo = mvpAtomicGet64 ( &sHeader->mAlloc );      // 죽는다 (2)
        sInd    = sSlotNo % ( aSlotCount + 1 ) ;            //TODO:

        /*** Full 난 상황이라고 가정 하자 */
        if ( sAlloc[sInd] == -1 )
        {
            if ( sSlotNo == mvpAtomicGet64 ( &sHeader->mAlloc ) )
            {
                return( ERR_DBM_NO_SPACE );
            }
            else
            {
                continue;
            }
        }

        /* 성공  **/
        if ( sSlotNo == mvpAtomicCas64 ( &sHeader->mAlloc, sSlotNo + 1, sSlotNo ) )
        {
            *aReturnSlot = sAlloc[sInd] ;
            sAlloc[sInd] = -1;

            return 0;
        }
        /* 실패 언넘이 끼어들어따  */
        else
        {
            continue;
        }
    }

    return 0;
}


/**
 *  Slot 번호를 통해 해당 Slot 의 Segment No 를 찾아낸다.
 */
int dbmSegmentManager::FindSegmentFromSlot ( long long aSlot )
{
    long long sDiff = ( aSlot - mHeader->mInitSlotCount );

    if ( sDiff < 0 )
    {
        return 0;
    }

#if 0
    int sSegmentNo = 1;

    // 나누기가 느리다고 하니깐. 한개 확장까지는 좀 버티어 보자. --;;
    if ( ( aSlot - mHeader->mInitSlotCount ) >= mHeader->mExtendSlotCount )
    {
        /* 아 젠장 나누면 되더라 .... */
        sSegmentNo = ( aSlot - mHeader->mInitSlotCount ) / mHeader->mExtendSlotCount + 1;
    }

    return sSegmentNo;
#else
    //[성능함수] 2014.11.21 -okt- mExtendSlotPower 변수를 추가하여, 나누기 연산 제거.
    return ( sDiff >> mHeader->mExtendSlotPower ) + 1;
#endif
}


/**
* Description
*
* 해당 Slot 을 사용가능한 상태로 만들어놓는다.
*
* Argument
*   @aSlot             : aSlot  번호
*   @aLogHandle        : Logging 할  Handle 주소
*
* Return
*    0 이면 성공, 그외에는 모두 실패
*
*    자세한 에러로그는  전달한 aLogHandle 에 기록한다.
*
*/
#ifdef DBM_SLOT_TRACE
_VOID dbmSegmentManager::FreeSlot ( long long aSlot, int aCheckFlag, const char* aFile, const char* aFunc, int aLine )
#else
_VOID dbmSegmentManager::FreeSlot ( long long aSlot, int aCheckFlag )
#endif
{
    long long sSlotCount;
    int     sSegmentNo;

    _TRY
    {
#ifdef DBM_SLOT_TRACE
        // 중복 free 검사.
        if ( mSlotTraceMap != NULL )
        {
            static int  sDupCnt = 0;
            char*       pVal = (char*)mSlotTraceMap->mFind( this->mObjectName, &aSlot ); // 유발.

            if ( pVal != NULL )
            {
                if ( aCheckFlag == 0 )
                {
                    DBM_ERR ( "[FATAL] double free detected. [Slot,%d,PRE,%s,NEW,%s:%d]", aSlot, pVal, aFile, aLine );

                    //mSlotTraceMap->mPrint();  // 디버그 용도로만 사용한다. 다 출력하기엔 수십만건이 될 수 있다.
                    _DASSERT( 0 ); // 당함.
                }
                else
                {
                    sDupCnt++;
                    if ( sDupCnt < 4 || sDupCnt % 10000 == 0 )
                    {
                        // Flag = 1 인 경우는 죽지안고 다음으로 넘긴다.
                        DBM_WARN ( "double free detected. but ignore [Slot,%d,PRE,%s,NEW,%s:%d]", aSlot, pVal, aFile, aLine );
                    }

                    _THROW( ERR_DBM_DOUBLE_FREE_SLOT );
                }
            }
        }

        /*
         * free slot 등록.
         * 개념적으로는 FreeSlot이 성공하고 등록을 해야하지만. FreeSlot 성공후, Map에 등록하기 전에 다른 쓰레드가 Alloc - Free 할 수 있다.
         * 때문에, 사전에 등록한다. ( FreeSlot은 반드시 성공하고 리턴될 것이므로 )
         */
        if ( mEnvCheckFlag == 1 && aCheckFlag == 0 && mSlotTraceMap != NULL )
        {
            char    buf[64];
            char*   sFile = strrchr ( (char*)aFile, '/' );

            if ( sFile == NULL )
                sFile = (char*) aFile;
            else
                sFile++;
            snprintf ( buf, sizeof(buf), "%s:%d,%d", sFile, aLine, gettid_s() );     // 필요하다면 aFunc, aSlot 함께 기록, 단 64Byte.

            _CALL( mSlotTraceMap->mInsert( this->mObjectName, &aSlot, buf ) );
        }
#endif


        sSegmentNo = FindSegmentFromSlot (aSlot);

        sSlotCount = sSegmentNo == 0 ? mHeader->mInitSlotCount : mHeader->mExtendSlotCount ;
        _CALL( FreeSlot ( sSegmentNo, sSlotCount, aSlot, aCheckFlag ) );
    }
    _CATCH
    {
        // 내부함수에서 잘찍었다. 중복해서 찍지 아니한다.
        //_CATCH_ERR;
    }
    _FINALLY
    _END
}

/*
 *
 * 주어진 Segment 번호를 Free 한다.
 *
 */
_VOID dbmSegmentManager::FreeSlot ( int aSegmentNo , long long aSlotCount , long long aSlotNo , int aCheckFlag )
{
    dbmSegmentHeader* sHeader ;
    long long sSlotNo;
    long long sInd;
    long long sTmp;
    long long*   sFree;
    //int   sFreeInd;
    int     i ;

    _TRY
    {
        /** 해당 aSegmentNo 에 Attach가 되어있는지에 대해 확인 */
        _CALL( CheckShmAttach ( aSegmentNo ) );

        /** Header 값을 세팅 **/
        sHeader = (dbmSegmentHeader*) mStartAddress[aSegmentNo ] ;

        /* sFree 는 첫번째를 가르킨다 **/
        if ( aSegmentNo != 0 )
        {
            sFree = (long long*) (mStartAddress[aSegmentNo] + sizeof(dbmSegmentHeader) ) ;
        }
        else
        {
            sFree = (long long*) (mStartAddress[aSegmentNo] + mHeader->mUserHeaderSize + sizeof(dbmSegmentHeader) ) ;
        }


        /*********************************************************************
         *
         * Double free 를 체크한다.
         * 가장 단순하게  Slot Area 를 전체 싹 훑겠다.
         *
         * 사실 가장 깔끔한 구현방법은, Free Allocator 시작 시점 부터 aSlotCount 만큼만
         * 훑는 거지만, Concurrency 문제가 존재하기 때문에 걍 가장 간단하게 간다.
         *
         * *******************************************************************/
        //if ( aCheckFlag == 1 && mEnvCheckFlag == 0 )  // mEnvCheckFlag = 1 인 경우는 상위단에서 DblFree 체크를 이미 했다.
        if ( aCheckFlag == 1 )
        {
            for ( i = 0; i < ( aSlotCount + 1 ); i++ )
            {
                if ( sFree[i] == aSlotNo )
                {
                    DBM_ERR( "[FATAL] double free detected. i=%d, [H,%d,%d,S,%d,%d,%d] (tid=%d)",
                             i, sHeader->mFree, sHeader->mAlloc, sFree[0], sFree[i], sFree[aSlotCount], gettid_s() );

                    _THROW( ERR_DBM_DOUBLE_FREE_SLOT );
                }
            }
        }


        while ( true )
        {
            sSlotNo = mvpAtomicGet64 ( &sHeader->mFree );
            sInd    = sSlotNo % ( aSlotCount + 1  ) ;
            sTmp    = sSlotNo + 1;

            /*** 내가 이번에 본 Slot 이 Empty 인지 검사   */
            if ( sFree[sInd] != -1 )
            {
                if ( sSlotNo == mvpAtomicGet64 ( &sHeader->mFree ) )
                {
                    /** 이 상황은 Alloc  보다 Free 가 더 많이 일어났다는 것을 의미한다.
                     * 이경우는 완전히 릴리즈 될때까지 다른 모듈의 문제점을 빨리 찾기 위해서
                     * 죽이는게 깔끔하다 */

                    //assert ( 0 &&  "Free 가 너무 많다 !!@!" ) ;
                    /***************************************************************
                     * 원래는 여기서 걍 죽도록 되어있었는데, 그냥 죽으니까 곤란하다.
                     * 위 assert 는 정상적인 상황에서도 발생할 수 있다. 다음과 같이 바꾼다.
                     ****************************************************************/

                    assert( sHeader->mFree - sHeader->mAlloc > 0 && "Free 를 너무 많이 했따. " );

                    // 2014.12.14. -okt- 탐지로직 자체가 오탐이 있을수 있다. 때문에 RELEASE에서는 절대 돌리면 안된다.
                    // 2014.12.14. -okt-[queue6] timeout 이 발생하는 경우 있음... 여기 코드는 막는다. ( 2014/07/06 )
                    //            _DBM_SEGMGR_DBLFREE_CHECK=1 환경변수로만 이제 dup free 탐지가능.
#if 0 // defined(DBM_SLOT_TRACE) && defined(_DEBUG)
                    /*
                     * 여기에 진입한 것은 정상적이지 않을 수 있으므로 (무한루핑) Flag 값이 없어도 검사를 해본다.
                     * (gdb) p *sFree@48
                     * $10 = {0, 2, 3,  4, 4, 5, 6, 7, 9, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42,
  43, 44, 45, 45, 46}
                     */
                    {
                        int sFind = 0;
                        int sFindDup = 0;

                        DBM_DBG( "Start, check double free or not. aSlotNo=%d,%d", aSlotNo, aSlotCount );
retry:
                        for ( i = 0; i < ( aSlotCount - 1 ); i++ )
                        {
                            // sFree[i] == sFree[i+1] 조건도 오탐이 있을 수 있으나. 거의 가능성이 없다.
                            if ( sFree[i] != -1 && ( sFree[i] == aSlotNo || sFree[i] == sFree[i+1] ) )
                            {
                                // [FATAL] double free detected. i=40, My=0 [H,170,41,S,2,0,41] (tid=28220)
                                DBM_ERR( "[FATAL] double free detected. i=%d, My=%d [H,%d,%d,S,%d,%d,%d] (tid=%d)",
                                         i, aSlotNo,
                                         sHeader->mFree, sHeader->mAlloc,
                                         sFree[0], sFree[i], sFree[i+1], gettid_s() );

                                // 위에서 DUP 검사할때는 통과하고, 나중에 걸릴수도 있다.
                                if ( aCheckFlag == 0 )
                                {
                                    _DASSERT( 0 );
                                }
                                _THROW( ERR_DBM_DOUBLE_FREE_SLOT );
                            }
                            // 반납할 비어있는 공간이 있는지 검사.
                            else if ( sFree[i] == -1 )
                            {
                                sFind = 1;
                            }
                        }

                        // 루프를 스캔하여 읽고 있는 도중에 락을 잡은 구간이 아니어서 오탐이 될 수 있다.
                        if ( sFind == 0 )
                        {
                            sFindDup++;
//                          if ( sFindDup == 3 )
                            if ( sFindDup == 2 )
                            {
                                DBM_WARN( "[FATAL] double free not sure but no empty slot possible. re-check. i=%d, My=%d [H,%d,%d,S,%d,%d] (tid=%d)",
                                         i, aSlotNo, sHeader->mFree, sHeader->mAlloc, sFree[0], sFree[aSlotCount], gettid_s() );
                                if ( aCheckFlag == 0 )
                                {
                                    DBM_ERR( "[FATAL] double free not found but no empty slot. abort.. i=%d, My=%d [H,%d,%d,S,%d,%d] (tid=%d)",
                                             i, aSlotNo, sHeader->mFree, sHeader->mAlloc, sFree[0], sFree[aSlotCount], gettid_s() );
                                    _DASSERT( 0 );
                                }
                                _THROW( ERR_DBM_DOUBLE_FREE_SLOT );
                            }
                            else
                            {
                                goto retry;
                            }
                        }
                        DBM_TRC( "  End, check double free or not. aSlotNo=%d,%d", aSlotNo, i );
                    }
#endif

                    pthread_yield_s( );
                    continue;
                }
                else
                {
                    /** 다른 Thread가 헤더 값을 바꿨으니 이 경우인지 다시 체크 */
                    continue;
                }
            }

            /* 성공  **/
            if ( sSlotNo == mvpAtomicCas64 ( &sHeader->mFree, sTmp, sSlotNo ) )
            {
                sFree[sInd] = aSlotNo;
                _RETURN;

            }
            /* 실패 언넘이 끼어들어따  */
            else
            {
                continue;
            }
        }
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_DOUBLE_FREE_SLOT )
        {
            _CATCH_ERR;
        }
        else
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* FreeSlot */


/* 현재 Segment 의 Global Lock 을 획득한다. */
_VOID dbmSegmentManager::dbmLockSegment ( )
{
    int     tid;
    int     sLock;

    _TRY
    {
RETRY:
        tid = gettid_s ( );
        _rc = dbmLockManager::mAtomicLockTry ( (char*) &mHeader->mLock, tid, -1 );

        /* Lock 을 획득하지 못한 경우라면 다시 한번 체크하여 본다 */
        if ( _rc != 0 )
        {
            sLock = mHeader->mLock;
            _rc = tkill_s ( sLock, 0 );
            /* 어떤 놈이 잡고 죽은거 같다  */
            if ( _rc == -1 && errno == ESRCH )
            {
                //DBM_INFO( "Try to check tid [%d]  but changes tid [%d] \n", mHeader->mLock, tid ) ;

                /* Lock 변수를 내껄로 바꿔버린다 */
                // 여기서 CAS를 사용하지 않으면, UnLock 하러 들어갔는데. 다른 TaskID인 경우가 발생한다.
                //mHeader->mLock = tid;
                if ( mvpAtomicCas32 ( &mHeader->mLock, tid, sLock ) == sLock )
                {
                    _RETURN;
                }
                else
                {
                    pthread_yield_s();
                    goto RETRY;
                }
            }
            else
            {
                //DBM_INFO( "Locking with tid [%d] but already locked by [%d] \n", tid, mHeader->mLock ) ;
                _THROW( RC_FAILURE );
            }

        }
    }
    _CATCH
    {
        //정상적으로 락을 못잡는 것은 많다. 오류 출력하면 안됨.
        //_CATCH_ERR;
    }
    _FINALLY
    _END
}


// 전체 Segment Lock 을 풀어준다.
_VOID dbmSegmentManager::dbmUnlockSegment ()
{
    int     tid;

    _TRY
    {
        tid = gettid_s();

        /* UnLock 은 Lock 의 Owner 만 수행할 수 있따. */
        _rc = dbmLockManager::mAtomicLockTry ( (char*) &mHeader->mLock, -1, tid );

        /* 일단 여기에 죽는 코드를 넣어놓자  졸라 크리티컬한 상황이삼 */
        if ( _rc != 0 ) // CRITICAL_ERROR;
        {
            DBM_ERR( "[FATAL] Current TID [%d] but Lock header holds [%d]", tid , mHeader->mLock );
            _DASSERT( 0 );
        }
    }
    _CATCH
    {
        // 도달하지 않는 코드
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/* list drop :
 * list drop은 segment가 하나씩 증가가 아닌 LEFT RIGHT 따라 segment 처음과
 * 끝을 각각 사용 할 수 있으므로 따로 처리 한다 */
_VOID dbmSegmentManager::DropList()
{
    char    sFileName[MAX_SEGMENT_NAME_LENGTH];
    size_t  sSize;
    long long sSlotCount;
    int     i;
    char*   pAddr = NULL;

    _TRY
    {
        for( i = 0; i < MAX_SEGMENT_COUNT; i++ )
        {
            if( mHeader->mSegmentAlloc[i] != -1 )
            {
                _CALL( this->ListCheckShmAttach( i ) );
            }
        }

        /* Share memory 를 Detach 를 수행하고, 날린다 */
        for( i = ( MAX_SEGMENT_COUNT - 1 ); i >= 0; i-- )
        {
            if( mHeader->mSegmentAlloc[i] != -1 )
            {
                getFileName ( mInstName, mHeader->mSegmentName, i, sFileName );
                sSlotCount = i == 0 ? mHeader->mInitSlotCount : mHeader->mExtendSlotCount;

                if ( i == 0 )
                {
                    sSize = sSlotCount * mHeader->mSlotSize + sizeof(dbmSegmentHeader)
                            + sizeof(long long) * ( sSlotCount + 1 ) + mHeader->mUserHeaderSize;
                }
                else
                {
                    sSize = sSlotCount * mHeader->mSlotSize + sizeof(dbmSegmentHeader) + sizeof(long long) * ( sSlotCount + 1 );
                }

                _CALL( cmnShmDetach ( (void**)&mStartAddress[i], sSize ) );

                /** Detach 를 수행했으니 날린다 **/
                _IF_THROW( cmnShmDrop ( sFileName ), ERR_DBM_DROP_SHM_FAIL );
            }
        }
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_DROP_SHM_FAIL && errno == ENOENT )
        {
            _CATCH_DBG2(sFileName);
        }
        else
        {
            _CATCH_ERR2(sFileName);
        }
    }
    _FINALLY
    _END
}


/**
* Description
*
*  해당 Shared Memory 를 DROP 를 수행한다.
*  전체 Shared Memory Segment 를 날려버리겠다.
*
* Argument
*   @aObjectName       : 할당할 Object 의 번호
*   @aLogHandle        : Logging 할  Handle 주소
*
* Return
*    0 이면 성공, 그외에는 모두 실패
*
*    자세한 에러로그는  전달한 aLogHandle 에 기록한다.
*
*/
_VOID dbmSegmentManager::Drop ( )
{
    char    sFileName[MAX_SEGMENT_NAME_LENGTH];
    size_t  sSize;
    long long sSlotCount;
    int     i;
    char*   pAddr = NULL;

    _TRY
    {
        for ( i = 0; i < mHeader->mSegmentCount; i++ )
        {
            _CALL( this->CheckShmAttach ( i ) );
        }

        /* Share memory 를 Detach 를 수행하고, 날린다 */
        for ( i = ( mHeader->mSegmentCount - 1 ); i >= 0; i-- )
        {

            getFileName ( mInstName, mHeader->mSegmentName, i, sFileName );
            sSlotCount = i == 0 ? mHeader->mInitSlotCount : mHeader->mExtendSlotCount;

            if ( i == 0 )
            {
                sSize = sSlotCount * mHeader->mSlotSize + sizeof(dbmSegmentHeader)
                        + sizeof(long long) * ( sSlotCount + 1 ) + mHeader->mUserHeaderSize;
            }
            else
            {
                sSize = sSlotCount * mHeader->mSlotSize + sizeof(dbmSegmentHeader) + sizeof(long long) * ( sSlotCount + 1 );
            }

            _CALL( cmnShmDetach ( (void**)&mStartAddress[i], sSize ) );

            /** Detach 를 수행했으니 날린다 **/
            _IF_THROW( cmnShmDrop ( sFileName ), ERR_DBM_DROP_SHM_FAIL );
        }
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_DROP_SHM_FAIL && errno == ENOENT )
        {
            _CATCH_DBG2(sFileName);
        }
        else
        {
            _CATCH_ERR2(sFileName);
        }
    }
    _FINALLY
    _END
}


/**
 * Description
 *
 *  해당 Shared Memory 를 Detach 를 수행한다.
 *
 * Argument
 *   @aLogHandle        : Logging 할  Handle 주소
 *
 * Return
 *    0 이면 성공, 그외에는 모두 실패
 *
 *    자세한 에러로그는  전달한 aLogHandle 에 기록한다.
 *
 */
_VOID dbmSegmentManager::Detach()
{
    char    sFileName[MAX_SEGMENT_NAME_LENGTH];
    size_t  sSize;
    long long sSlotCount;
    int     i;
    char*   pAddr = NULL;

    _TRY
    {
        for ( i = 0; i < mHeader->mSegmentCount; i++ )
        {
            _CALL( this->CheckShmAttach ( i ) );
        }

        /* Share memory 를 Detach 를 수행하고, 날린다 */
        for ( i = ( mHeader->mSegmentCount - 1 ); i >= 0; i-- )
        {

            getFileName ( mInstName, mHeader->mSegmentName, i, sFileName );
            sSlotCount = i == 0 ? mHeader->mInitSlotCount : mHeader->mExtendSlotCount;

            if ( i == 0 )
            {
                sSize = sSlotCount * mHeader->mSlotSize + sizeof(dbmSegmentHeader)
                        + sizeof(long long) * ( sSlotCount + 1 ) + mHeader->mUserHeaderSize;
            }
            else
            {
                sSize = sSlotCount * mHeader->mSlotSize + sizeof(dbmSegmentHeader) + sizeof(long long) * ( sSlotCount + 1 );
            }

            _CALL( cmnShmDetach ( (void**)mStartAddress[i], sSize ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/**
 * Description
 *
 *  Slot 번호를 받아서 해당 주소로 변환한다.
 *  이주소는 형변환이 꼭 필요하기 때문에 void * 로 리턴한다.
 * Argument
 *   @aSlot             : aSlot  번호
 *   @aLogHandle        : Logging 할  Handle 주소
 *
 * Return
 *    NULL 이면 변환 실패  , 그 외에는 잘된것으로 본다.
 *    자세한 에러로그는  전달한 aLogHandle 에 기록한다.
 *
 */
_VOID dbmSegmentManager::ListSlot2Addr ( long long aSlotID , void* aReturnPtr /* [주의] void** 의미임 */ )
{
    int     sSegmentNo = 0 ;
    long long sPos ;
    char*   sSlotPtr ;

    _TRY
    {
        /* 만약 사용자가 엉뚱한 aSlotID 를 줬다고 하자. 그럼  CheckShmAttach가 실패할꺼고,
         * 결국 NULL 이 리턴된다. 즉 인자값 검사는 안해도 상관 없을 것 같다 */

        _DASSERT ( aSlotID >= 0 ) ;

        if ( aSlotID >= mHeader->mInitSlotCount )
        {
            sSegmentNo = FindSegmentFromSlot ( aSlotID ) ;
        }

        if (  mStartAddress[sSegmentNo] == NULL )
        {
            _rc = ListCheckShmAttach ( sSegmentNo );
            if ( unlikely( _rc != 0 ) )
            {
                DBM_INFO("error aSlotID=%ld, sSegmentNo=%d, rc=%d (err=%d,tid=%d)\n"
                        , aSlotID, sSegmentNo, _rc, errno, gettid_s() );

                /*
                 * TOOD (OKT): 사용하는 곳에서 type-casting 없이 사용하도록 void** 의미인데, void*로 선언함.
                 */
                *(void**)aReturnPtr = NULL ;
                _THROW( ERR_DBM_ATTACH_SHM_FAIL );
            }
        }

        if ( sSegmentNo == 0 )
        {
            sSlotPtr = mStartAddress[0] + sizeof(dbmSegmentHeader) + mUserHeaderSize
                     + ( aSlotID * mHeader->mSlotSize )
                     + ( ( mHeader->mInitSlotCount + 1 ) << 3 );
            *(void**)aReturnPtr = sSlotPtr;
        }
        else
        {
            sPos = aSlotID - ( mHeader->mExtendSlotCount * ( sSegmentNo - 1 ) + mHeader->mInitSlotCount );
            sSlotPtr = mStartAddress[sSegmentNo] + sizeof(dbmSegmentHeader)
                    + sizeof(long long) * ( mHeader->mExtendSlotCount + 1 );
            sSlotPtr += mHeader->mSlotSize * sPos;
            *(void**)aReturnPtr = sSlotPtr;
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}



/**
 * Description
 *
 *  Slot 번호를 받아서 해당 주소로 변환한다.
 *
 * Argument
 *   @aSlot             : aSlot  번호
 *   @aLogHandle        : Logging 할  Handle 주소
 *
 */
// (성능) Top3 함수임. 주의요망.
//        _TRY .. _CATCH를 성능구간이어서 사용안함.
_VOID dbmSegmentManager::Slot2Addr ( long long aSlotID , void* aReturnPtr /* [주의] void** 의미임 */ )
{
    long long sPos ;
    char*   sSlotPtr ;
    int     sSegmentNo = 0 ;
    int     sRC;

    /* 만약 사용자가 엉뚱한 aSlotID 를 줬다고 하자. 그럼  CheckShmAttach가 실패할꺼고,
     * 결국 NULL 이 리턴된다. 즉 인자값 검사는 안해도 상관 없을 것 같다 */
#ifdef _DEBUG
    // queue6.out ( 2014/06/10 )
    if ( aSlotID < 0 )
    {
        DBM_ERR( "[FATAL] aSlotID=%d", aSlotID );
    }
#endif
    _DASSERT ( aSlotID >= 0 ) ;

    // 2014.12.14. -okt- (성능) 함수진입도 가급적 안한다.
    if ( aSlotID >= mHeader->mInitSlotCount )
    {
        sSegmentNo = FindSegmentFromSlot ( aSlotID ) ;
    }

    // 2014.12.14. -okt- (성능) 함수진입도 가급적 안한다.
    if (  mStartAddress[sSegmentNo] == NULL )
    {
        sRC = CheckShmAttach ( sSegmentNo );
        if ( unlikely( sRC != 0 ) )
        {
            DBM_INFO("error aSlotID=%ld, sSegmentNo=%d, rc=%d (err=%d,tid=%d)\n"
                    , aSlotID, sSegmentNo, sRC, errno, gettid_s() );

            // 2014.12.14. -okt- 사용하는 곳에서 type-casting 없이 사용하도록 void** 의미인데, void*로 선언함.
            *(void**)aReturnPtr = NULL ;
            return( ERR_DBM_ATTACH_SHM_FAIL );
        }
    }

    /*** 해당의 주소에서 해당 Slot 의 주소값을 계산 */
    if ( sSegmentNo == 0 )
    {
#if 0
        sSlotPtr = mStartAddress[0] + sizeof(dbmSegmentHeader) + mUserHeaderSize
                 + ( mHeader->mInitSlotCount + 1 ) * sizeof(long long);
        sSlotPtr += aSlotID * mHeader->mSlotSize;
#else
        sSlotPtr = mStartAddress[0] + sizeof(dbmSegmentHeader) + mUserHeaderSize
                 + ( aSlotID * mHeader->mSlotSize )
                 + ( ( mHeader->mInitSlotCount + 1 ) << 3 );
#endif
        *(void**)aReturnPtr = sSlotPtr;
    }
    else
    {
        sPos = aSlotID - ( mHeader->mExtendSlotCount * ( sSegmentNo - 1 ) + mHeader->mInitSlotCount );
        sSlotPtr = mStartAddress[sSegmentNo] + sizeof(dbmSegmentHeader)
                 + sizeof(long long) * ( mHeader->mExtendSlotCount + 1 );
        sSlotPtr += mHeader->mSlotSize * sPos;
        *(void**)aReturnPtr = sSlotPtr;
        //DBM_INFO("Try to Find Segment[%d] absPos[%ld] input [%ld]\n", sSegmentNo, sPos, aSlotID ) ;
    }

    return 0;
} /* Slot2Addr */


/**
* Description
*
*  이름을 통해 현재 존재하는 Shared Memory 를 삭제한다.
*
* Argument
*   @aObjectName      : 해당 Object 의 이름
*   @aLogHandle       : Logging 용 Log handle
**
* Return
*    0 이면 Success
*    그외이면 모두 Fail.
*
*    자세한 에러로그는  전달한 aLogHandle 에 기록한다.
*
*/
_VOID dbmSegmentManager::Drop ( char* aInstName, char* aObjectName )
{
    dbmSegmentManager* sObj = NULL;

    _TRY
    {
        _CALL( dbmSegmentManager::Attach ( aInstName, aObjectName, &sObj ) );
        _CALL( sObj->Drop ( ) );

        delete_s ( sObj );
    }
    _CATCH
    {
        _CATCH_WARN2( aObjectName );
    }
    _FINALLY
    _END
}


/*
 * 특정 Object 의 이름을 받아 dbmSpaceStat 형의 결과를 반환
 * 하는데 대충 비슷하게 보여주는 것으로 알면 된다.
 */
_VOID dbmSegmentManager::GetSpaceStat ( char* aInstName, char* aObjectName , dbmSpaceStat* aReturnStat )
{

    int     sCount;
    int     i = 0;
    char    sFileName[MAX_SEGMENT_NAME_LENGTH] ;
    long long sSlotSize;
    long long sTotalSlot = 0;
    long long sUsedSlot = 0;
    long long sFreeSlot = 0;
    dbmSegmentHeader* sHeader[MAX_SEGMENT_COUNT] ;

    _TRY
    {
        /* 0 번 헤더를 얻어낸다 */
        dbmSegmentManager::getFileName ( aInstName, aObjectName, i, sFileName );
        _rc = cmnShmAttach ( sFileName, sizeof(dbmSegmentHeader), (void**) &sHeader[0] );
        _IF_THROW( _rc, ERR_DBM_ATTACH_SHM_FAIL );

        /* 0번 Header 정보를 통해 다른 정보들을 같이 얻어낸다 */

        sCount = sHeader[0]->mSegmentCount;

        for ( i = 1; i < sCount; i++ )
        {
            dbmSegmentManager::getFileName ( aInstName, aObjectName, i, sFileName );
            _rc = cmnShmAttach ( sFileName, sizeof(dbmSegmentHeader), (void**) &sHeader[i] );
            _IF_THROW( _rc, ERR_DBM_ATTACH_SHM_FAIL );
        }


        /** Free Alloc Total 을 계산한다  */
        for ( i = 0; i < sCount; i++ )
        {
            sSlotSize = ( i == 0 ? sHeader[0]->mInitSlotCount : sHeader[0]->mExtendSlotCount );
            sTotalSlot += sSlotSize;
            sFreeSlot += sHeader[i]->mFree - sHeader[i]->mAlloc;
            sUsedSlot += ( sSlotSize - ( sHeader[i]->mFree - sHeader[i]->mAlloc ) );
        }

        /** 계산이 모두 끝났으면 붙여놨던 메모리를 Release 해준다 */

        for ( i = sCount - 1; i >= 0; i-- )
        {
            _rc = cmnShmDetach ( (void**)&sHeader[i], sizeof(dbmSegmentHeader) );
            _IF_THROW( _rc, ERR_DBM_DETACH_SHM_FAIL );
        }

        /*** Detach 가 모두 완료되면 구조체에 값을 넣어준다. */
        aReturnStat->mTotalSlot = sTotalSlot;
        aReturnStat->mAllocSlot = sUsedSlot;
        aReturnStat->mFreeSlot = sFreeSlot;
        aReturnStat->mSegmentCount = sCount;
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_ATTACH_SHM_FAIL )
        {
            DBM_ERR( " Can not Attach [%s] with Size [%d] . RC [%d] errno [%d] \n",
                     sFileName,
                     sizeof(dbmSegmentHeader) ,
                     _rc,
                     errno ) ;
        }
        else if ( _rc == ERR_DBM_DETACH_SHM_FAIL )
        {
            DBM_ERR( " Can not Detach [%i] with Size [%d] . RC [%d] errno [%d] \n",
                     i,
                     sizeof(dbmSegmentHeader) ,
                     _rc,
                     errno ) ;
        }

        _CATCH_ERR;
    }
    _FINALLY
    _END
}

/*
 * 특정 Object 의 이름을 받아 dbmListSpaceStat 형의 결과를 반환
 * 하는데 대충 비슷하게 보여주는 것으로 알면 된다.
 */
_VOID dbmSegmentManager::GetListSpaceStat ( char* aInstName, char* aObjectName , dbmSpaceStat* aReturnStat )
{
    int     sCount;
    int     i = 0;
    char    sFileName[MAX_SEGMENT_NAME_LENGTH] ;
    long long sSlotSize;
    long long sTotalSlot = 0;
    long long sUsedSlot = 0;
    long long sFreeSlot = 0;
    dbmSegmentHeader* sHeader[MAX_SEGMENT_COUNT] ;

    _TRY
    {
        /* 0 번 헤더를 얻어낸다 */
        dbmSegmentManager::getFileName ( aInstName, aObjectName, i, sFileName );
        _rc = cmnShmAttach ( sFileName, sizeof(dbmSegmentHeader), (void**) &sHeader[0] );
        _IF_THROW( _rc, ERR_DBM_ATTACH_SHM_FAIL );

        /* 0번 Header 정보를 통해 다른 정보들을 같이 얻어낸다 */

        sCount = sHeader[0]->mSegmentCount;

        for( i = 1; i < MAX_SEGMENT_COUNT; i++ )
        {
            if( sHeader[0]->mSegmentAlloc[i] != -1 )
            {
                dbmSegmentManager::getFileName ( aInstName, aObjectName, sHeader[0]->mSegmentAlloc[i] , sFileName );
                _rc = cmnShmAttach ( sFileName, sizeof(dbmSegmentHeader), (void**) &sHeader[i] );
                _IF_THROW( _rc, ERR_DBM_ATTACH_SHM_FAIL );
            }
        }


        /** Free Alloc Total 을 계산한다  */
        for( i = 0; i < MAX_SEGMENT_COUNT; i++ )
        {
            if( sHeader[0]->mSegmentAlloc[i] != -1 )
            {
                sSlotSize = ( i == 0 ? sHeader[i]->mInitSlotCount : sHeader[i]->mExtendSlotCount );
                sTotalSlot += sSlotSize;
                sFreeSlot += sHeader[i]->mFree - sHeader[i]->mAlloc;
                sUsedSlot += ( sSlotSize - ( sHeader[i]->mFree - sHeader[i]->mAlloc ) );
            }
        }

        /* 미구현 :
           아직 미구현 어떻게 해야 할까...
           slot Alloc 및 free 따로 하지 않끼 때문에 해당 값을 가지고 있지 않다.....
           Alloc 할때마다 해당 값을 set을 하면 엄청 느려 질 텐데 그러면 사용해야 하는 이유가
           없어지고 일단 해볼까... */

        /** 계산이 모두 끝났으면 붙여놨던 메모리를 Release 해준다 */
        for( i = 0; i < MAX_SEGMENT_COUNT; i++ )
        {
            if( sHeader[0]->mSegmentAlloc[i] != -1 )
            {
                _rc = cmnShmDetach ( (void**)&sHeader[i], sizeof(dbmSegmentHeader) );
                _IF_THROW( _rc, ERR_DBM_DETACH_SHM_FAIL );
            }
        }

        /*** Detach 가 모두 완료되면 구조체에 값을 넣어준다. */
        aReturnStat->mTotalSlot = sTotalSlot;
        aReturnStat->mAllocSlot = sUsedSlot;
        aReturnStat->mFreeSlot = sFreeSlot;
        aReturnStat->mSegmentCount = sCount;
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_ATTACH_SHM_FAIL )
        {
            DBM_ERR( " Can not Attach [%s] with Size [%d] . RC [%d] errno [%d] \n",
                     sFileName,
                     sizeof(dbmSegmentHeader) ,
                     _rc,
                     errno ) ;
        }
        else if ( _rc == ERR_DBM_DETACH_SHM_FAIL )
        {
            DBM_ERR( " Can not Detach [%i] with Size [%d] . RC [%d] errno [%d] \n",
                     i,
                     sizeof(dbmSegmentHeader) ,
                     _rc,
                     errno ) ;
        }

        _CATCH_ERR;
    }
    _FINALLY
    _END
}

_VOID dbmSegmentManager::AllocExtend( int aSegmentNo )
{

    _TRY
    {
        do
        {
            _rc = dbmLockSegment();
            if( _rc == RC_SUCCESS )
            {
                _CALL( ExtendUntilSuccess( aSegmentNo ) );
                _RETURN;
            }
            else
            {
                if( mHeader->mLock == -1 )
                {
                    _RETURN;
                }
            }

        } while( true );

    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        if ( mHeader->mLock == gettid_s() )
        {
            dbmUnlockSegment ( );
        }
    }
    _END

}


_VOID dbmSegmentManager::Extend ( )
{
    _TRY
    {
        do
        {
            _rc = dbmLockSegment ( );
            if ( _rc == RC_SUCCESS )
            {
                _CALL( ExtendUntilSuccess ( mHeader->mNextExtendNo ) );
                //dbmUnlockSegment ( );
                _RETURN;
            }
            else
            {
                if ( mHeader->mLock == -1 )
                {
                    // 누군가가 락을 잡고 작업을 했다. 그냥 성공으로 나간다.
                    _RETURN;
                }
                else
                {
                    cmnUSleep(30);
                    if ( mHeader->mLock == -1 )
                    {
                        _RETURN;
                    }
                    else
                    {
                        cmnUSleep(100);
                        if ( mHeader->mLock == -1 )
                        {
                            _RETURN;
                        }
                    }
                }
            }
        }
        while ( true );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        if ( mHeader->mLock == gettid_s() )
        {
            dbmUnlockSegment ( );
        }
    }
    _END
}


long long dbmSegmentManager::GetLastExtendSlotNo ( )
{
    return ( mHeader->mInitSlotCount + mHeader->mExtendSlotCount * ( mHeader->mSegmentCount - 1 ) ) - 1;
}


long long dbmSegmentManager::GetUsageExtendSlotNo( long long aAllocSlot )
{

    /* AllocSlot은 0부터 시작하기 때문에 아래의 공식에서는 개수로 처리 하므로 +1를 해주어
     * 공식 처리를 한다 */
    aAllocSlot++;

    /* 여기에서 +1의 의미는 해당 segment 0에서부터 시작을 하기 때문에 +1을 하여 segment total에서 -1을 해주기 때문이다
     * xampel : 10이라고 했을 경우 결국 9번째 segment 이다 */
    return mHeader->mExtendSlotCount - ( ( ( mHeader->mMaxSlotCount - aAllocSlot ) / mHeader->mInitSlotCount ) + 1 );
}

/******************************************************************************
 *
 * LIST Truncate 를 하기 위해서 다음과 같이 진행한다.
 *
 *****************************************************************************/
_VOID dbmSegmentManager::TruncateList ( )
{
    char    sFileName [ MAX_SEGMENT_NAME_LENGTH ] ;
    size_t  sSize;
    long long sSlotCount;
    long long*   sStartSlot;

    char*   sDataAddress;
    int     i;

    _TRY
    {
        /**** 먼저 Lock 을 획득 ****/
        do
        {
            _rc = dbmLockSegment ( );

            if ( _rc == RC_SUCCESS )
            {
                /**** 현재 dbmSegmentManager 객체의 member 를 초기화 **/
                this->mSegmentCount = 1;

                char* pAddr = NULL;

                for( i = ( MAX_SEGMENT_COUNT - 1 ); i > 0; i-- )
                {
                    if( mHeader->mSegmentAlloc[i] != -1 )
                    {
                        getFileName ( mInstName, mHeader->mSegmentName, i, sFileName );
                        sSlotCount = mHeader->mExtendSlotCount;

                        sSize = sSlotCount * mHeader->mSlotSize + sizeof(dbmSegmentHeader) + sizeof(long long) * ( sSlotCount + 1 );

                        // ERR_CMN_INVALID_ARG: 700
                        _rc = cmnShmDetach ( (void**)&mStartAddress[i], sSize );
                        if ( _rc != 0 )
                        {
                            DBM_WARN ( "shmDetach fail, but ignore, rc=%d, mStartAddress[%d]=%p (err=%d,lwp=%d)"
                                    , _rc, i, mStartAddress[i], errno, gettid_s() );
                        }

                        _IF_THROW( cmnShmDrop ( sFileName ), ERR_DBM_DROP_SHM_FAIL );
                    }
                }

                sDataAddress = (char*) mHeader + sizeof(dbmSegmentHeader) + mHeader->mUserHeaderSize + sizeof(long long) * ( mHeader->mInitSlotCount + 1 );

                /*** 기존에 사용되는 공간에 대해서 memset_s */
                memset_s ( sDataAddress, -1, mHeader->mInitSlotCount * mHeader->mSlotSize );

                sStartSlot = (long long*) ( sDataAddress - ( sizeof(long long) * ( mHeader->mInitSlotCount + 1 ) ) );

                /*** Slot 공간을 초기화 ****/
                for ( i = 0; i < ( mHeader->mInitSlotCount + 1 ); i++ )
                {
                    if ( i < mHeader->mInitSlotCount )
                    {
                        sStartSlot[i] = i;

                    }
                    else
                    {
                        sStartSlot[i] = -1;
                    }
                }

                /* Extend 에 할당된 메모리를 모두 날렸으니 Header 를 초기화 */
                mHeader->mAlloc = 0;
                mHeader->mFree = mHeader->mInitSlotCount;
                mHeader->mSegmentCount = 1;
                mHeader->mNextExtendNo = 1;
                memset_s( mHeader->mSegmentAlloc, -1, sizeof(int) * MAX_SEGMENT_COUNT );
                mHeader->mSegmentAlloc[0] = 0;

                _RETURN;
            }
            else
            {
                if ( mHeader->mLock == -1 )
                {
                    // 누군가가 락을 잡고 작업을 했다. 그냥 성공으로 나간다.
                    _RETURN;
                }
            }
        }
        while ( true );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        if ( mHeader->mLock == gettid_s() )
        {
            dbmUnlockSegment ( );
        }
    }
    _END
} /* Truncate */



/******************************************************************************
 *
 * Truncate 를 하기 위해서 다음과 같이 진행한다.
 *
 *****************************************************************************/
_VOID dbmSegmentManager::Truncate ( )
{
    char    sFileName [ MAX_SEGMENT_NAME_LENGTH ] ;
    size_t  sSize;
    long long sSlotCount;
    long long*   sStartSlot;

    char*   sDataAddress;
    int     i;

    _TRY
    {
        /**** 먼저 Lock 을 획득 ****/
        do
        {
            _rc = dbmLockSegment ( );

            if ( _rc == RC_SUCCESS )
            {
                DBM_DBG( "truncate segment [%s] with [%d] segments (err=%d,lwp=%d)",
                        mHeader->mSegmentName,
                        mHeader->mSegmentCount - 1, errno, gettid_s() );

                /**** 현재 dbmSegmentManager 객체의 member 를 초기화 **/

                this->mSegmentCount = 1;

                char* pAddr = NULL;
                /** Lock 을 잡았으니 Truncate 작업을 수행한다 **/
                for ( i = mHeader->mSegmentCount - 1; i > 0; i-- )
                {
                    getFileName ( mInstName, mHeader->mSegmentName, i, sFileName );
                    sSlotCount = mHeader->mExtendSlotCount;

                    sSize = sSlotCount * mHeader->mSlotSize + sizeof(dbmSegmentHeader) + sizeof(long long) * ( sSlotCount + 1 );

                    // ERR_CMN_INVALID_ARG: 700
                    _rc = cmnShmDetach ( (void**)&mStartAddress[i], sSize );
                    if ( _rc != 0 )
                    {
                        DBM_WARN ( "shmDetach fail, but ignore, rc=%d, mStartAddress[%d]=%p (err=%d,lwp=%d)"
                                , _rc, i, mStartAddress[i], errno, gettid_s() );
                    }

                    _IF_THROW( cmnShmDrop ( sFileName ), ERR_DBM_DROP_SHM_FAIL );
                }

                sDataAddress = (char*) mHeader + sizeof(dbmSegmentHeader) + mHeader->mUserHeaderSize + sizeof(long long) * ( mHeader->mInitSlotCount + 1 );

                /*** 기존에 사용되는 공간에 대해서 memset_s */
                memset_s ( sDataAddress, -1, mHeader->mInitSlotCount * mHeader->mSlotSize );

                sStartSlot = (long long*) ( sDataAddress - ( sizeof(long long) * ( mHeader->mInitSlotCount + 1 ) ) );

                /*** Slot 공간을 초기화 ****/
                for ( i = 0; i < ( mHeader->mInitSlotCount + 1 ); i++ )
                {
                    if ( i < mHeader->mInitSlotCount )
                    {
                        sStartSlot[i] = i;

                    }
                    else
                    {
                        sStartSlot[i] = -1;
                    }
                }

                /* Extend 에 할당된 메모리를 모두 날렸으니 Header 를 초기화 */
                mHeader->mAlloc = 0;
                mHeader->mFree = mHeader->mInitSlotCount;
                mHeader->mSegmentCount = 1;
                mHeader->mNextExtendNo = 1;

                _RETURN;
            }
            else
            {
                if ( mHeader->mLock == -1 )
                {
                    // 누군가가 락을 잡고 작업을 했다. 그냥 성공으로 나간다.
                    _RETURN;
                }
            }
        }
        while ( true );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        if ( mHeader->mLock == gettid_s() )
        {
            dbmUnlockSegment ( );
        }
    }
    _END
} /* Truncate */


////////////////////////////////////////////////////////////////////////////////
// C TYPE Wrapper
////////////////////////////////////////////////////////////////////////////////

#ifdef DBM_SLOT_TRACE
_VOID dbmSegFreeSlot_( dbmSegmentManager* pInfo, long long aSlot, int aCheckFlag, const char* aFile, const char* aFunc, int aLine )
#else
_VOID dbmSegFreeSlot ( dbmSegmentManager* pInfo, long long aSlot, int aCheckFlag )
#endif
{
    _TRY
    {
        _DASSERT( pInfo != NULL );

#ifdef DBM_SLOT_TRACE
        _rc = pInfo->FreeSlot ( aSlot, aCheckFlag, aFile, aFunc, aLine );
#else
        _rc = pInfo->FreeSlot ( aSlot, aCheckFlag );
#endif
    }
    _CATCH
    _FINALLY
    _END
}

#ifdef DBM_SLOT_TRACE
_VOID dbmSegAllocSlot_( dbmSegmentManager* pInfo, long long* aReturnSlot, const char* aFile, const char* aFunc, int aLine )
#else
_VOID dbmSegAllocSlot ( dbmSegmentManager* pInfo, long long* aReturnSlot )
#endif
{
    _TRY
    {
        _DASSERT( pInfo != NULL );

#ifdef DBM_SLOT_TRACE
        _rc = pInfo->AllocSlot ( aReturnSlot, aFile, aFunc, aLine );
#else
        _rc = pInfo->AllocSlot ( aReturnSlot );
#endif
    }
    _CATCH
    _FINALLY
    _END
}

