/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    Configration을 읽고 관리하는 코드다.
 *******************************************************************************/

#include "dbmHeader.h"
#include "dbmConfigManager.h"

/********************************************************************
 * ID : dbmConfig
 *
 * Description
 *   생성자
 *
 * Arguments
 *
 * Return
 *
 ********************************************************************/
dbmConfig::dbmConfig( )
{
    mCommonPropList = NULL;
    mUserPropList   = NULL;
    mLoadPropList   = NULL;

    mInitialize();
}



/********************************************************************
 * ID : dbmConfig
 *
 * Description
 *   소멸자
 *
 * Arguments
 *
 * Return
 *
 ********************************************************************/
dbmConfig::~dbmConfig( )
{
    _TRY
    {
        // 파일이 열린 상태면 닫는다.
        if ( this->mFD > 0 )
        {
            close_s ( this->mFD );
        }

        if ( mCommonPropList != NULL )
        {
            mCommonPropList->clear();
            delete mCommonPropList;
            mCommonPropList = NULL;
        }
        if ( mUserPropList != NULL )
        {
            mUserPropList->clear();
            delete mUserPropList;
            mUserPropList = NULL;
        }
        if ( mLoadPropList != NULL )
        {
            mLoadPropList->clear();
            delete mLoadPropList;
            mLoadPropList = NULL;
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
//    _END
}


/********************************************************************
 * ID : mInitialize
 *
 * Description
 *    명시적인 초기화를 위한 외부 인터페이스
 *
 * Arguments
 *
 * Return
 *
 ********************************************************************/
int dbmConfig::mInitialize( )
{
    int     sIdx;
    int     sRC;


    /************************************************
 * Class member 변수부터 초기화.
 ************************************************/
    this->mFD = DBM_FD_NOT_USED;
    mCommonPropList = new std::map<std::string, int>;
    mCommonPropList->clear();

    mUserPropList = new std::map<std::string, int>;
    mUserPropList->clear();

    mLoadPropList = new std::map<std::string, std::string>;
    mLoadPropList->clear();

    // 환경변수부터 체크한다.
    sRC = mValidHome();
    _IF_RAISE( sRC, ENV_FATAL );


    // 파일명 결정.
    snprintf ( mConfigFile, sizeof( mConfigFile )-1, "%s/%s/%s",
               getenv( ENV_DBM_HOME ), DBM_CONFIG_FILE_PATH, DBM_CONFIG_FILE_NAME );

    // 추가될 공통 Property가 있으면 여기에 추가하라.
    sIdx = 0;

    // 2014.12.14. -okt- unitTest/metaManager - DBM_INSTANCE 를 제거하기가 곤란함.
    mCommonPropList->insert( std::map<std::string, int>::value_type( "DBM_INSTANCE", sIdx++ ) );

    // 2014.12.14. -okt- TRACE_LOG_LEVEL 구현해야함. TRACE_LOG_DIR
//    mCommonPropList->insert( std::map<std::string, int>::value_type( "TRACE_LOG_DIR", sIdx++ ) );
//    mCommonPropList->insert( std::map<std::string, int>::value_type( "TRACE_LOG_BUFFER_LENGTH", sIdx++ ) );
//    mCommonPropList->insert( std::map<std::string, int>::value_type( "TRACE_LOG_BUFFER_COUNT", sIdx++ ) );
//    mCommonPropList->insert( std::map<std::string, int>::value_type( "TRACE_LOG_LEVEL", sIdx++ ) );

    mCommonPropList->insert( std::map<std::string, int>::value_type( "UNDO_SLOT_SIZE", sIdx++ ) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "UNDO_INIT_SIZE", sIdx++ ) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "UNDO_EXTEND_SIZE", sIdx++ ) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "UNDO_MAX_SIZE", sIdx++ ) );

    mCommonPropList->insert( std::map<std::string, int>::value_type( "TABLE_INIT_ROWS", sIdx++ ) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "TABLE_EXTEND_ROWS", sIdx++ ) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "TABLE_MAX_ROWS", sIdx++ ) );

    mCommonPropList->insert( std::map<std::string, int>::value_type( "DBM_PROMPT_MODE", sIdx++ ) );

    mCommonPropList->insert( std::map<std::string, int>::value_type( "DISK_LOG_ENABLE", sIdx++ ) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "DISK_LOG_IO_TYPE", sIdx++ ) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "DISK_LOG_COMPRESS", sIdx++ ) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "DISK_LOG_DIR", sIdx++ ) );
//    mCommonPropList->insert( std::map<std::string, int>::value_type( "DBM_DATA_DIR", sIdx++ ) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "DISK_LOG_FILE_SIZE", sIdx++ ) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "DISK_LOG_BUFFER_SIZE", sIdx++ ) );

    mCommonPropList->insert( std::map<std::string, int>::value_type( "REPL_ENABLE", sIdx++) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "REPL_REMOTE_HOST_IP", sIdx++) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "REPL_REMOTE_HOST_PORT", sIdx++) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "REPL_LOCAL_HOST_IP", sIdx++) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "REPL_LOCAL_HOST_PORT", sIdx++) );

    mCommonPropList->insert( std::map<std::string, int>::value_type( "REPL_MY_HB_PORT", sIdx++) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "REPL_REMOTE_HB_PORT", sIdx++) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "REPL_MEMORY_ENABLE", sIdx++) );

    mCommonPropList->insert( std::map<std::string, int>::value_type( "CHECK_POINT_PATH", sIdx++) );
    mCommonPropList->insert( std::map<std::string, int>::value_type( "CHECK_POINT_DB_SIZE", sIdx++) );

    // 추가될 User Property가 있으면 여기에 추가하라.
    sIdx = 0;
    mUserPropList->insert( std::map<std::string, int>::value_type( "DBM_INSTANCE", sIdx++ ) );

//    mUserPropList->insert( std::map<std::string, int>::value_type( "TRACE_LOG_DIR", sIdx++ ) );
//    mUserPropList->insert( std::map<std::string, int>::value_type( "TRACE_LOG_BUFFER_LENGTH", sIdx++ ) );
//    mUserPropList->insert( std::map<std::string, int>::value_type( "TRACE_LOG_BUFFER_COUNT", sIdx++ ) );
//    mUserPropList->insert( std::map<std::string, int>::value_type( "TRACE_LOG_LEVEL", sIdx++ ) );

    mUserPropList->insert( std::map<std::string, int>::value_type( "TABLE_INIT_ROWS", sIdx++ ) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "TABLE_EXTEND_ROWS", sIdx++ ) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "TABLE_MAX_ROWS", sIdx++ ) );

    mUserPropList->insert( std::map<std::string, int>::value_type( "DISK_LOG_ENABLE", sIdx++ ) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "DISK_LOG_IO_TYPE", sIdx++ ) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "DISK_LOG_COMPRESS", sIdx++ ) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "DISK_LOG_DIR", sIdx++ ) );
//    mUserPropList->insert( std::map<std::string, int>::value_type( "DBM_DATA_DIR", sIdx++ ) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "DISK_LOG_FILE_SIZE", sIdx++ ) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "DISK_LOG_BUFFER_SIZE", sIdx++ ) );

    mUserPropList->insert( std::map<std::string, int>::value_type( "REPL_ENABLE", sIdx++) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "REPL_REMOTE_HOST_IP", sIdx++) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "REPL_REMOTE_HOST_PORT", sIdx++) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "REPL_LOCAL_HOST_IP", sIdx++) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "REPL_LOCAL_HOST_PORT", sIdx++) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "REPL_MY_HB_PORT", sIdx++) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "REPL_REMOTE_HB_PORT", sIdx++) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "REPL_MEMORY_ENABLE", sIdx++) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "CHECK_POINT_PATH", sIdx++) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "CHECK_POINT_DB_SIZE", sIdx++) );

    /***********************************************
     * by lim272, for archiving logs. 2015.08.28
    ***********************************************/
    mUserPropList->insert( std::map<std::string, int>::value_type( "ARCHIVE_ENABLE", sIdx++) );
    mUserPropList->insert( std::map<std::string, int>::value_type( "ARCHIVE_LOG_PATH", sIdx++) );

    // 정상리턴
    return RC_SUCCESS;

    // 예외처리
    _EXCEPTION( ENV_FATAL )
    {
        fprintf( stdout, "ENV FATAL!!!!!\n" );
    }

    _EXCEPTION_END;
    return sRC;
}


/********************************************************************
 * ID : mGet
 *
 * Description
 *    실제 로딩파트.
 ********************************************************************/
void dbmConfig::mGet( char* aSection, char* aPropName )
{
    std::string  sKey;
    char    sVal [4096];

    // 저장해둔 PropName을 통해 읽는다.
    memset_s ( sVal, 0x00, sizeof(sVal) );
    if( getenv( aPropName ) != NULL )
    {
        snprintf ( sVal, sizeof(sVal), "%s", getenv ( aPropName ) );
    }
    else
    {
        sRC = cmnReadElement( this->mFD, aSection, aPropName, sVal, NULL );
        if ( sRC )
        {
#if 0
            if ( strncmp_s( aPropName, "TRACE_LOG_DIR", sizeof("TRACE_LOG_DIR") - 1 ) == 0 )
            {
                fprintf(stdout,  "      mFD=%d, aSection=<%s>,sVal<%s>\n", this->mFD, aSection, sVal);
            }
#endif
            return;
        }
    }

    /************************************************
 * Key를 만들고.
 ************************************************/
    sKey.clear();
    sKey.append( aSection );
    sKey.append( aPropName );

    /************************************************
 * LoadList에 저장한다.
 ************************************************/
    mLoadPropList->insert( std::map<std::string, std::string>::value_type( sKey, sVal ) );
}



/********************************************************************
 * ID : mLoad
 *
 * Description
 *    여기서는 COMMON 프로퍼티 로딩할것임.
 ********************************************************************/
int dbmConfig::mLoad( char* aSection )
{
    std::map<std::string, int>::iterator sProp;
    std::string sKey;

    _TRY
    {
        // 실제 Config 파일을 열고
        _CALL( cmnOpenConfig( mConfigFile, &this->mFD ) );

        // 약속된 Property list을 읽는다.
        if ( strlen_s(aSection)== strlen_s( DBM_COMMON_SECTION )
                && strncmp_s( aSection, DBM_COMMON_SECTION, strlen_s(aSection)) == 0 )
        {
            for( sProp = mCommonPropList->begin(); sProp != mCommonPropList->end(); sProp++ )
            {
                mGet( aSection, (char*)sProp->first.c_str() );
            }
        }
        else
        {
            for( sProp = mUserPropList->begin(); sProp != mUserPropList->end(); sProp++ )
            {
                mGet( aSection, (char*)sProp->first.c_str() );
            }
        }

        // 실제 Config 파일을 닫는다.
        _CALL( cmnCloseConfig( &this->mFD ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}




/********************************************************************
 * ID : mLoad
 *
 * Description
 *
 * Arguments
 *
 * Return
 *
 ********************************************************************/
int dbmConfig::mLoad( const char* aSection )
{
    return mLoad( (char*)aSection );
}




/********************************************************************
 * ID : mSearch
 *
 * Description
 *    여기서는 Property를 찾아서 리턴해준다.
 *
 * Arguments
 *
 * Return
 *
 ********************************************************************/
int dbmConfig::mSearch( char* aSection, char* aPropName, char* aRetVal )
{
    std::map<std::string, std::string>::iterator   sProp;
    std::string sKey;
    int                              sTry = 0;


    /************************************************
     * mKey 만들고
     ************************************************/
    sKey.clear();
    sKey.append( aSection );
    sKey.append( aPropName );

    /************************************************
     * 탐색 후 결과 리턴한다.
     ************************************************/
repeat:
    sProp = mLoadPropList->find( sKey );

    if ( sProp == mLoadPropList->end() )
    {
        if (sTry == 0 && (strncmp_s (aSection, DBM_COMMON_SECTION, strlen_s(aSection)) != 0 || strlen_s(DBM_COMMON_SECTION) != strlen_s(aSection)))
        {
            sKey.clear();
            sKey.append(DBM_COMMON_SECTION);
            sKey.append(aPropName);
            sTry = 1;
            goto repeat;
        }
        aRetVal[0] = 0x00;
        return RC_FAILURE;
    }

    memcpy_s( aRetVal, sProp->second.c_str(), sProp->second.length() );
    /************************************************
     * 일단은 여기서 Null-terminating한다.
     ************************************************/
    aRetVal[sProp->second.length()] = 0x00;

    /************************************************
     * 정상리턴.
     ************************************************/
    return RC_SUCCESS;
}




/********************************************************************
 * ID : mSearch
 *
 * Description
 *    여기서는 Property를 찾아서 리턴해준다.
 *
 * Arguments
 *
 * Return
 *
 ********************************************************************/
int dbmConfig::mSearch( const char* aSection, const char* aPropName, char* aRetVal )
{
    return( mSearch( (char*)aSection, (char*)aPropName, aRetVal ) );
}

int dbmConfig::mSearch( char* aSection, const char* aPropName, char* aRetVal )
{
    return( mSearch( aSection, (char*)aPropName, aRetVal ) );
}


/********************************************************************
 * ID : mValidHome
 *
 * Description
 *    여기서는 DBM_HOME 설정여부만 체크해봄.
 *
 * Arguments
 *
 * Return
 *
 ********************************************************************/
int dbmConfig::mValidHome( )
{
    if ( getenv( ENV_DBM_HOME ) != NULL )
    {
        return RC_SUCCESS;
    }
    else
    {
        return RC_FAILURE;
    }
}


void dbmConfig::mPrintAll()
{
    std::map<std::string, int>::iterator sProp1;
    std::map<std::string, std::string>::iterator sProp;

    _TRY
    {
        _PRT( "\n[ COMMONList............................... ]\n" );
        for ( sProp1 = mCommonPropList->begin(); sProp1 != mCommonPropList->end(); sProp1++ )
        {
            _PRT_N( sProp1->first.c_str(), sProp1->second );
        }

        _PRT( "\n[ Load............................... ]\n" );
        for ( sProp = mLoadPropList->begin(); sProp != mLoadPropList->end(); sProp++ )
        {
            _PRT_S( sProp->first.c_str(), sProp->second.c_str() );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}
