/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 * Index 관련되어 처리 하는 Source 이다.
*******************************************************************************/
#include "dbmIndexManagerInterface.h"
#include "dbmHeader.h"

const int g_DBM_INDEX_DEGREE_sub1_div2 = ( DBM_INDEX_DEGREE - 1 ) >> 1;
const int g_DBM_INDEX_DEGREE_add1_div2 = ( DBM_INDEX_DEGREE + 1 ) >> 1;


/********************************************************************
 * extern functions
********************************************************************/

/***********************************************
 * 변경자 : wind * 변경일 : 15.11.09 * 참고 : #1027
 * 변경 내용 : mInsertKey에서 키 캐스팅을 제거한다.
 * 예상대로라면 아래 함수 원형은 사라져도 됨
 ***********************************************/
#if 0
_VOID dbmIndexManager::mInsertKey ( int aTransID , char *aKey , long long aDataSlot )
{
    return dbmIdxInsertKey ( mInstName, aDataSlot, aTransID, aKey, NULL, this, NULL );
}

_VOID dbmIndexManager::mInsertKey ( int aTransID , char *aKey , long long aDataSlot, long long* aExtraKey )
{
    return dbmIdxInsertKey ( mInstName, aDataSlot, aTransID, aKey, NULL, this, aExtraKey );
}

_VOID dbmIndexManager::mInsertKey ( char* aInstName , long long aDataSlot , int aTransID , char* aIndexName , char *aKey )
{
    return dbmIdxInsertKey ( aInstName, aDataSlot, aTransID, aKey, aIndexName, NULL, NULL );
}
#endif
_VOID dbmIndexManager::mInsertKey ( int aTransID , char *aKey , long long aDataSlot )
{
    return dbmIdxInsertKey ( mInstName, aDataSlot, aTransID, aKey, NULL, this );
}

_VOID dbmIndexManager::mInsertKey ( char* aInstName , long long aDataSlot , int aTransID , char* aIndexName , char *aKey )
{
    return dbmIdxInsertKey ( aInstName, aDataSlot, aTransID, aKey, aIndexName, NULL );
}

/********************************************************************
 * ID : mInsertKeyNon(static)
 *
 * Description
 *    dbm Index key Delete
 *
 * Argument
 *    aDataSlot : input : data slot ID
 *    aTransID  : input : transaction ID
 *    aKey      : input : Index Key value
 *    aIndexName: input : static call 분류 시 사용 index name
 *    pUser     : input : static call 분류 시 사용 pUser
 *
********************************************************************/
__thread char*  g_sInsertNonIndexNode = NULL;
__thread int    g_bIsUniqueIndex = DBM_UNIQUE;

// 2014.10.02 -okt- top-1 성능 함수 (INSERT)
//_VOID dbmIdxInsertKey ( char* aInstName, long long aDataSlot , int aTransID , char *aKey , char* aIndexName , void* pUser, long long* aExtraKey )
_VOID dbmIdxInsertKey ( char* aInstName, long long aDataSlot , int aTransID , char *aKey , char* aIndexName , void* pUser )
{
    dbmIndexNode*       sCurr = NULL;
    dbmIndexNode*       sChild = NULL;
    dbmIndexNode*       sNewNode = NULL;

    dbmIndexNode*       sInkey; // 2014.11.20 -okt- [perf] 불필요 초기화 제거

    dbmIndexManager*    pInfo = NULL;
    dbmIndexHeader*     sIndexHeader = NULL;
    dbmSegmentManager*  sSegMgr; // 2014.11.20 -okt- [perf] 불필요 초기화 제거
    dbmLockManager*     sLockMgr = NULL;

    char    sKeyTemp[DBM_NON_UNIQUE_KEY_SIZE] = { 0, };
    char    sKeyData[DBM_NON_UNIQUE_KEY_SIZE] = { 0, };
    char*   sKey;                   // key
    int     sCount;                 // node count
    int     sPos;                   // 삽입 위치를 저장하기 위한 임시 변수
    int     sPosition = 0;          // 컴파일 워닝 제거
    long long sDataSlot;

    long long sSlotID;              //Alloc Slot ID
    char*   sAddrRootCurrNodePt;    //root id Slot2Addr address

    int     sKeySize;
    int     sLockF = 0;
    int     sCurrStepF = 0;
    int     sRC = -1;

    _TRY
    {
        // 2014.10.02 -okt- 성능함수이고 내부함수이므로, 오류 검사를 최소화 (릴리즈에서 검사하지 않는다.)
        _DASSERT ( aKey != NULL );   // input key data check
        // pUser: 내부호출일때 class 자신(this), aIndexName 정호출
        _DASSERT ( pUser != NULL || aIndexName != NULL );

        // 일반 호출
        if ( likely( pUser != NULL ) )
        {
            pInfo = (dbmIndexManager*)pUser;
            sSegMgr = pInfo->mSegMgr;
            sIndexHeader = pInfo->mIndexHeader;
            sLockMgr = pInfo->mLockMgr;
        }
        // TxMgr의 Recovery에서만 사용 ( 객체없이 Static )
        else if ( aIndexName != NULL )
        {
            _CALL( dbmSegmentManager::Attach ( aInstName, aIndexName, &sSegMgr ) );
            sIndexHeader = (dbmIndexHeader*) sSegMgr->GetUserHeader ( );
        }


        /* Index Tree X-Lock mode */
        /* sIndexHdr->lock -1 이면 잡을수 있고.. 없으면 try  futex 처리 */
        _CALL( mSpinLockLib( &sIndexHeader->mLock, &sIndexHeader->mFutex, aTransID, sLockMgr ) );
        sLockF = 1; // _CATCH에서 해제필요 여부 판단위해

        /* dic object type */
        g_bIsUniqueIndex = sIndexHeader->mIndex.mIsUniqueIndex;
        sKeySize = ( g_bIsUniqueIndex ) ? sIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );

        // 2014.10.02 -okt- 위의 락위치를 여기로 내리면 더 늦어진다. 이해가 안되지만 원복.
        /* insert Configure Check */
        sRC = dbmIdxInsertCheck ( aTransID, sIndexHeader );
        if ( unlikely( sRC != 0 ) )
        {
            sLockF = 0; // _CATCH에서 해제필요 여부 판단위해
            sRC = mSpinUnlockLib( &sIndexHeader->mLock, &sIndexHeader->mFutex, aTransID, sLockMgr );
            if ( sRC != 0 ) //, UNLOCK_ERROR );
            {
                DBM_ERR ( "spin unlock error, rc=%d [L,%p,%d,T,%d] (err=%d,tid=%d)",
                          sRC, &sIndexHeader->mLock, sIndexHeader->mLock, aTransID, errno, gettid_s( ) );
                _THROW( ERR_DBM_UNLOCK_FAIL );
            }

            _RETURN;
        }
        sCurrStepF = 1;     // mInsertCheck() 내부에서 상태가 바뀐다.

        /* insert key state set */
        _CALL( dbmIdxInsertClear ( &sCurr, sIndexHeader, sSegMgr, pUser, aTransID ) );

        /* 나중 Index Root 처리 부분이 정해지면 거기에서 처리 */
        /* 초기화 처리 */
        //sFound = 0;
        //sFinished = 0;
        sCount = 0;
        sDataSlot = 0;
        //sNodeCheck = 0;

        /* 자식노드 초기 화 */
        sChild = NULL;
        //sSlotAddr = NULL;

        //memset_s ( sKeyTemp, 0x00, sizeof( sKeyTemp ) );
        *(long long*)( sKeyTemp + sIndexHeader->mIndex.mKeySize ) = 0L;  // 2014.10.14 -okt- extra 쪽만 바꾸면 되지 않을까?
        sKey = (char*) &sKeyTemp;

        // input key set
        sDataSlot = aDataSlot;
        //sNodeCheck = 1;


        if ( unlikely( g_sInsertNonIndexNode == NULL ) )
        {
            int sLen = sizeof(dbmIndexNode) + ( ( DBM_INDEX_KEY_MAX_SIZE + 8 ) * DBM_INDEX_DEGREE );
            g_sInsertNonIndexNode = (char*) malloc_s ( sLen );
            if ( g_sInsertNonIndexNode == NULL )
            {
                _DASSERT( 0 );
                _THROW( ERR_DBM_MEM_ALLOC );
            }

            memset_s ( g_sInsertNonIndexNode, 0x00, sLen );
        }

        /* key cast */
        // 2014.10.14 -okt- if 한번을 줄이기 위해. 함수내부로 이동
//        if ( g_bIsUniqueIndex == DBM_NON_UNIQUE )
//        {
//            /* non-unique index extra값을 증가한다 */
//            /* 초기값은 index 생성 시 ActCreateIndex에서 초기화 한다 */
//            mvpAtomicInc64 ( &sIndexHeader->mExtra );
//        }
        //(void) dbmIdxIndexKeyCast ( &sKey, aKey, sIndexHeader, aExtraKey );
        /***********************************************
         * 변경자 : wind * 변경일 : 15.11.09 * 참고 : #1027
         * 변경 내용 : mInsertKey에서 키 캐스팅을 제거한다.
         * 그리고 예상대로라면 NU인덱스일 경우 ExtraKey가 sKey뒤에 항상 붙어서 올 것으로 예상된다.
         * 그렇다면 밑의 조건에서 NU인덱스일 경우 이렇게 변경하면 된다.
         * memcpy_s( sKey, aKey, sIndexHeader->mIndex.mKeySize + 8 );
         ***********************************************/
#if 0
        memcpy_s( sKey, aKey, sIndexHeader->mIndex.mKeySize );
        if ( g_bIsUniqueIndex == DBM_NON_UNIQUE )
        {
            if( aExtraKey == NULL )
            {
                mvpAtomicInc64 ( &sIndexHeader->mExtra );   // 2014.10.14 -okt- if 한번을 줄이기 위해. 함수내부로 이동
                *(long long*) ( sKey + sIndexHeader->mIndex.mKeySize ) = sIndexHeader->mExtra;
                DBM_INFO( "aExtraKey is not exist...and then what is aKey extra? [%lld]", *(long long*) ( aKey + sIndexHeader->mIndex.mKeySize ) );
            }
            else
            {
                DBM_INFO( "aExtraKey is exist...is it same aKey extra? [%lld:%lld]"
                        , *(long long*) ( aKey + sIndexHeader->mIndex.mKeySize )
                        , *aExtraKey);
                *(long long*) ( sKey + sIndexHeader->mIndex.mKeySize ) = *aExtraKey;
            }
        }
#endif
        if ( g_bIsUniqueIndex == DBM_NON_UNIQUE )
        {
            //DBM_INFO( "what is aKey extra? [%lld]", *(long long*) ( aKey + sIndexHeader->mIndex.mKeySize ) );
            memcpy_s( sKey, aKey, sIndexHeader->mIndex.mKeySize + 8 );
        }
        else
        {
            memcpy_s( sKey, aKey, sIndexHeader->mIndex.mKeySize );
        }


        /* key node postion */
        int sFound;
        _CALL( dbmIdxInsertPosition ( &sCurr, &sPosition, sKey, &sFound, sIndexHeader, sSegMgr ) );

        if ( unlikely( sFound == 1 ) )
        {
            // #919 로그 도배 방지. INSERT DUP은 정상로직에서도 가능하다.
            //DBM_ERR ( "[Insertion] key already exists in the Index key" );
            _IF_THROW( sFound == 1, ERR_DBM_DUP_ERROR );
        }
        else
        {
            /* key를 B-Tree 삽입 */
            sChild = NULL;
            /* 만약 sInkey가 존재한다면 In-key와 같이 취급 - 즉, 1개의 element 소유 */
            sInkey = NULL;
            //sFinished = 0;

            do /* while */
            {
                //sCurr에 Element 몇개가 있는지...
                sCount = sCurr->mIndexSlotHeader.mNodeCount;

                if ( sInkey )
                {
                    /* 새로 생성한 sInkey 객체의 Node값 6(DBM_INDEX_DEGREE) 다시 가져와서 돈다 */
                    sKey = INDEX_POS( sInkey, 0, sKeySize );
                }

                // key값이 차수보다 작으면 Full이 아니니까.....
                // 0:4 1:4 2:4 3:4 4:4
                if ( sCount < DBM_INDEX_DEGREE - 1 ) // full이 아닐경우
                {
                    /******************************************
                     * search key node 와 경합해야 한다
                     * leaf spin lock 처리
                     *******************************************/

                    _CALL( mSpinLockLib( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, sLockMgr ) );
                    //_IF_THROW( sRC, ERR_DBM_LOCK_FAIL ); LEAF_LOCK_ERROR1 );

                    _CALL( dbmIdxInsertKeyPush ( &sCurr, aTransID, &sPosition, sKey, sCount, &sPos, sDataSlot, sIndexHeader ) );

                    if ( sInkey )
                    {
                        /* pCurr->pChild[0] --> 3
                         * pCurr->pChild[1] --> 4,5 새로 생성한 놈의 pointer
                         * pCurr->pChild[2] --> 7,8 새로 생성한 놈의 pointer
                         * 분기 처리 자식 노드를 분할 한다
                         */
                        sCurr->mChild[sPos] = sInkey->mChild[0];
                        sCurr->mChild[sPos + 1] = sInkey->mChild[1];

                        /* 아래의 자식 노드가 변경이 이루어 졌기 때문에 트리 변경이 이루어 진것이다
                         * 그리하여 BTree 변경체크를 해둔다 */
                        mvpAtomicInc64 ( &sCurr->mBtreeCheck );
                        // sCurr->mBtreeCheck ++;   // 2014.10.02 -okt- 락잡았는데. 그냥 변경하면 ?
                    }

//                    sFinished = 1; // 2014.10.02 -okt-

                    /*********************************************
                     * leaf unlock 처리
                     *********************************************/
                    mvpAtomicCas32_s ( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

//                    sFinished = 1;
                    break;
                }
                else
                {
                    sIndexHeader->mTreeCheck = 1;

                    /*******************************************
                     * full이 난경우에는 split 처리...
                     ********************************************/

                    /* sKey 삽입 */
                    sCount = DBM_INDEX_DEGREE - 1;

                    /* Overflow position set */
                    if ( dbmIdxBinarySearchInLeafNoLock ( sCount, &sPos, sCurr, sKey, sIndexHeader) != 0 )
                    {
                        DBM_ERR ( "[Insertion] key [%d] already exists in the Index key", *(int*)sKey );

                        /*
                         * TODO: 2014.11.20. -okt- 인덱스가 깨진걸로 볼 수 있는 상황이라고 함 (shw). 디버거에서만 죽는 코드 추가.
                         *       POC 이후, 실재로 걸리는 경우가 있으면, 릴리즈도 죽일지는 그때 생각.
                         */
                        _DASSERT( 0 );
                        //_IF_THROW( sFound == 1, ERR_DBM_DUP_ERROR );
                        _THROW( ERR_DBM_DUP_ERROR );
                    }



                    _CALL( mSpinLockLib( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, sLockMgr) );

                    /* 현재 노드에 대한여 삽입 및 정렬 처리 한다 */
                    _CALL( dbmIdxInsertAdjust ( &sCurr, aTransID, sPos, sDataSlot, sKey, sIndexHeader, NULL ) ); // xx

                    if ( sInkey )
                    {
                        /* 부모에 새로 생성한 자식  NODE pointer 할당 한다 */
                        sCurr->mChild[sPos] = sInkey->mChild[0];
                        sCurr->mChild[sPos + 1] = sInkey->mChild[1];
                        /* 아래의 자식 노드가 변경이 이루어 졌기 때문에 트리 변경이 이루어 진것이다
                         * 그리하여 BTree 변경체크를 해둔다 */
                        mvpAtomicInc64 ( &sCurr->mBtreeCheck );
                    }

                    /* 중간값을 찾아 부모노드에게 넘겨준다 */
                    /* 중간 값 구하기 */
                    /* 입력 : 1,2,3,4,5 */
                    /* 중간[2]=3 */
                    /* 출력 sPos:2 sKey:3  */
                    sPos = g_DBM_INDEX_DEGREE_sub1_div2;

                    //memset_s ( sKeyData, 0x00, sizeof( sKeyData ) );
                    memcpy_s ( sKeyData, INDEX_POS( sCurr, sPos, sKeySize ), sKeySize );
                    sDataSlot = sCurr->mRID[sPos];

                    /* Alloc Slot & address */
                    sRC = dbmIdxWriteLeaf ( &sSlotID, &sAddrRootCurrNodePt, sSegMgr, sIndexHeader );
                    if ( unlikely( sRC ) ) //, ALLOC_SLOT_NEW_FAIL );
                    {
                        /* leaf unlock 처리  */
                        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

                        DBM_ERR ( "Alloc slot sNewSlotPt faile" );
                        _THROW( ERR_DBM_SEGMENT_ATTACH_FAIL );
                    }

#ifdef _DEBUG   // 논리흐름상 있으나, Index로깅 불필요.
                    if ( pInfo != NULL )
                    {
                        /* Index Logging 처리를 한다 */
                        sRC = pInfo->mIndexLogging ( &sSlotID, aTransID );
                        if ( sRC ) //, DBM_INDEX_LOGGING_FAIL2 );
                        {
                            /* leaf unlock 처리  */
                            mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

                            DBM_ERR ( "mWriteMemlog faile2[%d]",  sRC );
                            _THROW( ERR_DBM_LOG_WRITE_FAIL );
                        }
                    }
#endif

                    sNewNode = (dbmIndexNode*) sAddrRootCurrNodePt;
                    /******************************************
                     * search key node 와 경합해야 한다
                     * leaf spin lock 처리
                     *******************************************/
                    sRC = mSpinLockLib( &sNewNode->mIndexSlotHeader.mLock, NULL, aTransID, sLockMgr );
                    if ( unlikely( sRC ) ) //, LEAF_LOCK_ERROR );
                    {
                        /*********************************************
                        * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

                        DBM_ERR( "leaf lock error [%d][%d]", sRC, sCurr->mIndexSlotHeader.mLock );
                        _THROW( ERR_DBM_LOCK_FAIL );
                    }

                    /* insert new key 조정 */
                    if ( g_bIsUniqueIndex )
                    {
                        _CALL( dbmIdxInsertNewKeyPush ( &sCurr, &sNewNode, aTransID, sPos, sKey, sIndexHeader, sSegMgr, NULL ) );
                    }
                    else
                    {
                        _CALL( dbmIdxInsertNewKeyPushNu ( &sCurr, &sNewNode, aTransID, sPos, sKey, sIndexHeader, sSegMgr, NULL ) );
                    }

                    if ( sCurr->mIndexSlotHeader.mRootSlotID != 0 && sCurr->mIndexSlotHeader.mRootFlag != 1 )
                    {
                        sInkey = (dbmIndexNode*)g_sInsertNonIndexNode;
                        memset_s ( sInkey, 0x00, sizeof(dbmIndexNode) ); // 2014.10.14 -okt- 제거할수는 없겠지?

                        /* sInkey 생성하여 key 및 child 삽입 */
                        // 2014.10.01 -okt- 여기서 락을 풀고있다.
                        _CALL( dbmIdxInsertLeafAdjust ( &sCurr, &sNewNode, &sInkey, sKeyData,
                                                        sDataSlot, aTransID, sIndexHeader, sSegMgr, NULL) );
                    }
                    else
                    {
                        /* sInkey 생성하여 key 및 child 삽입 */
                        sRC = dbmIdxWriteLeaf ( &sSlotID, &sAddrRootCurrNodePt, sSegMgr, sIndexHeader );
                        if ( unlikely( sRC ) ) //, ALLOC_SLOT_NEW_FAIL2 );
                        {
                            /* leaf unlock 처리  */
                            mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

                            DBM_ERR( "mWriteMemlog faile2[%d]", sRC );
                            _THROW( ERR_DBM_LOG_WRITE_FAIL );
                        }

                        sInkey = (dbmIndexNode*) sAddrRootCurrNodePt;

#ifdef _DEBUG   // 논리흐름상 있으나, Index로깅 불필요.
                        if ( pInfo != NULL )
                        {
                            /* Index Logging 처리를 한다 */
                            sRC = pInfo->mIndexLogging ( &sSlotID, aTransID );
                            if ( sRC ) //, DBM_INDEX_LOGGING_FAIL3 );
                            {
                                /*********************************************
                                 * leaf unlock 처리
                                 *********************************************/
                                mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
                                mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

                                DBM_ERR( "mWriteMemlog faile3[%d]", sRC );
                                _THROW( ERR_DBM_LOG_WRITE_FAIL );
                            }

                        }
#endif

                        /* sInkey 생성하여 key 및 child 삽입 */
                        // 2014.10.01 -okt- 여기서 락을 풀고있다.
                        _CALL( dbmIdxInsertLeafNewAdjust ( &sCurr, &sNewNode, &sInkey, sKeyData,
                                                           sDataSlot, aTransID, sSlotID, sIndexHeader, NULL) );
//                        sFinished = 1;
                        break;
                    }
                }
            } while ( 1 ); // ( sFinished == 0 );
        } /* End of if */

        /* Index Insert key Start 상태 변경 */
        {
            sCurrStepF = 0;
            sIndexHeader->mCurrStep = 0;
            sIndexHeader->mTreeCheck = 0;

            _CALL( mSpinUnlockLib( &sIndexHeader->mLock, &sIndexHeader->mFutex, aTransID, sLockMgr ) );
            sLockF = 0; // _CATCH에서 해제필요 여부 판단위해
            //DBM_TRC( ">> UnLock [T,%d,%d,L,%p,%d,F,%p,%d,]", aTransID, errno, &sIndexHeader->mLock, sIndexHeader->mLock, &sIndexHeader->mFutex, sIndexHeader->mFutex );
        }

#if 0
        _CALL( sSegMgr->Slot2Addr(sIndexHeader->mRootPid, &sSlotAddr) );
        PrintNodeElement3Lib((dbmIndexNode*)sSlotAddr,sIndexHeader,sSegMgr);
#endif

    }
    _CATCH
    {
        if ( _rc == ERR_DBM_DUP_ERROR )
        {
            _CATCH_DBG;
        }
        else
        {
            _CATCH_WARN;
        }

        /* unlock process */
        if ( sCurrStepF == 1 )
        {
            sIndexHeader->mCurrStep = 0;
        }
        if ( sLockF == 1 )
        {
            dbmLockManager::mSpinUnlock ( (char*) &sIndexHeader->mLock, &sIndexHeader->mFutex, aTransID );
        }
    }
    _FINALLY
    _END
} /* End of mInsertKey() */



/********************************************************************
 * static functions
 *
 * 2014.09.24 (OKT): 정적 함수로 뺄수 있는 부분을 따로 모은다.
 *
********************************************************************/

/********************************************************************
 * ID : mInsertClear(satic)
 *
 * Description
 *     dbm Index insert key node clear 및 사용할 node 포인터를 반환한다.
 * Argument
 *     aCurr        : output : 사용할 node의 포인터를 반환 한다.
 *     aIndexHeader : input : dbm index Header
 *     aSegMgr      : input : Index segment pointer
 *     puser        : input : static call 분류 시 사용 pUser
 *     aTransID     : input : Transaction ID
 *
********************************************************************/
_VOID dbmIdxInsertClear ( dbmIndexNode** aCurr , dbmIndexHeader* aIndexHeader , dbmSegmentManager* aSegMgr , void* pUser , int aTransID )
{
    /* NODE 선언 */
    dbmIndexNode*       sCurr = NULL;
    dbmIndexHeader*     sIndexHeader = NULL;
    dbmSegmentManager*  sSegMgr = NULL;
    dbmIndexManager*    pInfo = NULL;

    long long sSlotID;        // Alloc Slot ID
    char*   sAddrSlotID;    // slot id Slot2Addr address

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        /* Root,Internal,leaf Node  Create */
        /* 나중에 space manager Alloc Page */
        /* roog page 0:미할당 1:할당 */
        if ( likely( mvpAtomicGet32 ( &sIndexHeader->mRootAllocCk ) == 1 ) )
        {
            /* 기존에 root가 있다는 것이다 header에 있는 root놈을 가져오자 */
            _CALL( sSegMgr->Slot2Addr ( sIndexHeader->mRootPid, &sCurr ) );

            sCurr->mCurrSlot = sIndexHeader->mRootPid;

            /* index child stat check */
            if ( unlikely( sCurr->mCurrSlot < 0 ) ) //, INDEX_ROOT_STATE_ERROR );
            {
                DBM_ERR( "index root state error root pid[%lld] slot[%lld] root check[%d]",
                         sIndexHeader->mRootPid,
                         sCurr->mCurrSlot,
                         sIndexHeader->mRootAllocCk );
                _THROW( ERR_DBM_STATE_ERROR );
            }
        }
        else
        {
            /**********************************************************************
             * node간의 연결정보
             * 1) 기존에 있던놈들은 양도
             * 2) 기존에 있던 놈은 새로운 NODE 가르킨다.
             * 3) 새로운 NODE 놈은 기존에 있던 NODE가 가리키고 있던 NODE 가리킨다.
             * 4) 새로 생신 NODE 와 기존에 있던 NODE 신규 ROOT NODE 간직하고 있는다
             **********************************************************************/

            /* Alloc Slot & address */
            _CALL( dbmIdxWriteLeaf ( &sSlotID, &sAddrSlotID, sSegMgr, aIndexHeader ) );
            //_IF_THROW( sRC, ERR_DBM_ALLOC_SLOT_FAIL ); //ALLOC_SLOT_ERROR );

            sCurr = (dbmIndexNode*) sAddrSlotID;

            _DASSERT( sCurr->mIndexSlotHeader.mLock <= 0 ); // 2014.12.14. -okt- #630 추적 임시코드
            sCurr->mIndexSlotHeader.mLock = -1;

            /* 초기화 처리 */
            sCurr->mCurrSlot = sSlotID;
            sCurr->mIndexSlotHeader.mLeafcheck = 1;
            sCurr->mIndexSlotHeader.mNodeCount = 0;

            /* slot Header info set */
            /* 1:root slot 0:non-root slot */
            sCurr->mIndexSlotHeader.mRootFlag = 1;
            sCurr->mIndexSlotHeader.mRootSlotID = sSlotID;
            sCurr->mIndexSlotHeader.mLeafNextID = -1;
            sCurr->mIndexSlotHeader.mLeafPrevID = -1;

            /* Index Root Page 할당 완료 */
            mvpAtomicSet32 ( &sIndexHeader->mRootAllocCk, 1 );

            /* Index Depth Clear 2014.04.03 -shw- */
            mvpAtomicSet32 ( &sIndexHeader->mDepthNo, 1 );

            /* Index Root PID */
            sIndexHeader->mRootPid = sSlotID;

            /* root flag set */
            sCurr->mRoot = 1;

            /* Btree Check value 초기화 */
            sCurr->mBtreeCheck = 0;

            /* 초기값 증가 */
            mvpAtomicInc64 ( &sCurr->mBtreeCheck );

#ifdef _DEBUG   // 논리흐름상 있으나, Index로깅 불필요.
            if ( pUser != NULL )
            {
                pInfo = (dbmIndexManager*) pUser;

                /* Index Logging 처리를 한다 */
                _CALL( pInfo->mIndexLogging ( &sCurr->mCurrSlot, aTransID ) );
            }
#endif

            /* non-unique index type bucket 최조 한번 초기화*/
            /***********************************************
             * 변경자 : wind * 변경일 : 15.10.27 * 참고 : #1011
             * 변경 내용 : NU인덱스에 키 입력 시 extrakey 값을 미리 할당 받게 되어 여기서 초기화 하면 안된다.
             ***********************************************/
            //sIndexHeader->mExtra = 0;
        }

        *aCurr = sCurr;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* dbmIdxInsertClear */


/********************************************************************
 * id : mWriteLeaf(static)
 *
 * description
 *    Index Leaf Alloc Slot Leaf write
 *
 * Argument
 *     aSlotID   : output : 사용할 slot ID를 반환한다.
 *     aSlotAddr : output : 사용할 slot의 address 반환한다.
 *     aSegMgr   : input  : dbm Index Segment
 *
********************************************************************/
_VOID dbmIdxWriteLeaf ( long long* aSlotID , char** aSlotAddr , dbmSegmentManager* aSegMgr , dbmIndexHeader* aIndexHeader )
{
    dbmSegmentManager*  sSegMgr = NULL;
    dbmIndexHeader*     sIndexHeader = NULL;
    dbmIndexNode*       sCurr = NULL;
    int     sKeySize;
    long long sSlotID;                // Alloc Slot ID

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        sKeySize = ( g_bIsUniqueIndex ) ? sIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );

        _CALL( dbmSegAllocSlot ( sSegMgr, &sSlotID ) );
        _CALL( sSegMgr->Slot2Addr ( sSlotID, &sCurr ) );

        sCurr->mIndexSlotHeader.mRootFlag = -1;

        _DASSERT( sCurr->mIndexSlotHeader.mLock <= 0 ); // 2014.12.14. -okt- #630 추적 임시코드
        sCurr->mIndexSlotHeader.mLock = -1;

        sCurr->mIndexSlotHeader.mRootSlotID = -1;
        sCurr->mIndexSlotHeader.mLeafNextID = -1;
        sCurr->mIndexSlotHeader.mLeafPrevID = -1;
        sCurr->mIndexSlotHeader.mNodeCount = -1;
        sCurr->mIndexSlotHeader.mLeafcheck = -1;

        //TODO: 2014.11.17 -okt- 다른 곳에서 해주는 것으로 대응되는 것 같아서 막았으나.
        //      --> 이부분은 함부로 바꾸면 안된다고 현웅님. 지적. (원복)
        memset_s ( &sCurr->mRID[0]  , -1, sizeof(long long) * DBM_INDEX_DEGREE );
        memset_s ( &sCurr->mChild[0], -1, sizeof(long long) * DBM_INDEX_DEGREE );
        //sCurr->mRID[0] = -1;
        //sCurr->mChild[0] = -1;

        sCurr->mRoot = -1;
        sCurr->mBtreeCheck = -1;
        sCurr->mCurrSlot = sSlotID;

        //memset_s ( INDEX_POS( sCurr, 0, sKeySize ), 0x00, sKeySize * DBM_INDEX_DEGREE );
        *(int*)INDEX_POS( sCurr, 0, sKeySize ) = 0x00;

        *aSlotAddr = (char*)sCurr;
        *aSlotID = sSlotID;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* dbmIdxWriteLeaf */


/********************************************************************
 * id : mIndexLogging
 *
 * description
 *   Index Logging process
 *   Alloc Slot을 받은 후 해당 값을 로깅해 놓는다.
 *
 * Argument
 *     aSlotID  : input : 로깅할 Slot ID
 *     aTransID : input : Transaction ID
 *
********************************************************************/
_VOID dbmIndexManager::mIndexLogging ( long long* aSlotID , int aTransID )
{
    int             sRC;

    _TRY
    {
        /* 2014.06.19 -shw- Index loggging 관련 free가 필요 없기 때문에 제거 한다 */
#if 0
        /* logging 관련 선언 */
        dbmLogType      sLogType;
        dbmLogHeader*   sLogHead = NULL;

        /* Logging type set */
        sLogType = DBM_ALLOC_IDX_SLOT_LOG;

        /* logging 처리를 한다 */
        _CALL ( mLogMgr->mWriteMemLog( sLogType, aTransID, mIndexID, mIndexName,
                                       mIndexHeader->mIndex.mTableName,
                                       *aSlotID,
                                       NULL,
                                       0,
                                       mIndexHeader,
                                       mIndexHeader,
                                       &sLogHead ) );
#endif
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}


/********************************************************************
 * ID : mInsertPosition(static)
 *
 * Description
 *   dbm Index  key node positio search
 *
 * Argument
 *     aCurr        : output : 해당 key값이 저장되어 있는 NODE의 포인터를 반환한다.
 *     aPosition    : output : binary search로 구한 node안에서의 position
 *     aKey         : input  : input key value
 *     aFound       : output : insert 하기전 동일한 값이 있을경우의 체크값 (1: 존재함)
 *     aIndexHeader : input  : dbm Index Header
 *     aSegMgr      : input  : dbm Index segment
 *
********************************************************************/
_VOID dbmIdxInsertPosition ( dbmIndexNode** aCurr, int* aPosition, char* aKey,
                             int* aFound, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr )
{
    /* NODE 선언 */
    dbmIndexNode*       sCurr;                  // 현재 node pointer
    dbmIndexNode*       sChild;                 // 자식 ndoe pointer
    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;
    int                 sCount;                 // node count

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        sCurr = *aCurr;
        *aFound = 0;

        do /* while */
        {
            /********************************
            * sCurr 현재수행중인 *NODE
            * Key NODE 개수
            * nCount = nElm 개수 key
            *********************************/
            sCount = sCurr->mIndexSlotHeader.mNodeCount;

            if ( sCount == 0 )
            {
                /****************************************************************
                 * root node 초기에는 값이 0일수 있음
                 * node의 개수가 0이다
                 * 자식이 없을 경우에는 결국 root가 최상의 curr pointer 이다
                 *****************************************************************/
                if ( sCurr->mIndexSlotHeader.mLeafcheck == 1 )
                {
                    sChild = NULL;
                }
                else
                {
                    _CALL( sSegMgr->Slot2Addr ( sCurr->mChild[0], &sChild ) );
                    sChild->mCurrSlot = sCurr->mChild[0];
                }
            }
            else
            {
                if ( dbmIdxBinarySearchInLeafNoLock ( sCount, aPosition, sCurr, aKey, sIndexHeader ) != 0 )
                {
                    *aFound = 1;
                    break;
                }

                if ( sCurr->mIndexSlotHeader.mLeafcheck == 1 )
                {
                    sChild = NULL;
                }
                else
                {
                    _CALL( sSegMgr->Slot2Addr ( sCurr->mChild[*aPosition], &sChild ) );
                    sChild->mCurrSlot = sCurr->mChild[*aPosition];
                }
            }

            /* 위의 값에서 sChild 자식 노드값을 구한다 */
            if ( sChild != NULL )
            {
                sChild->mIndexSlotHeader.mRootSlotID = sCurr->mCurrSlot;
                sCurr = sChild;

                /* index child stat check */
                if ( unlikely( sCurr->mCurrSlot < 0 ) ) //, INDEX_STATE_ERROR );
                {
                    DBM_ERR ( "sCount [%d] ", sCount );
                    DBM_ERR ( "index state error root pid[%lld] slot[%lld] root check[%d]",
                           sIndexHeader->mRootPid, sCurr->mCurrSlot, sIndexHeader->mRootAllocCk);
                    _THROW( ERR_DBM_STATE_ERROR );
                }
            }
#ifdef _DEBUG
            else
            {
                /* 자식이 없을 경우에는 결국 root가 최상의 curr pointer 이다 */
            }
#endif
        }
        while ( !*aFound && sChild != NULL );

        /* 변경된 현재노드의 pointer를 이동시켜 준다 */
        *aCurr = sCurr;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
}


/********************************************************************
 * ID : mInsertKeyPush(static)
 *
 * Description
 *    dbm Index  node key insert
 *
 * Argument
 *    aCurr     : input
 *    aTransID
 *    aPosition    : input : node position 가르킨다.
 *    aKey         : input : input key value
 *    aCount       : input : node에 저장되어 있는 key count
 *    aPos         : output: node에 저장된 최종 position 가리킨다.
 *    aDataSlot    : input : Input 처리 해야 할 Data Slot
 *    aIndexHeader : input : dbm Index Header
 *
********************************************************************/
_VOID dbmIdxInsertKeyPush ( dbmIndexNode** aCurr, int aTransID, int* aPosition,
                            char* aKey, int aCount, int* aPos,long long aDataSlot, dbmIndexHeader* aIndexHeader )
{
    /* NODE 선언 */
    dbmIndexNode*   sCurr;          // 현재 node pointer
    dbmIndexHeader* sIndexHeader;
    int     sCount;                 // node count
    int     sKeySize;

    _TRY
    {
        sIndexHeader = aIndexHeader;

        /* 환경값 MOVE */
        sCurr = *aCurr;
        sCount = aCount;

        /* 해당 위치에 바로 삽입 */
        /* key값이 아예 없으면 sPos = 0 */
        if ( sCount == 0 )
        {
            *aPos = 0;
        }
        else
        {
            /* internal이 아닐경우는 위에서 binary search 했기 때문에 다시 할 필요가 없다 */
            if ( sCurr->mIndexSlotHeader.mLeafcheck == 1 )
            {
                *aPos = *aPosition;
            }
            else
            {
                if ( dbmIdxBinarySearchInLeafNoLock ( sCount, aPos, sCurr, aKey, sIndexHeader ) != 0 )
                {
                    mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

                    DBM_ERR( "[Insertion] key [%d] already exists in the Index key", *(int*)aKey );
                    _THROW( ERR_DBM_DUP_ERROR );
                }
            }
        }

        sKeySize = ( g_bIsUniqueIndex ) ? sIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );

        /* 삽입정렬 */
        /* sPos+1[3] , sPos[2], (DBM_INDEX_DEGREE-2)-sPos */
        if ( DBM_INDEX_DEGREE - 2 > *aPos )
        {
            memmove_s ( INDEX_POS( sCurr, *aPos + 1, sKeySize ),
                        INDEX_POS( sCurr, *aPos, sKeySize ),
                        sKeySize * ( ( DBM_INDEX_DEGREE - 2 ) - *aPos ) );
            memmove_s ( &sCurr->mRID[*aPos + 1],
                        &sCurr->mRID[*aPos], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 2 ) - *aPos ) );
            memmove_s ( &sCurr->mChild[*aPos + 2],
                        &sCurr->mChild[*aPos + 1], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 2 ) - *aPos ) );
        }

        // 위에서 내가 삽입할 놈의 저장 공간을 결정해 놓았으니.. 삽입하자...
        /* 삽입 */
        memcpy_s ( INDEX_POS( sCurr, *aPos, sKeySize ), aKey, sKeySize );

        sCurr->mRID[*aPos] = aDataSlot;
        mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );

        // 초기화 한다
        // sKey가 삽입되는 경우는 leaf 뿐임
        sCurr->mChild[*aPos + 1] = -1;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* dbmIdxInsertKeyPush */


/********************************************************************
 * ID : mBinarySearchInLeafNoLock(static)
 *
 * Description
 *   dbm Index key binary search
 *
 * Argument
 *     aCount       : input : Node에 저장되어 있는 key Count
 *     aPosition    : output : key가 저장되어야 할 node의 position 반환한다.
 *     aCurr        : input : Index node pointer
 *     aKey         : input : input Key value
 *     aIndexHeader : input : Index Header
 *
********************************************************************/
// 2014.11.18. -okt- 성능 구간. _TRY .. _CATCH 제거
_VOID dbmIdxBinarySearchInLeafNoLock ( int aCount, int* aPosition, dbmIndexNode* aCurr, char* aKey, dbmIndexHeader* aIndexHeader )
{
    int     sKeySize;
    int     sLow;
    int     sHigh;
    int     sMid;
    int     sRC;

    /* clear */
    sLow = sHigh = sMid = 0;
    sHigh = aCount - 1;

    sKeySize = ( g_bIsUniqueIndex ) ? aIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( aIndexHeader->mIndex.mKeySize );

    while ( sLow <= sHigh )
    {
        // 2014.12.14. -okt- (성능) 나누기
        //sMid = (sLow + sHigh) / 2;
        sMid = ( ( sLow + sHigh ) >> 1 );

        sRC = dbmIdxIndexPosition ( aIndexHeader, aKey, INDEX_POS( aCurr, sMid, sKeySize ) );
        if ( sRC > 0 )
        {
            sHigh = sMid - 1;
        }
        else if ( sRC < 0 )
        {
            sLow = sMid + 1;
        }
        else
        {
            // #919 로그 도배 방지. INSERT DUP은 정상로직에서도 가능하다.
            //같은게 있으면 오류...
            DBM_DBG( "key dup error [%d]", sRC );
            return( RC_FAILURE );
        }
    } /* while(sLow <= sHigh) */

    sRC = dbmIdxIndexCompare ( aIndexHeader, aKey, INDEX_POS( aCurr, sMid, sKeySize ), DBM_GT, 0 );
    if ( sRC )
    {
        *aPosition = sMid;
    }
    else
    {
        *aPosition = sMid + 1;
    }

    return 0;
} /* dbmIdxBinarySearchInLeafNoLock */


/********************************************************************
 * ID : mIndexKeyCast(static)
 *
 * Description
 *    dbm Index key key size copy
 *
 * Argument
 *     aNode        : output : 실제 key copy
 *     aKey         : input : input key
 *     aIndexHeader : input : dbm Index header
 *
********************************************************************/
void dbmIdxIndexKeyCast ( char** aNode, char* aKey, dbmIndexHeader* aIndexHeader, long long* aExtraKey)
{
    dbmIndexObject* sIndex = &aIndexHeader->mIndex; // 성능시도
    int     sKeyOffset = 0;
    int     i;

    // 2014.10.01 -okt- (성능) index column 개수 X insert 수 만큼 memcpy
    for ( i = 0; i < sIndex->mColumnCount; i++ )
    {
        memcpy_s ( *aNode + sKeyOffset, aKey + sIndex->mKey[i].mOffset, sIndex->mKey[i].mSize );
        sKeyOffset += sIndex->mKey[i].mSize;
    }

    /* index 맨 마지막에 extra key 값을 넣어준다 */
    if ( g_bIsUniqueIndex == DBM_NON_UNIQUE )
    {
        if( aExtraKey == NULL )
        {
            mvpAtomicInc64 ( &aIndexHeader->mExtra );   // 2014.10.14 -okt- if 한번을 줄이기 위해. 함수내부로 이동
            *(long long*) ( *aNode + sKeyOffset ) = aIndexHeader->mExtra;
        }
        else
        {
            *(long long*) ( *aNode + sKeyOffset ) = *aExtraKey;
        }
    }
} /* dbmIdxIndexKeyCast */


/********************************************************************
 * ID : mInsertAdjust (static)
 *
 * Description
 *    dbm Index insert 처리 할 key 값들을 삽입 정렬 하여  key 값들을 삽입한다.
 *
 * Argument
 *     aCurr        : input,output : index Node pointer
 *     aTransID     : input : Transaction ID
 *     aPos         : input : index key가 저장 되어야 할 포인터
 *     aDataSlot    : input : Input Data slot ID
 *     aKey         : input : input Key value
 *     aIndexHeader : input : dbm Index Header
 *     aLockMgr     : input : dbm Lock Handle
 *
********************************************************************/
_VOID dbmIdxInsertAdjust ( dbmIndexNode** aCurr ,
                           int aTransID ,
                           int aPos ,
                           long long aDataSlot ,
                           char* aKey ,
                           dbmIndexHeader* aIndexHeader ,
                           dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sCurr = NULL;           // 현재 node pointer
    char*               sKey = NULL;
    int                 sKeySize;
    int                 sPos;

    /* 환경값 MOVE */
    sCurr = *aCurr;
    sPos = aPos;
    sKey = aKey;

    sKeySize = ( g_bIsUniqueIndex ) ? aIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( aIndexHeader->mIndex.mKeySize );

    /* 값을 정렬하여 치환해라 */
    /* 기존 key들을 shift     */
    if ( DBM_INDEX_DEGREE - 1 >= aPos )
    {
        memmove_s ( INDEX_POS( sCurr, sPos, sKeySize ),
                    INDEX_POS( sCurr, sPos - 1, sKeySize ),
                    ( sKeySize * ( ( DBM_INDEX_DEGREE ) - sPos ) ) );
        memmove_s ( &sCurr->mRID[sPos], &sCurr->mRID[sPos - 1], sizeof(long long) * ( ( DBM_INDEX_DEGREE ) - sPos ) );
        memmove_s ( &sCurr->mChild[sPos + 1], &sCurr->mChild[sPos], sizeof(long long) * ( ( DBM_INDEX_DEGREE ) - sPos ) );
    }

    /* 삽입 */
    /* 해당 key 와 pinter  삽입한다 */
    // 2014.02.18 -shw- 초기값이 필요가 없기는 하지만 초기화 하는게 좋을것 같아서 다시 푼다. select lock 부분은 다르게 처리 하였다.
    // 2014.02.17 -shw- leaf에서의 mChild 초기화가 필요없고 leaf node가 아니라면 function 종료 후 aPos+1값을 처리한다.
    memcpy_s ( INDEX_POS( sCurr, sPos, sKeySize ), sKey, sKeySize );
    sCurr->mRID[sPos] = aDataSlot;
    sCurr->mChild[sPos + 1] = -1;

    return 0;
} /* dbmIdxInsertAdjust */


/********************************************************************
 * ID : mInsertNewKeyPush(static)
 *
 * Description
 *   Index 새로운 노드 생성하고 key copy 하여 준다.
 *
 * Argument
 *     aCurr    : input : 기존 NODE의 정보 Pointer
 *     aNewNode : output: 신규 NODE의 pointer 정보이다.
 *     aTransID : input : Transaction ID
 *     aPos     : input : 현재 노드의 저장될 position
 *     aKey     : input : Index Key value
 *     aIndexHeader:input:Index Heaer
 *     aSegMgr  : input : Index Segemnt Position
 *     aLockMgr : input : Lock Maanger position
 *
********************************************************************/
_VOID dbmIdxInsertNewKeyPush ( dbmIndexNode** aCurr ,
                               dbmIndexNode** aNewNode ,
                               int aTransID ,
                               int aPos ,
                               char* aKey ,
                               dbmIndexHeader* aIndexHeader ,
                               dbmSegmentManager* aSegMgr ,
                               dbmLockManager* aLockMgr )
{
    /* NODE 선언 */
    dbmIndexNode*       sCurr;                  // 현재 node pointer
    dbmIndexNode*       sNewNode;               // New ndoe pointer
    dbmIndexNode*       sRootChangeNode;        // root change imsi node pointer

    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;

    int     sLeafcheck;
    char*   sKey;                   // key pointer
    int     sPos;                   // node pointer
    int     sPos2;
    int     sCheck = 0;             // node lock check
    int     sKeySize;
    int     sRC;                    // return value
    int     i;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        /* 환경값 MOVE */
        sCurr = *aCurr;
        sNewNode = *aNewNode;
        sKey = aKey;
        sPos = aPos;

        sKeySize = sIndexHeader->mIndex.mKeySize;
        sLeafcheck = sCurr->mIndexSlotHeader.mLeafcheck;

        /* leaf check   */
        if ( sLeafcheck == 1 )
        {
            sNewNode->mIndexSlotHeader.mLeafcheck = 1;
            sPos2 = sPos;
        }
        else
        {
            sNewNode->mIndexSlotHeader.mLeafcheck = -1;
            sPos2 = sPos + 1;
        }

        /* nPos : 3,4 오른쪽 노드 2개 */
        if ( sPos + 1 < DBM_INDEX_DEGREE )
        {
            memmove_s ( INDEX_POS( sNewNode, 0, sKeySize ),
                        INDEX_POS( sCurr, sPos2, sKeySize ),
                        sKeySize * ( DBM_INDEX_DEGREE - sPos2 ) );
            memmove_s ( &sNewNode->mRID[0], &sCurr->mRID[sPos2], sizeof(long long) * ( DBM_INDEX_DEGREE - sPos2 ) );
            memmove_s ( &sNewNode->mChild[0], &sCurr->mChild[sPos2], sizeof(long long) * ( DBM_INDEX_DEGREE - sPos2 ) );

            sNewNode->mIndexSlotHeader.mNodeCount = DBM_INDEX_DEGREE - sPos2;
        }

        //TODO: 2014.10.14 -okt- (성능) 0으로 비교하는게 빠르단다.
        if ( sLeafcheck != 1 )
        {
            for ( i = sPos2; i < DBM_INDEX_DEGREE; ++i )
            {
                /* internal node가 분기가 되면 아래의 internal node 및 leaf rootslotid가 바뀌게 되므로
                 * 위의 부분에서만 move 해준다. */
                _CALL( sSegMgr->Slot2Addr ( sNewNode->mChild[i - sPos2], &sRootChangeNode ) );

                /* sChild Lock process */
                _CALL( mSpinLockLib ( &sRootChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                sRootChangeNode->mIndexSlotHeader.mRootSlotID = sNewNode->mCurrSlot;

                /* 트리 변경이 이루어 졌으니 값을 넣어보자 */
                mvpAtomicInc64 ( &sRootChangeNode->mBtreeCheck );

                /* unlock Process */
                mvpAtomicCas32_s( &sRootChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
            }

            /* output : 2 = 5 */
            sNewNode->mChild[DBM_INDEX_DEGREE - sPos2] = sCurr->mChild[DBM_INDEX_DEGREE];

            /* internal node가 분기가 되면 아래의 internal node 및 leaf rootslotid가 바뀌게 되므로
             * 위의 부분에서만 move 해준다. 마직막 child internal ndoe도 처리해 주어야 한다 */
            _CALL( sSegMgr->Slot2Addr ( sNewNode->mChild[DBM_INDEX_DEGREE - sPos2], &sRootChangeNode ) );

            /* sChild Lock process */
            _CALL( mSpinLockLib ( &sRootChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

            sRootChangeNode->mIndexSlotHeader.mRootSlotID = sNewNode->mCurrSlot;

            /* 트리 변경이 이루어 졌으니 값을 넣어보자 */
            mvpAtomicInc64 ( &sRootChangeNode->mBtreeCheck );

            /* unlock Process */
            mvpAtomicCas32_s( &sRootChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
        }

        /* sCurr를 clear한 후 sOverflow의 1st half를 copy */
        /* split 처리 후 중간 나머지 값들을 초기화 해준다 */
        memset_s ( &sCurr->mRID[sPos], 0x00, sizeof(long long) * ( DBM_INDEX_DEGREE - sPos ) );
        memset_s ( &sCurr->mChild[sPos2], -1, sizeof(long long) * ( DBM_INDEX_DEGREE - sPos2 ) );
        memset_s ( INDEX_POS( sCurr, sPos, sKeySize ), 0x00, sKeySize * ( DBM_INDEX_DEGREE - sPos ) );
        //TODO: 2014.11.17 -okt- 여기 memset도 없애고 싶으나, dbmIdxWriteLeaf 경우와는 달리 안될듯 같다. (확인요)
        //      그런데. 이 부분은 한건 마다 불리는 경우라서 효과는 더 클것 같은데.. 위험하다. 혹시 빼기 결과가 0일수도 있을것 같고.
//        sCurr->mRID[sPos] = 0x00;
//        sCurr->mChild[sPos2] = -1;
//        *(int*)INDEX_POS( sCurr, sPos, sKeySize ) = 0x00;

        //sCurr->mIndexSlotHeader.mNodeCount = 0; // 2014.10.14 -okt- 막음
        /* DGREE-1 : 4 */
        sCurr->mChild[DBM_INDEX_DEGREE - 1] = -1;

        /* 2개 노드로 split 처리 한다 */
        /* 왼쪽노드 2개 오른쪽 노드2개 가운데 1개 */
        /* 왼쪽노드 2개 */
        /* sPos : 2 */
        /* sCurr left 노드 2개 */
        /* sPos는 위에서 중간값을 구했음 */
        // 2014.04.03 -shw for문 필요 없어서 수정.
        sCurr->mIndexSlotHeader.mNodeCount = sPos;


        /* 트리 변경이 이루어 졌으니 값을 넣어보자 */
        mvpAtomicInc64 ( &sCurr->mBtreeCheck );
        mvpAtomicInc64 ( &sNewNode->mBtreeCheck );

    }
    _CATCH
    {
        _CATCH_WARN;

        {
#if 0 // 2014.09.18 (OKT_L0) 중복 락 처리 제거
            /* leaf unlock 처리  */
            mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
            mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
#endif
        }
    }
    _FINALLY
    _END
} /* dbmIdxInsertNewKeyPush */


/********************************************************************
 * ID : mInsertLeafAdjust(static)
 *
 * Description
 *   dbm Index node에서 DEGREE FULL이라서 분기 처리 하는 부분의
 *   처리를 한다.
 *
 * Argument
 *     aCurr          : split 되어 있는 기존 노드 정보의 pointer
 *     aNewNode       : 신규로 생성 된 노드의 pointer
 *     aInkey         : 임시로 저장하는 Node Key Pointer
 *     aKey           : input : Input Data Key
 *     aDataSlot      : input : Data slot ID
 *     dbmIndexHeader : input : dbm Index Header
 *     aSegMgr        : input : Index Segment Pointer
 *
********************************************************************/
_VOID dbmIdxInsertLeafAdjust ( dbmIndexNode** aCurr, dbmIndexNode** aNewNode, dbmIndexNode** aInkey, char* aKey,
                             long long aDataSlot, int aTransID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr)
{
    /* NODE 선언 */
    dbmIndexNode*       sCurr = NULL;            // 현재 node pointer
    dbmIndexNode*       sNewNode = NULL;         // New ndoe pointer
    dbmIndexNode*       sInkey = NULL;           // root Insert kye pointer
    dbmIndexHeader*     sIndexHeader = NULL;

    dbmIndexNode*       sNextNode = NULL;        // root change imsi node pointer
    dbmIndexNode*       sCurrNode = NULL;
    dbmSegmentManager*  sSegMgr = NULL;

    long long sDataSlot;              // key data
    char*   sKeyData = NULL;        // key pointer
    int     sKeySize;
    int     sRC;                    // return value

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        /* 환경값 MOVE */
        sCurr = *aCurr;
        sNewNode = *aNewNode;
        sInkey = *aInkey;
        sKeyData = aKey;
        sDataSlot = aDataSlot;

        /**********************************************************************************
         * sInkey 생성하여 key 및 child 삽입
         * sInkey node 하나 생성하여 kery 값을 삽입하고 양쪽 포인터를 넣어두어 key가 개인
         * 노드처럼 사용하도록 하였다
         * sInkey->mElm[0] = nKey 가 부모 key가 된다
         * 임시 key 값을 저장한다
         * 이렇게 생성한 놈의 앞으로 root가 된다
         ***********************************************************************************/

        /* root key move */
        sKeySize = ( g_bIsUniqueIndex ) ? sIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );
        memcpy_s ( INDEX_POS( sInkey, 0, sKeySize ), sKeyData, sKeySize );

        sInkey->mRID[0] = sDataSlot;
        sInkey->mChild[0] = sCurr->mCurrSlot;
        sInkey->mChild[1] = sNewNode->mCurrSlot;

        /* 새로 생긴 leaf right slot 에 관련된 부분이다 */
        /* root flag */
        sNewNode->mIndexSlotHeader.mRootFlag = 0;
        /* 1:root slot 0:non-root slot */
        sNewNode->mIndexSlotHeader.mRootSlotID = sCurr->mIndexSlotHeader.mRootSlotID;
        /* next leaf id */
        /* 중간에 삽이 시 기존에 Next Node의 ID를 연결 시켜주어야 한다  */
        sNewNode->mIndexSlotHeader.mLeafNextID = sCurr->mIndexSlotHeader.mLeafNextID;
        /* prev leaf id */
        sNewNode->mIndexSlotHeader.mLeafPrevID = sCurr->mCurrSlot;

        /* Curr slot Header info set */
        /* 1:root slot 0:non-root slot */
        sCurr->mIndexSlotHeader.mRootFlag = 0;
        /* next leaf id */
        sCurr->mIndexSlotHeader.mLeafNextID = sNewNode->mCurrSlot;


        /* prev leaf id */
        /* curr이 가지고 있던 Next node의 Prev node 번호를 새로 생긴 놈으로 바꾸어야 한다. */
        if ( sNewNode->mIndexSlotHeader.mLeafNextID >= 0 )
        {
            _CALL( sSegMgr->Slot2Addr ( sNewNode->mIndexSlotHeader.mLeafNextID, &sNextNode ) );

            /******************************************
             * search key node 와 경합해야 한다
             * leaf spin lock 처리
             *******************************************/
            _CALL( mSpinLockLib( &sNextNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

            sNextNode->mIndexSlotHeader.mLeafPrevID = sNewNode->mCurrSlot;

            /* 트리 변경이 이루어 졌으니 값을 넣어보자 */
            mvpAtomicInc64 ( &sNextNode->mBtreeCheck );

            mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID );
        }

        /*************************************************************************************
         * 거슬러 올라가며 삽입 반복
         * 처음 수행할때는 상관이 없지만 이전 root가 있다면 그 위에 root에 같이 만들어 주어야
         * 하기 때문에 stack을 이용하여 기존 root의 포인터를 찾는 과정이다
         * 부모 node로 올려 보냄
         **************************************************************************************/

        /****************************************************
         * sCurr에 stack
         * 에 있는 sCurr 정보를 넘겨준다...
         * 요 sCurr이라는 놈은 root의 [0][3]의 값이다...
         *****************************************************/

        /* 트리 변경이 이루어 졌으니 값을 넣어보자 */
        mvpAtomicInc64 ( &sCurr->mBtreeCheck );
        mvpAtomicInc64 ( &sNewNode->mBtreeCheck );

//        /*********************************************
//         * leaf unlock 처리
//         *********************************************/
//        mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
//        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

        _CALL( sSegMgr->Slot2Addr ( sCurr->mIndexSlotHeader.mRootSlotID, &sCurrNode ) );
//        if ( sRC || sCurrNode == NULL ) //, SLOT2ADDR_FAIL2 );
//        {
//            DBM_ERR ( "Slot2Addr faile2 rc=%d, addr=%p", sRC, sCurrNode );
//            return ERR_DBM_SLOT2ADDR_FAIL;  // 의도적
//        }

        *aCurr = sCurrNode;
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    {
        mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
    }
    _END
} /* mInsertLeafAdjustLib */


/********************************************************************
 * ID : mInsertLeafNewAdjust (static)
 *
 * Description
 *   dbm Index node에서 DEGREE FULL이라서 분기 처리 하는 부분의
 *   처리를 한다.(NEW)
 *
 * Argument
 *     aCurr        : input : 기존 노드를 가리키고 있는 Pointer
 *     aNewNode     : input : 신규 노드를 가리키고 있는 pointer
 *     aInkey       : input : 임시로 저정되어 있는 노드의 pointer
 *     aKey         : input : Input Key value
 *     aDataSlot    : input : Data Slot ID
 *     aTransID     : input : Transaction ID
 *     aSlotID      : input : 신규로 생성한 Index Slot ID
 *     aIndexHeader : input : Index Header
 *
********************************************************************/
_VOID dbmIdxInsertLeafNewAdjust ( dbmIndexNode** aCurr, dbmIndexNode** aNewNode, dbmIndexNode** aInkey, char* aKey,
                                long long aDataSlot, int aTransID, long long aSlotID, dbmIndexHeader* aIndexHeader, dbmLockManager* aLockMgr)
{
    /* NODE 선언 */
    dbmIndexNode*       sCurr = NULL;           // 현재 node pointer
    dbmIndexNode*       sNewNode = NULL;        // New ndoe pointer
    dbmIndexNode*       sInkey = NULL;          // root Insert kye pointer
    dbmIndexHeader*     sIndexHeader = NULL;

    long long           sSlotID;                // Alloc Slot ID
    long long           sDataSlot;              // key data
    char*               sKeyData = NULL;        // key pointer
    int                 sRC;                    // return value

    _TRY
    {
        sIndexHeader = aIndexHeader;

        /* 환경값 MOVE */
        sCurr = *aCurr;
        sNewNode = *aNewNode;
        sInkey = *aInkey;
        sKeyData = aKey;
        sDataSlot = aDataSlot;
        sSlotID = aSlotID;

        sRC = mSpinLockLib( &sInkey->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr );
        if ( sRC ) //, LEAF_LOCK_ERROR );
        {
            DBM_ERR ( "leaf lock error [%d][%d]", sRC, sNewNode->mIndexSlotHeader.mLock );

            mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
            mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

            _THROW( ERR_DBM_LOCK_FAIL );
        }

        sInkey->mCurrSlot = sSlotID;
        sInkey->mIndexSlotHeader.mNodeCount = 0;

        //DBM_DBG ("test");
        /* 2014.04.03 -shw sDepth Count */
        mvpAtomicInc32 ( &sIndexHeader->mDepthNo );

        /*************************************************************************************
         * 중요 : 이때에만 root가 생성되면서 분기 처리가된다
         * sInkey 생성하여 key 및 child 삽입
         * sInkey node 하나 생성하여 kery 값을 삽입하고 양쪽 포인터를 넣어두어 key가 개인
         * 노드처럼 사용하도록 하였다
         * sInkey->mElm[0] = nKey 가 부모 key가 된다
         * 임시 key 값을 저장한다
         * 이렇게 생성한 놈의 앞으로 root가 된다
         * Alloc Slot & address
         **************************************************************************************/

        /* 새로 생긴 leaf right slot 에 관련된 부분이다 */
        /* root flag */
        sNewNode->mIndexSlotHeader.mRootFlag = 0;
        /* 1:root slot 0:non-root slot */
        sNewNode->mIndexSlotHeader.mRootSlotID = sSlotID;
        /* next leaf id */
        sNewNode->mIndexSlotHeader.mLeafNextID = -1;
        /* prev leaf id */
        sNewNode->mIndexSlotHeader.mLeafPrevID = sCurr->mCurrSlot;
        /* leaf check   */
        if ( sCurr->mIndexSlotHeader.mLeafcheck == 1 )
        {
            sNewNode->mIndexSlotHeader.mLeafcheck = 1;
        }
        else
        {
            sNewNode->mIndexSlotHeader.mLeafcheck = -1;
        }

        /* Curr slot Header info set */
        /* 1:root slot 0:non-root slot */
        sCurr->mIndexSlotHeader.mRootFlag = 0;
        /* 1:root slot 0:non-root slot */
        sCurr->mIndexSlotHeader.mRootSlotID = sSlotID;
        /* next leaf id */
        sCurr->mIndexSlotHeader.mLeafNextID = sNewNode->mCurrSlot;
        /* prev leaf id */
        //sCurr->mIndexSlotHeader.mLeafPrevID = -1;
        /* leaf check */
        if ( sCurr->mIndexSlotHeader.mLeafcheck == 1 )
        {
            sCurr->mIndexSlotHeader.mLeafcheck = 1;
        }
        else
        {
            sCurr->mIndexSlotHeader.mLeafcheck = -1;
        }

        /* root slot Header info set */
        sInkey->mIndexSlotHeader.mRootFlag = 1; /* 1:root slot 0:non-root slot */
        /* 1:root slot 0:non-root slot */
        //sInkey->mIndexSlotHeader.mRootSlotID = SlotID;
        sInkey->mIndexSlotHeader.mRootSlotID = -1;
        /* next leaf id */
        sInkey->mIndexSlotHeader.mLeafNextID = -1;
        /* prev leaf id */
        sInkey->mIndexSlotHeader.mLeafPrevID = -1;
        /* leaf check */
        sInkey->mIndexSlotHeader.mLeafcheck = -1;
        /* Btree Check value 초기화 */
        sInkey->mBtreeCheck = 0;
        /* Btree 조정가 증가 */
        mvpAtomicInc64 ( &sInkey->mBtreeCheck );

        /* root key move */
        sIndexHeader->mRootPid = sSlotID;

        /* mInkey data set */
        int sKeySize = ( g_bIsUniqueIndex ) ? sIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );
        memcpy_s ( INDEX_POS( sInkey, 0, sKeySize ), sKeyData, sKeySize );

        sInkey->mRID[0] = sDataSlot;
        mvpAtomicInc32 ( &sInkey->mIndexSlotHeader.mNodeCount );
        sInkey->mChild[0] = sCurr->mCurrSlot;
        sInkey->mChild[1] = sNewNode->mCurrSlot;

        /* Tree 레벨 증가 */
        /* pInkey가 새 root가 됨 */
        sCurr->mRoot = 0;
        sInkey->mRoot = 1;

        /* 트리 변경이 이루어 졌으니 값을 넣어보자 */
        mvpAtomicInc64 ( &sCurr->mBtreeCheck );
        mvpAtomicInc64 ( &sNewNode->mBtreeCheck );
        mvpAtomicInc64 ( &sInkey->mBtreeCheck );

        /*********************************************
         * leaf unlock 처리
         *********************************************/
        mvpAtomicCas32_s( &sInkey->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );  // 상위단에서 락
        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );     // 상위단에서 락
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mInsertLeafNewAdjustLib */


/********************************************************************
 * ID : mInsertNonNewKeyPush(static)
 *
 * Description
 *   non-unique Index 새로운 노드 생성하고 key copy 하여 준다.
 *
 * Argument
 *     aCurr    : input : 기존 NODE의 정보 Pointer
 *     aNewNode : output: 신규 NODE의 pointer 정보이다.
 *     aTransID : input : Transaction ID
 *     aPos     : input : 현재 노드의 저장될 position
 *     aKey     : input : Index Key value
 *     aIndexHeader:input:Index Heaer
 *     aSegMgr  : input : Index Segemnt Position
 *     aLockMgr : input : Lock Maanger position
 *
********************************************************************/
_VOID dbmIdxInsertNewKeyPushNu ( dbmIndexNode** aCurr ,
                                  dbmIndexNode** aNewNode ,
                                  int aTransID ,
                                  int aPos ,
                                  char* aKey ,
                                  dbmIndexHeader* aIndexHeader ,
                                  dbmSegmentManager* aSegMgr ,
                                  dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sCurr;                  // 현재 node pointer
    dbmIndexNode*       sNewNode;               // New ndoe pointer
    dbmIndexNode*       sRootChangeNode;        // root change imsi node pointer
    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;

    int     sLeafcheck;
    char*   sKey;                   // key pointer
    int     sPos;                   // node pointer
    int     sPos2;
    int     sKeySize;
    int     sRC;                    // return value
    int     i;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        /* 환경값 MOVE */
        sCurr = *aCurr;
        sNewNode = *aNewNode;
        sKey = aKey;
        sPos = aPos;

        sKeySize = INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );
        sLeafcheck = sCurr->mIndexSlotHeader.mLeafcheck;

        /******************************************
         * search key node 와 경합해야 한다
         * leaf spin lock 처리
         *******************************************/
        // 2014.10.01 -okt- dbmIdxInsertKey 상위에서 락을 잡고 들어온다.
//        _CALL( mSpinLockLib ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
//        _CALL( mSpinLockLib ( &sNewNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

        /* leaf check   */
        if ( sLeafcheck == 1 )
        {
            sNewNode->mIndexSlotHeader.mLeafcheck = 1;
            sPos2 = sPos;
        }
        else
        {
            sNewNode->mIndexSlotHeader.mLeafcheck = -1;
            sPos2 = sPos + 1;
        }

        /* nPos : 3,4 오른쪽 노드 2개 */
        if ( sPos + 1 <= DBM_INDEX_DEGREE )
        {
            memmove_s ( INDEX_POS( sNewNode, 0, sKeySize ),
                        INDEX_POS( sCurr, sPos2, sKeySize ), sKeySize * ( DBM_INDEX_DEGREE - sPos2 ) );
            memmove_s ( &sNewNode->mRID[0], &sCurr->mRID[sPos2], sizeof(long long) * ( DBM_INDEX_DEGREE - sPos2 ) );
            memmove_s ( &sNewNode->mChild[0], &sCurr->mChild[sPos2], sizeof(long long) * ( DBM_INDEX_DEGREE - sPos2 ) );

            sNewNode->mIndexSlotHeader.mNodeCount = DBM_INDEX_DEGREE - sPos2;
        }

        if ( sLeafcheck != 1 )
        {
            for ( i = sPos2; i < DBM_INDEX_DEGREE; ++i )
            {
                /* internal node가 분기가 되면 아래의 internal node 및 leaf rootslotid가 바뀌게 되므로
                 * 위의 부분에서만 move 해준다. */
                _CALL( sSegMgr->Slot2Addr ( sNewNode->mChild[i - sPos2], &sRootChangeNode ) );

                /* sChild Lock process */
                _CALL( mSpinLockLib ( &sRootChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                sRootChangeNode->mIndexSlotHeader.mRootSlotID = sNewNode->mCurrSlot;

                /* 트리 변경이 이루어 졌으니 값을 넣어보자 */
                mvpAtomicInc64 ( &sRootChangeNode->mBtreeCheck );

                /* unlock Process */
                mvpAtomicCas32_s( &sRootChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
            }

            /* output : 2 = 5 */
            sNewNode->mChild[DBM_INDEX_DEGREE - sPos2] = sCurr->mChild[DBM_INDEX_DEGREE];

            /* internal node가 분기가 되면 아래의 internal node 및 leaf rootslotid가 바뀌게 되므로
             * 위의 부분에서만 move 해준다. 마직막 child internal ndoe도 처리해 주어야 한다 */
            _CALL( sSegMgr->Slot2Addr ( sNewNode->mChild[DBM_INDEX_DEGREE - sPos2], &sRootChangeNode ) );

            /* sChild Lock process */
            _CALL( mSpinLockLib ( &sRootChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

            sRootChangeNode->mIndexSlotHeader.mRootSlotID = sNewNode->mCurrSlot;

            /* 트리 변경이 이루어 졌으니 값을 넣어보자 */
            mvpAtomicInc64 ( &sRootChangeNode->mBtreeCheck );

            /* unlock Process */
            mvpAtomicCas32_s( &sRootChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
        }


        /* sCurr를 clear한 후 sOverflow의 1st half를 copy */
        /* split 처리 후 중간 나머지 값들을 초기화 해준다 */
        memset_s ( INDEX_POS( sCurr, sPos, sKeySize ), 0x00, sKeySize * ( DBM_INDEX_DEGREE - sPos ) );
        memset_s ( &sCurr->mRID[sPos], 0, sizeof(long long) * ( DBM_INDEX_DEGREE - sPos ) );
        memset_s ( &sCurr->mChild[sPos2], -1, sizeof(long long) * ( DBM_INDEX_DEGREE - sPos2 ) );

        //sCurr->mIndexSlotHeader.mNodeCount = 0;
        sCurr->mChild[DBM_INDEX_DEGREE - 1] = -1; // DGREE-1 : 4


        /* 2개 노드로 split 처리 한다 */
        /* 왼쪽노드 2개 오른쪽 노드2개 가운데 1개 */
        /* 왼쪽노드 2개 */
        /* sPos : 2 */
        /* sCurr left 노드 2개 */
        /* sPos는 위에서 중간값을 구했음 */
        // 2014.04.03 -shw for문 필요 없어서 수정.
        sCurr->mIndexSlotHeader.mNodeCount = sPos;

        /* 트리 변경이 이루어 졌으니 값을 넣어보자 */
        mvpAtomicInc64 ( &sCurr->mBtreeCheck );
        mvpAtomicInc64 ( &sNewNode->mBtreeCheck );
    }
    _CATCH
    {
        _CATCH_WARN;

        //TODO: 2014.10.01 -okt- 상위단에서 풀어준다. 필요없을듯. mLeafcheck 의 의미는?
#if 0
        /* leaf unlock 처리  */
        if ( sCurr->mIndexSlotHeader.mLeafcheck == 1 )
        {
            mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
        }

        if ( sNewNode->mIndexSlotHeader.mLeafcheck == 1 )
        {
            mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
        }
#endif
    }
    _FINALLY
    _END
} /* dbmIdxInsertNewKeyPushNu */


/********************************************************************
 * ID : mInsertCheck
 *
 * Description
 *   dbm Index Insert 처리 시 체크 로직
 *
 * Argument
 *     aTransID     : input : Transacton ID
 *     aLockMgr     : input : Lock Maanger pointer
 *     aIndexHeader : input : Index Segemnt Position
 *
********************************************************************/
_VOID dbmIdxInsertCheck ( int aTransID , dbmIndexHeader* aIndexHeader )
{
    dbmIndexHeader* sIndexHeader = aIndexHeader;

    _TRY
    {
        _DASSERT( sIndexHeader != NULL );

        if ( unlikely( sIndexHeader->mIndex.mKeySize > DBM_INDEX_KEY_MAX_SIZE ) )
        {
            DBM_ERR( "Index Key Max Size error [%d]", sIndexHeader->mIndex.mKeySize );
            _THROW( ERR_DBM_KEY_MAX_SIZE_FAIL );
        }

        /* index Operation 검증 */
        if ( unlikely( sIndexHeader->mCurrStep != 0 ) )
        {
            /* leaf 상태가 이상하니... lock건 놈을 풀어주고... error 리턴하자 */
            /* unlock */
            DBM_ERR( "index Curr State ERROR Index Rebulid Request !!! step [%d] lock[%d]",
                      sIndexHeader->mCurrStep, sIndexHeader->mLock );
            _DASSERT( 0 );
            _THROW( ERR_DBM_CURR_STAT_FAIL );
        }

        /* Index Insert key Start 상태 변경 */
        sIndexHeader->mCurrStep = 1;
        sIndexHeader->mTreeCheck = 0;
    }
    _CATCH
    {
        //_CATCH_WARN;
    }
    _FINALLY
    _END
} /* dbmIdxInsertCheck */

