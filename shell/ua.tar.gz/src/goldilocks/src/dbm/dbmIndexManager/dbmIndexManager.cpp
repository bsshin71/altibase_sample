/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 * Index 관련되어 처리 하는 Source 이다.
*******************************************************************************/
#include "dbmIndexManagerInterface.h"
#include "dbmHeader.h"


/********************************************************************
 * ID : dbmIndexManager
 *
 * Description
 *   소멸자
 *
********************************************************************/
dbmIndexManager::dbmIndexManager()
{
    mIndexID        = 0;
    mIndexHeader    = NULL;
    mSegMgr         = NULL;
    mLogMgr         = NULL;
    mLockMgr        = NULL;
    mRoot           = NULL;
    memset_s ( mIndexName, 0, sizeof(mIndexName) );

    mSkipCompareKeysize = -1;
} /* End of dbmIndexManager() */


/********************************************************************
 * ID : dbmIndexManager
 *
 * Description
 *   소멸자
 *
********************************************************************/
dbmIndexManager::~dbmIndexManager()
{
    delete_s( mSegMgr );
} /* End of ~dbmIndexManager() */


/********************************************************************
 * ID : mIndexManageer
 *
 * Description
 * index logfile wriete Handle 선언
 *
 * Argument
 *     aIndexName : input : input Index Name
 *     aLogMgr    : input : Index Log Manager Handle 객체 선언
 *     aLockMgr   : input : Index Lock Manager Handle 객체 선언
 *
********************************************************************/
_VOID dbmIndexManager::mInitIndex ( char* aInstName , char* aIndexName , dbmLogManager* aLogMgr , dbmLockManager* aLockMgr )
{
    _TRY
    {
        mLogMgr  = aLogMgr;
        mLockMgr = aLockMgr;

        _CALL( dbmSegmentManager::Attach(aInstName, aIndexName, &mSegMgr ) );

        memset_s( mInstName, 0x00, DBM_NAME_LEN );
        memset_s( mIndexName, 0x00, DBM_NAME_LEN );
        strcpy_s( mIndexName, aIndexName );

        mIndexHeader = (dbmIndexHeader*)mSegMgr->GetUserHeader();
        if ( mIndexHeader->mInitCompleteF != 1 ) //, INVALID_HEADER );
        {
            _THROW( ERR_DBM_INVALID_HEADER );
        }

        mIndexID = mIndexHeader->mIndex.mIndexID;

        mIndexHeader->mPID = gettid_s ();
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mInitIndex */


int dbmIndexManager::mIndexCompare ( char* aNode , char* aKey , dbmSignType aKeyCheckType )
{
    return dbmIdxIndexCompare ( this->mIndexHeader, aNode, aKey, aKeyCheckType, 0 );
}

int dbmIndexManager::mIndexPosition ( char* aNode , char* aKey )
{
    return dbmIdxIndexPosition ( this->mIndexHeader, aNode, aKey );
}


_VOID mSpinLockLib ( volatile void* aLock , volatile int* aFutex , int aMyID, dbmLockManager* aLockMgr )
{
    int sRC;

    if ( aLockMgr == NULL )
        sRC = dbmLockManager::mSpinLock( aLock, aFutex, aMyID );
    else
        sRC = aLockMgr->mSpinLock( aLock, aFutex, aMyID );

    return sRC;
}

_VOID mSpinUnlockLib ( volatile void* aLock , volatile int* aFutex , int aMyID, dbmLockManager* aLockMgr )
{
    int sRC;

    if ( aLockMgr == NULL )
        sRC = dbmLockManager::mSpinUnlock( aLock, aFutex, aMyID );
    else
        sRC = aLockMgr->mSpinUnlock( aLock, aFutex, aMyID );

    return sRC;
}


/********************************************************************
 * id : mIndexCompare
 *
 * description
 *   dbm index node에 같은 key 값이 들어 있는지 체크 한다.
 *
 * type : 0  NODE 같은 값이 있는지 체크
 *        1  NODE 작은 값이 있는지 체크
 *        2  NODE 큰 값이 있는지 체크
 *        2번째 arguement 값을 기준으로 비교
 *
 * Argument
 *     aNode          : input : 비교 대상값이 저장되어 있는 Pinter
 *     aKey           : input : Input Key value
 *     aKeyCheckType  : input : Key 비교 Check value
 *     aIndexHeader   : input : dbm Index header
 *
********************************************************************/
// [주의] select 성능 중요 함수
int dbmIdxIndexCompare ( dbmIndexHeader* aIndexHeader, char* aNode, char* aKey, dbmSignType aKeyCheckType, int aEQCnt )
{
    dbmColumnObject* sKey;
    int     sKeyOffset = 0;
    int     sCheckValue = 0; // 컴파일 워닝 제거
    int     sColumnCount2;
    int     sEQCnt = aEQCnt;
    int     ix;

//    _TRY
    {
        _DASSERT( aIndexHeader != NULL );
        _DASSERT( aNode != NULL );
        //if ( aNode == NULL ) return 0; // NODE-.mElm[i] key 값에 입력받은 킥밧이 있으면 return 1 없으면 return 0

        sKey = aIndexHeader->mIndex.mKey;
        sColumnCount2 = aIndexHeader->mIndex.mColumnCount - 1;

        /********************************************
         * key 값 비교시 char -> colsize 만큼 비교
         * 숫자는 precision 만큼 비교 한다
         ********************************************/
        for ( ix = 0; ix <= sColumnCount2; ix++ )
        {
            switch ( sKey[ix].mColumnType )
            {
                case DBM_COLUMN_CHAR_TYPE:
                    /* 0: 같음 0< 작음 0> 큼 */
                    sCheckValue = mIndexCompareString ( aKey + sKeyOffset, aNode + sKeyOffset, sKey[ix].mSize );
                    break;

                case DBM_COLUMN_SHORT_TYPE:
                    sCheckValue = mIndexCompareShort ( aKey + sKeyOffset, aNode + sKeyOffset );
                    break;

                case DBM_COLUMN_INT_TYPE:
                    sCheckValue = mIndexCompareInt ( aKey + sKeyOffset, aNode + sKeyOffset );
                    break;

                case DBM_COLUMN_LONG_TYPE:
                    sCheckValue = mIndexCompareLong ( aKey + sKeyOffset, aNode + sKeyOffset );
                    break;

                    //현재 Double, float, date type key는 없다고 본다.
                    //TODO: 2014.12.14. -okt- 실수의 등호 비교는 DBL_EPSILON 구글 찾아보고 사용하면 가능
                default:
                    DBM_TRC( "Column type not Found type [%d]", sKey[ix].mColumnType );
                    _DASSERT( 0 );
                    break;
            }

            //int mIndexRetCompare ( int aCheckValue , dbmSignType aKeyCheckType , int* aBreakCheck , int ix , int sColumnCount )
            {
                /* 0: 같은가 1:작은가 2:큰가 */
                /* 3: 첫번째 컬럼이 같으면서 2번째 컬럼이 큰가 */
                /* 4: 첫번째 컬럼이 같으면서 2번째 컬럼이 작은가 */
                /* 같은 조건인지 체크 하나라도 같지 않은면 같지 않은거다 */

                if ( sCheckValue != 0 )
                {
                    break;
                }
                // 여기까지 오면 "sCheckValue == 0" 충족

                sKeyOffset = sKeyOffset + sKey[ix].mSize;
                sEQCnt--; // 선행하는 '=' (등호)의 개수를 확인하는 용도

                if ( ix == sColumnCount2 ) // 마지막 컬럼
                {
                    if ( g_bIsUniqueIndex == DBM_NON_UNIQUE ) // 마지막 컬럼
                    {
                        sCheckValue = mIndexCompareLong ( aKey + sKeyOffset, aNode + sKeyOffset );
                    }
                    // 마지막 이어서 어짜피 나간다.
                }
            } /* mIndexRetCompare */
        } /* for */

        //int mIndexRetCheck ( int aCheckValue , dbmSignType aKeyCheckType )
        {
            /* 0: 같은가 1:작은가 2:큰가 */
            /* 같은 조건인지 체크 하나라도 같지 않은면 같지 않은거다 */
            switch ( aKeyCheckType )
            {
                case DBM_EQ:
                    if ( sCheckValue == 0 )
                    {
                        return TRUE; //1;
                    }
                    break;

                case DBM_LT:
                //case DBM_LT2:
                    if ( sEQCnt <= 0 && sCheckValue < 0 )
                    {
                        return TRUE;
                    }
                    break;

                case DBM_GT:
                //case DBM_GT2:
                    if ( sEQCnt <= 0 && sCheckValue > 0 )
                    {
                        return TRUE;
                    }
                    break;

                default:
                    _DASSERT( 0 );
                    break;
            }
        }

        return FALSE;
    }
//    _CATCH
//    _FINALLY
} /* dbmIdxIndexCompare */


/********************************************************************
 * id : mIndexPosition(static)
 *
 * description
 *   dbm Index Position Check
 *   key에 저장되어 있는 type별 해당 값을 체크 한다.
 *
 * Argument
 *     aNode        : input : key가 저장되어 있는 node의 포인터
 *     aKey         : input : Input Key value
 *     aIndexHeader : input : dbm Index Header
 *
********************************************************************/
// [주의] insert 성능 중요 함수
int dbmIdxIndexPosition ( dbmIndexHeader* aIndexHeader, char* aNode , char* aKey )
{
    dbmIndexObject* sIndex;
    char*   sKey        = aKey;
    int     sKeyOffset  = 0;
    int     sRC; // = INT_MIN;
    int     ix;

    _DASSERT( aIndexHeader != NULL );
    _DASSERT( aNode != NULL );
    //if ( aNode == NULL ) return 0; // NODE-.mElm[i] key 값에 입력받은 킥밧이 있으면 return 1 없으면 return 0

    sIndex = &aIndexHeader->mIndex;

    /********************************************
     * key 값 비교시 char -> colsize 만큼 비교
     * 숫자는 precision 만큼 비교 한다
     ********************************************/
    for ( ix = 0; ix < sIndex->mColumnCount; ix++ )
    {
        switch ( sIndex->mKey[ix].mColumnType )
        {
            case DBM_COLUMN_CHAR_TYPE:
                /* char diff */
                /* 0: 같음 0< 작음 0> 큼 */
                sRC = mIndexCompareString ( sKey + sKeyOffset, aNode + sKeyOffset, sIndex->mKey[ix].mSize );
                break;

            case DBM_COLUMN_SHORT_TYPE:
                sRC = mIndexCompareShort ( sKey + sKeyOffset, aNode + sKeyOffset );
                break;

            case DBM_COLUMN_INT_TYPE:
                sRC = mIndexCompareInt ( sKey + sKeyOffset, aNode + sKeyOffset );
                break;

            case DBM_COLUMN_LONG_TYPE:
                sRC = mIndexCompareLong ( sKey + sKeyOffset, aNode + sKeyOffset );
                break;

                //현재 Double , flottype key는 없다고 본다.
            default:
                DBM_TRC( "[FATAL] Column type not Found type [%d]", sIndex->mKey[ix].mColumnType );
                _DASSERT( 0 );
                break;
        }

        /* 첫번째 컬럼이 동일하다면 두번째의 비교값을 가지고 해야 하기 때문에 다음꺼로 비교 하기위해 넘어간다 */
        if ( sRC != 0 )
        {
            return sRC; // 첫번째 값이 비교가 되었기 때문에 나가라
        }

        sKeyOffset = sKeyOffset + sIndex->mKey[ix].mSize;

        if ( g_bIsUniqueIndex == DBM_NON_UNIQUE )
        {
            /* key index 값이 같고 extra 같하고 비교를 해야 한다 */
            if ( ix == ( sIndex->mColumnCount - 1 ) )
            {
                return mIndexCompareLong ( sKey + sKeyOffset, aNode + sKeyOffset );
            }
        }
    } /* for */

    return sRC;
} /* dbmIdxIndexPosition */


/********************************************************************
 * static functions
 *
 * 2014.09.24 (OKT): 정적 함수로 뺄수 있는 부분을 따로 모은다.
 *
********************************************************************/

/********************************************************************
 * id : mIndexCompareString(static)
********************************************************************/
int mIndexCompareString ( char* aKey1, char* aKey2, int aSize )
{
    /* 2014.06.11 -shw0 strncmp_s-> memcmp */
    return memcmp_s ( aKey1, aKey2, aSize );

#if 0
    //TODO: 2014.10.24 -okt- prefech 하고는 싶다. 위치는 100 clock 앞에 두는게 적당하다는 글을 봄 (검증안됨)
    #include <emmintrin.h>
    _mm_prefetch( aKey2, MM_HINT_T0 );
    _mm_load_ps 이런것 사용해 보기
#endif
}

/********************************************************************
 * id : mIndexCompareShort(static)
********************************************************************/
int mIndexCompareShort( char* aKey1, char* aKey2 )
{

    if ( *(short*)aKey1 > *(short*)aKey2 )
        return 1;
    else
    if ( *(short*)aKey1 < *(short*)aKey2 )
        return -1;
    else
        return 0;
}

/********************************************************************
 * id : mIndexCompareInt(static)
********************************************************************/
int mIndexCompareInt( char* aKey1, char* aKey2)
{

    if ( *(int*)aKey1 > *(int*)aKey2 )
        return 1;
    else
    if ( *(int*)aKey1 < *(int*)aKey2 )
        return -1;
    else
        return 0;
}

/********************************************************************
 * id : mIndexCompareLong(static)
********************************************************************/
int mIndexCompareLong ( char* aKey1 , char* aKey2 )
{
    if ( *(long long*) aKey1 > *(long long*) aKey2 )
        return 1;
    else if ( *(long long*) aKey1 < *(long long*) aKey2 )
        return -1;

    return 0;
}


/********************************************************************
 * id : mIndexRetCheck
 *
 * description
 * dbm index node key Chkec 하여 값을 리턴한다.
 * 0: 같은가 1:작은가 2:큰가
 * 3: 첫번째 컬럼이 같으면서 2번째 컬럼이 큰가
 * 4: 첫번째 컬럼이 같으면서 2번째 컬럼이 작은가
 * 같은 조건인지 체크 하나라도 같지 않은면 같지 않은거다
 *
 * Argument
 *     aCheckValue   : input : check 하려고 하는 비교 값
 *     aCheckType    : input : check 하려고 하는 type
 *
********************************************************************/
//int mIndexRetCheck ( int aCheckValue , dbmSignType aKeyCheckType )
//{
//    /* 0: 같은가 1:작은가 2:큰가 */
//    /* 같은 조건인지 체크 하나라도 같지 않은면 같지 않은거다 */
//    switch ( aKeyCheckType )
//    {
//        case DBM_EQ:
//            if ( aCheckValue == 0 )
//            {
//                return TRUE; //1;
//            }
//            break;
//        case DBM_LT:
//        case DBM_LT2:
//            if ( aCheckValue < 0 )
//            {
//                return TRUE;
//            }
//            break;
//        case DBM_GT:
//        case DBM_GT2:
//            if ( aCheckValue > 0 )
//            {
//                return TRUE;
//            }
//            break;
//        default:
//            _DASSERT( 0 );
//            break;
//    }
//
//    return FALSE;
//}


/********************************************************************
 * id : mIndexRetCompare
 *
 * description
 * dbm index node key Chkec 하여 값을 리턴한다.
 * 0: 같은가 1:작은가 2:큰가
 * 3: 첫번째 컬럼이 같으면서 2번째 컬럼이 큰가
 * 4: 첫번째 컬럼이 같으면서 2번째 컬럼이 작은가
 * 같은 조건인지 체크 하나라도 같지 않은면 같지 않은거다
 *
 * Argument
 *     aCheckValue   : input : check 하려고 하는 비교 값
 *     aCheckType    : input : check 하려고 하는 type
 *     aBreakCheck   : output: 조건을 체크하고 종료 관련 처리 플래그
 *     aCount        : input : check key count
 *     aColumnCount  : input : key columnt count
 *
********************************************************************/
//int mIndexRetCompare ( int aCheckValue , dbmSignType aKeyCheckType , int* aBreakCheck , int aCount , int aColumnCount )
//{
//    int     sRet;   // 0: 같음 0< 작음 0> 큼
//
//    /* 초기화 */
//    *aBreakCheck = 0;
//    sRet = aCheckValue;
//
//    /* 0: 같은가 1:작은가 2:큰가 */
//    /* 3: 첫번째 컬럼이 같으면서 2번째 컬럼이 큰가 */
//    /* 4: 첫번째 컬럼이 같으면서 2번째 컬럼이 작은가 */
//    /* 같은 조건인지 체크 하나라도 같지 않은면 같지 않은거다 */
//    switch ( aKeyCheckType )
//    {
//        case DBM_EQ:
//            if ( sRet != 0 )
//            {
//                sRet = -1;
//                *aBreakCheck = 1;
//            }
//            break;
//
//        case DBM_LT:
//            if ( sRet == 0 )
//            {
//                sRet = 0;
//            }
//            else
//            {
//                *aBreakCheck = 1;
//                if ( sRet > 0 )
//                {
//                    sRet = 0;
//                }
//            }
//            break;
//
//        case DBM_GT:
//            if ( sRet == 0 )
//            {
//                sRet = -1;
//            }
//            else
//            {
//                *aBreakCheck = 1;
//                if ( sRet < 0 )
//                {
//                    sRet = -1;
//                }
//            }
//            break;
//
//        case DBM_GT2:
//            // 작은가 부등호 비교
//            if ( aCount < ( aColumnCount - 1 ) )
//            {
//                if ( sRet != 0 )
//                {
//                    // 첫번째 컬럼이 0하고 다르니까 없는 것이다 오류 리턴.
//                    *aBreakCheck = 1;
//                }
//
//                // 첫번째 컬럼 하고 같으니 두번째 컬럼을 비교해 보자
//                sRet = -1;
//            }
//            // 마지막만 비교하면 되니까... i == node-1이 같으면 마지막 이다.
//            else if ( aCount == ( aColumnCount - 1 ) )
//            {
//                if ( sRet > 0 )
//                {
//                    // 크니까 OK
//                    *aBreakCheck = 1;
//                    // 여기에서만 sRet 을 그대로 보내고, 나머지는 -1 이다.
//                }
//                else
//                {
//                    if ( sRet != 0 || g_bIsUniqueIndex != DBM_NON_UNIQUE  ) // non-unique index type 한번더 체크 따로...
//                    {
//                        *aBreakCheck = 1;
//                    }
//                    sRet = -1;
//                }
//            }
//            else
//            {
//                // type 3은 첫번째, 두번째 컬럼을 비교 하는 것이다.
//                sRet = -1;
//                *aBreakCheck = 1;
//            }
//            break;
//
//        case DBM_LT2:
//            // 작은가 부등호 비교
//            if ( aCount < ( aColumnCount - 1 ) )
//            {
//                if ( sRet != 0 )
//                {
//                    // 첫번째 컬럼이 0하고 다르니까 없는 것이다 오류 리턴.
//                    // 작은 값을 비교할 때는 sRC 값이 1인것이 오류 값이다.
//                    *aBreakCheck = 1;
//                }
//
//                // 작은 값을 비교할 때는 sRC 값이 1인것이 오류 값이다.
//                // 첫번째 컬럼 하고 같으니 두번째 컬럼을 비교해 보자
//                sRet = 1;
//            }
//            // 마지막만 비교하면 되니까... i == node-1이 같으면 마지막 이다.
//            else if ( aCount == ( aColumnCount - 1 ) )
//            {
//                if ( sRet < 0 )
//                {
//                    // 작으니까 OK
//                    *aBreakCheck = 1;
//                    // 여기에서만 sRet 을 그대로 보내고, 나머지는 1 이다.
//                }
//                else
//                {
//                    if ( sRet != 0 || g_bIsUniqueIndex != DBM_NON_UNIQUE  ) // non-unique index type 한번더 체크 따로...
//                    {
//                        // 없으면 오류 리턴
//                        *aBreakCheck = 1;
//                    }
//                    sRet = 1;
//                }
//            }
//            else
//            {
//                // type 3은 첫번째, 두번째 컬럼을 비교 하는 것이다.
//                sRet = 1;
//                *aBreakCheck = 1;
//            }
//            break;
//
//        default:
//            _DASSERT( 0 );
//            break;
//    }
//
//    return sRet;
//} /* mIndexRetCompare */


void dbmIndexManager::PrintNodeElement ( dbmIndexNode* pNode )
{
    dbmIndexNode*   pChild;
    dbmIndexNode*   pInter;
    int     sKeySize;
    int     i, j;

    _TRY
    {
        sKeySize = mIndexHeader->mIndex.mKeySize;

        /* Print Post-order */
        if ( pNode->mIndexSlotHeader.mLeafcheck == 1 )
        {
            pChild = NULL;
        }
        else
        {
            _CALL( mSegMgr->Slot2Addr ( pNode->mChild[0], &pChild ) );
        }

        if ( pChild == NULL )
        { /* leaf */
            _PRT( "[ " );
            //DBM_DBG("[ ");
            for ( i = 0; i < pNode->mIndexSlotHeader.mNodeCount; i++ )
            {
                for ( j = 0; j < mIndexHeader->mIndex.mColumnCount; j++ )
                {
                    switch ( mIndexHeader->mIndex.mKey[j].mColumnType )
                    {
                        case DBM_COLUMN_CHAR_TYPE:
                            _PRT( "%s", INDEX_POS( pNode, i, sKeySize ) + mIndexHeader->mIndex.mKey[j].mOffset );

                            break;
                        case DBM_COLUMN_SHORT_TYPE:
                            _PRT( "%d", *(short*) INDEX_POS( pNode, i, sKeySize ) + mIndexHeader->mIndex.mKey[j].mOffset );

                            break;

                        case DBM_COLUMN_INT_TYPE:
                            _PRT( "%d", *(int*) INDEX_POS( pNode, i, sKeySize ) + mIndexHeader->mIndex.mKey[j].mOffset );

                            break;

                        case DBM_COLUMN_LONG_TYPE:
                            _PRT( "%lld", *(long long*) INDEX_POS( pNode, i, sKeySize ) + mIndexHeader->mIndex.mKey[j].mOffset );
                            break;
                        default:
                            DBM_DBG( "Column type not Found type [%d]", mIndexHeader->mIndex.mKey[j].mColumnType );
                            break;
                    }
                }
                _PRT( " " );
            }
            _PRT( "] " );

            _RETURN;
        }

        /* leftmost child 출력 */
        _CALL( mSegMgr->Slot2Addr ( pNode->mChild[0], &pInter ) );

        PrintNodeElement2 ( pInter );

        /* node 내의 key와 other child 출력 */
        for ( i = 1; i < DBM_INDEX_DEGREE; ++i )
        {
            if ( pNode->mChild[i] < 1 )
                pInter = NULL;
            else
            {
                _CALL( mSegMgr->Slot2Addr ( pNode->mChild[i], &pInter ) );
            }

            if ( pInter == NULL )
            {
                _RETURN;
            }

            PrintNodeElement2 ( pInter );

            for ( j = 0; j < mIndexHeader->mIndex.mColumnCount; j++ )
            {
                switch ( mIndexHeader->mIndex.mKey[j].mColumnType )
                {
                    case DBM_COLUMN_CHAR_TYPE:
                        _PRT( "%s", INDEX_POS( pNode, i - 1, sKeySize ) + mIndexHeader->mIndex.mKey[j].mOffset );

                        break;
                    case DBM_COLUMN_SHORT_TYPE:
                        _PRT( "%d",*(short*) INDEX_POS( pNode, i - 1, sKeySize ) + mIndexHeader->mIndex.mKey[j].mOffset );

                        break;

                    case DBM_COLUMN_INT_TYPE:
                        _PRT( "%d", *(int*) INDEX_POS( pNode, i - 1, sKeySize ) + mIndexHeader->mIndex.mKey[j].mOffset );

                        break;

                    case DBM_COLUMN_LONG_TYPE:
                        _PRT( "%lld", *(long long*) INDEX_POS( pNode, i - 1, sKeySize ) + mIndexHeader->mIndex.mKey[j].mOffset );

                        break;
                    default:
                        DBM_DBG( "Column type not Found type [%d]", mIndexHeader->mIndex.mKey[j].mColumnType );
                        break;
                }
                _PRT( " " );
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _ENDVOID
} /* PrintNodeElement */


void dbmIndexManager::PrintNodeElement2 ( dbmIndexNode* pNode )
{
    dbmIndexNode*   pChild;
    dbmIndexNode*   pInter;
    int     sKeySize;
    int     sKeyIndexOffset;
    int     i, j;

    _TRY
    {
        sKeyIndexOffset = 0;
        sKeySize = mIndexHeader->mIndex.mKeySize;

        /* Print Post-order */
        if ( pNode->mIndexSlotHeader.mLeafcheck == 1 )
        {
            pChild = NULL;
        }
        else
        {
            _CALL( mSegMgr->Slot2Addr ( pNode->mChild[0], &pChild ) );
        }

        if ( pChild == NULL )
        { /* leaf */
            _PRT( "[ " );
            //DBM_DBG("[ ");

            for ( i = 0; i < pNode->mIndexSlotHeader.mNodeCount; i++ )
            {
                for ( j = 0; j < mIndexHeader->mIndex.mColumnCount; j++ )
                {

                    switch ( mIndexHeader->mIndex.mKey[j].mColumnType )
                    {
                        case DBM_COLUMN_CHAR_TYPE:
                            _PRT( "%s", INDEX_POS( pNode, i, sKeySize ) + sKeyIndexOffset );

                            break;
                        case DBM_COLUMN_SHORT_TYPE:
                            _PRT( "%d", *(short*) ( INDEX_POS( pNode, i, sKeySize ) + sKeyIndexOffset ) );

                            break;

                        case DBM_COLUMN_INT_TYPE:
                            _PRT( "%d", *(int*) ( INDEX_POS( pNode, i, sKeySize ) + sKeyIndexOffset ) );

                            break;

                        case DBM_COLUMN_LONG_TYPE:
                            _PRT( "%lld", *(long long*) ( INDEX_POS( pNode, i, sKeySize ) + sKeyIndexOffset ) );
                            break;
                        default:
                            DBM_DBG( "Column type not Found type [%d]", mIndexHeader->mIndex.mKey[j].mColumnType );
                            break;
                    }

                    sKeyIndexOffset = sKeyIndexOffset + mIndexHeader->mIndex.mKey[j].mSize;
                }
                _PRT( " " );

                sKeyIndexOffset = 0;
            }
            _PRT( "] " );

            _RETURN;
        }

        /* leftmost child 출력 */
        _CALL( mSegMgr->Slot2Addr ( pNode->mChild[0], &pInter ) );

        PrintNodeElement2 ( pInter );

        /* node 내의 key와 other child 출력 */
        for ( i = 1; i < DBM_INDEX_DEGREE; ++i )
        {
            if ( pNode->mChild[i] < 1 )
                pInter = NULL;
            else
            {
                _CALL( mSegMgr->Slot2Addr ( pNode->mChild[i], &pInter ) );
            }

            if ( pInter == NULL )
            {
                _RETURN;
            }

            PrintNodeElement2 ( pInter );

            sKeyIndexOffset = 0;

            for ( j = 0; j < mIndexHeader->mIndex.mColumnCount; j++ )
            {
                switch ( mIndexHeader->mIndex.mKey[j].mColumnType )
                {
                    case DBM_COLUMN_CHAR_TYPE:
                        _PRT( "%s", INDEX_POS( pNode, i - 1, sKeySize ) + sKeyIndexOffset );
                        break;
                    case DBM_COLUMN_SHORT_TYPE:
                        _PRT( "%d", *(short*) ( INDEX_POS( pNode, i - 1, sKeySize ) + sKeyIndexOffset ) );
                        break;

                    case DBM_COLUMN_INT_TYPE:
                        _PRT( "%d", *(int*) ( INDEX_POS( pNode, i - 1, sKeySize ) + sKeyIndexOffset ) );
                        break;

                    case DBM_COLUMN_LONG_TYPE:
                        _PRT( "%lld", *(long long*) ( INDEX_POS( pNode, i - 1, sKeySize ) + sKeyIndexOffset ) );
                        break;
                    default:
                        DBM_DBG( "Column type not Found type [%d]", mIndexHeader->mIndex.mKey[j].mColumnType );
                        break;
                }
                _PRT( " " );

                sKeyIndexOffset = sKeyIndexOffset + mIndexHeader->mIndex.mKey[j].mSize;
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _ENDVOID
} /* PrintNodeElement2 */


void PrintNodeElement3Lib ( dbmIndexNode* pNode , dbmIndexHeader* aIndexHeader , dbmSegmentManager* aSegMgr )
{
    dbmIndexNode*   pChild;
    dbmIndexNode*   pInter;
    dbmIndexHeader* mIndexHeader;
    dbmSegmentManager* mSegMgr;

    int     sKeySize;
    int     sKeyIndexOffset;
    int     i, j;

    _TRY
    {
        sKeyIndexOffset = 0;

        mIndexHeader = (dbmIndexHeader*) aIndexHeader;
        mSegMgr = (dbmSegmentManager*) aSegMgr;

        sKeySize = mIndexHeader->mIndex.mKeySize;

        /* Print Post-order */
        if ( pNode->mIndexSlotHeader.mLeafcheck == 1 )
        {
            pChild = NULL;
        }
        else
        {
            _CALL( mSegMgr->Slot2Addr ( pNode->mChild[0], &pChild ) );
        }

        if ( pChild == NULL )
        { /* leaf */
            _PRT( "[ " );
            //DBM_DBG("[ ");
            for ( i = 0; i < pNode->mIndexSlotHeader.mNodeCount; i++ )
            {
                for ( j = 0; j < mIndexHeader->mIndex.mColumnCount; j++ )
                {
                    switch ( mIndexHeader->mIndex.mKey[j].mColumnType )
                    {
                        case DBM_COLUMN_CHAR_TYPE:
                            _PRT( "%s", INDEX_POS( pNode, i, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset );
                            break;

                        case DBM_COLUMN_SHORT_TYPE:
                            _PRT( "%d", *(short*) ( INDEX_POS( pNode, i, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset ) );
                            break;

                        case DBM_COLUMN_INT_TYPE:
                            _PRT( "%d", *(int*) ( INDEX_POS( pNode, i, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset ) );
                            break;

                        case DBM_COLUMN_LONG_TYPE:
                            _PRT( "%lld", *(long long*) ( INDEX_POS( pNode, i, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset ) );
                            break;

                        default:
                            DBM_DBG( "Column type not Found type [%d]", mIndexHeader->mIndex.mKey[j].mColumnType );
                            break;
                    }

                    sKeyIndexOffset = sKeyIndexOffset + mIndexHeader->mIndex.mKey[j].mSize;
                }

                _PRT( " " );

                sKeyIndexOffset = 0;
            }
            //fprintf(stdout," current[%lld] mLeafNextID[%lld] ",pNode->mCurrSlot,pNode->mIndexSlotHeader.mLeafNextID);
            _PRT( "] " );

            _RETURN;
        }

        /* leftmost child 출력 */
        _CALL( mSegMgr->Slot2Addr ( pNode->mChild[0], &pInter ) );

        PrintNodeElement3Lib ( pInter, mIndexHeader, mSegMgr );

        /* node 내의 key와 other child 출력 */
        for ( i = 1; i < DBM_INDEX_DEGREE; ++i )
        {
            if ( pNode->mChild[i] < 1 )
                pInter = NULL;
            else
            {
                _CALL( mSegMgr->Slot2Addr ( pNode->mChild[i], &pInter ) );
            }

            if ( pInter == NULL )
            {
                _RETURN;
            }

            PrintNodeElement3Lib ( pInter, mIndexHeader, mSegMgr );

            for ( j = 0; j < mIndexHeader->mIndex.mColumnCount; j++ )
            {
                switch ( mIndexHeader->mIndex.mKey[j].mColumnType )
                {
                    case DBM_COLUMN_CHAR_TYPE:
                        _PRT( "%s", INDEX_POS( pNode, i - 1, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset );
                        break;

                    case DBM_COLUMN_SHORT_TYPE:
                        _PRT( "%d", *(short*) ( INDEX_POS( pNode, i - 1, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset ) );
                        break;

                    case DBM_COLUMN_INT_TYPE:
                        _PRT( "%d", *(int*) ( INDEX_POS( pNode, i - 1, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset ) );
                        break;

                    case DBM_COLUMN_LONG_TYPE:
                        _PRT( "%lld", *(long long*) ( INDEX_POS( pNode, i - 1, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset ) );
                        break;

                    default:
                        DBM_DBG( "Column type not Found type [%d]", mIndexHeader->mIndex.mKey[j].mColumnType );
                        break;
                }
                _PRT( " " );

                sKeyIndexOffset = sKeyIndexOffset + mIndexHeader->mIndex.mKey[j].mSize;
            }

            sKeyIndexOffset = 0;
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _ENDVOID
} /* PrintNodeElement3Lib */


void dbmIndexManager::PrintNodeElement3(dbmIndexNode* pNode)
{
    dbmIndexNode*   pChild;
    dbmIndexNode*   pInter;
    int     sKeySize;
    int     sKeyIndexOffset;
    int     i, j;

    _TRY
    {
        sKeyIndexOffset = 0;
        sKeySize = mIndexHeader->mIndex.mKeySize;

        /* Print Post-order */
        if ( pNode->mIndexSlotHeader.mLeafcheck == 1 )
        {
            pChild = NULL;
        }
        else
        {
            _CALL( mSegMgr->Slot2Addr ( pNode->mChild[0], &pChild ) );
        }

        if ( pChild == NULL )
        { /* leaf */
            _PRT( "[ " );
            //DBM_DBG("[ ");
            for ( i = 0; i < pNode->mIndexSlotHeader.mNodeCount; i++ )
            {
                for ( j = 0; j < mIndexHeader->mIndex.mColumnCount; j++ )
                {
                    switch ( mIndexHeader->mIndex.mKey[j].mColumnType )
                    {
                        case DBM_COLUMN_CHAR_TYPE:
                            _PRT( "%s", INDEX_POS( pNode, i, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset );
                            break;

                        case DBM_COLUMN_SHORT_TYPE:
                            _PRT( "%d", *(short*) INDEX_POS( pNode, i, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset );
                            break;

                        case DBM_COLUMN_INT_TYPE:
                            _PRT( "%d", *(int*) INDEX_POS( pNode, i, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset );
                            break;

                        case DBM_COLUMN_LONG_TYPE:
                            _PRT( "%lld", *(long long*) INDEX_POS( pNode, i, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset );
                            break;

                        default:
                            DBM_DBG( "Column type not Found type [%d]", mIndexHeader->mIndex.mKey[j].mColumnType );
                            break;
                    }

                    sKeyIndexOffset = sKeyIndexOffset + mIndexHeader->mIndex.mKey[j].mSize;
                }
                _PRT( " " );

                sKeyIndexOffset = 0;
            }
            //fprintf(stdout," current[%lld] mLeafNextID[%lld] ",pNode->mCurrSlot,pNode->mIndexSlotHeader.mLeafNextID);
            _PRT( "] " );

            _RETURN;
        }

        /* leftmost child 출력 */
        _CALL( mSegMgr->Slot2Addr ( pNode->mChild[0], &pInter ) );

        PrintNodeElement3 ( pInter );

        /* node 내의 key와 other child 출력 */
        for ( i = 1; i < DBM_INDEX_DEGREE; ++i )
        {
            if ( pNode->mChild[i] < 1 )
                pInter = NULL;
            else
            {
                _CALL( mSegMgr->Slot2Addr ( pNode->mChild[i], &pInter ) );
            }

            if ( pInter == NULL )
            {
                _RETURN;
            }

            PrintNodeElement3 ( pInter );

            for ( j = 0; j < mIndexHeader->mIndex.mColumnCount; j++ )
            {
                switch ( mIndexHeader->mIndex.mKey[j].mColumnType )
                {
                    case DBM_COLUMN_CHAR_TYPE:
                        _PRT( "%s", INDEX_POS( pNode, i - 1, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset );

                        break;
                    case DBM_COLUMN_SHORT_TYPE:
                        _PRT( "%d", *(short*) INDEX_POS( pNode, i - 1, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset );

                        break;

                    case DBM_COLUMN_INT_TYPE:
                        _PRT( "%d", *(int*) INDEX_POS( pNode, i - 1, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset );

                        break;

                    case DBM_COLUMN_LONG_TYPE:
                        _PRT( "%lld", *(long long*) INDEX_POS( pNode, i - 1, INDEX_KEY_SIZE(sKeySize) ) + sKeyIndexOffset );

                        break;
                    default:
                        DBM_DBG( "Column type not Found type [%d]", mIndexHeader->mIndex.mKey[j].mColumnType );
                        break;
                }
                _PRT( " " );

                sKeyIndexOffset = sKeyIndexOffset + mIndexHeader->mIndex.mKey[j].mSize;
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _ENDVOID
} /* PrintNodeElement3 */


void dbmIndexManager::PrintNodeElement4 ( dbmIndexNode* pNode )
{
    dbmIndexNode*   pChild;
    dbmIndexNode*   pInter;
    int     sKeySize;
    int     sKeyIndexOffset;
    int     i, j;

    _TRY
    {
        sKeyIndexOffset = 0;
        sKeySize = mIndexHeader->mIndex.mKeySize;

        /* Print Post-order */
        if ( pNode->mIndexSlotHeader.mLeafcheck == 1 )
        {
            pChild = NULL;
        }
        else
        {
            _CALL( mSegMgr->Slot2Addr ( pNode->mChild[0], &pChild ) );
        }

        if ( pChild == NULL )
        { /* leaf */
            _PRT( "[ " );
            //DBM_DBG("[ ");
            for ( i = 0; i < pNode->mIndexSlotHeader.mNodeCount; i++ )
            {
                for ( j = 0; j < mIndexHeader->mIndex.mColumnCount; j++ )
                {
                    switch ( mIndexHeader->mIndex.mKey[j].mColumnType )
                    {
                        case DBM_COLUMN_CHAR_TYPE:
                            _PRT( "%s", INDEX_POS( pNode, i, sKeySize ) + sKeyIndexOffset );
                            break;

                        case DBM_COLUMN_SHORT_TYPE:
                            _PRT( "%d", *(short*) INDEX_POS( pNode, i, sKeySize ) + sKeyIndexOffset );
                            break;

                        case DBM_COLUMN_INT_TYPE:
                            _PRT( "%d", *(int*) INDEX_POS( pNode, i, sKeySize ) + sKeyIndexOffset );
                            break;

                        case DBM_COLUMN_LONG_TYPE:
                            _PRT( "%lld", *(long long*) INDEX_POS( pNode, i, sKeySize ) + sKeyIndexOffset );
                            break;

                        default:
                            DBM_DBG( "Column type not Found type [%d]", mIndexHeader->mIndex.mKey[j].mColumnType );
                            break;
                    }

                    sKeyIndexOffset = sKeyIndexOffset + mIndexHeader->mIndex.mKey[j].mSize;
                }
                _PRT( " " );

                sKeyIndexOffset = 0;
            }
            _PRT( " current[%lld] mLeafNextID[%lld] ", pNode->mCurrSlot, pNode->mIndexSlotHeader.mLeafNextID );
            _PRT( "] " );

            _RETURN;
        }

        /* leftmost child 출력 */
        _CALL( mSegMgr->Slot2Addr ( pNode->mChild[0], &pInter ) );

        PrintNodeElement4 ( pInter );

        /* node 내의 key와 other child 출력 */
        for ( i = 1; i < DBM_INDEX_DEGREE; ++i )
        {
            if ( pNode->mChild[i] < 1 )
                pInter = NULL;
            else
            {
                _CALL( mSegMgr->Slot2Addr ( pNode->mChild[i], &pInter ) );
            }

            if ( pInter == NULL )
            {
                _RETURN;
            }

            PrintNodeElement4 ( pInter );

            for ( j = 0; j < mIndexHeader->mIndex.mColumnCount; j++ )
            {
                switch ( mIndexHeader->mIndex.mKey[j].mColumnType )
                {
                    case DBM_COLUMN_CHAR_TYPE:
                        _PRT( "%s", INDEX_POS( pNode, i - 1, sKeySize ) + sKeyIndexOffset );
                        break;

                    case DBM_COLUMN_SHORT_TYPE:
                        _PRT( "%d", *(short*) INDEX_POS( pNode, i - 1, sKeySize ) + sKeyIndexOffset );
                        break;

                    case DBM_COLUMN_INT_TYPE:
                        _PRT( "%d", *(int*) INDEX_POS( pNode, i - 1, sKeySize ) + sKeyIndexOffset );
                        break;

                    case DBM_COLUMN_LONG_TYPE:
                        _PRT( "%lld", *(long long*) INDEX_POS( pNode, i - 1, sKeySize ) + sKeyIndexOffset );
                        break;

                    default:
                        DBM_DBG( "Column type not Found type [%d]", mIndexHeader->mIndex.mKey[j].mColumnType );
                        break;
                }
                _PRT( " " );

                sKeyIndexOffset = sKeyIndexOffset + mIndexHeader->mIndex.mKey[j].mSize;
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _ENDVOID
} /* PrintNodeElement4 */


////////////////////////////////////////////////////////////////////////////////
// 사용되지 않음
////////////////////////////////////////////////////////////////////////////////
#if 1

void PrintNodeElement2Lib (dbmIndexNode* pNode, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr)
{
    dbmSegmentManager* sSegMgr;
    dbmIndexNode*   pChild;
    dbmIndexNode*   pInter;
    dbmIndexHeader* sIndexHeader;
    int     sKeySize;
    int     sKeyIndexOffset;
    int     i, j;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        sKeyIndexOffset = 0;
        sKeySize = sIndexHeader->mIndex.mKeySize;

        /* Print Post-order */
        if ( pNode->mIndexSlotHeader.mLeafcheck == 1 )
        {
            pChild = NULL;
        }
        else
        {
            _CALL( sSegMgr->Slot2Addr ( pNode->mChild[0], &pChild ) );
        }

        if ( pChild == NULL )
        { /* leaf */
//            printf ( "\t[ " );
//            for ( i = 0; i < pNode->mIndexSlotHeader.mNodeCount; i++ )
//            {
//                printf ( "%d", *(int*) INDEX_POS( pNode, i, sIndexHeader->mIndex.mKeySize ) + ( sIndexHeader->mIndex.mKey[0].mSize * sKeyIndexOffset ) );
//                printf ( " " );
//            }
//            printf ( "] " );

            printf ( "\t   [ mCurrSlot=%lld (mNodeCount=%d) ]\n\t>> [mRootSlotID=%lld,mRoot=%d <== (상위)",
                     pNode->mCurrSlot,
                     pNode->mIndexSlotHeader.mNodeCount,
                     pNode->mIndexSlotHeader.mRootSlotID,
                     pNode->mRoot );

            printf ( "\n\t>> [%lld,%lld,%lld,%d,%d,%d, ", pNode->mIndexSlotHeader.mLeafPrevID, pNode->mCurrSlot,
//                     pNode->mRoot,
//                     pNode->mIndexSlotHeader.mRootSlotID,
                     pNode->mIndexSlotHeader.mLeafNextID,
                     pNode->mIndexSlotHeader.mLeafcheck,
                     pNode->mIndexSlotHeader.mRootFlag,
                     pNode->mIndexSlotHeader.mLock );

            // format ‘%lld’ expects argument of type ‘long long int’, but argument 12 has type ‘long long {aka long int}’ [-Wformat=]
            printf ( "\n\t>> [%lld,%lld,%lld,%lld,%lld, "
                     "%lld,%lld,%lld,%lld,%lld,%lld] ",
                     pNode->mRID[0], pNode->mRID[1], pNode->mRID[2], pNode->mRID[3], pNode->mRID[4],
                     pNode->mChild[0], pNode->mChild[1], pNode->mChild[2], pNode->mChild[3], pNode->mChild[4], pNode->mChild[5] );

            printf ( "\n" );
            fflush ( stdout );

            _RETURN;
        }

        /* leftmost child 출력 */
        _CALL( sSegMgr->Slot2Addr ( pNode->mChild[0], &pInter ) );

        PrintNodeElement2Lib ( pInter, sIndexHeader, sSegMgr );

        /* node 내의 key와 other child 출력 */
        for ( i = 1; i < DBM_INDEX_DEGREE; ++i )
        {
            if ( pNode->mChild[i] < 1 )
            {
                pInter = NULL;
            }
            else
            {
                _CALL( sSegMgr->Slot2Addr ( pNode->mChild[i], &pInter ) );
            }

            if ( pInter == NULL )
            {
                _RETURN;
            }

            PrintNodeElement2Lib ( pInter, sIndexHeader, sSegMgr );

            for ( j = 0; j < sIndexHeader->mIndex.mColumnCount; j++ )
            {
                switch ( sIndexHeader->mIndex.mKey[j].mColumnType )
                {
                    case DBM_COLUMN_CHAR_TYPE:
                        printf ( "%s", INDEX_POS( pNode, i - 1, sKeySize ) + ( sIndexHeader->mIndex.mKey[j].mSize * sKeyIndexOffset ) );
                        break;
                    case DBM_COLUMN_SHORT_TYPE:
                        printf ( "%d",
                                 *(short*) INDEX_POS( pNode, i - 1, sKeySize ) + ( sIndexHeader->mIndex.mKey[j].mSize * sKeyIndexOffset ) );
                        break;
                    case DBM_COLUMN_INT_TYPE:
                        printf ( "%d",
                                 *(int*) INDEX_POS( pNode, i - 1, sKeySize ) + ( sIndexHeader->mIndex.mKey[j].mSize * sKeyIndexOffset ) );
                        break;
                    case DBM_COLUMN_LONG_TYPE:
                        printf ( "%lld",
                                 *(long long*) INDEX_POS( pNode, i - 1, sKeySize ) + ( sIndexHeader->mIndex.mKey[j].mSize * sKeyIndexOffset ) );
                        break;
                    default:
                        DBM_DBG( "Column type not Found type [%d]", sIndexHeader->mIndex.mKey[j].mColumnType );
                        break;
                }
                printf ( " " );
            }
        }

        printf ( "\n" );
        fflush ( stdout );
    }
    _CATCH
    {
        _CATCH_WARN;

        _PRT( "\n" );
    }
    _FINALLY
    _ENDVOID
} /* PrintNodeElement2Lib */


void PrintNodeElementbySlotId ( long long aSlotID , dbmSegmentManager* aSegMgr )
{
    dbmIndexNode*   pNode;

    _TRY
    {
        if ( aSlotID < 0 ) return;

        _CALL ( aSegMgr->Slot2Addr ( aSlotID, &pNode ) );
        _DASSERT ( pNode != NULL );

        printf ( "\t   [mCurrSlot,%lld,mNodeCount,%d,]\n\t>> [mRootSlotID,%lld,mRoot,%d,]",
                 pNode->mCurrSlot, pNode->mIndexSlotHeader.mNodeCount, pNode->mIndexSlotHeader.mRootSlotID, pNode->mRoot );

        printf ( "\n\t>> [Pre,%lld,Cur,%lld,Next,%lld,LeafF,%d,RootF,%d,Lock,%d,] ",
                pNode->mIndexSlotHeader.mLeafPrevID,
                pNode->mCurrSlot,
                pNode->mIndexSlotHeader.mLeafNextID,
                pNode->mIndexSlotHeader.mLeafcheck,
                pNode->mIndexSlotHeader.mRootFlag,
                pNode->mIndexSlotHeader.mLock );

        printf ( "\n\t>> [RID,%lld,%lld,%lld,%lld,%lld,] "
                "[Child,%lld,%lld,%lld,%lld,%lld,%lld] ",
                pNode->mRID[0],
                pNode->mRID[1],
                pNode->mRID[2],
                pNode->mRID[3],
                pNode->mRID[4],
                pNode->mChild[0],
                pNode->mChild[1],
                pNode->mChild[2],
                pNode->mChild[3],
                pNode->mChild[4],
                pNode->mChild[5]
                );

        printf ( "\n" ); fflush(stdout);
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}


void PrintNodeElementbySlotId2 ( long long aSlotID , dbmSegmentManager* aSegMgr )
{
    dbmIndexNode*   pNode;
    dbmIndexNode*   pChild;

    _TRY
    {
        if ( aSlotID < 0 ) return;

        printf ( ">>>> Self\n" );
        PrintNodeElementbySlotId ( aSlotID, aSegMgr );

        _CALL ( aSegMgr->Slot2Addr ( aSlotID, &pNode ) );
        _DASSERT ( pNode != NULL );

        printf ( "\n>>>> Root\n" );
        PrintNodeElementbySlotId ( pNode->mIndexSlotHeader.mRootSlotID, aSegMgr );

        if ( pNode->mIndexSlotHeader.mLeafPrevID > 0 )
        {
            printf ( "\n>>>> PrevSlot\n" );
            PrintNodeElementbySlotId ( pNode->mIndexSlotHeader.mLeafPrevID, aSegMgr );

            printf ( "\n>>>> Prev's Root\n" );
            _CALL ( aSegMgr->Slot2Addr ( pNode->mIndexSlotHeader.mLeafPrevID, &pChild ) );
            _DASSERT ( pChild != NULL );
            PrintNodeElementbySlotId ( pChild->mIndexSlotHeader.mRootSlotID, aSegMgr );
        }

        if ( pNode->mIndexSlotHeader.mLeafNextID > 0 )
        {
            printf ( "\n>>>> NextSlot\n" );
            PrintNodeElementbySlotId ( pNode->mIndexSlotHeader.mLeafNextID, aSegMgr );

            printf ( "\n>>>> Next's Root\n" );
            _CALL ( aSegMgr->Slot2Addr ( pNode->mIndexSlotHeader.mLeafNextID, &pChild ) );
            _DASSERT ( pChild != NULL );
            PrintNodeElementbySlotId ( pChild->mIndexSlotHeader.mRootSlotID, aSegMgr );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}


#endif


