/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 * Index 관련되어 처리 하는 Source 이다.
*******************************************************************************/
#include "dbmIndexManagerInterface.h"
#include "dbmHeader.h"


_VOID dbmIndexManager::mDeleteKey ( int aTransID , char* aKey, int aCheck )
{
    return dbmIdxDeleteKey ( mInstName, aTransID, aKey, NULL, this, aCheck );
}

_VOID dbmIndexManager::mDeleteKey(char* aInstName, int aTransID, char* aIndexName, char* aKey, int aCheck )
{
    return dbmIdxDeleteKey ( aInstName, aTransID, aKey, aIndexName, NULL, aCheck );
}

__thread char*  gDeletKey;
/********************************************************************
 * ID : mDeleteKey(static)
 *
 * Description
 *   dbm Index key Delete
 *   input 받은 key의 값을 삭제하고 B-Tree 조정을 하도록 한다.
 *
 * Argument
 *     aTransID   : input : Transaction ID
 *     aKey       : input : delete 처리해야 할 key value
 *     aIndexName : input : static call 분류 시 사용 index name
 *     pUser      : input : static call 분류 시 사용 pUser
 *
********************************************************************/
_VOID dbmIdxDeleteKey ( char* aInstName, int aTransID , char* aKey , char* aIndexName , void* pUser, int aCheck )
{
    dbmIndexNode*       sCurr = NULL;   // Index 현재 node pointer
    dbmIndexNode*       sChild = NULL;  // Index Child node pointer
    dbmIndexNode*       sNewNode = NULL;// Index New node pointer

    dbmIndexManager*    pInfo = NULL;
    dbmIndexHeader*     sIndexHeader = NULL;
    dbmSegmentManager*  sSegMgr = NULL;
    dbmLockManager*     aLockMgr = NULL;        // 편의상 sLockMgr 대신 aLockMgr 이름 사용

    int     sPos;               // not position
    int     sCount;             // internal node count
    int     sInternalCheck;     // internal check 1:internal 0:non-internal
    int     sFiniShed;          // B-Tree 재조정 Flag 0:x 1:재조정 필요
    int     sFound;             // B-Tree Find
    int     sBtreeCheck;        // B-Tree 1 : Right, 0 : left sibling check
    int     sFreeSlotCheck;     // 0:non-free slot 1:free lsot

    int     sLockF = 0;
    int     sCurrStepF = 0;
    int     sKeySize;
    int     sRC;                // return value

    _TRY
    {
        _ASSERT ( aKey != NULL );   // input key data check
        _ASSERT ( pUser != NULL || aIndexName != NULL );   // pUser: 내부호출일때 class 자신(this), aIndexName 정정호출

        // 일반 호출
        if ( pUser != NULL )
        {
            pInfo = (dbmIndexManager*) pUser;
            sIndexHeader = pInfo->mIndexHeader;
            sSegMgr = pInfo->mSegMgr;
            aLockMgr = pInfo->mLockMgr;
        }
        // TxMgr의 Recovery에서만 사용 ( 객체없이 Static )
        else if ( aIndexName != NULL )
        {
            _CALL( dbmSegmentManager::Attach ( aInstName, aIndexName, &sSegMgr ) );
            sIndexHeader = (dbmIndexHeader*) sSegMgr->GetUserHeader ( );
        }

        /* key Max Size Check */
        if ( sIndexHeader->mIndex.mKeySize > DBM_INDEX_KEY_MAX_SIZE )
        {
            DBM_ERR( "index Key Max Size error [%s,%s,%d]", aInstName, aIndexName, sIndexHeader->mIndex.mKeySize );
            _THROW( ERR_DBM_KEY_MAX_SIZE_FAIL );
        }

        /* Index Tree X-LOCK mode */
        _CALL( mSpinLockLib( &sIndexHeader->mLock, &sIndexHeader->mFutex, aTransID, aLockMgr ) );
        sLockF = 1; // _CATCH에서 해제필요 여부 판단위해

        /* Index Operation 검증 */
        if ( sIndexHeader->mCurrStep != 0 )
        {
            DBM_ERR( "Index Delete Curr state Error Index Rebulid Request !!! state[%d] lock[%d]",
                     sIndexHeader->mCurrStep, sIndexHeader->mLock );
            _THROW( ERR_DBM_CURR_STAT_FAIL );
        }

        /* index Deltekey state change */
        sIndexHeader->mCurrStep = 1;
        sIndexHeader->mTreeCheck = 1;
        sCurrStepF = 1; // 나중에 원복할지 여부 결정위해 추가.

        /* Non-Unique Index Type Set */
        /* dic object type */
        g_bIsUniqueIndex = sIndexHeader->mIndex.mIsUniqueIndex;

        if ( gDeletKey == NULL )
        {
            gDeletKey = (char*) malloc_s ( DBM_INDEX_KEY_MAX_SIZE + 8 );
            _ASSERT( gDeletKey != NULL );
        }

        // 2014.12.14. -okt- 원래코드가 [BUGBUG] 8Byte만 초기화 하고 있음, 그래도 동작하는 것으로 보아, 불필요한 코드일듯.. ( 2014.09.24 )
        memset_s ( gDeletKey, 0x00, DBM_INDEX_KEY_MAX_SIZE + 8 );

        // 2014.04.02 -shw- key memory create
        sKeySize = ( g_bIsUniqueIndex ) ? sIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );
        memcpy_s ( gDeletKey, aKey, sKeySize ); // iniput key copy

        /* 초기화 처리 */
        sChild = NULL;
        sCurr = NULL;
        sNewNode = NULL;
        sPos = 0;
        sCount = 0;
        sInternalCheck = 0;
        sFiniShed = 0;
        sFound = 0;
        sBtreeCheck = 0;
        sFreeSlotCheck = 0;

        if ( g_bIsUniqueIndex == DBM_NON_UNIQUE )
        {
            if ( aCheck == 0 )
            {
                /* 여기까지 왔다는건 현재의 curr 노드에 해당 데이터가 있다는 것이다... */
                _CALL( dbmIdxDeletePositionNu ( &sCurr, gDeletKey, sIndexHeader, sSegMgr ) );

                /***********************************************************************************
                * 여기에서 search 시에는 Extra 값을 제외한 값을 가져와 비교를 하고
                * 비교한 값을 가지고 삭제 하기 위하여 (같다고 나온 비교값을 삭제) sKey+Extra 값을
                * 더한 값의 key value 생성 한다
                ***********************************************************************************/
                _CALL( dbmIdxSearchExist ( sIndexHeader, sCurr, gDeletKey, &sPos ) );

                //memset_s ( gDeletKey, 0x00, sKeySize );
                memcpy_s ( gDeletKey, INDEX_POS( sCurr, sPos, sKeySize ), sKeySize );
            }
        }

        /* 여기까지 왔다는건 현재의 curr 노드에 해당 데이터가 있다는 것이다... */
        _CALL( dbmIdxDeletePosition ( &sCurr, gDeletKey, sIndexHeader, sSegMgr ) );


        /**************************************************************************
        * curr(현재)  node에서 sChild가 있다는 것은 아래의 leaf가 있다는 것을
        * 얘기 하는 것이다. 최소한 curr의 leftmost child도 null이 아닐것이다...
        * leaf가 아니라는 것은 root or internal slot 이라는 것이다
        ***************************************************************************/
        if ( sCurr->mIndexSlotHeader.mLeafcheck != 1 )
        {
            /* internale node에서의 position 구한다 */
            /* Delete 구간에서 search 에서는 node간 lock은 필요없다 */
            _CALL( dbmIdxDeleteSearchExist ( sCurr, gDeletKey, sIndexHeader, &sPos ) );

            /* child 현재의 node slot copy */
            _CALL( sSegMgr->Slot2Addr ( sCurr->mChild[sPos], &sChild ) );

            /*
             * 여기까지 되었다는 것은 해당 internal node에서 해당 key와 child을 찾았다는 것을 의미한다
             */

            /*
             * leaf key 값이 나올때 까지 loop 돌면서 해당 leaf의 key값이 나오면
             * key 값과 child 치환한다 */
            if ( g_bIsUniqueIndex )
            {
                sRC = dbmIdxDeleteInternalCheck ( &sCurr, &sChild, sPos, aTransID, sIndexHeader, sSegMgr, NULL );
            }
            else
            {
                sRC = dbmIdxDeleteInternalCheckNu( &sCurr, &sChild, sPos, aTransID, sIndexHeader, sSegMgr, NULL );
            }
            if ( sRC ) //, DBM_INDEX_SLOT2ADDR_FAIL2 );
            {
                DBM_ERR ( " DBM_INDEX_SLOT2ADDR_FAIL2 [%d]",  sRC );
                _THROW( ERR_DBM_SLOT2ADDR_FAIL );
            }

            sCurr = sChild;
        }

        /* key delete 하고 shift 처리를 한다 */

        // key position을 구한다
        _CALL( dbmIdxDeleteSearchExist ( sCurr, gDeletKey, sIndexHeader, &sPos ) );

        /*******************************************************************************
         * sCurr 현재의 node는 무조건 leaf이어야 한다. 이런 전제가 깨지면 안되기 때문에
         * 체크를 함 한다
         ********************************************************************************/
        if ( sCurr->mIndexSlotHeader.mLeafcheck != 1 ) //, DBM_INDEX_LEAF_CHECK_ERROR );
        {
            DBM_ERR ( "dbm B-Tree Index Leaf Check Error [%d]", sCurr->mIndexSlotHeader.mLeafcheck);
            _THROW( ERR_DBM_LEAF_CHECK_FAIL );
        }

        /*********************************************************************
         * curr에서 key 값을 비교하여 nPos을 구한다.
         * 해당 포지션을 삭제하고 삭제한 포지션의 자리에 하나씩 자리를 이동한다.
         * 일단 leaf 공간에서 하나씩 자리를 이동해 주도록 한다.
         **********************************************************************/
        sRC = dbmIdxDeleteShift ( &sCurr, sPos, aTransID, sIndexHeader, NULL );
        if ( sRC ) //, DBM_INDEX_DELETE_SHIFT_ERROR );
        {
            DBM_ERR ( "dbm index data left shit error [%d]",  sRC );
            _THROW( ERR_DBM_BTREE_CONTROL_FAIL );
        }


        // TREE 조정 처리...
        do
        {
            /* DBM_INDEX_DEGREE 중간값보다 클때만 B-Tree 조정을 하도록 한다. */
            if ( sCurr->mIndexSlotHeader.mRootFlag == 1
                    || sFreeSlotCheck == 1
                    || sCurr->mIndexSlotHeader.mNodeCount >= ( g_DBM_INDEX_DEGREE_add1_div2 - 1 ) )
            {
                sFiniShed = 1;
            }
            else
            {
                /* 초기화 처리 */
                sFound = 0;
                sBtreeCheck = 0;
                sChild = NULL;

                _CALL( sSegMgr->Slot2Addr ( sCurr->mIndexSlotHeader.mRootSlotID, &sNewNode ) );

                /* 상위 internal element count가 없다는 것은 뭔가 심각한 문제가 있다는 것이다 */
                if ( unlikely( sNewNode->mIndexSlotHeader.mNodeCount < 1 ) ) //, DBM_INDEX_NODE_COUNT_FAIL );
                {
                    DBM_ERR ( "new node count error [%d]", sNewNode->mIndexSlotHeader.mNodeCount );
                    _THROW( ERR_DBM_NODE_COUNT_FAIL );
                }

                sPos = -1;

                /* Newnode 에서의 child에서 Curr node가 있는 위치를 구한다 */
                sRC = dbmIdxDeleteNodeExist ( sNewNode, sCurr, sSegMgr, &sPos );
                if ( unlikely( sRC != 0 ) ) //, DBM_INDEX_NODE_POSITION_FAIL );
                {
                    if ( pInfo == NULL ) /* NULL: 정적호출 ELSE: 내부호출 */
                    {
                        DBM_ERR( "Curr Internal Child position find error [%d]", sPos );
                    }
                    else
                    {
                        DBM_ERR( "Curr Internal Child position find error [%d] key[%s][%d]", sPos, aKey, *(int*)( aKey + 20 ) );
                    }

                    _THROW( ERR_DBM_POSITION_ERROR );
                }

                /* node sibling 구해온다 */
                /* sBtreeCheck 0:right sibling
                 *             1:left sibling
                 */
                sFound = dbmIdxDeleteSiblingSet ( sNewNode, sPos, &sBtreeCheck, sSegMgr );

                /*
                 * TODO: 2014.11.20. -okt- 상위에서 ERR_DBM_SLOT2ADDR_FAIL 검사하는 부분을 고침.
                 *       위와 같이 고치니. TxMgr/perf.sh dic_max_check 테스트에서 Hang 걸림.
                 *       결국 아래 오류처리는 의미 없는 코드이므로 막음.
                 */
                // 2014.09.26 -okt- sFound 값이 FALSE(0) 이 오는 경우가 있는데, drop table, 이는 의도된 것이라고 함. -shw-
#if 0
                if ( unlikely( sFound == ERR_DBM_SLOT2ADDR_FAIL ) ) // 원래코드
                //if ( unlikely( sFound == FALSE ) ) // 이렇게 고치면 Hang
                {
                    DBM_ERR ( "DBM_INDEX_SLOT2ADDR_FAIL4 [%d]",  sRC );
                    _THROW( ERR_DBM_SLOT2ADDR_FAIL );
                }
#endif

//                if ( pInfo != NULL )
//                {
//                    /* 2014.02.18 -shw- delete key 처리 시  logging  필요없어 일단 막음 */
//                    /* New에 대한 Index Logging 처리를 한다 */
//                    sRC = mIndexLogging(&sNewNode->mCurrSlot,aTransID);
//                    _IF_RAISE(sRC, DBM_INDEX_LOGGING_FAIL2);
//                }

                /************************************************************************************
                 * 여기에서 실제 조정이 이루어진다.
                 * 크게 4가지로 볼수 있다
                 ************************************************************************************/
                if ( sFound )
                {
                    if ( sBtreeCheck == 1 )
                    {
                        /* 좌측 sibling, parent 와 합쳐 반으로 나누기 .. key, child만 이동하기로 하자... */
                        if ( g_bIsUniqueIndex )
                        {
                            sRC = dbmIdxDeleteLeftSibling ( &sNewNode, &sCurr, sPos, aTransID, sIndexHeader, sSegMgr, NULL );
                        }
                        else
                        {
                            sRC = dbmIdxDeleteLeftSiblingNu ( &sNewNode, &sCurr, sPos, aTransID, sIndexHeader, sSegMgr, NULL );
                        }
                        if ( sRC ) //, DBM_INDEX_LEFT_SIBLING_FAIL );
                        {
                            DBM_ERR ( "Index data left shift error [%d]",  sRC );
                            _THROW( ERR_DBM_BTREE_CONTROL_FAIL );
                        }
                    }
                    else
                    {

                        /* 우측 sibling, parent와 합쳐 반으로 나누기 - key값, child만 이동 */
                        if ( g_bIsUniqueIndex )
                        {
                            sRC = dbmIdxDeleteRightSibling ( &sNewNode, &sCurr, sPos, aTransID, sIndexHeader, sSegMgr, NULL );
                        }
                        else
                        {
                            sRC = dbmIdxDeleteRightSiblingNu ( &sNewNode, &sCurr, sPos, aTransID, sIndexHeader, sSegMgr, NULL );
                        }
                        if ( sRC ) //, DBM_INDEX_RIGHT_SIBLING_FAIL );
                        {
                            DBM_ERR ( "B-Tree mDeleteRightSibling error [%d]",  sRC );
                            _THROW( ERR_DBM_BTREE_CONTROL_FAIL );
                        }

                    }

                    sFiniShed = 1;
                }
                else
                {
                    /* sPos가 0일 때에는 right sibling 처리를 한다 */
                    sBtreeCheck = ( sPos == 0 ) ? 2 : 1;

                    if ( sBtreeCheck == 1 )
                    {
                        /*****************************************************************
                         * left, right sibling의 포함되지 못하였을 경우 parent 합쳐서
                         * B-Tree 재조정을 하도록 한다.
                         *****************************************************************/
                        /* 우측 sibling, parent와 합쳐 반으로 나누기 - key값, child만 이동 */
                        if ( g_bIsUniqueIndex )
                        {
                            sRC = dbmIdxDeleteNonLeftSibling ( &sNewNode, &sCurr, sPos, aTransID, sIndexHeader, sSegMgr, NULL );
                        }
                        else
                        {
                            sRC = dbmIdxDeleteNonLeftSiblingNu ( &sNewNode, &sCurr, sPos, aTransID, sIndexHeader, sSegMgr, NULL );
                        }
                        if ( sRC ) //, DBM_INDEX_NON_LEFT_SIBLING_FAIL );
                        {
                            DBM_ERR ( "dbm B-Tree non-left sibling error [%d]",  sRC );
                            _THROW( ERR_DBM_BTREE_CONTROL_FAIL );
                        }

                        sCurr = sNewNode;
                    }
                    else
                    {
                        /*****************************************************************
                         * left, right sibling의 포함되지 못하였을 경우 parent 합쳐서
                         * B-Tree 재조정을 하도록 한다.
                         *****************************************************************/
                        /* 우측 sibling, parent와 합쳐 반으로 나누기 - key값, child만 이동 */
                        if ( g_bIsUniqueIndex )
                        {
                            sRC = dbmIdxDeleteNonRightSibling ( &sNewNode, &sCurr, sPos, aTransID, sIndexHeader, sSegMgr, NULL );
                        }
                        else
                        {
                            sRC = dbmIdxDeleteNonRightSiblingNu ( &sNewNode, &sCurr, sPos, aTransID, sIndexHeader, sSegMgr, NULL );
                        }
                        if ( sRC ) //, DBM_INDEX_NON_RIGHT_SIBLING_FAIL );
                        {
                            DBM_ERR ( "dbm B-Tree not-right sibling error [%d]",  sRC );
                            _THROW( ERR_DBM_BTREE_CONTROL_FAIL );
                        }

                        sCurr = sNewNode;
                    }

                    if ( sCurr->mIndexSlotHeader.mNodeCount == 0 )
                    {
                        // (D)01:10:20.835814 05027 dbmIndexManager   mDeleteKeyLib  971 free slot nodeCount[0] root flag[-1]
                        DBM_DBG( "free slot nodeCount[%d] root flag[%d]",
                                 sCurr->mIndexSlotHeader.mNodeCount, sCurr->mIndexSlotHeader.mRootFlag );

                        /* free slot check 1을 하는 이유는 sNoewNode의 node count가 0이면 free slot을 해주어야
                         * 하는데 free slot을 하고 난 후 위에서 위의 pointer을 가지고 종료 하는 if 문이 있기 때문에
                         * 해당 sCurr free 해주고 난 후 아래의 sFreeSlotCheck값을 이용하여 free 하려고 하기
                         * 때문이다 */
                        sFreeSlotCheck = 1;

                        // sCurr Node Count 0이니 다쓴것이다. free slot을 해주라.
                        _CALL( dbmSegFreeSlot( sSegMgr, sCurr->mCurrSlot, 0 ) );   // by mDeleteKeyLib
                    }
                }
            } /* End of if () */

        }
        while ( !sFiniShed );

        /* Index Delete key state change */
        {
            sCurrStepF = 0;
            sIndexHeader->mCurrStep = 0;
            sIndexHeader->mTreeCheck = 0;

            sLockF = 0;
            _CALL( mSpinUnlockLib( &sIndexHeader->mLock, &sIndexHeader->mFutex, aTransID, aLockMgr ) );
        }

#ifdef INDEX_TEST
        printf(" **** delete end print pid[%lld] key[%d] lock[%d] aTransID[%d] **** \n",
                sIndexHeader->mRootPid, *(int*)aKey,sIndexHeader->mLock,aTransID);
        sRC = sSegMgr->Slot2Addr(sIndexHeader->mRootPid, &sSlotAddr);
        _IF_RAISE( sRC, DBM_INDEX_SLOT2ADDR_FAIL1);
        PrintNodeElement2((dbmIndexNode*)sSlotAddr, sLogH,sIndexHeader,sSegMgr);
        printf(" **** end print key[%d]**** \n", *(int*)aKey);
#endif

#ifndef USE_NEW_SHM_NODETACH
        if ( pInfo == NULL ) /* NULL: 정적호출 ELSE: 내부호출 */
        {
            sSegMgr->Detach ( );
        }
#endif
    }
    _CATCH
    {
        _CATCH_WARN;

#ifndef USE_NEW_SHM_NODETACH
        if ( pInfo == NULL )
        {
            sSegMgr->Detach ( );
        }
#endif

        /* unlock process */
        if ( sCurrStepF == 1 )
        {
            sIndexHeader->mCurrStep = 0;
        }
        if ( sLockF == 1 )
        {
            (void) mSpinUnlockLib( &sIndexHeader->mLock, &sIndexHeader->mFutex, aTransID, aLockMgr );
        }

        sIndexHeader->mTreeCheck = 0;
    }
    _FINALLY
    _END
} /* mDeleteKeyLib */


/********************************************************************
 * ID : mDeleteNodeExist(static)
 *
 * Description
 *   현재 NODE와 pointer가 상위 internal node의 child 위치가 어디 인지
 *   파악을 한다.
 *
********************************************************************/
dbmIndexNode* g_pIdxNodeTmp = NULL;
_VOID dbmIdxDeleteNodeExist (dbmIndexNode* aNewNode,dbmIndexNode* aCurr, dbmSegmentManager* aSegMgr, int* aPos )
{
    int ix;

    _TRY
    {
        for ( ix = 0; ix <= aNewNode->mIndexSlotHeader.mNodeCount; ++ix )
        {
            if ( aCurr->mCurrSlot == aNewNode->mChild[ix] )
            {
                *aPos = ix;
                _RETURN;
            }
        }

        aSegMgr->Slot2Addr ( 0, &g_pIdxNodeTmp );

        DBM_ERR( "[FATAL] dbmIdxDeleteNodeExist fail [%d,%d,%p,%p] (err=%d,thr=%d)",
                 ix, aNewNode->mIndexSlotHeader.mNodeCount, aCurr, aNewNode, errno, gettid_s ( ) );

        DBM_INFO( ">>>> mCurrSlot" );
        PrintNodeElementbySlotId2 ( aCurr->mCurrSlot, aSegMgr );
        DBM_INFO( ">>>> aNewNode" );
        PrintNodeElementbySlotId2 ( aNewNode->mCurrSlot, aSegMgr );

        _DASSERT ( 0 );
        _THROW( -1 );
    }
    _CATCH
    _FINALLY
    _END
}


/********************************************************************
 * ID : mDeleteSearchExistLib() (static)
 *
 * Description(non-unique index type)
 *   dbm Index search key Exist Check
 *   같은 키가 존재 하는지 체크 한다.
 *
 * Argument
 *     aNode        : input : 검색 할 NODE 포이터
 *     aKey         : input : Input Key Data
 *     aIndexHeader : input : dbm Index Header
 *
********************************************************************/
int dbmIdxDeleteSearchExist ( dbmIndexNode* aNode , char* aKey , dbmIndexHeader* aIndexHeader, int *aPos )
{
    int     sKeySize;
    int     ix;

    _TRY
    {
        _DASSERT ( aNode != NULL );

        sKeySize = ( g_bIsUniqueIndex ) ? aIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( aIndexHeader->mIndex.mKeySize );
        for ( ix = 0; ix < aNode->mIndexSlotHeader.mNodeCount; ++ix )
        {
            if ( dbmIdxIndexCompare ( aIndexHeader, INDEX_POS( aNode, ix, sKeySize ), aKey, DBM_EQ, 0 ) != 0 )
            {
                *aPos = ix;
                _RETURN;
            }
        }

        // 찾지못함.
        return( ERR_DBM_KEY_NOT_EXIST );
    }
    _CATCH
    _FINALLY
    _END
} /* dbmIdxDeleteSearchExist */


/********************************************************************
 * ID : mSearchExist() (static)
 *
 * Description
 *   dbm Index search key Exist Check
 *   같은 키가 존재 하는지 체크 한다.
 *
 * Argument
 *     aNode        : input : 검색 할 NODE 포이터
 *     aKey         : input : Input Key Data
 *     aIndexHeader : input : dbm Index Header
 *
********************************************************************/
_VOID dbmIdxSearchExist ( dbmIndexHeader* aIndexHeader, dbmIndexNode* aNode, char* aKey, int *aPos )
{
    int     sKeySize;
    int     sIsUniqueIndexPre = g_bIsUniqueIndex;
    int     ix;

    _TRY
    {
        _DASSERT ( aNode != NULL );

        sKeySize = ( g_bIsUniqueIndex ) ? aIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( aIndexHeader->mIndex.mKeySize );

        /* 중요 : column count수만큼만 비교를 하면 되기 때문에 aNodeIndexType 1인데도 1을 따로 주지는 않고
         *        non-unique type 1을 로지 않고 0으로 주어 비교 한다 */
        g_bIsUniqueIndex = DBM_UNIQUE; // before 비교 extra 제외

        /* 2015.05.29 -shw- 노드 마지막 부터 첫번째 까지 비교를 하도록 수정 */
        //for ( ix = 0; ix < aNode->mIndexSlotHeader.mNodeCount; ++ix )
        for ( ix = aNode->mIndexSlotHeader.mNodeCount - 1; ix >= 0; --ix )
        {
            if ( dbmIdxIndexCompare ( aIndexHeader, INDEX_POS( aNode, ix, sKeySize ), aKey, DBM_EQ, 0 ) != 0 )
            {
                g_bIsUniqueIndex = sIsUniqueIndexPre; // after 전으로 복귀

                *aPos = ix;
                _RETURN;
            }
        }

        g_bIsUniqueIndex = sIsUniqueIndexPre; // after 전으로 복귀

        // 찾지못함.
        return( ERR_DBM_KEY_NOT_EXIST );
    }
    _CATCH
    _FINALLY
    _END
} /* dbmIdxSearchExist */


/********************************************************************
 * ID : mDeleteKeyClear(static)
 *
 * Description
 *   입력받은 key 값을 clear 한다.
 * Argument
 *     aode     : input : clear 처리 할 node value
 *
********************************************************************/
void dbmIdxDeleteKeyClear ( dbmIndexNode** aNode , dbmIndexHeader* aIndexHeader )
{
    dbmIndexHeader* sIndexHeader = aIndexHeader;
    dbmIndexNode*   sCurr = *aNode;

    /* sChild 초기화 */
    sCurr->mIndexSlotHeader.mRootFlag = -1;
    sCurr->mIndexSlotHeader.mRootSlotID = -1;
    sCurr->mIndexSlotHeader.mLeafNextID = -1;
    sCurr->mIndexSlotHeader.mLeafPrevID = -1;
    sCurr->mIndexSlotHeader.mLeafcheck = -1;
    sCurr->mIndexSlotHeader.mNodeCount = 0;

    //TODO: 2014.11.17 -okt- 다른 곳에서 해주는 것으로 대응되는 것 같아서 막았으나.
    //      --> 이부분은 함부로 바꾸면 안된다고 현웅님. 지적. (원복)
    memset_s ( &sCurr->mRID[0]  , -1, sizeof(long long) * DBM_INDEX_DEGREE );
    memset_s ( &sCurr->mChild[0], -1, sizeof(long long) * DBM_INDEX_DEGREE );
    //sCurr->mRID[0] = -1;
    //sCurr->mChild[0] = -1;

    sCurr->mRoot = -1;
    sCurr->mBtreeCheck = -1;

    int sKeySize = ( g_bIsUniqueIndex ) ? sIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );

    //memset_s ( INDEX_POS( sCurr, 0, sKeySize ), 0x00, sKeySize * DBM_INDEX_DEGREE );
    *(int*)INDEX_POS( sCurr, 0, sKeySize ) = 0x00;
} /* dbmIdxDeleteKeyClear */


/********************************************************************
 * static functions
 *
 * 2014.09.24 -okt- 정적 함수로 뺄수 있는 부분을 따로 모은다. (성능)
 *
********************************************************************/

/********************************************************************
 * ID : mBinarySearchDeleteLeaf
 *
 * Description
 *   dbm Index key binary search
 *   dbm Delete 관련 해당 key의 position을 찾는다.
 *
 * Argument
 *     aCount      : input : 해당 노드에 저장 되어 있는 key count
 *     aPosition   : output: key가 저장되어 있는 position
 *     aCurr       : input : key가 저장되어 있는 노드의 pointer
 *     aKey        : input : key value
 *     aIndexHeader: input : dbm Index Header
 *
********************************************************************/
//TODO: 2014.09.26 -okt- 함수이름에서 검사라는 의미가 있어야하는가?
int dbmIdxBinarySearchDeleteLeaf ( int aCount, int* aPosition, dbmIndexNode* aCurr, char* aKey, dbmIndexHeader* aIndexHeader )
{
    dbmIndexHeader* sIndexHeader = aIndexHeader;
    int     sKeySize;
    int     sLow;
    int     sHigh;
    int     sMid;
    int     sRC;

    _TRY
    {
        sLow = sMid = 0;
        sHigh = aCount - 1;

        sKeySize = ( g_bIsUniqueIndex ) ? sIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );
        while ( sLow <= sHigh )
        {
            sMid = ( sLow + sHigh ) >> 1;   // "/ 2"

            sRC = dbmIdxIndexPosition ( sIndexHeader, aKey, INDEX_POS( aCurr, sMid, sKeySize ) );
            if ( sRC > 0 )
            {
                sHigh = sMid - 1;
            }
            else if ( sRC < 0 )
            {
                sLow = sMid + 1;
            }
            else
            {
                /* 같은 key가 존재하는지 체크한다 */
                return( RC_FAILURE ); // FOUND
            }
        }

        sRC = dbmIdxIndexCompare ( sIndexHeader, aKey, INDEX_POS( aCurr, sMid, sKeySize ), DBM_GT, 0 );
        if ( sRC )
        {
            *aPosition = sMid;
        }
        else
        {
            *aPosition = sMid + 1;
        }
    }
    _CATCH
    _FINALLY
    _END // NOTFOUND
} /* dbmIdxBinarySearchDeleteLeaf */


/********************************************************************
 * ID : mBinarySearchDeleteNuLeaf
 *
 * Description(non-unique index type)
 *   dbm Index key binary search
 *   dbm Delete 관련 해당 key의 position을 찾는다.
 *
 * Argument
 *     aCount      : input : 해당 노드에 저장 되어 있는 key count
 *     aPosition   : output: key가 저장되어 있는 position
 *     aCurr       : input : key가 저장되어 있는 노드의 pointer
 *     aKey        : input : key value
 *     aIndexHeader: input : dbm Index Header
 *
********************************************************************/
int dbmIdxBinarySearchDeleteLeafNu ( int aCount, int* aPosition, dbmIndexNode* aCurr, char* aKey, dbmIndexHeader* aIndexHeader )
{
    dbmIndexHeader* sIndexHeader =  NULL;
    int     sKeySize;
    int     sIsUniqueIndex = g_bIsUniqueIndex;
    int     sLow;
    int     sHigh;
    int     sMid;
    int     sRC;

    _TRY
    {
        sIndexHeader = aIndexHeader;

        /* clear */
        sLow = sHigh = sMid = 0;
        sHigh = aCount - 1;

        sKeySize = ( g_bIsUniqueIndex ) ? sIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );

        /* 중요 : column count수만큼만 비교를 하면 되기 때문에 aNodeIndexType 1인데도 1을 따로 주지는 않고
         non-unique type 1을 로지 않고 0으로 주어 비교 한다 */
        g_bIsUniqueIndex = DBM_UNIQUE;

        while ( sLow <= sHigh )
        {
            sMid = ( sLow + sHigh ) >> 1;

            sRC = dbmIdxIndexPosition ( sIndexHeader, aKey, INDEX_POS( aCurr, sMid, sKeySize ) );
            if ( sRC > 0 )
            {
                sHigh = sMid - 1;
            }
            else if ( sRC < 0 )
            {
                sLow = sMid + 1;
            }
            else
            {
                /* 같은 key가 존재하는지 체크한다 */
                g_bIsUniqueIndex = sIsUniqueIndex;
                return( RC_FAILURE ); // FOUND
            }
        } /* while */

        sRC = dbmIdxIndexCompare ( sIndexHeader, aKey, INDEX_POS( aCurr, sMid, sKeySize ), DBM_GT, 0 );
        if ( sRC )
        {
            *aPosition = sMid;
        }
        else
        {
            *aPosition = sMid + 1;
        }
    }
    _CATCH
    _FINALLY
    {
        g_bIsUniqueIndex = sIsUniqueIndex;
    }
    _END // NOTFOUND
} /* dbmIdxBinarySearchDeleteLeafNu */


/********************************************************************
 * ID : mDeletePosition
 *
 * Description
 *   dbm Index Delete Position set
 *   root node 부터 B-Tree Search 하여 해당 key 값이 있는 NODE 찾는다.
 *
 * Argument
 *    aCurrNode    : input : Root Node Pointer
 *    aKey         : input : Input Key value
 *    aIndexHeader : input : dbm Index Header
 *    aSegMgr      : output: key 값이 저자되어 있는 node 포인터.
 *
********************************************************************/
_VOID dbmIdxDeletePosition ( dbmIndexNode** aCurrNode , char* aKey , dbmIndexHeader* aIndexHeader , dbmSegmentManager* aSegMgr )
{
    dbmIndexNode*       sCurr;          // Index 현재 node pointer
    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;

    int                 sFound;         // data find check value
    int                 sCount;         // node Count
    int                 sPosition;      // node position
    int                 sDepthChkCnt;   // BTree depth check

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        /* 초기화 처리 */
        sFound = 0;
        sCount = 0;
        sPosition = 0;
        sDepthChkCnt = 0;

        /* root address set */
        _CALL( sSegMgr->Slot2Addr ( sIndexHeader->mRootPid, &sCurr ) );

        /* 같은키가 나올때까지 root에서부터 leaf가 올때 까지 찾아라.... */
        do
        {

            /* 현재 노드의 element count 가져온다 */
            sCount = sCurr->mIndexSlotHeader.mNodeCount;

            if ( dbmIdxBinarySearchDeleteLeaf ( sCount, &sPosition, sCurr, aKey, sIndexHeader ) != 0 )
            {
                /* key가 존재한다는 것이다 */
                sFound = 1;
                *aCurrNode = sCurr;
            }
            else
            {
                if ( sCurr->mChild[sPosition] < 0 )
                {
                    DBM_DBG( "data not found !!! [%lld]", sCurr->mChild[sPosition] );
                    _THROW( ERR_DBM_KEY_NOT_EXIST );
                }

                _CALL( sSegMgr->Slot2Addr ( sCurr->mChild[sPosition], &sCurr ) );
            }

            /* BTree Deptch Check */
            if ( unlikely( sDepthChkCnt > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR );
            {
                DBM_ERR( "index depth max error [%d]", sDepthChkCnt );
                _THROW( ERR_DBM_DEPTH_FAIL );
            }

            sDepthChkCnt++;
        }
        while ( !sFound );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* dbmIdxDeletePosition */


/********************************************************************
 * ID : mDeleteNuPosition
 *
 * Description(Non-unique index type)
 *   dbm Index Delete Position set
 *   root node 부터 B-Tree Search 하여 해당 key 값이 있는 NODE 찾는다.
 *
 * Argument
 *    aCurrNode    : input : Root Node Pointer
 *    aKey         : input : Input Key value
 *    aIndexHeader : input : dbm Index Header
 *    aSegMgr      : output: key 값이 저자되어 있는 node 포인터.
 *
********************************************************************/
_VOID dbmIdxDeletePositionNu ( dbmIndexNode** aCurrNode , char* aKey , dbmIndexHeader* aIndexHeader , dbmSegmentManager* aSegMgr )
{
    dbmIndexNode*       sCurr = NULL; // Index 현재 node pointer
    dbmIndexHeader*     sIndexHeader = aIndexHeader;
    dbmSegmentManager*  sSegMgr = aSegMgr;

    int     sCount = 0;         // node Count
    int     sPosition = 0;      // node position
    int     sDepthChkCnt = 0;   // BTree depth check

    _TRY
    {
        /* root address set */
        _CALL( sSegMgr->Slot2Addr ( sIndexHeader->mRootPid, &sCurr ) );

        /* 같은키가 나올때까지 root에서부터 leaf가 올때 까지 찾아라.... */
        do
        {
            /* 현재 노드의 element count 가져온다 */
            sCount = sCurr->mIndexSlotHeader.mNodeCount;

            if ( dbmIdxBinarySearchDeleteLeafNu ( sCount, &sPosition, sCurr, aKey, sIndexHeader ) != 0 )
            {
                /* key가 존재한다는 것이다 */
                *aCurrNode = sCurr;
                break;  // 찾았다. 0을 리턴, sFound = 1;
            }
            else
            {
                if ( sCurr->mChild[sPosition] < 0 )
                {
                    DBM_DBG( "data not found !!! [%lld]", sCurr->mChild[sPosition] );
                    _THROW( ERR_DBM_KEY_NOT_EXIST );
                }

                _CALL( sSegMgr->Slot2Addr ( sCurr->mChild[sPosition], &sCurr ) );
            }

            /* BTree Deptch Check */
            if ( unlikely( sDepthChkCnt > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR);
            {
                DBM_ERR( "index depth max error [%d]", sDepthChkCnt );
                _THROW( ERR_DBM_DEPTH_FAIL );
            }

            sDepthChkCnt++;
        }
        while ( 1 );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* dbmIdxDeletePositionNu */


/********************************************************************
 * ID : mDeleteInternalCheck
 *
 * Description
 *   dbm Index Delete Internal node 인지 leaf node인지 체크를 하고 해당 key값을
 *   Chagge 한다.
 *   Internal Node에 key 값이 저장 되어 있다면 해당 key 값을 leaf node와 chage
 *   한 후 해당 key 값을 삭제하여 주고 B-Tree 조정을 하도록 한다.
 *
 *  Argument
 *  aCurr        : input : Key 값이 저장 되어 있는 Node Pointer
 *  aChild       : input : Key 값의 자식 노드의 Pointer
 *  aPos         : input : 해당 key 값이 저장되어 있는 노드의 position
 *  aTransID     : input : Transaction ID
 *  aIndexHeader : input : dbm Index header
 *  aSegMgr      : input : Index Segment pointer
 *  aLockMgr     : input : Lock Manager pointer
 *
********************************************************************/
_VOID dbmIdxDeleteInternalCheck ( dbmIndexNode** aCurr ,
                                  dbmIndexNode** aChild ,
                                  int aPos ,
                                  int aTransID ,
                                  dbmIndexHeader* aIndexHeader ,
                                  dbmSegmentManager* aSegMgr ,
                                  dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sCurr;          // Index 현재 node pointer
    dbmIndexNode*       sChild;         // Index Child node pointer
    dbmIndexNode*       sNextNode;      // Index 현재의 next node pointer
    dbmIndexNode*       sChangeNode;    // Index 상위 노드 Change pointer

    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;

    char    sKeyData[DBM_INDEX_KEY_MAX_SIZE];
    int     sKeySize;
    int     sFound;         // internal node find
    int     sSlotOverCheck; // 0:root node 1:interal node
    int     sPos;           // leaf key position
    int     sFiniShed;
    long long sRID;
    int     sRC;            // return value
    int     i;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        /* 초기화 처리 */
        sCurr = NULL;
        sChild = NULL;
        sNextNode = NULL;
        sChangeNode = NULL;

        memset_s ( sKeyData, 0x00, sizeof( sKeyData ) );
        sSlotOverCheck = 0;
        sPos = 0;
        sRID = 0;
        sFiniShed = 0;

        sCurr = *aCurr;
        sChild = *aChild;
        sKeySize = sIndexHeader->mIndex.mKeySize;

        while ( 1 )
        {
            /********************************************************************
             * 참고 Root or Internal Node의 삭제일 경우 일단 마지막 까지 다 처리후
             * leaf 구간의 삭제를 다시한번 진행을 한다
             ********************************************************************/

            /* child node에서 가장 큰값의 node 찾는다 */
            sFound = sChild->mIndexSlotHeader.mNodeCount - 1;


            /* 하위 노드의 제일큰 값 기준으로 계속 내려간다 */
            /* mChiild 0보다 크다는 것은 하위 node 뙤는 leaf가 있다는 것이다 */
            if ( sChild->mChild[sFound + 1] >= 0 && sChild->mIndexSlotHeader.mLeafcheck != 1 )
            {
                _CALL( sSegMgr->Slot2Addr ( sChild->mChild[sFound + 1], &sChild ) );

                /* sChild  한번 찾았으면 한번 다시 삭제루틴을 타야 한다 */
                sSlotOverCheck = 2;
            }
            else
            {
                /* key swap process */

                /* 해당 Slot의 변경이 이루어 지기 때문에 해당 slot에 lock을 걸어야 한다 */
                _CALL( mSpinLockLib ( &sChild->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
                _CALL( mSpinLockLib ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                /* next node 와 값을 체크하기 위하여 next pointer가져온다 */
                if ( sChild->mIndexSlotHeader.mLeafNextID >= 0 && sSlotOverCheck != 2 )
                {
                    _CALL( sSegMgr->Slot2Addr ( sChild->mIndexSlotHeader.mLeafNextID, &sNextNode ) );

                    /* 해당 Slot의 변경이 이루어 지기 때문에 해당 slot에 lock을 걸어야 한다 */
                    _CALL( mSpinLockLib ( &sNextNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                    /* 상위 코드와 right sibliing 의 첫번째가 같다는 것은 바로 상위 노드의 값의 변경이 이루어
                     * 졌다는 것을 알 수 있다 */
                    if ( dbmIdxIndexCompare ( sIndexHeader,
                                              INDEX_POS( sCurr, aPos, sKeySize ),
                                              INDEX_POS( sNextNode, 0, sKeySize ),
                                              DBM_EQ, 0 ) != 0
                         && sNextNode->mIndexSlotHeader.mLeafcheck == 1 )
                    {
                        /* internal node */
                        sSlotOverCheck = 1;
                    }
                    else
                    {
                        /* leaf unlock process */
                        mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID );
                    }
                }


                /* internal node check */
                if ( sSlotOverCheck == 1 )
                {
                    /* sChild key imsi buffer move */
                    memcpy_s ( sKeyData, INDEX_POS( sChild, sFound, sKeySize ), sKeySize );
                    sRID = sChild->mRID[sFound];

                    /* sChild 상위 노드 copy */
                    memcpy_s ( INDEX_POS( sChild, sFound, sKeySize ), INDEX_POS( sCurr, aPos, sKeySize ), sKeySize );
                    sChild->mRID[sFound] = sCurr->mRID[aPos];

                    /* 상위 노드 하위 노드 copy */
                    memcpy_s ( INDEX_POS( sCurr, aPos, sKeySize ), sKeyData, sKeySize );
                    sCurr->mRID[aPos] = sRID;

                    /* 위에는 서로 change이기 때문에 node count 변경이 없다 */

                    /* next node 우측으로 shift */
                    /* leaf node니까... child 신경쓰지 말자 */

                    /* data move */
                    memcpy_s ( INDEX_POS( sNextNode, 0, sKeySize ), INDEX_POS( sCurr, aPos, sKeySize ), sKeySize );
                    sNextNode->mRID[0] = sCurr->mRID[aPos];
                    //sNextNode->mChild[0] = sCurr->mChild[aPos+1];

                    /* Btree Check 조정 value 변경 */
                    mvpAtomicInc64 ( &sCurr->mBtreeCheck );
                    mvpAtomicInc64 ( &sChild->mBtreeCheck );
                    mvpAtomicInc64 ( &sNextNode->mBtreeCheck );
                }
                else
                {
                    /********************************************************************************
                     * 참고 :
                     *                           [7 13]
                     *          [3 5]            [9 11]                [15 17]
                     *     [1 2][3 4][5 6]  [7 8][9 10][11 12]  [13 14][15 16][17 18 19]
                     *     7를 삭제한다고 하였을 경우 삭제 알고리즘에 의해서 6값을 삭제 후
                     *     leaf ndoe에서 7의 값을 찾아 상위로 올라가는 값 6으로  치환을 해준다
                     *********************************************************************************/

                    /* sChild key imsi buffer move */
                    memcpy_s ( sKeyData, INDEX_POS( sChild, sFound, sKeySize ), sKeySize );
                    sRID = sChild->mRID[sFound];

                    if ( sChild->mIndexSlotHeader.mLeafNextID >= 0 )
                    {
                        _CALL( sSegMgr->Slot2Addr ( sChild->mIndexSlotHeader.mLeafNextID, &sChangeNode ) );
                    }
                    else
                    {
                        if ( unlikely( sChild->mIndexSlotHeader.mLeafNextID < 0 ) ) //, DBM_INDEX_NEXTID_FAIL );
                        {
                            DBM_ERR ( "dbm index fail" );
                            _THROW( ERR_DBM_INVALID_KEY_VALUE );
                        }
                    }

                    do
                    {
                        /*  LeafNextID 제거하기 위하여 참조되는 sChangeNode가 변경이 이루어 질수 있기에 해당
                         *  node에 대한 spin lock를 건다 */
                        _CALL( mSpinLockLib ( &sChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                        for ( i = 0; i < sChangeNode->mIndexSlotHeader.mNodeCount; i++ )
                        {
                            if ( dbmIdxIndexCompare ( sIndexHeader,
                                                      INDEX_POS( sChangeNode, i, sKeySize ),
                                                      INDEX_POS( sCurr, aPos, sKeySize ),
                                                      DBM_EQ, 0 ) != 0
                                 && sChangeNode->mIndexSlotHeader.mLeafcheck == 1 )
                            {

                                memcpy_s ( INDEX_POS( sChangeNode, i, sKeySize ), sKeyData, sKeySize );
                                sChangeNode->mRID[i] = sRID;

                                sFiniShed = 1;
                            }
                        }

                        if ( sFiniShed != 1 )
                        {
                            /* leaf unlock process */
                            mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );

                            sRC = sSegMgr->Slot2Addr ( sChangeNode->mIndexSlotHeader.mLeafNextID, &sChangeNode );
                            if ( unlikely( sRC != 0 ) ) // || sChangeNode == NULL, DBM_INDEX_SLOT2ADDR_FAIL4 );
                            {
                                /* leaf unlock process */
                                mvpAtomicCas32_s(&sChangeNode->mIndexSlotHeader.mLock,-1,aTransID);

                                DBM_ERR ( "dbm slot2addr_fila4 [%d]", sRC );
                                _THROW( ERR_DBM_SLOT2ADDR_FAIL );
                            }
                        }
                        else
                        {
                            /*
                             * Btree Check 조정 value 변경
                             * 순서바뀌면 안된다. - 2014/07/18 -
                             */
                            mvpAtomicInc64 ( &sChangeNode->mBtreeCheck );

                            /* leaf unlock process */
                            mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
                        }

                    }
                    while ( !sFiniShed );

                    memcpy_s ( INDEX_POS( sChild, sFound, sKeySize ), INDEX_POS( sCurr, aPos, sKeySize ), sKeySize );
                    sChild->mRID[sFound] = sCurr->mRID[aPos];

                    /* 상위 노드 하위 노드 copy */
                    memcpy_s ( INDEX_POS( sCurr, aPos, sKeySize ), sKeyData, sKeySize );
                    sCurr->mRID[aPos] = sRID;

                    /* Btree Check 조정 value 변경 */
                    mvpAtomicInc64 ( &sCurr->mBtreeCheck );
                    mvpAtomicInc64 ( &sChild->mBtreeCheck );
                }

                /*상위 노드를 다시 찾게 되었을때 변경이 될 수 있기 때문에 다시한번 schild변경해 준다 */
                *aChild = sChild;

                /* leaf unlock process */
                mvpAtomicCas32_s( &sChild->mIndexSlotHeader.mLock, -1, aTransID );
                mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

                if ( sSlotOverCheck == 1 )
                {
                    /* leaf unlock process */
                    mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID );
                }

                break;
            }
        } /* while */
    }
    _CATCH
    {
        _CATCH_WARN;

        {
            /* leaf unlock process */
            mvpAtomicCas32_s( &sChild->mIndexSlotHeader.mLock, -1, aTransID );
            mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

            if ( sSlotOverCheck == 1 )
            {
                /* leaf unlock process */
                mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID );
            }
        }
    }
    _FINALLY
    _END
} /* dbmIdxDeleteInternalCheck */


/********************************************************************
 * ID : mDeleteNuInternalCheck
 *
 * Description(Non-unique index type)
 *   dbm Index Delete Internal node 인지 leaf node인지 체크를 하고 해당 key값을
 *   Chagge 한다.
 *   Internal Node에 key 값이 저장 되어 있다면 해당 key 값을 leaf node와 chage
 *   한 후 해당 key 값을 삭제하여 주고 B-Tree 조정을 하도록 한다.
 *
 *  Argument
 *  aCurr        : input : Key 값이 저장 되어 있는 Node Pointer
 *  aChild       : input : Key 값의 자식 노드의 Pointer
 *  aPos         : input : 해당 key 값이 저장되어 있는 노드의 position
 *  aTransID     : input : Transaction ID
 *  aIndexHeader : input : dbm Index header
 *  aSegMgr      : input : Index Segment pointer
 *  aLockMgr     : input : Lock Manager pointer
 *
********************************************************************/
_VOID dbmIdxDeleteInternalCheckNu ( dbmIndexNode** aCurr ,
                                    dbmIndexNode** aChild ,
                                    int aPos ,
                                    int aTransID ,
                                    dbmIndexHeader* aIndexHeader ,
                                    dbmSegmentManager* aSegMgr ,
                                    dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sCurr;          // Index 현재 node pointer
    dbmIndexNode*       sChild;         // Index Child node pointer
    dbmIndexNode*       sNextNode;      // Index 현재의 next node pointer
    dbmIndexNode*       sChangeNode;    // Index 상위 노드 Change pointer

    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;

    char                sKeyData[DBM_INDEX_KEY_MAX_SIZE+8];
    int                 sFound;         // internal node find
    int                 sSlotOverCheck; // 0:root node 1:interal node
    int                 sPos;           // leaf key position
    int                 sFiniShed;
    long long           sRID;
    int                 sKeySize;
    int                 sRC;            // return value
    int                 i;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        /* 초기화 처리 */
        sCurr = NULL;
        sChild = NULL;
        sNextNode = NULL;
        sChangeNode = NULL;

        memset_s ( sKeyData, 0x00, sizeof( sKeyData ) );
        sSlotOverCheck = 0;
        sPos = 0;
        sRID = 0;
        sFiniShed = 0;

        sCurr = *aCurr;
        sChild = *aChild;

        sKeySize = INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );

        while ( 1 )
        {
            /********************************************************************
             * 참고 Root or Internal Node의 삭제일 경우 일단 마지막 까지 다 처리후
             * leaf 구간의 삭제를 다시한번 진행을 한다
             ********************************************************************/

            /* child node에서 가장 큰값의 node 찾는다 */
            sFound = sChild->mIndexSlotHeader.mNodeCount - 1;

            /* 하위 노드의 제일큰 값 기준으로 계속 내려간다 */
            /* mChiild 0보다 크다는 것은 하위 node 뙤는 leaf가 있다는 것이다 */
            if ( sChild->mChild[sFound + 1] >= 0 )
            {
                _CALL( sSegMgr->Slot2Addr ( sChild->mChild[sFound + 1], &sChild ) );

                /* sChild  한번 찾았으면 한번 다시 삭제루틴을 타야 한다 */
                sSlotOverCheck = 2;
            }
            else
            {
                /* key swap process */

                /* 해당 Slot의 변경이 이루어 지기 때문에 해당 slot에 lock을 걸어야 한다 */
                _CALL( mSpinLockLib ( &sChild->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
                _CALL( mSpinLockLib ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                /* next node 와 값을 체크하기 위하여 next pointer가져온다 */
                if ( sChild->mIndexSlotHeader.mLeafNextID >= 0 && sSlotOverCheck != 2 )
                {
                    _CALL( sSegMgr->Slot2Addr ( sChild->mIndexSlotHeader.mLeafNextID, &sNextNode ) );

                    /* 해당 Slot의 변경이 이루어 지기 때문에 해당 slot에 lock을 걸어야 한다 */
                    _CALL( mSpinLockLib ( &sNextNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                    /* 상위 코드와 right sibliing 의 첫번째가 같다는 것은 바로 상위 노드의 값의 변경이 이루어
                     * 졌다는 것을 알 수 있다 */
                    if ( dbmIdxIndexCompare ( sIndexHeader,
                                              INDEX_POS( sCurr, aPos, sKeySize ),
                                              INDEX_POS( sNextNode, 0, sKeySize ),
                                              DBM_EQ, 0 ) != 0
                         && sNextNode->mIndexSlotHeader.mLeafcheck == 1 )
                    {
                        /* internal node */
                        sSlotOverCheck = 1;
                    }
                    else
                    {
                        /* leaf unlock process */
                        mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID );
                    }

                }


                /* internal node check */
                if ( sSlotOverCheck == 1 )
                {
                    /* sChild key imsi buffer move */
                    memcpy_s ( sKeyData, INDEX_POS( sChild, sFound, sKeySize ), sKeySize );
                    sRID = sChild->mRID[sFound];

                    /* sChild 상위 노드 copy */
                    memcpy_s ( INDEX_POS( sChild, sFound, sKeySize ), INDEX_POS( sCurr, aPos, sKeySize ), sKeySize );
                    sChild->mRID[sFound] = sCurr->mRID[aPos];

                    /* 상위 노드 하위 노드 copy */
                    memcpy_s ( INDEX_POS( sCurr, aPos, sKeySize ), sKeyData, sKeySize );
                    sCurr->mRID[aPos] = sRID;

                    /* 위에는 서로 change이기 때문에 node count 변경이 없다 */

                    /* next node 우측으로 shift */
                    /* leaf node니까... child 신경쓰지 말자 */

                    /* data move */
                    memcpy_s ( INDEX_POS( sNextNode, 0, sKeySize ), INDEX_POS( sCurr, aPos, sKeySize ), sKeySize );
                    sNextNode->mRID[0] = sCurr->mRID[aPos];
                    //sNextNode->mChild[0] = sCurr->mChild[aPos+1];

                    /* Btree Check 조정 value 변경 */
                    mvpAtomicInc64 ( &sCurr->mBtreeCheck );
                    mvpAtomicInc64 ( &sChild->mBtreeCheck );
                    mvpAtomicInc64 ( &sNextNode->mBtreeCheck );

                }
                else
                {
                    /********************************************************************************
                     * 참고 :
                     *                           [7 13]
                     *          [3 5]            [9 11]                [15 17]
                     *     [1 2][3 4][5 6]  [7 8][9 10][11 12]  [13 14][15 16][17 18 19]
                     *     7를 삭제한다고 하였을 경우 삭제 알고리즘에 의해서 6값을 삭제 후
                     *     leaf ndoe에서 7의 값을 찾아 상위로 올라가는 값 6으로  치환을 해준다
                     *********************************************************************************/

                    /* sChild key imsi buffer move */
                    memcpy_s ( sKeyData, INDEX_POS( sChild, sFound, sKeySize ), sKeySize );
                    sRID = sChild->mRID[sFound];

                    if ( sChild->mIndexSlotHeader.mLeafNextID >= 0 )
                    {
                        _CALL( sSegMgr->Slot2Addr ( sChild->mIndexSlotHeader.mLeafNextID, &sChangeNode ) );
                    }
                    else
                    {
                        if ( sChild->mIndexSlotHeader.mLeafNextID < 0 ) //, DBM_INDEX_NEXTID_FAIL );
                        {
                            DBM_ERR( "dbm index fail" );
                            _THROW( ERR_DBM_INVALID_KEY_VALUE );
                        }
                    }

                    do /* while */
                    {

                        /*  LeafNextID 제거하기 위하여 참조되는 sChangeNode가 변경이 이루어 질수 있기에 해당
                         *  node에 대한 spin lock를 건다 */
                        _CALL( mSpinLockLib ( &sChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                        for ( i = 0; i < sChangeNode->mIndexSlotHeader.mNodeCount; i++ )
                        {
                            if ( dbmIdxIndexCompare ( sIndexHeader,
                                                      INDEX_POS( sChangeNode, i, sKeySize ),
                                                      INDEX_POS( sCurr, aPos, sKeySize ), DBM_EQ, 0 ) != 0
                                    && sChangeNode->mIndexSlotHeader.mLeafcheck == 1 )
                            {
                                memcpy_s ( INDEX_POS( sChangeNode, i, sKeySize ), sKeyData, sKeySize );
                                sChangeNode->mRID[i] = sRID;

                                sFiniShed = 1;
                            }
                        } /* for */

                        if ( sFiniShed != 1 )
                        {
                            /* leaf unlock process */
                            mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );

                            sRC = sSegMgr->Slot2Addr ( sChangeNode->mIndexSlotHeader.mLeafNextID, &sChangeNode );
                            if ( unlikely ( sRC != 0 ) ) // || sChangeNode == NULL, DBM_INDEX_SLOT2ADDR_FAIL4 );
                            {
                                /* leaf unlock process */
                                mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );

                                DBM_ERR ( "dbm slot2addr_fila4 [%d]", sRC );
                                _THROW( ERR_DBM_SLOT2ADDR_FAIL );
                            }
                        }
                        else
                        {
                            /* Btree Check 조정 value 변경 */
                            mvpAtomicInc64 ( &sChangeNode->mBtreeCheck );
                            /* leaf unlock process */
                            mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
                        }

                    }
                    while ( !sFiniShed );

                    memcpy_s ( INDEX_POS( sChild, sFound, sKeySize ), INDEX_POS( sCurr, aPos, sKeySize ), sKeySize );
                    sChild->mRID[sFound] = sCurr->mRID[aPos];

                    /* 상위 노드 하위 노드 copy */
                    memcpy_s ( INDEX_POS( sCurr, aPos, sKeySize ), sKeyData, sKeySize );
                    sCurr->mRID[aPos] = sRID;

                    /* Btree Check 조정 value 변경 */
                    mvpAtomicInc64 ( &sCurr->mBtreeCheck );
                    mvpAtomicInc64 ( &sChild->mBtreeCheck );
                }


                /*상위 노드를 다시 찾게 되었을때 변경이 될 수 있기 때문에 다시한번 schild변경해 준다 */
                *aChild = sChild;

                /* leaf unlock process */
                mvpAtomicCas32_s( &sChild->mIndexSlotHeader.mLock, -1, aTransID );
                mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

                if ( sSlotOverCheck == 1 )
                {
                    mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID );
                }

                break;
            }
        }
    }
    _CATCH
    {
        _CATCH_WARN;

        {
            /* leaf unlock process */
            mvpAtomicCas32_s( &sChild->mIndexSlotHeader.mLock, -1, aTransID );
            mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

            if ( sSlotOverCheck == 1 )
            {
                mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID );
            }
        }
    }
    _FINALLY
    _END
} /* dbmIdxDeleteInternalCheckNu */


/********************************************************************
 * ID : mDeleteShift
 *
 * Description
 *   현재 노드의 key 삭제하고 Tree 조정을 하도록 한다(shit 처리를 한다.)
 *
 * Argument
 *     aCurr        : input,ouput :  delete key가 있는  Node의 pointer
 *     aPos         : input : key가 저장 되어 있는 노드의 position
 *     aTransID     : input : Transaction ID
 *     aIndexHeader : input : dbm Index Header
 *     aLockMgr     : input : Index Lock heandle
 *
********************************************************************/
_VOID dbmIdxDeleteShift ( dbmIndexNode** aCurr , int aPos , int aTransID ,
                          dbmIndexHeader* aIndexHeader , dbmLockManager* aLockMgr )
{
    dbmIndexHeader* sIndexHeader;
    dbmIndexNode*   sCurr;
    int     sKeySize;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sCurr = *aCurr;

        sKeySize = ( g_bIsUniqueIndex ) ? sIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );

        /************************************************************
         * 참고 : 일단 여기 부분을 타는 놈은 leaf만 타는 것이다.. leaf가
         *        아닌놈이 탔다 그러면 잘못된 것이기 때문에 leaf에 대한
         *        체크는 위에서 하기로 하고 여기에서 삭제는 key or data slot
         *        만 하는 것으로 한다 .
         ************************************************************/

        /* index node lock */
        _CALL( mSpinLockLib ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

        if ( aPos == DBM_INDEX_DEGREE - 2 )
        {
            memset_s ( INDEX_POS( sCurr, aPos, sKeySize ), 0x00, sKeySize );
            sCurr->mRID[aPos] = -1;
        }
        else
        {
            /*********************************************************************
             * aPos :현재의 삭제 포지션
             * aPos+1이 (DBM_INDEX_DEGREE-1) 크게되면 포진션을 이동할 필요가 없다
             * 참고 : aPos 위치를 삭제되었고 aPos에 다음 포지션(aPos+1)부터
             *        (DBM_INDEX_DEGREE-1) - (aPos+1)) 이동해라,
             *        (남은 포지션만큼 이동하게 된다)
             **********************************************************************/

            if ( ( aPos + 1 ) < ( DBM_INDEX_DEGREE - 1 ) )
            {
                /* key move */
                memmove_s ( INDEX_POS( sCurr, aPos, sKeySize ),
                            INDEX_POS( sCurr, aPos + 1, sKeySize ),
                            sKeySize * ( ( DBM_INDEX_DEGREE - 1 ) - ( aPos + 1 ) ) );

                /* data move */
                memmove_s ( &sCurr->mRID[aPos],
                            &sCurr->mRID[aPos + 1], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 1 ) - ( aPos + 1 ) ) );
            }

            /* 빈자리  초기화 */
            memset_s ( INDEX_POS( sCurr, DBM_INDEX_DEGREE - 2, sKeySize ), 0x00, sKeySize );
        }

        /* 여기까지 되었다는 것은 정상 적으로 한건이 삭제 되었다는 것을 의미하기
         * 때문에 node count 하나를 감소 시킨다 */
        //TODO: 2014.11.20. -okt- 다른 모든 구간에서 mIndexSlotHeader.mLock을 잡고 진행하기 때문에 문제가 없지만. 통일성.
        //      나중에는 오히려, 락잡았으니. 성능을 위해.. atomic 을 빼야할듯
        //sCurr->mIndexSlotHeader.mNodeCount -- ;
        mvpAtomicDec32 ( &sCurr->mIndexSlotHeader.mNodeCount );

        /* leaf unlock 처리 */
        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* dbmIdxDeleteShift */


/********************************************************************
 * ID : mDeleteSiblingSet
 *
 * Description
 *   현재의 ndoe B-Tree 조정을 left or right sibling 할것인 결정한다.
 *
 * Argument
 *     aNewNode   : input : 비교 대상 key가 있는 노드의 pointer
 *     aPos       : input : Node에 key가 저장 되어 있는 position
 *     aBtreeCheck: output: Delete 처리 Check 값.
 *     aSegMgr    : input : Index segment pointer
 *
 * BtreeCheck : 1(left sibling) 2(right sibling)
 *
********************************************************************/
int dbmIdxDeleteSiblingSet ( dbmIndexNode* aNewNode, int aPos, int* aBtreeCheck, dbmSegmentManager* aSegMgr )
{
    dbmSegmentManager*  sSegMgr = aSegMgr;
    dbmIndexNode*       sNewNode = NULL;

    _TRY
    {
        if ( aPos == 0 )
        {
            /* 상위 position이 0번째이면 right sibling 처리 한다 */
            /* right sibling process */
            _CALL( sSegMgr->Slot2Addr ( aNewNode->mChild[aPos + 1], &sNewNode ) );

            /* 우측 sibling이 DBM_INDEX_DEGREE 중간값보다 크다면 right sibling 처리 한다. */
            if ( sNewNode->mIndexSlotHeader.mNodeCount > ( g_DBM_INDEX_DEGREE_add1_div2 - 1 ) )
            {
                *aBtreeCheck = 2;
                return TRUE; // 1; // 의도적
            }

            /* 중간 값보다 크지  않다면 right sibling 으로 parent merge 처리 한다 */
        }
        else if ( aPos == DBM_INDEX_DEGREE - 1 )
        {
            /* 상위 position이 마지막이면 left sibling 처리 한다 (DEGREE-1) */
            /* left sibling process */
            _CALL( sSegMgr->Slot2Addr ( aNewNode->mChild[aPos - 1], &sNewNode ) );

            /* 좌측 sibling이 DBM_INDEX_DEGREE 중간값보다 크다면 left sibling 처리 한다. */
            if ( sNewNode->mIndexSlotHeader.mNodeCount > ( g_DBM_INDEX_DEGREE_add1_div2 - 1 ) )
            {
                *aBtreeCheck = 1;
                return TRUE; // 1; // 의도적
            }
        }
        else
        {
            /* pos가 중간일 때의 처리를 한다 */

            /* left sibling check */
            _CALL( sSegMgr->Slot2Addr ( aNewNode->mChild[aPos - 1], &sNewNode ) );

            if ( sNewNode->mIndexSlotHeader.mNodeCount > ( g_DBM_INDEX_DEGREE_add1_div2 - 1 ) )
            {
                *aBtreeCheck = 1;
                return TRUE; // 1; // 의도적
            }

            if ( aNewNode->mChild[aPos + 1] >= 0 )
            {
                /* right sibling check */
                _CALL( sSegMgr->Slot2Addr ( aNewNode->mChild[aPos + 1], &sNewNode ) );

                if ( sNewNode->mIndexSlotHeader.mNodeCount > ( g_DBM_INDEX_DEGREE_add1_div2 - 1 ) )
                {
                    *aBtreeCheck = 2;
                    return TRUE; // 1; // 의도적
                }
            }
        }

        // 2014.09.26 -okt- 여기에 도달하면 상위단에서 오류처리가 센다. 죽고 확인하자.
        // -shw- 확인받음. 정상이라고함.
        return FALSE; // 의도적
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    //_END
    return ERR_DBM_SLOT2ADDR_FAIL;
} /* dbmIdxDeleteSiblingSet */


/********************************************************************
 * ID : mDeleteLeftSibling
 *
 * Description
 *   좌측 sibling, parent 와 합쳐 B-Tree 조정을 하도록 한다.
 *   좌측 노드를 기준으로 Tree 조정을 하도록 한다.
 * Argument
 *     aNewNode     : input : 부모노드의 key가 저장되어 있는 pointer
 *     aCurr        : input : 자식 노드의 key가 저장되어 있는 pointer
 *     aPos         : input : 부모 노드에서 key가 가리키도 있는 자식 노드의 position
 *     aTransID     : input : Transaction ID
 *     aIndexHeader : input : dbm Index Header
 *     aSegMgr      : input : Index Segment Pointer
 *     aLockMgr     : input : Index Lock Handle
 *
********************************************************************/
_VOID dbmIdxDeleteLeftSibling ( dbmIndexNode** aNewNode ,
                                dbmIndexNode** aCurr ,
                                int aPos ,
                                int aTransID ,
                                dbmIndexHeader* aIndexHeader ,
                                dbmSegmentManager* aSegMgr ,
                                dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sNewNode = NULL;
    dbmIndexNode*       sCurr = NULL;
    dbmIndexNode*       sChild = NULL;
    dbmIndexNode*       sChangeNode = NULL;

    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;

    int     sKeySize;
    int     sTemp2;         /* 임시 element count */
    int     sTemp3;         /* 임시 element count */
    int     sLeafCheck = 0; /* sLeafCheck 1: leaf process 0:non-leaf process */
    int     sMoveSize;      /* move size *        */
    int     i;

    _TRY
    {
        /* 초기화 처리 */
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        sNewNode = *aNewNode;
        sCurr = *aCurr;
        sKeySize = sIndexHeader->mIndex.mKeySize;

        /* child left sibling */
        /* 하위 노드의 좌측 노드 */
        _CALL( sSegMgr->Slot2Addr ( sNewNode->mChild[aPos - 1], &sChild ) );

        /* 2014.02.18 -shw- delete key 처리 시  logging  필요없어 일단 막음 */
        /* sChild에 대한 Index Logging 처리를 한다 */
        //sRC = mIndexLogging(&sChild->mCurrSlot,aTransID);
        //_IF_RAISE(sRC, DBM_INDEX_LOGGING_FAIL);

        /* 하위 노드의  좌측 노드의 element 개수 */
        sTemp3 = sChild->mIndexSlotHeader.mNodeCount;

        /* 균형을 맞추기 위해 left sibling nTemp개수만큼 분배 처리를 한다 */
        /* 쉽게 생각을 해라... 걍.. left sibling에서 이동하려는 개수라 생각... */
        /* 남은 노드수에서 / 2 을 해서 균형있게 분배해라.. */
        sTemp2 = ( sTemp3 - sCurr->mIndexSlotHeader.mNodeCount ) >> 1;

        /* position 구하기 위하여 search 하는데 다른 node와 lock 경합이 필요하다 */
        _CALL( mSpinLockLib ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sNewNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sChild->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );


        /* pCurr에서 nTemp2 이동 node수만큼 우측으로 shift 처리 한다. 빈자리를 만들어 주자.... */
        /* DBM_INDEX_DEGREE-2 --> key 삭제 1 + 우측으로 shift 1 최대 -2 만큼 처리를 한다 */
        if ( DBM_INDEX_DEGREE - 2 >= sTemp2 )
        {
            memmove_s ( INDEX_POS( sCurr, sTemp2, sKeySize ),
                        INDEX_POS( sCurr, 0, sKeySize ),
                        sKeySize * ( ( DBM_INDEX_DEGREE - 2 ) - ( sTemp2 - 1 ) ) );
            memmove_s ( &sCurr->mRID[sTemp2],
                        &sCurr->mRID[0], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 2 ) - ( sTemp2 - 1 ) ) );
            memmove_s ( &sCurr->mChild[sTemp2 + 1],
                        &sCurr->mChild[1], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 2 ) - ( sTemp2 - 1 ) ) );
        }
        /* 제일 첫번째 자식값을 이동한 부분의 요소의 pointer로 이동 시켜준다 */
        sCurr->mChild[sTemp2] = sCurr->mChild[0];


        /* 상위 internal node의 맨끝에 있는 노드값을 하위 node에 삽입하자 */
        memcpy_s ( INDEX_POS( sCurr, sTemp2 - 1, sKeySize ),
                   INDEX_POS( sNewNode, aPos - 1, sKeySize ), sKeySize );
        sCurr->mRID[sTemp2 - 1] = sNewNode->mRID[aPos - 1];

        /* 상위 노드는 없어지고 현재의 노드는 증가 하므로 해당 node Count 변경하자 */
        mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );
        sNewNode->mIndexSlotHeader.mNodeCount = sNewNode->mIndexSlotHeader.mNodeCount - 1;

        /* left sibling에서 nTemp2-1만큼 pCurr로 이동처리 한다. */
        /* -1의 의미는 위의 root에서 하나 이동 했으니 이동한 만큼 -1을 해주는 것이다 */
        /* 참고 : sTemp3 = sChild element count */
        /*        leaf와 구분하여 처리 하지 않는 이유는 아래에서 left구간의 처리를 따로 해주기 때문이다. */
        for ( i = 0; i < sTemp2 - 1; ++i )
        {
            /* -2는 root에서 미리 한번 이동 했기 때문에 -2의 값을 해준다 */
            memcpy_s ( INDEX_POS( sCurr, sTemp2 - i - 2, sKeySize ),
                       INDEX_POS( sChild, sTemp3 - i - 1, sKeySize ), sKeySize );
            sCurr->mRID[sTemp2 - i - 2] = sChild->mRID[sTemp3 - i - 1];
            sCurr->mChild[sTemp2 - i - 1] = sChild->mChild[sTemp3 - i];

            mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );

            if ( sChild->mChild[sTemp3 - i] >= 0 && sChild->mIndexSlotHeader.mLeafcheck != 1 )
            {
                /* sChild의 child가 sCurr로 이동이 되므로 sChild의 Child 노드들의 root id를 바꾸어 주어야 한다 */
                _CALL( sSegMgr->Slot2Addr ( sChild->mChild[sTemp3 - i], &sChangeNode ) );

                _CALL( mSpinLockLib ( &sChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                sChangeNode->mIndexSlotHeader.mRootSlotID = sCurr->mCurrSlot;

                mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
            }
        }
        /* 이동한 자식의 값을 left sibling에 옮겨준다
         * 참고로 위의 포문을 타지 않아도 left sibling의 맨마직막 값을 root로 옮기기 때문에
         * 위의 마지막 자식의 값을 옮겨준다 */
        sCurr->mChild[0] = sChild->mChild[sTemp3 - sTemp2 + 1];

        if ( sChild->mChild[sTemp3 - sTemp2 + 1] >= 0 && sChild->mIndexSlotHeader.mLeafcheck != 1 )
        {
            /* sChild의 child가 sCurr로 이동이 되므로 sChild의 Child 노드들의 root id를 바꾸어 주어야 한다 */
            _CALL( sSegMgr->Slot2Addr ( sChild->mChild[sTemp3 - sTemp2 + 1], &sChangeNode ) );

            _CALL( mSpinLockLib ( &sChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

            sChangeNode->mIndexSlotHeader.mRootSlotID = sCurr->mCurrSlot;

            mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
        }


        /* 하위 노드의 left sibling에서 가장 큰값을 상위 internal node로 올려버리자. */
        memcpy_s ( INDEX_POS( sNewNode, aPos - 1, sKeySize ),
                   INDEX_POS( sChild, sTemp3 - sTemp2, sKeySize ), sKeySize );
        sNewNode->mRID[aPos - 1] = sChild->mRID[sTemp3 - sTemp2];
        /* 참고 : child는 위에서 옮겨 주었다 */

        /* NODE간 이동관련 nodecoutn 정리 */
        mvpAtomicInc32 ( &sNewNode->mIndexSlotHeader.mNodeCount );
        /* sChiild 하위 노드는 아래에서 한꺼번에 한다 */

        /* 하위 노드의 left 에서 올린만큼 초기화를 해주자. */
        /* -1의 의미는 array의 값을 빼주는 의미이다 실제 1 array [0] */
        /* sTemp3 = sChild element count sTemp2 : schid -> sCurr 이동 개수 */
        /* sTemp3-sTemp2의 의미는 이동한 숫자만큼 sTemp3의 pointer의 위치에서 삭제하려는 것이다 */
        sMoveSize = ( sTemp3 - 1 ) - ( sTemp3 - sTemp2 - 1 );

        if ( ( sTemp3 - 1 ) > ( sTemp3 - sTemp2 - 1 ) )
        {
            memset_s ( INDEX_POS( sChild, sTemp3 - sTemp2, sKeySize ), 0x00, sKeySize * sMoveSize );

            //[DONE] #240 mDeleteNodeExist 함수에서 부모의 Child 목록에 자신이 없어서 죽음. ( 2014.03.27 )
            memset_s ( &sChild->mRID[sTemp3 - sTemp2], -1, sizeof(long long) * sMoveSize );
            memset_s ( &sChild->mChild[( ( sTemp3 - sTemp2 ) + 1 )], -1, sizeof(long long) * sMoveSize );  // leaf 구분을 해주어서 초기화를 해야할까???
        }

        /* 삭제한 만큼 노드 count 줄여 준다 */
        sChild->mIndexSlotHeader.mNodeCount = sChild->mIndexSlotHeader.mNodeCount - sTemp2;


        /* 상위 node의 값이 아래로 내려왔고 sCurr적용된 값이 shiht 값과 동일하다면
         * 현재 상위에 있는 값을 아래로 내려 주어야 한다
         * 10 [11 11] --> 10 [10 11] */
        /* sTemp2-1의 위치의 의미는 상위 node가 하위 노드로 내련간 위치를 가르킨다
         * 위에서 sTemp2-1의 위치에 상위 node값을 하위 노르값으로 내렸음 */
        if ( dbmIdxIndexCompare ( sIndexHeader,
                                  INDEX_POS( sCurr, sTemp2 - 1, sKeySize ),
                                  INDEX_POS( sCurr, sTemp2, sKeySize ),
                                  DBM_EQ, 0 )
             && sCurr->mIndexSlotHeader.mLeafcheck == 1 )
        {
            /* leaf 구간의 data를 한칸씩 이동을 하다 */
            memmove_s ( INDEX_POS( sCurr, 1, sKeySize ),
                        INDEX_POS( sCurr, 0, sKeySize ), sKeySize * sTemp2 );
            memmove_s ( &sCurr->mRID[1], &sCurr->mRID[0], sizeof(long long) * sTemp2 );
            memmove_s ( &sCurr->mChild[2], &sCurr->mChild[1], sizeof(long long) * sTemp2 );

            /* 상위 node값을 하위 노드로 내린다 */
            memcpy_s ( INDEX_POS( sCurr, 0, sKeySize ),
                       INDEX_POS( sNewNode, aPos - 1, sKeySize ), sKeySize );
            sCurr->mRID[0] = sNewNode->mRID[aPos - 1];
        }

        /* Btree Check 조정 value 변경 */
        mvpAtomicInc64 ( &sCurr->mBtreeCheck );
        mvpAtomicInc64 ( &sNewNode->mBtreeCheck );
        mvpAtomicInc64 ( &sChild->mBtreeCheck );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    {
        /* leaf unlock 처리 */
        mvpAtomicCas32_s( &sChild->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
    }
    _END
} /* dbmIdxDeleteLeftSibling */


/********************************************************************
 * ID : mDeleteNuLeftSibling
 *
 * Description(non-unique index type)
 *   좌측 sibling, parent 와 합쳐 B-Tree 조정을 하도록 한다.
 *   좌측 노드를 기준으로 Tree 조정을 하도록 한다.
 * Argument
 *     aNewNode     : input : 부모노드의 key가 저장되어 있는 pointer
 *     aCurr        : input : 자식 노드의 key가 저장되어 있는 pointer
 *     aPos         : input : 부모 노드에서 key가 가리키도 있는 자식 노드의 position
 *     aTransID     : input : Transaction ID
 *     aIndexHeader : input : dbm Index Header
 *     aSegMgr      : input : Index Segment Pointer
 *     aLockMgr     : input : Index Lock Handle
 *
********************************************************************/
_VOID dbmIdxDeleteLeftSiblingNu ( dbmIndexNode** aNewNode ,
                                  dbmIndexNode** aCurr ,
                                  int aPos ,
                                  int aTransID ,
                                  dbmIndexHeader* aIndexHeader ,
                                  dbmSegmentManager* aSegMgr ,
                                  dbmLockManager* aLockMgr )
{
    dbmSegmentManager*  sSegMgr;
    dbmIndexHeader*     sIndexHeader;
    dbmIndexNode*       sNewNode;
    dbmIndexNode*       sCurr;
    dbmIndexNode*       sChild;
    dbmIndexNode*       sChangeNode;

    int     sKeySize;
    int     sTemp2;         /* 임시 element count */
    int     sTemp3;         /* 임시 element count */
    int     sLeafCheck;     /* sLeafCheck 1: leaf process 0:non-leaf process */
    int     sMoveSize;      /* move size *        */
    int     i;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        /* 초기화 처리 */
        sNewNode = NULL;
        sCurr = NULL;
        sChild = NULL;
        sChangeNode = NULL;
        sLeafCheck = 0;

        sNewNode = *aNewNode;
        sCurr = *aCurr;

        sKeySize = INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );

        /* child left sibling */
        /* 하위 노드의 좌측 노드 */
        _CALL( sSegMgr->Slot2Addr ( sNewNode->mChild[aPos - 1], &sChild ) );

        /* 2014.02.18 -shw- delete key 처리 시  logging  필요없어 일단 막음 */
        /* sChild에 대한 Index Logging 처리를 한다 */
        //sRC = mIndexLogging(&sChild->mCurrSlot,aTransID);
        //_IF_RAISE(sRC, DBM_INDEX_LOGGING_FAIL);

        /* 하위 노드의  좌측 노드의 element 개수 */
        sTemp3 = sChild->mIndexSlotHeader.mNodeCount;

        /* 균형을 맞추기 위해 left sibling nTemp개수만큼 분배 처리를 한다 */
        /* 쉽게 생각을 해라... 걍.. left sibling에서 이동하려는 개수라 생각... */
        /* 남은 노드수에서 / 2 을 해서 균형있게 분배해라.. */
        sTemp2 = ( sTemp3 - sCurr->mIndexSlotHeader.mNodeCount ) >> 1;


        /* position 구하기 위하여 search 하는데 다른 node와 lock 경합이 필요하다 */
        _CALL( mSpinLockLib ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sNewNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sChild->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

        /* pCurr에서 nTemp2 이동 node수만큼 우측으로 shift 처리 한다. 빈자리를 만들어 주자.... */
        /* DBM_INDEX_DEGREE-2 --> key 삭제 1 + 우측으로 shift 1 최대 -2 만큼 처리를 한다 */
        if ( DBM_INDEX_DEGREE - 2 >= sTemp2 )
        {
            memmove_s ( INDEX_POS( sCurr, sTemp2, sKeySize ),
                        INDEX_POS( sCurr, 0, sKeySize ), sKeySize * ( ( DBM_INDEX_DEGREE - 2 ) - ( sTemp2 - 1 ) ) );
            memmove_s ( &sCurr->mRID[sTemp2],
                        &sCurr->mRID[0], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 2 ) - ( sTemp2 - 1 ) ) );
            memmove_s ( &sCurr->mChild[sTemp2 + 1],
                        &sCurr->mChild[1], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 2 ) - ( sTemp2 - 1 ) ) );
        }
        /* 제일 첫번째 자식값을 이동한 부분의 요소의 pointer로 이동 시켜준다 */
        sCurr->mChild[sTemp2] = sCurr->mChild[0];

        /* 상위 internal node의 맨끝에 있는 노드값을 하위 node에 삽입하자 */
        memcpy_s ( INDEX_POS( sCurr, sTemp2 - 1, sKeySize ),
                   INDEX_POS( sNewNode, aPos - 1, sKeySize ), sKeySize );
        sCurr->mRID[sTemp2 - 1] = sNewNode->mRID[aPos - 1];

        /* 상위 노드는 없어지고 현재의 노드는 증가 하므로 해당 node Count 변경하자 */
        mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );
        sNewNode->mIndexSlotHeader.mNodeCount = sNewNode->mIndexSlotHeader.mNodeCount - 1;


        /* left sibling에서 nTemp2-1만큼 pCurr로 이동처리 한다. */
        /* -1의 의미는 위의 root에서 하나 이동 했으니 이동한 만큼 -1을 해주는 것이다 */
        /* 참고 : sTemp3 = sChild element count */
        /*        leaf와 구분하여 처리 하지 않는 이유는 아래에서 left구간의 처리를 따로 해주기 때문이다. */
        for ( i = 0; i < sTemp2 - 1; ++i )
        {
            /* -2는 root에서 미리 한번 이동 했기 때문에 -2의 값을 해준다 */
            memcpy_s ( INDEX_POS( sCurr, sTemp2 - i - 2, sKeySize ),
                       INDEX_POS( sChild, sTemp3 - i - 1, sKeySize ), sKeySize );
            sCurr->mRID[sTemp2 - i - 2] = sChild->mRID[sTemp3 - i - 1];
            sCurr->mChild[sTemp2 - i - 1] = sChild->mChild[sTemp3 - i];

            mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );

            if ( sChild->mChild[sTemp3 - i] >= 0 && sChild->mIndexSlotHeader.mLeafcheck != 1 )
            {
                /* sChild의 child가 sCurr로 이동이 되므로 sChild의 Child 노드들의 root id를 바꾸어 주어야 한다 */
                _CALL( sSegMgr->Slot2Addr ( sChild->mChild[sTemp3 - i], &sChangeNode ) );

                _CALL( mSpinLockLib ( &sChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                sChangeNode->mIndexSlotHeader.mRootSlotID = sCurr->mCurrSlot;

                mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
            }
        }
        /* 이동한 자식의 값을 left sibling에 옮겨준다
         * 참고로 위의 포문을 타지 않아도 left sibling의 맨마직막 값을 root로 옮기기 때문에
         * 위의 마지막 자식의 값을 옮겨준다 */
        sCurr->mChild[0] = sChild->mChild[sTemp3 - sTemp2 + 1];

        if ( sChild->mChild[sTemp3 - sTemp2 + 1] >= 0 && sChild->mIndexSlotHeader.mLeafcheck != 1 )
        {
            /* sChild의 child가 sCurr로 이동이 되므로 sChild의 Child 노드들의 root id를 바꾸어 주어야 한다 */
            _CALL( sSegMgr->Slot2Addr ( sChild->mChild[sTemp3 - sTemp2 + 1], &sChangeNode ) );

            _CALL( mSpinLockLib ( &sChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

            sChangeNode->mIndexSlotHeader.mRootSlotID = sCurr->mCurrSlot;

            mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
        }


        /* 하위 노드의 left sibling에서 가장 큰값을 상위 internal node로 올려버리자. */
        memcpy_s ( INDEX_POS( sNewNode, aPos - 1, sKeySize ),
                   INDEX_POS( sChild, sTemp3 - sTemp2, sKeySize ), sKeySize );
        sNewNode->mRID[aPos - 1] = sChild->mRID[sTemp3 - sTemp2];
        /* 참고 : child는 위에서 옮겨 주었다 */

        /* NODE간 이동관련 nodecoutn 정리 */
        mvpAtomicInc32 ( &sNewNode->mIndexSlotHeader.mNodeCount );
        /* sChiild 하위 노드는 아래에서 한꺼번에 한다 */

        /* 하위 노드의 left 에서 올린만큼 초기화를 해주자. */
        /* -1의 의미는 array의 값을 빼주는 의미이다 실제 1 array [0] */
        /* sTemp3 = sChild element count sTemp2 : schid -> sCurr 이동 개수 */
        /* sTemp3-sTemp2의 의미는 이동한 숫자만큼 sTemp3의 pointer의 위치에서 삭제하려는 것이다 */
        sMoveSize = ( sTemp3 - 1 ) - ( sTemp3 - sTemp2 - 1 );

        if ( ( sTemp3 - 1 ) > ( sTemp3 - sTemp2 - 1 ) )
        {
            memset_s ( INDEX_POS( sChild, sTemp3 - sTemp2, sKeySize ), 0x00, sKeySize * sMoveSize );

            //[DONE] #240 mDeleteNodeExist 함수에서 부모의 Child 목록에 자신이 없어서 죽음. ( 2014.03.27 )
            memset_s ( &sChild->mRID[sTemp3 - sTemp2], -1, sizeof(long long) * sMoveSize );
            memset_s ( &sChild->mChild[( ( sTemp3 - sTemp2 ) + 1 )], -1, sizeof(long long) * sMoveSize );  // leaf 구분을 해주어서 초기화를 해야할까???
        }

        /* 삭제한 만큼 노드 count 줄여 준다 */
        sChild->mIndexSlotHeader.mNodeCount = sChild->mIndexSlotHeader.mNodeCount - sTemp2;


        /* 상위 node의 값이 아래로 내려왔고 sCurr적용된 값이 shiht 값과 동일하다면
         * 현재 상위에 있는 값을 아래로 내려 주어야 한다
         * 10 [11 11] --> 10 [10 11] */
        /* sTemp2-1의 위치의 의미는 상위 node가 하위 노드로 내련간 위치를 가르킨다
         * 위에서 sTemp2-1의 위치에 상위 node값을 하위 노르값으로 내렸음 */
        if ( dbmIdxIndexCompare ( sIndexHeader,
                                  INDEX_POS( sCurr, sTemp2 - 1, sKeySize ),
                                  INDEX_POS( sCurr, sTemp2, sKeySize ),
                                  DBM_EQ, 0 )
             && sCurr->mIndexSlotHeader.mLeafcheck == 1 )
        {
            /* leaf 구간의 data를 한칸씩 이동을 하다 */
            memmove_s ( INDEX_POS( sCurr, 1, sKeySize ),
                        INDEX_POS( sCurr, 0, sKeySize ), sKeySize * sTemp2 );
            memmove_s ( &sCurr->mRID[1], &sCurr->mRID[0], sizeof(long long) * sTemp2 );
            memmove_s ( &sCurr->mChild[2], &sCurr->mChild[1], sizeof(long long) * sTemp2 );

            /* 상위 node값을 하위 노드로 내린다 */
            memcpy_s ( INDEX_POS( sCurr, 0, sKeySize ),
                       INDEX_POS( sNewNode, aPos - 1, sKeySize ), sKeySize );
            sCurr->mRID[0] = sNewNode->mRID[aPos - 1];
        }

        /* Btree Check 조정 value 변경 */
        mvpAtomicInc64 ( &sCurr->mBtreeCheck );
        mvpAtomicInc64 ( &sChild->mBtreeCheck );
        mvpAtomicInc64 ( &sNewNode->mBtreeCheck );

    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    {
        /* leaf unlock 처리 */
        mvpAtomicCas32_s( &sChild->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
    }
    _END
} /* dbmIdxDeleteLeftSiblingNu */


/********************************************************************
 * ID : mDeleteRightSibling
 *
 * Description
 *   우측 sibling, parent 와 합쳐 B-Tree 조정을 하도록 한다.
 *
 * Argument
 *    aNewNode     : input : 부모노드의 key가 저장되어 있는 pointer
 *    aCurr        : input : 자식 노드의 key가 저장되어 있는 pointer
 *    aPos         : input : 부모 노드에서 key가 가리키도 있는 자식 노드의 position
 *    aTransID     : input : Transaction ID
 *    aIndexHeader : input : dbm Index Header
 *    aSegMgr      : input : Index Segment Pointer
 *    aLockMgr     : input : Index Lock Handle
 *
********************************************************************/
_VOID dbmIdxDeleteRightSibling ( dbmIndexNode** aNewNode ,
                                 dbmIndexNode** aCurr ,
                                 int aPos ,
                                 int aTransID ,
                                 dbmIndexHeader* aIndexHeader ,
                                 dbmSegmentManager* aSegMgr ,
                                 dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sNewNode;
    dbmIndexNode*       sCurr;
    dbmIndexNode*       sChild;
    dbmIndexNode*       sChangeNode;

    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;


    int     sKeySize;
    int     sTemp2;         /* 임시 element count */
    int     sTemp3;         /* 임시 element count */
    int     sTempSize;      /* 임시 size */
    int     sCount;         /* node Count*/
    int     sNodeMoveCheck; /* node move check    */
    int     i;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        /* 초기화 처리 */
        sNewNode = NULL;
        sCurr = NULL;
        sChild = NULL;
        sChangeNode = NULL;
        sNodeMoveCheck = 0;

        sNewNode = *aNewNode;
        sCurr = *aCurr;
        sKeySize = sIndexHeader->mIndex.mKeySize;

        /* child right sibling */
        /* 하위 노드의 우측 노드 */
        _CALL( sSegMgr->Slot2Addr ( sNewNode->mChild[aPos + 1], &sChild ) );

        /* 2014.02.18 -shw- delete key 처리 시  logging  필요없어 일단 막음 */
        /* sChild에 대한 Index Logging 처리를 한다 */
        //sRC = mIndexLogging(&sChild->mCurrSlot,aTransID);
        //_IF_RAISE(sRC, DBM_INDEX_LOGGING_FAIL);

        /* 하위 노드의  우측 노드의 element 개수 */
        sTemp3 = sChild->mIndexSlotHeader.mNodeCount;

        /* 균형을 맞추기 위해 right sibling nTemp개수만큼 분배 처리를 한다 */
        /* 쉽게 생각을 해라... 걍.. right sibling에서 이동하려는 개수라 생각... */
        /* sCurr 노드  와  sChild 비교해서 sChild가 남는 만큼 분배해서 균형을 맞춘다 */
        /* 참고 : [1 2 3 4] 5 [5 6 7 9 10 11 12 13]
         *        sTemp3 = 9
         *        sTemp2 = (9-3)/2 = 3
         *        sTemp2 = 3-1 = 2
         *        2만큼 sChild -> sCurr로 이동 (3인 이유는 위에서 key값 하나를 삭제했기 때문)
         */
        sTemp2 = ( sTemp3 - sCurr->mIndexSlotHeader.mNodeCount ) >> 1;


        /* position 구하기 위하여 search 하는데 다른 node와 lock 경합이 필요하다 */
        _CALL( mSpinLockLib ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sNewNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sChild->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

        /* 상위 internal node 노드값을 하위 node에 삽입하자 */
        memcpy_s ( INDEX_POS( sCurr, sCurr->mIndexSlotHeader.mNodeCount, sKeySize ),
                   INDEX_POS( sNewNode, aPos, sKeySize ), sKeySize );
        sCurr->mRID[sCurr->mIndexSlotHeader.mNodeCount] = sNewNode->mRID[aPos];

        /* 상위 노드는 없어지고 현재의 노드는 증가 하므로 해당 node Count 변경하자 */
        mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );
        sNewNode->mIndexSlotHeader.mNodeCount = sNewNode->mIndexSlotHeader.mNodeCount - 1;

        /* 상위 NODE로 올라가는 값을 leaf에도 하나 더 만들어 주어야 한다 */

        sCount = sCurr->mIndexSlotHeader.mNodeCount;

        /* right sibling에서 nTemp2-1만큼 pCurr로 이동처리 한다. */
        for ( i = 0; i < sTemp2 - 1; ++i )
        {
            /* sCurr의 node에서 내려온 값과 right sibling node의 첫번째 값이 같으면 해당 값의 node
             * 값이 상위 node에서 내려왔기 때문에 새로이 copy해주지 right sibling에서 하나더 가져
             * 오도록 한다 */
            if ( dbmIdxIndexCompare ( sIndexHeader,
                                      INDEX_POS( sCurr, sCount - 1, sKeySize ),
                                      INDEX_POS( sChild, 0, sKeySize ),
                                      DBM_EQ, 0 )
                 && i == 0 && sCurr->mIndexSlotHeader.mLeafcheck == 1 )
            {
                /* leaf만이 값이 양쪽으로 올수 있다 */
                sNodeMoveCheck = 1;
                sTemp2++;
            }
            else
            {
                if ( sNodeMoveCheck == 1 )
                {
                    /* 상위 root가 내려 왔기 때문에 다음부터 가져오라는 의미이다. */
                    /* -1의 의미는 현재 노드의 위의 로직에서 i++이 되었기 때문에 -1를 해주어야 한다 */
                    memcpy_s ( INDEX_POS( sCurr, sCount + i - 1, sKeySize ),
                               INDEX_POS( sChild, i, sKeySize ), sKeySize );
                    sCurr->mRID[sCount + i - 1] = sChild->mRID[i];
                    sCurr->mChild[sCount + i - 1] = sChild->mChild[i];

                    /* sCurr 이동관련 Node 정리해 준다 */
                    mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );

                    if ( sChild->mChild[i] >= 0 && sChild->mIndexSlotHeader.mLeafcheck != 1 )
                    {
                        /* sChild의 child가 sCurr로 이동이 되므로 sChild의 Child 노드들의 root id를 바꾸어 주어야 한다 */
                        _CALL( sSegMgr->Slot2Addr ( sChild->mChild[i], &sChangeNode ) );

                        _CALL( mSpinLockLib ( &sChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                        sChangeNode->mIndexSlotHeader.mRootSlotID = sCurr->mCurrSlot;

                        mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );

                    }

                }
                else
                {
                    /* +1의 의미는 상위 root가 내려 왔기 때문에 다음부터 가져오라는 의미이다. */
                    memcpy_s ( INDEX_POS( sCurr, sCount + i, sKeySize ),
                               INDEX_POS( sChild, i, sKeySize ), sKeySize );
                    sCurr->mRID[sCount + i] = sChild->mRID[i];
                    sCurr->mChild[sCount + i] = sChild->mChild[i];

                    /* sCurr 이동관련 Node 정리해 준다 */
                    mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );

                    if ( sChild->mChild[i] >= 0 && sChild->mIndexSlotHeader.mLeafcheck != 1 )
                    {
                        /* sChild의 child가 sCurr로 이동이 되므로 sChild의 Child 노드들의 root id를 바꾸어 주어야 한다 */
                        _CALL( sSegMgr->Slot2Addr ( sChild->mChild[i], &sChangeNode ) );

                        _CALL( mSpinLockLib ( &sChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                        sChangeNode->mIndexSlotHeader.mRootSlotID = sCurr->mCurrSlot;

                        mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
                    }
                }
            }
        }

        /* leaf node간의 계산을 하기 위하여 sNodeMoveCheck 1일 때에는 sTemp21을 증가 하였기 때문에
         * 정상 적으로 체크 후에는 -1 하여 원복 처리 해준다 */
        if ( sNodeMoveCheck == 1 )
            sTemp2--;

        // 맨마지막에 sChild 넘겨준다.
        sCurr->mChild[sCount + sTemp2 - 1] = sChild->mChild[sTemp2 - 1];

        /* sChild의 child가 sCurr로 이동이 되므로 sChild의 Child 노드들의 root id를 바꾸어 주어야 한다 */
        if ( sChild->mChild[sTemp2 - 1] >= 0 && sChild->mIndexSlotHeader.mLeafcheck != 1 )
        {
            _CALL( sSegMgr->Slot2Addr ( sChild->mChild[sTemp2 - 1], &sChangeNode ) );

            _CALL( mSpinLockLib ( &sChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

            sChangeNode->mIndexSlotHeader.mRootSlotID = sCurr->mCurrSlot;

            mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
        }


         /******************************************************************************************
         * sTemp2 > 1 보다 크다는 것은 결국 sChild에서 sCurr로 이동이 있어다는 것을 얘기 한다.
         * 이동이 있다는 것은 sTemp2만큼 이동을 하게 되는 것인데 이동이 되었을 경우 이동한 sTemp2
         * 수의 값이  sChild에서 제일 큰값이이면 이동을 하지 않았을 경우에는 sTemp2의 값의 이동이
         * 없기 때문에 기본값이 sTemp2=1 에서 0번째의 값을 구하기 위하여 -1을 하여 구해준다
         *******************************************************************************************/
        if ( sChild->mIndexSlotHeader.mLeafcheck != 1 )
        {
            /* 하위 노드의 right sibling에서 가장 큰값을 상위 internal node로 올려버리자. */
            /* right sibling에서 부모로 key 올려주고 left shift */
            memcpy_s ( INDEX_POS( sNewNode, aPos, sKeySize ),
                       INDEX_POS( sChild, sTemp2 - 1, sKeySize ), sKeySize );
            sNewNode->mRID[aPos] = sChild->mRID[sTemp2 - 1];
        }
        else
        {
            /* 하위 노드의 right sibling에서 가장 큰값을 상위 internal node로 올려버리자. */
            /* right sibling에서 부모로 key 올려주고 left shift */
            memcpy_s ( INDEX_POS( sNewNode, aPos, sKeySize ),
                       INDEX_POS( sChild, sTemp2, sKeySize ), sKeySize );
            sNewNode->mRID[aPos] = sChild->mRID[sTemp2];
        }

        /* NODE간 이동관련 nodecoutn 정리 */
        mvpAtomicInc32 ( &sNewNode->mIndexSlotHeader.mNodeCount );


        /* left sibling에서 이동 한만큼 옮겨 주어라 */
        /* 0의 pointer에 nTemp2부터 (DBM_INDEX_DEGREE-1)-sTemp2 한사이즈만큼 옮겨라 */
        if ( ( ( DBM_INDEX_DEGREE - 1 ) - sTemp2 ) > 0 )
        {
            memmove_s ( INDEX_POS( sChild, 0, sKeySize ),
                        INDEX_POS( sChild, sTemp2, sKeySize ),
                        sKeySize * ( ( DBM_INDEX_DEGREE - 1 ) - sTemp2 ) );
            memmove_s ( &sChild->mRID[0],
                        &sChild->mRID[sTemp2], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 1 ) - sTemp2 ) );
            memmove_s ( &sChild->mChild[0],
                        &sChild->mChild[sTemp2], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 1 ) - sTemp2 ) );
        }

        /* 맨 마지막에 있는 거을 올려 주어야 한다 */
        sChild->mChild[DBM_INDEX_DEGREE - 1 - sTemp2] = sChild->mChild[DBM_INDEX_DEGREE - 1];

        /* sChild NODE간 이동관련 nodecoutn 정리 */
        sChild->mIndexSlotHeader.mNodeCount = sChild->mIndexSlotHeader.mNodeCount - sTemp2;


        /* 기준 : sTemp3 - (sTemp3 - (sTemp3-sTemp2))
         * size : (sTemp3 - (sTemp3-sTemp2))
         *
         */
        sTempSize = sTemp3 - ( sTemp3 - sTemp2 );

        if ( sTemp3 > ( sTemp3 - sTemp2 ) )
        {
            memset_s ( INDEX_POS( sChild, sTemp3 - sTempSize, sKeySize ), 0x00, sTempSize * sKeySize );
            //[DONE] #240 RID와 Child 초기화는 -1
            memset_s ( &sChild->mRID[sTemp3 - sTempSize], -1, sizeof(long long) * sTempSize );
            memset_s ( &sChild->mChild[sTemp3 - sTempSize + 1], -1, sizeof(long long) * sTempSize );
        }

        /* Btree Check 조정 value 변경 */
        mvpAtomicInc64 ( &sCurr->mBtreeCheck );
        mvpAtomicInc64 ( &sChild->mBtreeCheck );
        mvpAtomicInc64 ( &sNewNode->mBtreeCheck );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    {
        /* leaf unlock 처리 */
        mvpAtomicCas32_s( &sChild->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
    }
    _END
} /* dbmIdxDeleteRightSibling */


/********************************************************************
 * ID : mDeleteNuRightSibling
 *
 * Description(non-unique index type)
 *   우측 sibling, parent 와 합쳐 B-Tree 조정을 하도록 한다.
 *
 * Argument
 *    aNewNode     : input : 부모노드의 key가 저장되어 있는 pointer
 *    aCurr        : input : 자식 노드의 key가 저장되어 있는 pointer
 *    aPos         : input : 부모 노드에서 key가 가리키도 있는 자식 노드의 position
 *    aTransID     : input : Transaction ID
 *    aIndexHeader : input : dbm Index Header
 *    aSegMgr      : input : Index Segment Pointer
 *    aLockMgr     : input : Index Lock Handle
 *
********************************************************************/
_VOID dbmIdxDeleteRightSiblingNu ( dbmIndexNode** aNewNode ,
                                   dbmIndexNode** aCurr ,
                                   int aPos ,
                                   int aTransID ,
                                   dbmIndexHeader* aIndexHeader ,
                                   dbmSegmentManager* aSegMgr ,
                                   dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sNewNode;
    dbmIndexNode*       sCurr;
    dbmIndexNode*       sChild;
    dbmIndexNode*       sChangeNode;

    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;

    int     sKeySize;
    int     sTemp2;         /* 임시 element count */
    int     sTemp3;         /* 임시 element count */
    int     sTempSize;      /* 임시 size */
    int     sCount;         /* node Count*/
    int     sNodeMoveCheck; /* node move check    */
    int     i;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        /* 초기화 처리 */
        sNewNode = NULL;
        sCurr = NULL;
        sChild = NULL;
        sChangeNode = NULL;
        sNodeMoveCheck = 0;

        sNewNode = *aNewNode;
        sCurr = *aCurr;

        sKeySize = INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );

        /* child right sibling */
        /* 하위 노드의 우측 노드 */
        _CALL( sSegMgr->Slot2Addr ( sNewNode->mChild[aPos + 1], &sChild ) );

        /* 2014.02.18 -shw- delete key 처리 시  logging  필요없어 일단 막음 */
        /* sChild에 대한 Index Logging 처리를 한다 */
        //sRC = mIndexLogging(&sChild->mCurrSlot,aTransID);
        //_IF_RAISE(sRC, DBM_INDEX_LOGGING_FAIL);

        /* 하위 노드의  우측 노드의 element 개수 */
        sTemp3 = sChild->mIndexSlotHeader.mNodeCount;

        /* 균형을 맞추기 위해 right sibling nTemp개수만큼 분배 처리를 한다 */
        /* 쉽게 생각을 해라... 걍.. right sibling에서 이동하려는 개수라 생각... */
        /* sCurr 노드  와  sChild 비교해서 sChild가 남는 만큼 분배해서 균형을 맞춘다 */
        /* 참고 : [1 2 3 4] 5 [5 6 7 9 10 11 12 13]
         *        sTemp3 = 9
         *        sTemp2 = (9-3)/2 = 3
         *        sTemp2 = 3-1 = 2
         *        2만큼 sChild -> sCurr로 이동 (3인 이유는 위에서 key값 하나를 삭제했기 때문)
         */
        //  sTemp2 = ( sTemp3 - sCurr->mIndexSlotHeader.mNodeCount ) / 2;
        sTemp2 = ( sTemp3 - sCurr->mIndexSlotHeader.mNodeCount ) >> 1;

        /* position 구하기 위하여 search 하는데 다른 node와 lock 경합이 필요하다 */
        _CALL( mSpinLockLib ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sNewNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sChild->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

        /* 상위 internal node 노드값을 하위 node에 삽입하자 */
        memcpy_s ( INDEX_POS( sCurr, sCurr->mIndexSlotHeader.mNodeCount, sKeySize ),
                   INDEX_POS( sNewNode, aPos, sKeySize ), sKeySize );
        sCurr->mRID[sCurr->mIndexSlotHeader.mNodeCount] = sNewNode->mRID[aPos];

        /* 상위 노드는 없어지고 현재의 노드는 증가 하므로 해당 node Count 변경하자 */
        mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );
        sNewNode->mIndexSlotHeader.mNodeCount = sNewNode->mIndexSlotHeader.mNodeCount - 1;

        /* 상위 NODE로 올라가는 값을 leaf에도 하나 더 만들어 주어야 한다 */

        sCount = sCurr->mIndexSlotHeader.mNodeCount;

        /* right sibling에서 nTemp2-1만큼 pCurr로 이동처리 한다. */
        for ( i = 0; i < sTemp2 - 1; ++i )
        {
            /* sCurr의 node에서 내려온 값과 right sibling node의 첫번째 값이 같으면 해당 값의 node
             * 값이 상위 node에서 내려왔기 때문에 새로이 copy해주지 right sibling에서 하나더 가져
             * 오도록 한다 */
            if ( dbmIdxIndexCompare ( sIndexHeader,
                                      INDEX_POS( sCurr, sCount - 1, sKeySize ),
                                      INDEX_POS( sChild, 0, sKeySize ),
                                      DBM_EQ, 0 )
                 && i == 0 && sCurr->mIndexSlotHeader.mLeafcheck == 1 )
            {
                /* leaf만이 값이 양쪽으로 올수 있다 */
                sNodeMoveCheck = 1;
                sTemp2++;
            }
            else
            {
                if ( sNodeMoveCheck == 1 )
                {
                    /* 상위 root가 내려 왔기 때문에 다음부터 가져오라는 의미이다. */
                    /* -1의 의미는 현재 노드의 위의 로직에서 i++이 되었기 때문에 -1를 해주어야 한다 */
                    memcpy_s ( INDEX_POS( sCurr, sCount + i - 1, sKeySize ),
                               INDEX_POS( sChild, i, sKeySize ), sKeySize );
                    sCurr->mRID[sCount + i - 1] = sChild->mRID[i];
                    sCurr->mChild[sCount + i - 1] = sChild->mChild[i];

                    /* sCurr 이동관련 Node 정리해 준다 */
                    mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );

                    if ( sChild->mChild[i] >= 0 && sChild->mIndexSlotHeader.mLeafcheck != 1 )
                    {
                        /* sChild의 child가 sCurr로 이동이 되므로 sChild의 Child 노드들의 root id를 바꾸어 주어야 한다 */
                        _CALL( sSegMgr->Slot2Addr ( sChild->mChild[i], &sChangeNode ) );

                        _CALL( mSpinLockLib ( &sChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                        sChangeNode->mIndexSlotHeader.mRootSlotID = sCurr->mCurrSlot;

                        mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
                    }

                }
                else
                {
                    /* +1의 의미는 상위 root가 내려 왔기 때문에 다음부터 가져오라는 의미이다. */
                    memcpy_s ( INDEX_POS( sCurr, sCount + i, sKeySize ),
                               INDEX_POS( sChild, i, sKeySize ), sKeySize );
                    sCurr->mRID[sCount + i] = sChild->mRID[i];
                    sCurr->mChild[sCount + i] = sChild->mChild[i];

                    /* sCurr 이동관련 Node 정리해 준다 */
                    mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );

                    if ( sChild->mChild[i] >= 0 && sChild->mIndexSlotHeader.mLeafcheck != 1 )
                    {
                        /* sChild의 child가 sCurr로 이동이 되므로 sChild의 Child 노드들의 root id를 바꾸어 주어야 한다 */
                        _CALL( sSegMgr->Slot2Addr ( sChild->mChild[i], &sChangeNode ) );

                        _CALL( mSpinLockLib ( &sChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                        sChangeNode->mIndexSlotHeader.mRootSlotID = sCurr->mCurrSlot;

                        mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
                    }
                }
            }
        }

        /* leaf node간의 계산을 하기 위하여 sNodeMoveCheck 1일 때에는 sTemp21을 증가 하였기 때문에
         * 정상 적으로 체크 후에는 -1 하여 원복 처리 해준다 */
        if ( sNodeMoveCheck == 1 )
        {
            sTemp2--;
        }

        // 맨마지막에 sChild 넘겨준다.
        sCurr->mChild[sCount + sTemp2 - 1] = sChild->mChild[sTemp2 - 1];

        /* sChild의 child가 sCurr로 이동이 되므로 sChild의 Child 노드들의 root id를 바꾸어 주어야 한다 */
        if ( sChild->mChild[sTemp2 - 1] >= 0 && sChild->mIndexSlotHeader.mLeafcheck != 1 )
        {
            _CALL( sSegMgr->Slot2Addr ( sChild->mChild[sTemp2 - 1], &sChangeNode ) );

            _CALL( mSpinLockLib ( &sChangeNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

            sChangeNode->mIndexSlotHeader.mRootSlotID = sCurr->mCurrSlot;

            mvpAtomicCas32_s( &sChangeNode->mIndexSlotHeader.mLock, -1, aTransID );
        }


        /******************************************************************************************
         * sTemp2 > 1 보다 크다는 것은 결국 sChild에서 sCurr로 이동이 있어다는 것을 얘기 한다.
         * 이동이 있다는 것은 sTemp2만큼 이동을 하게 되는 것인데 이동이 되었을 경우 이동한 sTemp2
         * 수의 값이  sChild에서 제일 큰값이이면 이동을 하지 않았을 경우에는 sTemp2의 값의 이동이
         * 없기 때문에 기본값이 sTemp2=1 에서 0번째의 값을 구하기 위하여 -1을 하여 구해준다
         *******************************************************************************************/
        if ( sChild->mIndexSlotHeader.mLeafcheck != 1 )
        {
            /* 하위 노드의 right sibling에서 가장 큰값을 상위 internal node로 올려버리자. */
            /* right sibling에서 부모로 key 올려주고 left shift */
            memcpy_s ( INDEX_POS( sNewNode, aPos, sKeySize ),
                       INDEX_POS( sChild, sTemp2 - 1, sKeySize ), sKeySize );
            sNewNode->mRID[aPos] = sChild->mRID[sTemp2 - 1];
        }
        else
        {
            /* 하위 노드의 right sibling에서 가장 큰값을 상위 internal node로 올려버리자. */
            /* right sibling에서 부모로 key 올려주고 left shift */
            memcpy_s ( INDEX_POS( sNewNode, aPos, sKeySize ),
                       INDEX_POS( sChild, sTemp2, sKeySize ), sKeySize );
            sNewNode->mRID[aPos] = sChild->mRID[sTemp2];
        }

        /* NODE간 이동관련 nodecoutn 정리 */
        mvpAtomicInc32 ( &sNewNode->mIndexSlotHeader.mNodeCount);


        /* left sibling에서 이동 한만큼 옮겨 주어라 */
        /* 0의 pointer에 nTemp2부터 (DBM_INDEX_DEGREE-1)-sTemp2 한사이즈만큼 옮겨라 */
        if ( ( ( DBM_INDEX_DEGREE - 1 ) - sTemp2 ) > 0 )
        {
            memmove_s ( INDEX_POS( sChild, 0, sKeySize ),
                        INDEX_POS( sChild, sTemp2, sKeySize ), sKeySize * ( ( DBM_INDEX_DEGREE - 1 ) - sTemp2 ) );
            memmove_s ( &sChild->mRID[0], &sChild->mRID[sTemp2], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 1 ) - sTemp2 ) );
            memmove_s ( &sChild->mChild[0], &sChild->mChild[sTemp2], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 1 ) - sTemp2 ) );
        }

        /* 맨 마지막에 있는 거을 올려 주어야 한다 */
        sChild->mChild[DBM_INDEX_DEGREE - 1 - sTemp2] = sChild->mChild[DBM_INDEX_DEGREE - 1];

        /* sChild NODE간 이동관련 nodecoutn 정리 */
        sChild->mIndexSlotHeader.mNodeCount = sChild->mIndexSlotHeader.mNodeCount - sTemp2;

        /* 기준 : sTemp3 - (sTemp3 - (sTemp3-sTemp2))
         * size : (sTemp3 - (sTemp3-sTemp2))
         *
         */
        sTempSize = sTemp3 - ( sTemp3 - sTemp2 );

        if ( sTemp3 > ( sTemp3 - sTemp2 ) )
        {
            memset_s ( INDEX_POS( sChild, sTemp3 - sTempSize, sKeySize ), 0x00, sTempSize * sKeySize );
            //[DONE] #240 RID와 Child 초기화는 -1
            memset_s ( &sChild->mRID[sTemp3 - sTempSize], -1, sizeof(long long) * sTempSize );
            memset_s ( &sChild->mChild[sTemp3 - sTempSize + 1], -1, sizeof(long long) * sTempSize );
        }

        /* Btree Check 조정 value 변경 */
        mvpAtomicInc64 ( &sCurr->mBtreeCheck );
        mvpAtomicInc64 ( &sChild->mBtreeCheck );
        mvpAtomicInc64 ( &sNewNode->mBtreeCheck );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    {
        /* leaf unlock 처리 */
        mvpAtomicCas32_s( &sChild->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
    }
    _END
} /* dbmIdxDeleteRightSiblingNu */


/********************************************************************
 * ID : mDeleteNonleftSibling
 *
 * Description
 *   좌측 sibling, parent 와 합쳐 B-Tree 조정을 하도록 한다.
 *   위의 모듈은 internal node 와 비교 하였을 경우 left,right sibling 할게
 *   없을 경우 타게 되는 모듈이다. 위의 모듈을 탄다는 것으 parent 합쳐서
 *   left sibling이 된다는 것을 의미한다.
 *
 * Argument
 *     aNewNode     : input : 부모노드의 key가 저장되어 있는 pointer
 *     aCurr        : input : 자식 노드의 key가 저장되어 있는 pointer
 *     aPos         : input : 부모 노드에서 key가 가리키도 있는 자식 노드의 position
 *     aTransID     : input : Transaction ID
 *     aIndexHeader : input : dbm Index Header
 *     aSegMgr      : input : Index Segment Pointer
 *     aLockMgr     : input : Index Lock Handle
 *
********************************************************************/
_VOID dbmIdxDeleteNonLeftSibling ( dbmIndexNode** aNewNode ,
                                   dbmIndexNode** aCurr ,
                                   int aPos ,
                                   int aTransID ,
                                   dbmIndexHeader* aIndexHeader ,
                                   dbmSegmentManager* aSegMgr ,
                                   dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sNewNode = NULL;
    dbmIndexNode*       sCurr = NULL;
    dbmIndexNode*       sChild = NULL;
    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;

    int     sKeySize;
    int     sTemp2;         /* 임시 element count */
    int     sTemp3;         /* 임시 element count */
    int     i;

    _TRY
    {
        /* 초기화 처리 */
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;
        sNewNode = *aNewNode;
        sCurr = *aCurr;
        sKeySize = sIndexHeader->mIndex.mKeySize;

        /* child left sibling */
        /* 하위 노드의 좌측 노드 */
        _CALL( sSegMgr->Slot2Addr ( sNewNode->mChild[aPos - 1], &sChild ) );

        /* 2014.02.18 -shw- delete key 처리 시  logging  필요없어 일단 막음 */
        /* sChild에 대한 Index Logging 처리를 한다 */
        //sRC = mIndexLogging(&sChild->mCurrSlot,aTransID);
        //_IF_RAISE(sRC, DBM_INDEX_LOGGING_FAIL);

        /* 하위 노드의  좌측 노드의 element 개수 */
        sTemp3 = sChild->mIndexSlotHeader.mNodeCount;

        /*********************************************************************
         * 여기에서는 기준이 left sibling이 된다. sTmpe2의 개수를 left sibling
         * 에 현재의 node에서 이동하려는 개수이다. 앞으로 sTmpe2의 slot은 없어
         * 지게 되므로 위와 관련 된 값을 조정을 해야 한다.
         * sCurr 현재 노드의 element 개수
         **********************************************************************/
        sTemp2 = sCurr->mIndexSlotHeader.mNodeCount;

        /* position 구하기 위하여 search 하는데 다른 node와 lock 경합이 필요하다 */
        _CALL( mSpinLockLib ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sNewNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sChild->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

        /* parent 처리를 한다 */
        /* 하위 노드의 left 마지막에 상위 internal node의 값을 입력하자. */
        /* curr 현재 노드의 child left에 옮겨주어야 한다. */
        memcpy_s ( INDEX_POS( sChild, sTemp3, sKeySize ),
                   INDEX_POS( sNewNode, aPos - 1, sKeySize ), sKeySize );
        sChild->mRID[sTemp3] = sNewNode->mRID[aPos - 1];
        /* 아래에서 right sibling에서 다시 가져올거기 때문에 첫번째 child 옮겨 놓는다 */
        sChild->mChild[sTemp3 + 1] = sCurr->mChild[0];

        /* node의 element 요소가 변경 되기 때문에 변경을 해준다 */
        mvpAtomicInc32 ( &sChild->mIndexSlotHeader.mNodeCount );
        sNewNode->mIndexSlotHeader.mNodeCount = sNewNode->mIndexSlotHeader.mNodeCount - 1;

        /* sCurr key와 child를  left sibling에 merge 하자... */
        /* +1의 의미는 위에서 상위 노드 하나를 sChild로 하나 내리는데 이에 대한값을 -1 해주는것이다 */
        if ( dbmIdxIndexCompare ( sIndexHeader,
                                  INDEX_POS( sChild, sTemp3, sKeySize ),
                                  INDEX_POS( sCurr, 0, sKeySize ),
                                  DBM_EQ, 0 ) != 0
             && sChild->mIndexSlotHeader.mLeafcheck == 1 )
        {

            /* leaf process */
            for ( i = 0; i < sTemp2 - 1; ++i )
            {
                /* sChild +1의 의미는 : 위에서 상위 노드 더한값을 더해준다는 위미
                 * sCurr  +1의 의미는 : leaf의 값이 벌써 상위 노드가 내려감으로써 반영 되었기 때문에 더해
                 *                      준다는 의미 */
                memcpy_s ( INDEX_POS( sChild, i + sTemp3 + 1, sKeySize ),
                           INDEX_POS( sCurr, i + 1, sKeySize ), sKeySize );
                sChild->mRID[i + sTemp3 + 1] = sCurr->mRID[i + 1];
                sChild->mChild[i + sTemp3 + 2] = sCurr->mChild[i + 2];
            }

            sTemp2 = sTemp2 - 1;
        }
        else
        {
            /* internal process */
            for ( i = 0; i < sTemp2; ++i )
            {
                memcpy_s ( INDEX_POS( sChild, i + sTemp3 + 1, sKeySize ),
                           INDEX_POS( sCurr, i, sKeySize ), sKeySize );
                sChild->mRID[i + sTemp3 + 1] = sCurr->mRID[i];
                sChild->mChild[i + sTemp3 + 2] = sCurr->mChild[i + 1];
            }
        }


        /* sCurr, sChild node의 element 요소가 변경 되기 때문에 변경을 해준다 */
        sChild->mIndexSlotHeader.mNodeCount = sChild->mIndexSlotHeader.mNodeCount + sTemp2;

        /*
        상위 internal ndoe에서 key , child 삭제하도록 하자....
        (상위 internal 노드가 하나 내려갔기 때문에 하나씩 옆으로 치환해주도록 한다 )
        */

        /* size : (DEGREE-1) - (sPos-1)
         * 어디에다 : sPos-1
         * 어디부터 : (sPos-1)+1 (sPos)
         * 어디만큼 : size
         */

        if ( sNewNode->mIndexSlotHeader.mNodeCount > 0 ) // && sNewNode->mIndexSlotHeader.mNodeCount >= aPos )
        {
            if ( sNewNode->mIndexSlotHeader.mNodeCount >= aPos )
            {
                memmove_s ( INDEX_POS( sNewNode, aPos - 1, sKeySize ),
                            INDEX_POS( sNewNode, aPos, sKeySize ),
                            sKeySize * ( ( DBM_INDEX_DEGREE - 1 ) - ( aPos - 1 ) ) );
                memmove_s ( &sNewNode->mRID[aPos - 1],
                            &sNewNode->mRID[aPos], sizeof(long long*) * ( ( DBM_INDEX_DEGREE - 1 ) - ( aPos - 1 ) ) );
                memmove_s ( &sNewNode->mChild[aPos],
                            &sNewNode->mChild[aPos + 1], sizeof(long long*) * ( ( DBM_INDEX_DEGREE - 1 ) - ( aPos - 1 ) ) );

                memset_s ( INDEX_POS( sNewNode, DBM_INDEX_DEGREE - 2, sKeySize ), 0x00, sKeySize );

                sNewNode->mRID[DBM_INDEX_DEGREE - 2] = -1;
                sNewNode->mChild[DBM_INDEX_DEGREE - 1] = -1;
            }
            else
            {
                memset_s ( INDEX_POS( sNewNode, aPos - 1, sKeySize ), 0x00, sKeySize );
                sNewNode->mRID[aPos - 1] = -1;
                sNewNode->mChild[aPos] = -1;

                memset_s ( INDEX_POS( sNewNode, DBM_INDEX_DEGREE - 2, sKeySize ), 0x00, sKeySize );
                sNewNode->mRID[DBM_INDEX_DEGREE - 2] = -1;
                sNewNode->mChild[DBM_INDEX_DEGREE - 1] = -1;
            }
        }

        /**********************************************
         * leaf간의 관계를 조정 한다
         **********************************************/
        _rc = dbmIdxDeleteNonLeftAdjust ( &sNewNode, &sCurr, &sChild, aTransID, sIndexHeader, sSegMgr, aLockMgr );
        if ( unlikely( _rc != 0 ) ) //, DBM_INDEX_ADJUST_FAIL );
        {
            DBM_ERR( "dbm mDeleteNonLeftAdjust errror [%d]", _rc );
            _THROW( ERR_DBM_FREE_SLOT_FATAL_IN_INDEX );
        }

        if ( sNewNode->mIndexSlotHeader.mNodeCount == 0 )
        {
            /* sChild 초기화 */
            dbmIdxDeleteKeyClear ( &sNewNode, sIndexHeader );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    {
        /* leaf unlock 처리 */
        mvpAtomicCas32_s( &sChild->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
        /* 2014.02.06 -shw- free slot한 후 lock 풀어줄필요가 없다... 주석으로 막음 */
        //mvpAtomicCas32_s(&sCurr->mIndexSlotHeader.mLock,-1,aTransID); //TODO: 2014.09.26 -okt- 오류시에는 이걸 해제하는데 버그일듯.
    }
    _END
} /* dbmIdxDeleteNonLeftSibling */


/********************************************************************
 * ID : mDeleteNuNonleftSibling
 *
 * Description(non-unique index type)
 *   좌측 sibling, parent 와 합쳐 B-Tree 조정을 하도록 한다.
 *   위의 모듈은 internal node 와 비교 하였을 경우 left,right sibling 할게
 *   없을 경우 타게 되는 모듈이다. 위의 모듈을 탄다는 것으 parent 합쳐서
 *   left sibling이 된다는 것을 의미한다.
 *
 * Argument
 *     aNewNode     : input : 부모노드의 key가 저장되어 있는 pointer
 *     aCurr        : input : 자식 노드의 key가 저장되어 있는 pointer
 *     aPos         : input : 부모 노드에서 key가 가리키도 있는 자식 노드의 position
 *     aTransID     : input : Transaction ID
 *     aIndexHeader : input : dbm Index Header
 *     aSegMgr      : input : Index Segment Pointer
 *     aLockMgr     : input : Index Lock Handle
 *
********************************************************************/
_VOID dbmIdxDeleteNonLeftSiblingNu ( dbmIndexNode** aNewNode ,
                                     dbmIndexNode** aCurr ,
                                     int aPos ,
                                     int aTransID ,
                                     dbmIndexHeader* aIndexHeader ,
                                     dbmSegmentManager* aSegMgr ,
                                     dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sNewNode;
    dbmIndexNode*       sCurr;
    dbmIndexNode*       sChild;
    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;
    int     sKeySize;
    int     sTemp2;         /* 임시 element count */
    int     sTemp3;         /* 임시 element count */
    int     sRC;
    int     i;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        /* 초기화 처리 */
//        sNewNode = NULL;
//        sCurr = NULL;
        sChild = NULL;

        sNewNode = *aNewNode;
        sCurr = *aCurr;

        sKeySize = INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );

        /* child left sibling */
        /* 하위 노드의 좌측 노드 */
        _CALL( sSegMgr->Slot2Addr ( sNewNode->mChild[aPos - 1], &sChild ) );

        /* 2014.02.18 -shw- delete key 처리 시  logging  필요없어 일단 막음 */
        /* sChild에 대한 Index Logging 처리를 한다 */
        //sRC = mIndexLogging(&sChild->mCurrSlot,aTransID);
        //_IF_RAISE(sRC, DBM_INDEX_LOGGING_FAIL);

        /* 하위 노드의  좌측 노드의 element 개수 */
        sTemp3 = sChild->mIndexSlotHeader.mNodeCount;

        /*********************************************************************
         * 여기에서는 기준이 left sibling이 된다. sTmpe2의 개수를 left sibling
         * 에 현재의 node에서 이동하려는 개수이다. 앞으로 sTmpe2의 slot은 없어
         * 지게 되므로 위와 관련 된 값을 조정을 해야 한다.
         * sCurr 현재 노드의 element 개수
         **********************************************************************/
        sTemp2 = sCurr->mIndexSlotHeader.mNodeCount;


        /* position 구하기 위하여 search 하는데 다른 node와 lock 경합이 필요하다 */
        _CALL( mSpinLockLib ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sNewNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sChild->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

        /* parent 처리를 한다 */
        /* 하위 노드의 left 마지막에 상위 internal node의 값을 입력하자. */
        /* curr 현재 노드의 child left에 옮겨주어야 한다. */
        memcpy_s ( INDEX_POS( sChild, sTemp3, sKeySize ),
                   INDEX_POS( sNewNode, aPos - 1, sKeySize ), sKeySize );
        sChild->mRID[sTemp3] = sNewNode->mRID[aPos - 1];
        /* 아래에서 right sibling에서 다시 가져올거기 때문에 첫번째 child 옮겨 놓는다 */
        sChild->mChild[sTemp3 + 1] = sCurr->mChild[0];

        /* node의 element 요소가 변경 되기 때문에 변경을 해준다 */
        mvpAtomicInc32 ( &sChild->mIndexSlotHeader.mNodeCount );
        sNewNode->mIndexSlotHeader.mNodeCount = sNewNode->mIndexSlotHeader.mNodeCount - 1;


        /* sCurr key와 child를  left sibling에 merge 하자... */
        /* +1의 의미는 위에서 상위 노드 하나를 sChild로 하나 내리는데 이에 대한값을 -1 해주는것이다 */
        if ( dbmIdxIndexCompare ( sIndexHeader,
                                  INDEX_POS( sChild, sTemp3, sKeySize ),
                                  INDEX_POS( sCurr, 0, sKeySize ),
                                  DBM_EQ, 0 ) != 0
             && sChild->mIndexSlotHeader.mLeafcheck == 1 )
        {

            /* leaf process */
            for ( i = 0; i < ( sTemp2 - 1 ); ++i )
            {
                /* sChild +1의 의미는 : 위에서 상위 노드 더한값을 더해준다는 위미
                 * sCurr  +1의 의미는 : leaf의 값이 벌써 상위 노드가 내려감으로써 반영 되었기 때문에 더해
                 *                      준다는 의미 */
                memcpy_s ( INDEX_POS( sChild, i + sTemp3 + 1, sKeySize ),
                           INDEX_POS( sCurr, i + 1, sKeySize ), sKeySize );
                sChild->mRID[i + sTemp3 + 1] = sCurr->mRID[i + 1];
                sChild->mChild[i + sTemp3 + 2] = sCurr->mChild[i + 2];
            }

            sTemp2 = sTemp2 - 1;
        }
        else
        {
            /* internal process */
            for ( i = 0; i < sTemp2; ++i )
            {
                memcpy_s ( INDEX_POS( sChild, i + sTemp3 + 1, sKeySize ),
                           INDEX_POS( sCurr, i, sKeySize ), sKeySize );
                sChild->mRID[i + sTemp3 + 1] = sCurr->mRID[i];
                sChild->mChild[i + sTemp3 + 2] = sCurr->mChild[i + 1];
            }
        }


        /* sCurr, sChild node의 element 요소가 변경 되기 때문에 변경을 해준다 */
        sChild->mIndexSlotHeader.mNodeCount = sChild->mIndexSlotHeader.mNodeCount + sTemp2;

        /*
        상위 internal ndoe에서 key , child 삭제하도록 하자....
        (상위 internal 노드가 하나 내려갔기 때문에 하나씩 옆으로 치환해주도록 한다 )
        */

        /* size : (DEGREE-1) - (sPos-1)
         * 어디에다 : sPos-1
         * 어디부터 : (sPos-1)+1 (sPos)
         * 어디만큼 : size
         */


        if ( sNewNode->mIndexSlotHeader.mNodeCount > 0 ) //&& sNewNode->mIndexSlotHeader.mNodeCount >= aPos )
        {
            if ( sNewNode->mIndexSlotHeader.mNodeCount >= aPos )
            {
                memmove_s ( INDEX_POS( sNewNode, aPos - 1, sKeySize ),
                            INDEX_POS( sNewNode, aPos, sKeySize ), sKeySize * ( ( DBM_INDEX_DEGREE - 1 ) - ( aPos - 1 ) ) );
                memmove_s ( &sNewNode->mRID[aPos - 1],
                            &sNewNode->mRID[aPos], sizeof(long long*) * ( ( DBM_INDEX_DEGREE - 1 ) - ( aPos - 1 ) ) );
                memmove_s ( &sNewNode->mChild[aPos],
                            &sNewNode->mChild[aPos + 1], sizeof(long long*) * ( ( DBM_INDEX_DEGREE - 1 ) - ( aPos - 1 ) ) );

                memset_s ( INDEX_POS( sNewNode, DBM_INDEX_DEGREE - 2, sKeySize ), 0x00, sKeySize );
                sNewNode->mRID[DBM_INDEX_DEGREE - 2] = -1;
                sNewNode->mChild[DBM_INDEX_DEGREE - 1] = -1;
            }
            else // if ( sNewNode->mIndexSlotHeader.mNodeCount > 0 )
            {
                memset_s ( INDEX_POS( sNewNode, aPos - 1, sKeySize ), 0x00, sKeySize );
                sNewNode->mRID[aPos - 1] = -1;
                sNewNode->mChild[aPos] = -1;

                memset_s ( INDEX_POS( sNewNode, DBM_INDEX_DEGREE - 2, sKeySize ), 0x00, sKeySize );
                sNewNode->mRID[DBM_INDEX_DEGREE - 2] = -1;
                sNewNode->mChild[DBM_INDEX_DEGREE - 1] = -1;
            }
        }


        /**********************************************
         * leaf간의 관계를 조정 한다
         **********************************************/
        sRC = dbmIdxDeleteNonLeftAdjust ( &sNewNode, &sCurr, &sChild, aTransID, sIndexHeader, sSegMgr, aLockMgr );
        if ( sRC != 0 ) //, DBM_INDEX_ADJUST_FAIL );
        {
            DBM_ERR( "mDeleteNonLeftAdjust errror [%d]", sRC );
            _THROW( ERR_DBM_FREE_SLOT_FATAL_IN_INDEX );
        }

        if ( sNewNode->mIndexSlotHeader.mNodeCount == 0 )
        {
            /* sChild 초기화 */
            dbmIdxDeleteKeyClear ( &sNewNode, sIndexHeader );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    {
        /* leaf unlock 처리 */
        mvpAtomicCas32_s( &sChild->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
        /* 2014.02.06 -shw- free slot한 후 lock 풀어줄필요가 없다... 주석으로 막음 */
        //mvpAtomicCas32_s(&sCurr->mIndexSlotHeader.mLock,-1,aTransID); // 2014.09.26 -okt- 오류에서는 열려있었음.
    }
    _END
} /* dbmIdxDeleteNonLeftSiblingNu */


/********************************************************************
 * ID : mDeleteNonRightSibling
 *
 * Description
 *   좌측 sibling, parent 와 합쳐 B-Tree 조정을 하도록 한다.
 *   위의 모듈은 internal node 와 비교 하였을 경우 left,right sibling 할게
 *   없을 경우 타게 되는 모듈이다. 위의 모듈을 탄다는 것으 parent 합쳐서
 *   right sibling이 된다는 것을 의미한다.
 *
 * Argument
 *     aNewNode    : input : 부모 노드 가리키고 있는 pointer
 *     aCurr       : input : 현재 자신의 node 가리키는 pointer
 *     aPos        : input : 부모 노드에서 key가 가리키도 있는 자식 노드의 position
 *     aTransID    : input : Transaction ID
 *     aIndexHeader: input : dbm Index Header
 *     aSegMgr     : input : Index Segment Pointer
 *     aLockMgr    : input : Index Lock Handle
 *
********************************************************************/
_VOID dbmIdxDeleteNonRightSibling ( dbmIndexNode** aNewNode ,
                                    dbmIndexNode** aCurr ,
                                    int aPos ,
                                    int aTransID ,
                                    dbmIndexHeader* aIndexHeader ,
                                    dbmSegmentManager* aSegMgr ,
                                    dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sNewNode = NULL;
    dbmIndexNode*       sCurr = NULL;
    dbmIndexNode*       sChild = NULL;
    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;

    int     sKeySize;
    int     sTemp2;         /* 임시 element count */
    int     sTemp3;         /* 임시 element count */
    int     i;

    _TRY
    {
        /* 초기화 처리 */
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;
        sNewNode = *aNewNode;
        sCurr = *aCurr;
        sKeySize = sIndexHeader->mIndex.mKeySize;

        /* child left sibling */
        /* 하위 노드의 우측 노드 */
        _CALL( sSegMgr->Slot2Addr ( sNewNode->mChild[aPos + 1], &sChild ) );

        /* 2014.02.18 -shw- delete key 처리 시  logging  필요없어 일단 막음 */
        /* sChild에 대한 Index Logging 처리를 한다 */
        //sRC = mIndexLogging(&sChild->mCurrSlot,aTransID);
        //_IF_RAISE(sRC, DBM_INDEX_LOGGING_FAIL);

        /* 하위 노드의  우측 노드의 element 개수 */
        sTemp3 = sChild->mIndexSlotHeader.mNodeCount;

        /*********************************************************************
         * 여기에서는 기준이 left sibling이 된다. sTmpe2의 개수를 left sibling
         * 에 현재의 node에서 이동하려는 개수이다. 앞으로 sTmpe2의 slot은 없어
         * 지게 되므로 위와 관련 된 값을 조정을 해야 한다.
         * sCurr 현재 노드의 element 개수
         **********************************************************************/
        sTemp2 = sCurr->mIndexSlotHeader.mNodeCount;


        /* position 구하기 위하여 search 하는데 다른 node와 lock 경합이 필요하다 */
        _CALL( mSpinLockLib ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sNewNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sChild->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

        /* parent 처리를 한다 */
        memcpy_s ( INDEX_POS( sCurr, sTemp2, sKeySize ),
                   INDEX_POS( sNewNode, aPos, sKeySize ), sKeySize );
        sCurr->mRID[sTemp2] = sNewNode->mRID[aPos];
        /* 아래에서 right sibling 다가져올거기 때문에 right 첫번째 child 옮겨 놓는다 */
        sCurr->mChild[sTemp2 + 1] = sChild->mChild[0];

        /* node의 element 요소가 변경 되기 때문에 변경을 해준다 */
        mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );
        sNewNode->mIndexSlotHeader.mNodeCount = sNewNode->mIndexSlotHeader.mNodeCount - 1;


        /* sCurr key와 child를  curr sibling에 merge 하자... */
        /* 상위 노드와 하위 노드가 같다는 것은 결국 leaf 라는 것이다. leaf의 노드는
         * child에 대하여 신경쓰지 말자.. 왜냐 없으니까... */
        if ( dbmIdxIndexCompare ( sIndexHeader,
                                  INDEX_POS( sCurr, sTemp2, sKeySize ),
                                  INDEX_POS( sChild, 0, sKeySize ),
                                  DBM_EQ, 0 ) )
        {
            /* [1 2] [3 4] 3 */
            for ( i = 0; i < ( sTemp3 - 1 ); ++i )
            {
                /***************************************************************************
                 * i : sTemp2부터 순차적으로 1+2....
                 * 1 : sTemp2에서 root값이 1내려 왔기 때문에 copy pointer 위치는 sTemp2+1을
                 *     해주어야 한다.
                 ****************************************************************************/
                memcpy_s ( INDEX_POS( sCurr, i + sTemp2 + 1, sKeySize ),
                           INDEX_POS( sChild, i + 1, sKeySize ), sKeySize );
                sCurr->mRID[i + sTemp2 + 1] = sChild->mRID[i + 1];
                sCurr->mChild[i + sTemp2 + 2] = sChild->mChild[i + 2];
            }

            sTemp3 = sTemp3 - 1;
        }
        else
        {
            for ( i = 0; i < sTemp3; ++i )
            {
                /***************************************************************************
                 * i : sTemp2부터 순차적으로 1+2....
                 * 1 : sTemp2에서 root값이 1내려 왔기 때문에 copy pointer 위치는 sTemp2+1을
                 *     해주어야 한다.
                 ****************************************************************************/
                memcpy_s ( INDEX_POS( sCurr, i + sTemp2 + 1, sKeySize ),
                           INDEX_POS( sChild, i, sKeySize ), sKeySize );
                sCurr->mRID[i + sTemp2 + 1] = sChild->mRID[i];
                /* [3] = [1]
                 * [4] = [2]
                 * -- [2]의 값은 위에서 하였음 */
                sCurr->mChild[i + sTemp2 + 2] = sChild->mChild[i + 1];
            }
        }

        /* sCurr, sChild node의 element 요소가 변경 되기 때문에 변경을 해준다 */
        sCurr->mIndexSlotHeader.mNodeCount = sCurr->mIndexSlotHeader.mNodeCount + sTemp3;


        /*
         상위 internal ndoe에서 key , child 삭제하도록 하자....
         (상위 internal 노드가 하나 내려갔기 때문에 하나씩 옆으로 치환해주도록 한다 )
         */

        /* size : (DEGREE-1) - (sPos)
         * 어디에다 : sPos
         * 어디부터 : (sPos+1)
         * 어디만큼 : size((DBM_INDEX_DEGREE-1) - aPos)
         */

        if ( sNewNode->mIndexSlotHeader.mNodeCount > 0 )
        {
            memmove_s ( INDEX_POS( sNewNode, aPos, sKeySize ),
                        INDEX_POS( sNewNode, aPos + 1, sKeySize ),
                        sKeySize * ( ( DBM_INDEX_DEGREE - 1 ) - aPos ) );
            memmove_s ( &sNewNode->mRID[aPos],
                        &sNewNode->mRID[aPos + 1], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 1 ) - aPos ) );
            memmove_s ( &sNewNode->mChild[aPos + 1],
                        &sNewNode->mChild[aPos + 2], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 1 ) - aPos ) );

            /* sNewNode 마지막 초기화 처리 */
            memset_s ( INDEX_POS( sNewNode, DBM_INDEX_DEGREE - 2, sKeySize ), 0x00, sKeySize );
            sNewNode->mRID[DBM_INDEX_DEGREE - 2] = -1;
            sNewNode->mChild[DBM_INDEX_DEGREE - 1] = -1;
        }


        /**********************************************
         * leaf간의 관계를 조정 한다
         **********************************************/
        _CALL( dbmIdxDeleteNonRightAdjust ( &sNewNode, &sCurr, &sChild, aTransID, sIndexHeader, sSegMgr, aLockMgr ) );

        if ( sNewNode->mIndexSlotHeader.mNodeCount == 0 )
        {
            /* sChild 초기화 */
            dbmIdxDeleteKeyClear ( &sNewNode, sIndexHeader );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    {
        /* leaf unlock 처리 */
        /* 2014.02.06 shw free slot을 다시 lock풀어줄 필요가 없다 */
        //mvpAtomicCas32_s(&sChild->mIndexSlotHeader.mLock,-1,aTransID);        // 2014.09.26 -okt- 원래코드는 오류발생하면 풀었다.
        mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
    }
    _END
} /* dbmIdxDeleteNonRightSibling */


/********************************************************************
 * ID : mDeleteNuNonRightSibling
 *
 * Description(non-unique index type)
 *   좌측 sibling, parent 와 합쳐 B-Tree 조정을 하도록 한다.
 *   위의 모듈은 internal node 와 비교 하였을 경우 left,right sibling 할게
 *   없을 경우 타게 되는 모듈이다. 위의 모듈을 탄다는 것으 parent 합쳐서
 *   right sibling이 된다는 것을 의미한다.
 *
 * Argument
 *     aNewNode    : input : 부모 노드 가리키고 있는 pointer
 *     aCurr       : input : 현재 자신의 node 가리키는 pointer
 *     aPos        : input : 부모 노드에서 key가 가리키도 있는 자식 노드의 position
 *     aTransID    : input : Transaction ID
 *     aIndexHeader: input : dbm Index Header
 *     aSegMgr     : input : Index Segment Pointer
 *     aLockMgr    : input : Index Lock Handle
 *
********************************************************************/
_VOID dbmIdxDeleteNonRightSiblingNu ( dbmIndexNode** aNewNode ,
                                      dbmIndexNode** aCurr ,
                                      int aPos ,
                                      int aTransID ,
                                      dbmIndexHeader* aIndexHeader ,
                                      dbmSegmentManager* aSegMgr ,
                                      dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sNewNode;
    dbmIndexNode*       sCurr;
    dbmIndexNode*       sChild;
    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;
    int     sKeySize;
    int     sTemp2;         /* 임시 element count */
    int     sTemp3;         /* 임시 element count */
    int     sRC;
    int     i;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        /* 초기화 처리 */
        sNewNode = NULL;
        sCurr = NULL;
        sChild = NULL;

        sNewNode = *aNewNode;
        sCurr = *aCurr;

        sKeySize = INDEX_KEY_SIZE( sIndexHeader->mIndex.mKeySize );

        /* child left sibling */
        /* 하위 노드의 우측 노드 */
        _CALL( sSegMgr->Slot2Addr ( sNewNode->mChild[aPos + 1], &sChild ) );

        /* 2014.02.18 -shw- delete key 처리 시  logging  필요없어 일단 막음 */
        /* sChild에 대한 Index Logging 처리를 한다 */
        //sRC = mIndexLogging(&sChild->mCurrSlot,aTransID);
        //_IF_RAISE(sRC, DBM_INDEX_LOGGING_FAIL);

        /* 하위 노드의  우측 노드의 element 개수 */
        sTemp3 = sChild->mIndexSlotHeader.mNodeCount;

        /*********************************************************************
         * 여기에서는 기준이 left sibling이 된다. sTmpe2의 개수를 left sibling
         * 에 현재의 node에서 이동하려는 개수이다. 앞으로 sTmpe2의 slot은 없어
         * 지게 되므로 위와 관련 된 값을 조정을 해야 한다.
         * sCurr 현재 노드의 element 개수
         **********************************************************************/
        sTemp2 = sCurr->mIndexSlotHeader.mNodeCount;


        /* position 구하기 위하여 search 하는데 다른 node와 lock 경합이 필요하다 */
        _CALL( mSpinLockLib ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sNewNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );
        _CALL( mSpinLockLib ( &sChild->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

        /* parent 처리를 한다 */
        memcpy_s ( INDEX_POS( sCurr, sTemp2, sKeySize ),
                   INDEX_POS( sNewNode, aPos, sKeySize ), sKeySize );
        sCurr->mRID[sTemp2] = sNewNode->mRID[aPos];
        /* 아래에서 right sibling 다가져올거기 때문에 right 첫번째 child 옮겨 놓는다 */
        sCurr->mChild[sTemp2 + 1] = sChild->mChild[0];

        /* node의 element 요소가 변경 되기 때문에 변경을 해준다 */
        mvpAtomicInc32 ( &sCurr->mIndexSlotHeader.mNodeCount );
        sNewNode->mIndexSlotHeader.mNodeCount = sNewNode->mIndexSlotHeader.mNodeCount - 1;


        /* sCurr key와 child를  curr sibling에 merge 하자... */
        /* 상위 노드와 하위 노드가 같다는 것은 결국 leaf 라는 것이다. leaf의 노드는
         * child에 대하여 신경쓰지 말자.. 왜냐 없으니까... */
        if ( dbmIdxIndexCompare ( sIndexHeader,
                                  INDEX_POS( sCurr, sTemp2, sKeySize ),
                                  INDEX_POS( sChild, 0, sKeySize ),
                                  DBM_EQ, 0 ) != 0 )
        {

            /* [1 2] [3 4] 3 */
            for ( i = 0; i < ( sTemp3 - 1 ); ++i )
            {
                /***************************************************************************
                 * i : sTemp2부터 순차적으로 1+2....
                 * 1 : sTemp2에서 root값이 1내려 왔기 때문에 copy pointer 위치는 sTemp2+1을
                 *     해주어야 한다.
                 ****************************************************************************/
                memcpy_s ( INDEX_POS( sCurr, i + sTemp2 + 1, sKeySize ),
                           INDEX_POS( sChild, i + 1, sKeySize ), sKeySize );
                sCurr->mRID[i + sTemp2 + 1] = sChild->mRID[i + 1];
                sCurr->mChild[i + sTemp2 + 2] = sChild->mChild[i + 2];
            }

            sTemp3 = sTemp3 - 1;
        }
        else
        {
            for ( i = 0; i < sTemp3; ++i )
            {
                /***************************************************************************
                 * i : sTemp2부터 순차적으로 1+2....
                 * 1 : sTemp2에서 root값이 1내려 왔기 때문에 copy pointer 위치는 sTemp2+1을
                 *     해주어야 한다.
                 ****************************************************************************/
                memcpy_s ( INDEX_POS( sCurr, i + sTemp2 + 1, sKeySize ),
                           INDEX_POS( sChild, i, sKeySize ), sKeySize );
                sCurr->mRID[i + sTemp2 + 1] = sChild->mRID[i];
                /* [3] = [1]
                 * [4] = [2]
                 * -- [2]의 값은 위에서 하였음 */
                sCurr->mChild[i + sTemp2 + 2] = sChild->mChild[i + 1];
            }
        }

        /* sCurr, sChild node의 element 요소가 변경 되기 때문에 변경을 해준다 */
        sCurr->mIndexSlotHeader.mNodeCount = sCurr->mIndexSlotHeader.mNodeCount + sTemp3;


        /*
        상위 internal ndoe에서 key , child 삭제하도록 하자....
        (상위 internal 노드가 하나 내려갔기 때문에 하나씩 옆으로 치환해주도록 한다 )
        */

        /* size : (DEGREE-1) - (sPos)
         * 어디에다 : sPos
         * 어디부터 : (sPos+1)
         * 어디만큼 : size((DBM_INDEX_DEGREE-1) - aPos)
         */

        if ( sNewNode->mIndexSlotHeader.mNodeCount > 0 )
        {
            memmove_s ( INDEX_POS( sNewNode, aPos, sKeySize ),
                        INDEX_POS( sNewNode, aPos + 1, sKeySize ), sKeySize * ( ( DBM_INDEX_DEGREE - 1 ) - aPos ) );
            memmove_s ( &sNewNode->mRID[aPos],
                        &sNewNode->mRID[aPos + 1], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 1 ) - aPos ) );
            memmove_s ( &sNewNode->mChild[aPos + 1],
                        &sNewNode->mChild[aPos + 2], sizeof(long long) * ( ( DBM_INDEX_DEGREE - 1 ) - aPos ) );

            /* sNewNode 마지막 초기화 처리 */
            memset_s ( INDEX_POS( sNewNode, DBM_INDEX_DEGREE - 2, sKeySize ), 0x00, sKeySize );
            sNewNode->mRID[DBM_INDEX_DEGREE - 2] = -1;
            sNewNode->mChild[DBM_INDEX_DEGREE - 1] = -1;
        }


        /**********************************************
         * leaf간의 관계를 조정 한다
         **********************************************/
        sRC = dbmIdxDeleteNonRightAdjust ( &sNewNode, &sCurr, &sChild, aTransID, sIndexHeader, sSegMgr, aLockMgr );
        if ( sRC != 0 ) //, DBM_INDEX_ADJUST_FAIL );
        {
            DBM_ERR ( "dbm mDeleteNonRightAdjust errror [%d]", sRC);
            _THROW( ERR_DBM_FREE_SLOT_FATAL_IN_INDEX );
        }

        if ( sNewNode->mIndexSlotHeader.mNodeCount == 0 )
        {
            /* sChild 초기화 */
            dbmIdxDeleteKeyClear ( &sNewNode, sIndexHeader );
        }

        /* leaf unlock 처리 */
        /* 2014.02.06 shw free slot을 다시 lock풀어줄 필요가 없다 */
        //mvpAtomicCas32_s(&sChild->mIndexSlotHeader.mLock,-1,aTransID);
        mvpAtomicCas32_s( &sNewNode->mIndexSlotHeader.mLock, -1, aTransID );
        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* dbmIdxDeleteNonRightSiblingNu */


/********************************************************************
 * ID : mDeleteNonLeafAdjust
 *
 * Description
 * mDeleteNonLeftSibling 처리 시 변경된 Node간의 관계를 조정한다.
 *
 * Argument
 *     aNewNode     : input : 부모 노드 가리키고 있는 pointer
 *     aCurr        : input : 현재 자신의 node 가리키는 pointer
 *     aChild       : input : 자신의 왼쪽의 node의 pointer
 *     aTransID     : input : Transaction ID
 *     aIndexHeader : input : dbm Index Header
 *     aSegMgr      : input : Index Segment Pointer
 *     aLockMgr     : input : Index Lock Handle
 *
********************************************************************/
_VOID dbmIdxDeleteNonLeftAdjust ( dbmIndexNode** aNewNode ,
                                  dbmIndexNode** aCurr ,
                                  dbmIndexNode** aChild ,
                                  int aTransID ,
                                  dbmIndexHeader* aIndexHeader ,
                                  dbmSegmentManager* aSegMgr ,
                                  dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sNewNode;
    dbmIndexNode*       sCurr;
    dbmIndexNode*       sChild;
    dbmIndexNode*       sNextNode;
    dbmIndexNode*       sCurrChildNode;

    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;

    long long           sCurrSlot;
    int                 i;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        sNewNode = *aNewNode;
        sCurr = *aCurr;
        sChild = *aChild;

        /* 2013.01.22 shw */
        /* sCurr의 node가 없어지면서 root가 변경이 되기 때문에 sCurr의 node의 root
         * flag를 변경해 준다 */
        for ( i = 0; i < DBM_INDEX_DEGREE; i++ )
        {
            if ( sCurr->mChild[i] >= 0 && sCurr->mIndexSlotHeader.mLeafcheck != 1 )
            {
                _CALL( sSegMgr->Slot2Addr ( sCurr->mChild[i], &sCurrChildNode ) );

                _CALL( mSpinLockLib ( &sCurrChildNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                sCurrChildNode->mIndexSlotHeader.mRootSlotID = sChild->mCurrSlot;

                mvpAtomicCas32_s( &sCurrChildNode->mIndexSlotHeader.mLock, -1, aTransID );
            }
            else
            {
                break;
            }
        }

        /**********************************************
         * leaf간의 관계를 조정 한다
         **********************************************/
        /* 1.Child */
        // Root Slot ID
        if ( sNewNode->mIndexSlotHeader.mNodeCount == 0 )
        {
            if ( sNewNode->mIndexSlotHeader.mRootFlag == 1 )
            {
                /* node Count가 0이라는 것은 element 없다는 것이다. 결국은 못쓰는 slot이 되는 것을 얘기한다
                 * root flag 설정으로 변경을 해준다 */
                /* root slot Header info set */
                sChild->mIndexSlotHeader.mRootFlag = 1; /* 1:root slot 0:non-root slot */
                /* 1:root slot 0:non-root slot */
                sChild->mIndexSlotHeader.mRootSlotID = -1;
                /* next leaf id */
                sChild->mIndexSlotHeader.mLeafNextID = -1;
                /* prev leaf id */
                sChild->mIndexSlotHeader.mLeafPrevID = -1;

                if ( sChild->mIndexSlotHeader.mLeafcheck != 1 )
                    sChild->mIndexSlotHeader.mLeafcheck = -1;

                /* root key move */
                sIndexHeader->mRootPid = sChild->mCurrSlot;
            }
            /* root flag가 1이 아니라는 것은 상위 slot이 계속 살아있게 되는 것을 의미한다 */

        }
        else
        { // Root Slot이 0 아니였을 경우
            /* root slot이 그대로 있기 때문에 rootslot id변경은 필요 없다 */
            /* right sibling 조정이기 때문에 mleafPrev ID 변경은 없다 */

            /* right sibling 조정이 있기 때문에 mleafnext ID 변경은 있다 */
            /* next leaf id */
            sChild->mIndexSlotHeader.mLeafNextID = sCurr->mIndexSlotHeader.mLeafNextID;

        }

        /* Btree Check 조정 value 변경 */
        mvpAtomicInc64 ( &sCurr->mBtreeCheck );
        mvpAtomicInc64 ( &sChild->mBtreeCheck );
        mvpAtomicInc64 ( &sNewNode->mBtreeCheck );

        sCurrSlot = sCurr->mCurrSlot;
        /* sChild 초기화 */
        dbmIdxDeleteKeyClear ( &sCurr, sIndexHeader );
        sCurr->mCurrSlot = -1;

        /* 2. sCurr */
        // sCurr Node Count 무조건 0이다
        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
        _CALL( dbmSegFreeSlot( sSegMgr, sCurrSlot, 0 ) );     // by mDeleteNonLeftAdjustLib

        /* 2014.01.22 shw sNewNode->mIndexSlotHeader.mNodeCount < 0주석으로 막음 */
        /* 0보다 클때도 sChild가 사라지게 되면 next id가 있을 수 있기 때문에 해당 next id를 변경해 주여야 한다 */
        /* 3. Next Node */
        /* next ID가 있을 경우 이전의 slot id가 변경이 되었기 때문에 바꾸어 준다 */
        if ( sChild->mIndexSlotHeader.mLeafcheck == 1 && sChild->mIndexSlotHeader.mLeafNextID >= 0 )
        {
#ifdef INDEX_TEST
            DBM_DBG( "sChild->mIndexSlotHeader.mLeafNextID[%lld]", sChild->mIndexSlotHeader.mLeafNextID );
#endif

            _CALL( sSegMgr->Slot2Addr ( sChild->mIndexSlotHeader.mLeafNextID, &sNextNode ) );

            _CALL( mSpinLockLib ( &sNextNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

            sNextNode->mIndexSlotHeader.mLeafPrevID = sChild->mCurrSlot;

            mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* dbmIdxDeleteNonLeftAdjust */


/********************************************************************
 * ID : mDeleteNonRightAdjust
 *
 * Description
 * mDeleteNonRightSibling 처리 시 변경된 Node간의 관계를 조정한다.
 *
 * Argument
 *     aNewNode     : input : 부모 노드 가리키고 있는 pointer
 *     aCurr        : input : 현재 자신의 node 가리키는 pointer
 *     aChild       : input : 자신의 오른쪽의 node의 pointer
 *     aTransID     : input : Transaction ID
 *     aIndexHeader : input : dbm Index Header
 *     aSegMgr      : input : Index Segment Pointer
 *     aLockMgr     : input : Index Lock Handle
 *
********************************************************************/
_VOID dbmIdxDeleteNonRightAdjust ( dbmIndexNode** aNewNode ,
                                   dbmIndexNode** aCurr ,
                                   dbmIndexNode** aChild ,
                                   int aTransID ,
                                   dbmIndexHeader* aIndexHeader ,
                                   dbmSegmentManager* aSegMgr ,
                                   dbmLockManager* aLockMgr )
{
    dbmIndexNode*       sNewNode;
    dbmIndexNode*       sCurr;
    dbmIndexNode*       sChild;
    dbmIndexNode*       sNextNode;
    dbmIndexNode*       sCurrChildNode;

    dbmIndexHeader*     sIndexHeader;
    dbmSegmentManager*  sSegMgr;
    long long           sCurrSlot;
    int                 i;

    _TRY
    {
        sIndexHeader = aIndexHeader;
        sSegMgr = aSegMgr;

        sNewNode = *aNewNode;
        sCurr = *aCurr;
        sChild = *aChild;

        /* 2013.01.22 shw */
        /* sChild의 node가 없어지면서 root가 변경이 되기 때문에 sChild의 node의 root
         * flag를 변경해 준다 */
        for ( i = 0; i < DBM_INDEX_DEGREE; i++ )
        {
            if ( sChild->mChild[i] >= 0 && sChild->mIndexSlotHeader.mLeafcheck != 1 )
            {
                _CALL( sSegMgr->Slot2Addr ( sChild->mChild[i], &sCurrChildNode ) );

                _CALL( mSpinLockLib ( &sCurrChildNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

                sCurrChildNode->mIndexSlotHeader.mRootSlotID = sCurr->mCurrSlot;

                mvpAtomicCas32_s( &sCurrChildNode->mIndexSlotHeader.mLock, -1, aTransID );
            }
            else
            {
                break;
            }
        }

        /**********************************************
         * leaf간의 관계를 조정 한다
         **********************************************/
        /* 1.Curr */
        // Root Slot ID
        if ( sNewNode->mIndexSlotHeader.mNodeCount == 0 )
        {
            if ( sNewNode->mIndexSlotHeader.mRootFlag == 1 )
            {
                /* node Count가 0이라는 것은 element 없다는 것이다. 결국은 못쓰는 slot이 되는 것을 얘기한다
                 * root flag 설정으로 변경을 해준다 */
                /* root slot Header info set */
                sCurr->mIndexSlotHeader.mRootFlag = 1; /* 1:root slot 0:non-root slot */
                /* 1:root slot 0:non-root slot */
                sCurr->mIndexSlotHeader.mRootSlotID = -1;
                /* next leaf id */
                sCurr->mIndexSlotHeader.mLeafNextID = -1;
                /* prev leaf id */
                sCurr->mIndexSlotHeader.mLeafPrevID = -1;

                if ( sCurr->mIndexSlotHeader.mLeafcheck != 1 )
                    sCurr->mIndexSlotHeader.mLeafcheck = -1;

                /* root key move */
                sIndexHeader->mRootPid = sCurr->mCurrSlot;
            }
            /* root flag가 1이 아니라는 것은 상위 slot이 계속 살아있게 되는 것을 의미한다 */
        }
        else
        { // Root Slot이 0 아니였을 경우
            /* root slot이 그대로 있기 때문에 rootslot id변경은 필요 없다 */
            /* right sibling 조정이기 때문에 mleafPrev ID 변경은 없다 */

            /* right sibling 조정이 있기 때문에 mleafnext ID 변경은 있다 */
            /* next leaf id */
            sCurr->mIndexSlotHeader.mLeafNextID = sChild->mIndexSlotHeader.mLeafNextID;
        }

        /* Btree Check 조정 value 변경 */
        mvpAtomicInc64 ( &sCurr->mBtreeCheck );
        mvpAtomicInc64 ( &sChild->mBtreeCheck );
        mvpAtomicInc64 ( &sNewNode->mBtreeCheck );

        sCurrSlot = sChild->mCurrSlot;

        /* sChild 초기화 */
        dbmIdxDeleteKeyClear ( &sChild, sIndexHeader );
        sChild->mCurrSlot = -1;

        /* 2. Child */
        // sChild Node Count 무조건 0이다
        mvpAtomicCas32_s( &sChild->mIndexSlotHeader.mLock, -1, aTransID );

        /*
         * 2014.10.14 -okt-
         * 위의 락푸는 코드와 순서를 바꾸면, I/U/D는 인덱스전역락에서 대기하지만.
         * SELECT는 여기에서 대기하고 있다가. mlock에서 깨어나지 못할수 있다고 설명들음
         */
        _CALL( dbmSegFreeSlot( sSegMgr, sCurrSlot, 0 ) );  // by mDeleteNonRightAdjustLib

        /* 3. Next Node */
        /* 이전 slot이 변경이 되었으므로 변경 전의 값을 설정한다 */
        if ( sCurr->mIndexSlotHeader.mLeafcheck == 1 && sCurr->mIndexSlotHeader.mLeafNextID >= 0 )
        {
            _CALL( sSegMgr->Slot2Addr ( sCurr->mIndexSlotHeader.mLeafNextID, &sNextNode ) );

            _CALL( mSpinLockLib ( &sNextNode->mIndexSlotHeader.mLock, NULL, aTransID, aLockMgr ) );

            sNextNode->mIndexSlotHeader.mLeafPrevID = sCurr->mCurrSlot;

            mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID );
        }
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* dbmIdxDeleteNonRightAdjust */
