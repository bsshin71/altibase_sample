rm -f main_test
#g++ -g -o main_test main_test.cpp -I../../include -I../../../common/lib/src/include -I../../../common/include -L./ -L/home/shw/dbm_renewal/trunk/common/lib/src -lTest -lcmn -lm -lpthread -ldl -rdynamic -lrt
g++ -g -o main_test main_test.cpp -I../../include -I../../../common/lib/src/include -I../../../common/include -L../ -L/home/shw/dbm_renewal/trunk/common/lib/src -ldbm -lcmn -lm -lpthread -ldl -rdynamic -lrt 

