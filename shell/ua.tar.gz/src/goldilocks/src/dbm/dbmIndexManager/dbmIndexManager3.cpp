/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 * Index 관련되어 처리 하는 Source 이다.
*******************************************************************************/
#include "dbmIndexManagerInterface.h"
#include "dbmHeader.h"

#define INDEX_KEY_LEN   264

/********************************************************************
 * ID : mSearchKey
 *
 * Description
 *   dbm Index key search 처리 한다.
 *
 * Argument
 *     aTransID : input : Transaction ID
 *     aKey     : input : 검색할 key value
 *     aRID     : output: key 검색하여 찾은 data ID
 *
********************************************************************/
__thread int*   g_nDepthNodeCnt = NULL;
__thread long long*  g_nBtreeCnt = NULL;
__thread char*  g_pKey = NULL;
__thread int*   g_nDepthNodePosition = NULL;

_VOID dbmIndexManager::mSearchKey ( int aTransID , char* aKey , long long* aRID )
{
    /* NODE pointer */
    dbmIndexSlotHeader* sIndexSlotHeader;
    dbmIndexNode*   sRoot = NULL;
    dbmIndexNode*   sChild = NULL;
    dbmIndexNode*   sPositionNode;

    char*   sSlotAddr = NULL;
    int     sPos = 0;
    int     nTmpOffset;
    char*   pBuf = NULL;
    int     sRepeat = 0;

    int     sCount;
    char*   sKey = NULL;
    int     sPosition;
    int     sDepthChkCnt;
    int     sNodeCheck;
    int     sFirStNodeCheck;
    int     sIndexCheck;
    long long sIndexSlotID;
    long long sBtreeCnt;
    int     sRC = -1;
    int     sRC2 = -1;
    int     i;
    int     sRetryCnt = 0;

    _TRY
    {
        sIndexCheck = 0;
        sIndexSlotID = 0;

        if ( g_nDepthNodeCnt == NULL )
        {
            g_nDepthNodeCnt = (int*) malloc_s ( sizeof(int) * DBM_INDEX_DEPTH_MAX );
            g_nBtreeCnt = (long long*) malloc_s ( sizeof(long long) * DBM_INDEX_DEPTH_MAX );
            g_pKey = (char*) malloc_s ( INDEX_KEY_LEN * DBM_INDEX_DEPTH_MAX );
            g_nDepthNodePosition = (int*) malloc_s ( sizeof(int) * DBM_INDEX_DEPTH_MAX );

            memset_s ( g_nDepthNodeCnt, 0, sizeof(int) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_nBtreeCnt , 0, sizeof(long long) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_pKey, 0, INDEX_KEY_LEN * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_nDepthNodePosition, 0, sizeof(int) * DBM_INDEX_DEPTH_MAX );
        }

        /* 2014.06.02 -shw- non-unique index type */
        /* mSearchKeyLT unique type만 오기 때문에 global 변수인 g_nNonIndexType 값을 0으로 초기화 한다 */
        g_bIsUniqueIndex = DBM_UNIQUE;

repeat:
        /* Index Tree Check */
        if( mIndexHeader->mTreeCheck  == 1 )
        {
            pthread_yield_s ();
            goto repeat;
        }

        /* 초기화 처리 */
        sDepthChkCnt = 0;
        sFirStNodeCheck = 0;
        sNodeCheck = 0;
        sBtreeCnt = 0;

        g_nDepthNodeCnt[0] = 0;
        g_nBtreeCnt[0] = 0;
        g_nDepthNodePosition[0] = 0;
        *(long long*) g_pKey = 0;

        _CALL( mSegMgr->Slot2Addr ( mIndexHeader->mRootPid, &sRoot ) );
        sKey = aKey;

#ifdef INDEX_TEST
        DBM_DBG( "***** mSearchKey start *****");
        DBM_DBG( "mSEarchKey input [%lld] child[%lld] key[%s][%d]",
                mIndexHeader->mRootPid, sRoot->mChild[0], sKey,*(int*)(sKey+20));
        PrintNodeElement2((dbmIndexNode*)sSlotAddr);

        _PRT(" search start !!!!!!!!!! \n");
        PrintNodeElement2((dbmIndexNode*)sSlotAddr);
        _PRT(" search end !!!!!!!!!! \n");
#endif

        /*************************************************
        * data null check
        *************************************************/
        if ( unlikely( sRoot->mIndexSlotHeader.mNodeCount <= 0 && sRoot->mChild[0] < 0 ) )
        {
            DBM_TRC( "Index Root data not found. [%d][%lld]", sRoot->mIndexSlotHeader.mNodeCount, sRoot->mChild[0] );
            _THROW( ERR_DBM_KEY_NOT_EXIST );
        }

        do /* while */
        {
            sIndexSlotHeader = &sRoot->mIndexSlotHeader;

            /* root 아래에 leaf 분기 되면 자식 노드는 0 부터 분기 된다 2:root 0:left leaf 1:right leaf */
            //if (sRoot->mChild[0] < 0)
            if ( sIndexSlotHeader->mLeafcheck == 1 )
            {

                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                sPositionNode = sRoot;

                // search key node 와 경합해야 한다, leaf spin lock 처리
                _CALL( mLockMgr->mSpinLock( &sIndexSlotHeader->mLock, NULL, aTransID ) );

                // search한 결과값을 알려준다
                sRC = dbmIdxSearchExist ( this->mIndexHeader, sRoot, sKey, &sPos );
                if ( sRC == 0 )
                {
                    *aRID = sRoot->mRID[sPos];
                }

                /* 2014.04.14 -shw- lock 순서 aRID 뒤로 변경 */
                mvpAtomicCas32_s ( &sIndexSlotHeader->mLock, -1, aTransID );

                /* index check 증가 값 */
                sIndexCheck++;

                /* 제일 처음일때 root의 분기 처리가 되었을 경우 lock 체크를 할 수 없기에
                 * 처음일 경우 mRootSlotID가 있다는 것은 leaf가 아니므로 재처리 한다 */
                if ( unlikely( sFirStNodeCheck == 0 ) )
                {
                    if ( sIndexSlotHeader->mRootSlotID > 0)
                    {
                        /* 계속 looping 인데 방어 코드가 있어야 하는거 아닌가 */
                        DBM_DBG( "First Select mRootSlotID, ix=%d, [%d] goto", ++sRepeat, sIndexSlotHeader->mRootSlotID );

                        if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) )
                        {
                            DBM_ERR( "index first node check error index 깨짐....[%d]", sIndexCheck );
                            _THROW ( ERR_DBM_DEPTH_FAIL );
                        }

                        pthread_yield_s ();
                        goto repeat;
                    }
                }

                if ( sRC == 0 )
                {
                    _RETURN;
                }
                else
                {
                    // 검색도중 스플릿인경우로 일시적으로 NOT FOUND 일수 있으므로, 검사한다.
                    /*
                     * 2014.09.30 -okt- aKey를 깨지지않게하기위해, 8Byte를 출력한다. 왜 "aKey+20" 을 출력하는지 모르겠다.
                     * test10_10_1 이 여기서 오류난다. (확률 극히 낮음 )
                     */
                    // #900 NOCS 테스트에서 생각보다 많이 진입한다. 진입비용을 그대로 둘 것인가?
                    DBM_DBG( "key not found [%.8s][%d] (err=%d,tid=%d)", aKey, *(int*)(aKey+20), errno, gettid_s() );

                    for ( i = sDepthChkCnt - 1; i >= 0; i-- )
                    {
                        // search key node 와 경합해야 한다, leaf spin lock 처리
                        _CALL( mLockMgr->mSpinLock( &sPositionNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        /* search 처리 후 해당 delte or insert로 트리 조정이 변경 되면 기존에 검색했던
                           값들이 변경 되기 때문에 다시 처음부터 갬색을 해보아야 한다 */
                        /* 2014.02.18 -shw */
                        /* 위의 lock를 사용하지 않기 위해 아래의  sIndexSlotID로 data copy 후 다시 체크했다 */
                        sIndexSlotID = mvpAtomicGet64 ( &sPositionNode->mIndexSlotHeader.mRootSlotID );
                        if ( unlikely( sIndexSlotID < 0 ) )
                        {
                            /*********************************************
                            * leaf unlock 처리
                            *********************************************/
                            mvpAtomicCas32_s ( &sPositionNode->mIndexSlotHeader.mLock, -1, aTransID );

                            DBM_DBG( "key not found sIndexSlotID change [%d] goto", sIndexSlotID );

                            if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) )
                            {
                                DBM_ERR( "index first node check error index 깨짐....[%d]", sIndexCheck );
                                _THROW ( ERR_DBM_DEPTH_FAIL );
                            }

                            pthread_yield_s( );
                            goto repeat;
                        }

                        {
                            sRC2 = mSegMgr->Slot2Addr ( sIndexSlotID, &sSlotAddr );
                            if ( unlikely( sRC2 != 0 ) ) //|| sSlotAddr == NULL )
                            {
                                mvpAtomicCas32_s ( &sPositionNode->mIndexSlotHeader.mLock, -1, aTransID );
                                _THROW( ERR_DBM_SLOT2ADDR_FAIL );
                            }

                            /*********************************************
                            * leaf unlock 처리
                            *********************************************/
                            mvpAtomicCas32_s ( &sPositionNode->mIndexSlotHeader.mLock, -1, aTransID );

                            sPositionNode = (dbmIndexNode*)sSlotAddr;
                        }

                        // search key node 와 경합해야 한다, leaf spin lock 처리
                        _CALL( mLockMgr->mSpinLock( &sPositionNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        mBinarySearchSelectLeaf ( sPositionNode->mIndexSlotHeader.mNodeCount, &sPosition, sPositionNode, sKey );

                        // sPosition==0?0:( sPosition - 1 ) 처리
                        if ( g_nDepthNodeCnt[i] != sPositionNode->mIndexSlotHeader.mNodeCount
                                || g_nBtreeCnt[i] != sPositionNode->mBtreeCheck
                                || g_nDepthNodePosition[i] != sPosition
                                || mIndexCompare ( g_pKey + ( i * INDEX_KEY_LEN ),
                                                   INDEX_POS( sPositionNode,
                                                              sPosition==0?0:( sPosition - 1 ), mIndexHeader->mIndex.mKeySize ), DBM_EQ ) != 1 )
                        {
                            mvpAtomicCas32_s( &sPositionNode->mIndexSlotHeader.mLock, -1, aTransID );

                            if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) )
                            {
                                DBM_ERR( "index node count fail index 깨짐... [%d:%d][%lld:%lld][%d:%d]",
                                          g_nDepthNodeCnt[i],sPositionNode->mIndexSlotHeader.mNodeCount,g_nBtreeCnt[i],sPositionNode->mBtreeCheck,
                                          g_nDepthNodePosition[i], sPosition );
                                _THROW( ERR_DBM_DEPTH_FAIL );
                            }

                            DBM_DBG( "TREE Retry [%lld][%lld]", sPositionNode->mBtreeCheck, g_nBtreeCnt[i] );

                            pthread_yield_s( );
                            goto repeat;
                        }

                        g_nDepthNodeCnt[i] = 0;
                        g_nDepthNodePosition[i] = 0;
                        g_nBtreeCnt[i] = 0;
                        mvpAtomicCas32_s ( &sPositionNode->mIndexSlotHeader.mLock, -1, aTransID );
                    } /* for */

                    if( mIndexHeader->mTreeCheck  == 1 )
                    {
                        pthread_yield_s ();
                        goto repeat;
                    }

// 2015.01.12 -okt- #760 삼성증권 PoC 에서 NOTFOUND 수정시 임시 추가한 안전 코드 원복
//            shw 확인받았고, 아래 막은 후 발생하면 새는 곳을 찾아야함.
#if 0
                    sRetryCnt++;
                    if( sRetryCnt < 10 )
                    {
                        goto repeat;
                    }
#endif

                    DBM_TRC( "key not found [%.8s][%d] (err=%d,tid=%d)", aKey, *(int*)(aKey+20), errno, gettid_s() ); // 위에 중복
                    _THROW( ERR_DBM_KEY_NOT_EXIST ); // 진짜로 없다.
                }

                break;
            }
            // ( sIndexSlotHeader->mLeafcheck != 1 )
            else
            {
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }
                // 2014.02.19 -shw- example14 참고 중간에 분기 처리 시 node count변경하는데 이를
                // lock를 걸지 않으면 binary search 할때 잘못된 값을 가져올수 밖에 없다. 결국 lock
                // 를 잡아야만 하는 건가.
                _CALL( mLockMgr->mSpinLock( &sIndexSlotHeader->mLock, NULL, aTransID ) );

                // 2014.07.10 btree check value로 변경 처리 한다.
                g_nDepthNodeCnt[sDepthChkCnt] = sIndexSlotHeader->mNodeCount;
                g_nBtreeCnt[sDepthChkCnt] = sRoot->mBtreeCheck;

                /* 2014.02.18 -shw */
                /* 위의 lock를 사용하지 않기 위해 아래의  sIndexSlotID로 data copy 후 다시 체크했다 */
                sCount = sIndexSlotHeader->mNodeCount;
                mBinarySearchSelectLeaf ( sCount, &sPosition, sRoot, sKey );

                g_nDepthNodePosition[sDepthChkCnt] = sPosition;

                // for 루프안에서 변수선언하지 않는다.
                nTmpOffset = 1;
                pBuf = g_pKey + ( sDepthChkCnt * INDEX_KEY_LEN );
                if ( sPosition == 0 )
                {
                    nTmpOffset = 0;
                }

                memcpy_s ( pBuf,
                           INDEX_POS( sRoot, sPosition - nTmpOffset, mIndexHeader->mIndex.mKeySize ),
                           mIndexHeader->mIndex.mKeySize );
                pBuf[mIndexHeader->mIndex.mKeySize] = 0;

                sIndexSlotID = mvpAtomicGet64 ( &sRoot->mChild[sPosition] );
                if ( sIndexSlotID < 0 )
                {
                    DBM_DBG( "Search Leaf sIndexSlotID change [%d] goto", sIndexSlotID );

                    /* 2014.03.25 -shw- goto repeat 할 때에 위에 lock 처리 된 부분을 unlock 해주어야 한다 */
                    // TODO: 2014.10.01 -okt- 여기서 중복락해제 발생, #630
                    mvpAtomicCas32_s( &sIndexSlotHeader->mLock, -1, aTransID );

                    if ( unlikely( sNodeCheck > DBM_INDEX_DEPTH_MAX ) )
                    {
                        DBM_DBG( "[INDEX_BRANCH_ERROR] slef[%lld] mchild[%lld] position[%d]", pthread_self(), sRoot->mChild[sPosition], sPosition );
                        _THROW( ERR_DBM_DEPTH_FAIL );
                    }

                    sNodeCheck++;

                    pthread_yield_s( );
                    goto repeat;
                }

                _CALL( mSegMgr->Slot2Addr(sIndexSlotID, &sChild) );
                mvpAtomicCas32_s ( &sIndexSlotHeader->mLock, -1, aTransID );
                sRoot = sChild;

                sDepthChkCnt++;
            }

            /* search key check 0: 처음 1: 반복 */
            sFirStNodeCheck = 1;

            if ( unlikely( sDepthChkCnt > DBM_INDEX_DEPTH_MAX ) )
            {
                DBM_ERR( "index depth max error [%d]", sDepthChkCnt );
                _THROW( ERR_DBM_DEPTH_FAIL );
            }
        } while ( 1 );

        DBM_TRC( "key not found ");
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_KEY_NOT_EXIST )
        {
            _CATCH_TRC;
        }
        else
        {
            switch ( _rc )
            {
                case ERR_DBM_SLOT2ADDR_FAIL:
                    /*
                     * TODO: 2014.09.26 -okt- 여기에 진입하는 경우가 없을수 있다. 초기 소스와 비교하고, 확인요.
                     * 락해제를 굳이 이런식으로 해야할까?
                     */
                    DBM_ERR( "Slot2Addr fail, mLock=%d, tx=%d", sRoot->mIndexSlotHeader.mLock, aTransID );
                    mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );
                    break;

                case ERR_DBM_LOCK_FAIL:
                    DBM_ERR( "index select leaf lock error [%d]", _rc );
                    break;

                case ERR_DBM_DEPTH_FAIL:
                    //TODO: 2014.10.02 -okt- 락이풀리고 여기오는 경우가 있다 [BUGBUG]
                    mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );
                    break;

                default:
                    break;
            }

            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* mSearchKey */


/********************************************************************
 * ID : mSearchKeyNu
 *
 * Description (non-unique index type)
 *   dbm Index key search 처리 한다.
 *
 * Argument
 *     aTransID : input : Transaction ID
 *     aKey     : input : 검색할 key value
 *     aRID     : output: key 검색하여 찾은 data ID
 *
********************************************************************/
__thread int*   g_nDepthNuNodeCnt = NULL;
__thread long long* g_nBtreeNuCnt = NULL;
__thread int*   g_nDepthNuNodePosition = NULL;
__thread char*  g_pKeyNuData = NULL;

_VOID dbmIndexManager::mSearchKeyNu ( int aTransID , char* aKey , long long* aRID, long long* aExtraKey, long long* aCurrExtraKey )
{
    /* NODE pointer */
    dbmIndexNode*   sRoot = NULL;
    dbmIndexNode*   sChild;
    dbmIndexNode*   sPositionNode;

    int     sCount;
    char*   sKey;
    char*   sKeyAddr;
    int     sPosition;
    int     sDepthChkCnt;
    int     sNodeCheck;
    int     sFirStNodeCheck;
    int     sIndexCheck;
    int     sRepeat;
    long long sIndexSlotID;
    long long sExtraTmp;
    long long sBtreeCnt;
    int     sKeySize;
    int     sRC;
    int     sRC2;
    int     i;

    _TRY
    {
        /* 초기화 처리 */
        sIndexCheck = 0;
        sIndexSlotID = 0;
        sRepeat = 0;
        sExtraTmp = 0;
        sExtraTmp = *aExtraKey;

        if ( g_nDepthNuNodeCnt == NULL )
        {
            g_nDepthNuNodeCnt = (int*) malloc_s ( sizeof(int) * DBM_INDEX_DEPTH_MAX );
            g_nBtreeNuCnt = (long long*) malloc_s ( sizeof(long long) * DBM_INDEX_DEPTH_MAX );
            g_nDepthNuNodePosition = (int*) malloc_s ( sizeof(int) * DBM_INDEX_DEPTH_MAX );
            g_pKeyNuData = (char*) malloc_s ( INDEX_KEY_LEN * DBM_INDEX_DEPTH_MAX );

            memset_s ( g_nDepthNuNodeCnt, 0, sizeof(int) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_nBtreeNuCnt , 0, sizeof(long long) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_nDepthNuNodePosition, 0, sizeof(int) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_pKeyNuData, 0, INDEX_KEY_LEN * DBM_INDEX_DEPTH_MAX );
        }

        /* non-unique index type set */
        g_bIsUniqueIndex = DBM_NON_UNIQUE;
        sKeySize = ( g_bIsUniqueIndex ) ? mIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( mIndexHeader->mIndex.mKeySize );

        // 2014.10.01 -okt- 루프내부 변수를 위로 선언.
        int     nTmpOffset = 1;
        char*   pBuf = NULL;
repeat:
        /* Index Tree Check */
        if( mIndexHeader->mTreeCheck  == 1 )
        {
            pthread_yield_s ();
            goto repeat;
        }

        /* 초기화 처리 */
        sDepthChkCnt = 0;
        sFirStNodeCheck = 0;
        sNodeCheck =0;
        sBtreeCnt = 0;

        g_nDepthNuNodeCnt[0] = 0;
        g_nBtreeNuCnt[0] = 0;
        g_nDepthNuNodePosition[0] = 0;
        *(long long*)g_pKeyNuData = 0;

        _CALL( mSegMgr->Slot2Addr ( mIndexHeader->mRootPid, &sRoot ) );
        sKey = aKey;

        /*************************************************
        * data null check
        *************************************************/
        if ( sRoot->mIndexSlotHeader.mNodeCount <= 0 && sRoot->mChild[0] < 0 )
        {
            DBM_INFO( "Index Root data not found !!!! [%d][%lld]", sRoot->mIndexSlotHeader.mNodeCount, sRoot->mChild[0] );
            *aExtraKey = -1;
            _THROW( ERR_DBM_KEY_NOT_EXIST );
        }

        do
        {
            /******************************************
            * search key node 와 경합해야 한다
            * leaf spin lock 처리
            *******************************************/

            /* root 아래에 leaf 분기 되면 자식 노드는 0 부터 분기 된다 2:root 0:left leaf 1:right leaf */
            if ( sRoot->mIndexSlotHeader.mLeafcheck == 1 )
            {
                // 2015.01.17 lock 잡는 구간을 위에서 아래로 각각 leaf별로 잡도록 처리 한다 -shw-
                // 2014.02.19 -shw- example14 참고 중간에 분기 처리 시 node count변경하는데 이를
                // lock를 걸지 않으면 binary search 할때 잘못된 값을 가져올수 밖에 없다. 결국 lock
                // 를 잡아야만 하는 건가.
                _CALL( mLockMgr->mSpinLock( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                sPositionNode = sRoot;

                /* 제일 처음일때 root의 분기 처리가 되었을 경우 lock 체크를 할 수 없기에
                 * 처음일 경우 mRootSlotID가 있다는 것은 leaf가 아니므로 재처리 한다 */
                if ( sFirStNodeCheck == 0 )
                {
                    if ( sRoot->mIndexSlotHeader.mRootSlotID > 0 )
                    {
                        mvpAtomicCas32_s ( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                        /* 계속 looping 인데 방어 코드가 있어야 하는거 아닌가 */
                        DBM_DBG( "First Select mRootSlotID, ix=%d, [%d] goto", ++sRepeat, sRoot->mIndexSlotHeader.mRootSlotID );

                        if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) )
                        {
                            DBM_ERR( "index first node check error index error...[%d]", sIndexCheck );
                            _THROW ( ERR_DBM_DEPTH_FAIL );
                        }

                        *aExtraKey = sExtraTmp;

                        pthread_yield_s();
                        goto repeat;
                    }
                }

                // TODO: 2014.09.29 -okt- 현웅님한테 의도 설명을 들어야함. _rc가 상위단에서 검사에 사용되고 있는데, 막으면 오류남.
                /* key value를 찾는다 */
                _rc = mSearchExistNu ( sRoot, sKey ,aTransID, aExtraKey, aRID, aCurrExtraKey );
                if ( _rc == ERR_DBM_INDEX_BETREE_RETRY )
                {
                    *aExtraKey = sExtraTmp;
                    DBM_DBG( " Btree Retry [%d]", _rc ); //TODO: 2014.09.29 -okt- 찍을거면 횟수라도 같이, 근데 찍어야해?

                    pthread_yield_s();
                    goto repeat;
                }

                _IF_THROW( _rc && _rc != -1 , ERR_DBM_KEY_NOT_EXIST );

                /* index check 증가 값 */
                sIndexCheck++;

                if ( _rc != -1 )
                {
                    _RETURN;
                }
                else
                {
                    for ( i = sDepthChkCnt - 1; i >= 0; i-- )
                    {
                        /* Index Tree Check */
                        if( mIndexHeader->mTreeCheck  == 1 )
                        {
                            pthread_yield_s ();
                            goto repeat;
                        }

                        /******************************************
                        * search key node 와 경합해야 한다
                        * leaf spin lock 처리
                        *******************************************/
                        _CALL( mLockMgr->mSpinLock( &sPositionNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        /* 2014.02.18 -shw */
                        /* 위의 lock를 사용하지 않기 위해 아래의  sIndexSlotID로 data copy 후 다시 체크했다 */
                        sIndexSlotID = mvpAtomicGet64 ( &sPositionNode->mIndexSlotHeader.mRootSlotID );
                        if ( sIndexSlotID < 0 )
                        {
                            /*********************************************
                            * leaf unlock 처리
                            *********************************************/
                            mvpAtomicCas32_s ( &sPositionNode->mIndexSlotHeader.mLock, -1, aTransID );

                            DBM_DBG( "key not found sIndexSlotID change [%d] goto", sIndexSlotID );

                            if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) )
                            {
                                DBM_ERR( "[DBM_INDEX_DEPTH_MAX] index first node check error index error....[%d]", sIndexCheck );
                                _THROW ( ERR_DBM_DEPTH_FAIL );
                            }

                            *aExtraKey = sExtraTmp;
                            pthread_yield_s( );
                            goto repeat;
                        }

                        /*********************************************
                        * leaf unlock 처리
                        *********************************************/
                        mvpAtomicCas32_s ( &sPositionNode->mIndexSlotHeader.mLock, -1, aTransID );

                        _CALL( mSegMgr->Slot2Addr ( sIndexSlotID, &sPositionNode ) );

                        /******************************************
                        * search key node 와 경합해야 한다
                        * leaf spin lock 처리
                        *******************************************/
                        _CALL( mLockMgr->mSpinLock( &sPositionNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        if ( *aExtraKey == -1 )
                        {
                            /* 0: unique index type 1: non-unique index type */
                            mBinarySearchSelectExtraLeaf ( sPositionNode->mIndexSlotHeader.mNodeCount, &sPosition, sPositionNode, sKey );
                        }
                        else
                        {
                            mBinarySearchSelectLeafNu ( sPositionNode->mIndexSlotHeader.mNodeCount, &sPosition, sPositionNode, sKey, aExtraKey );
                        }


                        if ( sPosition == 0 )
                        {
                            sKeyAddr = INDEX_POS( sPositionNode, sPosition, sKeySize );

                            if ( g_nDepthNuNodeCnt[i] != sPositionNode->mIndexSlotHeader.mNodeCount
                                    || g_nBtreeNuCnt[i] != sPositionNode->mBtreeCheck
                                    || g_nDepthNuNodePosition[i] != sPosition
                                    || mIndexCompare ( g_pKeyNuData + ( i * INDEX_KEY_LEN ), sKeyAddr, DBM_EQ ) != 1 )
                            {
                                mvpAtomicCas32_s ( &sPositionNode->mIndexSlotHeader.mLock, -1, aTransID );

                                if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) )
                                {
                                    DBM_DBG( "[DBM_INDEX_DEPTH_MAX] index node count fail index error... [%d]", sIndexCheck );
                                    _THROW ( ERR_DBM_DEPTH_FAIL );
                                }

                                DBM_DBG( "TREE Retry [%lld][%lld][%lld]", g_nBtreeNuCnt[i], sPositionNode->mBtreeCheck, *aExtraKey );
                                *aExtraKey = sExtraTmp;

                                pthread_yield_s( );
                                goto repeat;
                            }
                        }
                        else
                        {
                            sKeyAddr = INDEX_POS( sPositionNode, sPosition - 1, sKeySize );

                            if ( g_nDepthNuNodeCnt[i] != sPositionNode->mIndexSlotHeader.mNodeCount
                                    || g_nBtreeNuCnt[i] != sPositionNode->mBtreeCheck
                                    || g_nDepthNuNodePosition[i] != sPosition
                                    || mIndexCompare ( g_pKeyNuData + ( i * INDEX_KEY_LEN ), sKeyAddr, DBM_EQ ) != 1 )
                            {
                                mvpAtomicCas32_s ( &sPositionNode->mIndexSlotHeader.mLock, -1, aTransID );

                                if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) )
                                {
                                    DBM_DBG( "[DBM_INDEX_DEPTH_MAX] index node count fail index error... [%d]", sIndexCheck );
                                    _THROW ( ERR_DBM_DEPTH_FAIL );
                                }

                                // TREE Retry [2][1][16]
                                DBM_DBG( "TREE Retry [%lld][%lld][%lld]",
                                         g_nBtreeNuCnt[i], sPositionNode->mBtreeCheck, *aExtraKey );
                                *aExtraKey = sExtraTmp;

                                pthread_yield_s();
                                goto repeat;
                            }

                        }

                        g_nDepthNuNodeCnt[i] = 0;
                        g_nDepthNuNodePosition[i] = 0;
                        g_nBtreeNuCnt[i] = 0;
                        mvpAtomicCas32_s ( &sPositionNode->mIndexSlotHeader.mLock, -1, aTransID );
                    } /* for */

                    /* Index Tree Check */
                    if( mIndexHeader->mTreeCheck  == 1 )
                    {
                        pthread_yield_s ();
                        goto repeat;
                    }

                    DBM_DBG( "key not found. ExtraKey=%lld", *aExtraKey );

                    /* key Clear */
                    *aExtraKey = -1;

                    _THROW( ERR_DBM_KEY_NOT_EXIST );
                }

                break;
            }
            // mLeafcheck != 1
            else
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                _CALL( mLockMgr->mSpinLock( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                // 2014.07.10 btree check value로 변경 처리 한다.
                g_nDepthNuNodeCnt[sDepthChkCnt] = sRoot->mIndexSlotHeader.mNodeCount;
                g_nBtreeNuCnt[sDepthChkCnt] = sRoot->mBtreeCheck;

                /* 2014.02.18 -shw */
                /* 위의 lock를 사용하지 않기 위해 아래의  sIndexSlotID로 data copy 후 다시 체크했다 */
                sCount = sRoot->mIndexSlotHeader.mNodeCount;

                /* aExtraKey -1 : 검색이 처음이다. aExtraKey -1이 아니다라는 것은 : 동일 key가 있었다는 것이다 */
                if ( *aExtraKey == -1 )
                {
                    mBinarySearchSelectExtraLeaf( sCount, &sPosition, sRoot, sKey );
                }
                else
                {
                    mBinarySearchSelectLeafNu ( sCount, &sPosition, sRoot, sKey , aExtraKey);
                }

                g_nDepthNuNodePosition[sDepthChkCnt] = sPosition;

                nTmpOffset = 1;
                pBuf = g_pKeyNuData + ( sDepthChkCnt * INDEX_KEY_LEN );

                if ( sPosition == 0 )
                {
                    nTmpOffset = 0;
                }

                memcpy_s ( pBuf, INDEX_POS( sRoot, sPosition - nTmpOffset, sKeySize ), sKeySize );
                pBuf[sKeySize] = 0;

                sIndexSlotID = mvpAtomicGet64 ( &sRoot->mChild[sPosition] );
                if ( sIndexSlotID < 0 )
                {
                    mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                    DBM_DBG( "Search Leaf sIndexSlotID change [%d] goto", sIndexSlotID );

                    if ( unlikely( sNodeCheck > DBM_INDEX_DEPTH_MAX ) )
                    {
                        DBM_ERR( "[INDEX_BRANCH_ERROR] slef[%lld] mchild[%lld] position[%d]", pthread_self(), sRoot->mChild[sPosition], sPosition );
                        _THROW( ERR_DBM_DEPTH_FAIL );
                    }

                    sNodeCheck++;

                    pthread_yield_s( );
                    goto repeat;
                }

                _CALL( mSegMgr->Slot2Addr ( sIndexSlotID, &sChild ) );

                mvpAtomicCas32_s ( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );
                sRoot = sChild;
                sDepthChkCnt++;
            } /* sRoot->mIndexSlotHeader.mLeafcheck != 1 */

            /* search key check 0: 처음 1: 반복 */
            sFirStNodeCheck = 1;

            if ( unlikely( sDepthChkCnt > DBM_INDEX_DEPTH_MAX ) )
            {
                DBM_ERR("[DBM_INDEX_DEPTH_MAX] index depth max error [%d]", sDepthChkCnt);
                _THROW ( ERR_DBM_DEPTH_FAIL );
            }

        } while(1);

        DBM_DBG( "key not found ");
    }
    _CATCH
    {
        /*
         * 2014.10.01 -okt- sRoot->mIndexSlotHeader.mLock 락해제는 필요없을 것으로 보인다.
         * 1) SLOT 오류는 죽어야할 것이고
         * 2) DEPTH 오류는 각각 풀고 있는것 같고.
         */
//        switch ( _rc )
//        {
//            case ERR_DBM_SLOT2ADDR_FAIL:
//                DBM_ERR( "Slot2Addr fail, mLock=%d, tx=%d", sRoot->mIndexSlotHeader.mLock, aTransID );
//                mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );
//                break;
//
//            case ERR_DBM_LOCK_FAIL:
//                DBM_ERR( "index select leaf lock error [%d]", _rc );
//                break;
//
//            case ERR_DBM_DEPTH_FAIL:
//                mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );
//                break;
//
//            case ERR_DBM_KEY_NOT_EXIST:
//                DBM_DBG( "search exist error [%d]", _rc );
//                break;
//
//            default:
//                DBM_ERR( "non unique index search error [%d]", _rc );
//                break;
//        }

        *aExtraKey = -1;

        if ( _rc == ERR_DBM_KEY_NOT_EXIST )
        {
            _CATCH_DBG;
        }
        else
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* mSearchKeyNu */


/********************************************************************
 * ID : mSearchExistNu()
 *
 * Description(non-unique inex type)
 *   dbm Index search key Exist Check
 *   같은 키가 존재 하는지 체크 한다.
 *
 *   ExtraKey -1 이였을 때에는 Max 값을 기준으로 Extra 값을 구하여 주고
 *   ExtraKey -1 이 아니었을 경우에는 Min값을 기준으로 Extra 값을 구하여 준다.
 * Argument
 *     aNode        : input : 검색 할 NODE 포이터
 *     aKey         : input : Input Key Data
 *
********************************************************************/
int dbmIndexManager::mSearchExistNu ( dbmIndexNode* aNode , char* aKey , int aTransID , long long* aExtraKey , long long* aRID, long long* aCurrExtraKey )
{
    dbmIndexNode*   sPrevNode;
    dbmIndexNode*   sFirstNode;
    dbmIndexNode*   sFirstCheckNode;
    char    sKey[INDEX_KEY_SIZE(mIndexHeader->mIndex.mKeySize)];
    int     sCheck = 0;
    int     sKeySize;
    //int     sIsUniqueIndex = g_bIsUniqueIndex;
    int     sRC;
    int     i, j;

    _TRY
    {
        // TODO: 2014.09.29 -okt- 현웅님한테 의도 설명을 들어야함. _rc가 상위단에서 검사에 사용되고 있는데, 막으면 오류남.
        _rc = -1;

        /* 0: 값은키가 없음 */
        if ( unlikely( aNode == NULL ) )
        {
            *aExtraKey = -1;

            DBM_ERR ( "input key null data" );
            _THROW( ERR_DBM_KEY_NOT_EXIST );    /* 1060 */
        }

        /* 초기화 처리 */
        memset_s ( sKey, 0x00, sizeof( sKey ) );
        sKeySize = ( g_bIsUniqueIndex ) ? mIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( mIndexHeader->mIndex.mKeySize );


        if ( *aExtraKey != -1 )
        {
            /* ExtraKey가 있으므로 해당 ExtraKey값을 포함하여 Search 처리 한다 */
            memcpy_s ( sKey, aKey, mIndexHeader->mIndex.mKeySize );
            // remove 8 byte memcpy (성능)
            //memcpy_s(sKey+mIndexHeader->mIndex.mKeySize,aExtraKey,8);
            *(long long*) ( sKey + mIndexHeader->mIndex.mKeySize ) = *aExtraKey;
        }

        for ( i = aNode->mIndexSlotHeader.mNodeCount - 1; i >= 0; --i )
        {
            /* 최초 검색을 하였을 경우 Argument 값은 -1이다 */
            if ( *aExtraKey == -1 )
            {
                /* 중요 : column count수만큼만 비교를 하면 되기 때문에 aNodeIndexType 1인데도 1을 따로 주지는 않고
                 *        non-unique type 1을 로지 않고 0으로 주어 비교 한다 */
                g_bIsUniqueIndex = DBM_UNIQUE; // before 비교 extra 제외

                if ( dbmIdxIndexCompare ( mIndexHeader, INDEX_POS( aNode, i, sKeySize ), aKey, DBM_EQ, 0 ) != 0 )
                {
                    /* 결과값 리턴 */
                    *aRID = aNode->mRID[i];
                    /***********************************************
                     * 변경자 : wind
                     * 변경일 : 15.10.08
                     * 변경 내용 : 최초 검색에 한하여 aCurrExtraKey 값을 원한다면 현재 키의 EXTRAKEY 값을 준다.
                     ***********************************************/
                    if( aCurrExtraKey != NULL )
                    {
                        *aCurrExtraKey = *(long long*)(INDEX_POS( aNode, i, sKeySize ) + mIndexHeader->mIndex.mKeySize);
                    }

                    /* Next Value값 같은 key 값인지 체크 한다 */
                    if ( ( i - 1 ) >= 0
                            && dbmIdxIndexCompare ( mIndexHeader, INDEX_POS( aNode, i - 1, sKeySize ), aKey, DBM_EQ, 0 ) != 0 )
                    {
                        /* Next Key가 있으면 해당 해당 aExtra value 넣어서 반환한다 */
                        *aExtraKey = *(long long*) ( INDEX_POS( aNode, i - 1, sKeySize ) + mIndexHeader->mIndex.mKeySize );
                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
                    }
                    else
                    {
                        /* PrevNode에 Extra Key value가 있는지 검사 한다 */
                        if ( aNode->mIndexSlotHeader.mLeafPrevID >= 0 && i == 0 )
                        {
                            _CALL( mSegMgr->Slot2Addr ( aNode->mIndexSlotHeader.mLeafPrevID, &sPrevNode ) );

                            /*********************************************
                             * leaf unlock 처리
                             *********************************************/
                            mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );

                            /* Next leaf lock */
                            _CALL( mLockMgr->mSpinLock ( &sPrevNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                            /* 2014.08.06 -shw */
                            /* 순간적으로 Delete Tree 조정으로 인하여 mLeafPrevID 값을 가지고 찾으로 왔다가
                             * 변경 된 값을 참고 하는 경우가 발생 할 수 있다 */
                            /* 값이 있다면 NodeCount 0보다 항상 커야 하고 mLeafNextID 항상 0보다 커야 한다 */
                            if ( sPrevNode->mIndexSlotHeader.mNodeCount > 0 && aNode->mIndexSlotHeader.mLeafPrevID >= 0 )
                            {
                                /* Next Value값 같은 key 값인지 체크 한다 */
                                if ( dbmIdxIndexCompare ( mIndexHeader,
                                                          INDEX_POS( sPrevNode, sPrevNode->mIndexSlotHeader.mNodeCount - 1, sKeySize ),
                                                          aKey, DBM_EQ, 0 ) != 0 )
                                {
                                    /* Next Key가 있으면 해당 해당 aExtra value 넣어서 반환한다 */
                                    *aExtraKey = *(long long*) (
                                            INDEX_POS( sPrevNode, sPrevNode->mIndexSlotHeader.mNodeCount - 1, sKeySize )
                                            + mIndexHeader->mIndex.mKeySize );
                                }

                            }
                            else
                            {
                                DBM_DBG( "mLeafPrevID -1 value check [%lld] count[%d][%d] aExtraKey[%lld]",
                                         aNode->mIndexSlotHeader.mLeafPrevID,
                                         aNode->mIndexSlotHeader.mNodeCount,
                                         sPrevNode->mIndexSlotHeader.mNodeCount,
                                         *aExtraKey );

                                /* 2014.08.08 -shw- */
                                /* 위와 같이 next 노드의 값이 -1로 변경 하였고 해당 노드값의 변경이 이루어 졌다면
                                 * 뭔가 트리 조정이 발생 하여 값을 신뢰 할 수 없다는 것이다. 이에 해당 값을 다시한번
                                 * Retry 하는 것으로 수정을 한다 */
                                //*aExtraKey = -1;
                                mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID );

                                /* after 전으로 복귀 */
                                g_bIsUniqueIndex = DBM_NON_UNIQUE;
                                _THROW( ERR_DBM_INDEX_BETREE_RETRY );
                            }

                            mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID ); // Next leaf unlock
                        }
                        else
                        {
                            mvpAtomicCas32_s ( &aNode->mIndexSlotHeader.mLock, -1, aTransID ); // leaf unlock 처리
                        }

                    }

                    g_bIsUniqueIndex = DBM_NON_UNIQUE; // after 전으로 복귀
                    _RETURN;
                }

                g_bIsUniqueIndex = DBM_NON_UNIQUE; // after 전으로 복귀
            }
            else
            {
                /* aKey + ExtraKey value 합하여 검색 한다 */
                if ( dbmIdxIndexCompare ( mIndexHeader, INDEX_POS( aNode, i, sKeySize ), sKey, DBM_EQ, 0 ) != 0 )
                {
                    /* 위에서 Extra 값을 비교 하였기 때문에 전의 비교 값을 Extra 값을 제외한 key 값이 있는지만을 체크 하면 된다 */
                    g_bIsUniqueIndex = DBM_UNIQUE; // before 비교 extra 제외

                    /* 결과값 리턴 */
                    *aRID = aNode->mRID[i];

                    /***********************************************
                     * 변경자 : wind
                     * 변경일 : 15.10.08
                     * 변경 내용 : 최초 검색에 한하여 aCurrExtraKey 값을 원한다면 현재 키의 EXTRAKEY 값을 준다.
                     ***********************************************/
                    if( aCurrExtraKey != NULL )
                    {
                        *aCurrExtraKey = *(long long*)(INDEX_POS( aNode, i, sKeySize ) + mIndexHeader->mIndex.mKeySize);
                    }
                    /* Next Value값 같은 key 값인지 체크 한다 */
                    if ( ( i - 1 ) >= 0
                            && dbmIdxIndexCompare ( mIndexHeader, INDEX_POS( aNode, i - 1, sKeySize ), sKey, DBM_EQ, 0 ) != 0 )
                    {
                        /* Next Key가 있으면 해당 해당 aExtra value 넣어서 반환한다 */
                        *aExtraKey = *(long long*) ( INDEX_POS( aNode, i - 1, sKeySize) + mIndexHeader->mIndex.mKeySize );
                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
                    }
                    else
                    {
                        /* PrevNode에 Extra Key value가 있는지 검사 한다 */
                        if ( aNode->mIndexSlotHeader.mLeafPrevID >= 0 && i == 0 )
                        {
                            _CALL( mSegMgr->Slot2Addr ( aNode->mIndexSlotHeader.mLeafPrevID, &sPrevNode ) );

                            /*********************************************
                             * leaf unlock 처리
                             *********************************************/
                            mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );

                            /* Next leaf lock */
                            _CALL( mLockMgr->mSpinLock( &sPrevNode->mIndexSlotHeader.mLock,NULL,aTransID) );

                            /* 값이 있다면 NodeCount 0보다 항상 커야 하고 mLeafNextID 항상 0보다 커야 한다 */
                            if ( sPrevNode->mIndexSlotHeader.mNodeCount > 0 && aNode->mIndexSlotHeader.mLeafPrevID >= 0 )
                            {
                                /* Next Value값 같은 key 값인지 체크 한다 */
                                if ( dbmIdxIndexCompare ( mIndexHeader,
                                                          INDEX_POS( sPrevNode, sPrevNode->mIndexSlotHeader.mNodeCount - 1, sKeySize ),
                                                          aKey, DBM_EQ, 0 ) != 0 )
                                {
                                    /* Next Key가 있으면 해당 해당 aExtra value 넣어서 반환한다 */
                                    *aExtraKey = *(long long*) (
                                            INDEX_POS( sPrevNode, sPrevNode->mIndexSlotHeader.mNodeCount - 1, sKeySize )
                                            + mIndexHeader->mIndex.mKeySize );
                                }
                                else
                                {
                                    /* 검색을 마쳤으므로 이제 ExtraKey -1로 주어 검색하지 말라고 알려준다 */
                                    *aExtraKey = -1;
                                }

                            }
                            else
                            {
                                /* 검색을 마쳤으므로 이제 ExtraKey -1로 주어 검색하지 말라고 알려준다 */
                                DBM_DBG( "mLeafPrevID -1 value check [%lld] count[%d][%d] aExtraKey[%lld]\n",
                                         aNode->mIndexSlotHeader.mLeafPrevID,
                                         aNode->mIndexSlotHeader.mNodeCount,
                                         sPrevNode->mIndexSlotHeader.mNodeCount,
                                         *aExtraKey );
                                /* 2014.08.08 -shw- */
                                /* 위와 같이 next 노드의 값이 -1로 변경 하였고 해당 노드값의 변경이 이루어 졌다면
                                 * 뭔가 트리 조정이 발생 하여 값을 신뢰 할 수 없다는 것이다. 이에 해당 값을 다시한번
                                 * Retry 하는 것으로 수정을 한다 */
                                //*aExtraKey = -1;
                                mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID );

                                g_bIsUniqueIndex = DBM_NON_UNIQUE; // after 전으로 복귀
                                _THROW( ERR_DBM_INDEX_BETREE_RETRY );
                            }

                            /* Next leaf unlock */
                            mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID );
                        }
                        else
                        {
                            /* 검색을 마쳤으므로 이제 ExtraKey -1로 주어 검색하지 말라고 알려준다 */
                            *aExtraKey = -1;

                            /*********************************************
                            * leaf unlock 처리
                            *********************************************/
                            mvpAtomicCas32_s ( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
                        }
                    }

                    g_bIsUniqueIndex = DBM_NON_UNIQUE; // after 전으로 복귀
                    _RETURN;
                }
            }
        } /* for */

        /*********************************************
        * leaf unlock 처리
        *********************************************/
        mvpAtomicCas32_s ( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_INDEX_BETREE_RETRY )
        {
            _CATCH_ERR;
        }
    }
    _FINALLY
    _END
} /* mSearchExistNu */


__thread int*   g_nDepthNodeGtCnt = NULL;
__thread long long* g_nBtreeGtCnt = NULL;
__thread int*   g_nDepthNodeGtPosition = NULL;

/********************************************************************
 * ID : mSearchKeyGT
 *
 * Description
 *   dbm Index key select Next
 *   입력 받은 key값보다 하나 더큰값을 반환한다.
 *
 * Arguemnt
 *     aTransID : input : Transaction ID
 *     aKey     : input : 검색 처리할 key value
 *     aRID     : output: search 하여 찾은 data ID
 *     aNextKey : output: input key values의 다음 Next ID
 *
********************************************************************/
_VOID dbmIndexManager::mSearchKeyGT ( int aTransID , char* aKey , long long* aRID , int* aCount, char aNextKey[][DBM_INDEX_KEY_MAX_SIZE] , int aEQCnt )
{
    /* NODE pointer */
    dbmIndexNode*   sRoot;
    dbmIndexNode*   sCurr;
    dbmIndexNode*   sChild;

    int     sCount;
    char*   sKey;
    int     sPosition;
    int     sDepthChkCnt;
    int     sDepthNodeCnt[DBM_INDEX_DEPTH_MAX];
    int     sFirStNodeCheck;
    int     sIndexCheck;
    long long sDataSlot;
    long long sBtreeCnt;
    long long sIndexSlotID;
    int     sRC;
    int     sRC2;
    int     i;

    _TRY
    {
        sIndexCheck = 0;

        if ( g_nDepthNodeGtCnt == NULL )
        {
            g_nDepthNodeGtCnt = (int*) malloc_s ( sizeof(int) * DBM_INDEX_DEPTH_MAX );
            g_nBtreeGtCnt = (long long*) malloc_s ( sizeof(long long) * DBM_INDEX_DEPTH_MAX );
            g_nDepthNodeGtPosition = (int*) malloc_s ( sizeof(int) * DBM_INDEX_DEPTH_MAX );

            memset_s ( g_nDepthNodeGtCnt, 0, sizeof(int) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_nBtreeGtCnt, 0, sizeof(long long) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_nDepthNodeGtPosition, 0, sizeof(int) * DBM_INDEX_DEPTH_MAX );
        }

        /* 2014.06.02 -shw- non-unique index type */
        /* mSearchKeyLT unique type만 오기 때문에 global 변수인 g_nNonIndexType 값을 0으로 초기화 한다 */
        g_bIsUniqueIndex = DBM_UNIQUE;

repeat:
        /* Index Tree Check */
        if( mIndexHeader->mTreeCheck  == 1 )
        {
            pthread_yield_s ();
            goto repeat;
        }

        sChild = NULL;
        sDepthChkCnt = 0;
        sFirStNodeCheck = 0;
        memset_s ( sDepthNodeCnt, 0, sizeof( sDepthNodeCnt ) );

        g_nDepthNodeGtCnt[0] = 0;
        g_nBtreeGtCnt[0] = 0;
        g_nDepthNodeGtPosition[0] = 0;

        _CALL( mSegMgr->Slot2Addr ( mIndexHeader->mRootPid, &sRoot ) );
        sKey = aKey;

        sIndexCheck++;

        /*************************************************
        * data null check
        *************************************************/
        if ( unlikely( sRoot->mIndexSlotHeader.mNodeCount <= 0 && sRoot->mChild[0] < 0 ) )
        {
            DBM_TRC( "Index Root data not found. [%lld][%lld]", sRoot->mChild[0], sRoot->mChild[1] );
            _THROW( ERR_DBM_KEY_NOT_EXIST );
        }

        do
        {
            /* root 아래에 leaf 분기 되면 자식 노드는 0 부터 분기 된다 2:root 0:left leaf 1:right leaf */
            if ( sRoot->mIndexSlotHeader.mLeafcheck == 1 )
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                /******************************************
                 * search key node 와 경합해야 한다
                 * leaf spin lock 처리
                 *******************************************/
                _CALL( mLockMgr->mSpinLock ( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                /* 제일 처음일때 root의 분기 처리가 되었을 경우 lock 체크를 할 수 없기에
                 * 처음일 경우 mRootSlotID가 있다는 것은 leaf가 아니므로 재처리 한다 */
                if ( sFirStNodeCheck == 0 )
                {
                    if ( sRoot->mIndexSlotHeader.mRootSlotID > 0 )
                    {
                        /* undo process */
                        mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                        /* 계속 looping 인데 방어 코드가 있어야 하는거 아닌가 */
                        DBM_DBG( "First Select mRootSlotID [%d] goto", sRoot->mIndexSlotHeader.mRootSlotID );
                        pthread_yield_d ( );    //TODO: 2014.09.29 -okt- 넣을까 말까? "_d"는 안 넣은거다.
                        goto repeat;
                    }
                }
                /* undo process */
                mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                /* 입력된 키값보다 하나 더큰 값을 return 한다 */
                //sRC = mSearchNextGT ( sRoot, sKey, &sDataSlot, aTransID, &aNextKey, aEQCnt );

                // by lim272. 2015-01-15
                // aRID는 Array다. 여기에 aCount만큼 아예 TableSlot정보를 싹 가져온다.
                // 이때 가져올수 있는거는 겨우 DBM_INDEX_DEGREE만큼이고
                // 재수없으면 1건만 가져올수 있다. (하필 Node내의 맨 끝이라면...)
                sRC = mSearchNextGT ( sRoot, sKey, aRID, aCount, aTransID, aNextKey, aEQCnt );
                _IF_THROW( sRC && sRC != ERR_DBM_KEY_NOT_EXIST, ERR_DBM_SLOT2ADDR_FAIL ); //INDEX_NEXTKEY_ERROR );

                /* search한 결과갑을 알려준다 */
                //*aRID = sDataSlot;

                // 2014.09.29 -okt- 여기까지 오면 mSearchNextGT 성공이거나, ERR_DBM_KEY_NOT_EXIST 이다.
                if ( sRC == RC_SUCCESS )
                {
                    //DBM_DBG( "aKey[%s] aNextKey[%s] ", aKey,aNextKey);
                    _RETURN;
                }
                else // if ( sRC == ERR_DBM_KEY_NOT_EXIST )
                {
                    for ( i = sDepthChkCnt - 1; i >= 0; i-- )
                    {
                        /******************************************
                        * search key node 와 경합해야 한다
                        * leaf spin lock 처리
                        *******************************************/
                        _CALL( mLockMgr->mSpinLock( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        sIndexSlotID = mvpAtomicGet64 (&sRoot->mIndexSlotHeader.mRootSlotID );
                        if ( sIndexSlotID < 0 )
                        {
                            mvpAtomicCas32_s ( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                            DBM_DBG( "key not found sIndexSlotID change [%d] retry ", sIndexSlotID );
                            pthread_yield_s( );
                            goto repeat;
                        }

                        /*********************************************
                        * leaf unlock 처리
                        *********************************************/
                        mvpAtomicCas32_s ( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                        _CALL( mSegMgr->Slot2Addr(sIndexSlotID, &sCurr) );
                        sRoot = sCurr;

                        /******************************************
                        * search key node 와 경합해야 한다
                        * leaf spin lock 처리
                        *******************************************/
                        _CALL( mLockMgr->mSpinLock( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        mBinarySearchSelectLeaf ( sCurr->mIndexSlotHeader.mNodeCount, &sPosition, sCurr, sKey );

                        if ( g_nDepthNodeGtCnt[i] != sCurr->mIndexSlotHeader.mNodeCount
                                || g_nBtreeGtCnt[i] != sCurr->mBtreeCheck
                                || g_nDepthNodeGtPosition[i] != sPosition )
                        {
                            mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
                            /* 계속 looping 인데 방어 코드가 있어야 하는거 아닌가 */
                            DBM_DBG( "sBtreeCnt [%lld][%lld]  mNodeCount goto [%d][%d] ",
                                     g_nBtreeGtCnt[i],
                                     sCurr->mBtreeCheck,
                                     g_nDepthNodeGtCnt[i],
                                     sCurr->mIndexSlotHeader.mNodeCount );

                            if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR2 );
                            {
                                DBM_ERR( "index depth max error [%d]", sIndexCheck );
                                _THROW( ERR_DBM_DEPTH_FAIL );
                            }

                            goto repeat;
                        }

                        g_nDepthNodeGtCnt[i] = 0;
                        g_nBtreeGtCnt[i] = 0;
                        g_nDepthNodeGtPosition[i] = 0;

                        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
                    } /* for */

                    /* Index Tree Check */
                    if( mIndexHeader->mTreeCheck  == 1 )
                    {
                        pthread_yield_s ();
                        goto repeat;
                    }

                    _THROW( ERR_DBM_KEY_NOT_EXIST );

                    break;
                }

                _DASSERT( 0 );  // 2014.09.29 -okt- 도달하지 않을 것 같다. 확인하자.
                break;
            }
            else
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                /* Search GT Lock Try */
                _CALL( mLockMgr->mSpinLock( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                sDepthNodeCnt[sDepthChkCnt] = sRoot->mIndexSlotHeader.mNodeCount;

                // 2014.07.10 btree check value로 변경 처리 한다.
                g_nDepthNodeGtCnt[sDepthChkCnt] = sRoot->mIndexSlotHeader.mNodeCount;
                g_nBtreeGtCnt[sDepthChkCnt] = sRoot->mBtreeCheck;

                sCount = sRoot->mIndexSlotHeader.mNodeCount;

                mBinarySearchSelectLeaf ( sCount, &sPosition, sRoot, sKey );

                g_nDepthNodeGtPosition[sDepthChkCnt] = sPosition;

                /* sRoot->mChild -1 이라는 것은 internal 분기가 되었다는 것을 의미한다
                 * 그렇기 때문에 새로 처음부터 검색을 해야 한다 */
                if ( sRoot->mChild[sPosition] == -1 )
                {

                    mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                    DBM_DBG( "slef[%lld] mchild[%lld] position[%d]", pthread_self(), sRoot->mChild[sPosition], sPosition );

                    if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR3 );
                    {
                        DBM_ERR( "index depth max error [%d]", sIndexCheck );
                        _THROW( ERR_DBM_DEPTH_FAIL );
                    }

                    goto repeat;
                }

                _CALL( mSegMgr->Slot2Addr ( sRoot->mChild[sPosition], &sChild ) );

                mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );
                sRoot = sChild;
                sDepthChkCnt++;
            }

            /* search key check 0: 처음 1: 반복 */
            sFirStNodeCheck = 1;

            if ( unlikely( sDepthChkCnt > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR );
            {
                DBM_ERR( "index depth max error [%d]", sDepthChkCnt );

#if 0 // 2014.03.19 -shw- lock 제거로 인하여 주석으로 막음.
                /*********************************************
                 * leaf unlock 처리
                 *********************************************/
                mvpAtomicCas32_s(&sRoot->mIndexSlotHeader.mLock, -1, aTransID);
#endif
                _THROW( ERR_DBM_DEPTH_FAIL );
            }
        } while ( 1 );

        //DBM_DBG( "key not found ");
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_KEY_NOT_EXIST )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mSearchKeyGT */


__thread int*   g_nDepthNodeGtNuCnt = NULL;
__thread long long*  g_nBtreeGtNuCnt = NULL;
__thread int*   g_nDepthNodeNuGtPosition = NULL;

/********************************************************************
 * ID : mSearchKeyNuGT
 *
 * Description(non-unique index type)
 *   dbm Index key select Next
 *   입력 받은 key값보다 하나 더큰값을 반환한다.
 *
 * Arguemnt
 *     aTransID : input : Transaction ID
 *     aKey     : input : 검색 처리할 key value
 *     aRID     : output: search 하여 찾은 data ID
 *     aNextKey : output: input key values의 다음 Next ID
 *
********************************************************************/
_VOID dbmIndexManager::mSearchKeyGTNu( int aTransID, char* aKey, long long* aRID,char* aNextKey,long long* aExtraKey, int aEQCnt )
{
    /* NODE pointer */
    dbmIndexNode*   sRoot;
    dbmIndexNode*   sCurr;
    dbmIndexNode*   sChild;

    int     sCount;
    char*   sKey;
    int     sPosition;
    int     sDepthChkCnt;
    int     sDepthNodeCnt[DBM_INDEX_DEPTH_MAX];
    int     sFirStNodeCheck;
    int     sIndexCheck;
    long long sDataSlot;
    long long sBtreeCnt;
    long long sIndexSlotID;
    long long sExtraTmp;
    int     sRC;
    int     sRC2;
    int     i;

    _TRY
    {
        sExtraTmp = *aExtraKey;
        sIndexCheck = 0;

        /* non-unique index type set */
        g_bIsUniqueIndex = DBM_NON_UNIQUE;

        if ( g_nDepthNodeGtNuCnt == NULL )
        {
            g_nDepthNodeGtNuCnt = (int*) malloc_s ( sizeof(int) * DBM_INDEX_DEPTH_MAX );
            g_nBtreeGtNuCnt = (long long*) malloc_s ( sizeof(long long) * DBM_INDEX_DEPTH_MAX );
            g_nDepthNodeNuGtPosition = (int*) malloc_s ( sizeof(int) * DBM_INDEX_DEPTH_MAX );

            memset_s ( g_nDepthNodeGtNuCnt, 0, sizeof(int) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_nBtreeGtNuCnt, 0, sizeof(long long) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_nDepthNodeNuGtPosition, 0, sizeof(int) * DBM_INDEX_DEPTH_MAX );
        }

repeat:
        /* Index Tree Check */
        if( mIndexHeader->mTreeCheck  == 1 )
        {
            pthread_yield_s ();
            goto repeat;
        }

        sChild = NULL;
        sDepthChkCnt = 0;
        sFirStNodeCheck = 0;
        memset_s ( sDepthNodeCnt, 0, sizeof( sDepthNodeCnt ) );

        g_nDepthNodeGtNuCnt[0] = 0;
        g_nBtreeGtNuCnt[0] = 0;
        g_nDepthNodeNuGtPosition[0] = 0;

        _CALL( mSegMgr->Slot2Addr ( mIndexHeader->mRootPid, &sRoot ) );
        sKey = aKey;

        sIndexCheck++;

        /*************************************************
        * data null check
        *************************************************/
        if ( sRoot->mIndexSlotHeader.mNodeCount <= 0 && sRoot->mChild[0] < 0 )
        {
            DBM_TRC( "data not found !!!! mNodeCount=[%d] mChild=[%lld][%lld]",
                     sRoot->mIndexSlotHeader.mNodeCount, sRoot->mChild[0], sRoot->mChild[1] );
            _THROW( ERR_DBM_KEY_NOT_EXIST );
        }

        do
        {
            /* root 아래에 leaf 분기 되면 자식 노드는 0 부터 분기 된다 2:root 0:left leaf 1:right leaf */
            if ( sRoot->mIndexSlotHeader.mLeafcheck == 1 )
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                /******************************************
                 * search key node 와 경합해야 한다
                 * leaf spin lock 처리
                 *******************************************/
                _CALL( mLockMgr->mSpinLock ( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                /* 제일 처음일때 root의 분기 처리가 되었을 경우 lock 체크를 할 수 없기에
                 * 처음일 경우 mRootSlotID가 있다는 것은 leaf가 아니므로 재처리 한다 */
                if ( sFirStNodeCheck == 0 )
                {
                    if ( sRoot->mIndexSlotHeader.mRootSlotID > 0 )
                    {
                        mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                        /* 계속 looping 인데 방어 코드가 있어야 하는거 아닌가 */
                        DBM_DBG( "First Select mRootSlotID [%d] goto", sRoot->mIndexSlotHeader.mRootSlotID );
                        *aExtraKey = sExtraTmp;
                        pthread_yield_d ( );    //TOOD (OKT):
                        goto repeat;
                    }
                }

                /* unlock process */
                mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                if ( *aExtraKey == -1 )
                {
                    /* non-unique index type set */
                    g_bIsUniqueIndex = DBM_UNIQUE;

                    /* 입력된 키값보다 하나 더큰 값을 return 한다 */
                    sRC = mSearchNextGTNu ( sRoot, sKey, &sDataSlot, aTransID, &aNextKey, aExtraKey, aEQCnt );
                    g_bIsUniqueIndex = DBM_NON_UNIQUE;
                }
                else
                {
                    /* 입력된 키값보다 하나 더큰 값을 return 한다 */
                    sRC = mSearchNextExtraGT ( sRoot, sKey, &sDataSlot, aTransID, &aNextKey, aExtraKey, aEQCnt );
                }
                _IF_THROW( sRC && sRC != ERR_DBM_KEY_NOT_EXIST, sRC ); // INDEX_NEXTKEY_ERROR );

                /* search한 결과갑을 알려준다 */
                *aRID = sDataSlot;

                // 2014.09.29 -okt- 여기까지 오면 성공이거나, ERR_DBM_KEY_NOT_EXIST 이다.
                if ( sRC == RC_SUCCESS )
                {
                    _RETURN;
                }
                else // if ( sRC == ERR_DBM_KEY_NOT_EXIST )
                {
                    for ( i = sDepthChkCnt - 1; i >= 0; i-- )
                    {
                        /******************************************
                         * search key node 와 경합해야 한다
                         * leaf spin lock 처리
                         *******************************************/
                        _CALL( mLockMgr->mSpinLock( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        sIndexSlotID = mvpAtomicGet64 ( &sRoot->mIndexSlotHeader.mRootSlotID );
                        if ( sIndexSlotID < 0 )
                        {
                            mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                            DBM_DBG( "key not found sIndexSlotID change [%d] retry ", sIndexSlotID );
                            *aExtraKey = sExtraTmp;
                            pthread_yield_s( );
                            goto repeat;
                        }

                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                        _CALL( mSegMgr->Slot2Addr ( sIndexSlotID, &sCurr ) );
                        sRoot = sCurr;

                        /******************************************
                         * search key node 와 경합해야 한다
                         * leaf spin lock 처리
                         *******************************************/
                        _CALL( mLockMgr->mSpinLock ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        if ( *aExtraKey == -1 )
                        {
                            mBinarySearchSelectExtraLeaf ( sCurr->mIndexSlotHeader.mNodeCount, &sPosition, sCurr, sKey );
                        }
                        else
                        {
                            mBinarySearchSelectLeafNu ( sCurr->mIndexSlotHeader.mNodeCount, &sPosition, sCurr, sKey, aExtraKey );
                        }

                        if ( g_nDepthNodeGtNuCnt[i] != sCurr->mIndexSlotHeader.mNodeCount
                                || g_nBtreeGtNuCnt[i] != sCurr->mBtreeCheck
                                || g_nDepthNodeNuGtPosition[i] != sPosition )
                        {
                            mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

                            /* 계속 looping 인데 방어 코드가 있어야 하는거 아닌가 */
                            DBM_DBG( "i[%d] : [%d][%d] sBtreeCnt retry [%lld][%lld]  mNodeCount goto [%d][%d] ",
                                     i,
                                     g_nBtreeGtNuCnt[i],
                                     sCurr->mBtreeCheck,
                                     g_nDepthNodeGtNuCnt[i],
                                     sCurr->mIndexSlotHeader.mNodeCount );

                            if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR2 );
                            {
                                DBM_ERR( "index depth max error [%d]", sIndexCheck );
                                _THROW( ERR_DBM_DEPTH_FAIL );
                            }

                            *aExtraKey = sExtraTmp;
                            pthread_yield_s( );
                            goto repeat;
                        }

                        g_nDepthNodeGtNuCnt[i] = 0;
                        g_nBtreeGtNuCnt[i] = 0;
                        g_nDepthNodeNuGtPosition[i] = 0;

                        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
                    } /* for */

                    /* Index Tree Check */
                    if( mIndexHeader->mTreeCheck  == 1 )
                    {
                        pthread_yield_s ();
                        goto repeat;
                    }

                    DBM_DBG( "key not found ");
                    _THROW( ERR_DBM_KEY_NOT_EXIST );

                    break;
                }

                _DASSERT( 0 );  // 2014.09.29 -okt- 도달하지 않을 것 같다. 확인하자.
                break;
            }
            // if ( sRoot->mIndexSlotHeader.mLeafcheck != 1 )
            else
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                /* Search GT Lock Try */
                _CALL( mLockMgr->mSpinLock( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                // 2014.07.10 btree check value로 변경 처리 한다.
                g_nDepthNodeGtNuCnt[sDepthChkCnt] = sRoot->mIndexSlotHeader.mNodeCount;
                g_nBtreeGtNuCnt[sDepthChkCnt] = sRoot->mBtreeCheck;

                sCount = sRoot->mIndexSlotHeader.mNodeCount;

                /* aExtraKey -1 : 검색이 처음이다. aExtraKey -1이 아니다라는 것은 : 동일 key가 있었다는 것이다 */
                if ( *aExtraKey == -1 )
                {
                    mBinarySearchSelectExtraLeaf ( sCount, &sPosition, sRoot, sKey );
                }
                else
                {
                    mBinarySearchSelectLeafNu ( sCount, &sPosition, sRoot, sKey, aExtraKey );
                }

                g_nDepthNodeNuGtPosition[sDepthChkCnt] = sPosition;

                /* sRoot->mChild -1 이라는 것은 internal 분기가 되었다는 것을 의미한다
                 * 그렇기 때문에 새로 처음부터 검색을 해야 한다 */
                if ( sRoot->mChild[sPosition] == -1 )
                {
                    mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                    DBM_DBG( "slef[%lld] mchild[%lld] position[%d]", pthread_self(), sRoot->mChild[sPosition], sPosition );

                    if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR3 );
                    {
                        DBM_ERR( "index depth max error [%d]", sIndexCheck );
                        _THROW( ERR_DBM_DEPTH_FAIL );
                    }

                    goto repeat;
                }

                _CALL( mSegMgr->Slot2Addr ( sRoot->mChild[sPosition], &sChild ) );

                mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );
                sRoot = sChild;
                sDepthChkCnt++;
            }

            /* search key check 0: 처음 1: 반복 */
            sFirStNodeCheck = 1;

            if ( unlikely( sDepthChkCnt > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR );
            {
                DBM_ERR( "index depth max error [%d]", sDepthChkCnt );
                _THROW( ERR_DBM_DEPTH_FAIL );
            }
        } while(1);
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_KEY_NOT_EXIST )
        {
            _CATCH_WARN;

            *aExtraKey = -1;
        }
    }
    _FINALLY
    _END
} /* mSearchKeyGTNu */


__thread int*   g_nDepthNodeLtCnt = NULL;
__thread long long*  g_nBtreeLtCnt = NULL;
__thread int*   g_nDepthNodeLtPosition = NULL;
/********************************************************************
 * ID : mSearchKeyLT
 *
 * Description
 *   dbm Index key select Prev
 *   입력 받은 key값 보다 하나더 작은 key값을 반환한다.
 *
 * Argument
 *     aTransID : input : Transaction ID
 *     aKey     : input : input data key value
 *     aRID     : output: key value 보다 하나 더작은 data ID
 *     aPrevKey : output: key value 보다 하나 더 작은 key value
 *
********************************************************************/
_VOID dbmIndexManager::mSearchKeyLT ( int aTransID , char* aKey , long long* aRID , int* aCount, char aPrevKey[][DBM_INDEX_KEY_MAX_SIZE] , int aEQCnt )
{
    /* NODE pointer */
    dbmIndexNode*   sRoot;
    dbmIndexNode*   sCurr;
    dbmIndexNode*   sChild;

    int     sCount;
    char*   sKey;
    int     sPosition;
    int     sDepthChkCnt;
    int     sDepthNodeCnt[DBM_INDEX_DEPTH_MAX];
    int     sFirStNodeCheck;
    long long sDataSlot;
    int     sIndexCheck;
    long long sBtreeCnt;
    long long sIndexSlotID;
    int     sRC;
    int     sRC2;
    int     i;

    _TRY
    {
        sIndexCheck = 0;

        /* 2014.06.02 -shw- non-unique index type */
        /* mSearchKeyLT unique type만 오기 때문에 global 변수인 g_nNonIndexType 값을 0으로 초기화 한다 */
        g_bIsUniqueIndex = DBM_UNIQUE;

        if ( g_nDepthNodeLtCnt == NULL )
        {
            g_nDepthNodeLtCnt = (int*) malloc_s ( sizeof(int) * DBM_INDEX_DEPTH_MAX );
            g_nBtreeLtCnt = (long long*) malloc_s ( sizeof(long long) * DBM_INDEX_DEPTH_MAX );
            g_nDepthNodeLtPosition = (int*) malloc_s ( sizeof(int) * DBM_INDEX_DEPTH_MAX );

            memset_s ( g_nDepthNodeLtCnt, 0, sizeof(int) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_nBtreeLtCnt, 0, sizeof(long long) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_nDepthNodeLtPosition, 0, sizeof(int) * DBM_INDEX_DEPTH_MAX );
        }

repeat:
        /* Index Tree Check */
        if( mIndexHeader->mTreeCheck  == 1 )
        {
            pthread_yield_s ();
            goto repeat;
        }

        sChild = NULL;
        sDepthChkCnt = 0;
        sFirStNodeCheck = 0;
        memset_s ( sDepthNodeCnt, 0, sizeof( sDepthNodeCnt ) );

        g_nDepthNodeLtCnt[0] = 0;
        g_nBtreeLtCnt[0] = 0;
        g_nDepthNodeLtPosition[0] = 0;

        _CALL( mSegMgr->Slot2Addr ( mIndexHeader->mRootPid, &sRoot ) );
        sKey = aKey;

#ifdef INDEX_TEST
        DBM_DBG( "***** mSearchKey start ***** ");
        DBM_DBG( "mSEarchKey input [%lld] child[%lld] key[%d]", mIndexHeader->mRootPid, sRoot->mChild[0],*(int*)sKey);
        PrintNodeElement2((dbmIndexNode*)sSlotAddr);

        _PRT(" search start !!!!!!!!!! \n");
        PrintNodeElement2((dbmIndexNode*)sSlotAddr);
        _PRT(" search end !!!!!!!!!! \n");
#endif

        /*************************************************
        * data null check
        *************************************************/
        if ( sRoot->mIndexSlotHeader.mNodeCount <= 0 && sRoot->mChild[0] < 0 )
        {
            DBM_DBG( "data not found !!!! [%lld][%lld]", sRoot->mChild[0], sRoot->mChild[1] );
            _THROW( ERR_DBM_KEY_NOT_EXIST );
        }

        sIndexCheck++;

        do
        {
            /* root 아래에 leaf 분기 되면 자식 노드는 0 부터 분기 된다 2:root 0:left leaf 1:right leaf */
            if ( sRoot->mIndexSlotHeader.mLeafcheck == 1 )
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                /******************************************
                 * search key node 와 경합해야 한다
                 * leaf spin lock 처리
                 *******************************************/
                _CALL( mLockMgr->mSpinLock ( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                /* 제일 처음일때 root의 분기 처리가 되었을 경우 lock 체크를 할 수 없기에
                 * 처음일 경우 mRootSlotID가 있다는 것은 leaf가 아니므로 재처리 한다 */
                if ( sFirStNodeCheck == 0 )
                {
                    if ( sRoot->mIndexSlotHeader.mRootSlotID > 0 )
                    {
                        /* undo process */
                        mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                        /* 계속 looping 인데 방어 코드가 있어야 하는거 아닌가 */
                        DBM_DBG( "First Select mRootSlotID [%d] goto", sRoot->mIndexSlotHeader.mRootSlotID );
                        goto repeat;
                    }
                }

                /* undo process */
                mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                /* 입력된 키값보다 하나 더작은 값을 return 한다 */
                //sRC = mSearchNextLT ( sRoot, sKey, &sDataSlot, aTransID, &aPrevKey, aEQCnt );

                // aRID는 Array다. 여기에 aCount만큼 아예 TableSlot정보를 싹 가져온다.
                // 이때 가져올수 있는거는 겨우 DBM_INDEX_DEGREE만큼이고
                // 재수없으면 1건만 가져올수 있다. (하필 Node내의 맨 끝이라면...)
                sRC = mSearchNextLT ( sRoot, sKey, aRID, aCount, aTransID, aPrevKey, aEQCnt );
                _IF_THROW( sRC && sRC != ERR_DBM_KEY_NOT_EXIST, sRC ); //, INDEX_PREVKEY_ERROR );

                /* search한 결과갑을 알려준다 */
                //*aRID = sDataSlot;

                // 2014.09.29 -okt- 여기까지 오면 성공이거나, ERR_DBM_KEY_NOT_EXIST 이다.
                if ( sRC == RC_SUCCESS )
                {
                    _RETURN;
                }
                else // if ( sRC == ERR_DBM_KEY_NOT_EXIST )
                {
                    for ( i = sDepthChkCnt - 1; i >= 0; i-- )
                    {
                        /******************************************
                         * search key node 와 경합해야 한다
                         * leaf spin lock 처리
                         *******************************************/
                        _CALL( mLockMgr->mSpinLock ( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        sIndexSlotID = sRoot->mIndexSlotHeader.mRootSlotID;

                        if ( sIndexSlotID < 0 )
                        {
                            mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                            DBM_DBG( "key not found sIndexSlotID change [%d] retry ", sIndexSlotID );
                            pthread_yield_s( );
                            goto repeat;
                        }

                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                        _CALL( mSegMgr->Slot2Addr ( sIndexSlotID, &sCurr ) );
                        sRoot = sCurr;

                        /******************************************
                         * search key node 와 경합해야 한다
                         * leaf spin lock 처리
                         *******************************************/
                        _CALL( mLockMgr->mSpinLock ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        mBinarySearchSelectLeaf ( sCurr->mIndexSlotHeader.mNodeCount, &sPosition, sCurr, sKey );

                        if ( g_nDepthNodeLtCnt[i] != sCurr->mIndexSlotHeader.mNodeCount
                                || g_nBtreeLtCnt[i] != sCurr->mBtreeCheck
                                || g_nDepthNodeLtPosition[i] != sPosition )
                        {
                            mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

                            /* 계속 looping 인데 방어 코드가 있어야 하는거 아닌가 */
                            DBM_DBG( "selectsBtreeCnt [%lld][%lld] [%d][%d]",
                                     g_nBtreeLtCnt[i],
                                     sCurr->mBtreeCheck,
                                     g_nDepthNodeLtCnt[i],
                                     sCurr->mIndexSlotHeader.mNodeCount );

                            if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR2 );
                            {
                                DBM_ERR( "index depth max error [%d]", sIndexCheck );
                                _THROW( ERR_DBM_DEPTH_FAIL );
                            }

                            pthread_yield_s( ); // 2014.09.29 -okt- 추가
                            goto repeat;
                        }

                        g_nDepthNodeLtCnt[i] = 0;
                        g_nBtreeLtCnt[i] = 0;
                        g_nDepthNodeLtPosition[i] = 0;

                        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
                    } /* for */

                    /* Index Tree Check */
                    if( mIndexHeader->mTreeCheck  == 1 )
                    {
                        pthread_yield_s ();
                        goto repeat;
                    }

                    DBM_DBG( "key not found" );
                    _THROW( ERR_DBM_KEY_NOT_EXIST );

                    break;
                }

                _DASSERT( 0 );  // 2014.09.29 -okt- 도달하지 않을 것 같다. 확인하자.
                break;
            }
            else
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                /* serach LT Lock Try */
                _CALL( mLockMgr->mSpinLock ( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                sDepthNodeCnt[sDepthChkCnt] = sRoot->mIndexSlotHeader.mNodeCount;

                // 2014.07.10 btree check value로 변경 처리 한다.
                g_nDepthNodeLtCnt[sDepthChkCnt] = sRoot->mIndexSlotHeader.mNodeCount;
                g_nBtreeLtCnt[sDepthChkCnt] = sRoot->mBtreeCheck;

                sCount = sRoot->mIndexSlotHeader.mNodeCount;

                mBinarySearchSelectLeaf ( sCount, &sPosition, sRoot, sKey );

                g_nDepthNodeLtPosition[sDepthChkCnt] = sPosition;

                /* sRoot->mChild -1 이라는 것은 internal 분기가 되었다는 것을 의미한다
                 * 그렇기 때문에 새로 처음부터 검색을 해야 한다 */
                if ( sRoot->mChild[sPosition] == -1 )
                {
                    mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                    DBM_DBG( "slef[%lld] mchild[%lld] position[%d]", pthread_self(), sRoot->mChild[sPosition], sPosition );

                    if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR3 );
                    {
                        DBM_ERR( "index depth max error [%d]", sIndexCheck );
                        _THROW( ERR_DBM_DEPTH_FAIL );
                    }

                    goto repeat;
                }

                _CALL( mSegMgr->Slot2Addr ( sRoot->mChild[sPosition], &sChild ) );

                mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );
                sRoot = sChild;
                sDepthChkCnt++;
            }

            /* search key check 0: 처음 1: 반복 */
            sFirStNodeCheck = 1;

            if ( unlikely( sDepthChkCnt > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR );
            {
                DBM_ERR( "index depth max error [%d]", sDepthChkCnt );
#if 0 // 2014.03.19 -shw-
                /*********************************************
                 * leaf unlock 처리
                 *********************************************/
                mvpAtomicCas32_s(&sRoot->mIndexSlotHeader.mLock, -1, aTransID);
#endif

                _THROW( ERR_DBM_DEPTH_FAIL );
            }
        } while ( 1 );
    }
    _CATCH
    {
        if ( _rc == ERR_DBM_KEY_NOT_EXIST )
        {
            _CATCH_DBG;
        }
        else
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
} /* mSearchKeyLT */


__thread int*   g_nDepthNodeLtNuCnt = NULL;
__thread long long* g_nBtreeLtNuCnt = NULL;
__thread int*   g_nDepthNodeNuLtPosition = NULL;

/********************************************************************
 * ID : mSearchKeyLTNu
 *
 * Description(non-unique index type)
 *   dbm Index key select Prev
 *   입력 받은 key값 보다 하나더 작은 key값을 반환한다.
 *
 * Argument
 *     aTransID : input : Transaction ID
 *     aKey     : input : input data key value
 *     aRID     : output: key value 보다 하나 더작은 data ID
 *     aPrevKey : output: key value 보다 하나 더 작은 key value
 *
********************************************************************/
_VOID dbmIndexManager::mSearchKeyLTNu ( int aTransID , char* aKey , long long* aRID , char* aPrevKey , long long* aExtraKey , int aEQCnt )
{
    /* NODE pointer */
    dbmIndexNode*   sRoot;
    dbmIndexNode*   sCurr;
    dbmIndexNode*   sChild;

    int     sCount;
    char*   sKey;
    int     sPosition;
    int     sDepthChkCnt;
    int     sDepthNodeCnt[DBM_INDEX_DEPTH_MAX];
    int     sFirStNodeCheck;
    long long sDataSlot;
    int     sIndexCheck;
    long long sBtreeCnt;
    long long sIndexSlotID;
    long long sExtraTmp;
    int     sRC;
    int     sRC2;
    int     i;

    _TRY
    {
        sIndexCheck = 0;
        sExtraTmp = *aExtraKey;

        /* non-unique index type set */
        g_bIsUniqueIndex = DBM_NON_UNIQUE;

        if ( g_nDepthNodeLtNuCnt == NULL )
        {
            g_nDepthNodeLtNuCnt = (int*) malloc_s ( sizeof(int) * DBM_INDEX_DEPTH_MAX );
            g_nBtreeLtNuCnt = (long long*) malloc_s ( sizeof(long long) * DBM_INDEX_DEPTH_MAX );
            g_nDepthNodeNuLtPosition = (int*) malloc_s ( sizeof(int) * DBM_INDEX_DEPTH_MAX );

            memset_s ( g_nDepthNodeLtNuCnt, 0, sizeof(int) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_nBtreeLtNuCnt, 0, sizeof(long long) * DBM_INDEX_DEPTH_MAX );
            memset_s ( g_nDepthNodeNuLtPosition, 0, sizeof(int) * DBM_INDEX_DEPTH_MAX );
        }

repeat:
        /* Index Tree Check */
        if( mIndexHeader->mTreeCheck  == 1 )
        {
            pthread_yield_s ();
            goto repeat;
        }

        sChild = NULL;
        sDepthChkCnt = 0;
        sFirStNodeCheck = 0;
        memset_s ( sDepthNodeCnt, 0, sizeof( sDepthNodeCnt ) );

        g_nDepthNodeLtNuCnt[0] = 0;
        g_nBtreeLtNuCnt[0] = 0;
        g_nDepthNodeNuLtPosition[0] = 0;

        _CALL( mSegMgr->Slot2Addr ( mIndexHeader->mRootPid, &sRoot ) );
        sKey = aKey;

#ifdef INDEX_TEST
        PrintNodeElement3Lib((dbmIndexNode*)sSlotAddr,mIndexHeader,mSegMgr);
#endif

        /*************************************************
         * data null check
         *************************************************/
        if ( sRoot->mIndexSlotHeader.mNodeCount <= 0 && sRoot->mChild[0] < 0 )
        {
            DBM_CERR( "data not found !!!! [%lld][%lld]", sRoot->mChild[0], sRoot->mChild[1] );
            _THROW( ERR_DBM_KEY_NOT_EXIST );
        }

        sIndexCheck++;

        do
        {
            /* root 아래에 leaf 분기 되면 자식 노드는 0 부터 분기 된다 2:root 0:left leaf 1:right leaf */
            if ( sRoot->mIndexSlotHeader.mLeafcheck == 1 )
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                /******************************************
                 * search key node 와 경합해야 한다
                 * leaf spin lock 처리
                 *******************************************/
                _CALL( mLockMgr->mSpinLock ( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                /* 제일 처음일때 root의 분기 처리가 되었을 경우 lock 체크를 할 수 없기에
                 * 처음일 경우 mRootSlotID가 있다는 것은 leaf가 아니므로 재처리 한다 */
                if ( sFirStNodeCheck == 0 )
                {
                    if ( sRoot->mIndexSlotHeader.mRootSlotID > 0 )
                    {
                        mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                        /* 계속 looping 인데 방어 코드가 있어야 하는거 아닌가 */
                        DBM_DBG( "First Select mRootSlotID [%d]  goto", sRoot->mIndexSlotHeader.mRootSlotID );
                        *aExtraKey = sExtraTmp;
                        goto repeat;
                    }
                }

                /* unlock process */
                mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                if ( *aExtraKey == -1 )
                {
                    /* non-unique index type set */
                    g_bIsUniqueIndex = DBM_UNIQUE;

                    /* 입력된 키값보다 하나 더작은 값을 return 한다 */
                    sRC = mSearchNextLTNu ( sRoot, sKey, &sDataSlot, aTransID, &aPrevKey, aExtraKey, aEQCnt );
                    g_bIsUniqueIndex = DBM_NON_UNIQUE;
                }
                else
                {
                    /* 입력된 키값보다 하나 더작은 값을 return 한다 */
                    sRC = mSearchNextExtraLT ( sRoot, sKey, &sDataSlot, aTransID, &aPrevKey, aExtraKey, aEQCnt );
                }
                _IF_THROW( sRC && sRC != ERR_DBM_KEY_NOT_EXIST, sRC ); //INDEX_NEXTKEY_ERROR );


                /* search한 결과갑을 알려준다 */
                *aRID = sDataSlot;

                // 2014.09.29 -okt- 여기까지 오면 성공이거나, ERR_DBM_KEY_NOT_EXIST 이다.
                if ( sRC == RC_SUCCESS )
                {
                    _RETURN;
                }
                else // if ( sRC == ERR_DBM_KEY_NOT_EXIST )
                {
                    for ( i = sDepthChkCnt - 1; i >= 0; i-- )
                    {
                        /******************************************
                         * search key node 와 경합해야 한다
                         * leaf spin lock 처리
                         *******************************************/
                        _CALL( mLockMgr->mSpinLock ( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        sIndexSlotID = sRoot->mIndexSlotHeader.mRootSlotID;

                        if ( sIndexSlotID < 0 )
                        {
                            mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                            DBM_DBG( "key not found sIndexSlotID change [%d] retry ", sIndexSlotID );
                            pthread_yield_s( );
                            *aExtraKey = sExtraTmp;
                            goto repeat;
                        }

                        _CALL( mSegMgr->Slot2Addr ( sIndexSlotID, &sCurr ) );

                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );
                        sRoot = sCurr;

                        /******************************************
                         * search key node 와 경합해야 한다
                         * leaf spin lock 처리
                         *******************************************/
                        _CALL( mLockMgr->mSpinLock ( &sCurr->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        if ( *aExtraKey == -1 )
                        {
                            mBinarySearchSelectExtraLeaf ( sCurr->mIndexSlotHeader.mNodeCount, &sPosition, sCurr, sKey );
                        }
                        else
                        {
                            mBinarySearchSelectLeafNu ( sCurr->mIndexSlotHeader.mNodeCount, &sPosition, sCurr, sKey, aExtraKey );
                        }

                        if ( g_nDepthNodeLtNuCnt[i] != sCurr->mIndexSlotHeader.mNodeCount
                                || g_nBtreeLtNuCnt[i] != sCurr->mBtreeCheck
                                || g_nDepthNodeNuLtPosition[i] != sPosition )
                        {
                            mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );

                            /* 계속 looping 인데 방어 코드가 있어야 하는거 아닌가 */
                            DBM_DBG( " selectsBtreeCnt [%lld][%lld]   [%d][%d] ",
                                     g_nBtreeLtNuCnt[i],
                                     sCurr->mBtreeCheck,
                                     g_nDepthNodeLtNuCnt[i],
                                     sCurr->mIndexSlotHeader.mNodeCount );

                            if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR2 );
                            {
                                DBM_ERR( "index depth max error [%d]", sIndexCheck );
                                _THROW( ERR_DBM_DEPTH_FAIL );
                            }

                            *aExtraKey = sExtraTmp;
                            pthread_yield_s( );
                            goto repeat;
                        }

                        g_nDepthNodeLtNuCnt[i] = 0;
                        g_nBtreeLtNuCnt[i] = 0;
                        g_nDepthNodeNuLtPosition[i] = 0;

                        mvpAtomicCas32_s( &sCurr->mIndexSlotHeader.mLock, -1, aTransID );
                    } /* for */

                    /* Index Tree Check */
                    if( mIndexHeader->mTreeCheck  == 1 )
                    {
                        pthread_yield_s ();
                        goto repeat;
                    }

                    DBM_DBG( "key not found " );
                    _THROW( ERR_DBM_KEY_NOT_EXIST );

                    break;
                }

                _DASSERT( 0 );  // 2014.09.29 -okt- 도달하지 않을 것 같다. 확인하자.
                break;
            }
            else
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                /* serach LT Lock Try */
                _CALL( mLockMgr->mSpinLock ( &sRoot->mIndexSlotHeader.mLock, NULL, aTransID ) );

                // 2014.07.10 btree check value로 변경 처리 한다.
                g_nDepthNodeLtNuCnt[sDepthChkCnt] = sRoot->mIndexSlotHeader.mNodeCount;
                g_nBtreeLtNuCnt[sDepthChkCnt] = sRoot->mBtreeCheck;

                sDepthNodeCnt[sDepthChkCnt] = sRoot->mIndexSlotHeader.mNodeCount;

                sCount = sRoot->mIndexSlotHeader.mNodeCount;

                /* aExtraKey -1 : 검색이 처음이다. aExtraKey -1이 아니다라는 것은 : 동일 key가 있었다는 것이다 */
                if ( *aExtraKey == -1 )
                {
                    mBinarySearchSelectExtraLeaf ( sCount, &sPosition, sRoot, sKey );
                }
                else
                {
                    mBinarySearchSelectLeafNu ( sCount, &sPosition, sRoot, sKey, aExtraKey );
                }

                g_nDepthNodeNuLtPosition[sDepthChkCnt] = sPosition;

                /* sRoot->mChild -1 이라는 것은 internal 분기가 되었다는 것을 의미한다
                 * 그렇기 때문에 새로 처음부터 검색을 해야 한다 */
                if ( sRoot->mChild[sPosition] == -1 )
                {
                    mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );

                    DBM_DBG( "slef[%lld] mchild[%lld] position[%d]", pthread_self(), sRoot->mChild[sPosition], sPosition );

                    if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR3 );
                    {
                        DBM_ERR( "index depth max error [%d]", sIndexCheck );
                        _THROW( ERR_DBM_DEPTH_FAIL );
                    }

                    goto repeat;
                }

                _CALL( mSegMgr->Slot2Addr ( sRoot->mChild[sPosition], &sChild ) );

                mvpAtomicCas32_s( &sRoot->mIndexSlotHeader.mLock, -1, aTransID );
                sRoot = sChild;
                sDepthChkCnt++;
            }

            /* search key check 0: 처음 1: 반복 */
            sFirStNodeCheck = 1;

            if ( unlikely( sDepthChkCnt > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR );
            {
                DBM_ERR( "index depth max error [%d]", sDepthChkCnt );
#if 0 // 2014.03.19 -shw-
                /*********************************************
                 * leaf unlock 처리
                 *********************************************/
                mvpAtomicCas32_s(&sRoot->mIndexSlotHeader.mLock, -1, aTransID);
#endif
                _THROW( ERR_DBM_DEPTH_FAIL );
            }
        }
        while ( 1 );

        //DBM_DBG( "key not found " );
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_KEY_NOT_EXIST )
        {
            _CATCH_WARN;

            *aExtraKey = -1;
        }
    }
    _FINALLY
    _END
} /* mSearchKeyLTNu */



/********************************************************************
 * private member functions
 *
 * 2014.09.24 (OKT): 정적 함수로 뺄수 있는 부분을 따로 모은다.
 *
********************************************************************/

/********************************************************************
 * ID : mBinarySearchSelectLeaf
 *
 * Description
 *   dbm Index key binary search
 *   해당 node에서 key값에 대하여 위치를 찾아 반환한다.
 *
 * Argument
 *     aCount    : input : node에 저장되어 있는 key count
 *     aPosition : output: key값의 position return
 *     aCurr     : input : key가 저장되어 있는 노드의 pointer
 *     aKey      : input : input key value
 *
********************************************************************/
void dbmIndexManager::mBinarySearchSelectLeaf ( int aCount , int* aPosition , dbmIndexNode* aCurr , char* aKey )
{
    int sLow;
    int sHigh;
    int sMid;
    int sRC;

    _TRY
    {
        /* clear */
        sLow = sHigh = sMid = 0;

        sHigh = aCount - 1;

        while ( sLow <= sHigh )
        {
            //sMid = ( sLow + sHigh ) / 2;
            sMid = ( sLow + sHigh ) >> 1;

            sRC = mIndexPosition ( aKey, INDEX_POS( aCurr, sMid, mIndexHeader->mIndex.mKeySize ) );

            if ( sRC > 0 )
            {
                sHigh = sMid - 1;
            }
            else if ( sRC < 0 )
            {
                sLow = sMid + 1;
            }
            else
            {
                *aPosition = sMid + 1;
                _RETURN;
            }
        } // while

        if ( mIndexCompare ( aKey, INDEX_POS( aCurr, sMid, mIndexHeader->mIndex.mKeySize ), DBM_GT ) )
        {
            *aPosition = sMid;
        }
        else
        {
            *aPosition = sMid + 1;
        }
    }
    _CATCH
    _FINALLY
    _ENDVOID
} /* mBinarySearchSelectLeaf */


/********************************************************************
 * ID : mBinarySearchSelectNuLeaf
 *
 * Description (non-unique index type)
 *   dbm Index key binary search
 *   해당 node에서 key값에 대하여 위치를 찾아 반환한다.
 *
 * Argument
 *     aCount    : input : node에 저장되어 있는 key count
 *     aPosition : output: key값의 position return
 *     aCurr     : input : key가 저장되어 있는 노드의 pointer
 *     aKey      : input : input key value
 *
********************************************************************/
void dbmIndexManager::mBinarySearchSelectLeafNu ( int aCount , int* aPosition , dbmIndexNode* aCurr , char* aKey , long long* aExtraKey )
{
    int     sKeySize;
    char    sKey[INDEX_KEY_SIZE(mIndexHeader->mIndex.mKeySize)];
    int     sLow;
    int     sHigh;
    int     sMid;
    int     sRC;

    _TRY
    {
        sKeySize = INDEX_KEY_SIZE( mIndexHeader->mIndex.mKeySize );

        /* 초기화 처리 */
        memset_s ( sKey, 0x00, sizeof( sKey ) );

        /* ExtraKey가 있으므로 해당 ExtraKey값을 포함하여 Search 처리 한다 */
        memcpy_s ( sKey, aKey, mIndexHeader->mIndex.mKeySize );
        *(long long*) ( sKey + mIndexHeader->mIndex.mKeySize ) = *aExtraKey;

        /* clear */
        sLow = sHigh = sMid = 0;

        sHigh = aCount - 1;

        while ( sLow <= sHigh )
        {
            //sMid = ( sLow + sHigh ) / 2;
            sMid = ( sLow + sHigh ) >> 1;

            sRC = mIndexPosition ( sKey, INDEX_POS( aCurr, sMid, sKeySize ) );

            if ( sRC > 0 )
            {
                sHigh = sMid - 1;
            }
            else if ( sRC < 0 )
            {
                sLow = sMid + 1;
            }
            else
            {
                *aPosition = sMid + 1;

                _RETURN
                ;
            }
        } // while

        sRC = mIndexCompare ( sKey, INDEX_POS( aCurr, sMid, sKeySize ), DBM_GT );
        if ( sRC )
        {
            *aPosition = sMid;
        }
        else
        {
            *aPosition = sMid + 1;
        }
    }
    _CATCH
    _FINALLY
    _ENDVOID
} /* mBinarySearchSelectLeafNu */


void dbmIndexManager::ShowIndexBinaryDump( )
{
    int     sRC;
    int     sCount;
    int     sPosition;
    int     i,j;
    int     sLen;
    int     sKeyOffset=0;
    char*   sSlotAddr;
    char*   sKeyValue;
    char    sKeyTemp[mIndexHeader->mIndex.mKeySize];
    char    sKey[INDEX_KEY_SIZE(mIndexHeader->mIndex.mKeySize)];
    char    sMsg[1024];


    dbmIndexNode*   sRootNode = NULL;

    /* index type */
    //g_bIsUniqueIndex = DBM_NON_UNIQUE;
    g_bIsUniqueIndex = mIndexHeader->mIndex.mIsUniqueIndex;

    /* sKey Copy */
    memset(sKey,0x0,sizeof(sKey));
    //*(int*)(sKey) = -1;


    for( j=0; j<mIndexHeader->mIndex.mColumnCount; j++ )
    {
        switch(mIndexHeader->mIndex.mKey[j].mColumnType)
        {
            case DBM_COLUMN_CHAR_TYPE:
                //memcpy(sKey + sKeyOffset ,0x00,mIndexHeader->mIndex.mKey[j].mSize);
                memset(sKey + sKeyOffset ,0x00,mIndexHeader->mIndex.mKey[j].mSize);
                break;

            case DBM_COLUMN_SHORT_TYPE:
                *(int*)(sKey+sKeyOffset) = SHRT_MIN;
                break;

            case DBM_COLUMN_INT_TYPE:
                *(int*)(sKey+sKeyOffset) = INT_MIN;
                break;

            case DBM_COLUMN_LONG_TYPE:
                *(long long*)(sKey+sKeyOffset) = LONG_MIN;
                break;
            default:
                DBM_WARN ( "Column type not Found type [%d]", mIndexHeader->mIndex.mKey[j].mColumnType );
                break;
        }

        sKeyOffset = sKeyOffset + mIndexHeader->mIndex.mKey[j].mSize;
    }

    sKeyOffset = 0;

    /* address 변환 */
    sRC = mSegMgr->Slot2Addr( mIndexHeader->mRootPid, &sSlotAddr );
    if ( sRC )
    {
        DBM_WARN("slot2addr Error [%d][%d] \n", sRC, errno );
        exit(-1);
    }

    sRootNode = (dbmIndexNode*)sSlotAddr;
    if ( sRootNode->mIndexSlotHeader.mNodeCount < 0 )
    {
        return;
    }

    do
    {
retry:
        /* offset 초기화 */
        sKeyOffset = 0;

        /* 현재의 노드가 leaf인가 */
        if ( sRootNode->mIndexSlotHeader.mLeafcheck == 1 )
        {
            DBM_WARN("SLOT NO [%lld] PREV/NEXT [%lld:%lld] NODE COUNT [%d]\n",
                    sRootNode->mCurrSlot,
                    sRootNode->mIndexSlotHeader.mLeafPrevID,
                    sRootNode->mIndexSlotHeader.mLeafNextID,
                    sRootNode->mIndexSlotHeader.mNodeCount);

            for(i=0; i<sRootNode->mIndexSlotHeader.mNodeCount;++i)
            {
                if ( mIndexHeader->mIndex.mIsUniqueIndex == 0 )
                {
                    sKeyValue = INDEX_POS( sRootNode,i,INDEX_KEY_SIZE(mIndexHeader->mIndex.mKeySize));
                }
                else
                {
                    sKeyValue = INDEX_POS( sRootNode,i,mIndexHeader->mIndex.mKeySize);
                }

                memset( sMsg, 0x00, sizeof(sMsg));
                sLen = 0;
                sLen += sprintf(sMsg + sLen, "%s", "[k: ");

                for( j=0; j<mIndexHeader->mIndex.mColumnCount; j++ )
                {
                    switch(mIndexHeader->mIndex.mKey[j].mColumnType)
                    {
                        case DBM_COLUMN_CHAR_TYPE:
                            memset(sKeyTemp,0x00,sizeof(sKeyTemp));
                            memcpy(sKeyTemp,sKeyValue+ sKeyOffset ,mIndexHeader->mIndex.mKey[j].mSize);
                            sLen += sprintf(sMsg + sLen, "[%s]", sKeyTemp);
                            break;

                        case DBM_COLUMN_SHORT_TYPE:
                            sLen += sprintf(sMsg + sLen, "[%d]", *(int*)(sKeyValue+sKeyOffset));
                            break;

                        case DBM_COLUMN_INT_TYPE:
                            sLen += sprintf(sMsg + sLen, "[%d]", *(int*)(sKeyValue+sKeyOffset));
                            break;

                        case DBM_COLUMN_LONG_TYPE:
                            sLen += sprintf(sMsg + sLen, "[%lld]", *(long long*)(sKeyValue+sKeyOffset));
                            break;
                        default:
                            DBM_WARN ( "Column type not Found type [%d]", mIndexHeader->mIndex.mKey[i].mColumnType );
                            break;
                    }

                    sKeyOffset = sKeyOffset + mIndexHeader->mIndex.mKey[j].mSize;
                }

                sLen += sprintf(sMsg + sLen, " Slot[%lld] ", sRootNode->mRID[i]);

                if ( mIndexHeader->mIndex.mIsUniqueIndex == 0 )
                {
                    sLen += sprintf(sMsg + sLen, "Extrakey[%lld] ",
                            *(long long*)(INDEX_POS( sRootNode,i,INDEX_KEY_SIZE(mIndexHeader->mIndex.mKeySize)) +
                            (long long)mIndexHeader->mIndex.mKeySize ));
                }
                /* offset 초기화 */
                sKeyOffset = 0;

                sLen += sprintf(sMsg + sLen, "]\n");
                DBM_WARN( sMsg );
            }


            if ( sRootNode->mIndexSlotHeader.mLeafNextID >= 0 )
            {
                sRC = mSegMgr->Slot2Addr( sRootNode->mIndexSlotHeader.mLeafNextID, &sSlotAddr);
                if ( sRC )
                {
                    DBM_WARN("slot2addr Error [%d][%d] \n", sRC, errno );
                    exit(-1);
                }

                sRootNode = (dbmIndexNode*)sSlotAddr;

                goto retry;
            }

            break;
        }
        else
        {
            sCount = sRootNode->mIndexSlotHeader.mNodeCount;

            mBinarySearchSelectExtraLeaf( sCount, &sPosition, sRootNode, sKey);

            sRC = mSegMgr->Slot2Addr( sRootNode->mChild[sPosition], &sSlotAddr);
            if ( sRC )
            {
                DBM_WARN("slot2addr Error [%d][%d] \n", sRC, errno );
                exit(-1);
            }

            sRootNode = (dbmIndexNode*)sSlotAddr;
        }

    } while(1);
}



/********************************************************************
 * ID : mBinarySearchSelectExtraLeaf
 *
 * Description (non-unique index type)
 *   dbm Index key binary search
 *   해당 node에서 key값에 대하여 위치를 찾아 반환한다.
 *   non-unique index type일 경우 좀더 세부적으로 검색 처리 한다
 *
 * Argument
 *     aCount    : input : node에 저장되어 있는 key count
 *     aPosition : output: key값의 position return
 *     aCurr     : input : key가 저장되어 있는 노드의 pointer
 *     aKey      : input : input key value
 *
********************************************************************/
void dbmIndexManager::mBinarySearchSelectExtraLeaf ( int aCount , int* aPosition , dbmIndexNode* aCurr , char* aKey )
{
    int     sKeySize;
    int     sLow;
    int     sHigh;
    int     sMid;
    int     sRC;
    int     i;

    _TRY
    {
        /* clear */
        sLow = sHigh = sMid = 0;
        sHigh = aCount - 1;

        sKeySize = ( g_bIsUniqueIndex ) ? mIndexHeader->mIndex.mKeySize : INDEX_KEY_SIZE( mIndexHeader->mIndex.mKeySize );

        /* 중요 : column count수만큼만 비교를 하면 되기 때문에 aNodeIndexType 1인데도 1을 따로 주지는 않고
         *        non-unique type 1을 로지 않고 0으로 주어 비교 한다 */
        g_bIsUniqueIndex = DBM_UNIQUE;

        while ( sLow <= sHigh )
        {
            sMid = ( sLow + sHigh ) >> 1;

            sRC = mIndexPosition ( aKey, INDEX_POS( aCurr, sMid, sKeySize ) );

            if ( sRC > 0 )
            {
                sHigh = sMid - 1;
            }
            else if ( sRC < 0 )
            {
                sLow = sMid + 1;
            }
            else
            {
                /*
                 * TODO: 2014.10.01 -okt- 확인요. 무슨의미가 있지?
                 */
                for ( i = sMid + 1; i < aCount; i++ )
                {
                    sRC = mIndexPosition ( aKey, INDEX_POS( aCurr, i, sKeySize ) );
                    if ( sRC != 0 )
                    {
                        break;
                    }
                }

                *aPosition = i;

                g_bIsUniqueIndex = DBM_NON_UNIQUE;
                _RETURN;
            }
        } /* while */

        sRC = mIndexCompare ( aKey, INDEX_POS( aCurr, sMid, sKeySize ), DBM_GT );
        if ( sRC )
        {
            *aPosition = sMid;
        }
        else
        {
            *aPosition = sMid + 1;
        }

        g_bIsUniqueIndex = DBM_NON_UNIQUE;
    }
    _CATCH
    _FINALLY
    _ENDVOID
} /* mBinarySearchSelectExtraLeaf */


/********************************************************************
 * ID : mSearchNextGT
 *
 * Description
 *   dbm Index search key Next
 *   input key보다 하나 더큰 key value 반한 환다.
 *
 * Argument
 *     aNode    : input : key가 저장되어 있는 노드의 포인터
 *     aKey     : input : input key value
 *     aDataSlot: output: serach하여 찾은 data ID
 *     aTransID : input : Transaction ID
 *     aNextKey : output: input key의 next key value
 *
********************************************************************/
int dbmIndexManager::mSearchNextGT ( dbmIndexNode* aNode , char* aKey , long long* aDataSlot , int* aCount, int aTransID , char aNextKey[][DBM_INDEX_KEY_MAX_SIZE] , int aEQCnt )
{
    dbmIndexNode*   sNextNode;
    int     sKeySize;
    int     sCmpData1;
    int     sCmpData2;
    int     sLock = 0;
    int     sRC;
    int     sInd = 0;
    int     i, j;

    _TRY
    {
        //_DASSERT( aEQCnt == 0 || aEQCnt == 1 ); //, ERR_DBM_INVALID_DATATYPE );
        _DASSERT( aEQCnt >= 0 ); //, ERR_DBM_INVALID_DATATYPE );

        sCmpData1 = 0;  // 같은가
        sCmpData2 = 0;  // 큰가

        /* 0: 값은키가 없음 */
        _IF_THROW( aNode == NULL, ERR_DBM_KEY_NOT_EXIST ); // KEY_VALUE_ERROR );

        sKeySize = mIndexHeader->mIndex.mKeySize;

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        /******************************************
         * search key node 와 경합해야 한다
         * leaf spin lock 처리
         *******************************************/
        _CALL( mLockMgr->mSpinLock ( &aNode->mIndexSlotHeader.mLock, NULL, aTransID ) );
        sLock = 1;

        if ( aEQCnt == 0 )
        {
            for ( i = 0; i < aNode->mIndexSlotHeader.mNodeCount; ++i )
            {
                /* sCmpData1 같은가 , sCmpData2 큰가 */
                /* 두번째 argument  기준으로 비교 */
                sCmpData1 = mIndexCompare ( aKey, INDEX_POS( aNode, i, sKeySize ), DBM_EQ );
                sCmpData2 = mIndexCompare ( aKey, INDEX_POS( aNode, i, sKeySize ), DBM_GT );

                if ( sCmpData2 == 1 )
                {
                    /* aKey 값보다 하나 더큼값의 data slot 값을 반환한다 */


                    // by lim272.
                    // 이하에 중복된 코드가 많아서 아래코드가 한 6군데 있음.
                    // 이거는 이렇다.
                    // 원래는 1건 딱 찾으면 그것만 리턴하던걸
                    // 그냥 그 노드에서 찾은 Slot위치부터 노드의 끝까지 싹 리턴하는거다.
                    //*aDataSlot = aNode->mRID[i];
                    //memcpy_s ( *aNextKey, INDEX_POS( aNode, i, sKeySize ), sKeySize );
                    for (j = i ; j<aNode->mIndexSlotHeader.mNodeCount; j++)
                    {
                        aDataSlot [sInd] = aNode->mRID[j];
                        memcpy_s ( aNextKey[sInd], INDEX_POS( aNode, j, sKeySize ), sKeySize );
                        sInd++;
                        //if (sInd >= 16) break;
                    }
                    /*
                    if( aNode->mIndexSlotHeader.mLeafNextID != -1 )
                    {
                        _CALL( mSegMgr->Slot2Addr ( aNode->mIndexSlotHeader.mLeafNextID, &sNextNode ) );
                        memcpy_s ( aNextKey[sInd+1], INDEX_POS( sNextNode, 0, sKeySize ), sKeySize );
                    }
                    */
                    //memcpy_s ( *aNextKey, INDEX_POS( aNode, (j - 1), sKeySize ), sKeySize );
                    *aCount = sInd;
                    _RETURN;
                }

                if ( sCmpData1 )
                {
                    /* i 값과 mNodeCount-1 한값이 같다면 i의 값이 마지막 node 값이라는 것을 알 수 있다 */
                    if ( i == ( aNode->mIndexSlotHeader.mNodeCount - 1 ) )
                    {
                        /* mLeafNextID -1 이라는 것은 앞의 slot이 없다는 것이다 결국 -1이라는 것은
                         * 데이터가 없다는 것이니 오류로 리턴하자 */
                        if ( aNode->mIndexSlotHeader.mLeafNextID < 0 )
                        {
                            _THROW( ERR_DBM_KEY_NOT_EXIST );
                        }

                        _CALL( mSegMgr->Slot2Addr ( aNode->mIndexSlotHeader.mLeafNextID, &sNextNode ) );

                        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
                        sLock = 0;

                        /* Next leaf lock */
                        _CALL( mLockMgr->mSpinLock ( &sNextNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        /* 값이 있다면 NodeCount 0보다 항상 커야 하고 mLeafNextID 항상 0보다 커야 한다 */
                        if ( sNextNode->mIndexSlotHeader.mNodeCount > 0 && aNode->mIndexSlotHeader.mLeafNextID >= 0 )
                        {
                            //*aDataSlot = sNextNode->mRID[0];
                            //memcpy_s ( *aNextKey, INDEX_POS( sNextNode, 0, sKeySize ), sKeySize );
                            for (j = 0; j<sNextNode->mIndexSlotHeader.mNodeCount; j++)
                            {
                                aDataSlot [sInd] = sNextNode->mRID[j];
                                memcpy_s ( aNextKey[sInd], INDEX_POS( sNextNode, j, sKeySize ), sKeySize );
                                sInd++;
                                //if (sInd >= 16) break;
                            }
                            *aCount = sInd;


                            mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID ); // Next leaf unlock
                            _RETURN;
                        }
                        else
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                        }

                        mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID ); // Next leaf unlock
                        _THROW( sRC );  // 여기는 바로 "return sRC" 하여도 된다. 빠를까 ㅠㅠ;;
                    }
                    else
                    {
                        /* 현재노드(i+1) 값이 nodeCount-1보다 큰대도 값이 없다면 없는 것이다 */
                        if ( ( i + 1 ) > ( aNode->mIndexSlotHeader.mNodeCount - 1 ) )
                        {
                            _THROW( ERR_DBM_KEY_NOT_EXIST );
                        }
                        else
                        {
                            /* aKey 값보다 하나 더큼값의 data slot 값을 반환한다 */
                            //*aDataSlot = aNode->mRID[i + 1];
                            //memcpy_s ( *aNextKey, INDEX_POS( aNode, i + 1, sKeySize ), sKeySize );
                            for (j = (i+1); j<aNode->mIndexSlotHeader.mNodeCount; j++)
                            {
                                aDataSlot [sInd] = aNode->mRID[j];
                                memcpy_s ( aNextKey[sInd], INDEX_POS( aNode, j, sKeySize ), sKeySize );
                                sInd++;
                                //if (sInd >= 16) break;
                            }
                            *aCount = sInd;


                            _RETURN;
                        }
                    }

                    _DASSERT( 0 ); // 도달하지 않음
                }
                else // if ( sCmpData1 == 0 )
                {
                    /* 2014.04.08 -shw */
                    /* delete 조정 후 tree 조정이 발생 하는데 해당 노드에 관련 된 key 값이 존재 하지 않는 경우의 수가 발생 활 수 있다
                     위와 같이 해당 노드에 key값이 없으면 nextid node의 첫번째가 next값이 되므로 해당 next값을 참조하도록 한다 */
                    /* i 값과 mNodeCount-1 한값이 같다면 i의 값이 마지막 node 값이라는 것을 알 수 있다 */
                    if ( i == ( aNode->mIndexSlotHeader.mNodeCount - 1 ) )
                    {
                        /* mLeafNextID -1 이라는 것은 앞의 slot이 없다는 것이다 결국 -1이라는 것은
                         * 데이터가 없다는 것이니 오류로 리턴하자 */
                        if ( aNode->mIndexSlotHeader.mLeafNextID < 0 )
                        {
                            _THROW( ERR_DBM_KEY_NOT_EXIST );
                        }

                        _CALL( mSegMgr->Slot2Addr ( aNode->mIndexSlotHeader.mLeafNextID, &sNextNode ) );

                        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
                        sLock = 0;

                        /* Next leaf lock */
                        _CALL( mLockMgr->mSpinLock ( &sNextNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        /* 값이 있다면 NodeCount 0보다 항상 커야 하고 mLeafNextID 항상 0보다 커야 한다 */
                        if ( sNextNode->mIndexSlotHeader.mNodeCount > 0 && aNode->mIndexSlotHeader.mLeafNextID >= 0 )
                        {
                            //*aDataSlot = sNextNode->mRID[0];
                            //memcpy_s ( *aNextKey, INDEX_POS( sNextNode, 0, sKeySize ), sKeySize );
                            for (j = 0; j<sNextNode->mIndexSlotHeader.mNodeCount; j++)
                            {
                                aDataSlot [sInd] = sNextNode->mRID[j];
                                memcpy_s ( aNextKey[sInd], INDEX_POS( sNextNode, j, sKeySize ), sKeySize );
                                sInd++;
                                //if (sInd >= 16) break;
                            }
                            *aCount = sInd;

                            mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID ); // Next leaf unlock
                            _RETURN;
                        }
                        else
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                        }

                        mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID ); // Next leaf unlock
                        _THROW( sRC );
                    }
                }
            } /* for */
        }
        else //if ( aEQCnt == 1 )
        {
            for ( i = 0; i < aNode->mIndexSlotHeader.mNodeCount; ++i )
            {
                /* sCmpData1  첫번째 컬럼 같고 두번째 컬럼이 큰가 */
                /* 두번째 argument  기준으로 비교 */
                //TODO: [OKT] DBM_GT2 제거
                //sCmpData1 = mIndexCompare ( aKey, INDEX_POS( aNode, i, sKeySize ), DBM_GT2 );
                sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, aKey, INDEX_POS( aNode, i, sKeySize ), DBM_GT, aEQCnt );

                if ( sCmpData1 )
                {
                    /* aKey 값보다 하나 더큼값의 data slot 값을 반환한다 */
                    //*aDataSlot = aNode->mRID[i];
                    //memcpy_s ( *aNextKey, INDEX_POS( aNode, i, sKeySize ), sKeySize );
                    for (j = i; j<aNode->mIndexSlotHeader.mNodeCount; j++)
                    {
                        aDataSlot[sInd] = aNode->mRID[j];
                        memcpy_s ( aNextKey[sInd], INDEX_POS( aNode, j, sKeySize ), sKeySize );
                        sInd++;
                        //if (sInd >= 16) break;
                    }
                    *aCount = sInd;
                    _RETURN;
                }
                else // if ( sCmpData1 == 0 )
                {
                    /* i 값과 mNodeCount-1 한값이 같다면 i의 값이 마지막 node 값이라는 것을 알 수 있다 */
                    if ( i == ( aNode->mIndexSlotHeader.mNodeCount - 1 ) )
                    {
                        /* mLeafNextID -1 이라는 것은 앞의 slot이 없다는 것이다 결국 -1이라는 것은
                         * 데이터가 없다는 것이니 오류로 리턴하자 */
                        if ( aNode->mIndexSlotHeader.mLeafNextID < 0 )
                        {
                            _THROW( ERR_DBM_KEY_NOT_EXIST );
                        }

                        _CALL( mSegMgr->Slot2Addr ( aNode->mIndexSlotHeader.mLeafNextID, &sNextNode ) );

                        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
                        sLock = 0;

                        /* Next leaf lock */
                        _CALL( mLockMgr->mSpinLock ( &sNextNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        /* 값이 있다면 NodeCount 0보다 항상 커야 하고 mLeafNextID 항상 0보다 커야 한다 */
                        if ( sNextNode->mIndexSlotHeader.mNodeCount > 0 && aNode->mIndexSlotHeader.mLeafNextID >= 0 )
                        {
                            /* 첫번째 컬럼이 같고 두번재 컬럼이 큰가 체크 */
                            //sCmpData1 = mIndexCompare ( aKey, INDEX_POS( sNextNode, 0, sKeySize ), DBM_GT2 );
                            sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, aKey, INDEX_POS( sNextNode, 0, sKeySize ), DBM_GT, aEQCnt );

                            if ( sCmpData1 )
                            {
                                //*aDataSlot = sNextNode->mRID[0];
                                //memcpy_s ( *aNextKey, INDEX_POS( sNextNode, 0, sKeySize ), sKeySize );
                                for (j = 0; j<sNextNode->mIndexSlotHeader.mNodeCount; j++)
                                {
                                    aDataSlot [sInd] = sNextNode->mRID[j];
                                    memcpy_s ( aNextKey[sInd], INDEX_POS( sNextNode, j, sKeySize ), sKeySize );
                                    sInd++;
                                    //if (sInd >= 16) break;
                                }
                                *aCount = sInd;
                                mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID ); // Next leaf unlock
                                _RETURN;
                            }
                            else
                            {
                                sRC = ERR_DBM_KEY_NOT_EXIST;
                            }
                        }
                        else
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                        }

                        mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID ); // Next leaf unlock
                        _THROW( sRC );
                    }
                }
            } /* for */
        }

        _THROW( ERR_DBM_KEY_NOT_EXIST );
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_KEY_NOT_EXIST )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    {
        if ( sLock != 0 )
        {
            /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
            /*********************************************
             * leaf unlock 처리
             *********************************************/
            mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
        }
    }
    _END
} /* mSearchNextGT */


/********************************************************************
 * ID : mSearchNextGTNu
 *
 * Description(non-unique index type)
 *   dbm Index search key Next
 *   input key보다 하나 더큰 key value 반한 환다.
 *
 * Argument
 *     aNode    : input : key가 저장되어 있는 노드의 포인터
 *     aKey     : input : input key value
 *     aDataSlot: output: serach하여 찾은 data ID
 *     aTransID : input : Transaction ID
 *     aNextKey : output: input key의 next key value
 *
********************************************************************/
int dbmIndexManager::mSearchNextGTNu ( dbmIndexNode* aNode , char* aKey , long long* aDataSlot ,
                                       int aTransID , char** aNextKey , long long* aExtraKey , int aEQCnt )
{
    dbmIndexNode*   sCurrNode;
    dbmIndexNode*   sNextNode;
    int     sKeySize;
    int     sKeySize2;
    int     sCmpData1;
    int     sCmpData2;
    int     sRC;
    int     sRC2;
    int     i;

    sRC = ERR_DBM_KEY_NOT_EXIST;
    sCmpData1 = 0;  // 같은가
    sCmpData2 = 0;  // 큰가
    sCurrNode = aNode;

    /* 0: 값은키가 없음 */
    _IF_RAISE( sCurrNode == NULL, KEY_VALUE_ERROR );

    sKeySize = INDEX_KEY_SIZE( mIndexHeader->mIndex.mKeySize );
    sKeySize2 = mIndexHeader->mIndex.mKeySize;

    if ( aEQCnt == 0 )
    {
        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        /******************************************
         * search key node 와 경합해야 한다
         * leaf spin lock 처리
         *******************************************/
retry2: // #630
        // 2014.10.14 -okt- 이걸 sRC로 바꾸면 안됨.
        sRC2 = mLockMgr->mSpinLock ( &sCurrNode->mIndexSlotHeader.mLock, NULL, aTransID );
        _IF_RAISE( sRC2, LEAF_LOCK_ERROR );

        for ( i = 0; i < sCurrNode->mIndexSlotHeader.mNodeCount; ++i )
        {
            /* sCmpData1 같은가 , sCmpData2 큰가 */
            /* 두번째 argument  기준으로 비교 */
            sCmpData1 = mIndexCompare ( aKey, INDEX_POS( sCurrNode, i, sKeySize ), DBM_EQ );
            sCmpData2 = mIndexCompare ( aKey, INDEX_POS( sCurrNode, i, sKeySize ), DBM_GT );

            if ( sCmpData2 == 1 )
            {
                /* aKey 값보다 하나 더큼값의 data slot 값을 반환한다 */
                *aDataSlot = sCurrNode->mRID[i];
                memcpy_s ( *aNextKey, INDEX_POS( sCurrNode, i, sKeySize ), sKeySize );
                *aExtraKey = *(long long*) ( INDEX_POS( sCurrNode, i, sKeySize) + sKeySize2 ); // NextKey에서 aExtra value 구하여 반환한다

                sRC = RC_SUCCESS;
                break;
            }

            if ( sCmpData1 )
            {
                /* i 값과 mNodeCount-1 한값이 같다면 i의 값이 마지막 node 값이라는 것을 알 수 있다 */
                if ( i == ( sCurrNode->mIndexSlotHeader.mNodeCount - 1 ) )
                {
                    /* mLeafNextID -1 이라는 것은 앞의 slot이 없다는 것이다 결국 -1이라는 것은
                     * 데이터가 없다는 것이니 오류로 리턴하자 */
                    if ( sCurrNode->mIndexSlotHeader.mLeafNextID < 0 )
                    {
                        sRC = ERR_DBM_KEY_NOT_EXIST;
                        break;
                    }

                    sRC = mSearchNextGTCompare ( &sCurrNode, aDataSlot, aNextKey, aTransID, aExtraKey, aKey );
                    // TODO: 2014.10.14 -okt- LT와 대칭적으로 추가.
                    if ( sRC == ERR_DBM_DUP_ERROR )
                    {
                        /* 동일 key가 존재 하기 때문에 새로이 다시 검색한다. */
                        goto retry2;
                    }
                    else
                    {
                        return sRC;
                    }
                }
                else
                {
                    /* 현재노드(i+1) 값이 nodeCount-1보다 큰대도 값이 없다면 없는 것이다 */
                    if ( ( i + 1 ) > ( sCurrNode->mIndexSlotHeader.mNodeCount - 1 ) )
                    {
                        sRC = ERR_DBM_KEY_NOT_EXIST;
                    }
                    else
                    {
                        /* 동일 key값이 있을 수 있기 때문에 leaf 구간에서 하나씩 node Count만큼 비교를 해본다 */
                        for ( i = i + 1; i < sCurrNode->mIndexSlotHeader.mNodeCount; i++ )
                        {
                            /* i+1 한 값하고 다르면 빠져 나와라 */
                            if ( !mIndexCompare ( aKey, INDEX_POS( sCurrNode, i, sKeySize ), DBM_EQ ) )
                            {
                                break;
                            }
                        }

                        /* i 값과 node Count 값이 같다는 것은 해당 leaf 구간에 data가 없다는 것이다 */
                        if ( i == sCurrNode->mIndexSlotHeader.mNodeCount )
                        {
                            /* mLeafNextID -1 이라는 것은 앞의 slot이 없다는 것이다 결국 -1이라는 것은
                             * 데이터가 없다는 것이니 오류로 리턴하자 */
                            if ( sCurrNode->mIndexSlotHeader.mLeafNextID < 0 )
                            {
                                sRC = ERR_DBM_KEY_NOT_EXIST;
                                break;
                            }

                            sRC = mSearchNextGTCompare ( &sCurrNode, aDataSlot, aNextKey, aTransID, aExtraKey, aKey );
                            return sRC;
                        }
                        else
                        {
                            /* aKey 값보다 하나 더큼값의 data slot 값을 반환한다 */
                            *aDataSlot = sCurrNode->mRID[i];
                            memcpy_s ( *aNextKey, INDEX_POS( sCurrNode, i, sKeySize ), sKeySize );
                            sRC = RC_SUCCESS;

                            /* NextKey에서 aExtra value 구하여 반환한다 */
                            *aExtraKey = *(long long*) ( INDEX_POS( sCurrNode, i, sKeySize) + sKeySize2 );
                        }
                    }
                }

                break;
            }
            else
            {
                /* 2014.04.08 -shw */
                /* delete 조정 후 tree 조정이 발생 하는데 해당 노드에 관련 된 key 값이 존재 하지 않는 경우의 수가 발생 활 수 있다
                 위와 같이 해당 노드에 key값이 없으면 nextid node의 첫번째가 next값이 되므로 해당 next값을 참조하도록 한다 */
                /* i 값과 mNodeCount-1 한값이 같다면 i의 값이 마지막 node 값이라는 것을 알 수 있다 */
                if ( i == ( sCurrNode->mIndexSlotHeader.mNodeCount - 1 ) )
                {
                    /* mLeafNextID -1 이라는 것은 앞의 slot이 없다는 것이다 결국 -1이라는 것은
                     * 데이터가 없다는 것이니 오류로 리턴하자 */
                    if ( sCurrNode->mIndexSlotHeader.mLeafNextID < 0 )
                    {
                        sRC = ERR_DBM_KEY_NOT_EXIST;
                        break;
                    }

                    sRC = mSearchNextGTCompare ( &sCurrNode, aDataSlot, aNextKey, aTransID, aExtraKey, aKey );
                    return sRC;
                }
            }
        }

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        /*********************************************
         * leaf unlock 처리
         *********************************************/
        mvpAtomicCas32_s( &sCurrNode->mIndexSlotHeader.mLock, -1, aTransID );
    }
    else //if ( aEQCnt == 1 )
    {
        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        /******************************************
         * search key node 와 경합해야 한다
         * leaf spin lock 처리
         *******************************************/
        sRC2 = mLockMgr->mSpinLock ( &sCurrNode->mIndexSlotHeader.mLock, NULL, aTransID );
        _IF_RAISE( sRC2, LEAF_LOCK_ERROR );

        for ( i = 0; i < sCurrNode->mIndexSlotHeader.mNodeCount; ++i )
        {
            /* sCmpData1  첫번째 컬럼 같고 두번째 컬럼이 큰가 */
            /* 두번째 argument  기준으로 비교 */
            //sCmpData1 = mIndexCompare ( aKey, INDEX_POS( sCurrNode, i, sKeySize ), DBM_GT2 );
            sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, aKey, INDEX_POS( sCurrNode, i, sKeySize ), DBM_GT, aEQCnt );

            if ( sCmpData1 )
            {
                /* aKey 값보다 하나 더큼값의 data slot 값을 반환한다 */
                *aDataSlot = sCurrNode->mRID[i];
                memcpy_s ( *aNextKey, INDEX_POS( sCurrNode, i, sKeySize ), sKeySize );
                *aExtraKey = *(long long*) ( INDEX_POS( sCurrNode, i, sKeySize) + sKeySize2 ); // NextKey에서 aExtra value 구하여 반환

                sRC = RC_SUCCESS;
                break;
            }
            else
            {
                /* i 값과 mNodeCount-1 한값이 같다면 i의 값이 마지막 node 값이라는 것을 알 수 있다 */
                if ( i == ( sCurrNode->mIndexSlotHeader.mNodeCount - 1 ) )
                {
                    /* mLeafNextID -1 이라는 것은 앞의 slot이 없다는 것이다 결국 -1이라는 것은
                     * 데이터가 없다는 것이니 오류로 리턴하자 */
                    if ( sCurrNode->mIndexSlotHeader.mLeafNextID < 0 )
                    {
                        sRC = ERR_DBM_KEY_NOT_EXIST;
                        break;
                    }

                    sRC = mSegMgr->Slot2Addr ( sCurrNode->mIndexSlotHeader.mLeafNextID, &sNextNode );
                    _IF_RAISE( sRC || sNextNode == NULL, SLOT2ADDR_FAIL );

                    /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
                    /*********************************************
                     * leaf unlock 처리
                     *********************************************/
                    mvpAtomicCas32_s( &sCurrNode->mIndexSlotHeader.mLock, -1, aTransID );

                    /* Next leaf lock */
                    sRC = mLockMgr->mSpinLock ( &sNextNode->mIndexSlotHeader.mLock, NULL, aTransID );
                    _IF_RAISE( sRC, LEAF_LOCK_ERROR2 );

                    /* 값이 있다면 NodeCount 0보다 항상 커야 하고 mLeafNextID 항상 0보다 커야 한다 */
                    if ( sNextNode->mIndexSlotHeader.mNodeCount > 0 && sCurrNode->mIndexSlotHeader.mLeafNextID >= 0 )
                    {
                        /* 첫번째 컬럼이 같고 두번재 컬럼이 큰가 체크 */
                        //sCmpData1 = mIndexCompare ( aKey, INDEX_POS( sNextNode, 0, sKeySize ), DBM_GT2 );
                        sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, aKey, INDEX_POS( sNextNode, 0, sKeySize ), DBM_GT, aEQCnt );

                        if ( sCmpData1 )
                        {
                            *aDataSlot = sNextNode->mRID[0];
                            memcpy_s ( *aNextKey, INDEX_POS( sNextNode, 0, sKeySize ), sKeySize );
                            *aExtraKey = *(long long*) ( INDEX_POS( sNextNode, 0, sKeySize) + sKeySize2 ); // NextKey에서 aExtra value 구하여 반환

                            sRC = RC_SUCCESS;
                        }
                        else
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                        }
                    }
                    else
                    {
                        sRC = ERR_DBM_KEY_NOT_EXIST;
                    }

                    /* Next leaf unlock */
                    mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID );

                    return sRC;
                }
            }
        }

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        /*********************************************
         * leaf unlock 처리
         *********************************************/
        mvpAtomicCas32_s( &sCurrNode->mIndexSlotHeader.mLock, -1, aTransID );
    }
//    else
//    {
//        DBM_ERR( "Index Search GT Type Error [%d]", aEQCnt );
//        sRC = ERR_DBM_INVALID_DATATYPE;
//        return sRC;
//    }


    _EXCEPTION(KEY_VALUE_ERROR)
    {
        DBM_ERR( "input key null data [%s]", aKey );
        sRC = ERR_DBM_KEY_NOT_EXIST;
    }

    _EXCEPTION(SLOT2ADDR_FAIL)
    {
        DBM_ERR("mSearchNextGT slot2addr change fail [%d]", sRC );
        mvpAtomicCas32_s(&sCurrNode->mIndexSlotHeader.mLock, -1, aTransID);
        sRC = ERR_DBM_SLOT2ADDR_FAIL;
    }

    _EXCEPTION( LEAF_LOCK_ERROR )
    {
        DBM_ERR( "index select leaf lock error [%d]", sRC );

        sRC = ERR_DBM_LOCK_FAIL;
    }

    _EXCEPTION( LEAF_LOCK_ERROR2 )
    {
        DBM_ERR( "index select leaf lock error2 [%d]", sRC );

        sRC = ERR_DBM_LOCK_FAIL;
    }

    _EXCEPTION_END;

    return sRC;
} /* mSearchNextGTNu */


/********************************************************************
 * ID : mSearchNextLT
 *
 * Description
 *   dbm Index search key Prev
 *   입력받은 key 보다 하나 더작은 값을 반환한다.
 *
 * Argument
 *     aNode    : input : input key value 있는 노드의 pointer
 *     aKey     : input : input key data value
 *     aDataSlot: output: search 하여 찾은 data ID
 *     aTransID : input : Transaction ID
 *     aPrevKey : output: 입력 받은 key 보다 하나 더작은 key
 *
********************************************************************/
int dbmIndexManager::mSearchNextLT ( dbmIndexNode* aNode , char* aKey , long long* aDataSlot , int* aCount, int aTransID , char aPrevKey[][DBM_INDEX_KEY_MAX_SIZE] , int aEQCnt )
{
    dbmIndexNode*   sPrevNode;
    int     sKeySize;
    int     sCmpData1;
    int     sCmpData2;
    int     sLock = 0;
    int     sRC;
    int     sInd = 0;
    int     i, j;

    _TRY
    {
        //_DASSERT( aEQCnt == 0 || aEQCnt == 1 ); //, ERR_DBM_INVALID_DATATYPE );
        _DASSERT( aEQCnt >= 0 ); //, ERR_DBM_INVALID_DATATYPE );

        sCmpData1 = 0;  // 같은가
        sCmpData2 = 0;  // 작은가

        /* 0: 값은키가 없음 */
        _IF_THROW( aNode == NULL, ERR_DBM_KEY_NOT_EXIST ); // KEY_VALUE_ERROR );

        sKeySize = mIndexHeader->mIndex.mKeySize;

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        /******************************************
         * search key node 와 경합해야 한다
         * leaf spin lock 처리
         *******************************************/
        _CALL( mLockMgr->mSpinLock ( &aNode->mIndexSlotHeader.mLock, NULL, aTransID ) );
        sLock = 1;

        if ( aEQCnt == 0 )
        {
            for ( i = aNode->mIndexSlotHeader.mNodeCount - 1; i >= 0; --i )
            {
                /* sCmpData1 같은가 , sCmpData2 작은가 */
                sCmpData1 = mIndexCompare ( aKey, INDEX_POS( aNode, i, sKeySize ), DBM_EQ );
                sCmpData2 = mIndexCompare ( aKey, INDEX_POS( aNode, i, sKeySize ), DBM_LT );

                if ( sCmpData2 == 1 )
                {
                    /* aKey 값보다 하나 작은 값의 data slot 값을 반환한다 */
                    //*aDataSlot = aNode->mRID[i];
                    //memcpy_s ( *aPrevKey, INDEX_POS( aNode, i, sKeySize ), sKeySize );
                    //memcpy_s ( aPrevKey[sInd], aKey, sKeySize );
                    for (j = i; j >= 0; j--)
                    {
                        aDataSlot [sInd] = aNode->mRID[j];
                        //memcpy_s ( aPrevKey[sInd+1], INDEX_POS( aNode, j, sKeySize ), sKeySize );
                        memcpy_s ( aPrevKey[sInd], INDEX_POS( aNode, j, sKeySize ), sKeySize );
                        sInd++;
                        //if (sInd >= 16) break;
                    }
                    *aCount = sInd;
                    _RETURN;
                }

                if ( sCmpData1 )
                {
                    if ( i == 0 )
                    {
                        /* mLeafPrevID -1 이라는 것은 전의 해당 slot이 없다는 것이다.*/
                        if ( aNode->mIndexSlotHeader.mLeafPrevID < 0 )
                        {
                            _THROW( ERR_DBM_KEY_NOT_EXIST );
                        }

                        _CALL( mSegMgr->Slot2Addr ( aNode->mIndexSlotHeader.mLeafPrevID, &sPrevNode ) );

                        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
                        sLock = 0;

                        /* Prev leaf lock */
                        _CALL( mLockMgr->mSpinLock ( &sPrevNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        if ( sPrevNode->mIndexSlotHeader.mNodeCount > 0 && aNode->mIndexSlotHeader.mLeafPrevID >= 0 )
                        {
                            //*aDataSlot = sPrevNode->mRID[sPrevNode->mIndexSlotHeader.mNodeCount - 1];
                            //memcpy_s ( *aPrevKey,
                            //           INDEX_POS( sPrevNode, sPrevNode->mIndexSlotHeader.mNodeCount - 1, sKeySize ),
                            //           sKeySize );
                            for (j = sPrevNode->mIndexSlotHeader.mNodeCount - 1; j >= 0; j--)
                            {
                                aDataSlot [sInd] = sPrevNode->mRID[j];
                                memcpy_s ( aPrevKey[sInd], INDEX_POS( sPrevNode, j, sKeySize ), sKeySize );
                                sInd++;
                            }
                            *aCount = sInd;

                            mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID );
                            _RETURN;
                        }
                        else
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                        }

                        /* Prev leaf unlock */
                        mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID );
                        _THROW( sRC );  // 여기는 바로 "return sRC" 하여도 된다. 빠를까 ㅠㅠ;;
                    }
                    else
                    {
                        /* aKey 값보다 하나 작은 값의 data slot 값을 반환한다 */
                        //*aDataSlot = aNode->mRID[i - 1];
                        //memcpy_s ( *aPrevKey, INDEX_POS( aNode, i - 1, sKeySize ), sKeySize );
                        for (j = i-1; j >= 0; j--)
                        {
                            aDataSlot [sInd] = aNode->mRID[j];
                            memcpy_s ( aPrevKey[sInd], INDEX_POS( aNode, j, sKeySize ), sKeySize );
                            sInd++;
                        }
                        *aCount = sInd;

                        _RETURN;
                    }

                    _DASSERT( 0 ); // 도달하지 않음
                }
            } /* for */
        }
        else //if ( aEQCnt == 1 )
        {
            for ( i = aNode->mIndexSlotHeader.mNodeCount - 1; i >= 0; --i )
            {
                /* sCmpData1 같은면서 작은가 */
                sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, aKey, INDEX_POS( aNode, i, sKeySize ), DBM_LT, aEQCnt );

                if ( sCmpData1 )
                {
                    /* aKey 값보다 하나 작은 값의 data slot 값을 반환한다 */
                    //*aDataSlot = aNode->mRID[i];
                    //memcpy_s ( *aPrevKey, INDEX_POS( aNode, i, sKeySize ), sKeySize );
                    for (j = i; j >= 0; j--)
                    {
                        aDataSlot [sInd] = aNode->mRID[j];
                        memcpy_s ( aPrevKey[sInd], INDEX_POS( aNode, j, sKeySize ), sKeySize );
                        sInd++;
                    }
                    *aCount = sInd;
                    _RETURN;
                }
                else
                {
                    if ( i == 0 )
                    {
                        /* mLeafPrevID -1 이라는 것은 전의 해당 slot이 없다는 것이다.*/
                        if ( aNode->mIndexSlotHeader.mLeafPrevID < 0 )
                        {
                            _THROW( ERR_DBM_KEY_NOT_EXIST );
                        }

                        _CALL( mSegMgr->Slot2Addr ( aNode->mIndexSlotHeader.mLeafPrevID, &sPrevNode ) );

                        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
                        sLock = 0;

                        /* Prev leaf lock */
                        _CALL( mLockMgr->mSpinLock ( &sPrevNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        if ( sPrevNode->mIndexSlotHeader.mNodeCount > 0 && aNode->mIndexSlotHeader.mLeafPrevID >= 0 )
                        {
                            /* 첫번째 컬럼이 같고 두번재 컬럼이 큰가 체크 */
                            sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, aKey,
                                                        INDEX_POS( sPrevNode, sPrevNode->mIndexSlotHeader.mNodeCount - 1, sKeySize ),
                                                        //DBM_LT2, aEQCnt );
                                                        DBM_LT, aEQCnt );
                            if ( sCmpData1 )
                            {
                                //*aDataSlot = sPrevNode->mRID[sPrevNode->mIndexSlotHeader.mNodeCount - 1];
                                //memcpy_s ( *aPrevKey,
                                //           INDEX_POS( sPrevNode, sPrevNode->mIndexSlotHeader.mNodeCount - 1, sKeySize ),
                                //           sKeySize );
                                for (j = sPrevNode->mIndexSlotHeader.mNodeCount - 1; j >= 0; j--)
                                {
                                    aDataSlot [sInd] = aNode->mRID[j];
                                    memcpy_s ( aPrevKey[sInd], INDEX_POS( sPrevNode, j, sKeySize ), sKeySize );
                                    sInd++;
                                }
                                *aCount = sInd;

                                mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID ); // Prev leaf unlock
                                _RETURN;
                            }
                            else
                            {
                                sRC = ERR_DBM_KEY_NOT_EXIST;
                            }
                        }
                        else
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                        }

                        mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID ); // Prev leaf unlock
                        _THROW( sRC );
                    }
                }
            } /* for */
        }

        _THROW( ERR_DBM_KEY_NOT_EXIST );
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_KEY_NOT_EXIST )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    {
        if ( sLock != 0 )
        {
            /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
            /*********************************************
             * leaf unlock 처리
             *********************************************/
            mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
        }
    }
    _END
} /* mSearchNextLT */


/********************************************************************
 * ID : mSearchNextNuLT
 *
 * Description (non-unique index type )
 *   dbm Index search key Prev
 *   입력받은 key 보다 하나 더작은 값을 반환한다.
 *
 * Argument
 *     aNode    : input : input key value 있는 노드의 pointer
 *     aKey     : input : input key data value
 *     aDataSlot: output: search 하여 찾은 data ID
 *     aTransID : input : Transaction ID
 *     aPrevKey : output: 입력 받은 key 보다 하나 더작은 key
 *
********************************************************************/
int dbmIndexManager::mSearchNextLTNu ( dbmIndexNode* aNode, char* aKey, long long* aDataSlot,
                                       int aTransID, char** aPrevKey, long long* aExtraKey, int aEQCnt )
{
    dbmIndexNode*   sCurrNode;
    dbmIndexNode*   sPrevNode;
    int     sKeySize;
    int     sKeySize2;
    int     sCmpData1;
    int     sCmpData2;
    int     sPrevNodeCount;
    char*   sSlotAddr;
    int     sRC;
    int     sRC2;
    int     i;

    sRC = ERR_DBM_KEY_NOT_EXIST;
    sCmpData1 = 0;  // 같은가
    sCmpData2 = 0;  // 작은가
    sCurrNode = aNode;

    /* 0: 값은키가 없음 */
    _IF_RAISE( sCurrNode == NULL, KEY_VALUE_ERROR );

    sKeySize = INDEX_KEY_SIZE( mIndexHeader->mIndex.mKeySize );
    sKeySize2 = mIndexHeader->mIndex.mKeySize;

    if ( aEQCnt == 0 )
    {
        /******************************************
         * search key node 와 경합해야 한다
         * leaf spin lock 처리
         *******************************************/
retry2: // #630
        // 2014.10.14 -okt- 이걸 sRC로 바꾸면 안됨.
        sRC2 = mLockMgr->mSpinLock ( &sCurrNode->mIndexSlotHeader.mLock, NULL, aTransID );
        _IF_RAISE( sRC2, LEAF_LOCK_ERROR );

        for ( i = sCurrNode->mIndexSlotHeader.mNodeCount - 1; i >= 0; --i )
        {
            /* sCmpData1 같은가 , sCmpData2 작은가 */
            sCmpData1 = mIndexCompare ( aKey, INDEX_POS( sCurrNode, i, sKeySize ), DBM_EQ );
            sCmpData2 = mIndexCompare ( aKey, INDEX_POS( sCurrNode, i, sKeySize ), DBM_LT );

            if ( sCmpData2 == 1 )
            {
                /* aKey 값보다 하나 작은 값의 data slot 값을 반환한다 */
                *aDataSlot = sCurrNode->mRID[i];
                memcpy_s ( *aPrevKey, INDEX_POS( sCurrNode, i, sKeySize ), sKeySize );
                *aExtraKey = *(long long*) ( INDEX_POS( sCurrNode, i, sKeySize) + sKeySize2 ); // NextKey에서 aExtra value 구하여 반환한다

                sRC = RC_SUCCESS;
                break;
            }

            if ( sCmpData1 )
            {
                if ( i == 0 ) // 마지막
                {
                    /* mLeafPrevID -1 이라는 것은 전의 해당 slot이 없다는 것이다.*/
                    if ( sCurrNode->mIndexSlotHeader.mLeafPrevID < 0 )
                    {
                        sRC = ERR_DBM_KEY_NOT_EXIST;
                        break;
                    }

                    // 2014.12.14. -okt- 함수내부에서 락을 풀고 있다. - sCurrNode->mIndexSlotHeader.mLock
                    sRC = mSearchNextLTCompare ( &sCurrNode, aDataSlot, aPrevKey, aTransID, aExtraKey, aKey );
                    if ( sRC == ERR_DBM_DUP_ERROR )
                    {
                        /* 동일 key가 존재 하기 때문에 새로이 다시 검색한다. */
                        goto retry2;
                    }
                    else
                    {
                        return sRC;
                    }
                }
                else
                {
                    /* non-unique index type에서 뒤의 같은 값이 계속 올수 있기 때문에 -1한 값을 다시 한번 비교해 본다 */
                    /* 같다면 다시한번 비교해봐!!!! */
                    if ( ! mIndexCompare ( aKey, INDEX_POS( sCurrNode, i - 1, sKeySize ), DBM_EQ ) )
                    {
                        /* aKey 값보다 하나 작은 값의 data slot 값을 반환한다 */
                        *aDataSlot = sCurrNode->mRID[i - 1];
                        memcpy_s ( *aPrevKey, INDEX_POS( sCurrNode, i - 1, sKeySize ), sKeySize );
                        *aExtraKey = *(long long*) ( INDEX_POS( sCurrNode, i - 1, sKeySize ) + sKeySize2 ); // PrevKey에서 aExtra value 구하여 반환한다

                        sRC = RC_SUCCESS;
                        break;
                    }
                }
            }
        }

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        /*********************************************
        * leaf unlock 처리
        *********************************************/
        mvpAtomicCas32_s(&sCurrNode->mIndexSlotHeader.mLock, -1, aTransID);
    }
    else //if ( aEQCnt == 1 )
    {
        /******************************************
        * search key node 와 경합해야 한다
         * leaf spin lock 처리
         *******************************************/
        sRC2 = mLockMgr->mSpinLock ( &sCurrNode->mIndexSlotHeader.mLock, NULL, aTransID );
        _IF_RAISE( sRC2, LEAF_LOCK_ERROR );

        for ( i = sCurrNode->mIndexSlotHeader.mNodeCount - 1; i >= 0; --i )
        {
            /* sCmpData1 같은면서 작은가 */
            //sCmpData1 = mIndexCompare ( aKey, INDEX_POS( sCurrNode, i, sKeySize ), DBM_LT2 );
            sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, aKey, INDEX_POS( sCurrNode, i, sKeySize ), DBM_LT, aEQCnt );

            if ( sCmpData1 )
            {
                /* aKey 값보다 하나 작은 값의 data slot 값을 반환한다 */
                *aDataSlot = sCurrNode->mRID[i];
                memcpy_s ( *aPrevKey, INDEX_POS( sCurrNode, i, sKeySize ), sKeySize );
                *aExtraKey = *(long long*) ( INDEX_POS( sCurrNode, i, sKeySize) + sKeySize2 ); // PrevKey에서 aExtra value 구하여 반환

                sRC = RC_SUCCESS;
                break;
            }
            else
            {
                if ( i == 0 )    // 여기가 루프의 끝이다.
                {
                    /* mLeafPrevID -1 이라는 것은 전의 해당 slot이 없다는 것이다.*/
                    if ( sCurrNode->mIndexSlotHeader.mLeafPrevID < 0 )
                    {
                        sRC = ERR_DBM_KEY_NOT_EXIST;
                        break;
                    }

                    sRC = mSegMgr->Slot2Addr ( sCurrNode->mIndexSlotHeader.mLeafPrevID, &sPrevNode );
                    _IF_RAISE( sRC, SLOT2ADDR_FAIL ); // 2014.11.18. -okt- 성능구간 중복검사 제거

                    /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
                    /*********************************************
                     * leaf unlock 처리
                     *********************************************/
                    mvpAtomicCas32_s( &sCurrNode->mIndexSlotHeader.mLock, -1, aTransID );

                    /* Prev leaf lock */
                    sRC = mLockMgr->mSpinLock ( &sPrevNode->mIndexSlotHeader.mLock, NULL, aTransID );
                    _IF_RAISE( sRC, LEAF_LOCK_ERROR2 );

retry:
                    if ( sPrevNode->mIndexSlotHeader.mNodeCount > 0 && sCurrNode->mIndexSlotHeader.mLeafPrevID >= 0 )
                    {
                        sPrevNodeCount = sPrevNode->mIndexSlotHeader.mNodeCount - 1;

                        /* 첫번째 컬럼이 같고 두번재 컬럼이 큰가 체크 */
                        //sCmpData1 = mIndexCompare ( aKey, INDEX_POS( sPrevNode, sPrevNodeCount, sKeySize ), DBM_LT2 );
                        sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, aKey, INDEX_POS( sPrevNode, sPrevNodeCount, sKeySize ), DBM_LT, aEQCnt );
                        if ( sCmpData1 )
                        {
                            *aDataSlot = sPrevNode->mRID[sPrevNode->mIndexSlotHeader.mNodeCount - 1];
                            memcpy_s ( *aPrevKey,
                                       INDEX_POS( sPrevNode, sPrevNode->mIndexSlotHeader.mNodeCount - 1, sKeySize ), sKeySize );
                            *aExtraKey = *(long long*) ( INDEX_POS( sPrevNode, sPrevNodeCount, sKeySize ) + sKeySize2 ); // PrevKey에서 aExtra value 구하여 반환한다
                            sPrevNodeCount = sPrevNode->mIndexSlotHeader.mNodeCount - 1;

                            sRC = RC_SUCCESS;
                        }
                        else
                        {
                            sCmpData1 = mIndexCompare ( aKey, INDEX_POS( sPrevNode, sPrevNodeCount, sKeySize ), DBM_EQ );

                            /* 같은게 있다면 계속 loop 돌면서 체크해 보아야 한다 */
                            if ( sCmpData1 )
                            {
                                for ( i = sPrevNode->mIndexSlotHeader.mNodeCount - 2; i >= 0; --i )
                                {
                                    /* 크거나 같은가... */
                                    //sCmpData1 = mIndexCompare ( aKey, INDEX_POS( sPrevNode, i, sKeySize ), DBM_LT2 );
                                    sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, aKey, INDEX_POS( sPrevNode, i, sKeySize ), DBM_LT, aEQCnt );

                                    if ( sCmpData1 )
                                    {
                                        *aDataSlot = sPrevNode->mRID[i];
                                        memcpy_s ( *aPrevKey, INDEX_POS( sPrevNode, i, sKeySize ), sKeySize );
                                        *aExtraKey = *(long long*) ( INDEX_POS( sPrevNode, i, sKeySize ) + sKeySize2 ); // PrevKey에서 aExtra value 구하여 반환한다

                                        sRC = RC_SUCCESS;
                                        break;
                                    }
                                    else /* 작은가 */
                                    if ( !mIndexCompare ( aKey, INDEX_POS( sPrevNode, i, sKeySize ), DBM_EQ ) )
                                    {
                                        sRC = ERR_DBM_KEY_NOT_EXIST;
                                        break;
                                    }
                                    /* 같으면 다시 비교 */

                                    /* 최초로 다시 왔다면 다시 비교 */
                                    if ( i == 0 )
                                    {
                                        /* mLeafPrevID -1 이라는 것은 전의 해당 slot이 없다는 것이다.*/
                                        if ( sPrevNode->mIndexSlotHeader.mLeafPrevID < 0 )
                                        {
                                            /* Prev leaf unlock */
                                            mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID );
                                            sRC = ERR_DBM_KEY_NOT_EXIST;
                                            break;
                                        }

                                        sRC = mSegMgr->Slot2Addr ( sPrevNode->mIndexSlotHeader.mLeafPrevID, &sSlotAddr );
                                        _IF_RAISE( sRC, SLOT2ADDR_FAIL ); // 2014.11.18. -okt- 성능구간 중복검사 제거

                                        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
                                        /*********************************************
                                         * leaf unlock 처리
                                         *********************************************/
#if 0
                                        mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID ); // Prev leaf unlock

                                        sPrevNode = (dbmIndexNode*) sSlotAddr;

                                        sRC = mLockMgr->mSpinLock ( &sPrevNode->mIndexSlotHeader.mLock, NULL, aTransID ); // Prev leaf lock
                                        _IF_RAISE( sRC, LEAF_LOCK_ERROR2 );
#else
                                        sRC = mLockMgr->mSpinLock ( &((dbmIndexNode*) sSlotAddr)->mIndexSlotHeader.mLock, NULL, aTransID ); // Prev leaf lock
                                        _IF_RAISE( sRC, LEAF_LOCK_ERROR2 );

                                        mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID ); // Prev leaf unlock

                                        sPrevNode = (dbmIndexNode*) sSlotAddr;
#endif

                                        goto retry;
                                    }
                                }
                            }
                            else
                            {
                                sRC = ERR_DBM_KEY_NOT_EXIST;
                            }
                        }
                    }
                    else
                    {
                        sRC = ERR_DBM_KEY_NOT_EXIST;
                    }

                    /* Prev leaf unlock */
                    mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID );

                    return sRC;
                } // if ( i == 0 )
            }
        } /* for */

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        /*********************************************
        * leaf unlock 처리
        *********************************************/
        /*
         * (OKT) 필요없을수도 있지만. 혹시나. 하고 추가했더만 testcase 죽는다. ( 2014.09.19 )
         */
        //if ( *(int*)sCurrNode->mIndexSlotHeader.mLock == aTransID )
        {
            mvpAtomicCas32_s( &sCurrNode->mIndexSlotHeader.mLock, -1, aTransID );
        }
    }
//    else
//    {
//        DBM_ERR( "Index Search LT Type Error [%d]", aEQCnt );
//        sRC = ERR_DBM_INVALID_DATATYPE;
//        return sRC;
//    }

    _EXCEPTION(KEY_VALUE_ERROR)
    {
        DBM_ERR("input key null data [%s]", aKey );
        sRC = ERR_DBM_KEY_NOT_EXIST;
    }

    _EXCEPTION(SLOT2ADDR_FAIL)
    {
        DBM_ERR( "mSearchNextGT slot2addr change fail [%d]", sRC );
        mvpAtomicCas32_s( &sCurrNode->mIndexSlotHeader.mLock, -1, aTransID );
        sRC = ERR_DBM_SLOT2ADDR_FAIL;
    }

    _EXCEPTION( LEAF_LOCK_ERROR )
    {
        DBM_ERR( "index select leaf lock error [%d]", sRC );

        sRC = ERR_DBM_LOCK_FAIL;
    }

    _EXCEPTION( LEAF_LOCK_ERROR2 )
    {
        DBM_ERR( "index select leaf lock error2 [%d]", sRC );

        sRC = ERR_DBM_LOCK_FAIL;
    }

    _EXCEPTION_END;

    return sRC;
} /* mSearchNextLTNu */


/********************************************************************
 * ID : mSearchNextExtraGT
 *
 * Description(non-unique index type)
 *   dbm Index search key Next
 *   input key보다 하나 더큰 key value 반한 환다.
 *
 * Argument
 *     aNode    : input : key가 저장되어 있는 노드의 포인터
 *     aKey     : input : input key value
 *     aDataSlot: output: serach하여 찾은 data ID
 *     aTransID : input : Transaction ID
 *     aNextKey : output: input key의 next key value
 *
********************************************************************/
int dbmIndexManager::mSearchNextExtraGT ( dbmIndexNode* aNode , char* aKey , long long* aDataSlot , int aTransID , char** aNextKey , long long* aExtraKey , int aEQCnt )
{
    dbmIndexNode*   sNextNode;
    int     sKeySize;
    int     sKeySize2;
    char    sKey[INDEX_KEY_SIZE(mIndexHeader->mIndex.mKeySize)];    // 이런게 되는거였나?
    int     sCmpData1;
    int     sCmpData2;
    int     sRC;
    int     i;

    _TRY
    {
        //_DASSERT( aEQCnt == 0 || aEQCnt == 1 ); //, ERR_DBM_INVALID_DATATYPE );
        _DASSERT( aEQCnt >= 0 ); //, ERR_DBM_INVALID_DATATYPE );

        sRC = ERR_DBM_KEY_NOT_EXIST;
        sCmpData1 = 0;  // 같은가
        sCmpData2 = 0;  // 큰가

        /* 0: 값은키가 없음 */
        _IF_THROW( aNode == NULL, ERR_DBM_KEY_NOT_EXIST ); //KEY_VALUE_ERROR );

        /* 초기화 처리 */
        //memset_s ( sKey, 0x00, sizeof( sKey ) ); // 2014.10.15 -okt- 중복, 불필요.
        sKeySize = INDEX_KEY_SIZE( mIndexHeader->mIndex.mKeySize );
        sKeySize2 = mIndexHeader->mIndex.mKeySize;

        /* ExtraKey가 있으므로 해당 ExtraKey값을 포함하여 Search 처리 한다 */
        memcpy_s ( sKey, aKey, sKeySize2 );
        // remove 8 byte memcpy (성능)
        //memcpy_s(sKey+sKeySize2,aExtraKey,8);
        *(long long*) ( sKey + sKeySize2 ) = *aExtraKey;

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        /******************************************
         * search key node 와 경합해야 한다
         * leaf spin lock 처리
         *******************************************/
        _CALL( mLockMgr->mSpinLock ( &aNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

        if ( aEQCnt == 0 )
        {
            for ( i = 0; i < aNode->mIndexSlotHeader.mNodeCount; ++i )
            {
                /* sCmpData1 같은가 , sCmpData2 큰가 */
                /* 두번째 argument  기준으로 비교 */
                sCmpData1 = mIndexCompare ( sKey, INDEX_POS( aNode, i, sKeySize ), DBM_EQ );
                sCmpData2 = mIndexCompare ( sKey, INDEX_POS( aNode, i, sKeySize ), DBM_GT );

                if ( sCmpData2 == 1 )
                {
                    /* aKey 값보다 하나 더큼값의 data slot 값을 반환한다 */
                    *aDataSlot = aNode->mRID[i];
                    memcpy_s ( *aNextKey, INDEX_POS( aNode, i, sKeySize ), sKeySize );
                    *aExtraKey = *(long long*) ( INDEX_POS( aNode, i, sKeySize ) + sKeySize2 ); // NextKey에서 aExtra value 구하여 반환한다

                    sRC = RC_SUCCESS;
                    break;
                }

                if ( sCmpData1 )
                {
                    /* i 값과 mNodeCount-1 한값이 같다면 i의 값이 마지막 node 값이라는 것을 알 수 있다 */
                    if ( i == ( aNode->mIndexSlotHeader.mNodeCount - 1 ) )
                    {
                        /* mLeafNextID -1 이라는 것은 앞의 slot이 없다는 것이다 결국 -1이라는 것은
                         * 데이터가 없다는 것이니 오류로 리턴하자 */
                        if ( aNode->mIndexSlotHeader.mLeafNextID < 0 )
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                            break;
                        }

                        sRC = mSearchNextGTCompare ( &aNode, aDataSlot, aNextKey, aTransID, aExtraKey, aKey );
                        return sRC;
                    }
                    else
                    {
                        /* 현재노드(i+1) 값이 nodeCount-1보다 큰대도 값이 없다면 없는 것이다 */
                        if ( ( i + 1 ) > ( aNode->mIndexSlotHeader.mNodeCount - 1 ) )
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                        }
                        else
                        {
                            /* 동일 key값이 있을 수 있기 때문에 leaf 구간에서 하나씩 node Count만큼 비교를 해본다 */
                            for ( i = i + 1; i < aNode->mIndexSlotHeader.mNodeCount; i++ )
                            {
                                /* i+1 한 값하고 다르면 빠져 나와라 */
                                if ( !mIndexCompare ( sKey, INDEX_POS( aNode, i, sKeySize ), DBM_EQ ) )
                                {
                                    break;
                                }
                            }

                            /* i 값과 node Count 값이 같다는 것은 해당 leaf 구간에 data가 없다는 것이다 */
                            if ( i == aNode->mIndexSlotHeader.mNodeCount )
                            {
                                /* mLeafNextID -1 이라는 것은 앞의 slot이 없다는 것이다 결국 -1이라는 것은
                                 * 데이터가 없다는 것이니 오류로 리턴하자 */
                                if ( aNode->mIndexSlotHeader.mLeafNextID < 0 )
                                {
                                    sRC = ERR_DBM_KEY_NOT_EXIST;
                                    break;
                                }

                                sRC = mSearchNextGTCompare ( &aNode, aDataSlot, aNextKey, aTransID, aExtraKey, aKey );
                                return sRC;
                            }
                            else
                            {
                                /* aKey 값보다 하나 더큼값의 data slot 값을 반환한다 */
                                *aDataSlot = aNode->mRID[i];
                                memcpy_s ( *aNextKey, INDEX_POS( aNode, i, sKeySize ), sKeySize );
                                *aExtraKey = *(long long*) ( INDEX_POS( aNode, i, sKeySize) + sKeySize2 ); // NextKey에서 aExtra value 구하여 반환한다

                                sRC = RC_SUCCESS;
                            }
                        }
                    }

                    break;
                }
                else
                {
                    /* 2014.04.08 -shw */
                    /* delete 조정 후 tree 조정이 발생 하는데 해당 노드에 관련 된 key 값이 존재 하지 않는 경우의 수가 발생 활 수 있다
                     위와 같이 해당 노드에 key값이 없으면 nextid node의 첫번째가 next값이 되므로 해당 next값을 참조하도록 한다 */
                    /* i 값과 mNodeCount-1 한값이 같다면 i의 값이 마지막 node 값이라는 것을 알 수 있다 */
                    if ( i == ( aNode->mIndexSlotHeader.mNodeCount - 1 ) )
                    {
                        /* mLeafNextID -1 이라는 것은 앞의 slot이 없다는 것이다 결국 -1이라는 것은
                         * 데이터가 없다는 것이니 오류로 리턴하자 */
                        if ( aNode->mIndexSlotHeader.mLeafNextID < 0 )
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                            break;
                        }

                        sRC = mSearchNextGTCompare ( &aNode, aDataSlot, aNextKey, aTransID, aExtraKey, aKey );
                        return sRC;
                    }
                }
            } /* for */
        }
        else //if ( aEQCnt == 1 )
        {
            for ( i = 0; i < aNode->mIndexSlotHeader.mNodeCount; ++i )
            {
                /* sCmpData1  첫번째 컬럼 같고 두번째 컬럼이 큰가 */
                /* 두번째 argument  기준으로 비교 */
                //sCmpData1 = mIndexCompare ( sKey, INDEX_POS( aNode, i, sKeySize ), DBM_GT2 );
                sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, sKey, INDEX_POS( aNode, i, sKeySize ), DBM_GT, aEQCnt );

                if ( sCmpData1 )
                {
                    /* aKey 값보다 하나 더큼값의 data slot 값을 반환한다 */
                    *aDataSlot = aNode->mRID[i];
                    memcpy_s ( *aNextKey, INDEX_POS( aNode, i, sKeySize ), sKeySize );
                    *aExtraKey = *(long long*) ( INDEX_POS( aNode, i, sKeySize ) + sKeySize2 ); // NextKey에서 aExtra value 구하여 반환한다

                    sRC = RC_SUCCESS;
                    break;
                }
                else
                {
                    /* i 값과 mNodeCount-1 한값이 같다면 i의 값이 마지막 node 값이라는 것을 알 수 있다 */
                    if ( i == ( aNode->mIndexSlotHeader.mNodeCount - 1 ) )
                    {

                        /* mLeafNextID -1 이라는 것은 앞의 slot이 없다는 것이다 결국 -1이라는 것은
                         * 데이터가 없다는 것이니 오류로 리턴하자 */
                        if ( aNode->mIndexSlotHeader.mLeafNextID < 0 )
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                            break;
                        }

                        sRC = mSegMgr->Slot2Addr ( aNode->mIndexSlotHeader.mLeafNextID, &sNextNode );
                        if ( unlikely( sRC != 0 ) ) // || sNextNode == NULL, SLOT2ADDR_FAIL );
                        {
                            DBM_ERR( "mSearchNextGT slot2addr change fail [%d]", sRC );
                            mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
                            _THROW( ERR_DBM_SLOT2ADDR_FAIL );
                        }

                        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );

                        /* Next leaf lock */
                        _CALL( mLockMgr->mSpinLock ( &sNextNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        /* 값이 있다면 NodeCount 0보다 항상 커야 하고 mLeafNextID 항상 0보다 커야 한다 */
                        if ( sNextNode->mIndexSlotHeader.mNodeCount > 0 && aNode->mIndexSlotHeader.mLeafNextID >= 0 )
                        {
                            /* 첫번째 컬럼이 같고 두번재 컬럼이 큰가 체크 */
                            //sCmpData1 = mIndexCompare ( sKey, INDEX_POS( sNextNode, 0, sKeySize ), DBM_GT2 );
                            sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, sKey, INDEX_POS( sNextNode, 0, sKeySize ), DBM_GT, aEQCnt );

                            if ( sCmpData1 )
                            {
                                *aDataSlot = sNextNode->mRID[0];
                                memcpy_s ( *aNextKey, INDEX_POS( sNextNode, 0, sKeySize ), sKeySize );
                                *aExtraKey = *(long long*) ( INDEX_POS( sNextNode, 0, sKeySize ) + sKeySize2 ); // NextKey에서 aExtra value 구하여 반환한다
                                sRC = RC_SUCCESS;
                            }
                            else
                            {
                                sRC = ERR_DBM_KEY_NOT_EXIST;
                            }
                        }
                        else
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                        }

                        /* Next leaf unlock */
                        mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID );

                        return( sRC );
                    }
                }
            } /* for */
        } /* aEQCnt == 1 */

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        /*********************************************
         * leaf unlock 처리
         *********************************************/
        mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );

        _THROW( sRC );
    }
    _CATCH
    {
        if ( _rc != RC_SUCCESS )
        {
            if ( _rc == ERR_DBM_KEY_NOT_EXIST )
            {
                _CATCH_TRC;
            }
            else
            {
                _CATCH_WARN;
            }
        }
    }
    _FINALLY
    _END
} /* mSearchNextExtraGT */


/********************************************************************
 * ID : mSearchNextExtraLT
 *
 * Description (non-unique index type )
 *   dbm Index search key Prev
 *   입력받은 key 보다 하나 더작은 값을 반환한다.
 *
 * Argument
 *     aNode    : input : input key value 있는 노드의 pointer
 *     aKey     : input : input key data value
 *     aDataSlot: output: search 하여 찾은 data ID
 *     aTransID : input : Transaction ID
 *     aPrevKey : output: 입력 받은 key 보다 하나 더작은 key
 *
********************************************************************/
int dbmIndexManager::mSearchNextExtraLT ( dbmIndexNode* aNode , char* aKey , long long* aDataSlot , int aTransID , char** aPrevKey , long long* aExtraKey , int aEQCnt )
{
    dbmIndexNode*   sPrevNode;
    int     sKeySize;
    int     sKeySize2;
    char    sKey[INDEX_KEY_SIZE(mIndexHeader->mIndex.mKeySize)];
    int     sCmpData1;
    int     sCmpData2;
    int     sRC;
    int     sRC2;
    int     i;

    /*
     * TODO: 2014.09.30 -okt- [TryCatch] 내부에서 직접 return 하지 않는것이 바람직하나.
     *  1. 성능 함수의 경우 점프비용도 있을수는 있고.
     *  2. mSearchNextGTNu 를 고치다가 몇번 원복해서.. 포기.
     */
    _TRY
    {
        //_DASSERT( aEQCnt == 0 || aEQCnt == 1 ); //, ERR_DBM_INVALID_DATATYPE );
        _DASSERT( aEQCnt >= 0 ); //, ERR_DBM_INVALID_DATATYPE );

        sRC = ERR_DBM_KEY_NOT_EXIST;
        sCmpData1 = 0;  // 같은가
        sCmpData2 = 0;  // 작은가

        /* 0: 값은키가 없음 */
        _IF_THROW( aNode == NULL, ERR_DBM_KEY_NOT_EXIST ); //KEY_VALUE_ERROR );

        // 2014.10.01 -okt- (성능) 특히 'loop' 안에서 hdr->idx->mSize 처럼, 주소를 따라가는 연산을 하지 않는다.
        sKeySize = INDEX_KEY_SIZE( mIndexHeader->mIndex.mKeySize );
        sKeySize2 = mIndexHeader->mIndex.mKeySize;

        /* 초기화 처리 */
        //memset_s ( sKey, 0x00, sizeof( sKey ) ); // 2014.10.15 -okt- 중복, 불필요.

        /* ExtraKey가 있으므로 해당 ExtraKey값을 포함하여 Search 처리 한다 */
        memcpy_s ( sKey, aKey, sKeySize2 );
        *(long long*) ( sKey + sKeySize2 ) = *aExtraKey;

        /******************************************
         * search key node 와 경합해야 한다
         * leaf spin lock 처리
         *******************************************/
        _CALL( mLockMgr->mSpinLock ( &aNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

        if ( aEQCnt == 0 )
        {
            for ( i = aNode->mIndexSlotHeader.mNodeCount - 1; i >= 0; --i )
            {
                /* sCmpData1 같은가 , sCmpData2 작은가 */
                sCmpData1 = mIndexCompare ( sKey, INDEX_POS( aNode, i, sKeySize ), DBM_EQ );
                sCmpData2 = mIndexCompare ( sKey, INDEX_POS( aNode, i, sKeySize ), DBM_LT );

                if ( sCmpData2 == 1 )
                {
                    /* aKey 값보다 하나 작은 값의 data slot 값을 반환한다 */
                    *aDataSlot = aNode->mRID[i];
                    memcpy_s ( *aPrevKey, INDEX_POS( aNode, i, sKeySize ), sKeySize );

                    /* NextKey에서 aExtra value 구하여 반환한다 */
                    *aExtraKey = *(long long*) ( INDEX_POS( aNode, i, sKeySize ) + sKeySize2 );

                    sRC = RC_SUCCESS;
                    break;
                }

                if ( sCmpData1 )
                {
                    if ( i == 0 )
                    {
                        /* mLeafPrevID -1 이라는 것은 전의 해당 slot이 없다는 것이다.*/
                        if ( aNode->mIndexSlotHeader.mLeafPrevID < 0 )
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                            break;
                        }

                        // 2014.12.14. -okt- 함수내부에서 락을 풀고 있다. - aNode->mIndexSlotHeader.mLock
                        sRC = mSearchNextLTCompare ( &aNode, aDataSlot, aPrevKey, aTransID, aExtraKey, aKey );
                        return( sRC );
                    }
                    else
                    {
                        /* aKey 값보다 하나 작은 값의 data slot 값을 반환한다 */
                        *aDataSlot = aNode->mRID[i - 1];
                        memcpy_s ( *aPrevKey, INDEX_POS( aNode, i - 1, sKeySize ), sKeySize );
                        *aExtraKey = *(long long*) ( INDEX_POS( aNode, i - 1, sKeySize ) + sKeySize2 ); // PrevKey에서 aExtra value 구하여 반환

                        sRC = RC_SUCCESS;
                    }

                    break;
                }
            } /* for */
        }
        else //if ( aEQCnt == 1 )
        {
            for ( i = aNode->mIndexSlotHeader.mNodeCount - 1; i >= 0; --i )
            {
                /* sCmpData1 같은면서 작은가 */
                //sCmpData1 = mIndexCompare ( sKey, INDEX_POS( aNode, i, sKeySize ), DBM_LT2 );
                sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, sKey, INDEX_POS( aNode, i, sKeySize ), DBM_LT, aEQCnt );

                if ( sCmpData1 )
                {
                    /* aKey 값보다 하나 작은 값의 data slot 값을 반환한다 */
                    *aDataSlot = aNode->mRID[i];
                    memcpy_s ( *aPrevKey, INDEX_POS( aNode, i, sKeySize ), sKeySize );
                    *aExtraKey = *(long long*) ( INDEX_POS( aNode, i, sKeySize ) + sKeySize2 ); // PrevKey에서 aExtra value 구하여 반환

                    sRC = RC_SUCCESS;
                    break;
                }
                else
                {
                    if ( i == 0 )
                    {
                        /* mLeafPrevID -1 이라는 것은 전의 해당 slot이 없다는 것이다.*/
                        if ( aNode->mIndexSlotHeader.mLeafPrevID < 0 )
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                            break;
                        }

                        sRC = mSegMgr->Slot2Addr ( aNode->mIndexSlotHeader.mLeafPrevID, &sPrevNode );
                        if ( unlikely( sRC ) ) //|| sPrevNode == NULL, SLOT2ADDR_FAIL );
                        {
                            DBM_ERR( "mSearchNextGT slot2addr change fail [%d]", sRC );
                            mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );
                            _THROW( ERR_DBM_SLOT2ADDR_FAIL );
                        }

                        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );

                        /* Prev leaf lock */
                        _CALL( mLockMgr->mSpinLock ( &sPrevNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                        if ( sPrevNode->mIndexSlotHeader.mNodeCount > 0 )
                        {
                            /* 첫번째 컬럼이 같고 두번재 컬럼이 큰가 체크 */
                            sCmpData1 = dbmIdxIndexCompare ( this->mIndexHeader, sKey,
                                                        INDEX_POS( sPrevNode, sPrevNode->mIndexSlotHeader.mNodeCount - 1, sKeySize ),
                                                        //DBM_LT2 );
                                                        DBM_LT, aEQCnt );
                            if ( sCmpData1 )
                            {
                                *aDataSlot = sPrevNode->mRID[sPrevNode->mIndexSlotHeader.mNodeCount - 1];
                                memcpy_s ( *aPrevKey,
                                           INDEX_POS( sPrevNode, sPrevNode->mIndexSlotHeader.mNodeCount - 1, sKeySize ),
                                           sKeySize );
                                *aExtraKey = *(long long*) ( INDEX_POS( sPrevNode, sPrevNode->mIndexSlotHeader.mNodeCount - 1, sKeySize ) + sKeySize2 ); // PrevKey에서 aExtra value 구하여 반환

                                sRC = RC_SUCCESS;
                            }
                            else
                            {
                                sRC = ERR_DBM_KEY_NOT_EXIST;
                            }
                        }
                        else
                        {
                            sRC = ERR_DBM_KEY_NOT_EXIST;
                        }

                        /* Prev leaf unlock */
                        mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID );

                        return( sRC );
                    }
                }
            } /* for */
        } /* else */

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        /*********************************************
         * leaf unlock 처리
         *********************************************/
        mvpAtomicCas32_s( &aNode->mIndexSlotHeader.mLock, -1, aTransID );

        _THROW( sRC );
    }
    _CATCH
    {
        if ( _rc != RC_SUCCESS )
        {
            if ( _rc == ERR_DBM_KEY_NOT_EXIST )
            {
                _CATCH_TRC;
            }
            else
            {
                _CATCH_WARN;
            }
        }
    }
    _FINALLY
    _END
} /* mSearchNextExtraLT */


/********************************************************************
 * ID : mSearchNextGTCompare
 *
 * Description
 *   dbm Index search key Next
 *   SearchNextGT 에서의 Next Segment address 가지고 와서 해당 값을
 *   리턴 한다.
 *
 * Argument
 *     aNode    : input : key가 저장되어 있는 노드의 포인터
 *     aDataSlot: output: data slot id
 *     aNextKey : output: input key의 next key value
 *     aTransID : input : Transaction ID
 *     aExtraKey: output: output key
 *
********************************************************************/
int dbmIndexManager::mSearchNextGTCompare ( dbmIndexNode** aNode , long long* aDataSlot , char** aNextKey ,
                                            int aTransID , long long* aExtraKey, char* aKey  )
{
    dbmIndexNode*   sNode;
    dbmIndexNode*   sNextNode;
    long long sLeafNextID;
    int     sRC;
    char    sKey[mIndexHeader->mIndex.mKeySize];

    _TRY
    {
        sNode = *aNode;
        sLeafNextID = sNode->mIndexSlotHeader.mLeafNextID; // 2014.10.14 -okt- 락을 풀고. 조회하고 있음

        /* Segment Address 변환 */
        sRC = mSegMgr->Slot2Addr ( sLeafNextID, &sNextNode );
        if ( unlikely( sRC != 0 ) )
        {
            DBM_ERR( "mSearchNextGT slot2addr change fail [%d]", sRC );
            mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID );
            _THROW( ERR_DBM_SLOT2ADDR_FAIL );
        }

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가, 이거 없거나, 위치 내리면 무한대기 */
        mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID ); // leaf unlock 처리

        _CALL( mLockMgr->mSpinLock ( &sNextNode->mIndexSlotHeader.mLock, NULL, aTransID ) ); // Next leaf lock

        /* 값이 있다면 NodeCount 0보다 항상 커야 하고 mLeafNextID 항상 0보다 커야 한다 */
        if ( likely( sNextNode->mIndexSlotHeader.mNodeCount > 0 && sLeafNextID >= 0 ) )
        {
            int     sKeySize = INDEX_KEY_SIZE( mIndexHeader->mIndex.mKeySize );
            char*   sPos2 = INDEX_POS( sNextNode, 0, sKeySize );

#if 0
            *aDataSlot = sNextNode->mRID[ 0 ];
            memcpy_s ( *aNextKey, sPos2, sKeySize );
            *aExtraKey = *(long long*) ( sPos2 + mIndexHeader->mIndex.mKeySize ); // NextKey에서 aExtra value 구하여 반환한다

            sRC = RC_SUCCESS;
#else


            /* 옥섭님 수정 : Tree 조정시 next node에 대하여 next id segment가 동일 key 값이 올 수 
             * 있다는 가정하에 동일 key값이 있으면 오류 처리를 하려고 했던 것으로 보인다 */
            /* 문제가 있던 부분은 aKey에 실제 key 값많이 아닌 extra값이 같이 들어오는 경우가 있다.
             * 실제 extra key 값은 없어야 한다 */
            /* 초기화는 하지 않아도 되겄지 */
            memcpy_s ( sKey, aKey, mIndexHeader->mIndex.mKeySize );

            if ( mIndexCompare ( sKey, sPos2, DBM_EQ ) == 0 )
            {
                *aDataSlot = sNextNode->mRID[ 0 ];
                memcpy_s ( *aNextKey, sPos2, sKeySize );
                *aExtraKey = *(long long*) ( sPos2 + mIndexHeader->mIndex.mKeySize ); // NextKey에서 aExtra value 구하여 반환

                sRC = RC_SUCCESS;
            }
            else
            {
                /* 다시 비교처리 하기 위하여 aNode에 next node pointer 값을 넘겨준다 */
                *aNode = sNextNode;

                sRC = ERR_DBM_DUP_ERROR; // 상위단에서 이걸 검사하고 있음.
            }
#endif
        }
        else
        {
            sRC = ERR_DBM_KEY_NOT_EXIST;
        }

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        mvpAtomicCas32_s( &sNextNode->mIndexSlotHeader.mLock, -1, aTransID ); // Next leaf unlock

        return( sRC );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mSearchNextGTCompare */


/********************************************************************
 * ID : mSearchNextLTCompare
 *
 * Description
 *   dbm Index search key  Prev
 *   SearchNextLT 에서의 Prev Segment address 가지고 와서 해당 값을
 *   리턴 한다.
 *
 * Argument
 *     aNode    : input : key가 저장되어 있는 노드의 포인터
 *     aDataSlot: output: data slot id
 *     aPrevKey : output: input key의 next key value
 *     aTransID : input : Transaction ID
 *     aExtraKey: output: output key
 *
********************************************************************/
int dbmIndexManager::mSearchNextLTCompare ( dbmIndexNode** aNode , long long* aDataSlot , char** aPrevKey ,
                                            int aTransID , long long* aExtraKey , char* aKey )
{
    dbmIndexNode*   sNode;
    dbmIndexNode*   sPrevNode;
    long long sLeafPrevID;
    int     sRC;

    _TRY
    {
        sNode = *aNode;
        sLeafPrevID = sNode->mIndexSlotHeader.mLeafPrevID; // 2014.10.14 -okt- 락을 풀고. 조회하고 있음

        /* Segment Address 변환 */
        sRC = mSegMgr->Slot2Addr ( sLeafPrevID, &sPrevNode );
        if ( unlikely( sRC != 0 ) )
        {
            DBM_ERR( "mSearchNextLTCompare mSearchNextLT slot2addr change fail [%d]", sRC );
            mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID );
            _THROW( ERR_DBM_SLOT2ADDR_FAIL );
        }

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가, 이거 없거나, 위치 내리면 무한대기 */
        mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID ); // leaf unlock 처리

        _CALL( mLockMgr->mSpinLock ( &sPrevNode->mIndexSlotHeader.mLock, NULL, aTransID ) ); // Next leaf lock

        /* 값이 있다면 NodeCount 0보다 항상 커야 하고 mLeafNextID 항상 0보다 커야 한다 */
        if ( likely( sPrevNode->mIndexSlotHeader.mNodeCount > 0 && sLeafPrevID >= 0 ) )
        {
            int     sKeySize = INDEX_KEY_SIZE( mIndexHeader->mIndex.mKeySize );
            char*   sPos2 = INDEX_POS( sPrevNode, sPrevNode->mIndexSlotHeader.mNodeCount - 1, sKeySize );

            if ( mIndexCompare ( aKey, sPos2, DBM_EQ ) == 0 )
            {
                *aDataSlot = sPrevNode->mRID[sPrevNode->mIndexSlotHeader.mNodeCount - 1];
                memcpy_s ( *aPrevKey, sPos2, sKeySize );
                *aExtraKey = *(long long*) ( sPos2 + mIndexHeader->mIndex.mKeySize ); // NextKey에서 aExtra value 구하여 반환

                sRC = RC_SUCCESS;
            }
            else
            {
                /* 다시 비교처리 하기 위하여 aNode에 prev node pointer 값을 넘겨준다 */
                *aNode = sPrevNode;

                sRC = ERR_DBM_DUP_ERROR; // 상위단에서 이걸 검사하고 있음.
            }
        }
        else
        {
            sRC = ERR_DBM_KEY_NOT_EXIST;
        }

        /* 2014.03.19 -shw- lock 경합으로 인하여 추가 */
        mvpAtomicCas32_s( &sPrevNode->mIndexSlotHeader.mLock, -1, aTransID ); // Next leaf unlock

        return( sRC );
    }
    _CATCH
    {
        _CATCH_WARN;
    }
    _FINALLY
    _END
} /* mSearchNextLTCompare */

_VOID dbmIndexManager::mMax ( int aTransID , dbmIndexNode* aNode, int* aNodeNo, int* aDepth, long long* aRID, char* aKey )
{
    dbmIndexNode*   sNode;
    dbmIndexNode*   sChild;
    long long sRID;
    long long sPrevNode;
    int     sKeySize;
    int     sCount;
    int     sPosition;
    int     sDepthChkCnt;
    int     sFirStNodeCheck;
    int     sIndexCheck;

    _TRY
    {
        sKeySize = mIndexHeader->mIndex.mKeySize;
        sIndexCheck = 0;
        sRID = *aRID;
repeat:
        /* Index Tree Check */
        if( mIndexHeader->mTreeCheck  == 1 )
        {
            pthread_yield_s ();
            goto repeat;
        }

        sChild = NULL;

        if( aNode == NULL )
        {
            _CALL( mSegMgr->Slot2Addr ( mIndexHeader->mRootPid, &sNode ) );
            *aDepth = 0;
            sFirStNodeCheck = 0;
        }
        else
        {
            sNode = aNode;
            sFirStNodeCheck = 1;
        }

        /*************************************************
        * data null check
        *************************************************/
        if ( unlikely( sNode->mIndexSlotHeader.mNodeCount <= 0 && sNode->mChild[0] < 0 ) )
        {
            DBM_TRC( "Index Root data not found. [%lld][%lld]", sNode->mChild[0], sNode->mChild[1] );
            _THROW( ERR_DBM_KEY_NOT_EXIST );
        }

        do
        {
            /* root 아래에 leaf 분기 되면 자식 노드는 0 부터 분기 된다 2:root 0:left leaf 1:right leaf */
            if ( sNode->mIndexSlotHeader.mLeafcheck == 1 )
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                /******************************************
                 * search key node 와 경합해야 한다
                 * leaf spin lock 처리
                 *******************************************/
                _CALL( mLockMgr->mSpinLock ( &sNode->mIndexSlotHeader.mLock, NULL, aTransID ) );
                /* 제일 처음일때 root의 분기 처리가 되었을 경우 lock 체크를 할 수 없기에
                 * 처음일 경우 mRootSlotID가 있다는 것은 leaf가 아니므로 재처리 한다 */
                if ( sFirStNodeCheck == 0 )
                {
                    if ( sNode->mIndexSlotHeader.mRootSlotID > 0 )
                    {
                        /* undo process */
                        mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID );

                        /* 계속 looping 인데 방어 코드가 있어야 하는거 아닌가 */
                        DBM_DBG( "First Select mRootSlotID [%d] goto", sNode->mIndexSlotHeader.mRootSlotID );
                        pthread_yield_d ( );    //TODO: 2014.09.29 -okt- 넣을까 말까? "_d"는 안 넣은거다.
                        goto repeat;
                    }
                }
                /* undo process */
                mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID );
                if( *aNodeNo < 0 )
                {
                    *aRID = sNode->mRID[sNode->mIndexSlotHeader.mNodeCount - 1];
                    memcpy_s ( aKey, INDEX_POS( sNode, sNode->mIndexSlotHeader.mNodeCount - 1, sKeySize ), sKeySize );
                    *aNodeNo = sNode->mIndexSlotHeader.mNodeCount - 1;
                }
                else
                {
                    if( *aNodeNo == 0 )
                    {
                        if ( sNode->mIndexSlotHeader.mLeafPrevID < 0 )
                        {
                            _THROW( ERR_DBM_KEY_NOT_EXIST );
                        }

                        sPrevNode = sNode->mIndexSlotHeader.mLeafPrevID;
                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID );
                        _CALL( mSegMgr->Slot2Addr ( sPrevNode, &sNode ) );
                        _CALL( mLockMgr->mSpinLock ( &sNode->mIndexSlotHeader.mLock, NULL, aTransID ) );
                        if ( sNode->mIndexSlotHeader.mNodeCount > 0 )
                        {
                            *aRID = sNode->mRID[sNode->mIndexSlotHeader.mNodeCount - 1];
                            memcpy_s ( aKey, INDEX_POS( sNode, sNode->mIndexSlotHeader.mNodeCount - 1, sKeySize ), sKeySize );
                            *aNodeNo = sNode->mIndexSlotHeader.mNodeCount - 1;
                        }
                        else
                        {
                            _THROW( ERR_DBM_KEY_NOT_EXIST );
                        }
                    }
                    else
                    {
                        *aRID = sNode->mRID[*aNodeNo - 1];
                        memcpy_s ( aKey, INDEX_POS( sNode, *aNodeNo - 1, sKeySize ), sKeySize );
                        *aNodeNo -= 1;
                    }
                }
                aNode = sNode;
                _RETURN;
            }
            else
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                /* Search LT Lock Try */
                _CALL( mLockMgr->mSpinLock( &sNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                //TODO:fhan sNode->mChild[sNode->mIndexSlotHeader.mNodeCount]의 의미를 모르겠다...
                if ( sNode->mChild[sNode->mIndexSlotHeader.mNodeCount] == -1 )
                {
                    mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID );
                    DBM_DBG( "slef[%lld] mchild[%lld] position[%d]", pthread_self(), sNode->mChild[0], 0 );
                    if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR3 );
                    {
                        DBM_ERR( "index depth max error [%d]", sIndexCheck );
                        _THROW( ERR_DBM_DEPTH_FAIL );
                    }

                    goto repeat;
                }
                _CALL( mSegMgr->Slot2Addr ( sNode->mChild[sNode->mIndexSlotHeader.mNodeCount], &sChild ) );
                mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID );
                sNode = sChild;
                *aDepth += 1;
            }

            sFirStNodeCheck = 1;

            if ( unlikely( *aDepth > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR );
            {
                DBM_ERR( "index depth max error [%d]", *aDepth );
                _THROW( ERR_DBM_DEPTH_FAIL );
            }

        } while ( 1 );
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_KEY_NOT_EXIST )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
}

_VOID dbmIndexManager::mMin ( int aTransID , dbmIndexNode* aNode, int* aNodeNo, int* aDepth, long long* aRID, char* aKey )
{
    dbmIndexNode*   sNode;
    dbmIndexNode*   sChild;

    long long sRID;
    long long sNextNode;
    int     sKeySize;
    int     sCount;
    int     sPosition;
    int     sFirStNodeCheck;
    int     sIndexCheck;

    _TRY
    {
        sKeySize = mIndexHeader->mIndex.mKeySize;
        sIndexCheck = 0;
        sRID = *aRID;
repeat:
        /* Index Tree Check */
        if( mIndexHeader->mTreeCheck  == 1 )
        {
            pthread_yield_s ();
            goto repeat;
        }

        sChild = NULL;

        if( aNode == NULL )
        {
            _CALL( mSegMgr->Slot2Addr ( mIndexHeader->mRootPid, &sNode ) );
            *aDepth = 0;
            sFirStNodeCheck = 0;
        }
        else
        {
            sNode = aNode;
            sFirStNodeCheck = 1;
        }

        /*************************************************
        * data null check
        *************************************************/
        if ( unlikely( sNode->mIndexSlotHeader.mNodeCount <= 0 && sNode->mChild[0] < 0 ) )
        {
            DBM_TRC( "Index Root data not found. [%lld][%lld]", sNode->mChild[0], sNode->mChild[1] );
            _THROW( ERR_DBM_KEY_NOT_EXIST );
        }

        do
        {
            /* root 아래에 leaf 분기 되면 자식 노드는 0 부터 분기 된다 2:root 0:left leaf 1:right leaf */
            if ( sNode->mIndexSlotHeader.mLeafcheck == 1 )
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                /******************************************
                 * search key node 와 경합해야 한다
                 * leaf spin lock 처리
                 *******************************************/
                _CALL( mLockMgr->mSpinLock ( &sNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                /* 제일 처음일때 root의 분기 처리가 되었을 경우 lock 체크를 할 수 없기에
                 * 처음일 경우 mRootSlotID가 있다는 것은 leaf가 아니므로 재처리 한다 */
                if ( sFirStNodeCheck == 0 )
                {
                    if ( sNode->mIndexSlotHeader.mRootSlotID > 0 )
                    {
                        /* undo process */
                        mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID );

                        /* 계속 looping 인데 방어 코드가 있어야 하는거 아닌가 */
                        DBM_DBG( "First Select mRootSlotID [%d] goto", sNode->mIndexSlotHeader.mRootSlotID );
                        pthread_yield_d ( );    //TODO: 2014.09.29 -okt- 넣을까 말까? "_d"는 안 넣은거다.
                        goto repeat;
                    }
                }
                /* undo process */
                mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID );
                if( *aNodeNo < 0 )
                {
                    *aRID = sNode->mRID[0];
                    memcpy_s ( aKey, INDEX_POS( sNode, 0, sKeySize ), sKeySize );
                    *aNodeNo = 0;
                }
                else
                {
                    /* aNodeNo 값과 mNodeCount-1 한값이 같다면 aNodeNo의 값이 마지막 node 값이라는 것을 알 수 있다 */
                    if( *aNodeNo == sNode->mIndexSlotHeader.mNodeCount - 1 )
                    {
                        if ( sNode->mIndexSlotHeader.mLeafNextID < 0 )
                        {
                            _THROW( ERR_DBM_KEY_NOT_EXIST );
                        }

                        sNextNode = sNode->mIndexSlotHeader.mLeafNextID;
                        /*********************************************
                         * leaf unlock 처리
                         *********************************************/
                        mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID );

                        _CALL( mSegMgr->Slot2Addr ( sNextNode, &sNode ) );
                        _CALL( mLockMgr->mSpinLock ( &sNode->mIndexSlotHeader.mLock, NULL, aTransID ) );
                        if ( sNode->mIndexSlotHeader.mNodeCount > 0 )
                        {
                            *aRID = sNode->mRID[0];
                            memcpy_s ( aKey, INDEX_POS( sNode, 0, sKeySize ), sKeySize );
                            *aNodeNo = 0;
                        }
                        else
                        {
                            _THROW( ERR_DBM_KEY_NOT_EXIST );
                        }
                    }
                    else
                    {
                        *aRID = sNode->mRID[*aNodeNo + 1];
                        memcpy_s ( aKey, INDEX_POS( sNode, *aNodeNo + 1, sKeySize ), sKeySize );
                        *aNodeNo += 1;
                    }
                }
                aNode = sNode;
                _RETURN;
            }
            else
            {
                /* Index Tree Check */
                if( mIndexHeader->mTreeCheck  == 1 )
                {
                    pthread_yield_s ();
                    goto repeat;
                }

                /* Search GT Lock Try */
                _CALL( mLockMgr->mSpinLock( &sNode->mIndexSlotHeader.mLock, NULL, aTransID ) );

                if ( sNode->mChild[0] == -1 )
                {
                    mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID );
                    DBM_DBG( "slef[%lld] mchild[%lld] position[%d]", pthread_self(), sNode->mChild[0], 0 );
                    if ( unlikely( sIndexCheck > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR3 );
                    {
                        DBM_ERR( "index depth max error [%d]", sIndexCheck );
                        _THROW( ERR_DBM_DEPTH_FAIL );
                    }

                    goto repeat;
                }
                _CALL( mSegMgr->Slot2Addr ( sNode->mChild[0], &sChild ) );
                mvpAtomicCas32_s( &sNode->mIndexSlotHeader.mLock, -1, aTransID );
                sNode = sChild;
                *aDepth += 1;
            }

            sFirStNodeCheck = 1;

            if ( unlikely( *aDepth > DBM_INDEX_DEPTH_MAX ) ) //, INDEX_DEPTH_ERROR );
            {
                DBM_ERR( "index depth max error [%d]", *aDepth );
                _THROW( ERR_DBM_DEPTH_FAIL );
            }

        } while ( 1 );
    }
    _CATCH
    {
        if ( _rc != ERR_DBM_KEY_NOT_EXIST )
        {
            _CATCH_WARN;
        }
    }
    _FINALLY
    _END
}
