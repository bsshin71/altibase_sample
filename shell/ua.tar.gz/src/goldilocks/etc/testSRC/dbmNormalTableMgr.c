/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *******************************************************************************/
#include <dbmTableInterface.h>
#include <dbmNormalTableMgr.h>
#include <cmnError.h>
#include <cmnShm.h>




/******************************************************************************
 * Name : dbmInternalCreateNormalTable
 *
 * Description
 *   새로운 Btree용 대응 테이블을 1개 생성하는 과정을 처리한다.
 *   생성시 Slot정보를 같이 저장해야 해서 이 크기를 역계산해서 덧붙힌다.
 *   따라서, 사용자가 지정한 크기보다는 조금 더 큰 Segment로 생성됨.
 *   결과적으로 TABLE_SIZE = ( TABLE_HEADER ) + ( SLOT_AREA ) + ( DATA_AREA ) 3가지로 엮인다.
 *
 * Argument
 *   aArg   : input   : dbmCreateArg 참조
 *
 * Return
 ******************************************************************************/
int dbmInternalCreateNormalTable( void* aArg )
{
    dbmNormalTableHeader*   sTableHdr;
    dbmTableCreateArg*      sCreateArg;
    dbmTableAttachArg       sAttachArg;
    char*                   sShmPtr = NULL;
    char                    sKeyString [1024];
    int                     sRC;


    /*******************************************************
     * 상위 함수에서 넘긴 인자를 맵핑한다.
     *******************************************************/
    sCreateArg = (dbmTableCreateArg*)aArg;

    /*******************************************************
     * 테이블의 Object ID 획득.
     * Dictionary에서 획득할건데 없다면 실패.
     *******************************************************/
    sRC = dbmGetNewObjectID( &sCreateArg->mObjectID );
    _IF_RAISE( ( sRC || sCreateArg->mObjectID < 0), GET_OBJECT_ID_FAIL );

    /********************************************************
     * Shared memory를 먼저 생성한다.
     * 여기서 Size는 Parsing된 init size라고 봐야 함.
     * Slot Area를 계산해서 덧붙힌다.
     ********************************************************/
    TABLE_KEY_NAME( sKeyString, sCreateArg->mUserName, sCreateArg->mTableName, 0 );
    sRC = cmnShmCreate( sKeyString, TABLE_AREA_SIZE( sCreateArg->mInitSize, sCreateArg->mRecordSize ) );
    _IF_RAISE( sRC, CREATE_FAIL );


    /*******************************************************
     * Shared memory에 Attach한다.
     *******************************************************/
    memset_s( &sAttachArg, 0x00, sizeof(dbmTableAttachArg) );

    strcpy_s( sAttachArg.mUserName, sCreateArg->mUserName );
    strcpy_s( sAttachArg.mTableName, sCreateArg->mTableName );
    sAttachArg.mSegNo      = 0;
    sAttachArg.mRecordSize = sCreateArg->mRecordSize;
    sAttachArg.mSize       = sCreateArg->mInitSize;

    sRC = dbmInternalAttachNormalTable( (void*)&sAttachArg, &sShmPtr );
    _IF_RAISE( sRC, ATTACH_FATAL );

    memset_s( sShmPtr, 0x00, sizeof(dbmNormalTableHeader) );

    /*******************************************************
     * Header구조체를 초기화해서 저장한다.
     *******************************************************/
    sTableHdr = (dbmNormalTableHeader*)sShmPtr;

    sTableHdr->mLock       = -1;
    sTableHdr->mSegNo      = 0;
    sTableHdr->mMaxSegNo   = 1;
    sTableHdr->mRecordSize = sCreateArg->mRecordSize;
    sTableHdr->mRecordMax  = ( sCreateArg->mInitSize / sCreateArg->mRecordSize );
    sTableHdr->mObjectID   = sCreateArg->mObjectID;
    sTableHdr->mIndexNum   = 0;
    sTableHdr->mAllocInd   = -1;
    sTableHdr->mFreeInd    = sTableHdr->mRecordMax - 1;
    sTableHdr->mSegSize    = sCreateArg->mInitSize;
    sTableHdr->mExtendSize = sCreateArg->mExtendSize;
    strcpy_s( sTableHdr->mUserName, sCreateArg->mUserName );
    strcpy_s( sTableHdr->mTableName, sCreateArg->mTableName );
    gettimeofday( &sTableHdr->mCreateTime, NULL );
    gettimeofday( &sTableHdr->mTruncTime,  NULL );

    /*******************************************************
     * Slot을 초기화 시킨다.
     *******************************************************/
    sRC = dbmInitSlotArea( sShmPtr );
    _IF_RAISE( sRC, INIT_SLOT_FATAL );

    sRC = cmnShmDetach( sShmPtr );
    return RC_SUCCESS;


    /*******************************************************
     * 에러 발생
     *******************************************************/
    _EXCEPTION( GET_OBJECT_ID_FAIL )
    {
        sRC = ERR_DBM_GET_OBJECT_ID_FAIL;
    }

    _EXCEPTION( CREATE_FAIL )
    {
        fprintf( stdout, "Create failed rc = %d\n", sRC );
        sRC = ERR_DBM_CREATE_TABLE_FAIL;
    }

    _EXCEPTION( ATTACH_FATAL )
    {
        fprintf( stdout, "Create failed rc = %d\n", sRC );
        sRC = ERR_DBM_CREATE_TABLE_FAIL;
    }

    _EXCEPTION( INIT_SLOT_FATAL )
    {
        fprintf( stdout, "Init failed rc = %d\n", sRC );
        sRC = ERR_DBM_INIT_TABLE_FAIL;
    }
    _EXCEPTION_END;
    if ( sShmPtr != NULL )
    {
        cmnShmDetach( sShmPtr );
    }
    return sRC;
}






/******************************************************************************
 * Name : dbmInternalExtendNormalTable
 *
 * Description
 *   테이블을 확장할때 처리한다.
 *
 * Argument
 *   adArg : input  : dbmExtendArg 구조체
 *   aSeqNo: input  : 확장시 만들어진 SegNo이다.
 *
 * Return
 ******************************************************************************/
int dbmInternalExtendNormalTable( void* aArg,  int* aSegNo )
{
    dbmNormalTableHeader*   sTableHdr;
    dbmNormalTableHeader*   sExtendHdr;
    dbmTableExtendArg*      sExtendArg;
    dbmTableAttachArg       sAttachArg;
    long                    sObjectID = -1;
    char                    sKeyString [1024];
    char*                   sShmPtr = NULL;
    int                     sRC;


    /********************************************************
     * Argument, TableHeader 맵핑.
     ********************************************************/
    *aSegNo = -1;
    sExtendArg = (dbmTableExtendArg*)aArg;

    sTableHdr = (dbmNormalTableHeader*)sExtendArg->mMainShmPtr;

    /********************************************************
     * 동시성 제어코드 넣어야 함.
     ********************************************************/


    /********************************************************
     * Shared memory를 먼저 생성한다.
     * KeyString은 main keyString에 SegNo를 붙혀서 만든다.
     * 나머지 웬간한 정보는 main segment에 있는 걸 이용한다.
     ********************************************************/
    *aSegNo = mvpAtomicGet32( &sTableHdr->mMaxSegNo );

    TABLE_KEY_NAME( sKeyString, sTableHdr->mUserName, sTableHdr->mTableName, (*aSegNo) );
    sRC = cmnShmCreate( sKeyString, TABLE_AREA_SIZE( sTableHdr->mExtendSize, sTableHdr->mRecordSize ) );
    _IF_RAISE( sRC, CREATE_FAIL );


    /*******************************************************
     * Shared memory에 Attach한다.
     *******************************************************/
    memset_s( &sAttachArg, 0x00, sizeof(dbmTableAttachArg) );

    strcpy_s( sAttachArg.mUserName,  sTableHdr->mUserName );
    strcpy_s( sAttachArg.mTableName, sTableHdr->mTableName );
    sAttachArg.mSegNo      = (*aSegNo);
    sAttachArg.mRecordSize = sTableHdr->mRecordSize;
    sAttachArg.mSize       = sTableHdr->mExtendSize;

    sRC = dbmInternalAttachNormalTable( (void*)&sAttachArg, &sShmPtr );
    _IF_RAISE( sRC, ATTACH_FATAL );


    /*******************************************************
     * Extended Shared memory에 Table Header를 초기화시킨다.
     *******************************************************/
    memset_s( sShmPtr, 0x00, sizeof(dbmNormalTableHeader) );

    sExtendHdr = (dbmNormalTableHeader*)sShmPtr;

    sExtendHdr->mLock       = -1;
    sExtendHdr->mSegNo      = (*aSegNo);
    sExtendHdr->mRecordSize = sTableHdr->mRecordSize;
    sExtendHdr->mRecordMax  = ( sTableHdr->mExtendSize / sTableHdr->mRecordSize );
    sExtendHdr->mObjectID   = sTableHdr->mObjectID;
    sExtendHdr->mAllocInd   = -1;
    sExtendHdr->mFreeInd    = sTableHdr->mRecordMax - 1;
    sExtendHdr->mSegSize    = sTableHdr->mExtendSize;
    strcpy_s( sExtendHdr->mUserName,  sTableHdr->mUserName );
    strcpy_s( sExtendHdr->mTableName, sTableHdr->mTableName );
    gettimeofday( &sExtendHdr->mCreateTime, NULL );
    gettimeofday( &sExtendHdr->mTruncTime, NULL );

    /*******************************************************
     * Main Shared memory에 SegNo를 증가시킨다.
     *******************************************************/
    sRC = dbmInitSlotArea( sShmPtr );
    _IF_RAISE( sRC, INIT_SLOT_FATAL );

    /*******************************************************
     * Main Shared memory에 SegNo를 증가시킨다.
     *******************************************************/
    mvpAtomicInc32 ( &sTableHdr->mMaxSegNo );

    sRC = cmnShmDetach( sShmPtr );
    return RC_SUCCESS;


    /*******************************************************
     * 에러 발생
     *******************************************************/
    _EXCEPTION( GET_OBJECT_ID_FAIL )
    {
        fprintf( stdout, "OBJECT_ID = rc=%d, sObjectID=%ld\n", sRC, sObjectID );
        sRC = ERR_DBM_GET_OBJECT_ID_FAIL;
    }

    _EXCEPTION( CREATE_FAIL )
    {
        fprintf( stdout, "Create failed rc = %d\n", sRC );
        sRC = ERR_DBM_CREATE_TABLE_FAIL;
    }

    _EXCEPTION( ATTACH_FATAL )
    {
        fprintf( stdout, "Create failed rc = %d\n", sRC );
        sRC = ERR_DBM_CREATE_TABLE_FAIL;
    }

    _EXCEPTION( INIT_SLOT_FATAL )
    {
        fprintf( stdout, "init_slot failed rc = %d\n", sRC );
        sRC = ERR_DBM_CREATE_TABLE_FAIL;
    }

    _EXCEPTION_END;
    if ( sShmPtr != NULL )
    {
        cmnShmDetach( sShmPtr );
    }
    return sRC;
}




/******************************************************************************
 * Name : dbmInternalAttachNormalTable
 *
 * Description
 *   테이블에 Attach하기
 *
 * Argument
 *   aArg      : Attach정보가 담긴 구조체
 *   aShmPtr   : 시작주소
 *
 * Return
 ******************************************************************************/
int dbmInternalAttachNormalTable( void* aArg, char** aShmPtr )
{
    dbmTableAttachArg*  sArg;
    int                 sRC;
    char                sKeyString[1024];


    sArg = (dbmTableAttachArg*)aArg;
    /********************************************************
     * Shared memory를 먼저 생성한다.
     * 여기서 Size는 Parsing된 init size라고 봐야 함.
     * Slot Area를 계산해서 덧붙힌다.
     ********************************************************/
    TABLE_KEY_NAME( sKeyString, sArg->mUserName, sArg->mTableName, sArg->mSegNo );
    sRC = cmnShmAttach( sKeyString
                      , TABLE_AREA_SIZE( sArg->mSize, sArg->mRecordSize )
                      , aShmPtr );
    _IF_RAISE( sRC, ATTACH_FAIL );

    return RC_SUCCESS;

    _EXCEPTION( ATTACH_FAIL )
    {
        sRC = ERR_DBM_ATTACH_SHM_FAIL;
    }

    _EXCEPTION_END;
    return sRC;
}







/******************************************************************************
 * Name : dbmInternalWriteNormalTable
 *
 * Description
 *   테이블에 1건의 데이터를 기록한다.
 *
 * Argument
 *   aArg : dbmDataArg 구조체
 *
 * Return
 ******************************************************************************/
int dbmInternalWriteNormalTable( void* aArg )
{
    dbmNormalTableHeader*   sTableHdr;
    dbmTableDataArg*        sData;
    dbmRowHeader*           sRowHdr;
    int                     sRC;

    sData = (dbmTableDataArg*)aArg;
    /************************************************
     * Table Header를 위치시킨다.
     ************************************************/
    sTableHdr = (dbmNormalTableHeader*)sData->mShmPtr;
    _IF_RAISE( sTableHdr->mRecordSize < sData->mSize, INVALID_RECORD_SIZE );
    _IF_RAISE( sTableHdr->mRecordMax < sData->mSlotOffset, INVALID_OFFSET );

    /************************************************
     * Row Header를 위치시킨다.
     ************************************************/
    sRowHdr = (dbmRowHeader*)RECORD_POS( sData->mShmPtr, sData->mSlotOffset );
    sRowHdr->mSize = sData->mSize;

    /************************************************
     * Offset 위치에 write 한다.
     ************************************************/
    memcpy_s( RECORD_POS( sData->mShmPtr, sData->mSlotOffset ) + sizeof( dbmRowHeader ), sData->mData, sData->mSize );

    return RC_SUCCESS;

    _EXCEPTION( INVALID_RECORD_SIZE )
    {
        sRC = ERR_DBM_INVALID_RECORD_SIZE;
    }

    _EXCEPTION( INVALID_OFFSET )
    {
        sRC = ERR_DBM_INVALID_OFFSET;
    }

    _EXCEPTION_END;
    return sRC;
}




/******************************************************************************
 * Name : dbmInternalReadNormalTable
 *
 * Description
 *   테이블에 1건의 데이터를 기록한다.
 *
 * Argument
 *   aArg : input : dbmDataArg 구조체
 *
 * Return
 ******************************************************************************/
int dbmInternalReadNormalTable( void* aArg )
{
    dbmNormalTableHeader*   sTableHdr;
    dbmTableDataArg*        sData;
    dbmRowHeader*           sRowHdr;


    sData = (dbmTableDataArg*)aArg;
    /************************************************
     * Table Header를 위치시킨다.
     ************************************************/
    sTableHdr = (dbmNormalTableHeader*)sData->mShmPtr;

    /************************************************
     * Row Header를 위치시킨다.
     ************************************************/
    sRowHdr = (dbmRowHeader*)RECORD_POS( sData->mShmPtr, sData->mSlotOffset );

    /************************************************
     * Offset 위치에 Read 한다.
     ************************************************/
    memcpy_s( sData->mData, RECORD_POS( sData->mShmPtr, sData->mSlotOffset ) + sizeof( dbmRowHeader ), sRowHdr->mSize );
    sData->mSize = sRowHdr->mSize;

    return RC_SUCCESS;
}



/******************************************************************************
 * Name : dbmInitSlotArea
 *
 * Description
 *   테이블에 Slot영역을 초기화시킨다.
 *
 * Argument
 *   aShmPtr     : input   : Shared Memory 시작주소 (어떤 segNo를 가진 놈이 될지 모름 )
 *
 * Return
 ******************************************************************************/
int dbmInitSlotArea( char* aShmPtr )
{
    dbmNormalTableHeader* sTableHdr;
    int                     sDummy;
    int                     i;
    char* sPtr;

    /**********************************************
     * Table Header에 붙어서 기본정보를 알아낸다.
     **********************************************/
    sTableHdr = (dbmNormalTableHeader*)aShmPtr;

    /**********************************************
     * memcpy용 변수로 보면 되겠음.
     **********************************************/
    sPtr = SLOT_POS( aShmPtr, 0 );

    /**********************************************
     * Alloc정보를 설정한다.
     **********************************************/
    for( i=0; i<sTableHdr->mRecordMax; i++ )
    {
        sDummy = i;
        memcpy_s( SLOT_POS( aShmPtr, i ), &sDummy, sizeof( int         ) );
    }

    /**********************************************
     * Free정보를 설정한다.
     **********************************************/
    sDummy = DBM_FREE_MARK;
    for( i=sTableHdr->mRecordMax; i<( sTableHdr->mRecordMax* 2); i++ )
    {
        memcpy_s( SLOT_POS( aShmPtr, i ), &sDummy, sizeof( int         ) );
    }

    return RC_SUCCESS;
}




/******************************************************************************
 * Name : dbmNormalAllocSlot
 *
 * Description
 *   테이블에 Slot영역을 할당받는다.
 *
 * Argument
 *   aShmPtr     : input   : Shared Memory 시작주소 (어떤 segNo를 가진 놈이 될지 모름 )
 *   aSlotOffset : output  : 가용한 공간을 리턴받을 변수 포인터
 *
 * Return
 *   SUCCESS / FAIL
 ******************************************************************************/
int dbmNormalAllocSlot( char* aShmPtr,
                                 int* aSlotOffset )
{
    dbmNormalTableHeader* sTableHdr;
    int                   sRC;
    long                  sInd;
    int* sSlot;


    *aSlotOffset = -1;
    sTableHdr = (dbmNormalTableHeader*)aShmPtr;
    _IF_RAISE( mvpAtomicGet64( &sTableHdr->mAllocInd ) == mvpAtomicGet64( &sTableHdr->mFreeInd ), NO_SPACE_FATAL );

    /*****************************************************
     * mAllocInd를 증가시킨 값을 MOD연산을 통해 확인
     *****************************************************/
    sInd = mvpAtomicInc64( &sTableHdr->mAllocInd ) % ( sTableHdr->mRecordMax* 2);
    sSlot = ( int*)SLOT_POS( aShmPtr, sInd );
    _IF_RAISE( (* sSlot ) == DBM_FREE_MARK, NO_SPACE_FATAL );

    /*****************************************************
     * 가용공간이 맞다면 해당 offset번호를 리턴한다.
     *****************************************************/
    *aSlotOffset = mvpAtomicCas32( sSlot, DBM_FREE_MARK,* sSlot );

    return RC_SUCCESS;

    _EXCEPTION( NO_SPACE_FATAL )
    {
        sRC = ERR_DBM_NO_SPACE_IN_TABLE;
    }

    _EXCEPTION_END;
    return sRC;
}





/******************************************************************************
 * Name : dbmNormalFreeSlot
 *
 * Description
 *   테이블에 Slot영역을 해제시킨다.
 *
 * Argument
 *   aArg : dbmSlotArg 구조체
 * Return
 *   SUCCESS / FAIL
 ******************************************************************************/
int dbmNormalFreeSlot( void* aArg )
{
    dbmNormalTableHeader*   sTableHdr;
    dbmTableSlotArg*        sSlotArg;
    int                     sRC;
    long                    sInd;
    int*                    sSlot;


    /*****************************************************
     * argment mapping
     *****************************************************/
    sSlotArg = (dbmTableSlotArg*)aArg;

    /*****************************************************
     * Table Header
     *****************************************************/
    sTableHdr = (dbmNormalTableHeader*)sSlotArg->mShmPtr[0];

    _IF_RAISE( sTableHdr->mRecordMax < sSlotArg->mSlotOffset,    INVALID_OFFSET );

    /*****************************************************
     * mFreeInd를 증가시킨 값을 MOD연산을 통해 확인
     *****************************************************/
    sInd = mvpAtomicInc64( &sTableHdr->mFreeInd ) % ( sTableHdr->mRecordMax* 2);
    sSlot = ( int*)SLOT_POS( sSlotArg->mShmPtr[sSlotArg->mSegNo], sInd );
    _IF_RAISE( (* sSlot ) != DBM_FREE_MARK, FREE_FATAL );

    /*****************************************************
     * Free할 수 있는 공간이 맞다면 셋업한다.
     *****************************************************/
    _IF_RAISE( mvpAtomicCas32( sSlot, sSlotArg->mSlotOffset, DBM_FREE_MARK ) != DBM_FREE_MARK, FREE_FATAL );

    return RC_SUCCESS;

    _EXCEPTION( INVALID_OFFSET )
    {
        sRC = ERR_DBM_INVALID_OFFSET;
    }

    _EXCEPTION( FREE_FATAL )
    {
        sRC = ERR_DBM_FREE_SLOT_FATAL_IN_TABLE;
    }

    _EXCEPTION_END;
    return sRC;
}


/******************************************************************************
 * Name : dbmExtendAllocSlot
 *
 * Description
 *   AllocSlot의 가장 상위 함수처리
 *
 * Argument
 *   aArg : dbmSlotArg구조체
 * Return
 *   SUCCESS / FAIL
 ******************************************************************************/
int dbmExtendAllocSlot( void* aArg )
{
    dbmNormalTableHeader*   sTableHdr;
    dbmNormalTableHeader*   sTmpHdr;
    dbmTableExtendArg       sExtendArg;
    dbmTableAttachArg       sAttachArg;
    dbmTableSlotArg*        sAllocArg;
    int                     i;
    int                     sRC;
    int                     sErrCount = 0;
    int                     sSegNo;
    int                     sSegMax;
    char                    sKeyString[1024];


    sAllocArg = (dbmTableSlotArg*)aArg;

    while ( 1 )
    {
        sTableHdr = (dbmNormalTableHeader*)sAllocArg->mShmPtr[0];
        sSegMax   = mvpAtomicGet32( &sTableHdr->mMaxSegNo );

        /**************************************************************************************
         * 일단은 모든 Segment에 Attach된 상태를 가정해야 한다.
         * 그런데 내가 Alloc중에 누군가는 Extend하고 있을 수 있다.
         * 즉, 나도모르는 aShmPtr이 증가할 수 있다.
         * 이것은 다행히도 mainSegment에서 감지할 수 있다. 왜냐하면 mMaxSegNo가 증가할테니까.
         *
         * 두번째 문제는 mAllocInd, mFreeInd가 따로 증가하니까 동시에 이를 딱 체크할려면
         * Lock을 걸어야 한다. 2 변수를 동시에 읽을 수 없으니까..
         * 근데 걍 한두건 비는걸 너무 신경쓰지말자...그게 차라리 낫지 않을까 싶다.
         *
         * 세번째 문제는 N개의 Segment내에서 빈 공간이 어딘가 찾는문제..
         * 이문제는 Free때도 마찬가지 일듯 ...
         *
         * 일단 테스트 코드에서는 아래처럼 loop를 돌리자.
         **************************************************************************************/
        for( i=0; i<sSegMax; i++ )
        {
            /*******************************************************
             * 공간이 모자르면 내가 직접 Extend해보는 코드
             *******************************************************/
            sTmpHdr = (dbmNormalTableHeader*)sAllocArg->mShmPtr[i];
            if ( sTmpHdr->mAllocInd == sTmpHdr->mFreeInd )   /* this-code is not atomic. */
            {
                continue;
            }

            sRC = dbmNormalAllocSlot( sAllocArg->mShmPtr[i], &sAllocArg->mSlotOffset );
            if ( sRC == RC_SUCCESS )
            {
                sAllocArg->mSegNo = i;
                return RC_SUCCESS;
            }
        }

        /***************************************************
         * 여기까지 왔다면 공간이 없다는 의미.
         * 확장한다.
         ***************************************************/
        _IF_RAISE( sSegMax >= DBM_SEGMENT_MAX, EXTEND_FATAL );
        fprintf( stdout, "Start Extend memory. ( segMax=%d )\n", sSegMax );

        /***************************************************
         * Table Header가 있는 정보를 맵핑해서 확장.
         ***************************************************/
        sExtendArg.mMainShmPtr = sAllocArg->mShmPtr[0];
        sRC = dbmInternalExtendNormalTable( (void*)&sExtendArg, &sSegNo );
        _IF_RAISE( sRC, EXTEND_FATAL );

        /***************************************************
         * 새롭게 확장됬기 때문에 이걸 Attach해줘야 한다.
         ***************************************************/
        memset_s( &sAttachArg, 0x00, sizeof(dbmTableAttachArg) );
        strcpy_s( sAttachArg.mUserName,   sTableHdr->mUserName );
        strcpy_s( sAttachArg.mTableName,  sTableHdr->mTableName );
        sAttachArg.mSegNo      = sSegNo;
        sAttachArg.mRecordSize = sTableHdr->mRecordSize;
        sAttachArg.mSize       = sTableHdr->mExtendSize;

        sRC = dbmInternalAttachNormalTable( (void*)&sAttachArg, &sAllocArg->mShmPtr[sSegMax] );
        _IF_RAISE( sRC, EXTEND_FATAL );

    }

    return -1;

    _EXCEPTION( EXTEND_FATAL )
    {
        fprintf( stdout, "Extend Failed rc=%d\n", sRC );
    }

    _EXCEPTION_END;
    return sRC;
}

