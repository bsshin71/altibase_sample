#include <stdio.h>
#include <dbmNormalTableMgr.h>
#include <dbmTableInterface.h>
#include <dbmUndoMgr.h>
#include <dbmUndoInterface.h>



void undoTest( )
{
    dbmUndoInterface    sUndo;
    dbmUndoCreateArg    sCreate;
    dbmUndoAttachArg    sAttach;
    dbmUndoSlotArg      sSlot;
    dbmUndoHeader*      sUndoHdr;
    dbmUndoSlot*        sUndoSlot;
    char*               ptr[1024];
    int                 i;
    int                 rc;

    sUndo.mCreate = dbmInternalCreateUndo;
    sUndo.mAllocSlot = dbmExtendAllocUndoSlot;
    sUndo.mAttach = dbmInternalAttachUndo;


    memset_s( &sCreate, 0x00, sizeof(dbmUndoCreateArg) );
    strcpy_s( sCreate.mUndoName, "onmir_test" );
    sCreate.mSessionCount = 100;
    sCreate.mExtendCount  = 100;

    rc = sUndo.mCreate( (void*)&sCreate );
    printf( "Undo Create rc=%d\n", rc );

    memset_s( &sAttach, 0x00, sizeof(dbmUndoAttachArg) );

    strcpy_s( sAttach.mUndoName, "onmir_test" );
    sAttach.mSegNo = 0;
    sAttach.mSessionCount = 100;
    rc = sUndo.mAttach( (void*)&sAttach, &ptr[0] );
    printf( "Undo Attach rc=%d\n", rc );

    sUndoHdr = (dbmUndoHeader*)ptr[0];
    printf( "mUndoSegNo = %d( max=%d ), mUndoSession = %d, mExtend=%d\n",
            sUndoHdr->mSegNo, sUndoHdr->mMaxSegNo, sUndoHdr->mSessionMax, sUndoHdr->mExtendCount );

/*
    for( i=0;i<sUndoHdr->mSessionMax; i++ )
    {
        sUndoSlot = (dbmUndoSlot*)UNDO_POS( ptr[0], i );
        printf( "Ind=%d, mPID=%d\n", i, sUndoSlot->mPID );
    }
    exit( -1 );
 */

    for( i=1; i<sUndoHdr->mMaxSegNo; i++ )
    {
        strcpy_s( sAttach.mUndoName, "onmir_test" );
        sAttach.mSegNo = i;
        sAttach.mSessionCount = sUndoHdr->mExtendCount;
        rc = sUndo.mAttach( (void*)&sAttach, &ptr[i] );
    }

    for( i=0; i<200; i++ )
    {
        sSlot.mShmPtr = ptr;
        sSlot.mPID    = getpid();
        rc = sUndo.mAllocSlot( (void*)&sSlot );
        printf( "Alloc Slot( segNo = %d, Offset = %d )\n", sSlot.mSegNo, sSlot.mSlotOffset );
    }

}


void repeatAlloc( dbmTableInterface* aTable, char** ptr )
{
    struct timespec     start, end;
    char                buff[1024];
    int                 i, rc, len;
    int                 slot, segno;
    dbmTableSlotArg     sArg;
    dbmTableDataArg     sData;

    clock_gettime( CLOCK_REALTIME, &start );
    for( i=0;i<1000000; i++ )
    {
        sArg.mShmPtr     = ptr;
        sArg.mSegNo      = -1;
        sArg.mSlotOffset = -1;

        rc = aTable->mAllocSlot( &sArg );
        if ( rc )
        {
            printf( "AllocSlot rc=%d( i=%d )\n", rc, i );
            break;
        }

        sprintf( buff,"%0100d", i );
        sData.mShmPtr = ptr[sArg.mSegNo];
        sData.mData = (char*)&buff[0];
        sData.mSize = 100;
        sData.mSlotOffset = sArg.mSlotOffset;

        rc = aTable->mWrite( (void*)&sData );
        rc = aTable->mRead( (void*)&sData );

        if ( i!=0 && i%10000 == 0 )
        {
            aTable->mFreeSlot( &sArg );
        }
    }
    clock_gettime( CLOCK_REALTIME, &end );
    printf( "Time = %.9f\n", ( double )( ( end.tv_sec+end.tv_nsec/1000000000.0) - ( start.tv_sec+start.tv_nsec/1000000000.0) ) );

}



int main( )
{
    dbmNormalTableHeader*   sTableHdr;
    dbmTableInterface       sTable;
    dbmTableCreateArg       sCreateArg;
    dbmTableAttachArg       sAttachArg;
    char                    buff[1024];
    int                     len;
    int                     i;
    char*                   ptr[1024];
    int                     slot;
    int                     segNo, sSegMax;
    int                     rc;

    undoTest();
    exit( -1 );

    sTable.mCreate    = dbmInternalCreateNormalTable;
    sTable.mAttach    = dbmInternalAttachNormalTable;
    sTable.mAllocSlot = dbmExtendAllocSlot;
    sTable.mFreeSlot  = dbmNormalFreeSlot;
    sTable.mWrite     = dbmInternalWriteNormalTable;
    sTable.mRead      = dbmInternalReadNormalTable;

    sCreateArg.mUserName [0] = 0x00;
    sprintf( sCreateArg.mTableName, "system_dictionary" );
    sCreateArg.mRecordSize = 600;
    sCreateArg.mInitSize   = (1024* 1024* 100 );
    sCreateArg.mExtendSize = cmnGetBuddy( 1024* 1024* 100 );

    rc = sTable.mCreate( (void*)&sCreateArg );


    sAttachArg.mUserName [0] = 0x00;
    sprintf( sAttachArg.mTableName, "system_dictionary" );
    sAttachArg.mSegNo = 0;
    sAttachArg.mRecordSize = 600;
    sAttachArg.mSize = (1024* 1024* 100 );

    rc = sTable.mAttach( (void*)&sAttachArg, &ptr[0] );
    if ( rc )
    {
        printf( "attach rc=%d\n", rc );
        exit( -1 );
    }

    sTableHdr = (dbmNormalTableHeader*)ptr[0];
    printf( "Table mSegNo = %d,( max=%d ) mRecordSize=  %d, mRecordMax = %ld, extendSize=%ld\n",
             sTableHdr->mSegNo, sTableHdr->mMaxSegNo, sTableHdr->mRecordSize, sTableHdr->mRecordMax,
             sTableHdr->mExtendSize );

    sSegMax = sTableHdr->mMaxSegNo;

    for( i=1; i<sSegMax; i++ )
    {
        sAttachArg.mSegNo = i;
        rc = sTable.mAttach( (void*)&sAttachArg, &ptr[i] );
        if ( rc )
        {
            printf( "Attach failed rc=%d( segNo=%d )\n", rc, i );
            exit( -1 );
        }
        sTableHdr = (dbmNormalTableHeader*)ptr[i];
        printf( "attach(%d-Segment ) rc=%d\n", sTableHdr->mSegNo, rc );
    }

    repeatAlloc( &sTable, ptr );

    sTableHdr = (dbmNormalTableHeader*)ptr[0];
    sSegMax = sTableHdr->mMaxSegNo;

    for( i=0;i<sSegMax; i++ )
    {
        sTableHdr = (dbmNormalTableHeader*)ptr[i];
        printf( "Table mSegNo = %d, mRecordSize=  %d, mRecordMax = %ld, mAlloc=%ld, mFree=%ld\n",
             sTableHdr->mSegNo, sTableHdr->mRecordSize, sTableHdr->mRecordMax, sTableHdr->mAllocInd, sTableHdr->mFreeInd );
    }

    return 0;
}
