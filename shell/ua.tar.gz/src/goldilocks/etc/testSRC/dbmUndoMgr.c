/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *******************************************************************************/
#include <dbmUndoInterface.h>
#include <dbmUndoMgr.h>
#include <cmnError.h>
#include <cmnShm.h>




/******************************************************************************
 * Name : dbmInternalCreateUndo
 *
 * Description
 *    Undo Segment를 최초에 만들때 처리한다.
 *
 * Argument
 *   aArg   : input   : dbmUndoCreateArg 참조
 *
 * Return
 ******************************************************************************/
int dbmInternalCreateUndo( void* aArg )
{
    dbmUndoHeader*      sUndoHdr;
    dbmUndoCreateArg*   sCreateArg;
    dbmUndoAttachArg    sAttachArg;
    char*               sShmPtr = NULL;
    char                sKeyString [1024];
    int                 sRC;


    /*******************************************************
     * 상위 함수에서 넘긴 인자를 맵핑한다.
     *******************************************************/
    sCreateArg = (dbmUndoCreateArg*)aArg;

    /*******************************************************
     * 테이블의 Object ID 획득.
     * Dictionary에서 획득할건데 없다면 실패.
     *******************************************************/
    sRC = dbmGetNewObjectID( &sCreateArg->mObjectID );
    _IF_RAISE( ( sRC || sCreateArg->mObjectID < 0 ), GET_OBJECT_ID_FAIL );

    /********************************************************
     * Shared memory를 먼저 생성한다.
     * 여기서 Size는 Parsing된 init size라고 봐야 함.
     * Slot Area를 계산해서 덧붙힌다.
     ********************************************************/
    UNDO_KEY_NAME( sKeyString, sCreateArg->mUndoName, 0 );
    sRC = cmnShmCreate( sKeyString, UNDO_AREA_SIZE( sCreateArg->mSessionCount ) );
    _IF_RAISE( sRC, CREATE_FAIL );


    /*******************************************************
     * Shared memory에 Attach한다.
     *******************************************************/
    memset_s( &sAttachArg, 0x00, sizeof(dbmUndoAttachArg) );

    strcpy_s( sAttachArg.mUndoName, sCreateArg->mUndoName );
    sAttachArg.mSegNo        = 0;
    sAttachArg.mSessionCount = sCreateArg->mSessionCount;

    sRC = dbmInternalAttachUndo( (void*)&sAttachArg, &sShmPtr );
    _IF_RAISE( sRC, ATTACH_FATAL );

    memset_s( sShmPtr, 0x00, sizeof(dbmUndoHeader) );

    /*******************************************************
     * Header구조체를 초기화해서 저장한다.
     *******************************************************/
    sUndoHdr = (dbmUndoHeader*)sShmPtr;

    sUndoHdr->mLock        = -1;
    sUndoHdr->mSegNo       = 0;
    sUndoHdr->mMaxSegNo    = 1;
    sUndoHdr->mSessionMax  = sCreateArg->mSessionCount;
    sUndoHdr->mExtendCount = sCreateArg->mExtendCount;
    sUndoHdr->mSessionID   = -1;
    sUndoHdr->mSCN         = -1;
    sUndoHdr->mReplSeq     = -1;
    sUndoHdr->mObjectID    = sCreateArg->mObjectID;
    strcpy_s( sUndoHdr->mUndoName, sCreateArg->mUndoName );
    gettimeofday( &sUndoHdr->mCreateTime, NULL );
    gettimeofday( &sUndoHdr->mTruncTime,  NULL );

    /*******************************************************
     * Undo Slot 초기화
     *******************************************************/
    sRC = dbmNormalInitUndo( sShmPtr );

    sRC = cmnShmDetach( sShmPtr );
    return RC_SUCCESS;


    /*******************************************************
     * 에러 발생
     *******************************************************/
    _EXCEPTION( GET_OBJECT_ID_FAIL )
    {
        sRC = ERR_DBM_GET_OBJECT_ID_FAIL;
    }

    _EXCEPTION( CREATE_FAIL )
    {
        fprintf( stdout, "Create failed rc = %d\n", sRC );
        sRC = ERR_DBM_CREATE_TABLE_FAIL;
    }

    _EXCEPTION( ATTACH_FATAL )
    {
        fprintf( stdout, "Create failed rc = %d\n", sRC );
        sRC = ERR_DBM_CREATE_TABLE_FAIL;
    }

    _EXCEPTION_END;
    if ( sShmPtr != NULL )
    {
        cmnShmDetach( sShmPtr );
    }
    return sRC;
}






/******************************************************************************
 * Name : dbmInternalExtendUndo
 *
 * Description
 *   UNDO를 확장할때 처리한다.
 *
 * Argument
 *   adArg : input  : dbmExtendArg 구조체
 *   aSeqNo: input  : 확장시 만들어진 SegNo이다.
 *
 * Return
 ******************************************************************************/
int dbmInternalExtendUndo( void* aArg
                                 ,  int* aSegNo )
{
    dbmUndoHeader*      sUndoHdr;
    dbmUndoHeader*      sExtendHdr;
    dbmUndoExtendArg*   sExtendArg;
    dbmUndoAttachArg    sAttachArg;
    long                sObjectID = -1;
    char                sKeyString [1024];
    char*               sShmPtr = NULL;
    int                 sRC;


    /********************************************************
 * Argument, TableHeader 맵핑.
 ********************************************************/
    *aSegNo = -1;
    sExtendArg = (dbmUndoExtendArg*)aArg;

    sUndoHdr = (dbmUndoHeader*)sExtendArg->mMainShmPtr;

    /********************************************************
 * 동시성 제어코드 넣어야 함.
 ********************************************************/


    /********************************************************
 * Shared memory를 먼저 생성한다.
 * KeyString은 main keyString에 SegNo를 붙혀서 만든다.
 * 나머지 웬간한 정보는 main segment에 있는 걸 이용한다.
 ********************************************************/
    *aSegNo = mvpAtomicGet32( &sUndoHdr->mMaxSegNo );

    UNDO_KEY_NAME( sKeyString, sUndoHdr->mUndoName, (*aSegNo) );
    sRC = cmnShmCreate( sKeyString, UNDO_AREA_SIZE( sUndoHdr->mExtendCount ) );
    _IF_RAISE( sRC, CREATE_FAIL );


    /*******************************************************
 * Shared memory에 Attach한다.
 *******************************************************/
    memset_s( &sAttachArg, 0x00, sizeof(dbmUndoAttachArg) );

    strcpy_s( sAttachArg.mUndoName,  sUndoHdr->mUndoName );
    sAttachArg.mSegNo        = (*aSegNo);
    sAttachArg.mSessionCount = sUndoHdr->mExtendCount;

    sRC = dbmInternalAttachUndo( (void*)&sAttachArg, &sShmPtr );
    _IF_RAISE( sRC, ATTACH_FATAL );


    /*******************************************************
 * Extended Shared memory에 Table Header를 초기화시킨다.
 *******************************************************/
    memset_s( sShmPtr, 0x00, sizeof(dbmUndoHeader) );

    sExtendHdr = (dbmUndoHeader*)sShmPtr;

    sExtendHdr->mLock        = -1;
    sExtendHdr->mSegNo       = (*aSegNo);
    sExtendHdr->mMaxSegNo    = sUndoHdr->mMaxSegNo;
    sExtendHdr->mSessionMax  = sUndoHdr->mExtendCount;
    sExtendHdr->mExtendCount = sUndoHdr->mExtendCount;
    sExtendHdr->mSessionID   = -1;
    sExtendHdr->mSCN         = -1;
    sExtendHdr->mReplSeq     = -1;
    sExtendHdr->mObjectID    = sUndoHdr->mObjectID;
    strcpy_s( sExtendHdr->mUndoName,  sUndoHdr->mUndoName );
    gettimeofday( &sExtendHdr->mCreateTime, NULL );
    gettimeofday( &sExtendHdr->mTruncTime,  NULL );


    /*******************************************************
 * Undo Slot 초기화
 *******************************************************/
    sRC = dbmNormalInitUndo( sShmPtr );

    /*******************************************************
 * Main Shared memory에 SegNo를 증가시킨다.
 *******************************************************/
    mvpAtomicInc32 ( &sUndoHdr->mMaxSegNo );

    sRC = cmnShmDetach( sShmPtr );
    return RC_SUCCESS;


    /*******************************************************
 * 에러 발생
 *******************************************************/
    _EXCEPTION( GET_OBJECT_ID_FAIL )
    {
        fprintf( stdout, "OBJECT_ID = rc=%d, sObjectID=%ld\n", sRC, sObjectID );
        sRC = ERR_DBM_GET_OBJECT_ID_FAIL;
    }

    _EXCEPTION( CREATE_FAIL )
    {
        fprintf( stdout, "Create failed rc = %d\n", sRC );
        sRC = ERR_DBM_CREATE_TABLE_FAIL;
    }

    _EXCEPTION( ATTACH_FATAL )
    {
        fprintf( stdout, "Create failed rc = %d\n", sRC );
        sRC = ERR_DBM_CREATE_TABLE_FAIL;
    }


    _EXCEPTION_END;
    if ( sShmPtr != NULL )
    {
        cmnShmDetach( sShmPtr );
    }
    return sRC;
}




/******************************************************************************
 * Name : dbmInternalAttachUndo
 *
 * Description
 *   테이블에 Attach하기
 *
 * Argument
 *   aArg      : Attach정보가 담긴 구조체
 *   aShmPtr   : 시작주소
 *
 * Return
 ******************************************************************************/
int dbmInternalAttachUndo( void* aArg, char** aShmPtr )
{
    dbmUndoAttachArg*   sArg;
    int                 sRC;
    char                sKeyString[1024];


    sArg = (dbmUndoAttachArg*)aArg;
    /********************************************************
 * Shared memory를 먼저 생성한다.
 * 여기서 Size는 Parsing된 init size라고 봐야 함.
 ********************************************************/
    UNDO_KEY_NAME( sKeyString, sArg->mUndoName, sArg->mSegNo );
    sRC = cmnShmAttach( sKeyString
                      , UNDO_AREA_SIZE( sArg->mSessionCount )
                      , aShmPtr );
    _IF_RAISE( sRC, ATTACH_FAIL );

    return RC_SUCCESS;

    _EXCEPTION( ATTACH_FAIL )
    {
        sRC = ERR_DBM_ATTACH_SHM_FAIL;
    }

    _EXCEPTION_END;
    return sRC;
}




/******************************************************************************
 * Name : dbmNormalInitUndo
 *
 * Description
 *   Undo Slot영역을 초기화시킨다.
 *
 * Argument
 *   aShmPtr     : input   : Shared Memory 시작주소 (어떤 segNo를 가진 놈이 될지 모름 )
 *
 * Return
 *   SUCCESS / FAIL
 ******************************************************************************/
int dbmNormalInitUndo( char* aShmPtr )
{
    dbmUndoHeader*  sUndoHdr;
    dbmUndoSlot*    sUndoSlot;
    int             sRC;
    int             i;


    /********************************************
 * Header Mapping
 ********************************************/
    sUndoHdr = (dbmUndoHeader*)aShmPtr;
    printf( "INIT:: SegNo =%d, mSessionMax = %d\n", sUndoHdr->mSegNo, sUndoHdr->mSessionMax );

    for( i=0; i<sUndoHdr->mSessionMax; i++ )
    {
        /********************************************
 * Slot Initialize
 ********************************************/
        sUndoSlot = (dbmUndoSlot*)UNDO_POS( aShmPtr, i );

        memset_s( sUndoSlot, 0x00, sizeof(sUndoSlot) );
        sUndoSlot->mPID       = DBM_UNDO_FREE_MARK;
        sUndoSlot->mLogSeq    = -1;
    }

    return RC_SUCCESS;
}


/******************************************************************************
 * Name : dbmNormalAllocUndoSlot
 *
 * Description
 *   Undo Slot영역을 할당받는다.
 *
 * Argument
 *   aShmPtr     : input   : Shared Memory 시작주소 (어떤 segNo를 가진 놈이 될지 모름 )
 *   aSlotOffset : output  : 가용한 공간을 리턴받을 변수 포인터
 *
 * Return
 *   SUCCESS / FAIL
 ******************************************************************************/
int dbmNormalAllocUndoSlot( char* aShmPtr,
                                     int aPID,
                                     int* aSlotOffset )
{
    dbmUndoHeader*  sUndoHdr;
    dbmUndoSlot*    sUndoSlot;
    int             sRC;
    int             sTry;
    long            sInd;


 * aSlotOffset = -1;
    sUndoHdr = (dbmUndoHeader*)aShmPtr;
    /*****************************************************
 * mSessionID를 증가시킨 값을 MOD연산을 통해 확인
 *****************************************************/
    sTry = 0;
    while( sTry < sUndoHdr->mSessionMax )
    {
        sInd = mvpAtomicInc64( &sUndoHdr->mSessionID ) % sUndoHdr->mSessionMax;
        sUndoSlot = (dbmUndoSlot*)UNDO_POS( aShmPtr, sInd );
        if( mvpAtomicCas32 ( &sUndoSlot->mPID, aPID, DBM_UNDO_FREE_MARK ) == DBM_UNDO_FREE_MARK )
        {
 * aSlotOffset = sInd;
            return RC_SUCCESS;
        }
        /***************************************
 * Alive Detect Code를 넣어야 함.
 ***************************************/
        sTry = sTry + 1;
    }


    return ERR_DBM_NO_SPACE_IN_UNDO;
}





/******************************************************************************
 * Name : dbmNormalFreeSlot
 *
 * Description
 *   UndoSlot영역을 해제시킨다.
 *
 * Argument
 *   aArg : input  : dbmUndoSlotArg 구조체
 *
 * Return
 *   SUCCESS / FAIL
 ******************************************************************************/
int dbmNormalFreeUndoSlot( void* aArg )
{
    dbmUndoHeader*  sUndoHdr;
    dbmUndoSlot*    sUndoSlot;
    dbmUndoSlotArg* sSlotArg;
    int             sRC;
    long            sInd;
    int*            sSlot;


    /*****************************************************
 * argment mapping
 *****************************************************/
    sSlotArg = (dbmUndoSlotArg*)aArg;

    /*****************************************************
 * Table Header
 *****************************************************/
    sUndoHdr  = (dbmUndoHeader*)sSlotArg->mShmPtr[sSlotArg->mSegNo];

    sUndoSlot = (dbmUndoSlot*)UNDO_POS( sSlotArg->mShmPtr[sSlotArg->mSegNo], sSlotArg->mSlotOffset );
    _IF_RAISE( sUndoHdr->mSessionMax < sSlotArg->mSlotOffset,    INVALID_OFFSET );

    /*****************************************************
 * Free할 수 있는 공간이 맞다면 셋업한다.
 *****************************************************/
    _IF_RAISE( mvpAtomicCas32( &sUndoSlot->mPID, DBM_UNDO_FREE_MARK, sSlotArg->mPID ) != sSlotArg->mPID, FREE_FATAL );

    return RC_SUCCESS;

    _EXCEPTION( INVALID_OFFSET )
    {
        sRC = ERR_DBM_INVALID_OFFSET;
    }

    _EXCEPTION( FREE_FATAL )
    {
        sRC = ERR_DBM_FREE_SLOT_FATAL_IN_TABLE;
    }

    _EXCEPTION_END;
    return sRC;
}


/******************************************************************************
 * Name : dbmExtendAllocUndoSlot
 *
 * Description
 *   AllocSlot의 가장 상위 함수처리
 *
 * Argument
 *   aArg : dbmSlotArg구조체
 * Return
 *   SUCCESS / FAIL
 ******************************************************************************/
int dbmExtendAllocUndoSlot( void* aArg )
{
    dbmUndoHeader*      sUndoHdr;
    dbmUndoExtendArg    sExtendArg;
    dbmUndoAttachArg    sAttachArg;
    dbmUndoSlotArg*     sAllocArg;
    int                 i;
    int                 sRC;
    int                 sErrCount = 0;
    int                 sSegNo;
    int                 sSegMax;
    char                sKeyString[1024];


    sAllocArg = (dbmUndoSlotArg*)aArg;

    while ( 1 )
    {
        sUndoHdr = (dbmUndoHeader*)sAllocArg->mShmPtr[0];
        sSegMax   = mvpAtomicGet32( &sUndoHdr->mMaxSegNo );

        /**************************************************************************************
 * 일단 테스트 코드에서는 아래처럼 loop를 돌리자.
 **************************************************************************************/
        for( i=0; i<sSegMax; i++ )
        {
            /*******************************************************
 * 공간이 모자르면 내가 직접 Extend해보는 코드
 *******************************************************/
            sRC = dbmNormalAllocUndoSlot( sAllocArg->mShmPtr[i], sAllocArg->mPID, &sAllocArg->mSlotOffset );
            if ( sRC == RC_SUCCESS )
            {
                sAllocArg->mSegNo = i;
                return RC_SUCCESS;
            }
        }

        /***************************************************
 * 여기까지 왔다면 공간이 없다는 의미.
 * 확장한다.
 ***************************************************/
        _IF_RAISE( sSegMax >= DBM_UNDO_SEGMENT_MAX, EXTEND_FATAL );
fprintf( stdout, "Start Extend memory. ( segMax=%d )\n", sSegMax );

        /***************************************************
 * Table Header가 있는 정보를 맵핑해서 확장.
 ***************************************************/
        sExtendArg.mMainShmPtr = sAllocArg->mShmPtr[0];
        sRC = dbmInternalExtendUndo( (void*)&sExtendArg, &sSegNo );
        _IF_RAISE( sRC, EXTEND_FATAL );

        /***************************************************
 * 새롭게 확장됬기 때문에 이걸 Attach해줘야 한다.
 ***************************************************/
        memset_s( &sAttachArg, 0x00, sizeof(dbmUndoAttachArg) );
        strcpy_s( sAttachArg.mUndoName,   sUndoHdr->mUndoName );
        sAttachArg.mSegNo        = sSegNo;
        sAttachArg.mSessionCount = sUndoHdr->mExtendCount;

        sRC = dbmInternalAttachUndo( (void*)&sAttachArg, &sAllocArg->mShmPtr[sSegMax] );
        _IF_RAISE( sRC, EXTEND_FATAL );

    }

    return -1;

    _EXCEPTION( EXTEND_FATAL )
    {
        fprintf( stdout, "Extend Failed rc=%d\n", sRC );
    }

    _EXCEPTION_END;
    return sRC;
}

