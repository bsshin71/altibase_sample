/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *******************************************************************************/
#include <dbmDictionaryMgr.h>
#include <dbmNormalTableMgr.h>
#include <cmnError.h>
#include <cmnShm.h>




/******************************************************************************
 * Name : dbmInitSystemDictionary
 *
 * Description
 *    system_dictionary를 초기화시킨다.
 *
 * Argument
 *
 * Return
 ******************************************************************************/
int dbmInitSystemDictionary( )
{
    dbmDictionary* sDic;
    int                 sRC;
    char* sShmPtr = NULL;


    /********************************************************
     * System에 Attach해서 고유번호를 채번할 준비를 한다.
     ********************************************************/
    sRC = cmnShmAttach( SYSTEM_DICTIONARY
                      , SYSTEM_DICTIONARY_HEADER_SIZE
                      , &sShmPtr );
    _IF_RAISE( sRC, ATTACH_FAIL );


    /********************************************************
     * Initialize 한다.
     ********************************************************/
    sDic = (dbmDictionary*)sShmPtr;

    sDic->mLock     = -1;
    sDic->mObjectID = 0;

    /********************************************************
     * Detach한다.
     ********************************************************/
    sRC = cmnShmDetach( sShmPtr );
    _IF_RAISE( sRC, DETACH_FAIL );

    return RC_SUCCESS;


    _EXCEPTION( ATTACH_FAIL )
    {
        fprintf( stdout, "attach failed rc = %d\n", sRC );
        sRC = ERR_DBM_ATTACH_SHM_FAIL;
    }
    _EXCEPTION( DETACH_FAIL )
    {
        fprintf( stdout, "detach failed rc = %d\n", sRC );
        sRC = ERR_DBM_DETACH_SHM_FAIL;
    }
    _EXCEPTION_END;
    return sRC;
}


