/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *******************************************************************************/
#include <dbmDictionaryMgr.h>
#include <dbmNormalTableMgr.h>
#include <cmnError.h>
#include <cmnShm.h>




/******************************************************************************
 * Name : dbmGetNewObjectID
 *
 * Description
 *   새로운 1개의 고유ID를 얻어낼 때 사용한다.
 *
 * Argument
 *   aObjectID   : output  : 고유ID를 리턴받을 변수포인터 (64bit )
 *
 * Return
 ******************************************************************************/
int dbmGetNewObjectID  ( long* aObjectID )
{
    dbmDictionary*  sDic;
    int             sRC;
    char*           sShmPtr = NULL;

    *aObjectID = -1;

    /********************************************************
     * System에 Attach해서 고유번호를 채번할 준비를 한다.
     ********************************************************/
    sRC = cmnShmAttach( SYSTEM_DICTIONARY
                      , SYSTEM_DICTIONARY_HEADER_SIZE
                      , &sShmPtr );
    /*******************************************************
     * 최초에 만드는 Object는 뭐가됬던 없을거니까
     * 그 놈만 유일하게 0으로 리턴해준다.
     *******************************************************/
    if ( errno == ENOENT )
    {
        *aObjectID = 0L;
        return RC_SUCCESS;
    }
    else
    {
        _IF_RAISE( sRC, ATTACH_FAIL );
    }

    /********************************************************
     * 고유번호를 채번한다.
     ********************************************************/
    sDic = (dbmDictionary*)sShmPtr;
    *aObjectID = mvpAtomicInc64( &sDic->mObjectID );

    /********************************************************
     * Detach한다.
     ********************************************************/
    sRC = cmnShmDetach( sShmPtr );
    _IF_RAISE( sRC, DETACH_FAIL );

    return RC_SUCCESS;


    _EXCEPTION( ATTACH_FAIL )
    {
        fprintf( stdout, "attach failed rc = %d\n", sRC );
        sRC = ERR_DBM_ATTACH_SHM_FAIL;
    }
    _EXCEPTION( DETACH_FAIL )
    {
        fprintf( stdout, "detach failed rc = %d\n", sRC );
        sRC = ERR_DBM_DETACH_SHM_FAIL;
    }
    _EXCEPTION_END;
    return sRC;
}


