#include "dbmSegmentManager.h"
#include "dbmLockManager.h"

#define     ERR_DBM_QUEUE_EMPTY    100000


#ifndef     ____O___DBM_SHM_QUEUE_MANAGER____
#define     ____O___DBM_SHM_QUEUE_MANAGER____

enum {
    END_OF_LIST = -1
} ;



int64_t getHeader (int64_t pos)
{
        return (pos >> 32);
}

int64_t getTail(int64_t pos)
{
        return (int64_t)((int)pos);
}

int64_t makeLinks(int64_t aHeader, int64_t aTail)
{
        return ( (aHeader<<32) | (aTail&0x00000000ffffffff) );
}


typedef struct
{
    int      mLock ;
    int      mFutex;

    int64_t  mLinks;

} dbmShmQHeader;

typedef struct
{
    int        mRowLock;
    int64_t    mMySlotNo;
    size_t     mDataSz;
    int64_t    mPrev;
} dbmQRowHeader;


class dbmShmQueueManager
{
    public :
        static int  Create( char * aQueueName,
                            int64_t   aQueueSize,
                            int64_t   aInitCount,
                            int64_t   aExtendCount,
                            int64_t   aMaxCount,
                            dbmShmQueueManager ** aReturnObj) ;

        static int Attach ( char * aQueueName,
                            dbmShmQueueManager  **aReturnObj);

        static int Drop ( char * aQueueName );




    public :

        dbmShmQHeader * testGetQueueHeader () ;

        int     Enqueue ( char *  aUserData,
                          size_t  aUserLen);

        int     Dequeue ( char * aUserData ,
                          size_t * aUserLen );

        int     Dequeue ( char * aUserData ,
                          size_t * aUserLen ,
                          int   aTimeout );

        int     Commit ();
        int     Rollback ();

        int     makeNode ( char * aUserData,
                           size_t aUserLen,
                           dbmQRowHeader *aPrev,
                           dbmQRowHeader **aReturn ) ;

    private :
        dbmSegmentManager  * mSegment;
        dbmShmQueueManager ( dbmSegmentManager *aSegmentManager );
        ~dbmShmQueueManager() ;


        int initQueueHeader ()  ;
        dbmShmQHeader      *mHeader;

    private :

        int     lock () ;
        int     unLock () ;


        dbmQRowHeader   *mQueueTxHeader;
};

#endif

