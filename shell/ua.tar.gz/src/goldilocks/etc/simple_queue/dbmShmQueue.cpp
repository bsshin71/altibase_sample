#include "dbmShmQueue.h"


dbmShmQueueManager::dbmShmQueueManager ( dbmSegmentManager* aSegmentManager )
{
    this->mSegment = aSegmentManager;
    this->mHeader = (dbmShmQHeader*)aSegmentManager->GetUserHeader () ;
    this->mQueueTxHeader  = NULL;
}

int dbmShmQueueManager::initQueueHeader ( )
{

    mHeader->mLock = -1;
    mHeader->mFutex = 0;

    mHeader->mLinks = makeLinks ( -1, -1 ) ;
    mQueueTxHeader  = NULL;

    return RC_SUCCESS;

}

int dbmShmQueueManager :: Create ( char*  aQueueName,
                                   int64_t   aQueueSize,
                                   int64_t   aInitCount,
                                   int64_t   aExtendCount,
                                   int64_t   aMaxCount,
                                   dbmShmQueueManager**  aReturnObj)
{

    int     sRC;
    dbmSegmentManager*   sSegmentManager ;
    dbmShmQueueManager*  sQueueManager;

    int     sSlotSize ;



    /********************************************************
     * Queue 의 Slot Size는 Queue Size + Row Header
     ********************************************************/
    sSlotSize = aQueueSize + sizeof ( dbmQRowHeader) ;

    sRC = dbmSegmentManager :: Create ( aQueueName,
                                        sSlotSize,
                                        aInitCount,
                                        aExtendCount,
                                        aMaxCount,
                                        sizeof(dbmShmQHeader) ,
                                        &sSegmentManager ) ;

    _TEST_RAISE ( sRC == RC_SUCCESS ,
                     ERROR_CREATE_SEGMENTMANAGER) ;

    sQueueManager = new dbmShmQueueManager ( sSegmentManager ) ;
    sQueueManager->initQueueHeader();

    *aReturnObj = sQueueManager;
    return RC_SUCCESS;

    _EXCEPTION ( ERROR_CREATE_SEGMENTMANAGER )
    {
        return  sRC;
    }

    _EXCEPTION_END;

    return sRC;
}

int dbmShmQueueManager::Attach ( char* aQueueName , dbmShmQueueManager** aReturnObj )
{
    int     sRC;
    dbmSegmentManager   *sSegmentManager ;
    dbmShmQueueManager  *sQueueManager;


    sRC = dbmSegmentManager :: Attach ( aQueueName,
                                        &sSegmentManager ) ;

    _TEST_RAISE ( sRC == RC_SUCCESS ,
                     ERROR_ATTACH_SEGMENTMANAGER) ;

    sQueueManager = new dbmShmQueueManager ( sSegmentManager ) ;



    *aReturnObj = sQueueManager;
    return RC_SUCCESS;

    _EXCEPTION ( ERROR_ATTACH_SEGMENTMANAGER )
    {
        return  sRC;
    }

    _EXCEPTION_END;

    return sRC;
}



int dbmShmQueueManager :: Drop ( char * aQueueName )
{
    int     sRC;
    sRC = dbmSegmentManager :: Drop ( aQueueName ) ;
    return sRC ;
}


int dbmShmQueueManager :: makeNode ( char * aUserData ,
                                     size_t aUserLen,
                                     dbmQRowHeader * aPrev ,
                                     dbmQRowHeader ** aReturn)
{
    int     sRC;
    int64_t sSlotNo ;

    dbmQRowHeader  sTmp;
    dbmQRowHeader *sRowPtr;


    sRC = mSegment -> AllocSlot (  &sSlotNo ) ;
    _TEST_RAISE ( sRC == RC_SUCCESS , ALLOC_SLOT_FAIL ) ;

    sRC = mSegment -> Slot2Addr ( sSlotNo , (char**) &sRowPtr) ;
    _TEST_RAISE ( sRC == RC_SUCCESS , SLOT2ADDR_FAIL ) ;


    memcpy_s ( (char*)sRowPtr + sizeof( dbmQRowHeader ),
             aUserData,
             aUserLen );

    /******************************************************
     * 중간에 죽을 수도 있기 때문에  한방에 복사한다.
     * 이렇게 한다고 Atomic 이 보장되는 것은 아니긴하고,
     * 사실 makeNode 이 함수 내에서는 어디서 죽어도 안전하다.
     * 어차피 복구할때 Freeslot 하면 그만임.
     ******************************************************/

    sTmp.mRowLock = -1;
    sTmp.mMySlotNo = sSlotNo ;
    sTmp.mDataSz=aUserLen;

    if ( aPrev )
    {
        sTmp.mPrev = aPrev->mMySlotNo ;
    }
    else
    {
        sTmp.mPrev = END_OF_LIST;
    }

    memcpy_s ( sRowPtr , &sTmp , sizeof (dbmQRowHeader)) ;


    *aReturn = sRowPtr;

    return RC_SUCCESS ;

    _EXCEPTION ( ALLOC_SLOT_FAIL )
    {
        return sRC;
    }

    _EXCEPTION ( SLOT2ADDR_FAIL )
    {
        return sRC;
    }
    _EXCEPTION_END;

    return sRC;
}



int     dbmShmQueueManager :: lock ()
{

    int     sRC;
    int tid;
    tid = syscall (SYS_gettid) ;

    do {
        sRC = dbmLockManager :: mAtomicLockTry ( (char*)&mHeader->mLock, tid,  -1) ;
    } while ( sRC != RC_SUCCESS ) ;

    assert ( tid == mHeader->mLock ) ;
    return sRC;
}

int     dbmShmQueueManager :: unLock ()
{

    int     sRC;
    int tid;
    tid = syscall (SYS_gettid) ;
    sRC = dbmLockManager :: mAtomicLockTry ( (char*)&mHeader->mLock, -1,tid) ;
    assert ( sRC == RC_SUCCESS ) ;
    return sRC;
}


int     dbmShmQueueManager :: Enqueue ( char * aUserData,
                                        size_t aUserLen )
{

    int     sRC;

    dbmQRowHeader   *sRowHeader;
    dbmQRowHeader   *sOriginalRow;

    int             sMyHeaderInput;
    int             sMyHeaderOutput;

    int64_t          sMyLink;

    /************************************************************
     * Enqueue 이니 새로운 노드를 만들어놓는다
     *
     * FULL 이 나더라도 makeNode 안에서 Exception 이 난다.
     *
     *
     * Recovery 시점에 어떤식의 Recovery 를 할것인지 고민해야한다.
     *
     ***********************************************************/
    sRC = makeNode ( aUserData, aUserLen , NULL,  &sRowHeader );
    _TEST_RAISE ( sRC == RC_SUCCESS , MAKE_NODE_FAIL ) ;

    /************************************************************
     * List 의 Link 를 구성한다.
     ***********************************************************/

    do
    {
        lock () ;
        sMyLink = mvpAtomicGet64 ( &mHeader->mLinks) ;

        sMyHeaderInput  = getHeader ( sMyLink ) ;
        sMyHeaderOutput = getTail ( sMyLink ) ;


        if ( sMyHeaderOutput == END_OF_LIST  )  // 한건도 없다
        {
            if ( sMyLink ==
                    mvpAtomicCas64 ( &mHeader->mLinks,
                                     makeLinks (sRowHeader->mMySlotNo,  sRowHeader->mMySlotNo),
                                     sMyLink))
            {
                unLock();
                sRC = cmnSignalFutex( &mHeader->mFutex );
                return RC_SUCCESS ;
            }
            unLock();
            continue;
        }
        else
        {
            if ( sMyHeaderInput == END_OF_LIST )
            {
                unLock();
                continue;
            }

            sRC = mSegment -> Slot2Addr ( sMyHeaderInput , (char**) &sOriginalRow) ;
            _TEST_RAISE ( sRC == RC_SUCCESS , SLOT2ADDR_FAIL ) ;

            if ( sMyLink ==
                    mvpAtomicCas64 ( &mHeader->mLinks,
                                      makeLinks (sRowHeader->mMySlotNo, sMyHeaderOutput ) ,
                                      sMyLink ))
            {

                sOriginalRow->mPrev = sRowHeader->mMySlotNo ;
                sRC = cmnSignalFutex( &mHeader->mFutex );
                unLock() ;
                return RC_SUCCESS;

            }

            unLock();
            continue ;

        }
    } while ( true );
    return RC_SUCCESS ;



    _EXCEPTION ( MAKE_NODE_FAIL )
    {
        return sRC;
    }
    _EXCEPTION ( SLOT2ADDR_FAIL)
    {
        return sRC;
    }
    _EXCEPTION_END;

    return RC_FAILURE;
}

int     dbmShmQueueManager :: Dequeue ( char * aUserData,
                                        size_t *aUserLen )
{

    return Dequeue( aUserData, aUserLen, 0 );
}


int     dbmShmQueueManager :: Dequeue ( char * aUserData,
                                        size_t *aUserLen,
                                        int     aTimeout )
{
    int     sRC;
    dbmQRowHeader   *sRowPtr;

    int64_t         sMyHeaderOutput ;
    int64_t         sMyHeaderInput ;

    int64_t         sMyLink ;


    do
    {
        lock () ;
        sMyLink = mvpAtomicGet64 ( &mHeader->mLinks ) ;
        sMyHeaderOutput = getTail ( sMyLink ) ;
        sMyHeaderInput  = getHeader( sMyLink ) ;

        if ( sMyHeaderOutput == END_OF_LIST )  // 한건도 없다
        {
            if( aTimeout != 0 )
            {
                unLock();
                /**  데이터가 없으니 잔다 */
                sRC = cmnWaitFutex( &mHeader->mFutex, aTimeout );
                if( sRC == ETIMEDOUT )
                {
                    return ERR_DBM_QUEUE_EMPTY;
                }

            }
            else // where aTimeout == 0
            {
                unLock();
                return ERR_DBM_QUEUE_EMPTY;
            }
            continue;
        }
        else
        {
            sRC = mSegment->Slot2Addr ( sMyHeaderOutput ,(char**) &sRowPtr );
            _TEST_RAISE ( sRC == RC_SUCCESS , SLOT2ADDR_FAIL ) ;

            if ( sMyLink  == mvpAtomicCas64 ( &mHeader->mLinks ,
                                               makeLinks (sMyHeaderInput, sRowPtr->mPrev ) ,
                                               sMyLink) )
            {
                unLock();
                break;
            }
            else
            {
                unLock();
                continue  ;
            }
        }

    } while ( true ) ;


    /**************************************************************************
     * Dequeue 를 성공했으므로 사용자에게 값을 복사해준다.
     * ***********************************************************************/
    *aUserLen = sRowPtr->mDataSz;
    memcpy_s ( aUserData,
             (char*)sRowPtr + sizeof ( dbmQRowHeader) ,
             sRowPtr->mDataSz ) ;

    /**************************************************************************
     * 복사가 끝났으니 이 공간은 Manager 로 반환한다.
     * ***********************************************************************/
    sRC = mSegment->FreeSlot ( sRowPtr->mMySlotNo );

    if ( sRC != RC_SUCCESS )
    {
        printf ("sRowPtr ->mMySlotNo : %ld \n", sRowPtr->mMySlotNo ) ;
    }

    _TEST_RAISE ( sRC == RC_SUCCESS, FREE_SLOT_ERROR ) ;


    /**************************************************************************
     * Dequeue 가 성공했으니 다음 Futex 를 대기하고 있는 놈을 깨운다.
     * ***********************************************************************/
    sRC = cmnSignalFutex ( &mHeader->mFutex) ;
    return sRC;


    _EXCEPTION ( SLOT2ADDR_FAIL  )
    {
        return sRC;
    }


    _EXCEPTION ( FREE_SLOT_ERROR  )
    {
        return sRC;
    }

   _EXCEPTION_END;

   return RC_FAILURE;
}


dbmShmQHeader * dbmShmQueueManager :: testGetQueueHeader ()
{
    return mHeader;
}



