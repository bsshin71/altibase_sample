/*******************************************************************************
 *
 * 사용자가 dbmTransLogger 를 통해서 쓴 로그를 읽어들인다.
 * 이 로그는 순서대로 읽어들여야한다.  이 Class 는 추상 Class
 *
 ******************************************************************************/

#ifndef __O_DBM_DISK_READ_H__
#define  __O_DBM_DISK_READ_H__

#include "dbmTransReader.h"
#include <queue>

#define   DBM_FILE_READ_BLOCK_COUNT 128 

class dbmLogFileReader ;
class dbmDiskReader : public dbmTransReader
{
public:
    //dbmDiskReader ( ) { };
    dbmDiskReader ( long long aLogBufferSize , char* aLogDestDir , char* aUndoName, int aReplOption );
    ~dbmDiskReader ( );

    int mGetLoadAnchor ( char* aUndoName, int aReplOption );
    virtual int mLoadLogBuffer ( long long aLSN = 0 );
    virtual int mReadLog ( dbmTransLog** aLog , char** aImage , long long aLSN );
    virtual char* mGetUndoName ( );

    int mAdjustLogAnchor (int aReplOption = 0 );

private:
    int mFillFiles ( );

protected:
    char    mLogDestDir[DBM_FILE_NAME_LEN];    // 로그 파일을 읽어올 Directory
    char    mInstanceName[DBM_NAME_LEN];

    // 기준으로 삼을 dbmAnchor 이다.
    // mLogDestDir 에서 마지막 Sync 된놈을 찾는다.
    dbmLogAnchor mLogAnchor;

    int     mIsAnchorLoadF;
    char    mFileNames[DBM_MAX_TRANS][DBM_FILE_NAME_LEN];
    int     mFileTranCount;

private:
    dbmLogFileReader* mLogFileReader;
    long long mLSN;

};


typedef struct queuedLogBlock
{
    char    data[DBM_LOG_BLOCK_SIZE];
} queuedLogBlock;



class  dbmLogFileReader
{
public:
    dbmLogFileReader ( char* aFileNames , int aFileTransCount )
    {
        mFileNames = aFileNames;
        mFileTransCount = aFileTransCount;
        mCompressTempBuffer = NULL;

        memset ( &mFDs, -1, sizeof(int) * DBM_MAX_TRANS );
        memset ( &mMyFileSeq, -1, sizeof(int) * DBM_MAX_TRANS );
    }

    ~dbmLogFileReader ( )
    {
    }

    int mFillQueue ( int aIdx , long long aStartLSN );

    /***********************************************
     * mBlockBuffer 로 부터 block 을 읽어내서 aBuf 에
     * 로그 버퍼 형태로 풀어서 넣어준다.
     **********************************************/
    int mGetLogByLSN ( long long aStartLSN , char* aBuf , int* aBufSize , long long* aLSN );

private:
    void mCheckIsDone ( int* aIsDone );
    int mDoDeCompress ( int aIsCompress );
    int dbmFindMinLSN ( );


private:
    char*   mFileNames;
    int     mFDs[DBM_MAX_TRANS];
    int     mFileTransCount;
    int     mMyFileSeq[DBM_MAX_TRANS];
    int     mIsDone[DBM_MAX_TRANS];

    queuedLogBlock mFirstBlock[DBM_MAX_TRANS];
    std::deque<queuedLogBlock> mBlockBuffer[DBM_MAX_TRANS];

    char*   mCompressTempBuffer;
    //long long mLSN;     // 2014/08/06 현재 미사용. 생성자 초기화 없어서 막음.
} ;

#endif /* __O_DBM_DISK_READ_H__ */


