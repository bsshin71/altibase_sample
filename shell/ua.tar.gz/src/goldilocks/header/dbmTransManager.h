/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    Transaction Manager 관련 자료구조 및 Definition 정의
 ******************************************************************************/
#ifndef __O_DBM_TRANS_MANAGER_H__
#define __O_DBM_TRANS_MANAGER_H__

#include "dbmCommon.h"
#include "dbmLockManager.h"
#include "dbmLogManager.h"
#include "dbmDicManager.h"
#include "dbmDiskLogger.h"
#include "dbmTableManager.h"
#include "dbmQueueManager.h"
#include "dbmListManager.h"


/**************************************************************
 * Definition
**************************************************************/
#define DBM_TXMGR_TRCLOG   "dbmTransManager.log"


/**************************************************************
 * dbmTransManager class
 *   - 하나의 transaction 을 관리하는 class 이다.
**************************************************************/
class dbmTransManager
{
private:
    char                mInstName[DBM_NAME_LEN];          /* undo name */

    int                 mTransID;                         /* transaction ID */
    char*               mTransHeader;                     /* transaction header for mTransID */

    dbmParseObject*     mParseObj;                        /* DDL 시 parsing 한 결과 저장 */
    dbmSegmentManager*  mUndoSegMgr;                      /* undo segment manager */

    int                 mTableCount;                      /* current table object count */
    int                 mQueueCount;                      /* current queue object count */
    int                 mListCount;                       /* current list object count  */

    dbmTableManager*    mTable[DBM_MAX_TABLE_PER_TRANS];  /* ptr array to dbmTableManager */
    dbmQueueManager*    mQueue[DBM_MAX_TABLE_PER_TRANS];  /* ptr array to dbmQueueManager */
    dbmListManager*     mList[DBM_MAX_TABLE_PER_TRANS];   /* ptr array to dbmListManager  */

    int                 mTableDDLCount[DBM_MAX_TABLE_PER_TRANS]; /* My Table DDL Count */
    int                 mQueueDDLCount[DBM_MAX_TABLE_PER_TRANS]; /* My Table DDL Count */
    int                 mListDDLCount[DBM_MAX_TABLE_PER_TRANS];  /* My Table DDL Count */

    dbmLogManager*      mLogMgr;                          /* log manager object */
    dbmLockManager*     mLockMgr;                         /* lock manager object */
    dbmConfig*          mConfigMgr;                       /* config manager object */

    dbmDeadLockManager* mDeadLockManager;                 /* DeadLock Manager */
    dbmDictionary*      mDic;                             /* dictionary for DDL */

    dbmTransLogger*     mTransLogger;                     /* mTransMgr */
    int                 mDiskLoggingF;                    /* flag for disk logging */

    dbmDataObject*      mData;                            /* user data */

public:
    dbmTransManager( );
    //dbmTransManager( cmnLogHandle* aTLogH );
    ~dbmTransManager( );

    char* mGetUndoName( void )
    {
        return mInstName;
    }

    dbmTableManager* mGetTableMgr( int aIndex )
    {
        return mTable[aIndex];
    }

    dbmQueueManager* mGetQueueMgr( int aIndex )
    {
        return mQueue[aIndex];
    }

    dbmListManager* mGetListMgr( int aIndex )
    {
        return mList[aIndex];
    }

    //_VOID mGetTableObj    ( int mIdx, dbmTableManager* aObj );
    int   mGetTransID     ( void );
    _VOID mInitTran       ( char* aUndoName,
                            void* aSessInfo,
                            void* aConfigObj,
                            dbmConnType aConType = DBM_LOCAL_CONNECT);
    _VOID mPrepareTable   ( char* aTableName );
    _VOID mFinalTran      ( void );
    _VOID mAct            ( void* aHandle );

    _VOID mFindTableInTx  ( char* aTableName, int* aTableIdx );
    _VOID mFindQueueInTx  ( char* aQueueName, int* aQueueIdx );
    _VOID mFindEventInTx  ( char* aQueueName, int* aQueueIdx );
    _VOID mFindListInTx   ( char* aListName, int* aListIdx );
    _VOID mFindIndexInTbl ( dbmTableManager* aTable, char* aIndexName, int* aIdx );

    static _VOID mDumpAllSlotList( char*            aUndoName,
                                 int                aTxID );
    static _VOID mDumpSlotList ( const char*        aStr,
                                 dbmSegmentManager* aSegMgr,
                                 long long          aStartSlot,
                                 long long          aLastSlot );
    static EXPORT_DLL _VOID mDumpTxLog    ( char*              aUndoName,
                                 int                aTxID,
                                 int                aFlag = 0);
    static EXPORT_DLL _VOID mDumpTxTable  ( dbmTransTable*     aTransTable );
    static EXPORT_DLL _VOID mDumpTxTable  ( char*              aUndoName,
                                 int                aStartIdx,
                                 int                aEndIdx );
    static int mDumpTxHeader   ( char*              aTransHeader );

//    static int mGetLogPtr   ( dbmSegmentManager* aSegMgr , long long aLogPos , char** aLogPtr );
//    static int mGetImagePtr ( dbmSegmentManager* aSegMgr , long long aImagePos , char** aImagePtr );

private:
    /*
     * Commit / Rollback 처리
     */
    _VOID mActCommitLib         ( int aDeferF );
    _VOID mActCommit            ( void );
    _VOID mDeferCommit          ( void );
    _VOID mDeferSync            ( void );
    _VOID mActNormalRollback    ( void );
    _VOID mActPartialRollback   ( long long aBackupLogPos, long long aBackupImagePos );
    _VOID mDoRollback           ( long long aBackupLogPos, long long aBackupImagePos );

    /*
     * DDL 처리
     */
    _VOID mActDDL               ( void* );
    _VOID mActTruncate          ( void* );
    _VOID mActAlterTableDiskLog ( void* );
    _VOID mActAlterTableMemLog  ( void* );
    _VOID mActCreateTable       ( void* );
    _VOID mActCreateIndex       ( void* );
    _VOID mActCreateTrig        ( void* );
    _VOID mActDropTable         ( void* );
    _VOID mActDropIndex         ( void* );
    _VOID mActDropTrig          ( void* );


    _VOID mHandleTransLog ( dbmLogHeader* aLog , dbmSegmentManager* aObjectSeg );


    /*
     * Etc
     */
    _VOID mActSetIndex  ( void* );
    _VOID mActGetIndex  ( void* );
    void mClearTransMgr  ();
    _VOID mFreeTransMgr ();
    void mInitTransItem  ( int              aTransId,
                           dbmTransHeader*  aTransHeader,
                           long long        aSessionID,
                           int              aUserID,
                           int              aPID,
                           dbmTxStatus      aStatus,
                           int              aSlotSize );

#if 0       // -fno-inline 옵션을 제거하기 위해
    char* mGetTxTable    ( char*            aUserHeader );
    char* mGetUndoHead   ( char*            aUserHeader );
#else
    inline
    char* mGetTxTable ( char* aUserHeader )
    {
        return (char*) ( aUserHeader );
    }

    inline
    char* mGetUndoHead ( char* aUserHeader )
    {
        return (char*) ( aUserHeader + sizeof(dbmTransTable) );
    }
#endif

    _VOID mActSessionOption ( dbmDataObject* aData, int* aValue ) ;

    int   mGetConfig     ( dbmConfig*       aConfigMgr,
                           char*            aUndoName,
                           const char*      aItemName );
    _VOID mGetTableConfig( dbmConfig*       aConfigMgr,
                           char*            aUndoName,
                           long long*       aUserInitSize,
                           long long*       aUserExtendSize,
                           long long*       aUserMaxSize,
                           long long*       aInitSize,
                           long long*       aExtendSize,
                           long long*       aMaxSize );
    _VOID mGetSessID     ( dbmUndoHeader* aUndoHeader, long long* aSessID );
    _VOID mUnprepareTable( char* aTableName, int aTableType );
};


#endif  /* __O_DBM_TRANS_MANAGER_H__ */
