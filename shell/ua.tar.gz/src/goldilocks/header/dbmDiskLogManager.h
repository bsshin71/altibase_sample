/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    DBM Disk Log read/write용도로만 쓸 것임.
*******************************************************************************/
#ifndef __O_DBM_DISK_LOG_MANAGER_H__
#define __O_DBM_DISK_LOG_MANAGER_H__

#include "dbmCommon.h"
#include "dbmAnchorManager.h"

/*******************************************************************************
 * DEFINE
*******************************************************************************/


#ifdef __cplusplus

/*******************************************************************************
 * CLASS
*******************************************************************************/
class dbmDiskLogManager
{
private:
    /************************************************
     * 내부 멤버변수들
    ************************************************/
    dbmConfig         * mConf;                    // Config Manager
    dbmAnchorManager  * mAnchor;                  // Anchor Class
    dbmDiskLogHeader  * mHeader;                  // Disk Log Header Pointer
    char              * mLogData;                 // Alloc할 메모리
    char                mPath     [1024];         // LOG_DIR
    char                mUserName [DBM_NAME_LEN]; // UserName
    int                 mTransID;                 // TransID
    int                 mCurrFD;                  // Current FD
    int                 mCurrFileNo;              // FileNo
    long long           mCurrFileOffset;          // FileOffset
    long long           mLogFileSize;             // Logfile MaxSize
    int                 mOffset;                  // LogBuffer Indicator
    int                 mCkptEnable;

    int                 mReadFD;                  // 현재 읽고 있는 FileNo
    long long           mReadOffset;              // 현재 읽고 가는 지점
    int                 mAllocSize;               // Allocation Size

    /************************************************
     * 내부 함수
    ************************************************/
    int mSwitchDiskLog ();                      // Switch Disk Log
    int mPushDiskFile  ();                      // 체크포인트한테 일하라고 던진다.
public:
    /************************************************
     * 생성, 소멸
    ************************************************/
    dbmDiskLogManager   ( );
    ~dbmDiskLogManager  ();

    /************************************************
     * 외부 공개 함수
    ************************************************/
    int mInitialize     (const char        * aUserName         // UserName
                       , int                 aTransID );       // TransID

    int mInitialize     (char              * aUserName         // UserName
                       , int                 aTransID );       // Trans-ID

    int mGetMemorySize ();                                     // 잡아놓은 LogBuffer 크기 리턴.
    int mExtendMemory  (int                  aSize);           // 잡아놓은 LogBuffer를 확장해야 할떄
    int mAppendDiskLog (dbmDiskLogPiece    * aLog);            // 메모리로그를 하나씩 추가할때 호출
    int mWriteDiskLog  ();                                     // 진짜 Disk에 쓰면 될 때 호출

    int mReadFirst     (char *  aFileName,   char ** aData);   // 첫번째 로그 읽을때.
    int mReadNext      (char ** aData);                        // 두번째 로그 읽을때
};


#endif

#endif  /* __O_DBM_DISK_LOG_MANAGER_H__ */

