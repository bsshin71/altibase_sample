

/*******************************************************************************
 *
 * Disk 에 실제 Write 하도록 만든 모듈이며, dbmTransLogger 를 상속받는다. 
 *
 * 주요한 member 는 mFlush () 와 mSync() 이며, 특히 mFlush 부분은 실제 Disk 에 Transaction 
 * Log 를 내려쓰는 부분을 담고 있는데, Block 단위로 나누어서 Disk 에 쓴다. 이때 Block 단위는 
 * 512 Byte 이며, Block Header + Block Data 로 구성되어있다. 
 *
 * mFlush 함수는 dbmTransLogger 에서 사용하는 mLogBuffer 를 512 - sizeof(dbmBlockHeader) 로 
 * 잘라서 Disk Block 을 구성한다. 각각의 Block 은 dbmBlockHeader 구조체를 Header 로 담고 있는데 
 * 해당 LSN 와 각 LSN 의 몇번째 Block 인지 , 언제 쓰였는지등의 부가정보를 담고 있다. 
 *
 * LSN 은 Commit 시점에 채번하기 때문에 한 LSN 에 속한 Block 은 모두 한 Transaction 으로 볼 수 있고
 * 이 Block 들의 정보는 모두 유실없이 기록되어야 복구가 가능하다.  만약 Block Sequence 가 다르다면 
 * 이 정보는 Curruption 된것으로 볼수 있고, 이는 데이터가 깨졌다고 봐야하는데 구조상 절대 그런게 발생 
 * 할수 없기 떄문에 로그파일 자체가 깨졌다고 보는것이 타당하다. 
 *
 * Disk 에 로깅되는 파일 단위는 각각의 파일이 하나의 Transation ID 와 매칭되며, 하나의 Transaction 은
 * 자신의 파일에만 Write 를 수행하며, 필요시점에 Switch 를 수행한다. 
 *
 * 이러한 개별적인 정보를 하나로 통합하기 위해서 LogAnchor 개념을 두었고, 이 Log Anchor 에는 
 * 로그파일이 쓰여지고 있는 전체정보를 관리한다. 그러나 실제 복구 시점에는 로그앵커파일과 실제 
 * Transaction 파일 간의 정보가 미스매치가 발생할 수 있기 때문에 전체 파일 리스트를 읽어서 로그 앵커를 
 * 재구성한다. 
 *
 * LogAnchor 는 언두 헤더에 저장되며, 실제 처리하는 과정은 모두 메모리에서 수행되는데 Switching 등의 
 * 연산 발생시 Disk 로 내려쓰도록 되어있다. 이런 방식으로 보자면 사실 Log Anchor 무용론이 있을 수 있는데, 
 * 사실 현재구조에서는 굳이 필요가 없을 수도 있다. 
 ******************************************************************************/


#ifndef __O_DBM_TRANS_DISK_WRITE_H__
#define  __O_DBM_TRANS_DISK_WRITE_H__

#include "dbmTransLogger.h"

class dbmDiskLogger : public dbmTransLogger
{
public:
//    dbmDiskLogger ( );              // Constructor
    virtual ~dbmDiskLogger ( );     // Desctructor

    dbmDiskLogger ( int aTxID , dbmLogAnchor *aLogAnchor , long long aLogBufferSize , dbmDiskSyncOption aOpts );
    _VOID mFlushAnchor ( );

public:
    virtual _VOID mFlush ( );
    virtual _VOID mSync ( );
    virtual _VOID mAnchor ( int aFalgF );
    //virtual int mCommitSync ( );  // 죽은코드

public:
    int     mSyncBytes;

protected:
    dbmLogAnchor* mLogAnchor;
    int     mFD;
    int     mReplFD;
    int     mHeaderFD;
//  int     mCurrentFile;
//  int     mImage;
    long long mMyFileSize;

    _VOID   mSwitchFile ( );
    char*   mAlignedBuf;

    dbmDiskSyncOption mSyncOpt;
    int     mDirectF;               // O_DIRECT 사용여부를 별도로 관리

private:
    int   getSyncOpt ( );
    _VOID mWriteLogFileHeader ( );
    _VOID mUpdateLogFileHeader ( long long aMarkLSN );
    _VOID mWriteEOF ( );

    long long mLastLSN;
};

class dbmCompressDiskLogger : public dbmDiskLogger
{
public:
    dbmCompressDiskLogger ( int aTxID , dbmLogAnchor * aLogAnchor , long long aLogBufferSize , dbmDiskSyncOption aOpts );
    dbmCompressDiskLogger ( );
    virtual ~dbmCompressDiskLogger ( )
    {
    }
    ;
    virtual _VOID mFlush ( );

private:
    _BOOL mCompress ( );

private:
    char*   mOutputBuffer;

    int     mLogBufferSize;
    int     mCompressBytes;
};

#endif /* __O_DBM_TRANS_DISK_WRITE_H__ */


