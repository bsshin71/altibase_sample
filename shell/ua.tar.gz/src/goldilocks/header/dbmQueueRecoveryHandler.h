#ifndef __O_DBM_QUEUE_RECOVERY_HANDLER_H__
#define __O_DBM_QUEUE_RECOVERY_HANDLER_H__

#include "dbmHeader.h"

class dbmTransLogger;

class dbmQueueRecoveryHandler
{
public:
    dbmQueueRecoveryHandler ( );
    ~dbmQueueRecoveryHandler ( );

    _VOID mComplete ( );

    _VOID mFindQueueIdx ( char* aQueueName , int* aIdx );

    _VOID mHandleDequeLog ( char* aInstName, dbmLogHeader* aCurLog , char* aRecoveryImage );
    _VOID mFinalize ( );

    _VOID mSetTransLogger ( dbmTransLogger* aTransLogger )
    {
        mTransLogger = aTransLogger;
        return 0;
    }

private:

    int     mQueueIdx;
    char    mQueueNames[DBM_MAX_TABLE_PER_TRANS][DBM_NAME_LEN];
    // 2015.03.17 -okt- 미사용변수 제거
    //int     mTxID[DBM_MAX_TABLE_PER_TRANS];

    dbmQNodeHeader*     mFirst[DBM_MAX_TABLE_PER_TRANS];
    dbmQNodeHeader*     mLast[DBM_MAX_TABLE_PER_TRANS];
    dbmSegmentManager*  mSegMgr[DBM_MAX_TABLE_PER_TRANS];

    dbmTransLogger*     mTransLogger;
};


#endif
