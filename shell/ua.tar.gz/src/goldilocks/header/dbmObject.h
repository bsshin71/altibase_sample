/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *
 ******************************************************************************/
#ifndef __O_DBM_INTERNAL_OBJECT_H__
#define __O_DBM_INTERNAL_OBJECT_H__

#include "dbmDefine.h"

#ifdef __cplusplus
extern "C"
{
#endif


/**************************************************************
 * 이곳에 있는 Object 들에는 함부로 멤버를 추가하거나 하면 안된다.
 * Fix 된 Schema 의 Dictionary 에서도 사용하기 때문.
 * 변경을 하고자 할 때는 먼저 협의하고 testcase 까지 검증을 해야 한다.
**************************************************************/

/**************************************************************
 * Segment infor Structure
**************************************************************/
typedef struct dbmInstanceObject
{
    long long       mInstanceID;
    char            mInstanceName[DBM_NAME_LEN];
    int             mMaxSegNo;
    long long       mInitSize;
    long long       mExtendSize;
    long long       mMaxSize;
    struct timeval  mCreateTime;
} dbmInstanceObject;


/**************************************************************
 * Column infor Structure
**************************************************************/
typedef struct dbmColumnObject
{
//    int             mColumnID;  // #824 2015.02.24 -okt- 인덱스 컬럼개수 6개에서 32개로 늘림 - align
    long long       mInstID;
    long long       mTableID;
    int             mColumnID;
    dbmColumnType   mColumnType;
    char            mColumnName [DBM_NAME_LEN];
    int             mSize;
    int             mOffset;
    int             mPrecision;
    int             mScale;
} dbmColumnObject;


typedef struct dbmColumnSetObject
{
    int             mCount;
    dbmColumnObject mCols [DBM_MAX_COLUMN];
} dbmColumnSetObject;


/**************************************************************
 * Table infor Structure
**************************************************************/
typedef struct dbmTableObject
{
    long long       mInstID;
    long long       mTableID;
    char            mInstName   [DBM_NAME_LEN];
    char            mTableName  [DBM_NAME_LEN];
    dbmTableType    mTableType;
    int             mColumnCount;
    int             mRecordSize;
    long long       mInitSize;
    long long       mExtendSize;
    long long       mMaxSize;
    int             mTimeOut;
    short           mNologgingF;
    short           mNoMemloggingF;
    char            mIndexName  [DBM_MAX_INDEX_PER_TABLE][DBM_NAME_LEN];
    struct timeval  mCreateTime;
} dbmTableObject;



/**************************************************************
 * Index infor Structure
**************************************************************/
typedef struct dbmIndexObject
{
    long long       mIndexID;
    long long       mInstID;
    long long       mTableID;
    char            mInstName   [DBM_NAME_LEN];
    char            mTableName  [DBM_NAME_LEN];
    char            mIndexName  [DBM_NAME_LEN];
    dbmIndexType    mIndexType;
    dbmUniqueType   mIsUniqueIndex;
    int             mColumnCount;
    int             mKeySize;
    dbmColumnObject mKey [DBM_MAX_COLUMN_PER_INDEX];
    struct timeval  mCreateTime;
} dbmIndexObject;


/**************************************************************
 * Event infor Structure
**************************************************************/
typedef struct dbmEventObject
{
    char            mInstName   [DBM_NAME_LEN];
    char            mTriggerName[DBM_NAME_LEN];
    char            mEventSrc   [DBM_NAME_LEN];
    char            mEventTrg   [DBM_NAME_LEN];
    char            mEnableFlag [8];
} dbmEventObject;


/**************************************************************
 * all objects' info - using by dictionary
**************************************************************/
typedef struct dbmObjectObject
{
    char            mInstName   [DBM_NAME_LEN];
    char            mObjectName [DBM_NAME_LEN];
    char            mObjectType [DBM_NAME_LEN];
} dbmObjectObject;


/**************************************************************
 * Table Total Info
**************************************************************/
typedef struct dbmTableInfo
{
    dbmTableObject      mTable;
    unsigned long long  mIndexCount;
    dbmIndexObject      mIndex[DBM_MAX_INDEX_PER_TABLE];
    dbmColumnSetObject  mColumn;
} dbmTableInfo;



/**************************************************************
 * Session info
**************************************************************/
typedef struct dbmSessionObject
{
    long long       mSessionID;                         // Session ID
    int             mUserID;                            // User ID
    int             mPID;                               // Process ID
    dbmConnType     mConnType;                          // 연결유형 ( LOCAL, REMOTE)
    int             mSocket;                            // Socket
    char            mIP [DBM_NAME_LEN];                 // IP 정보
    int             mPortNo;                            // PortNo
    struct timeval  mConnectTime;
} dbmSessionObject;


/**************************************************************
 * User info
**************************************************************/
typedef struct dbmUserObject
{
    int                 mUserID;                        // User ID
    char                mUserName[DBM_NAME_LEN];        // User 이름
    char                mUserPass[DBM_NAME_LEN];        // User 암호
    int                 mPermission;                    // User 권한 정의(Not Yet)
    struct timeval      mCreateTime;                    // 생성 시간
} dbmUserObject;


/**************************************************************
 * Data
**************************************************************/
typedef struct dbmDataSetObject
{
    char                mColumnName [DBM_NAME_LEN];
    char                mData [DBM_MAX_RECORD_SIZE];
    dbmSignType         mSign;
    int                 mDateFlag;
} dbmDataSetObject;

typedef struct dbmDataSet
{
    int                 mCount;                         // first column clause
    int                 mCount2;                        // second column clause
    int                 mCount3;                        // count clause
    dbmDataSetObject    mCols [DBM_MAX_COLUMN];
    char                mDateForm [DBM_MAX_COLUMN][DBM_MAX_RECORD_SIZE];
    int                 mDateFormCount;
    int                 mLimit;
    int                 mLimitOffset;
} dbmDataSet;

/**************************************************************
 * Parse Result Object
**************************************************************/
typedef struct dbmParseObject
{
    dbmTransType    mSQLType;

    union
    {
        dbmInstanceObject   mInstance;                  // create/drop instance
        dbmTableInfo        mTableInfo;                 // create/drop table/queue
        dbmIndexObject      mIndex;                     // create/drop index
        dbmEventObject      mEvent;                     // create/drop event(trigger)
        dbmUserObject       mUser;                      // create/drop user
        void*               mDataSet;
    } mObj;
    char            mSQL [DBM_MAX_SQL_LEN] ;            // SQL Text
    void*           mDataSet2;
} dbmParseObject;

/**************************************************************
 * DicObject
**************************************************************/
typedef dbmParseObject   dbmDicObject;


/**************************************************************
 * DataObject
**************************************************************/
typedef struct dbmDataObject
{
    dbmTransType    mTransType;                         // dbmTransType
    dbmTransType    mSearchWay;                         // GT? LT?
    char            mTableName [DBM_NAME_LEN];          // 대상 테이블
    dbmHandleOption mOption ;                           // Handle Option 종류
    int             mOptionVal ;                        // 해당 옵션의 값
    char*           mUserData;                          // UserData Pointer
    char*           mUserEndData;                       // For FetchRange
    char*           mColName;                           // Bind Column Name
    int             mDataSize;                          // Data Size
    long long       mSCN;                               // Serial Commit Number
    int             mTimeout;
    /*
     * -shw- search GT,LT type 추가
     * #886 2015.03.07 -okt- 선행하는 EQ의 개수로 사용하기 위해서 변수명을 mIndexType에서 mEQCnt로 변경
     */
    int             mEQCnt;                             // (구) mIndexType
    int             mIndexCount;                        // non-unique Count

    // Add for multi-row
    long long       mFetchRows[DBM_INDEX_DEGREE];       // Multi-Fetch-Row  추가
    char            mFetchKey[DBM_INDEX_DEGREE][DBM_INDEX_KEY_MAX_SIZE];
    short           mPartialCheck;
    int             mFetchInd;                          // Curr indicator in multi-rows
    int             mFetchCount;                        // number of fetching
    int             mLogCheck;
    int             mFirstLogCheck;
    volatile long long  mBackupLogPos;
    long long           mBackupImagePos;
} dbmDataObject;


/**************************************************************
 * Statistics
**************************************************************/
typedef struct dbmStatObject
{
    long long       mSelectTryCount;
    long long       mInsertTryCount;
    long long       mDeleteTryCount;
    long long       mUpdateTryCount;
    long long       mEnqueTryCount;
    long long       mDequeTryCount;
    /*
     * more stat here
     */
} dbmStatObject;


/**************************************************************
 * DiskLog Block Header
**************************************************************/
typedef struct dbmDiskLogHeader
{
    int             mTotalSize;                         // Log의 전체 크기 ( Header포함 )
    int             mTotalCount;                        // Log의 Count
    struct timeval  mWriteTime;                         // Write Time
} dbmDiskLogHeader;


/**************************************************************
 * DiskLog Manager를 쓰는 상위 사용자가 알면 되는거.
**************************************************************/
typedef struct dbmDiskLogPiece
{
    int             mSize;                              // 로그 1개당 길이 ( 자기 field길이 포함해서. )
    long long       mSCN;                               // SCN정보
    int             mTransType;                         // 로그 유형
    char            mInstName  [DBM_NAME_LEN];          // Undo
    char            mTableName [DBM_NAME_LEN];          // Table
    int             mOffset;                            // 실제 위치
    char            mData [16 + DBM_MAX_RECORD_SIZE];   // RowHeader + 데이터
} dbmDiskLogPiece;




/*******************************************************************************
 * CheckPoint List 관리 구조체
*******************************************************************************/
typedef struct dbmAnchorHeader
{
    volatile int    mLock;
    volatile int    mFutex;
    long long       mReadInd;
    long long       mWriteInd;
} dbmAnchorHeader;


/*******************************************************************************
 * LogAnchor
*******************************************************************************/
typedef struct dbmAnchorSlot
{
    int             mLastFileNo;                        // 자신의 현재 파일번호
    long long       mLastFileOffset;                    // 자신의 현재 파일의 Offset
    long long       mMaxSize;                           // 이 파일의 최대크기
    long long       mMinSCN;                            // 이 파일의 최소SCN
} dbmAnchorSlot;


/*******************************************************************************
 * MOM Topic Event Key
*******************************************************************************/
typedef struct momTopicKey
{
    char         mTopic [32];
    long long    mMsgID;
} momTopicKey;

/*******************************************************************************
 * MOM Topic Data
*******************************************************************************/
typedef struct momTopicData
{
    long long    mMsgID;
    int          mSize;
    char         mData[2048];
} momTopicData;


#ifdef __cplusplus
};
#endif

#endif  /* __O_DBM_INTERNAL_OBJECT_H__ */
