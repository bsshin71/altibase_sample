/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    Transaction Recovery Manager
 *    장애 시 복구나 Log 들의 dump 들을 찍어보는 등 장애처리 및 복구를
 *    위해 사용되는 Manager 로 객체없이 undo name 만으로 모든 것을
 *    처리할 수 있는 함수들을 모아놓았음.
 *    dbmTransactionManager 에서 복구까지 처리하게 되면, table 및 queue manager
 *    단에서 Transaction 을 복구하고자 할 때 더 상위 layer 의 Transaction Manager 를
 *    이용해야하는 상황이 생긴다.
 *    이를 막기 위해 전혀 별개의 manager 로 분리하였다.
 *
 ******************************************************************************/
#ifndef __O_DBM_RECOVERY_MANAGER_H__
#define __O_DBM_RECOVERY_MANAGER_H__

#include "dbmCommon.h"
#include "dbmLogManager.h"


/**************************************************************
 * Definition
**************************************************************/
_VOID dbmInitIndexHeader( dbmIndexHeader* aIndexHeader );
_VOID dbmInitQueueHeader( dbmQueueHeader* aQueueHeader );
_VOID dbmInitListHeader ( dbmListHeader*  aListHeader  );
_VOID dbmInitTableHeader( dbmTableHeader* aTableHeader );


/**************************************************************
 * dbmRecoveryManager class
**************************************************************/
class dbmRecoveryManager
{
public:
    static int mFinalTran           ( dbmSegmentManager* aUndoSegMgr,
                                      int                aTransID );
    static _VOID mRecoverTrans      ( char*              aUndoName,
                                      dbmSegmentManager* aUndoSegMgr,
                                      int                aTransID );
    static _VOID mRecoverTrans      ( char*              aUndoName,
                                      int                aTransID );
    static _VOID mRecoverAllTrans   ( char*              aUndoName );
    static _VOID mClearTransItem    ( dbmTransHeader*    aTransHeader );
    static _VOID mDumpTxHeader      ( char*              aTransHeader, int aFlag = 0 );
    static _VOID mLinkReverseList   ( dbmSegmentManager* aUndoSegMgr,
                                      dbmTransHeader*    aHeader,
                                      long long          aSlotID );
    static _VOID mRollbackRecovery  ( char*              aUndoName,
                                      int                aTransID );
    static _VOID mRollbackRecovery  ( char*              aUndoName,
                                      dbmSegmentManager* aUndoSegMgr,
                                      int                aTransID );


#if 0       // -fno-inline 옵션을 제거하기 위해 ( 실패 예제로 하나만 남겨둠 )
    static char* mGetTxHead ( char* aUserHeader, int aTransID );
#else
    inline
    static char* mGetTxHead ( char* aUserHeader , int aTransID )
    {
        return ( (char*) aUserHeader + sizeof(dbmTransHeader) * aTransID );
    }
#endif

    inline
    static char* mGetTxHead ( dbmTransTable* aTxTable , int aTransID )
    {
        return ( (char*) aTxTable + sizeof(dbmTransHeader) * aTransID );
    }

    inline
    static _VOID mGetLogPtr ( dbmSegmentManager* aSegMgr , long long aLogPos , void* aLogPtr /* char** aLogPtr */ )
    {
        char*   sTmp = NULL;
        int     sRC;

        sRC = aSegMgr->Slot2Addr ( SLOTID( aLogPos ), &sTmp );
        if ( unlikely( sRC ) ) // || sTmp == NULL )
        {
            return -2;
        }

        *(dbmLogHeader**)aLogPtr = GETLOG ( sTmp, OFFSET ( aLogPos ) );
        return 0;
    }

    inline
    static _VOID mGetImagePtr ( dbmSegmentManager* aSegMgr , long long aImagePos , void* aImagePtr /* char** aImagePtr */ )
    {
        char*   sTmp = NULL;
        int     sRC;

        sRC = aSegMgr->Slot2Addr ( SLOTID ( aImagePos ), &sTmp );
        if ( unlikely( sRC ) ) // || sTmp == NULL )
        {
            return -2;
        }

        *(dbmRowHeader**)aImagePtr = GETIMG ( sTmp, OFFSET ( aImagePos ) );
        return 0;
    }


    static _VOID mForceEnqueueCommit( char*              aInstName,
                                      dbmTransHeader*    aTxH,
                                      long long          aStartPos,
                                      long long          aEndPos,
                                      dbmSegmentManager* aUndoSegMgr );

    static _VOID mRollbackDequeAll  ( char*              aInstName,
                                      dbmTransHeader*    aTxH,
                                      long long          aStartPos,
                                      long long          aEndPos,
                                      dbmSegmentManager* aUndoSegMgr );
    static _VOID mRollbackDequeOne  ( dbmLogHeader*      aCurLog,
                                      char*              aImage,
                                      int                aImageSize,
                                      dbmSegmentManager* aSegMgr,
                                      dbmQueueHeader*    aQueueHeader );

    static _VOID mDropIndexFromTableHeader ( char* aInstName, char* aTableName , char* aIndexName );

    static int mCheckRollbackWithDisk ( dbmTransHeader * aTxH,
                                        int              aTxID,
                                        dbmLogAnchor    *aAnchor ) ;


#if 0
    static int mDumpAllSlotList     ( char*              aUndoName,
                                      int                aTxID );
    static int mDumpSlotList        ( const char*        aStr,
                                      dbmSegmentManager* aSegMgr,
                                      long long          aStartSlot,
                                      long long          aLastSlot );
    static int mDumpTxLog           ( char*              aUndoName,
                                      int                aTxID );
#endif
};


#endif  /* __O_DBM_RECOVERY_MANAGER_H__ */
