/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
*******************************************************************************/
#ifndef __O_DBM_INTERNAL_HANDLE_H__
#define __O_DBM_INTERNAL_HANDLE_H__

#include "dbmCommon.h"
#include "dbmTransManager.h"
#include "cmnErrorManager.h"      // dbmError


/*************************************************************
 * DEFINE
*************************************************************/
#define DBM_HANDLE_MARK          (993939392020101L)             // MAGIC VAL
#define DBM_DEFAULT_UNDO_NAME    "sys"


/*************************************************************
 * 구조체
*************************************************************/
typedef struct dbmInitMsgBody   dbmInitMsgBody;
typedef struct dbmMsgBody       dbmMsgBody;
typedef struct dbmRemoteMsg     dbmRemoteMsg;
typedef struct dbmRemoteHandle  dbmRemoteHandle;

typedef struct dbmInternalHandle
{
    char                mInstanceName[DBM_NAME_LEN];
    char*               mBindParam;
    dbmDictionary*      mDic;
    dbmTransManager*    mTrans;
    dbmSessionObject    mSess;
    dbmConfig*          mConf;
    dbmDataObject       mData;
    cmnErrorManager*    mError;
    dbmHandleOption     mOption;

    dbmRemoteHandle*    mRemote; /* for remote connection */
} dbmInternalHandle ;


typedef struct dbmInitMsgBody
{
    int                 mRC;                            /* result code for reponse msg */
} dbmInitMsgBody;


typedef struct dbmMsgBody   dbmRemoteObject;
typedef struct dbmMsgBody
{
    int                 mRC;                            /* result code for reponse msg */
    char                mTableName[DBM_NAME_LEN];       /* 대상 테이블 */
    //char*             mUserEndData;                   /* For FetchRange */
    char                mColName[DBM_NAME_LEN];         /* Bind Column Name */
    //long long         mSCN;                           /* Serial Commit Number */
    int                 mTimeout;
//  int                 mIndexType;                     /* search GT,LT type 추가 */
    int                 mEQCnt;                         /* search GT,LT type 추가 */
    int                 mIndexCheck;                    /* non-unique First Check */
    dbmHandleOption     mOption    ;                    /* Handle 의 옵션 */
    int                 mOptionVal ;                    /* 옵션 값 */
    int                 mDataSize;                      /* Data Size */
    int                 mCount;                         /* DBM_SELECT_COUNT 용 리턴 */
    long long           mSeq;                           /* sequence value */
    int                 mUserDataIsNULL;                /* UserData NULL 확인용 */
    char                mUserData[DBM_MAX_RECORD_SIZE]; /* UserData */
    char                mUserData2[DBM_MAX_RECORD_SIZE]; /* UserData2 */
} dbmMsgBody;


/* 실제 송수신되는 Message Buffer */
typedef struct dbmRemoteMsg
{
    int                 mMsgSize;                       /* msg size */
    dbmTransType        mMsgType;                       /* dbmTransType */
    char                mInstName [DBM_NAME_LEN];       /* instance name */

    union
    {
        dbmInitMsgBody  mInitMsgBody;                   /* msg body for init handle */
        dbmMsgBody      mMsgBody;                       /* msg body for all besides init */
    } mBody;
} dbmRemoteMsg;


typedef struct dbmRemoteTableInfo
{
    char                mTableName[DBM_NAME_LEN];
    int                 mRowSize;
} dbmRemoteTableInfo;


typedef struct dbmRemoteHandle
{
    int                 mSockFd;
    int                 mTableCount;
    dbmRemoteTableInfo  mTable[DBM_MAX_TABLE_PER_TRANS]; /* save prepared table info */

    dbmRemoteMsg        mMsg;       /* dbmRemoteMsg - 실제 전송하는 msg */
} dbmRemoteHandle;


#ifdef __cplusplus
extern "C"
{
#endif

/*************************************************************
 * Internal Function
*************************************************************/
extern int dbmLoadConfig ( dbmInternalHandle* aHandle );
extern int dbmInitTrans  ( dbmInternalHandle* aHandle );
extern int dbmInitSess   ( dbmInternalHandle* aHandle, dbmConnType aConnType );


extern int dbmExecInterColumn( dbmInternalHandle* aHandle,
                               const char* aTable,
                               void* aData,
                               dbmIndexObject* aDicIDXObj,
                               dbmTableObject* aDicTBLObj );
extern int dbmExecDic( dbmInternalHandle* aHandle,
                       const char* aTable,
                       void* aData,
                       dbmIndexObject** aDicIDXObj,
                       dbmTableInfo** aDicTBLInfo,
                       int aCheck ,
                       char (*aColumnFilterName)[DBM_NAME_LEN] = NULL,
                       int* aFilterCount = NULL, 
                       dbmHandle* aHandle2 = NULL );

extern int dbmExecColBind ( dbmHandle* aHandle , 
                            const char* aTable, 
                            void* aData, 
                            dbmIndexObject* aDicIDXObj, 
                            dbmTableInfo* aDicTBLInfo,
                            char (*aColumnFilterName)[DBM_NAME_LEN],
                            int sFilterCount );

extern int dbmExecBindData( dbmColumnObject* aDicColObj , char* aBindData , void* aData, int aDirectF );
extern int dbmExecDataCheck( void* aData, void* aDataTwo, dbmIndexObject* aDicIDXObj );
extern int dbmExecUpdate( void* aData, void* aTmpTable, dbmTableInfo* aDicTBLInfo, dbmIndexObject* aDicIDXObj );

/*************************************************************
 * Internal Function for Remote Connection
*************************************************************/
extern _VOID dbmRemoteCreateDDL ( dbmHandle* aHandle , const char* aSQL );
extern _VOID dbmRemoteDropTable ( dbmHandle* aHandle , const char* aTable );
//extern _VOID dbmRemoteDropQueue ( dbmHandle* aHandle , const char* aTable );
//extern _VOID dbmRemoteDropIndex ( dbmHandle* aHandle , const char* aIndex );
extern _VOID dbmRemoteTruncate ( dbmHandle* aHandle , const char* aTable );
extern _VOID dbmRemoteGetIndex ( dbmHandle* aHandle , const char* aTable, char* aIndexName );
extern _VOID dbmRemoteSetIndex ( dbmHandle* aHandle , const char* aTable, const char* aIndexName );
extern _VOID dbmRemotePrepareTable ( dbmHandle* aHandle , const char* aTable );
extern _VOID dbmRemoteColBind ( dbmHandle* aHandle, const char* aTable, const char* aColName, void* aUserData, int aColsize );
extern _VOID dbmRemoteClearBind (dbmHandle* aHandle);



#ifdef __cplusplus
};
#endif

#endif  /* __O_DBM_INTERNAL_HANDLE_H__ */
