/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 * ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    Index Manager 관련 자료구조 및 Definition 정의
 *
 ******************************************************************************/
#ifndef __O_DBM_INDEXMGR_INTERFACE_H__
#define __O_DBM_INDEXMGR_INTERFACE_H__

#include "dbmCommon.h"
#include "dbmObject.h"
#include "dbmStruct.h"
#include "dbmSegmentManager.h"
#include "dbmLogManager.h"
#include "dbmLockManager.h"

#define INDEX_POS(BASE,Y,X)    ( (char*)BASE + ( sizeof(dbmIndexNode) + ( (Y) * (X) ) ) )   // 곱하기 괄호 필수
#define INDEX_KEY_SIZE(BASE)   (BASE + 8)   // non-unique index Extra size long(8byte)더 가져온다.
#define PUTLINE "*===========================================*"
//#define INDEX_TEST2 1

/**************************************************************
 * dbmIndexManager class
 **************************************************************/
class dbmIndexManager
{
public:
    dbmIndexManager ( );
    ~dbmIndexManager ( );

    dbmSegmentManager* mGetSegMgr ( )
    {
        return mSegMgr;
    }
    dbmIndexHeader* mGetIndexHeader ( )
    {
        return mIndexHeader;
    }

    char* mGetIndexName ( )
    {
        return mIndexName;
    }
    int mGetIndexID ( )
    {
        return mIndexID;
    }

    void mSetSkipCompareKeysize ( int aSkipF )
    {
        mSkipCompareKeysize = aSkipF;
    }
    int mGetSkipCompareKeysize ( )
    {
        return mSkipCompareKeysize;
    }

    _VOID mInitIndex        ( char* aInstName, char* aIndexName, dbmLogManager* aLogMgr, dbmLockManager* aLockMgr );

    _VOID mInsertKey        ( int aTransID, char* aKey, long long aDataSlot );
    //_VOID mInsertKey        ( int aTransID, char* aKey, long long aDataSlot, long long* aExtraKey );
    _VOID mDeleteKey        ( int aTransID, char* aKey, int aCheck = 0 );
    static _VOID mInsertKey ( char* aInstName, long long aDataSlot, int aTransID, char* aIndexName, char* aKey );
    static _VOID mDeleteKey ( char* aInstName, int aTransID, char* aIndexName, char* aKey, int aCheck = 0 );

void ShowIndexBinaryDump( );
    _VOID mSearchKey        ( int aTransID, char* aKey, long long* aSlotID );
    _VOID mSearchKeyNu      ( int aTransID, char* aKey, long long* aSlotID, long long* aExtraKey, long long* aCurrExtraKey = NULL );
    _VOID mSearchKeyGT      ( int aTransID, char* aKey, long long* aSlotID, int* aCount, char aNextKey[][DBM_INDEX_KEY_MAX_SIZE], int aEQCnt = 0 );
    _VOID mSearchKeyGTNu    ( int aTransID, char* aKey, long long* aSlotID, char* aNextKey, long long* aExtraKey, int aEQCnt = 0 );
    _VOID mSearchKeyLT      ( int aTransID, char* aKey, long long* aSlotID, int* aCount, char aPrevKey[][DBM_INDEX_KEY_MAX_SIZE], int aEQCnt = 0 );
    _VOID mSearchKeyLTNu    ( int aTransID, char* aKey, long long* aSlotID, char* aPrevKey, long long* aExtraKey, int aEQCnt = 0 );

    _VOID mMax              ( int aTransID , dbmIndexNode* aNode, int* aNodeNo, int* aDepth, long long* aRID, char* aKey );
    _VOID mMin              ( int aTransID , dbmIndexNode* aNode, int* aNodeNo, int* aDepth, long long* aRID, char* aKey );

    int mIndexLogging       ( long long* aSlotID, int aTransID );

    void PrintNodeElement   ( dbmIndexNode* pNohe );
    void PrintNodeElement2  ( dbmIndexNode* pNohe );
    void PrintNodeElement3  ( dbmIndexNode* pNohe );
    void PrintNodeElement4  ( dbmIndexNode* pNohe );

private:
    int mIndexCompare       ( char* aNode, char* aKey, dbmSignType aKeyCheckType );
    int mIndexPosition      ( char* aNode, char* aKey );

    int mSearchExistNu      ( dbmIndexNode* aNode, char* aKey, int aTransID, long long* aExtraKey, long long* aRID, long long* aCurrExtraKey = NULL );

    void mBinarySearchSelectLeaf        ( int aCount, int* aPosition, dbmIndexNode* aCurr, char* aKey );
    void mBinarySearchSelectLeafNu      ( int aCount, int* aPosition, dbmIndexNode* aCurr, char* aKey, long long* aExtraKey );
    void mBinarySearchSelectExtraLeaf   ( int aCount, int* aPosition, dbmIndexNode* aCurr, char* aKey );

    int mSearchNextGT   ( dbmIndexNode* aNode, char* aKey, long long* aDataSlot, int* aCount, int aTransID, char aNextKey[][DBM_INDEX_KEY_MAX_SIZE], int aEQCnt = 0 );
    int mSearchNextGTNu ( dbmIndexNode* aNode, char* aKey, long long* aDataSlot, int aTransID, char** aNextKey, long long* aExtraKey, int aEQCnt = 0 );
    int mSearchNextLT   ( dbmIndexNode* aNode, char* aKey, long long* aDataSlot, int* aCount, int aTransID, char aPrevKey[][DBM_INDEX_KEY_MAX_SIZE], int aEQCnt = 0 );
    int mSearchNextLTNu ( dbmIndexNode* aNode, char* aKey, long long* aDataSlot, int aTransID, char** aPrevKey, long long* aExtraKey, int aEQCnt = 0 );

    int mSearchNextExtraGT ( dbmIndexNode* aNode, char* aKey, long long* aDataSlot, int aTransID, char** aNextKey, long long* aExtraKey, int aEQCnt = 0 );
    int mSearchNextExtraLT ( dbmIndexNode* aNode, char* aKey, long long* aDataSlot, int aTransID, char** aPrevKey, long long* aExtraKey, int aEQCnt = 0 );
    int mSearchNextGTCompare ( dbmIndexNode** aNode, long long* aDataSlot, char** aNextKey, int aTransID, long long* aExtraKey, char* aKey  );
    int mSearchNextLTCompare ( dbmIndexNode** aNode, long long* aDataSlot, char** aPrevKey, int aTransID, long long* aExtraKey, char* aKey );

public:
    dbmIndexHeader*         mIndexHeader;
    dbmSegmentManager*      mSegMgr;
    dbmLockManager*         mLockMgr;

private:
    int                     mIndexID;
    dbmLogManager*          mLogMgr;
    char                    mInstName[DBM_NAME_LEN];
    char                    mIndexName[DBM_NAME_LEN];
    char*                   mRoot;
    int                     mSkipCompareKeysize;
};

#endif  /* __O_DBM_INDEXMGR_INTERFACE_H__ */

/********************************************************************
 * extern functions
 ********************************************************************/
#ifdef __cplusplus
extern "C"
{
#endif

extern const int g_DBM_INDEX_DEGREE_sub1_div2;
extern const int g_DBM_INDEX_DEGREE_add1_div2;
extern __thread int g_bIsUniqueIndex;

// 2014.12.14. -okt- 2014.09.25, 이건 LockMgr 공통코드로 가야할듯
extern _VOID mSpinLockLib   ( volatile void* aLock, volatile int* aFutex, int aMyID, dbmLockManager* aLockMgr );
extern _VOID mSpinUnlockLib ( volatile void* aLock, volatile int* aFutex, int aMyID, dbmLockManager* aLockMgr );

extern int dbmIdxIndexCompare   ( dbmIndexHeader* aIndexHeader, char* aNode, char* aKey, dbmSignType aKeyCheckType, int aEQCnt );
extern int dbmIdxIndexPosition  ( dbmIndexHeader* aIndexHeader, char* aNode, char* aKey );
extern int dbmIdxSearchExist    ( dbmIndexHeader* aIndexHeader, dbmIndexNode* aNode, char* aKey, int* aPos );

extern void PrintNodeElement2Lib ( dbmIndexNode* pNode, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr );
extern void PrintNodeElement3Lib ( dbmIndexNode* pNode, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr );
extern void PrintNodeElementbySlotId  ( long long aSlotID, dbmSegmentManager* aSegMgr );
extern void PrintNodeElementbySlotId2 ( long long aSlotID, dbmSegmentManager* aSegMgr );

/********************************************************************
 * static functions
 *
 * 정적 함수로 각 소스 파일에서만 호출가능하나. 검색 편의상 여기에 모음
 ********************************************************************/

/* 공통 - dbmIndexManager.cpp */
static int mIndexCompareString  ( char* aKey1, char* aKey2, int aSize );
static int mIndexCompareShort   ( char* aKey1, char* aKey2 );
static int mIndexCompareInt     ( char* aKey1, char* aKey2 );
static int mIndexCompareLong    ( char* aKey1, char* aKey2 );

//static int mIndexRetCheck       ( int aCheckValue, dbmSignType aKeyCheckType );
//static int mIndexRetCompare     ( int aCheckValue, dbmSignType aKeyCheckType, int* aBreakCheck, int aCount, int aColumnCount );

/* INSERT - dbmIndexManager1.cpp */
//static _VOID dbmIdxInsertKey    ( char* aInstName, long long aDataSlot, int aTransID, char* aKey, char* aIndexName, void* pUser, long long* aExtraKey );
static _VOID dbmIdxInsertKey    ( char* aInstName, long long aDataSlot, int aTransID, char* aKey, char* aIndexName, void* pUser );

static _VOID dbmIdxInsertClear  ( dbmIndexNode** aCurr, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, void* pUser, int aTransID );
static _VOID dbmIdxWriteLeaf    ( long long* aSlotID, char** aSlotAddr, dbmSegmentManager* aSegMgr, dbmIndexHeader* aIndexHeader );
static _VOID dbmIdxInsertPosition   ( dbmIndexNode** aCurr, int* aPosition, char* aKey, int* aFound, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr );
static _VOID dbmIdxInsertKeyPush    ( dbmIndexNode** aCurr, int aTransID, int* aPosition, char* aKey, int aCount, int* aPos, long long aDataSlot, dbmIndexHeader* aIndexHeader );
static _VOID dbmIdxBinarySearchInLeafNoLock ( int aCount, int* aPosition, dbmIndexNode* aCurr, char* aKey, dbmIndexHeader* aIndexHeader );
static void  dbmIdxIndexKeyCast     ( char** aNode, char* aKey, dbmIndexHeader* aIndexHeader, long long* aExtraKey );

static _VOID dbmIdxInsertAdjust     ( dbmIndexNode** aCurr, int aTransID, int aPos, long long aDataSlot, char* aKey, dbmIndexHeader* aIndexHeader, dbmLockManager* aLockMgr );

static _VOID dbmIdxInsertNewKeyPush   ( dbmIndexNode** aCurr, dbmIndexNode** aNewNode, int aTransID, int aPos, char* aKey, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );
static _VOID dbmIdxInsertNewKeyPushNu ( dbmIndexNode** aCurr, dbmIndexNode** aNewNode, int aTransID, int aPos, char* aKey, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );
static _VOID dbmIdxInsertLeafAdjust   ( dbmIndexNode** aCurr, dbmIndexNode** aNewNode, dbmIndexNode** aInkey, char* aKey, long long aDataSlot, int aTransID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );
static _VOID dbmIdxInsertLeafNewAdjust( dbmIndexNode** aCurr, dbmIndexNode** aNewNode, dbmIndexNode** aInkey, char* aKey, long long aDataSlot, int aTransID, long long aSlotID, dbmIndexHeader* aIndexHeader, dbmLockManager* aLockMgr );

static _VOID dbmIdxInsertCheck  ( int aTransID, dbmIndexHeader* aIndexHeader );

/* DELETE - dbmIndexManager2.cpp */
static _VOID dbmIdxDeleteKey    ( char* aInstName, int aTransID, char* aKey, char* aIndexName, void* pUser, int aCheck );

static int dbmIdxDeleteNodeExist    ( dbmIndexNode* aNewNode, dbmIndexNode* aCurr, dbmSegmentManager* aSegMgr, int* aPos );
static int dbmIdxDeleteSearchExist  ( dbmIndexNode* aNode, char* aKey, dbmIndexHeader* aIndexHeader, int* aPos );
static void dbmIdxDeleteKeyClear    ( dbmIndexNode** aNode, dbmIndexHeader* aIndexHeader );

static int dbmIdxBinarySearchDeleteLeaf     ( int aCount, int* aPosition, dbmIndexNode* aCurr, char* aKey, dbmIndexHeader* aIndexHeader );
static int dbmIdxBinarySearchDeleteLeafNu   ( int aCount, int* aPosition, dbmIndexNode* aCurr, char* aKey, dbmIndexHeader* aIndexHeader );

static _VOID dbmIdxDeletePosition   ( dbmIndexNode** aCurrNode, char* aKey, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr );
static _VOID dbmIdxDeletePositionNu ( dbmIndexNode** aCurrNode, char* aKey, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr );

static _VOID dbmIdxDeleteInternalCheck   ( dbmIndexNode** aCurr, dbmIndexNode** aChild, int aPos, int aTransID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );
static _VOID dbmIdxDeleteInternalCheckNu ( dbmIndexNode** aCurr, dbmIndexNode** aChild, int aPos, int aTransID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );

static _VOID dbmIdxDeleteShift      ( dbmIndexNode** aCurr, int aPos, int aTransID, dbmIndexHeader* aIndexHeader, dbmLockManager* aLockMgr );
static int dbmIdxDeleteSiblingSet   ( dbmIndexNode* aNewNode, int aPos, int* aBtreeCheck, dbmSegmentManager* aSegMgr );

static _VOID dbmIdxDeleteLeftSibling    ( dbmIndexNode** aNewNode, dbmIndexNode** aCurr, int aPos, int aTransID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );
static _VOID dbmIdxDeleteLeftSiblingNu  ( dbmIndexNode** aNewNode, dbmIndexNode** aCurr, int aPos, int aTransID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );

static _VOID dbmIdxDeleteRightSibling   ( dbmIndexNode** aNewNode, dbmIndexNode** aCurr, int aPos, int aTrnasID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );
static _VOID dbmIdxDeleteRightSiblingNu ( dbmIndexNode** aNewNode, dbmIndexNode** aCurr, int aPos, int aTrnasID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );

static _VOID dbmIdxDeleteNonLeftSibling   ( dbmIndexNode** aNewNode, dbmIndexNode** aCurr, int aPos, int aTrnasID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );
static _VOID dbmIdxDeleteNonLeftSiblingNu ( dbmIndexNode** aNewNode, dbmIndexNode** aCurr, int aPos, int aTrnasID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );

static _VOID dbmIdxDeleteNonRightSibling  ( dbmIndexNode** aNewNode, dbmIndexNode** aCurr, int aPos, int aTrnasID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );
static _VOID dbmIdxDeleteNonRightSiblingNu( dbmIndexNode** aNewNode, dbmIndexNode** aCurr, int aPos, int aTrnasID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );

static _VOID dbmIdxDeleteNonLeftAdjust  ( dbmIndexNode** aNewNode, dbmIndexNode** aCurr, dbmIndexNode** aChild, int aTransID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );
static _VOID dbmIdxDeleteNonRightAdjust ( dbmIndexNode** aNewNode, dbmIndexNode** aCurr, dbmIndexNode** aChild, int aTransID, dbmIndexHeader* aIndexHeader, dbmSegmentManager* aSegMgr, dbmLockManager* aLockMgr );

#ifdef __cplusplus
}
#endif

