/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    내부적으로 DBM에 공통적으로 적용할 항목들에 대한 DEFINE절
*******************************************************************************/
#ifndef __O_DBM_DEFINE_H__
#define __O_DBM_DEFINE_H__

#include "cmnDef.h"

/**************************************************************
 * DBM 전용변수 (내부용)
**************************************************************/
extern int      _dbm_scn_ascending;     // FETCH를 수행할때, SCN 보다 큰 데이타가 이미 커밋되어 있으면, 오류없이, 해당 값을 읽음.

/**************************************************************
 * 공통DEFINE
**************************************************************/
#define DBM_DIRTY_ON                    1
#define DBM_DIRTY_OFF                   0

/* 환경변수 */
#define ENV_DBM_HOME                    "DBM_HOME"
#define ENV_DBM_INSTANCE                "DBM_INSTANCE"

#define ENV_DBM_TRCLOG_ECHO             "DBM_TRCLOG_ECHO"
#define ENV_DBM_TRCLOG_ASYNC_ENABLE     "DBM_TRCLOG_ASYNC_ENABLE"
#define ENV_DBM_TRCLOG_LEVEL            "DBM_TRCLOG_LEVEL"
#define ENV_DBM_TRCLOG_PID_TYPE         "DBM_TRCLOG_PID_TYPE"
#define ENV_DBM_TRCLOG_NAME_TYPE        "DBM_TRCLOG_NAME_TYPE"

#define DBM_ERROR_FILE_NAME             "dbm.error"

#define ENV_DBM_FILE_MODE               "DBM_FILE_MODE"
#define DBM_FILE_MODE                   ( 0660 )    // (S_IRUSR | S_IWUSR | S_IRGRP)

#define ENV_DBM_RTF_ON                  "DBM_RTF_ON"
#define ENV_DBM_SHM_PREFIX              "DBM_SHM_PREFIX"
#define ENV_DBM_GAP_PREFIX              "DBM_GAP_PREFIX"

/* NUMA 환경변수 */
#define ENV_DBM_LATENCY                 "DBM_LATENCY"               // 숫자값이 NODE번호를 의미, 다른 설정 없어도 자동 배치 시도.
#define ENV_DBM_NUMA_NODE               "DBM_NUMA_NODE"             // DBM_LATENCY 와 동일.
#define ENV_DBM_NUMA_SET                "DBM_NUMA_SET"              // DA 등 일반
#define ENV_DBM_NUMA_SET_CS             "DBM_NUMA_SET_CS"           // olsnr
#define ENV_DBM_NUMA_SET_MSQL           "DBM_NUMA_SET_MSQL"         // metaManager
#define ENV_DBM_NUMA_SET_IMP            "DBM_NUMA_SET_IMP"          // dbmImp
#define ENV_DBM_NUMA_SET_REPL_SEND      "DBM_NUMA_SET_REPL_SEND"    // 이중화 Send
#define ENV_DBM_NUMA_SET_REPL_RECV      "DBM_NUMA_SET_REPL_RECV"    // 이중화 Recv

/* dbmImp 환경변수 */
#define ENV_DBM_UPLOAD_THR_NUM          "DBM_UPLOAD_THR_NUM"
#define ENV_DBM_UPLOAD_LOGGING          "DBM_UPLOAD_LOGGING"
#define ENV_DBM_UPLOAD_READ_BLOCK_SIZE  "DBM_UPLOAD_READ_BLOCK_SIZE"


/* Hidden 환경변수 */
#define ENV_DBM_TEST_REMOTE_PORT        "_DBM_TEST_REMOTE_PORT"
#define ENV_DBM_TEST_REMOTE_IP          "_DBM_TEST_REMOTE_IP"

#define ENV_DBM_USE_SIGNAL_HANDLER      "_DBM_USE_SIGNAL_HANDLER"
#define ENV_DBM_SEGMGR_DBLFREE_CHECK    "_DBM_SEGMGR_DBLFREE_CHECK"
#define ENV_DBM_SCN_ASCENDING           "_DBM_SCN_ASCENDING"


/**************************************************************
 * Resource 제한과 관련해서 공통적인것들 쭈르르..
**************************************************************/
//#define  DBM_MAX_SEGMENT            4096      // (OKT): 미사용 (나중에서 큰의미 없을듯)
//#define  DBM_MAX_ROWCNT_SHORT       SHRT_MAX
//#define  DBM_MAX_ROWCNT_INT         INT_MAX
//#define  DBM_MAX_ROWCNT_LONG        LONG_MAX


/**************************************************************
 * Disk logging 관련해서 공통적인것들 쭈르르..
**************************************************************/
#define DBM_DISK_WATER_MARK        (89894934949403020L)
#define DBM_DISK_LOG_MEMORY_SIZE   (1024 * 1024 * 8)
#define DBM_ANCHOR_SLOT_COUNT      (8192)
#define DBM_CKPT_SLOT_SIZE         (8192)
#define DBM_CKPT_SLOT_COUNT        (8192)
#define DBM_ANCHOR_SIZE            (DBM_CKPT_SLOT_SIZE + (sizeof(dbmAnchorSlot) * DBM_ANCHOR_SLOT_COUNT) + (DBM_CKPT_SLOT_SIZE * DBM_CKPT_SLOT_COUNT))
#define DBM_FILE_NAME_LENGTH       1024

#define  DBM_LOG_BLOCK_SIZE        512
#define  DBM_LOG_ANCHOR_NAME       "anchor"
//#define  DBM_MAX_BLOCK_COUNT       20480 // 미사용 (2014/09/11)


/*************************************************************
 * dbmHandle내의 object개수 제한
*************************************************************/
#define  DBM_MAX_SPACE_COUNT        4
#define  DBM_MAX_TABLE_PER_TRANS    64
#define  DBM_MAX_DIC_TABLE_NUM      32
// #950 2015.05.26 테이블당 인덱스 개수 6개에서 12개로 늘림
//#define  DBM_MAX_INDEX_PER_TABLE    6
#define  DBM_MAX_INDEX_PER_TABLE    12

// #824 2015.02.24 -okt- 인덱스 컬럼개수 6개에서 32개로 늘림
//#define  DBM_MAX_COLUMN_PER_INDEX   6
#define  DBM_MAX_COLUMN_PER_INDEX   32

#define  DBM_MAX_COLUMN             256
#define  DBM_MAX_TRANS              1024
#define  DBM_NAME_LEN               32
#define  DBM_PATH_LEN               256
#define  DBM_NOT_USED               -1
#define  DBM_FD_NOT_USED            -1
#define  DBM_LOOPBACK_ADDR          "127.0.0.1"
#define  DBM_MAX_RECORD_SIZE        4096
#define  DBM_MAX_SQL_LEN            4096


/*************************************************************
 * 기타 DEFINE
*************************************************************/
#define DBM_DML_TYPE                1
#define DBM_CHG_DML_TYPE            20
#define DBM_TRANS_TYPE              100
#define DBM_DDL_TYPE                120
#define DBM_ETC_TYPE                150
#define INFINITE_SCN                -1
#define CKPT_REQUEST_QUE            "system_ckpt_request"
#define CKPT_REQUEST_QUE_SIZE       1024
#define MAX_SEGMENT_COUNT           1024

#ifdef _DEBUG
#define DBM_INDEX_DEGREE            64          // 성능 최적 옵션
//#define DBM_INDEX_DEGREE          5           // merge를 자주 발생하여 버그 재현은 높인다.
//#define DBM_INDEX_DEGREE          256         // 꺼꾸로 256 (최대값)에서 더 재현이 잘되는 종류의 버그도 있다.
#else
#define DBM_INDEX_DEGREE            64
#endif
// 2014.12.14. -okt- debug 모드에서라도 상수로 하여, 재컴파일 없이 변경테스트가능하게하자
// 1) DBM_INDEX_DEGREE - 2

#define DBM_INDEX_DEPTH_MAX         1000
#define DBM_INDEX_KEY_MAX_SIZE      256
#define DBM_NON_UNIQUE_KEY_SIZE     264
#define DBM_SPACE_HEADER_SIZE       8192
#define DBM_UNDO_HEADER_SIZE        8192
#define DBM_TXTABLE_SIZE            1024*1024    /* 1 MB 내에서 사용 */
#define MAX_NAME_LEN                32
#define DBM_SPIN_COUNT              32
#define FUTEX_WAIT_TIME             100000
#define DBM_REPLICATION_GAP_CHECK   1

//#define STACKSIZE                   (1024*1024*100)
#define STACKSIZE                   (1024*1024*10)
#define REPL_RECV_MAX               100

// 2015.03.12 -shw- sequence info define
#define DBM_SEQ_INCREMENT           1
#define DBM_SEQ_START               0LL
#define DBM_SEQ_MAXVALUE            100000000LL
#define DBM_SEQ_MINVALUE            1LL
#define DBM_SEQ_CYCLE               "cycle"

/* Check Point */
#define DBM_CHECK_POINT_LOGFILE_MAX 10000000
#define DBM_CHECK_POINT_DBFILE_MAX 10000000

/*
 * 1) 2014.07.28 -okt- #523 인덱스의 INIT Size는 별도로 입력받지 않고, 테이블의 값으로 계산한다. 크기를 2배 늘린다.
 * 2) 2014.11.21 -okt- 성능 구간아니고, 매크로 사용할 장점이 없다. 2의 지수를 반환하는 것으로 변경하면서 함수로 변경
 *
 */
#if 0
#define CALC_IDX_SLOT_COUNT(xx)     ((xx % (DBM_INDEX_DEGREE>>1)) ? \
                                    ((xx / (DBM_INDEX_DEGREE>>1))+1) : (xx / (DBM_INDEX_DEGREE>>1)))
#else
_INLINE
long long CALC_IDX_SLOT_COUNT ( long long aCnt )
{
    long long sRet;
    //int     i;

    sRet = ( ( aCnt % ( DBM_INDEX_DEGREE >> 1 ) ) ? ( ( aCnt / ( DBM_INDEX_DEGREE >> 1 ) ) + 1 ) : ( aCnt / ( DBM_INDEX_DEGREE >> 1 ) ) );

    return cmnGetBuddy( sRet );
}
#endif


/***********************************************
 * dictionary 관련 define
***********************************************/
#define SYS_INSTANCE_INIT_ROW       64
#define SYS_INSTANCE_EXTEND_ROW     64
#define SYS_INSTANCE_MAX_ROW        1024
#define SYS_TBL_INIT_ROW            1024
#define SYS_TBL_EXTEND_ROW          512
#define SYS_TBL_MAX_ROW             8192
//#define SYS_IDSTR_LEN             10
#define SYS_DIC_PREFIX              "$" /* prefix of dictionary object name */
#define SYS_DIC_PREFIX_CHAR         '$'
#define SYS_INST_NAME               SYS_DIC_PREFIX"sys_dic_inst"


/*************************************************
 * Connection 유형
*************************************************/
typedef enum dbmConnType
{
    DBM_LOCAL_CONNECT               = 1
  , DBM_REMOTE_CONNECT
  , DBM_REPL_CONNECT
} dbmConnType;


/*************************************************
 * Segment 유형
*************************************************/
typedef enum dbmSegmentType
{
    DBM_DICTIONARY_SEGMENT          = 1
  , DBM_UNDO_SEGMENT
  , DBM_DATA_SEGMENT
} dbmSegmentType;


/**************************************************************
 * DBM 이 제공하는 Object Type
**************************************************************/
typedef enum dbmObjectType
{
    DBM_OBJ_TABLE
  , DBM_OBJ_DIRECT_TABLE
  , DBM_OBJ_QUEUE
  , DBM_OBJ_LIST
  , DBM_OBJ_SEQUENCE
  , DBM_OBJ_INDEX
  , DBM_OBJ_TRIGGER
} dbmObjectType;


/**************************************************************
 * Column Type
**************************************************************/
typedef enum dbmColumnType
{
    DBM_COLUMN_CHAR_TYPE
  , DBM_COLUMN_INT_TYPE
  , DBM_COLUMN_LONG_TYPE
  , DBM_COLUMN_DOUBLE_TYPE
  , DBM_COLUMN_FLOAT_TYPE
  , DBM_COLUMN_SHORT_TYPE
  , DBM_COLUMN_DATE_TYPE
  , DBM_COLUMN_TYPE_MAX                 // 컴파일 워닝 제거용. 초기값
} dbmColumnType;


/**************************************************************
 * DBM 이 제공하는 Table Type
**************************************************************/
typedef enum dbmTableType
{
    DBM_TBL_NORMAL
  , DBM_TBL_QUEUE
  , DBM_TBL_DIRECT
  , DBM_TBL_SEQUENCE
  , DBM_TBL_LIST
} dbmTableType;

typedef enum dbmDicTableType
{
    DBM_DIC_TBL_INSTANCE
  , DBM_DIC_TBL_TABLE
  , DBM_DIC_TBL_INDEX
  , DBM_DIC_TBL_COLUMN
  , DBM_DIC_TBL_OBJECT
  , DBM_DIC_TBL_TRIGGER
  , DBM_DIC_TBL_MAX
} dbmDicTableType;


/**************************************************************
 * Index Type
 *   - 현재는 BTree 만 지원
**************************************************************/
typedef enum dbmIndexType
{
    DBM_INDEX_BTREE
  , DBM_INDEX_DIRECT
/*
  , DBM_INDEX_TTREE
  , DBM_INDEX_RTREE
  , DBM_INDEX_SPLAY
*/
} dbmIndexType;


/**************************************************************
 * Index Unique Type
**************************************************************/
typedef enum dbmUniqueType
{
    DBM_NON_UNIQUE  = 0             // FALSE
  , DBM_UNIQUE      = 1             // TRUE
} dbmUniqueType;


/**************************************************************
 * Transaction Manager 의 내부적인 Transaction 상태관리
**************************************************************/
typedef enum dbmTxStatus
{
    DBM_TX_FREE                     /* 아직 특정 Transaction 에 미할당된 상태 */
  , DBM_TX_ALLOC                    /* Alloc Trans 하여 할당만 된 상태 */
  , DBM_TX_LOG_WAIT                 /* Logging 작업 대기 중 */
  , DBM_TX_LOGGING                  /* Logging 진행 중인 상태 */
  , DBM_TX_COMMIT                   /* 기록된 Logging 을 이용하여 Commit 진행 중 */
  , DBM_TX_ROLLBACK                 /* 기록된 Logging 을 이용하여 Rollback 진행 중 */
} dbmTxStatus;

/**************************************************************
 * Transaction Manager 의 내부적인 DeferComit 상태관리
**************************************************************/
typedef enum dbmTxDeferStatus
{
    DBM_TX_DEFER_FREE               /* 아직 특정 Transaction 미할당 상태 */
  , DBM_TX_DEFER_COMMIT             /* Defercommit 으로 Logging 진행중인 상태 */
} dbmDeferStatus;

/**************************************************************
 * Transaction Type
**************************************************************/
typedef enum dbmTransType
{
    DBM_NOT_DEFINED                 = -1
    /* DML */
  , DBM_SELECT                      = DBM_DML_TYPE      // 1
  , DBM_SELECT_ROWSIZE
  , DBM_SELECT_GT
  , DBM_SELECT_LT
  , DBM_SELECT_DIRTY
  , DBM_SELECT_GT_DIRTY
  , DBM_SELECT_LT_DIRTY
  , DBM_SELECT_MAX
  , DBM_SELECT_MIN
  , DBM_FETCH_NEXT_LT
  , DBM_FETCH_NEXT_GT
  , DBM_FETCH_RANGE
  , DBM_SET_INDEX
  , DBM_GET_INDEX
  , DBM_FETCH
  , DBM_INSERT                      = DBM_CHG_DML_TYPE  // 20
  , DBM_DELETE
  , DBM_UPDATE
  , DBM_SELECT_FOR_UPDATE
  , DBM_ENQUE
  , DBM_DEQUE
  , DBM_DEQUE_MORE
  , DBM_DEQUE_ARRAY
  , DBM_BIND_COL
  , DBM_UPDATE_COL
  , DBM_UPDATE_COL_GT
  , DBM_UPDATE_COL_LT
  , DBM_CLEAR_BIND
  , DBM_SELECT_COUNT
  , DBM_SELECT_COUNT_GT
  , DBM_SELECT_COUNT_LT
  , DBM_SELECT_COUNT_BT
  , DBM_UPDATE_RANGE_GT
  , DBM_UPDATE_RANGE_LT
  , DBM_UPDATE_RANGE_BT
  , DBM_DELETE_RANGE_GT
  , DBM_DELETE_RANGE_LT
  , DBM_DELETE_RANGE_BT
  , DBM_LIST_LPUSH
  , DBM_LIST_RPUSH
  , DBM_LIST_LPOP
  , DBM_LIST_RPOP
  , DBM_LIST_RANGE
  , DBM_SEQ_CURRVAL
  , DBM_SEQ_NEXTVAL
  , DBM_SELECT_COUNT_DIRTY
  , DBM_SELECT_COUNT_GT_DIRTY
  , DBM_SELECT_COUNT_LT_DIRTY
  , DBM_SELECT_COUNT_BT_DIRTY
  //TODO: 2014.11.04 -okt- 2.1.0 릴리즈 후에 추가 된 것으로, 다음 2.2.0 릴리즈에서 위치를 변경해야한다. ( 버전호환성 )
//  , DBM_SELECT_COUNT_GE
//  , DBM_SELECT_COUNT_LE

    /* TRANS */
  , DBM_COMMIT                      = DBM_TRANS_TYPE    // 100
  , DBM_ROLLBACK
  , DBM_CUR_CLOSE
  , DBM_DEFER_COMMIT
  , DBM_DEFER_SYNC

    /* DDL */
  , DBM_TRUNCATE                    = DBM_DDL_TYPE      // 120
  , DBM_CREATE_USER
  , DBM_CREATE_INST
  , DBM_CREATE_DATA
  , DBM_CREATE_TABLE
  , DBM_CREATE_DIRECT_TABLE
  , DBM_CREATE_QUEUE
  , DBM_CREATE_LIST
  , DBM_CREATE_SEQUENCE
  , DBM_CREATE_INDEX
  , DBM_CREATE_OBJECT                                   // 130
  , DBM_CREATE_TRIG
  , DBM_DROP_USER
  , DBM_DROP_INST
  , DBM_DROP_DATA
  , DBM_DROP_TABLE
  , DBM_DROP_QUEUE
  , DBM_DROP_LIST
  , DBM_DROP_SEQUENCE
  , DBM_DROP_INDEX
  , DBM_DROP_TRIG                                       // 140
  , DBM_ALTER_TABLE_DISKLOG
  , DBM_ALTER_TABLE_MEMLOG

  /* Set option */
  , DBM_SET_OPTION
  , DBM_GET_OPTION

    /* ETC - for remote */
  , DBM_INIT_HANDLE                 = DBM_ETC_TYPE      // 150
  , DBM_PREPARE_TABLE
} dbmTransType;




/**************************************************************
 * Logging Type
 *  - 일단 이전 Log Type 을 그대로 가져왔음.
 *    변경이 필요하면 그때그때 수정하자.
**************************************************************/
typedef enum dbmLogType
{
    DBM_ALLOC_SLOT_LOG              = 1
  , DBM_ALLOC_IDX_SLOT_LOG
  , DBM_FREE_SLOT_LOG
  , DBM_INSERT_SLOT_LOG
  , DBM_UPDATE_SLOT_LOG

  , DBM_UPDATE_KEY_LOG
  , DBM_DELETE_SLOT_LOG
  , DBM_INSERT_INDEX_LOG
  , DBM_INSERT_INDEX_LOG2
  , DBM_DELETE_INDEX_LOG

  , DBM_DELETE_INDEX_LOG2
  , DBM_DELETE_INDEX_LOG3
  , DBM_DELETE_INDEX_LOG4
  , DBM_DELETE_DATA_LOG
  , DBM_SELECT_FOR_UPDATE_LOG

  , DBM_TRUNCATE_LOG
  , DBM_ENQUE_LOG
  , DBM_DEQUE_LOG
  , DBM_DDL_CREATE_QUEUE_LOG
  , DBM_DDL_CREATE_TABLE_LOG

  , DBM_DDL_CREATE_DIRECT_LOG
  , DBM_DDL_DROP_TABLE_LOG
  , DBM_DDL_CREATE_INDEX_LOG
  , DBM_DDL_DROP_INDEX_LOG
  , DBM_DDL_DROP_QUEUE_LOG

  , DBM_DDL_CREATE_TRIG_LOG
  , DBM_DDL_DROP_TRIG_LOG
  , DBM_DDL_DROP_USER_LOG
  , DBM_LOCK_ROW_LOG
  , DBM_DEFER_INSERT_LOG

  , DBM_DEFER_UPDATE_LOG
  , DBM_BEGIN_TX_LOG
  , DBM_REPL_COMMIT_LOG
  , DBM_REPL_ROLLBACK_LOG
  , DBM_COMMIT_LOG

  , DBM_ROLLBACK_LOG
  , DBM_SET_INDEX_LOG
  , DBM_COMMIT_ACK_LOG
  , DBM_CLEAR_DEFER_LOG
  , DBM_DEQUE_CONFIRM_LOG

  , DBM_DUMMY_ACK_LOG
  , DBM_DDL_CREATE_LIST_LOG
  , DBM_LIST_LPUSH_LOG
  , DBM_LIST_RPUSH_LOG
  , DBM_LIST_LPOP_LOG

  , DBM_LIST_RPOP_LOG
  , DBM_LIST_LRANG_LOG
  , DBM_LOCK_LIST_LOG
  , DBM_LIST_HEADER_LPUSH_LOG
  , DBM_LIST_HEADER_RPUSH_LOG

  , DBM_LIST_HEADER_LPOP_LOG
  , DBM_LIST_HEADER_RPOP_LOG
  , DBM_RECOVER_END_LOG

  , DBM_LOG_TYPE_MAX                     // 컴파일 워닝 제거용. 초기값
} dbmLogType;


/**************************************************************
 * Sign(sign of inequality) Type
**************************************************************/
typedef enum dbmSignType
{
    DBM_EQ
  , DBM_LT
  , DBM_GT
//  , DBM_GT2
//  , DBM_LT2
  , DBM_LE  // 3
  , DBM_GE
  , DBM_NE
  , DBM_CT
  , DBM_BT
  , DBM_CT_GT
  , DBM_CT_LT
} dbmSignType;


/**************************************************************
 * Disk Sync Option
 **************************************************************/
typedef enum  dbmDiskSyncOption
{
    NO_SYNC = 0
 ,  FSYNC
 ,  SYNC
 ,  DIRECT
 ,  DIRECT_SYNC
} dbmDiskSyncOption;


/**************************************************************
 * 일감 #558
 * 세션레벨 속성 지정을 위한 구조체로 완성되면 dbmDef.h 에 노출가능
**************************************************************/
typedef enum dbmHandleOption
{
    DBM_O_DISK_LOG_ENABLE   = 1000
  , DBM_O_DISK_LOG_IO_TYPE  = 1001
} dbmHandleOption ;


/**************************************************************
 * MOM Define
**************************************************************/
#define   MOM_TOPIC_MASTER   "topic_master"
#define   MOM_EVENT_FOR_DIS  "topic_event"


#endif  /* __O_DBM_DEFINE_H__ */
