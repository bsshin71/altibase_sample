/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   dbmDictionary Class 정의
*******************************************************************************/
#ifndef __O_DBM_DICTIONARY_MANAGER_H__
#define __O_DBM_DICTIONARY_MANAGER_H__

#include "dbmTableManager.h"
#include "dbmParser.h"


/**************************************************************
 * Dictionary Object Structure
**************************************************************/
typedef dbmInstanceObject       dbmInstanceDic;
typedef dbmSessionObject        dbmSessionDic;
typedef dbmColumnObject         dbmColumnDic;
typedef dbmColumnSetObject      dbmColumnSetDic;
typedef dbmIndexObject          dbmIndexDic;
typedef dbmTableObject          dbmTableDic;
typedef dbmObjectObject         dbmObjectDic;
typedef dbmEventObject          dbmEventDic;


/**************************************************************
 * dbmDictionary Class Definition
**************************************************************/
class dbmDictionary
{
private:
    int                 mTransID;
    dbmTransHeader*     mTransHeader;

    dbmTransTable*      mTxTable;
    dbmUndoHeader*      mUndoHeader;

    int                 mTableCount;
    dbmTableManager*    mTable[DBM_DIC_TBL_MAX];

    dbmSegmentManager*  mUndoSegMgr;
    dbmLogManager*      mLogMgr;
    dbmLockManager*     mLockMgr;
    dbmDeadLockManager* mDeadLockMgr;

public:
    dbmDictionary();
    ~dbmDictionary();

    _VOID   mCreate ();
    _VOID   mDrop ();
    _VOID   mAttach ();
    _VOID   mDetach ();
    _VOID   mInitObject ();
    void    mPrintAll ();

    _VOID   mInsert ( dbmDicObject*   aObject );
    _VOID   mDelete ( dbmDicObject*   aObject );
    _VOID   mSelect ( dbmDicObject*   aObject );
    _VOID   mUpdate ( dbmDicObject*   aObject );  /* only used for trigger update */
    _VOID   mGetFirst ( dbmDicObject*   aObject );
    _VOID   mGetNext ( dbmDicObject*   aObject );
    _VOID   mCheck ();
    _VOID   mRecover ();
    _VOID   mUpdateTableID ( dbmDicObject*   aObject );
    _VOID   mSetDiskNoLogging( dbmDicObject* aObject, int aNologgingF );
    _VOID   mSetMemNoLogging( dbmDicObject* aObject, int aNologgingF );
    _VOID   mSetIndex( char* aTableName, char* aIndexName );

private:
    _VOID   mParseCreateIndexDDL( dbmDicTableType  aTableType,
                                  dbmTableInfo*    aTableInfo,
                                  int              aIndexOrder,
                                  dbmUniqueType    aIsUniqueIndex,
                                  const char*      aKeyColumnListString );
    _VOID   mParseCreateDicDDL ( dbmTableInfo*   aTableInfo,
                                 dbmDicTableType aTableType );
    _VOID   mPrepareDicTable ( char* aTableName );
    _VOID   mUnprepareDicTable ( char* aTableName );
    _VOID   mGetTableIdx ( char* aTableName, int* aTableIdx );
    _VOID   mInsertInstance ( dbmInstanceDic* aInstance );
    _VOID   mSelectInstance ( dbmInstanceDic* aInstance, int aSelectType );
    _VOID   mDeleteInstance ( dbmInstanceDic* aInstance );
    _VOID   mInsertTable ( dbmTableDic* aTableDic, int aInitInsertF );
    _VOID   mInsertObject( dbmObjectDic* aObjectDic );
    _VOID   mInsertTrigger ( dbmEventDic* aEventDic );
    _VOID   mSelectTable ( dbmTableDic* aTableDic, int aSelectType );
    _VOID   mSelectObject ( dbmObjectDic* aObjectDic );
    _VOID   mSelectTrigger ( dbmEventDic* aEventDic );
    _VOID   mUpdateTable ( dbmTableDic* aTableDic );
    _VOID   mUpdateTrigger( dbmEventDic* aEventDic );
    _VOID   mDeleteTable ( dbmTableDic* aTableDic );
    _VOID   mDeleteObject ( dbmObjectDic* aObjectDic );
    _VOID   mDeleteTrigger ( dbmEventDic* aEventDic );
    _VOID   mInsertIndex ( dbmIndexDic* aIndexDic, int aTableUpdateF );
    _VOID   mSelectIndex ( long long    aUndoID,
                           long long    aTableID,
                           char*        aIndexName,
                           dbmIndexDic* aIndexDic,
                           int          aSelectType );
    _VOID   mUpdateIndex ( int          aOldTableID,
                           dbmIndexDic* aIndexDic );
    _VOID   mDeleteIndex ( long long    aUndoID,
                           long long    aTableID,
                           char*        aUndoName,
                           char*        aTableName,
                           char*        aIndexName,
                           dbmIndexDic* aIndexDic );
    _VOID   mInsertColumn( dbmColumnDic* aTableDic );
    _VOID   mSelectColumn( dbmColumnDic* aColumnDic );
    _VOID   mUpdateColumn( int           aTableID,
                           dbmColumnDic* aColumnDic );
    _VOID   mDeleteColumn( dbmColumnDic* aColumnDic );
    _VOID   mInitInsert ( void* aInfo, dbmTransType  aSQLType );
    _VOID   mDicCommit ();
    _VOID   mDicRollback ();
    _VOID   mDicRollbackRecovery ( int  aTxID );
    _VOID   mRecoveryTxAll ();

    void    mInitLogSlot ( dbmLogSlotHeader* aSlot, long long aSlotID );
    void    MK_INST_KEY ( char* v, char* undo_name );
    void    MK_TBL_KEY ( char* v, char* undo_name, char* table_name);
    void    MK_IDX_KEY ( char* v, long long instid, long long tblid, char* index_name);
    void    MK_COL_KEY ( char* v, long long instid, long long tblid, int col_id);

    _VOID mGetLogPtr   ( dbmSegmentManager* aSegMgr , long long aLogPos , void* aLogPtr /* char** aLogPtr */ );
    _VOID mGetImagePtr ( dbmSegmentManager* aSegMgr , long long aImagePos , void* aImagePtr /* char** aImagePtr */ );

    _VOID   mGetTableOfIndex ( char*            aUndoName,
                               char*            aIndexName,
                               dbmDicObject*    aDicObj );
    void    mInitTransItem ( int                aTransID,
                             dbmTransHeader*    aHeader,
                             long long          aSessionID,
                             int                aUserID,
                             int                aPID,
                             dbmTxStatus        aStatus,
                             int                aSlotSize );
    _VOID   mInitTran ();
    _VOID   mFinalTran ();
    _VOID   mFinalTran ( int    aTxID );
    _VOID   mClearTransItem ( dbmTransHeader* aHeader );
    _VOID   mGetIndexKeyColumnInfo( dbmIndexObject*  aParseIndex,
                                    dbmTableInfo*    aDicTableInfo,
                                    int*             aKeySize );
    _VOID   mLock   ( int  aMyTxID );
    _VOID   mUnlock ( int  aMyTxID );
    _VOID   mFindIndexInTbl( dbmTableManager*   aTable,
                             char*              aIndexName,
                             int*               aIdx );
    _VOID   mFindTableInTx( char* aTableName, int* aTableIdx );
};


#endif  /* __O_DBM_DICTIONARY_MANAGER_H__ */
