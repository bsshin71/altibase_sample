

/*******************************************************************************
 *
 * 사용자가 dbmTransLogger 를 통해서 쓴 로그를 읽어들인다.
 *
 * 이 로그는 순서대로 읽어들여야한다.  이 Class 는 추상 Class
 *
 ******************************************************************************/


#ifndef __O_DBM_TRANS_READ_H__
#define  __O_DBM_TRANS_READ_H__

#include "dbmHeader.h"


class dbmTransReader
{
public:
    //dbmTransReader ( );
    virtual ~dbmTransReader ( );

    dbmTransReader ( long long aLogBufferSize );

    /************************************************************************
     * Transaction 단위로 로그를 읽어 mLogBuffer 에 적재한다.
     *
     * mReadLogBuffer 는 다음과 같은 역할을 하여야한다.
     * 1. Transaction 로그를 풀어서 mLogBuffer  에 복사한다.
     * 2. mLogBuffer 에 복사된 byte 수를 mLogBufferIdx 에 복사한다.
     * 3. mMyLogBuuferIdx 를 0 으로 초기화 한다.
     *
     * 이 일을 하면서 세부구현은 하위 Class 로 내린다 .
     ***********************************************************************/
    virtual int mLoadLogBuffer ( long long aLSN ) = 0;

    /***********************************************************************
     * mLogBuffer 에 존재하는 Transaction Log 를 하나씩 꺼내준다.
     *
     * aLog 인자는 dbmTransLog 이다.
     * aImage 인자는 Logging 된 Image 를 가리키는 포인터이다.
     **********************************************************************/
    virtual int mReadLog ( dbmTransLog** aLog , char** aImage , long long aLSN ) = 0;

    virtual char* mGetUndoName ( ) = 0;

protected:
    char*   mLogBuffer;
    long long mLastLSN;
    int     mLogBufferIdx;   // TransLog를 읽었을때 쓰여진 전체 Total Size 를 기록
    int     mMyLogBufferIdx; // mReadLog 에서 읽어가면서 처리된 마지막 Index 를 기록

    long long mLogBufferSize;
} ;

#endif /* __O_DBM_TRANS_READ_H__ */


