/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   각종 Header 자료구조들을 모아놓음.
 ******************************************************************************/
#ifndef __O_DBM_STRUCT_H__
#define __O_DBM_STRUCT_H__

#include "dbmObject.h"

#ifdef __cplusplus
extern "C"
{
#endif


/**************************************************************
 * Definition
**************************************************************/


/**************************************************************
 * Extra Page Header
 * Extra의 경우는 PageHeader 다음에 바로 온다.
**************************************************************/
typedef struct dbmExtentHeader
{
    long long       mAllocInd;
    long long       mFreeInd;
} dbmExtentHeader;

/*************************************************************
*   - Index의 정보가 담겨 있다.
*************************************************************/
typedef struct dbmIndexSlotHeader
{
    int             mRootFlag;      /* 1:root slot 0:non-root slot */
    volatile int    mLock;          /* index leaf lock mode */
    volatile long long mRootSlotID;    /* 상위 root ID   */
    long long       mLeafNextID;    /* reaf link list */
    long long       mLeafPrevID;    /* reaf link list */
    volatile int    mNodeCount;     /* key count      */
    int             mLeafcheck;     /* 1: leaf 0:no-leaf */
} dbmIndexSlotHeader;

/*************************************************************
*     B-tree의 node structure
**************************************************************/
typedef struct dbmIndexNode
{
    dbmIndexSlotHeader  mIndexSlotHeader;
    int                 mRoot;
    long long           mRID[DBM_INDEX_DEGREE];     // Record Slot id
    long long           mChild[DBM_INDEX_DEGREE+1]; // 자식 slot id
    long long           mCurrSlot;                  // 현재 노드가 저장 되어 있는 Slot NO
    long long           mBtreeCheck;
} dbmIndexNode;
//==> char  mElm[DBM_INDEX_DEGREE][DBM_INDEX_KEY_MAX_SIZE]; 이곳에 key size 만큼 있다

/*************************************************************
*     stack의 node structure
**************************************************************/
typedef struct dbmIndexHeader
{
    dbmIndexObject  mIndex;          // 632 Byte

    int             mInitCompleteF;  // segment 생성 후 init 완료하였음.

    long long       mRootPid;
    volatile int    mRootAllocCk;    // root page 할당 여부 체크 0: 미할당 1:할당
    volatile int    mLock;           // 미할당:-1 할당:MyTxID
    volatile int    mFutex;
    volatile int    mCurrStep;       // 0:현재 미운영 1: 운영
    int             mPID;
    int             mDepthNo;        // B-Tree Depth number
    long long       mExtra;          // non-unique index
    volatile int    mTreeCheck;
} dbmIndexHeader;


/*************************************************************
*  dbm Object 의 Stat 정보의 구조체
**************************************************************/

typedef struct dbmSpaceStat
{
    int           mSegmentCount;
    long long     mTotalSlot;
    long long     mAllocSlot;
    long long     mFreeSlot;
} dbmSpaceStat;

/*
 * dbmTransManager::mActCreateIndex
 * 함수에서 아래 구조체를 사용함.
 * dbmTableHader와 연관성이 있어 실수의 소지가 있기 때문에. 여기에 모아둠.
 */
typedef struct dbmTmpIndex
{
    unsigned long long mIndexCount;
    dbmIndexObject  mIndex[DBM_MAX_INDEX_PER_TABLE];
}dbmTmpIndex;


/*************************************************************
 * Table Header 구조체
 *   - Table Segment 의 첫 User Header 영역에는 dbmTableHeader 정보가 들어간다.
 *   - Table Manager 는 자신이 자신이 담당하는 Table 에 대한
 *     모든 정보를 저장하고 있는 Table Header 에 대한 포인터를
 *     멤버 변수로 가지고 있어서 모든 연산 멤버함수에서 쉽게
 *     참조할 수 있다.
*************************************************************/
typedef struct dbmTableHeader
{
    dbmTableObject      mTableObj;

    /* [주의] 2014/04/01 -okt-
     * "컴파일 워닝때문에, int로 변경, 굳이 long일 필요가 없을듯"
     * 할려고 했으나. 소스를 추적하니..
     * "memcpy_s( (char *)&sTmpIndex, &sTableHeader->mIndexCount, sizeof(dbmTmpIndex) );"
     * 이런 형태의 코드가 있음.
     * 때문에 아래 2개 컬럼의 위치가 바뀌면 안됨.
     * 그리고 align 문제를 생각하면 '문제는 없을 것 같지만' int로 바꾸긴 거시기 함.
     */
    unsigned long long  mIndexCount;
    dbmIndexObject      mIndex[DBM_MAX_INDEX_PER_TABLE];

    dbmColumnSetObject  mCols;

    int                 mInitCompleteF;         /* segment 생성 후 init 완료하였음. */
    int                 mUseIndex;

    int                 mLock;
    long long           mRecordCount;
    char                mEventQueue[DBM_NAME_LEN];
    int                 mDDLCount ;
} dbmTableHeader;


/*************************************************************
 * Queue Header 구조체
 *   - Table Header 와 똑같은 구조로 사용해도 되지만,
 *     향후 Queue 기능을 DB 와 분리한 형태로 별도로 사용할 수
 *     있도록 하려면 별도의 구조체를 가져야할 듯함.
*************************************************************/
typedef struct dbmQueueHeader
{
    dbmTableObject  mTableObj;

    unsigned long long mIndexCount;
    dbmIndexObject  mIndex[DBM_MAX_INDEX_PER_TABLE];

    int             mInitCompleteF;             /* segment 생성 후 init 완료하였음. */
    volatile int    mLock;                      /* table lock for queue */
    volatile int    mLockEnq;                   /* Enq는 락을 하나 더 잡게 하여, Deq를 빠르게 한다. */

    volatile int   mRFutex;                     /* Dequeue 용 Futex */
    volatile int   mWFutex;                     /* Enqueue 용 Futex : 안씀 */


    volatile int    mEnq;                       /* Queue 의 마지막 리스트 Slot 번호  */
    volatile int    mDeq;                       /* Queue 의 첫번째 리스트 Slot 번호 */

    int             mOldEnq;                    /* Header 변경 시 로깅용 : mEnq */
    int             mOldDeq;                    /* Header 변경 시 로깅용 : mDeq */

    int             mRecoveryProcessF;          /* 현재 리커버리시 Lock 용 Flag */

    char            mTriggerQueue[DBM_NAME_LEN];
    int             mDDLCount ;
} dbmQueueHeader;


typedef struct dbmListHeader
{
    dbmTableObject  mTableObj;

    unsigned long long mIndexCount;
    dbmIndexObject  mIndex[DBM_MAX_INDEX_PER_TABLE];

    int             mInitCompleteF;             /* segment 생성 후 init 완료하였음. */
    volatile int    mLock;                      /* table lock for queue */

    int             mRecoveryProcessF;          /* 현재 리커버리시 Lock 용 Flag */
    int             mDDLCount ;

    int             mListTotalCount;            /* List Alloc Total Count */
    long long       mListLeftLast;              /* Left Last Postion      */
    long long       mListRightLast;             /* Right Last Position    */

    int             mSegmentAllocCk[MAX_SEGMENT_COUNT]; /* segment Alloc Check */
} dbmListHeader;


/*************************************************************
 * Row Header 구조체
*************************************************************/
typedef struct dbmRowHeader
{
    volatile long long mSCN;            // Commit SCN
    volatile int    mLock;              // trans id 저장하여 lock

#ifdef _DBM_MVCC2
    /*
     * TODO: 2015.03.06 -okt- (구현중) #888
     *
     * FETCH 개념에서 락이 해제된 Row 이지만. 세션이 유지되고 있다면, UNDO에서 해당 이미지를 찾아서,
     * ERR_DBM_FETCH_SCN_INVISIBLE 의 가능성을 줄이기 위해서 변수 추가
     */
    volatile int    mLockPre;
#endif

    /*
     * TODO: [OKT] #887 적용으로 dbmRowHeader 크기가 늘었다. 이게 별로 의미가 없다면, mRowSize를 제거하면 좋겠다.
     *             항후 우리가 LOB 개념 비슷하게, 마지막 컬럼 하나만, 큰 데이타를 저장하게 허용한다면. VARCHAR(4000) 이런것 대응,
     *             mRowSize가 필요할 것이다.
     *             지금은 모든 ROW가 길이가 같으니. 이 정보를 테이블 헤더로 옮기고, mRowSize는 컬럼마다, 길이 정보를 가져가는 특수한 테이블에 대한 정의로 사용하는 것은 어떨까.
     *             그렇게 되면 새로운 테이블 타입이 생기는 것이고, VARCHAR, NULL 을 지원할 수 있다.
     *             물론 기존 개념의 테이블이 컬럼별 처리를 안하는 성능 장점을 위해 유지하고,
     */
    int             mRowSize;           // Row Size (excluding row header)
} dbmRowHeader;

/****************************************************************
 * Logging 을 남길때 공통으로 사용하는 구조체
 ****************************************************************/
typedef struct dbmTransLog
{
    dbmLogType      mLogType;         // 로그형태
    int             mObjectID;        // ObjectID
    long long       mSlot  ;          // Slot 번호
    long long       mSCN ;            // SCN 번호
    //char            mTableName[DBM_NAME_LEN] ; // TableName
    char            mObjectName[DBM_NAME_LEN] ; // ObjectName
    char*           mImagePtr;        // Image 주소
    int             mImageSize;       // Image 크기
    long long       mLSN ;            // LSN
} dbmTransLog ;



/****************************************************************
 * Replication 에서 사용할 구조체
 ****************************************************************/

typedef struct dbmReplMsg
{
    long long   mLSN;               // 해당 로그의 MSG
    dbmTransLog mTransLog;          // TransLogHeader
    char        mData[DBM_MAX_RECORD_SIZE] ; //
} dbmReplMsg;


typedef struct dbmReplSeqInfo
{
    int     sTxID;                //mTxID
    long long sLSN;                 //mLSN
    int     sCurFileNo;           //currFileNo
    int     sTotalBlockNo;        // block transaction 에서의 block count
    int     sTranTotalSize;       // block transaction total size

    long long sSeq;                 // check sequence
    long long sMagicNo;             // check value

} dbmReplSeqInfo;

typedef struct dbmReplLog
{
    int     sTotalSize;
    int     sDataSize;
    int     sLogCount;
    int     sDummy;
    int     sTxID;
    long long sSeq;
    char    sLogData[STACKSIZE];
} dbmReplLog;

typedef struct dbmReplRecvSeq
{
    long long sSeqOffset;
    long long sSeq;
} dbmReplRecvSeq;


/****************************************************************
 * 로그 파일의 Header 정보
 ***************************************************************/

typedef struct  dbmLogFileHeader
{
    long long     mEndLSN ;
} dbmLogFileHeader;


/****************************************************************
 * Disk 에 사용할 LogBlock Header
 ****************************************************************/
typedef struct dbmLogBlockHeader
{
    long long  mLSN ;                // 이번에 쓰여질 LSN
    int      mTotalBlockNo;        // 전체 Block 의 갯수
    int      mCurrentBlockNo;      // 내가 쓰여진 Block 의 갯수
    int      mTranTotalSize;       // 본 트렌젝션의 전체 사이즈
    int      mIsCompressF;
    struct timeval mWriteTime;     // 본 블럭이 쓰여진 시점
    long long  mMagicNo; 
} dbmLogBlockHeader;


/****************************************************************
 * 한 Tx 별로 사용되는 Log Anchor
 ****************************************************************/
typedef struct dbmLogAnchorPerTx
{
    short   mStat;                // Commit 상태를 위한 변수
    int     mCurFileNo;           // 내 파일 번호
    int     mAlloc;               // Alloc 여부
    long long mLastFileSize ;       // 마지막 파일 사이즈
    long long mLastSyncSize ;      // 마지막으로 Sync 한 File Offset
} dbmLogAnchorPerTx ;

/****************************************************************
 * 관리하는 전체 Log Anchor 구조  : 이대로 Undo 에 저장한다.
 ***************************************************************/
typedef struct dbmLogAnchor
{
    volatile long long mLoggerLSN ;                       // Logger 의 LSN
    long long         mSyncCount;                        // Anchor 의 sync Count
    char              mInstanceName [DBM_NAME_LEN];      // 인스턴스 이름
    char              mLogDest  [DBM_FILE_NAME_LENGTH];
    long long         mLogFileSize;                      // 로그파일의 크기
    int               mLoggerEnableF ;                   // Logger 의 Enable 여부
    int               mLastFileSequence ;                // 로그앵커 이름을 만들 시퀀스
    int               mReplEnableF;                      // Replication Enable 여부
    int               mReplMemoryEnableF;                // Replication Memory Enable 여부
    struct timeval    mLastSyncTime;                     // 마지막으로 Sync 된 시간
    dbmLogAnchorPerTx mTxAnchor [DBM_MAX_TRANS];
} dbmLogAnchor;



/**************************************************************
 * Global Undo Header
 *  - 채번 등 Logging 등을 위해 Global 하게 사용되는 변수는
 *    dbmUndoHeader 에 둔다.
 *    동시성 처리가 필요한 채번은 그냥 다 여기에 모아두자.
**************************************************************/
typedef struct dbmUndoHeader
{
    long long       mGSCN;                      /* SCN 채번을 위한 Global 변수 */
    long long       mGLSN;                      /* LSN 채번을 위한 Global 변수 */
    long long       mSessID;                    /* SessionID 채번을 위한 Global 변수 */
    volatile int    mLock;                      /* ddl lock 을 위해 사용 */

    dbmStatObject   mStat;                      /* 통계 정보 저장 */

    dbmLogAnchor    mAnchor;                    /* Log Anchor */
} dbmUndoHeader;


/**************************************************************
 * Transaction Header
 *   - Pos(Position) 는 slot ID 와 slot 내에서의 유일한 offset 을
 *     32 bit 씩 사용한다.
 *     |----- 32 bit -----|---- 32bit ----|
 *          Slot ID            Offset
**************************************************************/
typedef struct dbmTransHeader
{
    volatile int    mPID;                           /* 복구 시 Process 체크 및 Lock 대용으로 사용 */
    volatile int    mMyTxID;                        /* my transaction ID */

    int             mLastAllocLogSlot;              /* Log 기록용으로 할당되어 있는 마지막 Slot ID */
    int             mLastAllocImageSlot;            /* Image 기록용으로 할당되어 있는 마지막 Slot ID */

    volatile long long mLogCurPos;                     /* 마지막으로 Log 를 기록한 위치 */
    volatile long long mImageCurPos;                   /* 마지막으로 Image 를 기록한 위치 */

    int             mUserID;                        /* 초기 connect 시에 할당되는 user ID */
    long long       mSessionID;                     /* 초기 connect 시에 할당되는 session ID */
    long long       mSCN;                           /* transaction commit 시에 획득한 SCN 저장 */
    dbmTxStatus     mStatus;                        /* 현재 transaction 의 상태 */
    dbmDeferStatus  mDeferStatus;                   /* DeferCommit status 나타낸다 */

    int             mLogCntPerSlot;                 /* 한 Slot 당 기록가능 Log 수 */
    int             mImageCntPerSlot;               /* 한 Slot 당 기록가능 Image 수 */

    long long       mLogStartPos;                   /* Log 의 Starting Position */
    long long       mImageStartPos;                 /* Image 의 Starting Position */

    long long       mRecoveryStartPos;              /* Recovery 수행 시 Rollback 의 start 지점
                                                       복구 시점에 만약 셋팅되어 있으면 mLogCurPos 와
                                                       비교하여 작은 것부터 Rollback 을 시작한다. */
    long long       mLockRecoveryPos;               /* Lock 을 못풀고 죽었을 경우 복구를 위함 */

    int             mWaitForTransID  ;                   /* Lock Wait 일 경우 어떤 놈을 기다리고 있는지 표시 */
    int             mWaitForObjectID;               /* Lock Wait 일 경우 어떤 ObjectID 를 기다리고 있는지 표시 */
    int             mWaitForSlotID;                 /* Lock Wait 일 경우 어떤 Slot 을 기다리고 있는지 표시 */

    int             mDiskLoggingEnableF;            /* Disk Logging 이 Enable 인지에 대하여 마킹 */
} dbmTransHeader;


/**************************************************************
 * Transaction Table ( array of dbmTransItem )
**************************************************************/
typedef struct dbmTransTable
{
    dbmTransHeader  mItem[DBM_MAX_TRANS];       /* array of dbmTransHeader */
} dbmTransTable;


/**************************************************************
 * Logging Header
 *  - Logging 영역(Logging 용 Slot)에는 dbmLogHeader 만 기록한다.
**************************************************************/
typedef struct dbmLogHeader
{
    dbmLogType      mLogType;                       /* logging type */
    long long       mMyLogPos;                      /* My Current Log Position */
    long long       mSCN;                           /* scn */
    int             mTransID;                       /* transaction ID */

    int             mObjectID;                      /* Object ID */
    char            mObjectName[DBM_NAME_LEN];      /* object Name */
    char            mTableName[DBM_NAME_LEN];       /* table Name */

    long long       mRefRecord;                     /* 참조하는 Table Record Slot ID. queue timeout 값으로도 사용 */
    long long       mImageLogPos;                   /* Image Logging 순서 위치 */
    int             mImageSize;                     /* Logging 한 Image 크기 */
    long long       mLSN;                           /* Log 의 Sequence Numer */

#if 0
    // 2014.11.18. -okt- char 타입이 movb로 바뀌는데 이게 perf에서 튄다.
    char            mLogValidF;                     /* Log 가 잘 기록되었음. */
    char            mImageLogValidF;                /* Image Log 가 잘 기록되었음. */
    char            mCommitCompleteF;               /* Commit 시 로그처리가 잘 완료되었음 */
    char            mRollbackCompleteF;             /* Rollback 이 잘 완료되었음 */
#else
    int             mLogValidF;                     /* Log 가 잘 기록되었음. */
    int             mImageLogValidF;                /* Image Log 가 잘 기록되었음. */
    int             mCommitCompleteF;               /* Commit 시 로그처리가 잘 완료되었음 */
    int             mRollbackCompleteF;             /* Rollback 이 잘 완료되었음 */
#endif

    long long       mQueProcDone;                   /* enque/deque 시 WInd(RInd)를 증가했는지 여부 */
    char*           mRefPtr;                        /* 살아있을 때만 사용하는 Header/Row/Manager pointer */
    char*           mObjectHeader;                  /* 살아있을 때만 사용하는 Object Header */
    struct timeval  mWriteTime;                     /* Log 를 기록시작한 시간 */
} dbmLogHeader;

typedef struct dbmLogSlotHeader
{
    long long       mMySlotID;
    long long       mPrev;                          /* prev slot ID */
    long long       mNext;                          /* next slot ID */
} dbmLogSlotHeader;

/**************************************************************
 * dbmCheckPoint header
**************************************************************/
typedef struct dbmCheckPointAnchor
{
    int             mTxNo;            /* LogAnchor Transaction No */
    int             mCurFileNo;       /* logfile Curr No          */
} dbmCheckPointAnchor;

typedef struct dbmCheckPointDbPerTx
{
    short       mStat;                // Commit 상태를 위한 변수
    int         mFDSequence;          // File Open Sequence
    int         mTransCnt;            // Trans Count
} dbmCheckPointDbPerTx;

typedef struct dbmCheckPointDbscn
{
    short       mStat;                // scn state
    long long   mSCN;                 // db image scn
} dbmCheckPointDbscn;

typedef struct dbmCheckPointDbAnchor
{
    char        mObjectName[DBM_NAME_LEN];
} dbmCheckPointDbAnchor;

typedef struct dbmCheckPointDataDDL
{
    char        mBlockData[DBM_LOG_BLOCK_SIZE];     // BlockHeader + TransLog + Image
} dbmCheckPointDataDDL;


typedef struct dbmCheckPointStAnchorTx
{
    short       mStat;
} dbmCheckPointStAnchorTx;

typedef struct dbmCheckPointStAnchor
{
    dbmCheckPointStAnchorTx mTxStAnchor [DBM_MAX_TRANS];
} dbmCheckPointStAnchor;

/**************************************************************
 * Event Type ( Trigger )  Data
 *  - Event 를 정의하는 데이터를 정의한다.
**************************************************************/

typedef enum dbmEventOperation
{
    DBM_EVENT_INSERT
  , DBM_EVENT_UPDATE_BEFORE
  , DBM_EVENT_UPDATE_AFTER
  , DBM_EVENT_DELETE
} dbmEventOperation;

typedef struct dbmEventDataHeader
{
    int                 mTxID;
    long long           mCommitSCN;
    dbmEventOperation   mEventType;
    int                 mObjectID;
    char                mObjectName[DBM_NAME_LEN];
    int                 mDataLen;
} dbmEventDataHeader;


#ifdef __cplusplus
};
#endif

#endif  /* __O_DBM_STRUCT_H__ */
