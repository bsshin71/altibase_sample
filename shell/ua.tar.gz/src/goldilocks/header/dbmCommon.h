/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    내부적으로 DBM에 공통적으로 적용할 항목들에 대한 DEFINE절
*******************************************************************************/
#ifndef __O_DBM_COMMON_H__
#define __O_DBM_COMMON_H__


#include "cmnApi.h"
#include "dbmAPI.h"
#include "dbmServer.h"
#include "dbmDefine.h"
#include "dbmObject.h"
#include "dbmStruct.h"
#include "dbmConfigManager.h"
#include "dbmAnchorManager.h"
#include "dbmSegmentManager.h"


#endif  /* __O_DBM_COMMON_H__ */
