/*
 * dbmHeader.h
 */

#ifndef DBMHEADER_H_
#define DBMHEADER_H_

#include "cmnHeader.h"
#include "dbmCommon.h"
#include "dbmLockManager.h"
#include "dbmLogManager.h"
#include "dbmIndexManagerInterface.h"
#include "dbmTableManager.h"
#include "dbmQueueManager.h"
#include "dbmDiskLogManager.h"
#include "dbmInternalHandle.h"
#include "dbmParser.h"
#include "dbmPerf.h"
#include "dbmRID.h"
#include "dbmRecoveryManager.h"
#include "dbmTransManager.h"


extern void* __liblz4_so;       // dbmDiskLogger.cpp 에 정의됨.
extern int ( *__LZ4_decompress_safe ) ( const char* source, char* dest, int inputSize, int maxOutputSize ) ;


//extern void dbmGetErrorByHandle ( dbmHandle* aHandle , char* aErrMsg );
extern _VOID dbmShowSession     ( char* aUndoName, int aSessionID );
extern char* LogType2Str( dbmLogType aLogType );
extern _VOID dbmSetHandleOption ( dbmHandle * aHandle, dbmHandleOption aOption, int val ) ;
extern _VOID dbmGetHandleOption ( dbmHandle * aHandle, dbmHandleOption aOption, int *val ) ;
extern void dbmVersion ( );
extern void dbmVersion ( char* aRev, char* aTime );

#endif /* DBMHEADER_H_ */
