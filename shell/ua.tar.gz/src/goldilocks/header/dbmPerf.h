#ifndef __O_DBM_PERF_H
#define __O_DBM_PERF_H

#include "dbmCommon.h"

typedef struct dbmPerfLog
{
    long long mCount;
    double mSumOfElap;
    struct timespec mStart;
    struct timespec mEnd;
} dbmPerfLog;


#ifdef __cplusplus

#include <map>
#include <string>


class dbmPerf
{
public:
    static std::map<std::string, dbmPerfLog> gPerf;

    static void dbmPerfInit   ();
    static void dbmPerfStart  (char *aFunc);
    static void dbmPerfEnd    (char *aFunc);
    static void dbmPrintAll   ();
};

#endif

#endif /* __O_DBM_PERF_H */
