/*******************************************************************************
* Copyright 2012, OnmirSoft Corporation or its subsidiaries.
* All rights reserved.
*******************************************************************************/
#include "dbmCommon.h"
#include "dbmLogManager.h"
#include "dbmLockManager.h"
#include "dbmRecoveryManager.h"

typedef struct dbmListSlotHeader
{
    int             mMySlot;
    int             mNext;
    int             mRowSize;
    volatile int    mLock;
    long long       mSCN;
} dbmListSlotHeader;

class dbmListManager
{

/* 변수 private 선언 */
private:
    int             mTableID;
    char            mListName[DBM_NAME_LEN];
    char            mInstName[DBM_NAME_LEN];


    dbmListHeader*      mListHeader;
    dbmSegmentManager*  mSegMgr;
    dbmLogManager*      mLogMgr;
    dbmLockManager*     mLockMgr;
    dbmTransLogger*     mTransLogger;

/* 변수 public 선언 */
public:


/* 상속 변수 선언   */
protected:



/* 함수 private 선언 */
private:
    _VOID mListCheck        ( int aTransID, void* aDataObject);
    _VOID mListMakeKey      ( int aCheck, long long* aAllocSlot );
    _VOID mListExtend       ( long long aAllocSlot );
    _VOID mListLock         ( char* aInstName, dbmListSlotHeader* aListRow, char* aBeforeImage, int aTransID );
    _VOID mReadList         ( int aTransID, long long aSlot, char* aRecord, int* aDataSize, int* aInserted );


/* 함수 public 선언 */
public:
    dbmListManager( );
    ~dbmListManager( );

    dbmListHeader*  mGetListHeader()    { return mListHeader; }
    _VOID           mGetListID()        { return mTableID; }
    _VOID           mSetTransLogger( dbmTransLogger* aLogger ) { mTransLogger = aLogger; return 0; };
    char*           mGetListName()      { return mListName; }

    _VOID mListRpush        ( int aTransID, void* aDataObject );
    _VOID mListLpush        ( int aTransID, void* aDataObject );
    _VOID mListRpop         ( int aTransID, void* aDataObject );
    _VOID mListLpop         ( int aTransID, void* aDataObject );
    _VOID mListRange        ( int aTransID, void* aDataObject );

    _VOID   mInitList( char*              aInstName, 
                       char*              aListName,
                       dbmDicObject*      aDicObject,
                       dbmLogManager*     aLogMgr,   
                       dbmLockManager*    aLockMgr );

    dbmSegmentManager* mGetSegMgr() { return mSegMgr; }

    _VOID mSetTableID ( int aTableID )
    {
        mTableID = aTableID;
        return 0;
    }

/* 상속 함수 선언   */
protected:


};


