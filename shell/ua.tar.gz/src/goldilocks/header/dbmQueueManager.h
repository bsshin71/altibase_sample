/*******************************************************************************
* Copyright 2012, OnmirSoft Corporation or its subsidiaries.
* All rights reserved.
*******************************************************************************/

/*******************************************************************************
* $Id$
*
* Description :
*   Queue 에 대한 각종 연산을 수행하는 Queue Manager
******************************************************************************/
#ifndef __O_DBM_QUEUE_MANAGER_H__
#define __O_DBM_QUEUE_MANAGER_H__

#include "dbmCommon.h"
#include "dbmLogManager.h"
#include "dbmLockManager.h"
#include "dbmRecoveryManager.h"


typedef struct dbmQNodeHeader
{
    int             mMySlot;
    int             mNext;
    int             mDataSize;
    volatile int    mLock;
    long long       mSCN;
} dbmQNodeHeader;

class dbmTransLogger;

/**************************************************************
 * dbmQueueManager class
**************************************************************/
class dbmQueueManager
{
private:
    char                mInstName[DBM_NAME_LEN];        /* table 이 소속된 instance name */
    char                mQueueName[DBM_NAME_LEN];
    int                 mTableID;
    dbmQueueHeader*     mQueueHeader;

    dbmSegmentManager*  mSegMgr;
    dbmLogManager*      mLogMgr;
    dbmLockManager*     mLockMgr;

    dbmQNodeHeader*     mQStartPtr;
    long long           mLastSlotID;

    dbmQNodeHeader*     mRollbackStartPtr;
    long long           mRollbackLastSlotID;

    dbmTransLogger*     mTransLogger;


public:
    dbmQueueManager( );
    ~dbmQueueManager( );

    _VOID mInitQueue ( char* aInstName , char* aQueueName , dbmDicObject* aDicObject ,
                       dbmLogManager* aLogMgr , dbmLockManager* aLockMgr );

    dbmSegmentManager* mGetSegMgr() { return mSegMgr; }
    /*
     * 자신이 관리하는 queue 정보 제공
     */
    dbmQueueHeader* mGetQueueHeader() { return mQueueHeader; }
    char* mGetQueueName()   { return mQueueName; }
    long long mGetQueueID() { return mTableID; }
    int mGetTableType()     { return mQueueHeader->mTableObj.mTableType; }
    int mGetMsgSize()       { return mQueueHeader->mTableObj.mRecordSize; }

    _VOID mEnque            ( int aTransID, void* aDataObject );
    _VOID mDeque            ( int aTransID, void* aDataObject );

    _VOID mEnqCommitAll     ( int aTransID ) ;
    _VOID mBuildNewNode     ( int aTransID, void* aDataObject, dbmQNodeHeader** aRtnPtr )  ;

    _VOID mDeqRollback      ( char* aBeforeImage, int aImageSize  ) ;
    _VOID mDeqRollbackComplete (int aTransID ) ;
    _VOID mBuildEnqueueLink ( int aSlotID ) ;
    _VOID mSetTransLogger   ( dbmTransLogger* aLogger ) { mTransLogger = aLogger; return 0; };

    // 2014.09.21. (OKT) 미구현 막음.
//    int mEnqueCommit        ( int aTransID, dbmLogHeader* aCurLog, char* aImage, int aImageSize, long long aSCN );
//    int mDequeMore          ( int aTransID, void* aDataObject );
//    int mDequeArray         ( int aTransID, void* aDataObject );
//    int mNewDeque           ( int aTransID, void* aDataObject ) ;
//    int mGetCount    () ;
};

#endif  /* __O_DBM_QUEUE_MANAGER_H__ */
