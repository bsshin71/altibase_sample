/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   DBM Parser용도
*******************************************************************************/
#ifndef __O_DBM_PARSER_H__
#define __O_DBM_PARSER_H__

#include "dbmCommon.h"

#define TOKEN_EQ(T,K)       ( memcmp ( T, K, strlen_s(K) ) == 0 && strlen_s(T) == strlen_s(K) )
#define TOKEN_NE(T,K)       ( memcmp ( T, K, strlen_s(K) ) != 0 || strlen_s(T) != strlen_s(K) )
#define TOKEN_EQ_IC(T,K)    ( strncasecmp ( T, K, strlen_s(K) ) == 0 && strlen_s(T) == strlen_s(K) )
#define TOKEN_NE_IC(T,K)    ( strncasecmp ( T, K, strlen_s(K) ) != 0 || strlen_s(T) != strlen_s(K) )
#define TOKEN_EQ_IC2(T,K,N) ( strncasecmp ( T, K, N ) == 0 && ( strlen_s(T) + strlen_s(K) >= ( 2 * (N) ) ) )
#define TOKEN_NE_IC2(T,K,N) ( strncasecmp ( T, K, N ) != 0 || ( strlen_s(T) + strlen_s(K) <  ( 2 * (N) ) ) )

/*****************************************************************************
 * create undo <name> init = 10 extend = 10 max = 10;
 * create data <name> init = 10 extend = 10 max = 10;
*****************************************************************************/
class dbmParser
{
public:
    /*
     * SQL 을 parsing 하여 결과로 dbmParseObject 를 리턴한다.
     */
    static _VOID mParse( char* aSQL, dbmParseObject* aObject );

private:
    /*
     * offset을 계산한다.
     */
    static int mCalcOffset( int aSize, int aCurrOffset );
    static int mCalcRecordSize( int aOffset, int aSize, int aAlign );
    static int mCalcAlign( int aAlign, int aSize );

    static _VOID mTruncateDDL( );
    static _VOID mCreateDDL( );
    static _VOID mDropDDL( );
    static _VOID mAlterDDL( ) ;

    static _VOID mInsertDML( );
    static _VOID mDeleteDML( );
    static _VOID mUpdateDML( );
    static _VOID mSelectDML( );
    static _VOID mEnqueueDML( );
    static _VOID mDequeueDML( );

    static _VOID mListPushDML();
    static _VOID mListPopDML();

    static _VOID mSequenceDML();
};


#endif  /* __O_DBM_PARSER_H__ */
