

/*******************************************************************************
 *
 * Transaction Log 를 기록하기 위한 상위 클래스로 최초 설계 목적은 모든 Transaction 
 * 을 Logging 하는 기능을 구현하기 위한 추상 클래스로 설계되었으나, 로그 버퍼에 Transaction 
 * Log 를 적재하는 일부 기능을 포함하게 되었다. 
 *
 * mWriteLog 함수는 Transaction 로그를 dbmTransLogger 에서 할당한 mLogBuffer 에
 * 복사하고, 여러번 호출하면 순서대로 차곡차곡 쌓이게 된다. 해당 mLogBuffer 에 
 * 복사한 총 Bytes 는 mLogBufferIdx 를 통해 알아낼 수 있다. 
 *
 * mFlush / mSync 는 dbmTransLogger 를 상속받는 클래스인 dbmDiskLogger 에서 구현되며, 
 * mFlush 는 실제 commit 시점에 호출되며, mSync 또한 Commmit 시점에 호출된다. 
 *
 * mFlush() 는 현재 mLogBuffer 에 있는 모든 Transaction 로그를 Commit 되었으니 내려 쓰라는 
 * 의미이고, mSync () 는 해당 내용이 제대로 쓰이도록 OS 차원의 sync 를 수행하는 것이다. 
 *
 * 그런데 만약 Memory Logging 모듈을 만든다면, 굳이 dbmTransLogger 를 상속받아서 구현할 
 * 필요는 없을 것도 같은데, 이걸 상속 받는다면 두번의 memcpy 가 일어나기 때문이다. 
 *
 ******************************************************************************/


#ifndef __O_DBM_TRANS_WRITE_H__
#define  __O_DBM_TRANS_WRITE_H__

#include "dbmCommon.h"


class dbmTransLogger
{
public:
    //dbmTransLogger ( );           // Constructor
    virtual ~dbmTransLogger ( );    // Desctructor, [컴파일워닝] virtual 추가, -Wdelete-non-virtual-dtor

    dbmTransLogger ( int aTxID , long long aLogBufferSize );  // 로그버퍼만큼 메모리를 할당한다.

public:
    virtual _VOID mWriteLog ( dbmTransLog* aLog );

    /** 이 부분은 Derived Class 에서 알아서 정의하라 */
    virtual int mFlush ( ) = 0;

    /*  Durability 를 위해서 지정하는 부분 */
    virtual int mSync ( ) = 0;

    /* mLogAnchor START, END write 지정 */
    virtual int mAnchor ( int aFlagF ) = 0;

    /*  Commit Log 를 남기는 영역 */
    //virtual int mCommitSync ( ) = 0;  // 죽은코드

//    bool mHasItem ( )
//    {
//        if ( mLogBufferIdx == 0 )
//        {
//            return false;
//        }
//        return true;
//    }

public:
    int     mLogBufferIdx;  // 로그버퍼가 얼마큼 쌓였는지 체크, TxMgr에서 함수없이 바로 접근 위해 노출, 2014.11.17. -okt-
protected:
    char*   mLogBuffer;     // 로그 버퍼 : 한 Tx 단위로 묶기 위한 임시버퍼
//  int     mLogBufferIdx;  // 로그버퍼가 얼마큼 쌓였는지 체크

    int     mLogBufferSize;
    int     mTxID;          // 현재 로그의 TxID
} ;

#endif /* __O_DBM_TRANS_WRITE_H__ */


