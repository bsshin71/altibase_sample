/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    Lock 을 담당하는 manager.
 *    class 외부에서는 dbmLockManager::mLock()과 같이 사용하면 된다.
 *    객체를 생성해서 사용하지는 않는다.
 ******************************************************************************/
#ifndef __O_DBM_LOCK_MANAGER_H__
#define __O_DBM_LOCK_MANAGER_H__

#include "dbmCommon.h"


/**************************************************************
 * Definition
**************************************************************/
typedef struct LockCount
{
    volatile int mInitLock        ;
    volatile int mAtomicLockTry   ;
    volatile int mAtomicUnlockTry ;
    volatile int mSpinLock        ;
    volatile int mSpinUnlock      ;

    volatile int mLock            ;
    volatile int mUnlock          ;
    volatile int mTableLock       ;
    volatile int mTableUnlock     ;
    volatile int mLockPID         ;

    volatile int mCheckLockPID    ;
} LockCount;

extern LockCount g_cnt_lock ;


/**************************************************************
 * dbmLockManager class
**************************************************************/
class dbmLockManager
{
private:
    static int   __mLockInfoSize;  /* 특정 ID 별로 나뉘어 있는 User 영역 하나의 Size      */
    static char* __mLockInfo;      /* 특정 ID 로 접근하여 PID 를 가져올 수 있는 User 영역 */

public:
    _VOID mInitLock ( int aSize , char* aLockInfo );

    static _VOID mAtomicLockTry   ( char* aLockVal, int aSetVal, int aCheckVal );
    static char* mGetLockInfoAddr () { return __mLockInfo; }
    static _VOID mAtomicUnlockTry ( char* aLockVal, int aCheckVal );

    static _VOID mLockPID    ( char*   aLockVal,         /* lock value pointer */
                               int     aSetVal,          /* pid to replace     */
                               int*    aPidReplacedF );  /* pid replaced flag  */

    static _VOID mSpinLock ( volatile void* aLock , volatile int* aFutex , int aMyID );
    static _VOID mSpinUnlock ( volatile void* aLock , volatile int* aFutex , int aMyID );
    static _VOID mLock ( volatile void* aLock , int aMyId , int* aPidReplacedF , int* aPirReplaced = NULL );
    static _VOID mUnlock ( volatile void* aLock , int aMyId );
    static _VOID mTableLock ( volatile void* aLock , int aTransID , int* aOldTx );
    static _VOID mTableUnlock ( volatile void* aLock , int aTransID );
    static int   mCheckLockPID ( int aTransID );
    static int   mRecoverCheckLockPID ( int aTransID, int aMyTxID );
};

/*
 * for IndexMgr Only ( Cost )
 */
#ifdef _DEBUG
#define mvpAtomicCas32_s(addr,val,pre)  { if (val!=-1) _ASSERT(0); mSpinUnlockLib( (addr), NULL, pre, NULL ); }
#else
#define mvpAtomicCas32_s(addr,val,pre)  mvpAtomicCas32(addr,val,pre)
#endif


#endif  /* __O_DBM_LOCK_MANAGER_H__ */
