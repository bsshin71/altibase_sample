/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *   space manager
 ******************************************************************************/
#ifndef __O_DBM_SEGMENT_MANAGER_H__
#define __O_DBM_SEGMENT_MANAGER_H__

#include "dbmCommon.h"
#include "cmnStlMap.h"


#define USE_NEW_SHM                         // cmnPShmXX 를 직접사용하지 않고, RefCount를 관리하는 cmnShmManager를 통해서 호출
#define USE_NEW_SHM_NODETACH                // SegMgr을 호출하는 사용단에서 detach를 호출하지 않음.

/**************************************************************
 * dbmSegment Manager 에서 사용하는 Header 등에 대한 상수값을 정의
**************************************************************/
#define     MAX_SEGMENT_NAME_LENGTH        128
#define     MAX_SEGMENT_COUNT              1024     // 이전: 512 ( 2014/09/10 )
#define     MAGIC_STRING                  "onmir_goldilocks_segmentFiles"


/**************************************************************
 * Segment 헤더를 저장하기 위한 자료구조
**************************************************************/
typedef struct dbmSegmentHeader
{
    volatile int    mLock;              // Lock
    char            mMagicString [MAX_SEGMENT_NAME_LENGTH] ;
    char            mInstName    [DBM_NAME_LEN] ; // 인스턴스 이름
    char            mSegmentName [MAX_SEGMENT_NAME_LENGTH] ; // 오브젝트 이름
    volatile int    mSegmentCount ;     // 현재 관리되는 Shared memory Segment 갯수
    size_t          mSlotSize;          // 해당 Segment 의 SlotSize
    long long       mInitSlotCount;     // Init Slot Size j
    long long       mMaxSlotCount ;     // MAX Slot Size
    long long       mExtendSlotCount;   // Extend Slot Size, (성능) 사용자가 입력한 값보다 크거나 같은 2의 제곱수.
    long long       mExtendSlotPower;   // 2014.11.21. (성능) Extend Slot Size에 대한 지수를 따로 저장한다.
    volatile int    mNextExtendNo;      // 다음 Extend 시 사용할 Extend 번호
    size_t          mUserHeaderSize;    // 사용자가 알아서 쓸 Header 의 크기

    /*
     * TODO: 2014.11.21 -okt- 확인요. 이거 목적이 무었인지? 위에 컬럼 ( 예, mExtendSlotPower ) 추가되면, 줄여야하는 것인지.
     */
    //char            mPadding1[32];
    char            mPadding1[28];

    /** Alloc Free 를 관리하기 함 */
    long long       dy;
    volatile long long mAlloc;
    volatile long long mFree;

    int             mSegmentAlloc[MAX_SEGMENT_COUNT]; /* segment Alloc Check */
} dbmSegmentHeader;


/**************************************************************
 * dbmSegmentManager class
**************************************************************/
#include <string>
#include <map>

#ifdef _DEBUG
#define DBM_SLOT_TRACE
#endif

class dbmSegmentManager
{
public:
    /**************************************************************
     * Static Functions
     **************************************************************/
    static _VOID Create ( char* aInstName,
                          char* aObjectName ,
                          size_t aSlotSize ,
                          long long aInitSlotCount ,
                          long long aExtendSlotCount ,
                          long long aMaxSlotCount ,
                          size_t aUserHeaderSize ,
                          dbmSegmentManager** aReturnObject );

    static _VOID EXPORT_DLL Drop ( char* aInstName, char* aObjectName );
    static _VOID EXPORT_DLL Attach ( char* aInstName, char* aObjectName , dbmSegmentManager** aReturnObject );
    static _VOID EXPORT_DLL AttachList ( char* aInstName, char* aObjectName , dbmSegmentManager** aReturnObject );
    static _VOID EXPORT_DLL GetSpaceStat ( char* aInstName, char* aObjectName , dbmSpaceStat* aReturnStat );
    static _VOID EXPORT_DLL GetListSpaceStat ( char* aInstName, char* aObjectName , dbmSpaceStat* aReturnStat );

public:
    /**************************************************************
     * Public method
     *************************************************************/
#ifdef DBM_SLOT_TRACE
    _VOID AllocSlot ( long long* aReturnSlot, const char* aFile = __FILE__, const char* aFunc = __FUNCTION__, int aLine = -1 );
    _VOID FreeSlot ( long long aSlot , int aCheckFlag = 0, const char* aFile = __FILE__, const char* aFunc = __FUNCTION__, int aLine = -1 );
#else
    _VOID AllocSlot ( long long* aReturnSlot );
    _VOID FreeSlot ( long long aSlot , int aCheckFlag = 0 );
#endif

    //_VOID Slot2Addr ( long long aSlot , char** aReturnPtr );
    _VOID EXPORT_DLL Slot2Addr ( long long aSlot , void* aReturnPtr /* [주의] void** 의미임 */ );
    _VOID EXPORT_DLL ListSlot2Addr( long long aSlot , void* aReturnPtr /* [주의] void** 의미임 */ );

    _VOID Detach ( );
    _VOID Drop ( );
    _VOID DropList( );

    // SlotSize 를 리턴한다
    size_t GetSlotSize ( )
    {
        return mSlotSize;
    }

    long long GetAlloc ( )
    {
        //return mHeader->mAlloc - 1;
        return mHeader->mAlloc;         // 사용되는 용도는 데이타 존재 확인
    }

    _VOID SetAlloc ( long long aUsedSlotMax )
    {
        // #63 metaManager에서 DIRECT 테이블에 대한 사용량을 조회하기 위해 추가, 락을 잡지 않아서 부정확
        // 그러나 성능때문에 락을 잡을 수 없다.
        if ( aUsedSlotMax + 1 > mHeader->mAlloc )
        {
            mHeader->mAlloc = aUsedSlotMax + 1;
        }

        return 0;
    }

    _VOID ListSetAlloc ()
    {
        mHeader->mAlloc++;

        return 0;
    }

    _VOID ListFreeAlloc ()
    {
        mHeader->mAlloc--;

        return 0;
    }


    // 사용자 Header 의 시작값을 리턴
    char* GetUserHeader ( )
    {
        return mStartAddress[0] + sizeof(dbmSegmentHeader);
    }

    _VOID Extend ( );
    _VOID Truncate ( );
    _VOID TruncateList ( );
    long long GetLastExtendSlotNo ( );

    long long GetUsageExtendSlotNo( long long aAllocSlot );

    _VOID AllocExtend( int aSegmentNo );

public:
    // 사용하지 않는 디폴트 생성자
    dbmSegmentManager ( );
    ~dbmSegmentManager ( );

private:
    /**************************************************************
     * private method
     *************************************************************/
    _VOID FreeSlot ( int aSegmentNo , long long aSlotcount , long long aSlotNo , int aCheckFlag );
    _VOID AllocSlot ( int sSegmentNo , long long aSlotCount , long long* aReturnSlot );

    // 이 생성자는 Create 할때만 사용함
    dbmSegmentManager ( dbmSegmentHeader* aSegmentHeader );

    // 이 생성자는 Attach 할때만 사용한다
    dbmSegmentManager ( dbmSegmentHeader* aSegmentHeader , int aSegmentCount , char** aStartAddr , size_t aSlotSize , size_t aUserHeaderSize );

    // 이 생성자는 List Attach 할 때만 사용한다.
    dbmSegmentManager ( dbmSegmentHeader* aSegmentHeader , int aSegmentCount , char** aStartAddr , size_t aSlotSize , size_t aUserHeaderSize , int aTemp );

    // Attach 할  파일의 이름을 만들어낸다.
    static _VOID getFileName ( char* aInstName, char* aObjectName , int aSegmentNo , char* aReturnFile );

    _VOID CreateAndInitSegment ( char* aObjectName , int aCurrentSegmentNo , size_t aSlotSize , long long aSlotCount , dbmSegmentHeader* aHeader );
    int FindSegmentFromSlot ( long long aSlot );
    _VOID ExtendUntilSuccess ( int aSegmentNo );

    //TODO: [WIN64] 윈도 함수와 이름이 같다.
    //      [winbase.h] #define dbmLockSegment(w) GlobalFix((HANDLE)(w))
    _VOID dbmLockSegment ( );
    _VOID dbmUnlockSegment ( );

    _VOID CheckShmAttach ( int aSegmentNo );
    _VOID ListCheckShmAttach ( int aSegmentNo );

private:
    /**************************************************************
     * private member
     *************************************************************/
    int     mSegmentCount;                              // 현재 Attach 된 Segment 의 갯수를 지정한다.
    char*   mStartAddress[MAX_SEGMENT_COUNT];           // 주소값을 지정한다.
    char    mInstName[DBM_NAME_LEN];                    // 현재 이 Segment 가 속한 instance 이름
    char    mObjectName[MAX_SEGMENT_NAME_LENGTH];       // 현재 이 Segment 가 Bind 된 객체의 이름을  저장

    size_t              mSlotSize;
    size_t              mUserHeaderSize;
public: // 2014.11.18. -okt- 상위단에서 Slot2Addr호출시 prefetch 할려고 public 노출
    dbmSegmentHeader*   mHeader;

#ifdef DBM_SLOT_TRACE
    static int          mEnvCheckFlag;
    static cmnStlMap*   mSlotTraceMap;
#endif
};


////////////////////////////////////////////////////////////////////////////////
// C TYPE Wrapper
////////////////////////////////////////////////////////////////////////////////
#ifdef DBM_SLOT_TRACE
#define dbmSegAllocSlot(a,b)    dbmSegAllocSlot_( a, b, __FILE__, __FUNCTION__, __LINE__ )
#define dbmSegFreeSlot(a,b,c)   dbmSegFreeSlot_( a, b, c, __FILE__, __FUNCTION__, __LINE__ )

extern _VOID dbmSegAllocSlot_( dbmSegmentManager* pInfo, long long* aReturnSlot, const char* aFile, const char* aFunc, int aLine );
extern _VOID dbmSegFreeSlot_( dbmSegmentManager* pInfo, long long aSlot, int aCheckFlag, const char* aFile, const char* aFunc, int aLine );
#else
extern _VOID dbmSegAllocSlot ( dbmSegmentManager* pInfo, long long* aReturnSlot );
extern _VOID dbmSegFreeSlot ( dbmSegmentManager* pInfo, long long aSlot, int aCheckFlag );
#endif


#endif  /* __O_DBM_SEGMENT_MANAGER_H__ */
