/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    Logging 을 담당하는 manager.
 ******************************************************************************/
#ifndef __O_DBM_LOG_MANAGER_H__
#define __O_DBM_LOG_MANAGER_H__

#include "dbmCommon.h"


/**************************************************************
 * Definition
**************************************************************/

//long long SLOTID(long long pos);
//long long OFFSET(long long pos);
//long long MK_POS(long long slot, long long offset);
//dbmRowHeader* GETIMG( char* aImageSlotPtr, long long aOffset );
//dbmLogHeader* GETLOG( char* aLogSlotPtr, long long aOffset );

/**************************************************************
 * dbmLogManager class
**************************************************************/
class dbmLogManager
{
private:
    char*               mTxHeader;
    char*               mUndoHeader;
    dbmSegmentManager*  mUndoSegMgr;

public:
    dbmLogManager( char*    aTxHeader,
                   char*    aUndoHeader,
                   dbmSegmentManager* aUndoSegMgr )
    {
        mTxHeader   = aTxHeader;
        mUndoHeader = aUndoHeader;
        mUndoSegMgr = aUndoSegMgr;
    }

    void mSetLogMgr( char*    aTxHeader,
                     char*    aUndoHeader,
                     dbmSegmentManager* aUndoSegMgr )
    {
        mTxHeader   = aTxHeader;
        mUndoHeader = aUndoHeader;
        mUndoSegMgr = aUndoSegMgr;
    }

    /**
     * Memory Log 기록 시
     */
    _VOID mWriteMemLog          ( int            aLogType, /* dbmLogType     aLogType, */
                                  int            aTransID,
                                  int            aObjectID,
                                  char*          aObjectName,
                                  char*          aTableName,
                                  long long      aRefRecord,
                                  char*          aValue,
                                  int            aSize,
                                  /* 2014.11.20. -okt- 타입캐스팅 비용제거. 혹은 내부에서.
                                  char*          aRefPointer,
                                  char*          aObjectHeader,
                                  char**         aLogHead
                                  */
                                  void*          aRefPointer,
                                  void*          aObjectHeader,
                                  void*          aLogHead /* char** aLogHead */
                                  );

    /*
     * aTransID 가 기록한 Undo Log 중에서 aSlotID 에
     * 해당하는 Record 의 최종 Before 이미지를 읽는다.
     * ReadRecord 할 때 해당 Row 의 TxID 가 자신의 것이
     * 아닐 때 사용한다.
     */
    _VOID mReadUndoRecord      ( int          aTransID,
                                 long long    aSlotID,
                                 char*        aData,
                                 int*         aDataSize,
                                 long long    aMySCN,
                                 int*         aInsertedRowF,
                                 dbmLogType*  aLogType = NULL );

    /*
     * 채번
     */
    void mGetSCN ( long long* aSCN );
    void mGetLSN ( long long* aLSN );

    // 값을 증가시키지 않고, 획득
    void mPeekSCN( long long* aSCN );

    static _VOID mFreeAllSlotList( int                aRecoveryFlag,
                                   dbmSegmentManager* aUndoSegMgr,
                                   dbmTransHeader*    aHeader );
    static _VOID mFreeSlotList ( int                aRecoveryFlag,
                                 dbmSegmentManager* aUndoSegMgr,
                                 dbmLogSlotHeader*  aStartSlot );

    static _VOID mLogMoveForward ( dbmSegmentManager* aSegMgr,
                                 dbmTransHeader*    aTxH,
                                 long long*         aCurPos );
    static _VOID mLogMoveBackward( dbmSegmentManager* aSegMgr,
                                 dbmTransHeader*    aTxH,
                                 long long*         aCurPos );
    inline
    static char* mGetTxHead    ( dbmTransTable*     aTxTable,
                                 int                aTransID )
    {
        return (char *) ( (char *) aTxTable + sizeof(dbmTransHeader) * aTransID );
    }
    static _VOID mDumpLog      ( char*              aLogHeader );
    static _VOID mDumpLog      ( char*              aLogHeader,
                                 long long          aLogPos );
    _VOID mIsInsertedRow       ( int                aTransID,
                                 long long          aSlotID,
                                 int*               aInsertedRowF );

    // 2014.09.22 (OKT): 사용되는 곳 없음.
    _VOID mExistEnqueLog       ( int                aTransID,
                                 int                aTableID,
                                 int*               aExistF );

    _VOID mFindLockedRecord    ( int                aTransID,
                                 int                aObjectID,
                                 long long          aSlotID,
                                 int *              aLockedF ) ;

private:
    _VOID mGetPos2Write        ( int*               aLastAllocSlot,
                                 int                aLogCntPerSlot,
                                 long long          aStartPos,
                                 long long*         aCurPos );

    _VOID mInitLogSlot         ( dbmLogSlotHeader*  aSlot,
                                 long long          aSlotID );

    _VOID mReadUndoSlotRecord  ( dbmTransHeader*   aTxHeader,
                                 char*             aSlot,
                                 int               aLastOffset,
                                 long long         aRecordSlotID,
                                 char*             aData,
                                 int*              aDataSize,
                                 long long         aMySCN,
                                 int*              aInsertedRowF,
                                 dbmLogType*       aLogType );
};

_INLINE
long long SLOTID ( long long pos )
{
    return ( pos >> 32 );
}

_INLINE
long long OFFSET ( long long pos )
{
    return (long long) ( (int) pos );
}

_INLINE
long long MK_POS ( long long slot , long long offset )
{
    return ( ( slot << 32 ) | ( offset & 0x00000000ffffffff ) );
}

_INLINE
dbmLogHeader* GETLOG( char* aLogSlotPtr, long long aOffset )
{
    return (dbmLogHeader*) ( aLogSlotPtr
                           + sizeof(dbmLogSlotHeader)
                           + sizeof(dbmLogHeader)
                           * aOffset );
}

_INLINE
dbmRowHeader* GETIMG( char* aImageSlotPtr, long long aOffset )
{
    return (dbmRowHeader*) ( aImageSlotPtr
                           + sizeof(dbmLogSlotHeader)
                           + (DBM_MAX_RECORD_SIZE+sizeof(dbmRowHeader))
                           * aOffset );
}


#endif  /* __O_DBM_LOG_MANAGER_H__ */
