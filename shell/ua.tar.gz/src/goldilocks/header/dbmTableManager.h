/*******************************************************************************
* Copyright 2012, OnmirSoft Corporation or its subsidiaries.
* All rights reserved.
*******************************************************************************/

/*******************************************************************************
* $Id$
*
* Description :
*    Table Manager 관련 자료구조 및 Definition 정의 .
*    Transaction Manager 가 dbmPrepareTable 단계에서 해당 table 에 대한 연산을
*    담당할 Table Manager 객체를 생성한다.
******************************************************************************/
#ifndef __O_DBM_TABLE_MANAGER_H__
#define __O_DBM_TABLE_MANAGER_H__

#include "dbmCommon.h"
#include "dbmLockManager.h"
#include "dbmLogManager.h"
#include "dbmIndexManagerInterface.h"
#include "dbmDeadLockManager.h"
#include "dbmQueueManager.h"

#define SLOT2EXTRA(X)   ( X + 1 )
#define EXTRA2SLOT(X)   ( X - 1 )

typedef struct dbmBindCols
{
    int             mBindCount;                             /* 현재 bind 되어 있는 colmumn 수 */
    char            mColName[DBM_MAX_COLUMN][MAX_NAME_LEN]; /* column name */
    int             mOffset[DBM_MAX_COLUMN];                /* 각 bind 컬럼의 offset */
    int             mDataSize[DBM_MAX_COLUMN];              /* 각 bind 컬럼의 user data size */
    int             mColSize[DBM_MAX_COLUMN];               /* 각 bind 컬럼의 column size */
    char            mData[DBM_MAX_RECORD_SIZE];             /* bind 된 모든 컬럼 data */
} dbmBindCols;


/**************************************************************
 * dbmTableManager class
**************************************************************/
class dbmTableManager
{
public:
    dbmTableManager( );
    ~dbmTableManager( );

    _VOID mInitTable ( char*              aInstName,
                       char*              aTableName,
                       int                aIndexCount,
                       dbmIndexObject*    aIndexObject,
                       dbmDicObject*      aDicObject,
                       dbmLogManager*     aLogMgr,
                       dbmLockManager*    aLockMgr,
                       dbmDeadLockManager* aDeadLockMgr);

    // 2014.09.21 (OKT): 유지보수성, 미사용함수 막기
//    _VOID mPrepareIndex ( char* aIndexName , dbmLogManager* aLogMgr , dbmLockManager* aLockMgr );

    _VOID mRemoveIdxMgr     ( char* aIndexName );

    _VOID mSetUseIndex      ( int aUseIndex )
    {
        mUseIndex = aUseIndex;
        return 0;
    }
    _VOID mSetSetIndexF ()  { mSetIndexF = 1; return 0; }
    _VOID mSetDicTableF ()  { mDicTableF = 1; return 0; }
    _VOID mSetEventQueue    ( char* aEventQueue ) ;
    int   mGetUseIndex  ()  { return mUseIndex; }
    int   mGetSetIndexF ()  { return mSetIndexF; }

    _VOID mSetTrigger ( dbmQueueManager* aTrigger )
    {
        mTrigger = aTrigger;
        return 0;
    }

    /*
     * 자신이 관리하는 table 정보 제공
     */
    dbmTableHeader* mGetTableHeader ( )
    {
        return mTableHeader;
    }
    char* mGetTableName ()  { return mTableName; }
    int   mGetTableID   ()  { return mTableID; }
    _VOID mSetTableID ( int aTableID )
    {
        mTableID = aTableID;
        return 0;
    }
    int mGetIndexCount  ()  { return mIndexCount; }
    int mGetTableType   ()  { return mTableHeader->mTableObj.mTableType; }
    int mGetRowSize     ()  { return mTableHeader->mTableObj.mRecordSize; }
    dbmIndexManager* mGetIndexMgrByObjID ( int aIndexID );
    dbmIndexManager* mGetIndexMgrByIdx ( int aIdx )
    {
        return mIndex[aIdx];
    }
    dbmSegmentManager* mGetSegMgr() { return mSegMgr; }

    /*
     * DML 처리
     */
    _VOID mSelect           ( int aTransID, void* aDataObject, int aDirtyFlag );
    _VOID mFetch            ( int aTransID, void* aDataObject ); /* 2014.06.23 -shw- module 추가 */
    _VOID mInsert           ( int               aTransID,
                              void*             aDataObject,
                              dbmTransHeader*   aTxHead,
                              long long*        aBackLogPos,
                              long long*        aBckImagePos );  /* 2014.08.04 -shw- aBackLogPos,aBckImagePos 추가 */
    _VOID mDelete           ( int               aTransID,
                              void*             aDataObject,
                              dbmTransHeader*   aTxHead      = NULL,
                              long long*        aBackLogPos  = NULL,
                              long long*        aBckImagePos = NULL);
    _VOID mUpdate           ( int               aTransID,
                              void*             aDataObject,
                              dbmTransHeader*   aTxHead      = NULL,
                              long long*        aBackLogPos  = NULL,
                              long long*        aBckImagePos = NULL );
    _VOID mSelectForUpdate  ( int               aTransID,
                              void*             aDataObject,
                              dbmTransHeader*   aTxHead      = NULL,
                              long long*        aBackLogPos  = NULL,
                              long long*        aBckImagePos = NULL );
    _VOID mSelectGT         ( int aTransID, void* aDataObject, int aDirtyFlag );
    _VOID mSelectLT         ( int aTransID, void* aDataObject, int aDirtyFlag );
    _VOID mFetchNextGT      ( int aTransID, void* aDataObject );
    _VOID mFetchNextLT      ( int aTransID, void* aDataObject );
    _VOID mFetchRange       ( int aTransID, void* aDataObject );
    _VOID mSelectMax        ( int aTransID, void* aDataObject );
    _VOID mSelectMin        ( int aTransID, void* aDataObject );
    _VOID mBindCol          ( int aTransID, void* aDataObject );
    _VOID mUpdateCol        ( int               aTransID,
                              void*             aDataObject,
                              dbmTransHeader*   aTxHead      = NULL,
                              long long*        aBackLogPos  = NULL,
                              long long*        aBckImagePos = NULL);
    _VOID mUpdateColGT      ( int               aTransID,
                              void*             aDataObject,
                              dbmTransHeader*   aTxHead      = NULL,
                              long long*        aBackLogPos  = NULL,
                              long long*        aBckImagePos = NULL);
    _VOID mUpdateColLT      ( int               aTransID,
                              void*             aDataObject,
                              dbmTransHeader*   aTxHead      = NULL,
                              long long*        aBackLogPos  = NULL,
                              long long*        aBckImagePos = NULL);
    _VOID mClearBind        ( int aTransID, void* aDataObject );

private:
    _VOID mDirectSelect     ( int aTransID, void* aDataObject );
    _VOID mDirectSelectGT   ( int aTransID, void* aDataObject );
    _VOID mDirectSelectLT   ( int aTransID, void* aDataObject );
    _VOID mDirectFetchNextGT( int aTransID, void* aDataObject );
    _VOID mDirectFetchNextLT( int aTransID, void* aDataObject );
    _VOID mDirectInsert     ( int aTransID, void* aDataObject );
    _VOID mDirectDelete     ( int aTransID, void* aDataObject );
    _VOID mDirectUpdate     ( int aTransID, void* aDataObject );
    _VOID mDirectSelectForUpdate ( int aTransID, void* aDataObject );
    _VOID mDirectUpdateCol  ( int aTransID, void* aDataObject );

    _VOID mMakeKey          ( dbmIndexObject*   aIndex,
                              char*             aUserData,
                              char*             aKey );
    _VOID mReadRecord       ( int               aTransID,
                              long long         aSlot,
                              char*             aRecord,
                              int*              aDataSize,
                              int*              aInserted,
                              int               aDirtyFlag,
                              dbmLogType*       aLogType = NULL );
    _VOID mFetchReadRecord  ( int               aTransID,
                              long long         aSlot,
                              char*             aRecord,
                              int*              aDataSize,
                              int*              aInserted,
                              dbmLogType*       aLogType = NULL );
    _VOID mRowLock          ( char*             aUndoName,
                              long long         aSlotID,
                              dbmRowHeader*     aRow,
                              char*             aBeforeImage,
                              int               aTransID,
                              int               aChkInsertF );
    _VOID mBuildDataObject  ( char* aData , int aDataLen , dbmDataObject* aOutput );

    _VOID mHandleTrigger    ( dbmEventOperation     aEventType,
                              int                   aTransID,
                              char*                 aData,
                              int                   aDataLen ) ;
    _VOID mCheckKey         ( dbmIndexHeader*       aUseIdxHead,
                              dbmIndexHeader*       aIdxHead,
                              char*                 aSrcData,
                              char*                 aUserData );
    _VOID mUpdateKey        ( int                   aTransID,
                              dbmTransHeader*       aTxHead,
                              long long*            aBackLogPos,
                              long long*            aBackImagePos,
                              long long             aSlotID,
                              char*                 aData,
                              dbmRowHeader*         aRow,
                              dbmLogHeader*         aLogHead,
                              int                   aIdxInd,
                              char*                 aUserData,
                              int*                  aBackupF );

public:
    char                mInstName[DBM_NAME_LEN];            // table 이 소속된 instance name
    char                mTableName[DBM_NAME_LEN];           // (성능) TxMgr.mFindTableInTx에서 바로 접근을 위해 public

    long long           mSelect_extrakey;
    long long           mSelect_curr_extrakey;
    char                mPkeyData[DBM_INDEX_KEY_MAX_SIZE];

private:
    int                 mTableID;
    dbmTableHeader*     mTableHeader;

    dbmSegmentManager*  mSegMgr;

    int                 mSetIndexF;
    int                 mUseIndex;
    int                 mIndexCount;    // 2014.09.21 (OKT): unsigned long 이어야할 이유가 없다. 사용을 섞어하고있음.
    dbmIndexManager*    mIndex[DBM_MAX_INDEX_PER_TABLE];

    dbmLogManager*      mLogMgr;
    dbmLockManager*     mLockMgr;
    dbmDeadLockManager* mDeadLockMgr;
    dbmQueueManager *   mTrigger;

    char*               mBindCols;      /* mInitTable 시에 dbmBindCols 만큼 malloc 하여 사용 */

    int                 mDicTableF;     /* dictionary table 일 경우 1 */

    long long           mFetchScn;      /* Fetch 처리 시 비교 처리 할 ROW SCN */
}; /* dbmTableManager */


#endif  /* __O_DBM_TABLE_MANAGER_H__ */
