/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    내부적으로 DBM에 공통적으로 적용할 항목들에 대한 DEFINE절
*******************************************************************************/
#ifndef __O_DBM_RID_H__
#define __O_DBM_RID_H__

#include "dbmCommon.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**************************************************************
 * PageID
**************************************************************/
//TODO 중복이름 구조체
#ifndef _TODO_DUP_PID_RID
#define _TODO_DUP_PID_RID
typedef struct dbmPID
{
    int             mSegNo;                             /* Segment 고유 번호 */
    int             mPageNo;                            /* Segment내 Page고유 번호 */
} dbmPID;


/**************************************************************
 * RowID
**************************************************************/
typedef struct dbmRID
{
    int             mSegNo;                             /* Segment 고유 번호 */
    int             mPageNo;                            /* Segment내 Page고유 번호 */
    int             mOffset;                            /* Page내의 slot 번호 */
} dbmRID;
#endif


#ifdef __cplusplus
};
#endif

#endif  /* __O_DBM_RID_H__ */

