/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    DBM Configration 설정을 읽고 찾아주는 Class 용도로만 쓴다.
*******************************************************************************/
#ifndef __O_DBM_CONFIG_MANAGER_H__
#define __O_DBM_CONFIG_MANAGER_H__

#include "dbmCommon.h"

/*******************************************************************************
 * DEFINE
*******************************************************************************/
#define DBM_CONFIG_FILE_PATH    "conf"                  // Config Directory
#define DBM_CONFIG_FILE_NAME    "dbm.cfg"               // Config File-Name
#define DBM_COMMON_SECTION      "COMMON"                // 공통 속성사항들의 Section-Name

/*******************************************************************************
 * DEFAULT VALUES
*******************************************************************************/
#define TABLE_INIT_ROWS_DEFS            1024
#define TABLE_EXTEND_ROWS_DEFS          (1 >> 17)       // 100000
#define TABLE_MAX_ROWS_DEFS             10000000        // TODO: 2014.11.21 -okt- 이렇게 되면, MAX까지 도달 못한다. 계산해서 바꾸던지. 룰을 한번 넘는 것은 허용하던지.

/*
 * UNDO_XX 기본값은 DICTIONARY 자체 UNDO에서도 사용됨. DIC쪽은 설정에 바뀌지 않는 소스 고정이므로
 * 기본값 변경시 고려요. ( 2014/07/16 )
 */
#define UNDO_SLOT_SIZE_DEFS             262144
#define UNDO_INIT_SIZE_DEFS             16
#define UNDO_EXTEND_SIZE_DEFS           16      // 2의 지수 필수.
#define UNDO_MAX_SIZE_DEFS              512

/*******************************************************************************
 * Env Variables
*******************************************************************************/

#ifdef __cplusplus

#include <map>
#include <string>
//using namespace std;

/*******************************************************************************
 * CLASS
*******************************************************************************/
class dbmConfig
{
private:
    std::map<std::string, int>*         mCommonPropList;    // 공통항목들
    std::map<std::string, int>*         mUserPropList;      // user에 해당하는 것들만 분리
    std::map<std::string, std::string>* mLoadPropList;      // 실제 읽어들인 props들 집합
    char    mConfigFile [4096];                 // Config File Name
    int     mFD;                                // File Descriptor
    int     sRC;                                // 에러코드
    void mGet( char* , char* );
public:
    dbmConfig( );
    ~dbmConfig( );

    int mInitialize ( );                        // 생성자에서 부를거임.
    int mValidHome  ( );                        // DBM_HOME 체크

    int mLoad       ( char* aSection );         // Load config하기. ( 특정 User Section )
    int mLoad       ( const char* aSection );   // Load config하기. ( Const )

    int mSearch     ( char* aSection            // 탐색 Section
                    , char* aProp               // 탐색 Property-Name
                    , char* aRetVal );          // 리턴 결과값

    int mSearch     ( const char* aSection      // 탐색 Section
                    , const char* aProp         // 탐색 Property-Name
                    , char* aRetVal );          // 리턴 결과값

    int mSearch     ( char* aSection            // 탐색 Section
                    , const char* aProp         // 탐색 Property-Name
                    , char* aRetVal );          // 리턴 결과값
    void mPrintAll();
};

#endif

#endif  /* __O_DBM_CONFIG_MANAGER_H__ */

