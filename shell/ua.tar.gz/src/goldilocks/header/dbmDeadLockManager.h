/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *    데드락의 검출을 위해서 사용하는 Manager
 ******************************************************************************/
#ifndef __O_DBM_DEADLOCK_MANAGER_H__
#define __O_DBM_DEADLOCK_MANAGER_H__

#include "dbmCommon.h"
#include "dbmLogManager.h"


/*
 * DeadLock 은 다음과 같은 조건이 모두 성립하여야 발생할 수 있다. 
 *  - Mutual Exclusive 
 *  - Circluar Wait ( Curcuit )  
 *  - Hold and Wait 
 *  - Non-preemtion 
 *
 * Goldilocks 에서 발생하는 발생시키는 Lock 은 위의 모든 조건을 성립하며, 
 * DeadLock 을 발생시킬 수 있다. 본 DeadLock Manager 는 위 조건 중 Circuit 조건을 
 * 검사하여 해당 DeadLock 이 Circuit 인지 아닌지에 대해서 판단하여 Circuit 이 발생한
 * 경우 뒤에 수행된 Transaction 을 Abort 시킴으로써 DeadLock 을 회피하도록 하는 모듈이다. 
 *
 *
 * Transaction Table 에는 내 TX와 내가 현재 기다리고 있는 TX (WaitForTx) 를 기록하게 되는데, 
 * 이를 통해 Lock Wait 을 들어가기 전에 내가 현재 기다리고 있는 TX 를 쭉 따라가서 내가 나오면 
 * 이 Lock 은 Circuit 으로 판단할 수 있다. 만약 Circuit 이면 DeadLock Detection 이 되었다고 
 * 판단하고 Transaction Manager 단으로 알려준다. 이후 롤백 작업은 Transaction Manager 가 수행한다. 
 *
 * 본 방식의 모듈의 단점은 그때 그때 순간의 TX 와 WaitForTxID 를 따라가기 때문에 매우 Busy 하게 
 * Lock 을 잡고 푸는 경우 False Alarm 이 발생할 수 있다. 이를 회피하기 위해서 LockRow 함수에서 
 * 열라 충분하게 검사를 수행하고 나서도 DeadLock 이 발생할 경우에만 에러를 리턴하게 되어있는데 
 * 이 횟수는 dbmTableManager::mRowLock 에 상수로 박혀있으며 현재는 131071 로 되어있다. 
 *
 * 이정도까지 검사해봤는데도 Circuit 으로 판별이 된다면 DeadLock 으로 판단한다. 
 *
 *
 */

/**************************************************************
 * dbmDeadLockManager class
**************************************************************/
class dbmDeadLockManager
{
public:
    dbmDeadLockManager ( dbmTransTable* aStartHeader , int aMyTransID , dbmLogManager* aLogManager );
    ~dbmDeadLockManager ( );

    _VOID mSetDeadLockMgr ( dbmTransTable* aStartHeader , int aMyTransID , dbmLogManager* aLogManager );
    _VOID mCheckDeadLock ( int aWaitObjectID , int aWaitSlotID , int aWaitForTx );
    _VOID mUnsetTransHeader ( );

private:

    dbmTransHeader* mGetTransHeader ( int aTxID )
    {
        return (dbmTransHeader*) dbmLogManager::mGetTxHead ( mTransStartAddr, aTxID );
    }

    _VOID mSetMyTransHeader ( int aWaitObjectID , int aWaitSlotID , int aWaitForTx );

    _VOID mCheckIsCircuit ( int* aIsCircuitF , int* aLastWaitTxID );

private:

    dbmTransTable*      mTransStartAddr;    /** 전체 Trans Header 를 가르키는 시작 포인터 */
    dbmTransHeader*     mMyTransHeader;     /** 나의 Trans Header 를 가르키는 포인터 */
    int                 mMyTransID ;        /** 내 Trans ID **/
    dbmLogManager*      mLogMgr;            /** 내 Log Manager */
};


#endif  /* __O_DBM_LOCK_MANAGER_H__ */
