/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
******************************************************************************/

/******************************************************************************
 * $Id$ *
 * Description :
******************************************************************************/
#include "dbmHeader.h"

#define SVC_LISTEN_PORT     20326
#define SVC_THR_MAX         4096

typedef struct PARAM
{
    int         mIdx;
    int         mSocket;
    int         mRecvStatus;
    char        mIPAddr[32];
} PARAM;


int     gPort = SVC_LISTEN_PORT;
PARAM   gThrParam [SVC_THR_MAX];

/******************************************************************************
 * static functions
******************************************************************************/
static void dbmMakeMsg ( dbmRemoteMsg* aMsg , dbmTransType aMsgType , int aMsgSize , char* aInstName , int aRC );
static int dbmProcCommand ( dbmHandle* aHandle , dbmRemoteMsg* aMsg );
static void* dbmReceiveThr ( void* );
static void* dbmRecvCheck ( void* );

static void printUsage ( )
{
    _PRT( "Usage: %s [-h] [-v] [-p listen port]\n", _dbm_argv[0] );
    //_PRT( "Usage: %s [OPTIONS]\n", _dbm_argv[0] );
    _PRT( "\n" );
    _PRT( "Options:\n" );
    _PRT( "  -h : This help message\n" );
    _PRT( "  -v : No daemon, Verbose mode\n" );
    _PRT( "  -p : Listen Port number \n" );

    _EXIT(-1);
}


/******************************************************************************
 * MAIN
******************************************************************************/
/*
 * TODO: 2014.10.22 -okt- 리슨너 추가할 속성 적어보기 ( 고민안하고 적었음 대부분 탈락일거임 )
 *  - MAX_LISTEN
 *  - MAX_CLIENT
 *  - MULTIPLEXING_MAX_THREAD_COUNT
 *  - DEDICATED_THREAD_MAX_COUNT
 *  - sStackSize
 *  - SVC_THR_MAX
 *  - select 제거해야함.
 */
_VOID main ( int argc , char** argv )
{
    pthread_attr_t  sAttr;
    pthread_t       tid[SVC_THR_MAX];
    pthread_t       sTid[1];
    int             sListenSock;
    int             sNewSock;
    char            sClientIP[32];
    long long       sStackSize = (1024 * 1024 * 2);
    fd_set          sFD;
    struct timeval  sTimeout;
    char*           pChar = NULL;
    int             sRC;
    int             i;

    _TRY
    {
        // _dbm_getArg 함수 사용을 위해 인자를 등록
        _dbm_setArg ( &argc, argv );

        /**************************************************
         * Input Parameter checking.
        **************************************************/
        pChar = _dbm_getArg ( "h" );
        if ( pChar != NULL )
        {
            printUsage();
        }

        pChar = _dbm_getArg ( "p:" );
        if ( pChar != NULL )
        {
            gPort = atoi ( pChar );
            if ( gPort <= 0 )
            {
                _PRT( "invalid port number.(%d)\n", gPort );
                printUsage();
            }
        }

        pChar = _dbm_getArg ( "v" );
        if ( pChar == NULL )
        {
            _rc = fork(); // 자식 프로세서로 Daemon 처리
            if ( _rc == 0 )
            {
                // 자식에게는 0이 리턴된다.
            }
            else
            {
                if ( _rc > 0 )
                {
                    // 부모에게는 자식의 PID가 리턴된다.
                    _EXIT( 0 ); // 정상종료, 0 리턴
                }
                else if ( _rc < 0 )
                {
                    _PRT( "fork fail, rc=%d, (err=%d)\n", _rc, errno );
                    _EXIT( _rc );
                }
            }
        }
        else
        {
            // 2014.12.14. -okt- '-v' verbose 모드일때, 화면 출력등을 재한할 수 있음. 나중에 추가
        }

        pthread_attr_init ( &sAttr );
        pthread_attr_setstacksize ( &sAttr, sStackSize );
        pthread_attr_setdetachstate ( &sAttr, PTHREAD_CREATE_DETACHED );

        signal ( SIGPIPE, SIG_IGN );

        for ( i = 0; i < SVC_THR_MAX; i++ )
        {
            gThrParam[i].mIdx = -1;
        }

        /****************************************************
         * Server Socket Open
         * Create main thread for checking network
         ****************************************************/
        //TODO: 2014.11.17 -okt- 버퍼크기를 32K(선재디폴트)로 변경.
        //sRC = cmnTcpServerOpen( &sListenSock, gPort, 1, 4096*2 );
        // Server는 Nonblock을 할 이유가 없다.
        sRC = cmnTcpServerOpen( &sListenSock, gPort, 0 ); //, 4096*2 );
        if (sRC)
        {
            DBM_ERR( "[Listener] server socket open failed. Port=[%d] rc=%d (err=%d,tid=%d)\n", gPort, sRC, errno, gettid_s() );
            _PRT( "[Listener] server socket open failed. Port=[%d] rc=%d (err=%d,tid=%d)\n", gPort, sRC, errno, gettid_s() );
            _EXIT( -1 );
        }

        _CALL( pthread_create ( &sTid[0], &sAttr, dbmRecvCheck, NULL ) );
        DBM_INFO( "[Listener] is Ready. Port=[%d]", gPort );
        _PRT( "[Listener] is Ready. Port=[%d]\n", gPort );


        /****************************************************
         * Connect 해오는 Client 의 접속을 Accept
         ****************************************************/
        while (1)
        {
            sTimeout.tv_sec  = 1;
            sTimeout.tv_usec = 0;

            FD_ZERO( &sFD );
            FD_SET( sListenSock, &sFD );

            memset_s ( sClientIP, 0x00, sizeof( sClientIP ) );

            /*---------------------------------------------------------
             * 등록한 socket 에 대해 event 대기
             *-------------------------------------------------------*/
            // accept는 이런거 안해도 되는데 왜 하는지 몰겠다....
            if ( ( sRC = select ( FD_SETSIZE, &sFD, NULL, NULL, &sTimeout ) ) <= 0 )
            {
                cmnUSleep ( 40 );
                continue;
            }

            // 원래코드대로라면 non-block을 셋팅해야 하는데 안되있음.
            // 수정함
            sRC = cmnTcpAcceptGetCliIP ( sListenSock, &sNewSock, 1, sClientIP );
            if (sRC)
            {
                DBM_ERR("[Listener] Socket accept failed. [%s] client[%d] (err=%d,tid=%d)",
                            sClientIP, sRC, errno, gettid_s() );
                _EXIT(-1);
            }

            DBM_DBG( "[Listener] Connection Request From [%s]", sClientIP);

            if ( FD_ISSET( sListenSock, &sFD ) )
            {
                /****************************************************
                 * TODO
                 * 빈자리를 찾아서 할당한다.
                 * -> 접속 성능이 잘 안나오겠지만 일단 이게 제일 쉽다.
                 * -> 개선 필요.
                 ****************************************************/
                for ( i = 0; i < SVC_THR_MAX; i++ )
                {
                    if ( gThrParam[i].mIdx == -1 )
                    {
                        break;
                    }
                }

                if ( i >= SVC_THR_MAX )
                {
                    DBM_WARN( "[Listener] Connection Full... [%d]", i );

                    cmnTcpClose ( sNewSock );
                    continue;
                }

                /****************************************************
                 * New service thread 생성
                 ****************************************************/
                gThrParam[i].mIdx         = i;
                gThrParam[i].mSocket      = sNewSock;
                gThrParam[i].mRecvStatus  = 0;
                sprintf(gThrParam [i].mIPAddr, "%s", sClientIP);

                sRC = pthread_create ( &sTid[i], &sAttr, dbmReceiveThr, &gThrParam[i] );
                if ( sRC != 0 )
                {
                    DBM_WARN( "[Listener] Service Thread create fail. [%d] (err=%d,tid=%d)", i, errno, gettid_s ( ) );

                    cmnTcpClose ( sNewSock );

                    gThrParam[i].mIdx         = -1;
                    gThrParam[i].mSocket      = -1;
                    gThrParam[i].mRecvStatus  = -1;
                    memset_s ( gThrParam[i].mIPAddr, 0x00, sizeof( gThrParam[i].mIPAddr ) );
                }
                else
                {
                    DBM_DBG( "[Listener:%d] Service Thread create. [%d]", i, sNewSock );
                }

                while ( gThrParam[i].mRecvStatus == 0 )
                {
                    cmnUSleep( 1 ); //TODO: 2014.10.22 -okt- 숫자가 맞나?
                }
            }
        }


        /****************************************************
         * Main Thread는 그냥 쉰다.
         ****************************************************/
        while (1)
        {
            //TODO: 2014.10.22 -okt- 감지할필요가 전혀없는가?
            sleep( 1000 );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
} /* main */


/******************************************************************************
 * static functions
******************************************************************************/


//TODO: 2014.10.22 -okt- aRC 인자 없앨수 있을듯.
void dbmMakeMsg ( dbmRemoteMsg* aMsg , dbmTransType aMsgType , int aMsgSize , char* aInstName , int aRC )
{
    aMsg->mMsgSize = aMsgSize;
    aMsg->mMsgType = aMsgType;
    strcpy_s( aMsg->mInstName, aInstName );
    *(int*)&aMsg->mBody = aRC;
}


/******************************************************************************
 * Name : receiverRealApply
******************************************************************************/
int dbmProcCommand ( dbmHandle* aHandle , dbmRemoteMsg* aMsg )
{
    dbmMsgBody* sMsgBody;
    char        sUseIndexName[DBM_NAME_LEN];
    int         sRC;

    sMsgBody = &aMsg->mBody.mMsgBody;

    /****************************************************
     * DDL 처리
     ****************************************************/
    if ( aMsg->mMsgType == DBM_NOT_DEFINED )
    {
        DBM_INFO( "[Listener] CreateDDL Request. [%s]",
                    sMsgBody->mUserData );

        return dbmExecuteDDL( aHandle, sMsgBody->mUserData );
    }

    switch( aMsg->mMsgType )
    {
        case DBM_SELECT:
            return dbmSelectRow ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData );
            break;

        case DBM_SELECT_ROWSIZE:
            return dbmGetRowSize ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData );
            break;

        case DBM_SELECT_GT:
            return dbmSelectRowGT ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, sMsgBody->mEQCnt );
            break;

        case DBM_SELECT_LT:
            return dbmSelectRowLT ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, sMsgBody->mEQCnt );
            break;

        case DBM_FETCH_NEXT_LT:
            return dbmFetchNextLT ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, sMsgBody->mEQCnt );
            break;

        case DBM_FETCH_NEXT_GT:
            return dbmFetchNextGT ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, sMsgBody->mEQCnt );
            break;

        case DBM_FETCH:
            return dbmFetchRow ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData );
            break;

        case DBM_SET_INDEX:
            return dbmSetIndex ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData );
            break;

        case DBM_GET_INDEX:
            return dbmGetIndex ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData );
            break;

        case DBM_INSERT:
            return dbmInsertRow ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, sMsgBody->mDataSize );
            break;

        case DBM_DELETE:
            return dbmDeleteRow ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData );
            break;

        case DBM_DELETE_RANGE_GT:
            return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, NULL, DBM_DELETE_RANGE_GT, NULL );
            break;

        case DBM_DELETE_RANGE_LT:
            return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, NULL, DBM_DELETE_RANGE_LT, NULL );
            break;

        case DBM_DELETE_RANGE_BT:
            return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, sMsgBody->mUserData2, DBM_DELETE_RANGE_BT, NULL );
            break;

        case DBM_UPDATE:
            return dbmUpdateRow ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData );
            break;

        case DBM_UPDATE_RANGE_GT:
            return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, NULL, DBM_UPDATE_RANGE_GT, NULL );
            break;

        case DBM_UPDATE_RANGE_LT:
            return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, NULL, DBM_UPDATE_RANGE_LT, NULL );
            break;

        case DBM_UPDATE_RANGE_BT:
            return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, sMsgBody->mUserData2, DBM_UPDATE_RANGE_BT, NULL );
            break;

        case DBM_SELECT_FOR_UPDATE:
            return dbmSelectForUpdateRow ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData );
            break;

        case DBM_ENQUE:
            return dbmEnqueue ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, sMsgBody->mDataSize );
            break;

        case DBM_DEQUE:
            return dbmDequeue ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, sMsgBody->mTimeout );
            break;

        case DBM_BIND_COL:
            return dbmColBind ( aHandle, sMsgBody->mTableName, sMsgBody->mColName, sMsgBody->mUserData, sMsgBody->mDataSize );
            break;

        case DBM_UPDATE_COL:
            return dbmUpdateRowByCols ( aHandle, sMsgBody->mTableName );
            break;

        case DBM_CLEAR_BIND:
            return dbmClearBind ( aHandle );
            break;

        case DBM_SELECT_COUNT:
            if( BITAND(sMsgBody->mUserDataIsNULL, (1 << 0)) )
            {
                return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, NULL, DBM_SELECT_COUNT, &sMsgBody->mCount );
            }
            else
            {
                return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, NULL, NULL, DBM_SELECT_COUNT, &sMsgBody->mCount );
            }
            break;

        case DBM_SELECT_COUNT_LT:
            if( BITAND(sMsgBody->mUserDataIsNULL, (1 << 0)) )
            {
                return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, NULL, DBM_SELECT_COUNT_LT, &sMsgBody->mCount );
            }
            else
            {
                return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, NULL, NULL, DBM_SELECT_COUNT_LT, &sMsgBody->mCount );
            }
            break;

        case DBM_SELECT_COUNT_GT:
            if( BITAND(sMsgBody->mUserDataIsNULL, (1 << 0)) )
            {
                return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, NULL, DBM_SELECT_COUNT_GT, &sMsgBody->mCount );
            }
            else
            {
                return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, NULL, NULL, DBM_SELECT_COUNT_GT, &sMsgBody->mCount );
            }
            break;

        case DBM_SELECT_COUNT_BT:
            if( BITAND(sMsgBody->mUserDataIsNULL, (1 << 0)) )
            {
                if( BITAND(sMsgBody->mUserDataIsNULL, (1 << 1)) )
                {
                    return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, sMsgBody->mUserData2, DBM_SELECT_COUNT_BT, &sMsgBody->mCount );
                }
                else
                {
                    return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData, NULL, DBM_SELECT_COUNT_BT, &sMsgBody->mCount );
                }
            }
            else
            {
                if( BITAND(sMsgBody->mUserDataIsNULL, (1 << 1)) )
                {
                    return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, NULL, sMsgBody->mUserData2, DBM_SELECT_COUNT_BT, &sMsgBody->mCount );
                }
                else
                {
                    return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, NULL, NULL, DBM_SELECT_COUNT_BT, &sMsgBody->mCount );
                }
            }
            break;

        case DBM_SEQ_NEXTVAL:
            return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, NULL , NULL, DBM_SEQ_NEXTVAL , NULL, &sMsgBody->mSeq );
            break;

        case DBM_SEQ_CURRVAL:
            return dbmExecInternalLib ( aHandle, sMsgBody->mTableName, NULL , NULL, DBM_SEQ_CURRVAL , NULL, &sMsgBody->mSeq );
            break;

        case DBM_COMMIT:
            return dbmCommit ( aHandle );
            break;

        case DBM_ROLLBACK:
            return dbmRollback ( aHandle );
            break;

        case DBM_TRUNCATE:
            DBM_INFO( "[Listener] Truncate Table[%s]", sMsgBody->mTableName );
            return dbmTruncate ( aHandle, sMsgBody->mTableName );
            break;

        case DBM_DROP_TABLE:
            DBM_INFO( "[Listener] Drop Table Request. [%s]", sMsgBody->mTableName );
            return dbmDropTable ( aHandle, sMsgBody->mTableName );
            break;

        case DBM_DROP_QUEUE:
            DBM_INFO( "[Listener] Drop Queue Request. [%s]", sMsgBody->mTableName );
            return dbmDropQueue ( aHandle, sMsgBody->mTableName );
            break;

        case DBM_DROP_INDEX:
            DBM_INFO( "[Listener] Drop Index Request. [%s]", sMsgBody->mTableName );
            return dbmDropIndex ( aHandle, sMsgBody->mTableName );
            break;

        case DBM_PREPARE_TABLE:
            DBM_INFO( "[Listener] Prepare. Table[%s]", sMsgBody->mTableName );

            sRC = dbmPrepareTable ( aHandle, sMsgBody->mTableName );
            if ( sRC == RC_SUCCESS )
            {
                /****************************************************
                 * prepare 되면 Record Size 를 알아내어 Remote 에 전달한다.
                 ****************************************************/
                sRC = dbmGetRowSize ( aHandle, sMsgBody->mTableName, sMsgBody->mUserData );
            }

            return sRC;
            break;

        case DBM_DEQUE_MORE :
        case DBM_DEQUE_ARRAY :
        case DBM_FETCH_RANGE :

        case DBM_SET_OPTION :
            return dbmSetHandleOption ( aHandle, sMsgBody->mOption , sMsgBody->mOptionVal ) ;

        case DBM_GET_OPTION :
            return dbmGetHandleOption ( aHandle, sMsgBody->mOption , &sMsgBody->mOptionVal ) ;

        default :
            return ERR_DBM_INVALID_OPERATION;
            break;
    }

    return RC_SUCCESS;
}


/******************************************************************************
 * Name : dbmRecvCheck
 *
 * Description
 *   Client 와의 Network Failure 를 감지하기 위해서 각 Client Server 의
 *   22 번 Port 에 connect 를 시도해본다.
 *   (일단 Goldi Ver 1 의 것을 그대로)
 *
******************************************************************************/
void* dbmRecvCheck ( void* param )
{
    char    sOldAddr[32];
    int     sSocket;
    int     sRC;
    int     i;

    sleep(1);

    while (1)
    {
#if 0
        /*
         * TODO
         * 이거 왜 자꾸 detect network failure 가 발생하는지 좀 봐야함.
         */
        memset_s ( sOldAddr, 0x00, sizeof( sOldAddr ) );

        for ( i = 0; i < SVC_THR_MAX; i++ )
        {
            if ( gThrParam[i].mIdx == -1 || gThrParam[i].mRecvStatus == 0 )
            {
                continue;
            }

            if ( strncmp ( gThrParam[i].mIPAddr, sOldAddr, strlen ( gThrParam[i].mIPAddr ) ) != 0 )
            {
                sRC = cmnTcpConnect ( &sSocket, gThrParam[i].mIPAddr, 22, 1, -1, 2 );
                if ( sRC )
                {
                    gThrParam[i].mRecvStatus = 0;
                    DBM_ERR( "[Listener] detect network failure. [%s]", gThrParam[i].mIPAddr );
                }
                else
                {
                    _PRT( "[Listener] network ok. [%s]\n", gThrParam[i].mIPAddr );
                    cmnTcpClose ( sSocket );
                }
            }

            sprintf ( sOldAddr, "%s", gThrParam[i].mIPAddr );
        }
#endif

        sleep(1);
    }

    return NULL;
} /* dbmRecvCheck */


/******************************************************************************
 * Name : dbmReceiveThr
******************************************************************************/
void* dbmReceiveThr(void* param)
{
    int             sRC;
    int             sIdx;
    int             sSocket;
    int             sRealSize;
    dbmRemoteMsg    sMsg;
    dbmHandle       sHandle;


    /****************************************************
     * Get Socket Information
     ****************************************************/
    sIdx    = (int)(((PARAM*)param)->mIdx);
    sSocket = (int)(((PARAM*)param)->mSocket);


    /****************************************************
     * 첫번째 수신하는 메시지는 무조건 Init Handle 이어야 한다.
     ****************************************************/
    memset_s ( &sMsg, 0x00, sizeof( sMsg ) );

    sRC = cmnTcpRecv ( sSocket, (char*) &sMsg, 0, (int*) &sRealSize );
    if ( sRC != RC_SUCCESS )
    {
        DBM_ERR( "[Listener:%d] Init Handle TcpRecv Fail. [%d] (err=%d,tid=%d)", sIdx, sRC, errno, gettid_s ( ) );
        goto thread_end2;
    }

    if ( ( sMsg.mMsgType != DBM_INIT_HANDLE ) || ( sMsg.mInstName[0] == 0x00 ) )
    {
        DBM_ERR( "[Listener:%d] Invalid First Msg. [%d]", sIdx, sMsg.mMsgType );
        goto thread_end2;
    }

    DBM_INFO( "[Listener:%d] Recv InitHandle Request OK", sIdx );


    /****************************************************
     * dbmInitHandle
     ****************************************************/
    // 2014.10.20 -okt- ENV_DBM_TEST_REMOTE_PORT 설정되었더라도, 리스너는 무조건 DA 접속이다.
    if ( getenv( ENV_DBM_TEST_REMOTE_PORT ) != NULL )
    {
        unsetenv( ENV_DBM_TEST_REMOTE_PORT );
    }

    sRC = dbmInitHandle( &sHandle, sMsg.mInstName );

    dbmMakeMsg( &sMsg,
                DBM_INIT_HANDLE,
                sizeof(dbmRemoteMsg) - sizeof(dbmMsgBody) + sizeof(dbmInitMsgBody),
                sMsg.mInstName, sRC );

    if ( sRC != RC_SUCCESS )
    {
        DBM_WARN( "[Listener:%d] dbmInitHandle failed [Inst=%s, %d]",
                    sIdx, sMsg.mInstName, sRC);

        /****************************************************
         * 실패 응답 전송
         ****************************************************/
        sRC = cmnTcpSend( sSocket, (char*)&sMsg, sMsg.mMsgSize, (int*)&sRealSize );
        if (sRC != RC_SUCCESS)
        {
            DBM_WARN( "[Listener:%d] Init Handle Response failed [Inst=%s, %d] (err=%d,tid=%d)",
                        sIdx, sMsg.mInstName, sRC, errno, gettid_s() );
        }

        goto thread_end;
    }
    else
    {
        /****************************************************
         * TODO
         * Undo 쪽에 Remote Connection 이라는 것을 표시해야 하는데
         * 마땅한 방법이 없다.
         * 현재는 Remote 로 붙어도 모두 Local Connection 으로 나올 것이다.
         ****************************************************/

        /****************************************************
         * 성공 응답 전송
         ****************************************************/
        sRC = cmnTcpSend( sSocket, (char*)&sMsg, sMsg.mMsgSize, (int*)&sRealSize );
        if (sRC != RC_SUCCESS)
        {
            DBM_WARN( "[Listener:%d] Init Handle Response failed [Inst=%s, %d] (err=%d,tid=%d)",
                        sIdx, sMsg.mInstName, sRC, errno, gettid_s() );

            goto thread_end;
        }
    }

    DBM_DBG( "[Listener:%d] dbmInitHandle OK [Inst=%s]", sIdx, sMsg.mInstName );


    /****************************************
     * Service Thread Job
    ****************************************/
    gThrParam[sIdx].mRecvStatus = 1;

    while (gThrParam[sIdx].mRecvStatus)
    {
        memset_s( &sMsg, 0x00, sizeof(sMsg));


        /****************************************************
         * blocking 모드로 다음 메시지를 기다림.
         ****************************************************/
        sRC = cmnTcpRecv ( sSocket, (char*) &sMsg, 0, (int*) &sRealSize );
        if ( sRC != RC_SUCCESS )
        {
            DBM_INFO( "[Listener:%d] socket(%d) recv fail. Disconnect. rc=%d (err=%d,tid=%d)",
                        sIdx, sSocket, sRC, errno, gettid_s() );
            goto thread_end;
        }


        /***************************************************
         * 수신한 메시지 처리
        ***************************************************/
        sRC = dbmProcCommand( &sHandle, &sMsg );


        /***************************************************
         * 전송이나 응답 자체의 에러일 경우는 Network Error 의
         * 차원이므로 thread 를 정지시키지만, SQL 이나
         * API 의 Error 에 대해서는 Client 쪽으로 그대로
         * 전달해주고 사용자의 후속 명령을 통해 처리되도록 한다.
        ***************************************************/
        *(int*)&sMsg.mBody = sRC;

        sRC = cmnTcpSend( sSocket, (char*)&sMsg, sMsg.mMsgSize, (int*)&sRealSize );
        if (sRC != RC_SUCCESS)
        {
            DBM_WARN( "[Listener:%d] Send Response failed [Inst=%s,Msg=%d,%d] (err=%d,tid=%d)",
                        sIdx, sMsg.mInstName, sRC, errno, gettid_s() );

            goto thread_end;
        }
    } /* While */

thread_end:
    dbmRollback ( &sHandle );
    dbmFreeHandle ( &sHandle );

thread_end2:
    cmnTcpClose ( sSocket );

    /********************************************
     * parameter 가용하게 설정.
    ********************************************/
    gThrParam[sIdx].mIdx    = -1;
    gThrParam[sIdx].mSocket = -1;
    gThrParam[sIdx].mRecvStatus = -1;
    memset_s ( gThrParam[sIdx].mIPAddr, 0x00, sizeof( gThrParam[sIdx].mIPAddr ) );

    // 요기까지 오면 (원인이야 어찌되었던) 쓰레드 정리면에선 정상종료한거다.
    DBM_INFO( "[Listener] Service Thread[%d] stop. (err=%d,tid=%d)", sIdx, errno, gettid_s() );

    return NULL;
} /* dbmReceiveThr */



