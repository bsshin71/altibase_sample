#!/bin/sh

#################################################################################
# @file     test.env.sh
#
# @history
#
#################################################################################


#################################################################################
# default global variables
#################################################################################

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$GDSRC/test/lib
export _DBM_TEST_LIBS=libtest_api.so
export _DBM_TEST_LIBS=libtest_etc.so:$_DBM_TEST_LIBS
export _DBM_TEST_LIBS=libtest_seg.so:$_DBM_TEST_LIBS

test_run=0


#################################################################################
# functions
#################################################################################

##########################################
# test_and_run
##########################################
declare run=""
test_and_run ()
{
    if [ "x"$test_run == "x1" ]
    then
        echo "${run}"
    else
        if [ "x"$1 == "x" ]
        then
            echo "${run}"; ${run}
        else
            echo "${run}"; ${run} &
        fi
    fi
}

##########################################
# echo_sleep 초단위시간
##########################################
echo_sleep ()
{
    echo "sleep "$1

    if [ "x"$test_run != "x1" ]
    then
        sleep $1
    fi
}


##########################################
# DDL
##########################################
f_create_undo ()
{
    test "x"$1 == "x" && exit 1

# !rmipc
# initdb;
    echo "
!echo ">> create undo '$UNDO'"
set instance \$sys_dic_inst ;
drop undo ${1};
create undo ${1};
" > _t.sql

    run="metaManager --silent -f _t.sql"
    test_and_run
}

f_drop_undo ()
{
    test "x"$1 == "x" && exit 1

    echo "
!echo ">> drop undo '$UNDO'"
set instance \$sys_dic_inst ;
drop undo ${1};
" > _t.sql

    run="metaManager --silent -f _t.sql"
    test_and_run
}


#################################################################################
# MAIN
#################################################################################

# f_create_undo


#################################################################################
# FINALLY
#################################################################################
#echo ""
#echo "> _DBM_TEST_LIBS=$_DBM_TEST_LIBS"
