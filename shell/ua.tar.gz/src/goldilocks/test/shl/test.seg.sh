#!/bin/sh

source ../test.env.sh

#UNDO=`basename $0 |sed -e 's/\..*$//g'`
UNDO=$1

rm -f /dev/shm/$DBM_SHM_PREFIX/${UNDO}*
rm -f /dev/shm/$DBM_SHM_PREFIX/*T[1-9]*

exit 0
