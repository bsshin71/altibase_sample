#!/bin/sh

source ../test.env.sh

#UNDO=`basename $0 |sed -e 's/\..*$//g'`
UNDO=$1

if [ "x"$2 == "x" ]
then
    f_create_undo $UNDO
else
    f_drop_undo $UNDO
fi

rm -f /dev/shm/$DBM_SHM_PREFIX/*T[1-9]*

exit 0
