#include "dbmGtestHeader.h"

#ifdef _GTEST

#define _aSlotSize          256
#define _aInitSlotCount     256
#define _aExtendSlotCount   256
#define _aMaxSlotCount      1024
#define _aUserHeaderSize    512

#define INST_NAME           "TINST"
#define OBJECT_NAME         "TCSEG001"
#define NUM_OF_THREADS2     4

#define NUM_OF_THREADS      16
//#define NUM_OF_THREADS      2

// 2014.11.21 -okt- dbmSegmentManager에서 extend 는 2의 지수만 가능.
//#define TEST_COUNT          100000
#define TEST_COUNT          (1 >> 17)

static void* thread_test ( void* ) ;
static void* thread_allocFree ( void* ) ;
static void* thread_truncate ( void* ) ;
static void* thread_free ( void* ) ;

long long*   gSlotValue;


////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TCSEG001 : public testing::Test
{
public:
    static void SetUpTestCase ()
    {
        ASSERT_EQ( system( "../shl/test.seg.sh TCSEG001 > /dev/null 2>&1" ), 0 );
    }

    static void TearDownTestCase()
    {
        _T_ENDLOG;
    }

    virtual void SetUp()
    {
        _TRY
        {
//          _CALL( dbmSegmentManager::Create ( OBJECT_NAME, _aSlotSize, _aInitSlotCount, _aExtendSlotCount, _aMaxSlotCount, _aUserHeaderSize, &mSegmentManager ) );
            _CALL( dbmSegmentManager::Create ( INST_NAME,
                                               OBJECT_NAME,
                                               _aSlotSize,
                                               TEST_COUNT,
                                               TEST_COUNT,
                                               TEST_COUNT * NUM_OF_THREADS,
                                               _aUserHeaderSize,
                                               &mSegmentManager ) );

            /************************************************************
             * 전역 변수를 초기화
             ***********************************************************/
            gSlotValue = (long long*) malloc ( sizeof(long long) * TEST_COUNT * NUM_OF_THREADS );
            for ( int i = 0; i < NUM_OF_THREADS * TEST_COUNT; i++ )
            {
                gSlotValue[i] = -1;
            }
        }
        _CATCH
        {
            _CATCH_ERR;
        }
        _FINALLY
        _ENDVOID
    }

    virtual void TearDown()
    {
        _TRY
        {
            _CALL( dbmSegmentManager::Drop ( INST_NAME, OBJECT_NAME ) );

            delete mSegmentManager;
            mSegmentManager = NULL;
        }
        _CATCH
        {
            _CATCH_ERR;
        }
        _FINALLY
        {
            _T_SUB_ENDLOG;
        }
        _ENDVOID
    }

    static dbmSegmentManager* mSegmentManager;
};

////////////////////////////////////////////////////////////////////////////////
// class static 변수
////////////////////////////////////////////////////////////////////////////////
dbmSegmentManager* TCSEG001::mSegmentManager = NULL;


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

/***************************************************************
 * N 개의 Thread 를 만들어서 각 N 개의 Thread 를 수행한 결과가
 * 전체 합이 맞는지 체크한다.
 ******************************************************************/
TEST_F ( TCSEG001, ThreadConcurrency )
{
    dbmSpaceStat    sStat;
    pthread_t       tid[NUM_OF_THREADS] ;

    _TRY
    {
        for ( int i = 0; i < NUM_OF_THREADS; i++ )
        {
            _CALL( pthread_create ( &tid[i], NULL, thread_test, NULL ) );
        }

        for ( int i = 0; i < NUM_OF_THREADS; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }

        /**** 모든 Thread 들이 종료되었기 때문에 값들이 제대로 들어가있는지에 대해서 검사 */
        for ( int i = 0; i < NUM_OF_THREADS * NUM_OF_THREADS; i++ )
        {
            ASSERT_EQ ( gSlotValue[i] , i );
        }

        /**** 전체 Slot 갯수를 검사 ***/
        dbmSegmentManager::GetSpaceStat ( INST_NAME, (char*) OBJECT_NAME, &sStat );
        EXPECT_EQ ( sStat.mAllocSlot, NUM_OF_THREADS * TEST_COUNT );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}


/***********************************************************************e
 * N 개의 Thread 를 만들어서  Alloc 과 Free 를 반복
 ************************************************************************/
TEST_F ( TCSEG001, ThreadAllocFree )
{
    pthread_t   tid[NUM_OF_THREADS] ;

    _TRY
    {
        for ( int i = 0 ; i < NUM_OF_THREADS ; i ++)
        {
            _CALL( pthread_create ( &tid[i] ,  NULL,  thread_allocFree, NULL ) );
            usleep ( i * 100 ) ;
        }

        for ( int i = 0 ; i < NUM_OF_THREADS ; i ++ )
        {
            _CALL( pthread_join ( tid[i] , NULL) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}


/***********************************************************************e
 * TEST_COUNT * THREAD_COUNT 의 갯수를 넣어놓고, Concurrency 하게
 * Free 하는 과정을 테스트함.
 ************************************************************************/
TEST_F ( TCSEG001, Multithread_free )
{
    pthread_t   tid[NUM_OF_THREADS] ;
    long long sSlotNo;
    int     sThreadNo[NUM_OF_THREADS];

    _TRY
    {
        /*************************************************
         * 먼저 TEST_COUNT * THREAD_COUNT 만큼 만들어넣는다.
         ************************************************/
        for ( int i = 0; i < TEST_COUNT * NUM_OF_THREADS; i++ )
        {
            _CALL( mSegmentManager->AllocSlot ( &gSlotValue[i] ) );
            ASSERT_EQ ( gSlotValue[i] , i );
        }

        for ( int i = 0; i < NUM_OF_THREADS; i++ )
        {
            sThreadNo[i] = i;
            _CALL( pthread_create ( &tid[i], NULL, thread_free, &sThreadNo[i] ) );
            usleep ( i * 100 );
        }

        for ( int i = 0; i < NUM_OF_THREADS; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}


/***********************************************************************e
 * N 개의 Thread 를 만들어서  Truncate
 ************************************************************************/
TEST_F ( TCSEG001, ThreadTruncate )
{
    int sRC;

    pthread_t   tid[NUM_OF_THREADS] ;

    _TRY
    {
        for ( int i = 0; i < NUM_OF_THREADS2; i++ )
        {
            _CALL( pthread_create ( &tid[i], NULL, thread_truncate, NULL ) );
            usleep ( i * 100 );
        }

        for ( int i = 0; i < NUM_OF_THREADS2; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}


////////////////////////////////////////////////////////////////////////////////
// static functions
////////////////////////////////////////////////////////////////////////////////

void* thread_truncate  ( void* arg )
{
    int     sRC ;
    dbmSegmentManager* sObj ;

    _TRY
    {
        _CALL( dbmSegmentManager::Attach ( INST_NAME, (char*) OBJECT_NAME, &sObj ) );

        for ( int i = 0; i < 50; i++ )
        {
            _CALL( sObj->Extend ( ) );
            //DBM_INFO ( "@@@@(1) i=%d, rc=%d (err=%d,lwp=%d)\n", i, sRC, errno, gettid_s() );
            _CALL( sObj->Truncate ( ) );
            //DBM_INFO ( "@@@@(2) i=%d, rc=%d (err=%d,lwp=%d)\n", i, sRC, errno, gettid_s() );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    return  NULL;
}

void* thread_allocFree ( void* arg )
{
    dbmSegmentManager* sObj ;
    long long sSlotNo;
    long long sSlotArray [TEST_COUNT];

    _TRY
    {
        _CALL( dbmSegmentManager::Attach ( INST_NAME, (char*) OBJECT_NAME , &sObj ) );

        for ( int i = 0; i < TEST_COUNT; i++ )
        {
            _CALL( sObj->AllocSlot ( &sSlotNo ) );
            EXPECT_LT ( sSlotNo , NUM_OF_THREADS * TEST_COUNT );
            sSlotArray[i] = sSlotNo;
        }

        for ( int i = 0; i < TEST_COUNT; i++ )
        {
            _CALL( sObj->FreeSlot ( sSlotArray[i] ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    return NULL ;
}

void* thread_free ( void* arg )
{
    long long sSlotNo;
    long long sSlotArray[TEST_COUNT];
    int     sMyThreadNo = *(int*) arg;
    dbmSegmentManager* sObj;

    _TRY
    {
        _CALL( dbmSegmentManager::Attach ( INST_NAME, (char*) OBJECT_NAME, &sObj ) );

        for ( int i = TEST_COUNT * sMyThreadNo; i < TEST_COUNT * ( sMyThreadNo + 1 ); i++ )
        {
            //printf ("MyThread : %d Free Slot : %d \n", sMyThreadNo , (sMyThreadNo * TEST_COUNT) + i );
            _CALL( sObj->FreeSlot ( gSlotValue[i] ) );
            EXPECT_EQ( i, gSlotValue[i] );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    return NULL ;
}

void* thread_test ( void* arg )
{
    long long sSlotNo;
    dbmSegmentManager* sObj;

    _TRY
    {
        _CALL( dbmSegmentManager::Attach ( INST_NAME, (char*) OBJECT_NAME, &sObj ) );

        for ( int i = 0; i < TEST_COUNT; i++ )
        {

            _CALL( sObj->AllocSlot ( &sSlotNo ) );
            EXPECT_LT ( sSlotNo , NUM_OF_THREADS * TEST_COUNT );
            EXPECT_EQ ( gSlotValue [sSlotNo] , -1 );                // Which is: 210959
            gSlotValue[sSlotNo] = sSlotNo;
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    return NULL;
}

#endif
