#include "dbmGtestHeader.h"

#ifdef _GTEST


typedef struct TABLE
{
    long long  mKey;
    char     mVal[20];
} TABLE;

#define OBJECT_NAME         "TFSHM001"
#define NUM_OF_THREADS      4
#define TEST_COUNT          ( 1000 * 100 )

static void* thread_allocFree ( void* ) ;


////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TFSHM001 : public testing::Test
{
public:
	static void SetUpTestCase ()
	{
	}

	static void TearDownTestCase()
	{
	    _T_ENDLOG;
	}

	virtual void SetUp()
	{
	}

	virtual void TearDown()
	{
        _T_SUB_ENDLOG;
	}
};

////////////////////////////////////////////////////////////////////////////////
// static 변수
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

TEST_F ( TFSHM001 , cmnShmCreate_s )
{
    void*   sAddr;
    int     i;

    _TRY
    {
        for ( i = 0; i < 1000; i++ )
        {
            _CALL( cmnShmCreate_s ( OBJECT_NAME, 1024 * 1024 * 10, NULL ) );
            _CALL( cmnShmDrop_s ( OBJECT_NAME ) );
        }

        for ( i = 0; i < 1000; i++ )
        {
            _CALL( cmnShmCreate_s ( OBJECT_NAME, 1024 * 1024 * 10, &sAddr ) );
            _CALL( cmnShmDrop_s ( OBJECT_NAME ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

TEST_F ( TFSHM001 , cmnShmAttach_s )
{
    void*   sAddr;
    void*   sAddr2;
    int     sSize = 1024 * 1024 * 10;
    int     i;

    _TRY
    {
        _rc = cmnShmAttach_s ( OBJECT_NAME, sSize, &sAddr );
        EXPECT_EQ( _rc, ERR_CMN_SHM_OPEN );

        _CALL( cmnShmCreate_s ( OBJECT_NAME, sSize, &sAddr ) );

        _CALL( cmnShmAttach_s ( OBJECT_NAME, 8, &sAddr ) );
        sAddr2 = sAddr;
        _CALL( cmnShmDetach_s ( &sAddr, 8 ) );
        _CALL( cmnShmDetach_s ( &sAddr2, 8 ) );

        for ( i = 0; i < TEST_COUNT; i++ )
        {
            _CALL( cmnShmAttach_s ( OBJECT_NAME, sSize, &sAddr ) );
            _CALL( cmnShmDetach_s ( &sAddr, sSize ) );
        }
        _CALL( cmnShmDrop_s ( OBJECT_NAME ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

TEST_F ( TFSHM001 , cmnShmXX_s )
{
    TABLE*  sData;
    void*   sAddr;
    int     sSize;
    int     sLinkCount;
    int     i;

    _TRY
    {
        sSize = sizeof(TABLE) * TEST_COUNT;
        _CALL( cmnShmCreate_s ( OBJECT_NAME, sSize, NULL ) );
        _CALL( cmnShmAttach_s ( OBJECT_NAME, sSize, &sAddr ) );

        memset ( sAddr, 0x00, sSize );

        /*---------------------------------------------------------
         * save some information in shm segment
         *-------------------------------------------------------*/
        sData = (TABLE *) sAddr;
        for ( i = 0; i < TEST_COUNT; i++ )
        {
            sData->mKey = (long long) i;
            sprintf ( sData->mVal, "%20d", i );

            sData++;
        }

        _CALL( cmnShmDetach_s ( &sAddr, sSize ) );

        // attach to shm segment again
        _CALL( cmnShmAttach_s ( OBJECT_NAME, sSize, &sAddr ) );

        /*---------------------------------------------------------
         * show saved information in shm segment
         *-------------------------------------------------------*/
        sData = (TABLE*) sAddr;
        for ( i = 0; i < 10; i++ )
        {
            DBM_ECHO( "    key[%ld] val[%s]", sData->mKey, sData->mVal );
            sData++;
        }

        _CALL( cmnShmDrop_s ( OBJECT_NAME ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        cmnShmDrop_s ( OBJECT_NAME );
    }
    _ENDVOID
}

/***********************************************************************e
 * N 개의 Thread 를 만들어서  Alloc 과 Free 를 반복
 ************************************************************************/
TEST_F ( TFSHM001, ThreadAllocFree )
{
    pthread_t   tid[NUM_OF_THREADS] ;
    void*       sAddr;
    int         sSize = 1024 * 1024 * 10;

    _TRY
    {
#if 1
        _CALL( cmnShmCreate_s ( OBJECT_NAME, sSize, &sAddr ) );
        _CALL( cmnShmDetach_s ( &sAddr, sSize ) );
        _CALL( cmnShmAttach_s ( OBJECT_NAME, 8, &sAddr ) );
#else
        _CALL( cmnShmCreate_s ( OBJECT_NAME, sSize, NULL ) );
#endif
        for ( int i = 0 ; i < NUM_OF_THREADS ; i ++)
        {
            _CALL( pthread_create ( &tid[i] ,  NULL,  thread_allocFree, NULL ) );
        }

        for ( int i = 0 ; i < NUM_OF_THREADS ; i ++ )
        {
            _CALL( pthread_join ( tid[i] , NULL) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        cmnShmDrop_s ( OBJECT_NAME );
    }
    _ENDVOID
}


////////////////////////////////////////////////////////////////////////////////
// static functions
////////////////////////////////////////////////////////////////////////////////

void* thread_allocFree ( void* arg )
{
    void*       sAddr;
    void*       sAddrArray[TEST_COUNT];
    int         sSize = 1024 * 1024 * 10;
    int         i, j;

    _TRY
    {
        for ( j = 0; j < TEST_COUNT; j++ )
        {
            for ( i = 0; i < 10; i++ )
            {
                if ( j%2 == 0 )
                {
                    _CALL( cmnShmAttach_s ( OBJECT_NAME, 8, &sAddr ) );
                }
                else
                {
                    _CALL( cmnShmAttach_s ( OBJECT_NAME, sSize, &sAddr ) );
                }
                sAddrArray[i] = sAddr;
            }

            for ( i = 0; i < 10; i++ )
            {
                if ( j%2 == 0 )
                {
                    _CALL( cmnShmDetach_s ( &sAddrArray[i], 8 ) );
                }
                else
                {
                    _CALL( cmnShmDetach_s ( &sAddrArray[i], sSize ) );
                }
            }
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    return NULL ;
}



#endif
