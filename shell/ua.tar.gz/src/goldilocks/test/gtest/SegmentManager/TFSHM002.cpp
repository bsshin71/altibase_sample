#include "dbmGtestHeader.h"

#ifdef _GTEST


typedef struct TABLE
{
    long long  mKey;
    char     mVal[20];
} TABLE;

#define TEST_NAME           "TFSHM002"
#define TEST_SLOT_COUNT     10

////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TFSHM002 : public testing::Test
{
public:
	static void SetUpTestCase ()
	{
	}

	static void TearDownTestCase()
	{
	    _T_ENDLOG;
	}

	virtual void SetUp()
	{
	}

	virtual void TearDown()
	{
        _T_SUB_ENDLOG;
	}
};

////////////////////////////////////////////////////////////////////////////////
// static 변수
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

TEST_F ( TFSHM002 , cmnPShmCreate )
{
    int     i;

    _TRY
    {
        for ( i = 0; i < TEST_SLOT_COUNT; i++ )
        {
            _CALL( cmnPShmCreate ( TEST_NAME, 1024 ) );
            _CALL( cmnPShmDrop ( TEST_NAME ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

TEST_F ( TFSHM002 , cmnPShmXX )
{
    TABLE*  sData;
    void*   sAddr;
    int     sShmSize;
    int     sLinkCount;
    int     i;

    _TRY
    {
        sShmSize = sizeof(TABLE) * TEST_SLOT_COUNT;
        _CALL( cmnPShmCreate ( TEST_NAME, sShmSize ) );
        _CALL( cmnPShmAttach ( TEST_NAME, sShmSize, &sAddr ) );

        memset ( sAddr, 0x00, sShmSize );

        /*---------------------------------------------------------
         * save some information in shm segment
         *-------------------------------------------------------*/
        sData = (TABLE *) sAddr;
        for ( i = 0; i < TEST_SLOT_COUNT; i++ )
        {
            sData->mKey = (long long) i;
            sprintf ( sData->mVal, "%20d", i );

            sData++;
        }

        /*---------------------------------------------------------
         * get attach num to shm
         *-------------------------------------------------------*/
        _CALL( cmnPShmGetAttachNum ( TEST_NAME, &sLinkCount ) );
        DBM_ECHO( "cmnPShmGetAttachNum OK [%d]", sLinkCount );

        _CALL( cmnPShmDetach ( &sAddr, sShmSize ) );

        // attach to shm segment again
        _CALL( cmnPShmAttach ( TEST_NAME, sShmSize, &sAddr ) );

        /*---------------------------------------------------------
         * show saved information in shm segment
         *-------------------------------------------------------*/
        sData = (TABLE*) sAddr;
        for ( i = 0; i < 10; i++ )
        {
            DBM_ECHO( "    key[%ld] val[%s]", sData->mKey, sData->mVal );

            sData++;
        }

        _CALL( cmnPShmDrop ( TEST_NAME ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        cmnPShmDrop ( TEST_NAME );
    }
    _ENDVOID
}


#endif
