#include "dbmGtestHeader.h"

#ifdef _GTEST


#define INST_NAME           "TINST"
#define OBJECT_NAME         "TFSEG001"
#define _aSlotSize          256
#define _aInitSlotCount     256
#define _aExtendSlotCount   256
#define _aMaxSlotCount      1024
#define _aUserHeaderSize    512


////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TFSEG001 : public testing::Test
{
public:
	static void SetUpTestCase ()
	{
        ASSERT_EQ( system( "../shl/test.seg.sh TFSEG001 > /dev/null 2>&1" ), 0 );
	}

	static void TearDownTestCase()
	{
	    _T_ENDLOG;
	}

	virtual void SetUp()
	{
	    _TRY
	    {
            _CALL( dbmSegmentManager::Create (
                    INST_NAME, OBJECT_NAME, _aSlotSize, _aInitSlotCount, _aExtendSlotCount,
                    _aMaxSlotCount, _aUserHeaderSize, &mSegmentManager ) );
	    }
	    _CATCH
	    {
	        _CATCH_ERR;
	    }
	    _FINALLY
	    _ENDVOID
	}

	virtual void TearDown()
	{
	    _TRY
	    {
            _CALL( dbmSegmentManager::Drop ( INST_NAME, OBJECT_NAME ) );

            delete mSegmentManager;
            mSegmentManager = NULL;
	    }
	    _CATCH
	    {
	        _CATCH_ERR;
	    }
	    _FINALLY
	    {
	        _T_SUB_ENDLOG;
	    }
	    _ENDVOID
	}

    static dbmSegmentManager* mSegmentManager;
    long long sSlot;
};

////////////////////////////////////////////////////////////////////////////////
// static 변수
////////////////////////////////////////////////////////////////////////////////
dbmSegmentManager* TFSEG001::mSegmentManager = NULL;


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

TEST_F ( TFSEG001 , FirstAllocTest )
{
    _TRY
    {
        _CALL( mSegmentManager->AllocSlot ( &sSlot ) );
        EXPECT_EQ( sSlot, 0 );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

TEST_F ( TFSEG001 , Alloc100 )
{
    _TRY
    {
        for ( int i = 0; i < 100; i++ )
        {
            _CALL( mSegmentManager->AllocSlot ( &sSlot ) );
            EXPECT_EQ( sSlot, i );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

TEST_F ( TFSEG001, FULL_TEST )
{
    _TRY
    {
        /** 꽉 채운다 */
        for ( int i = 0; i < _aMaxSlotCount; i++ )
        {
            _CALL( mSegmentManager->AllocSlot ( &sSlot ) );
            EXPECT_EQ( sSlot, i );
        }

        /** 위에서 꽉 채웠으니 한번 더 하면 에러가 나야한다 */
        EXPECT_NE ( mSegmentManager->AllocSlot ( &sSlot ), 0 );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

/* 공간 재활용 테스트 */
TEST_F ( TFSEG001, FULL_AND_FREE )
{
    long long* pSlot = (long long*) malloc ( sizeof( pSlot ) * _aMaxSlotCount );

    _TRY
    {
//        memset ( pSlot, 0x00, sizeof( pSlot ) * _aMaxSlotCount );

        /** 꽉 채운다 */
        for ( int i = 0; i < _aMaxSlotCount; i++ )
        {
            _CALL( mSegmentManager->AllocSlot ( &pSlot[i] ) );
            EXPECT_EQ( pSlot[i], i );
        }

        /** 위에서 꽉 채웠으니 한번 더 하면 에러가 나야한다 */
        EXPECT_NE ( mSegmentManager->AllocSlot ( &sSlot ), 0 );

        /** 전체를 Free 한다 */
        for ( int i = 0; i < _aMaxSlotCount; i++ )
        {
            _CALL( mSegmentManager->FreeSlot ( pSlot[i] ) );
        }

        /* 다시 한번 공간을 꽉 채운다 */
        for ( int i = 0; i < _aMaxSlotCount; i++ )
        {
            _CALL( mSegmentManager->AllocSlot ( &pSlot[i] ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        free_s ( pSlot );
    }
    _ENDVOID
}

/* Double Free 테스트 */
TEST_F ( TFSEG001, DOUBLE_FREE_TEST )
{
    long long* pSlot = (long long*) malloc ( sizeof( pSlot ) * _aMaxSlotCount );

    _TRY
    {
//        memset ( pSlot, 0x00, sizeof( pSlot ) * _aMaxSlotCount );

        /** 꽉 채운다 */
        for ( int i = 0; i < _aMaxSlotCount; i++ )
        {
            _CALL( mSegmentManager->AllocSlot ( &pSlot[i] ) );
            EXPECT_EQ( pSlot[i], i );
        }

        /** 전체를 Free 한다 */
        for ( int i = 0; i < _aMaxSlotCount; i++ )
        {
            _CALL( mSegmentManager->FreeSlot ( pSlot[i] ) );
        }

        /** 전체를 Free 한다 이건 백퍼 에러가 나야한다 */
        for ( int i = 0; i < _aMaxSlotCount; i++ )
        {
            EXPECT_NE( mSegmentManager->FreeSlot ( pSlot[i], 1 ), 0 );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        free_s ( pSlot );
    }
    _ENDVOID
}

TEST_F ( TFSEG001, MANUAL_EXTEND )
{
    _TRY
    {
        for ( int i = 0; i < 10; i++ )
        {
            _CALL( mSegmentManager->Extend ( ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

TEST_F ( TFSEG001 , testGetLastExtendSlotNo )
{
    _TRY
    {
        sSlot = mSegmentManager->GetLastExtendSlotNo ( );
        EXPECT_EQ ( sSlot, 255 );

        _CALL( mSegmentManager->Extend ( ) );
        sSlot = mSegmentManager->GetLastExtendSlotNo ( );
        EXPECT_EQ ( sSlot, 511 );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

TEST_F ( TFSEG001 , TRUNCATE )
{
    _TRY
    {
        _CALL( mSegmentManager->AllocSlot ( &sSlot ) );
        EXPECT_EQ ( sSlot, 0 );

        _CALL( mSegmentManager->Extend ( ) );
        sSlot = mSegmentManager->GetLastExtendSlotNo ( );
        EXPECT_EQ ( sSlot, 511 );

        _CALL( mSegmentManager->Truncate ( ) );
        sSlot = mSegmentManager->GetLastExtendSlotNo ( );
        EXPECT_EQ ( sSlot, 255 );

        _CALL( mSegmentManager->AllocSlot ( &sSlot ) );
        EXPECT_EQ ( sSlot, 0 );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

TEST_F (TFSEG001 , InvalidAttach )
{
    int     sFD;
    int     sRC;
    char    sBuf[1024];
    char    sInvalidFileName[1024] = "/dev/shm/myInvalidFileName_0";
    dbmSegmentManager* sObj;

    _TRY
    {
        sFD = open ( sInvalidFileName, O_CREAT | O_APPEND | O_RDWR, 0777 );
        EXPECT_TRUE( sFD > 0 );

        memset ( sBuf, 0x00, sizeof( sBuf ) );

        sRC = dbmSegmentManager::Attach ( INST_NAME, (char*) "myInvalidFileName", &sObj );
        EXPECT_NE( sRC, RC_SUCCESS );

        sRC = write ( sFD, sBuf, sizeof( sBuf ) );

        sRC = dbmSegmentManager::Attach ( INST_NAME, (char*) "myInvalidFileName", &sObj );
        EXPECT_NE( sRC, RC_SUCCESS );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        close ( sFD );
        unlink ( sInvalidFileName );
    }
    _ENDVOID
}

#endif
