#include "dbmGtestApi.h"

#define MM_RUN      "metaManager --silent -f _t.sql > /dev/null 2>&1 "


#define SQL_CRT_UNDO    "echo \"\
drop undo %s;                               \
create undo %s;                             \
\" |sed -e 's#;[ ]*#;\\n#g' > _t.sql"

#define SQL_DROP_UNDO   "echo \"\
drop undo %s;                               \
\" |sed -e 's#;[ ]*#;\\n#g' > _t.sql"

#define SQL_TBL_ITEM    "echo \"\
set undo %s;                                \
drop table item;                            \
create table item                           \
itemcd     char    8                        \
itemnm     char    20                       \
highprc    double  10 2                     \
lowprc     double  10 2                     \
smaxprc    double  10 2                     \
minprc     double  10 2                     \
currprc    double  10 2                     \
trdqty     long    15 0                     \
trdamt     long    15 0                     \
init 10000 extend 10000 max 1000000;        \
create index item_idx1 on item itemcd;      \
\" |sed -e 's#;[ ]*#;\\n#g' > _t.sql"

#define SQL_TBL_ACCNT   "echo \"\
set undo %s;                                \
drop table accnt;                           \
create table accnt                          \
accntno     char    8                       \
accntnm     char    20                      \
ablemoney   long    15 0                    \
unsettle    long    15 0                    \
init 30000 extend 10000 max 1000000;        \
create index accnt_idx1 on accnt accntno;   \
\" |sed -e 's#;[ ]*#;\\n#g' > _t.sql"

#define SQL_TBL_ORDNO   "echo \"\
set undo %s;                                \
drop table ordno;                           \
create table ordno                          \
brcd        char    3                       \
ordno       long    8 0                     \
init 10 extend 100 max 1000;                \
create index ordno_idx1 on ordno brcd;      \
\" |sed -e 's#;[ ]*#;\\n#g' > _t.sql"

#define SQL_TBL_ORDER   "echo \"\
set undo %s;                                \
drop table order;                           \
create table order                          \
accntno     char    8                       \
itemcd      char    8                       \
ordprc      long    8 0                     \
ordqty      long    8 0                     \
ordno       long    8 0                     \
init 1000000 extend 100000 max 10000000;    \
create index order_idx1 on order accntno itemcd ordno; \
create index order_idx2 on order ordno;     \
\" |sed -e 's#;[ ]*#;\\n#g' > _t.sql"

#define SQL_TBL_DROP    "echo \"\
set undo %s;                                \
drop table %s;                              \
\" |sed -e 's#;[ ]*#;\\n#g' > _t.sql"


PHTIMER _tc_timer;

_VOID TEST_SQL_UNDO ( char* aUndo, int aFlag )
{
    char    sSQL[2048];

    _TRY
    {
        if ( aFlag == 0 )
        {
            sprintf ( sSQL, SQL_CRT_UNDO, aUndo, aUndo );
        }
        else
        {
            sprintf ( sSQL, SQL_DROP_UNDO, aUndo );
        }
        _CALL( system( sSQL ) );
        _CALL( system( MM_RUN ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

_VOID TEST_SQL_TBL ( char* aUndo, char* aTable, int aFlag )
{
    char    sSQL[2048];
    char*   pChar = NULL;

    _TRY
    {
        if ( aFlag == 0 )
        {
            if ( strcmp( aTable, "item" ) == 0 )
            {
                pChar = SQL_TBL_ITEM;
            }
            else if ( strcmp( aTable, "accnt" ) == 0 )
            {
                pChar = SQL_TBL_ACCNT;
            }
            else if ( strcmp( aTable, "ordno" ) == 0 )
            {
                pChar = SQL_TBL_ORDNO;
            }
            else if ( strcmp( aTable, "order" ) == 0 )
            {
                pChar = SQL_TBL_ORDER;
            }
            else
            {
                _DASSERT( 0 );
            }

            // warning: format not a string literal, argument types not checked
            sprintf ( sSQL, (const char*)pChar, aUndo );
        }
        else
        {
            sprintf ( sSQL, SQL_TBL_DROP, aUndo, aTable );
        }

        _CALL( system( sSQL ) );
        _CALL( system( MM_RUN ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

