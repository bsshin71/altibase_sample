/*
 * main.cpp
 *
 *  Created on: Mar 18, 2014
 *      Author: paul
 */

#include "dbmGtestHeader.h"
#include "cmnLogManager.h"

#define ENV_DBM_TEST_LIBS               "_DBM_TEST_LIBS"    /* for gtest only */

#ifdef _GTEST
using ::testing::UnitTest;
//using ::testing::TestInfo;
using ::testing::InitGoogleTest;
#endif

static void usage ()
{
    printf ( "usage: %s --gtest_filter=T* \n", basename ( _dbm_argv[0] ) );
}

_VOID main ( int argc, char** argv )
{
    int     i;
    char*   pChar = NULL;

    // [gcc-warn] dereferencing type-punned pointer will break strict-aliasing rules
    static char pGtestStr[8] = { '-', '-', 'g', 't', 'e', 's', 't', 0 };    // --gtest_filter=XX
    static int  nGtestStr = *( (int*)pGtestStr );

    _TRY
    {
        _dbm_setArg ( &argc, argv );

        // 디버그 편의를 위해 실행 인자를 로깅한다. ( 사실은 GTEST가 아니고 일반에 적용 필요 )
        {
            char    zTmp[1024] = { 0, };
            int     pos = 0;
            int     len = 0;
            for ( int i = 0; i < _dbm_argc; i++ )
            {
                if ( sizeof( zTmp ) - pos < 1 )
                    break;

                len = snprintf ( (char*) zTmp + pos, sizeof( zTmp ) - pos, "%s ", _dbm_argv[i] );
                pos += len;
            }

            DBM_INFO ( "[GTEST] %s", zTmp );
        }

        // 테스트 대상 *.so 를 ../lib/ 경로에서 찾아서 모두 로딩한다. ( 어떤 테스트인지 모르므로 )
        pChar = getenv ( ENV_DBM_TEST_LIBS );
        if ( pChar != NULL )
        {
            char* token;
            char* saveptr1;
            void* handle;

            while ( 1 )
            {
                token = strtok_r ( pChar, ":", &saveptr1 );
                if ( token == NULL )
                    break;

                handle = dlopen ( token, RTLD_NOW );
                if ( handle == NULL )
                {
                    _PRT( "dlopen fail. [%s]\n", dlerror ( ) );
                    _THROW ( -1 );
                }

                pChar = NULL;
            }
        }
        else
        {
            //TODO: $GDSRC/test/lib 의 so를 직접로딩.
            _PRT( "$_DBM_TEST_LIBS not setted.\n" );
            _THROW( -1 );
        }

#ifdef _GTEST
        for ( i=1; i<argc; i++ )
        {
            if ( *( (int*)argv[i] ) == nGtestStr )
            {
                // GTEST 내부에서 인자를 감소시킨다. 때문에 argc도 포인터로 받아야 함.
                InitGoogleTest ( &argc, argv );
                _dbm_argc = argc;

                return RUN_ALL_TESTS ( );
            }
        }
#endif

        usage ();
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}
