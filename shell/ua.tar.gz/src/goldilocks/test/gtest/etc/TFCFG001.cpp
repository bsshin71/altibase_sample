/**
 * @file            TFCFG001.cpp ( unitTest/Config )
 */
#include "dbmGtestHeader.h"

#ifdef _GTEST


////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TFCFG001 : public testing::Test
{
public:
    static void SetUpTestCase ()
    {
    }

    static void TearDownTestCase()
    {
        _T_ENDLOG;
    }

    virtual void SetUp()
    {
    }

    virtual void TearDown()
    {
        _T_SUB_ENDLOG;
    }
};


////////////////////////////////////////////////////////////////////////////////
// class static 변수
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

TEST_F ( TFCFG001, testConfigManager )
{
    dbmConfig   sConf;
    char        sVal[1024];

    _TRY
    {
        _CALL( sConf.mLoad ( "COMMON" ) );
        _CALL( sConf.mLoad ( "fhan" ) );
        _CALL( sConf.mLoad ( "test" ) );

        sConf.mPrintAll ( );

        _PRT ( "\n> dbmConfig::mSearch..\n" );
        _CALL( sConf.mSearch ( "fhan", "TRACE_LOG_DIR", sVal ) );
        _PRT ( "mSearc rc = %d, TRACE_LOG_DIR( fhan)=[%s]\n", _rc, sVal );

        _CALL( sConf.mSearch ( "test", "TRACE_LOG_DIR", sVal ) );
        _PRT ( "mSearc rc = %d, TRACE_LOG_DIR( test)=[%s]\n", _rc, sVal );

        _CALL( sConf.mSearch ( "test", "TRACE_LOG_DIR", sVal ) );
        _PRT ( "mSearc rc = %d, TRACE_LOG_DIR( test)=[%s]\n", _rc, sVal );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}


#endif
