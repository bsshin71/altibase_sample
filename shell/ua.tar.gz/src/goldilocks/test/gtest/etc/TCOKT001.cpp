/*
 * okseop - 임시테스트 소스
 *
 * 개인적으로 사용하는 임시 코드이나, 기존 코드를 호출해야하는 필요가 있는 경우 사용하기 위해 등록.
 */

#include "dbmGtestHeader.h"


#ifdef _GTEST

//#define NUM_OF_THREADS      16
#define NUM_OF_THREADS      8
#define TEST_COUNT          ( 400 * 10000 * NUM_OF_THREADS )

static void* thread_test ( void* arg );
static void* thread_test2 ( void* arg );

/*
 *	Statistics counters of the socket lists
 */
//static DEFINE_PER_CPU(int, sockets_in_use) = 0;
long long g_test_percpu_cnt[ TEST_COUNT ] = { 0, };

////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TCOKT001 : public testing::Test
{
public:
    static void SetUpTestCase ()
    {
    }

    static void TearDownTestCase()
    {
        _T_ENDLOG;
    }

    virtual void SetUp()
    {
    	memset( g_test_percpu_cnt, 0x00, sizeof(g_test_percpu_cnt) );
    }

    virtual void TearDown()
    {
        _T_SUB_ENDLOG;
    }

    char*   mData;
    char*   mDataN[TEST_COUNT];
};


////////////////////////////////////////////////////////////////////////////////
// class static 변수
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

TEST_F ( TCOKT001 , DISABLED_PERCPU )
{
    _TRY
    {
#if 0
    	 /*
    	  * /usr/src/kernels/2.6.32-431.23.3.el6.x86_64/include/linux/percpu.h
    	  * 처럼 커널 코드 내부에서만 사용되는 기능.
    	  *
    	  * Per-CPU 변수의 개념은 좋으나,
    	  * SHM 환경에서 어떻게 사용가능한지 잘 모르겠고. 일단 커널 코드란 문제.
    	  * 스캐줄러 선점 문제 등으로 사용 불가할듯.
    	  */
    	#include <linux/percpu.h>

    	 static DEFINE_PER_CPU(int, sockets_in_use) = 0;
#endif
    }
    _CATCH
    _FINALLY
    _ENDVOID
}


// N 개의 Thread
TEST_F ( TCOKT001, NOPRECPU_T )
{
    pthread_t   tid[NUM_OF_THREADS] ;
    int         i;

    _TRY
    {

        for ( i = 0; i < NUM_OF_THREADS; i++ )
        {
            _CALL( pthread_create ( &tid[i], NULL, thread_test, NULL ) );
        }

        for ( i = 0; i < NUM_OF_THREADS; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }

    	long long sum = 0;
        for ( i = 0; i < NUM_OF_THREADS; i++ )
        {
        	sum += g_test_percpu_cnt[i];
        }
    	_PRT ( "%d thread, sum = %lld\n", NUM_OF_THREADS, sum );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}


TEST_F ( TCOKT001, PRECPU_T )
{
    pthread_t   tid[NUM_OF_THREADS] ;
    int         i;

    _TRY
    {
        for ( i = 0; i < NUM_OF_THREADS; i++ )
        {
            _CALL( pthread_create ( &tid[i], NULL, thread_test2, NULL ) );
        }

        for ( i = 0; i < NUM_OF_THREADS; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }

    	long long sum = 0;
        for ( i = 0; i < NUM_OF_THREADS; i++ )
        {
        	sum += g_test_percpu_cnt[i];
        }
    	_PRT ( "%d thread, sum = %lld\n", NUM_OF_THREADS, sum );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}


//////////////////////////////////////////////////////////////////////////////////
//// static functions
//////////////////////////////////////////////////////////////////////////////////
__thread int test_sCpu = 0;
int test_sCpu_total = 0;

int getcpu_s()
{
#if 0
	int sCpu = 0;
	int sCpuPre = 0;

	sCpuPre = sCpu;
	sCpu = sched_getcpu();

	return sCpu;
#else
	if ( test_sCpu == 0 )
	{
		test_sCpu = atomic_inc ( &test_sCpu_total );
	}

	return ( test_sCpu - 1 );
#endif
}

void* thread_test ( void* arg )
{
    _TRY
    {
    	_CALL_TM2(
			for ( int i = TEST_COUNT/NUM_OF_THREADS - 1; i >= 0; i-- )
			{
				atomic_inc( &g_test_percpu_cnt[0] );
			}
    	);
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    return NULL;
}

void* thread_test2 ( void* arg )
{
    _TRY
    {
    	_CALL_TM2(
			for ( int i = TEST_COUNT/NUM_OF_THREADS - 1; i >= 0; i-- )
			{
				atomic_inc( &g_test_percpu_cnt[ getcpu_s() ] );
			}
    	);
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    return NULL;
}


#endif
