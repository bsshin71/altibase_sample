#include "dbmGtestHeader.h"

#ifdef _GTEST

#define NUM_OF_THREADS      8
#define TEST_COUNT          100000
#define MEMMGR_SLOT_MAX     ( 10240 * 4 )
#define OBJECT_NAME         "TCMEM001"
//#define NUM_OF_THREADS2     4

static _VOID AllocFree10K ( int aThrNum = 1 );
static void* thread_allocFree ( void* arg );
static void* thread_test ( void* arg );


////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TCMEM001 : public testing::Test
{
public:
    static void SetUpTestCase ()
    {
    }

    static void TearDownTestCase()
    {
        _T_ENDLOG;
    }

    virtual void SetUp()
    {
    }

    virtual void TearDown()
    {
        _T_SUB_ENDLOG;
    }

    char*   mData;
    char*   mDataN[TEST_COUNT];
};


////////////////////////////////////////////////////////////////////////////////
// class static 변수
////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

TEST_F ( TCMEM001 , AllocOne )
{
    _TRY
    {
        _CALL( cmnMemAllocSlot ( (void**) &mData ) );
        _CALL( cmnMemFreeSlot ( (void**) &mData ) );
        _rc = cmnMemFreeSlot ( (void**) &mData );       // Double Free 테스트
        EXPECT_NE( _rc, 0 );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

TEST_F ( TCMEM001 , AllocN )
{
    int     sMaxSlotCnt = TEST_COUNT;
    int     i;

    _TRY
    {
        if ( TEST_COUNT > MEMMGR_SLOT_MAX - 1 )
        {
            sMaxSlotCnt = MEMMGR_SLOT_MAX - 1;
//          sMaxSlotCnt = MEMMGR_SLOT_MAX;          // alloc 을 못받아서 무한대기한다.
        }
        for ( i = 0; i < TEST_COUNT; i++ )
        {
            _CALL( cmnMemAllocSlot ( (void**) &mData ) );
            _CALL( cmnMemFreeSlot ( (void**) &mData ) );
        }

        for ( i = 0; i < sMaxSlotCnt; i++ )
        {
            _CALL( cmnMemAllocSlot ( (void**) &mDataN[i] ) );
        }

        for ( i = 0; i < sMaxSlotCnt; i++ )
        {
            _CALL( cmnMemFreeSlot ( (void**) &mDataN[i] ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}


TEST_F ( TCMEM001 , AllocFreeLong )
{
    int     i, j;

    _TRY
    {
        DBM_ECHO( "단일쓰레드 100만번 Alloc - Free 성능:" );
        _CALL_TM2 (
            for ( i = 0; i < 100; i++ )
            {
               _CALL( AllocFree10K() );
            }
        );

    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

//TEST_F ( TCMEM001, FULL_TEST )
//{
//    _TRY
//    {
//        /** 꽉 채운다 */
//        for ( i = 0; i < _aMaxSlotCount; i++ )
//        {
//            _CALL( mSegmentManager->AllocSlot ( &sSlot ) );
//            EXPECT_EQ( sSlot, i );
//        }
//
//        /** 위에서 꽉 채웠으니 한번 더 하면 에러가 나야한다 */
//        EXPECT_NE ( mSegmentManager->AllocSlot ( &sSlot ), 0 );
//    }
//    _CATCH
//    {
//        _CATCH_ERR;
//    }
//    _FINALLY
//    _ENDVOID
//}


/***************************************************************
 * N 개의 Thread 를 만들어서 각 N 개의 Thread 를 수행한 결과가
 * 전체 합이 맞는지 체크한다.
 ******************************************************************/
TEST_F ( TCMEM001, ThreadConcurrency )
//TEST_F ( TCMEM001, DISABLED_ThreadConcurrency )
{
    pthread_t   tid[NUM_OF_THREADS] ;
    int         i;

    _TRY
    {
        for ( i = 0; i < NUM_OF_THREADS; i++ )
        {
            _CALL( pthread_create ( &tid[i], NULL, thread_test, NULL ) );
        }

        for ( i = 0; i < NUM_OF_THREADS; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}


/***********************************************************************e
 * N 개의 Thread 를 만들어서  Alloc 과 Free 를 반복
 ************************************************************************/
TEST_F ( TCMEM001, ThreadAllocFree )
{
    pthread_t   tid[NUM_OF_THREADS] ;
    int         i;

    _TRY
    {
        for ( i = 0 ; i < NUM_OF_THREADS ; i ++)
        {
            _CALL( pthread_create ( &tid[i] ,  NULL,  thread_allocFree, NULL ) );
            usleep ( i * 100 ) ;
        }

        for ( i = 0 ; i < NUM_OF_THREADS ; i ++ )
        {
            _CALL( pthread_join ( tid[i] , NULL) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

//////////////////////////////////////////////////////////////////////////////////
//// static functions
//////////////////////////////////////////////////////////////////////////////////

_VOID AllocFree10K ( int aThrNum )
{
    char*   sDataN[10000];
    int     i, j;

    _TRY
    {
        for ( j = 0; j < 10000/aThrNum; j++ )
         {
             _CALL( cmnMemAllocSlot ( (void**) &sDataN[j] ) );
         }

         for ( j = 0; j < 10000/aThrNum; j++ )
         {
             _CALL( cmnMemFreeSlot ( (void**) &sDataN[j] ) );
         }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
}

void* thread_test ( void* arg )
{
    char*   sData;
    int     i, j;

    _TRY
    {
        for ( i = 0; i < (100*10000)/NUM_OF_THREADS; i++ )
        {
            _CALL( cmnMemAllocSlot ( (void**) &sData ) );
            sched_yield();
//            cmnNanoSleep ( 1000 );
            _CALL( cmnMemFreeSlot ( (void**) &sData ) );
            sched_yield();
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    return NULL;
}

void* thread_allocFree ( void* arg )
{
    int     i;

    _TRY
    {
        // 100만번 Alloc - Free
        for ( i = 0; i < 100; i++ )
        {
           _CALL( AllocFree10K ( NUM_OF_THREADS ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    return NULL ;
}


#endif
