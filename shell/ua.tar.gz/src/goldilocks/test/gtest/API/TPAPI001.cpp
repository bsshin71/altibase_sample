/**
 * @file            TPAPI001.cpp ( test6.cpp )
 */

#include "dbmGtestApi.h"

#ifdef _GTEST

#define UNDO_NAME       "TPAPI001"
#define TABLE_NAME      "T1"

// 기본값.
const int THREAED_NUM = 4;
//const int THREAED_NUM = 1;
#ifdef _DEBUG
const int TEST_COUNT = 200000;
//const int TEST_COUNT = 40000;
#else
const int TEST_COUNT = 5000000;
#endif

typedef struct
{
    char c1[20];
    int c2;
    int c3;
} TABLE;

static void* insert_thread ( void* );
static void* select_thread ( void* );
static void* update_thread ( void* );


////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TPAPI001 : public testing::Test
{
public:
	static void SetUpTestCase ()
	{
        char    sSql[1024];
        char    sError[2048];
	    char    buffer[1024];
	    int rc;
	    int i;
	    int nStart, nEnd, aCount;
	    struct timespec start, end;

		_TRY
		{
            ASSERT_EQ( system( "../shl/test.undo.sh TPAPI001 > /dev/null 2>&1" ), 0 );
            DBM_INFO ( "Start.. (%s)", UNDO_NAME );

	        _CALL ( dbmInitHandle ( &mDbmHandle, UNDO_NAME ) );

	        // Table creation
	        {
//                dbmDropTable ( &mDbmHandle, TABLE_NAME );
                sprintf ( sSql, "drop table %s", TABLE_NAME );
                _rc = dbmExecuteDDL ( &mDbmHandle, sSql );
                if ( _rc != 0 && _rc != ERR_DBM_TABLE_NOT_IN_DICTIONARY )
                    _THROW ( _rc );

#if 0
                sprintf ( sSql, "create table %s "
                           "c1 char 20 0 "
                           "c2 int 10 0 "
                           "c3 int 10 0 "
                           "init 10000000 extend 1000000 max 12000000",
                           TABLE_NAME );
#else
                sprintf ( sSql, "create table %s "
                           "c1 char 20 0 "
                           "c2 int 10 0 "
                           "c3 int 10 0 "
                           "init 1000 extend 10000 max 12000000",
                           TABLE_NAME );
#endif

                _CALL( dbmExecuteDDL ( &mDbmHandle, sSql ) );

                sprintf ( sSql, "create index idx_%s on %s c2", TABLE_NAME, TABLE_NAME );
                _CALL( dbmExecuteDDL ( &mDbmHandle, sSql ) );
	        }

            dbmFreeHandle ( &mDbmHandle );
		}
		_CATCH
		{
			_CATCH_ERR;
		}
		_FINALLY
		_ENDVOID
	}

	static void TearDownTestCase()
	{
        ASSERT_EQ( system( "../shl/test.undo.sh TPAPI001 drop > /dev/null 2>&1" ), 0 );
	    _T_ENDLOG;
	}

	virtual void SetUp()
	{
	}

	virtual void TearDown()
	{
	    _T_SUB_ENDLOG;
	}

    static dbmHandle mDbmHandle;
    static int bInserted;
};

////////////////////////////////////////////////////////////////////////////////
// class static 변수
////////////////////////////////////////////////////////////////////////////////
dbmHandle TPAPI001::mDbmHandle;
int TPAPI001::bInserted = 0;


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

typedef void* cmnThreadCbFunc ( void* arg );

static _VOID run ( cmnThreadCbFunc* cbFunc, int loop_cnt = TEST_COUNT, int thread_num = THREAED_NUM )
{
    pthread_t* tid = NULL;
    PARAM*  param = NULL;
    int     i;

    _TRY
    {
        tid = (pthread_t*) malloc ( sizeof(pthread_t) * thread_num );
        param = (PARAM*) malloc ( sizeof(PARAM) * thread_num );

        int start = 0;
        for ( i = 0; i < thread_num; i++ )
        {
            param[i].start = start;
            param[i].aCount = 0;
            _CALL( pthread_create ( &tid[i], NULL, cbFunc, &param[i] ) );
            start = start + ( loop_cnt / thread_num );
        }

        for ( i = 0; i < thread_num; i++ )
        {
            pthread_join ( tid[i], NULL );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        free_s ( tid );
        free_s ( param );
    }
    _END
}


TEST_F ( TPAPI001, insert )
{
//    ASSERT_EQ ( run ( insert_thread, TEST_COUNT/THREAED_NUM, 1 ), 0 );
    ASSERT_EQ ( run ( insert_thread ), 0 );
    bInserted = 1;
}

TEST_F ( TPAPI001, select )
{
    if ( bInserted != 1 )
    {
        DBM_INFO ( ">> testdata not ready, run insert..");
        ASSERT_EQ ( run ( insert_thread ), 0 );
    }
    ASSERT_EQ ( run ( select_thread ), 0 );
}

TEST_F ( TPAPI001, update )
{
    if ( bInserted != 1 )
    {
        DBM_INFO ( ">> testdata not ready, run insert..");
        ASSERT_EQ ( run ( insert_thread ), 0 );
    }
    ASSERT_EQ ( run ( update_thread ), 0 );
}


////////////////////////////////////////////////////////////////////////////////
// static functions
////////////////////////////////////////////////////////////////////////////////

static _VOID test_dml ( void *param, int opType )
{
    dbmHandle sHandle;
    int     i;
    int     j;
    int     nStart;
    int     nEnd;
    TABLE   sRow;
    struct timespec start, end;

    _TRY
    {
        nStart = (int) ( ( (PARAM*) param )->start );
        nEnd = nStart + ( TEST_COUNT / THREAED_NUM );
        _T_PRT( "================ [THR:%ld] (start=%d ~ end=%d)\n", pthread_self ( ), nStart, nEnd );

        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );
        _CALL( dbmPrepareTable ( &sHandle, (char*) TABLE_NAME ) );

        j = 1784;
        clock_gettime_s ( CLOCK_REALTIME, &start );
        for ( i = nStart; i < nEnd; i++ )
        //for (i=nEnd-1; i>=nStart; i--)
        {
            memset ( &sRow, 0x00, sizeof(TABLE) );
            sprintf ( sRow.c1, "%019d", i );

            if ( opType == INSERT )
            {
                sRow.c2 = i;
                sRow.c3 = 0;

                _CALL( dbmInsertRow ( &sHandle, (char*) TABLE_NAME, &sRow, sizeof(TABLE) ) );
                _CALL( dbmCommit ( &sHandle ) );
            }
            else if ( opType == SELECT )
            {
                //sRow.c1 = i;
                sRow.c2 = i;
                _CALL( dbmSelectRow ( &sHandle, (char*) TABLE_NAME, &sRow ) );
//                _CALL( dbmCommit ( &sHandle ) );
            }
            else if ( opType == UPDATE )
            {
                //sRow.c1 = j;
                sRow.c2 = j;
                _CALL( dbmSelectForUpdateRow ( &sHandle, (char*) TABLE_NAME, &sRow ) );

                sRow.c3 = sRow.c3 + 1;
                _CALL( dbmUpdateRow ( &sHandle, (char*) TABLE_NAME, &sRow ) );
                _CALL( dbmCommit ( &sHandle ) );
            }

#if 0
            if (i !=0 && (i % 10000) == 0) _T_PRT( "%d rows inserted..\n", i - nStart);
#endif
        }
        clock_gettime_s ( CLOCK_REALTIME, &end );
        _T_PRT( "LOOP=%d, i=%d, Elap=%.9f\n", TEST_COUNT, i,
                 (double) ( ( end.tv_sec + end.tv_nsec / 1000000000.0 ) - ( start.tv_sec + start.tv_nsec / 1000000000.0 ) ) );

        if ( opType == UPDATE )
        {
            memset ( &sRow, 0x00, sizeof(TABLE) );
            sprintf ( sRow.c1, "%019d", j );
            sRow.c2 = j;

            _CALL( dbmSelectRow ( &sHandle, (char*) TABLE_NAME, &sRow ) );
            _T_PRT( "last Select c3 = %d\n", sRow.c3 );
        }

        _CALL ( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
//        char    sError[1024];
//        dbmGetErrorByHandle ( &sHandle, sError );
    }
    _FINALLY
    _END
}


void* insert_thread ( void *param )
{
    _TRY
    {
        _CALL ( test_dml ( param, INSERT ) );
    }
    _CATCH
    {
        _CATCH_ERR;
        EXPECT_EQ ( _rc, 0 );
    }
    _FINALLY
    _ENDNULL
}

void* select_thread ( void *param )
{
    _TRY
    {
        _CALL ( test_dml ( param, SELECT ) );
    }
    _CATCH
    {
        _CATCH_ERR;
        EXPECT_EQ ( _rc, 0 );
    }
    _FINALLY
    _ENDNULL
}

void* update_thread ( void *param )
{
    _TRY
    {
        _CALL ( test_dml ( param, UPDATE ) );
    }
    _CATCH
    {
        _CATCH_ERR;
        EXPECT_EQ ( _rc, 0 );
    }
    _FINALLY
    _ENDNULL
}


#endif
