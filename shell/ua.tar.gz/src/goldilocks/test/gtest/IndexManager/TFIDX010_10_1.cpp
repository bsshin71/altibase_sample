/**
 * @file            TFIDX010_10_1.cpp ( unittest/IndexManager/test10_10_1.cpp )
 *
 * @note
 *  1. select row gt,lt (c1,c2,c3 integer) 검증 test
 */
#include "dbmGtestApi.h"

#ifdef _GTEST

#define UNDO_NAME       "TFIDX010_10_1"
#define TABLE_NAME      "T1"

#define THR             4
#define LOOP            ( 1000 * 10 )
//#define LOOP          ( 1000 * 1000 * 1 )

typedef struct TABLE
{
    char c1[20];
    int c2;
    int c3;
} TABLE;

static void* thr1 ( void* );
static void* thr2 ( void* );

////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TFIDX010_10_1 : public testing::Test
{
public:
	static void SetUpTestCase ()
	{
        struct timespec start, end;
        int     nStart, nEnd, aCount;
        char    sSql[1024];
        char    sError[2048];
	    char    buffer[1024];
	    int     rc;
	    int     i;

		_TRY
		{
            ASSERT_EQ( system( "../shl/test.undo.sh TFIDX010_10_1 > /dev/null 2>&1" ), 0 );
            DBM_INFO ( "Start.. (%s)", UNDO_NAME );

	        _CALL ( dbmInitHandle ( &mDbmHandle, UNDO_NAME ) );

	        // Table creation
	        {
                sprintf ( sSql, "drop table %s", TABLE_NAME );
                _rc = dbmExecuteDDL ( &mDbmHandle, sSql );
                if ( _rc != 0 && _rc != ERR_DBM_TABLE_NOT_IN_DICTIONARY )
                    _THROW ( _rc );

                sprintf ( sSql, "create table %s ( "
                          "c1 char(20) , "
                          "c2 int , "
                          "c3 int ) "
                          "init 10000000 extend 3000000 max 11000000", TABLE_NAME );
                _CALL( dbmExecuteDDL ( &mDbmHandle, sSql ) );

                sprintf ( sSql, "create index idx_%s on %s ( c1, c2, c3 )", TABLE_NAME, TABLE_NAME );
                _CALL( dbmExecuteDDL ( &mDbmHandle, sSql ) );
	        }

            _CALL( dbmFreeHandle ( &mDbmHandle ) );
		}
		_CATCH
		{
			_CATCH_ERR;
		}
		_FINALLY
		_ENDVOID
	}

	static void TearDownTestCase()
	{
        ASSERT_EQ( system( "../shl/test.undo.sh TFIDX010_10_1 drop > /dev/null 2>&1" ), 0 );
	    _T_ENDLOG;
	}

	virtual void SetUp()
	{
	}

	virtual void TearDown()
	{
	    _T_SUB_ENDLOG;
	}

    static dbmHandle mDbmHandle;
};

////////////////////////////////////////////////////////////////////////////////
// class static 변수
////////////////////////////////////////////////////////////////////////////////
dbmHandle TFIDX010_10_1::mDbmHandle;


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

TEST_F ( TFIDX010_10_1, thr1 )
{
    pthread_t* tid = NULL;
    PARAM*  param = NULL;
    int     loop_cnt = LOOP;
    int     thread_num = THR ;
    int     start;
    int     i;

    _TRY
    {
        tid = (pthread_t*) malloc ( sizeof(pthread_t) * thread_num );
        param = (PARAM*) malloc ( sizeof(PARAM) * thread_num );

        start = 0;
        for ( i = 0; i < thread_num; i++ )
        {
            param[i].tid = i;
            param[i].start = start;
            param[i].aCount = 0;

            _CALL( pthread_create ( &tid[i], NULL, thr1, &param[i] ) );

            start = start + ( LOOP / THR );
            cmnUSleep ( 10 );
        }

        for ( i = 0; i < thread_num; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        free_s ( tid );
        free_s ( param );
    }
    _ENDVOID
}


TEST_F ( TFIDX010_10_1, thr2 )
{
    pthread_t* tid = NULL;
    PARAM*  param = NULL;
    int     loop_cnt = LOOP;
    int     thread_num = THR ;
    int     start;
    int     i;

    _TRY
    {
        tid = (pthread_t*) malloc ( sizeof(pthread_t) * thread_num );
        param = (PARAM*) malloc ( sizeof(PARAM) * thread_num );

        start = 0;
        for ( i = 0; i < thread_num; i++ )
        {
            param[i].tid = i;
            param[i].start = start;
            param[i].aCount = 0;

            _CALL( pthread_create ( &tid[i], NULL, thr2, &param[i] ) );

            start = start + ( LOOP / THR );
            cmnUSleep ( 10 );
        }

        for ( i = 0; i < thread_num; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        free_s ( tid );
        free_s ( param );
    }
    _ENDVOID
}


////////////////////////////////////////////////////////////////////////////////
// static functions
////////////////////////////////////////////////////////////////////////////////

void* thr1 ( void *param )
{
    dbmHandle sHandle;
    TABLE   sRow;
    int     nStart, nEnd, aCount;
    cmnTime start, end;
    int     rc;
    int     i;

    _TRY
    {
        aCount = (int) ( ( (PARAM*) param )->aCount );
        nStart = (int) ( ( (PARAM*) param )->start );
        nEnd = nStart + ( LOOP / THR );

        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );
        _CALL( dbmPrepareTable ( &sHandle, (char*) TABLE_NAME ) );

        // Insert
        {
            _PRT( "================ 'insert-delete' [THR:%ld] (start=%d ~ end=%d)\n", pthread_self(), nStart, nEnd );
            cmnTimeGet( &start );

            for ( i = nStart; i < nEnd; i++ )
            {
                sprintf ( sRow.c1, "%019d", i );
                sRow.c2 = i;
                sRow.c3 = i;

                _CALL( dbmInsertRow ( &sHandle, TABLE_NAME, &sRow, sizeof(TABLE) ) );
                _CALL( dbmCommit ( &sHandle ) );
            }

            for ( i = nStart; i < nEnd; i++ )
            {
                sprintf ( sRow.c1, "%019d", i );
                sRow.c2 = i;
                sRow.c3 = i;

                if ( i % 2 == 0 )
                {
                    _CALL( dbmDeleteRow ( &sHandle, TABLE_NAME, &sRow ) );
                    _CALL( dbmCommit ( &sHandle ) );
                }

                if ( i % 100 == 0 )
                    _PRT ( "delete commit [%d] \n", i );
            }

            cmnTimeGet( &end );
            _PRT( "'insert-delete' [THR:%ld] LOOP=%d, i=%8d, Elap=%.9f\n", pthread_self(), LOOP, i, cmnTimeDiff2( start, end ) );
        }

        _CALL( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
}


void* thr2 ( void *param )
{
    dbmHandle sHandle;
    TABLE   sRow;
    int     nStart, nEnd, aCount;
    cmnTime start, end;
    int     rc;
    int     i;

    _TRY
    {
        aCount = (int) ( ( (PARAM*) param )->aCount );
        nStart = (int) ( ( (PARAM*) param )->start );
        nEnd = nStart + ( LOOP / THR );

        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );
        _CALL( dbmPrepareTable ( &sHandle, (char*) TABLE_NAME ) );

        // Insert + Select
        {
            _PRT( "================ 'select' [THR:%ld] (start=%d ~ end=%d)\n", pthread_self(), nStart, nEnd );
            cmnTimeGet( &start );

            int a = 1;
            i = 0;
            sprintf ( sRow.c1, "%019d", 0 );
            sRow.c2 = 0;
            sRow.c3 = 0;
            for ( ;; )
            {
                _CALL( dbmSelectRowGT ( &sHandle, TABLE_NAME, &sRow ) );

                if ( sRow.c2 != a )
                {
                    _PRT ( "GT sRow error [%s]:[%d] \n", sRow.c1, a );
                    exit ( -1 );
                }

                if ( sRow.c2 == 9999 )
                {
                    _PRT ( "GT OK : sRow [%d] \n", sRow.c2 );
                    break;
                }

                a = a + 2;
                i++;
            }

            int b = 9999;
            i = 0;
            sprintf ( sRow.c1, "%019d", LOOP );
            sRow.c2 = LOOP;
            sRow.c3 = LOOP;
            for ( ;; )
            {
                _CALL( dbmSelectRowLT ( &sHandle, TABLE_NAME, &sRow ) );

                if ( sRow.c2 != b )
                {
                    _PRT ( "LT data error [%s]:[%d] \n", sRow.c1, b );
                    exit ( -1 );
                }

                if ( sRow.c2 == 1 )
                {
                    _PRT ( "LT OK : data [%d] \n", sRow.c2 );
                    break;
                }

                b = b - 2;
                i++;
            }

            cmnTimeGet( &end );
            _PRT( "'select' [THR:%ld] LOOP=%d, i=%8d, Elap=%.9f\n", pthread_self(), LOOP, i, cmnTimeDiff2( start, end ) );
        }

        _CALL( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
}


#endif
