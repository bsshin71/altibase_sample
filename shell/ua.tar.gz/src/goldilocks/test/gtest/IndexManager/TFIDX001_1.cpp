/**
 * @file            TFIDX001_1.cpp ( unittest/IndexManager/test_1.cpp )
 *
 * @note
 *  1. 4개 thread를 다른 구간에 대해서 I/S/D 동시 수행
 */
#include "dbmGtestApi.h"

#ifdef _GTEST

#define UNDO_NAME       "TFIDX001_1"
#define TABLE_NAME      "T1"

#define THR             4
#define LOOP            ( 1000 * 1000 * 10 )
//#define LOOP          ( 1000 * 1000 * 1 )


typedef struct TABLE
{
    int c1;
    int c2;
} TABLE;

static void* test1 ( void* );

////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TFIDX001_1 : public testing::Test
{
public:
	static void SetUpTestCase ()
	{
        struct timespec start, end;
        int     nStart, nEnd, aCount;
        char    sSql[1024];
        char    sError[2048];
	    char    buffer[1024];
	    int     rc;
	    int     i;

		_TRY
		{
            ASSERT_EQ( system( "../shl/test.undo.sh TFIDX001_1 > /dev/null 2>&1" ), 0 );
            DBM_INFO ( "Start.. (%s)", UNDO_NAME );

	        _CALL ( dbmInitHandle ( &mDbmHandle, UNDO_NAME ) );

	        // Table creation
	        {
                sprintf ( sSql, "drop table %s", TABLE_NAME );
                _rc = dbmExecuteDDL ( &mDbmHandle, sSql );
                if ( _rc != 0 && _rc != ERR_DBM_TABLE_NOT_IN_DICTIONARY )
                    _THROW ( _rc );

                sprintf ( sSql, "create table %s "
                           "c1 int 10 0 "
                           "c2 int 10 0 "
                           "init 100000 extend 100000 max 20000000", TABLE_NAME );
                _CALL( dbmExecuteDDL ( &mDbmHandle, sSql ) );

                sprintf ( sSql, "create index idx_%s on %s c2", TABLE_NAME, TABLE_NAME );
                _CALL( dbmExecuteDDL ( &mDbmHandle, sSql ) );
	        }

            _CALL( dbmFreeHandle ( &mDbmHandle ) );
		}
		_CATCH
		{
			_CATCH_ERR;
		}
		_FINALLY
		_ENDVOID
	}

	static void TearDownTestCase()
	{
        ASSERT_EQ( system( "../shl/test.undo.sh TFIDX001_1 drop > /dev/null 2>&1" ), 0 );
	    _T_ENDLOG;
	}

	virtual void SetUp()
	{
	}

	virtual void TearDown()
	{
	    _T_SUB_ENDLOG;
	}

    static dbmHandle mDbmHandle;
};

////////////////////////////////////////////////////////////////////////////////
// class static 변수
////////////////////////////////////////////////////////////////////////////////
dbmHandle TFIDX001_1::mDbmHandle;


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

// 4개 thread를 다른 구간에 대해서 I/S/D 동시 수행
TEST_F ( TFIDX001_1, test1 )
{
    pthread_t* tid = NULL;
    PARAM*  param = NULL;
    int     loop_cnt = LOOP;
    int     thread_num = THR ;
    int     i;

    _TRY
    {
        tid = (pthread_t*) malloc ( sizeof(pthread_t) * thread_num );
        param = (PARAM*) malloc ( sizeof(PARAM) * thread_num );

        int start = 0;
        for ( i = 0; i < thread_num; i++ )
        {
            /* start = 0
             * start = 0 + (1000000 /4) --> 250000
             * start = 250000
             * start = 250000 + (1000000/4) --> 500000
             * start = 500000
             * start = 500000 + (1000000/4) --> 750000
             */

            param[i].tid = i;
            param[i].start = start;
            param[i].aCount = _dbm_argc;

            _CALL( pthread_create ( &tid[i], NULL, test1, &param[i] ) );

            start = start + ( LOOP / THR );
            cmnUSleep ( 10 );
        }

        for ( i = 0; i < thread_num; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        free_s ( tid );
        free_s ( param );
    }
    _ENDVOID
}


////////////////////////////////////////////////////////////////////////////////
// static functions
////////////////////////////////////////////////////////////////////////////////

void* test1 ( void *param )
{
    dbmHandle sHandle;
    TABLE   sRow;
    int     nStart, nEnd, aCount;
    cmnTime start, end;
    int     rc;
    int     i;

    _TRY
    {
        aCount = (int) ( ( (PARAM*) param )->aCount );
        nStart = (int) ( ( (PARAM*) param )->start );
        nEnd = nStart + ( LOOP / THR );
        _PRT( "================ [THR:%ld] (start=%d ~ end=%d)\n", pthread_self ( ), nStart, nEnd );

        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );
        _CALL( dbmPrepareTable ( &sHandle, (char*) TABLE_NAME ) );

        // Insert
        {
            cmnTimeGet( &start );
            for ( i = nStart; i < nEnd; i++ )
            {
                sRow.c1 = i;
                sRow.c2 = i;

                _CALL( dbmInsertRow ( &sHandle, TABLE_NAME, (char*)&sRow, sizeof(TABLE) ) );
                _CALL( dbmCommit ( &sHandle ) );

                if ( i != 0 && ( i % 100000 ) == 0 )
                    _PRT( "%d rows inserted.. (err=%d,tid=%d)\n", i - nStart, errno, gettid_s ( ) );
            }
            cmnTimeGet( &end );
            _PRT( "INSERT : LOOP=%d, i=%8d, Elap=%.9f\n", LOOP, i, cmnTimeDiff2( start, end ) );
        }

#if 0
        // Select
        {
            cmnTimeGet( &start );
            for ( i = nStart; i < nEnd; i++ )
            {
                sRow.c1 = i;
                sRow.c2 = i;

                _CALL( dbmSelectRow ( &sHandle, TABLE_NAME, (char*)&sRow ) );

                if ( i != 0 && ( i % 100000 ) == 0 )
                    DBM_INFO( "%d rows select.. (err=%d,tid=%d)", i - nStart, errno, gettid_s ( ) );
            }
            cmnTimeGet( &end );
            _PRT( "SELECT : LOOP=%d, i=%8d, Elap=%.9f\n", LOOP, i, cmnTimeDiff2( start, end ) );
        }
#endif

        // Delete
        {
            DBM_INFO( " *** [%ld] delete start (%d ~ %d) (err=%d,tid=%d)", pthread_self ( ), nStart, nEnd, errno, gettid_s ( ) );
            cmnTimeGet( &start );
            for ( i = nStart; i < nEnd; i++ )
            {
                sRow.c1 = i;
                sRow.c2 = i;

                _CALL( dbmDeleteRow ( &sHandle, TABLE_NAME, (char*)&sRow ) );
                _CALL( dbmCommit ( &sHandle ) );

                if ( i != 0 && ( i % 100000 ) == 0 )
                    DBM_INFO( "delete loop [%d] (err=%d,tid=%d)", i, errno, gettid_s ( ) );
            }
            cmnTimeGet( &end );
            _PRT( "DELETE : LOOP=%d, i=%8d, Elap=%.9f\n", LOOP, i, cmnTimeDiff2( start, end ) );
        }

        _CALL( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
}


#endif
