/**
 * @file            TFIDX001.cpp ( unittest/IndexManager/test1.cpp )
 *
 * @note
 *      [삭제가능할듯]
 *      2가지 쓰레드 ( U / S ) 가 0건 데이타인 테이블을 몇번 조회한다. ERR_DBM_NO_MATCH_RECORD 리턴.
 */
#include "dbmGtestApi.h"

#ifdef _GTEST

#define UNDO_NAME       "TFIDX001"
#define TABLE_NAME      "T1"

#define THR  1
#define LOOP 1000000

typedef struct TABLE
{
    int c1;
    int c2;
    int c3;
} TABLE;

static void* thr1 ( void* );
static void* thr2 ( void* );

////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TFIDX001 : public testing::Test
{
public:
	static void SetUpTestCase ()
	{
        struct timespec start, end;
        int     nStart, nEnd, aCount;
        char    sSql[1024];
        char    sError[2048];
	    char    buffer[1024];
	    int     rc;
	    int     i;

		_TRY
		{
            ASSERT_EQ( system( "../shl/test.undo.sh TFIDX001 > /dev/null 2>&1" ), 0 );
            DBM_INFO ( "Start.. (%s)", UNDO_NAME );

	        _CALL ( dbmInitHandle ( &mDbmHandle, UNDO_NAME ) );

	        // Table creation
	        {
//                dbmDropTable ( &mDbmHandle, TABLE_NAME );
                sprintf ( sSql, "drop table %s", TABLE_NAME );
                _rc = dbmExecuteDDL ( &mDbmHandle, sSql );
                if ( _rc != 0 && _rc != ERR_DBM_TABLE_NOT_IN_DICTIONARY )
                    _THROW ( _rc );

#if 0
                sprintf ( sSql, "create table %s "
                           "c1 char 20 0 "
                           "c2 int 10 0 "
                           "c3 int 10 0 "
                           "init 10000000 extend 1000000 max 12000000",
                           TABLE_NAME );
#else
                sprintf ( sSql, "create table %s "
                           "c1 char 20 0 "
                           "c2 int 10 0 "
                           "c3 int 10 0 "
                           "init 1000 extend 10000 max 12000000",
                           TABLE_NAME );
#endif

                _CALL( dbmExecuteDDL ( &mDbmHandle, sSql ) );

                sprintf ( sSql, "create index idx_%s on %s c2", TABLE_NAME, TABLE_NAME );
                _CALL( dbmExecuteDDL ( &mDbmHandle, sSql ) );
	        }

            _CALL( dbmFreeHandle ( &mDbmHandle ) );
		}
		_CATCH
		{
			_CATCH_ERR;
		}
		_FINALLY
		_ENDVOID
	}

	static void TearDownTestCase()
	{
        ASSERT_EQ( system( "../shl/test.undo.sh TFIDX001 drop > /dev/null 2>&1" ), 0 );
	    _T_ENDLOG;
	}

	virtual void SetUp()
	{
	}

	virtual void TearDown()
	{
	    _T_SUB_ENDLOG;
	}

    static dbmHandle mDbmHandle;
};

////////////////////////////////////////////////////////////////////////////////
// class static 변수
////////////////////////////////////////////////////////////////////////////////
dbmHandle TFIDX001::mDbmHandle;


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

// 2가지 종류의 N*2 쓰레드가 경합 테스트.
TEST_F ( TFIDX001, dummy_sel_upd )
{
    pthread_t* tid = NULL;
    PARAM*  param = NULL;
    int     loop_cnt = LOOP;
    int     thread_num = THR * 2;
    int     i;

    _TRY
    {
        tid = (pthread_t*) malloc ( sizeof(pthread_t) * thread_num );
        param = (PARAM*) malloc ( sizeof(PARAM) * thread_num );

        int start = 0;
        for ( i = 0; i < thread_num; )
        {
            param[i].start = start;
            param[i].aCount = 0;
            _CALL( pthread_create ( &tid[i], NULL, thr1, &param[i] ) );

            i++;
            param[i].start = start;
            param[i].aCount = 0;
            _CALL( pthread_create ( &tid[i], NULL, thr2, &param[i] ) );
            i++;

//            start = start + ( loop_cnt / thread_num / 2 );
        }

        for ( i = 0; i < thread_num; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        free_s ( tid );
        free_s ( param );
    }
    _ENDVOID
}


////////////////////////////////////////////////////////////////////////////////
// static functions
////////////////////////////////////////////////////////////////////////////////

void* thr1 ( void *param )
{
    dbmHandle sHandle;
    char    sError[1024];
    TABLE   sRow;
    int     nStart, nEnd, aCount;
    cmnTime start, end;
    int     rc;
    int     i;

    _TRY
    {
        aCount = (int) ( ( (PARAM*) param )->aCount );
        nStart = (int) ( ( (PARAM*) param )->start );
        nEnd = nStart + ( LOOP / THR );
        _PRT( "================ [THR:%ld] (start=%d ~ end=%d)\n", pthread_self ( ), nStart, nEnd );

        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );
        _CALL( dbmPrepareTable ( &sHandle, (char*) TABLE_NAME ) );

        cmnTimeGet( &start );
        for ( i = 1; i <= 4; i++ )
        {
            memset ( &sRow, 0x00, sizeof(TABLE) );
            sRow.c1 = i;
            sRow.c2 = i + 1;
            sRow.c3 = i;

            // ERR_DBM_NO_MATCH_RECORD : 1027
            rc = dbmUpdateRow ( &sHandle, (char*) TABLE_NAME, &sRow );
            EXPECT_EQ( rc, ERR_DBM_NO_MATCH_RECORD );
            cmnUSleep ( 10 );
#if 0
            if (i !=0 && (i % 10000) == 0) _PRT( "%d rows inserted..\n", i - nStart);
#endif
        }
        _PRT( "Update Sleep...\n" );
        cmnUSleep ( 10 * ( 10 - 4 ) );
        cmnTimeGet( &end );

        _PRT( "UPDATE : LOOP=%d, i=%8d, Elap=%.9f\n", LOOP, i, cmnTimeDiff2( start, end ) );

        memset ( &sRow, 0x00, sizeof( sRow ) );
        sRow.c1 = 1;
        rc = dbmSelectRowGT ( &sHandle, (char*) TABLE_NAME, &sRow );
        _PRT( "rc = %d, data.c1 = (%d, %d, %d)\n", rc, sRow.c1, sRow.c2, sRow.c3 );

        _CALL( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
}


void* thr2 ( void *param )
{
    dbmHandle sHandle;
    char    sError[1024];
    TABLE   sRow;
    int     nStart, nEnd, aCount;
    cmnTime start, end;
    int     rc;
    int     i;

    _TRY
    {
        aCount = (int) ( ( (PARAM*) param )->aCount );
        nStart = (int) ( ( (PARAM*) param )->start );
        nEnd = nStart + ( LOOP / THR );
        _PRT( "================ [THR:%ld] (start=%d ~ end=%d)\n", pthread_self ( ), nStart, nEnd );

        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );
//      _CALL_TM( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );
        _CALL( dbmPrepareTable ( &sHandle, (char*) TABLE_NAME ) );

        cmnTimeGet( &start );
        for ( i = 1; i < 10; i++ )
        {
            memset ( &sRow, 0x00, sizeof(TABLE) );
            sRow.c1 = i;

            rc = dbmSelectRow ( &sHandle, (char*) TABLE_NAME, &sRow );
            EXPECT_EQ( rc, ERR_DBM_NO_MATCH_RECORD );
            _PRT( "%d ==> (%d, %d, %d)\n", i, sRow.c1, sRow.c2, sRow.c3 );
            cmnUSleep ( 10 );
        }
        cmnTimeGet( &end );

//        _PRT( "LOOP=%d, i=%d, Elap=%.9f\n", LOOP, i, (double) ( ( end.tv_sec + end.tv_nsec / 1000000000.0 ) - ( start.tv_sec + start.tv_nsec / 1000000000.0 ) ) );
        _PRT( "SELECT : LOOP=%d, i=%8d, Elap=%.9f\n", LOOP, i, cmnTimeDiff2( start, end ) );

        _CALL( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
}


#endif
