/**
 * @file            TFIDX010.cpp ( unittest/IndexManager/test10.cpp )
 *
 * @note
 *  1. 4개 thread가 I-D/S 다른 구간 동시 수행
 */
#include "dbmGtestApi.h"

#ifdef _GTEST

#define UNDO_NAME       "TFIDX010"
#define TABLE_NAME      "T1"

#define THR             4
#define LOOP            ( 1000 * 1000 * 1 )
//#define LOOP          ( 1000 * 1000 * 1 )

typedef struct TABLE
{
    int     c1;
} TABLE;

static void* thr1 ( void* );
static void* thr2 ( void* );

////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TFIDX010 : public testing::Test
{
public:
	static void SetUpTestCase ()
	{
        struct timespec start, end;
        int     nStart, nEnd, aCount;
        char    sSql[1024];
        char    sError[2048];
	    char    buffer[1024];
	    int     rc;
	    int     i;

		_TRY
		{
            ASSERT_EQ( system( "../shl/test.undo.sh TFIDX010 > /dev/null 2>&1" ), 0 );
            DBM_INFO ( "Start.. (%s)", UNDO_NAME );

	        _CALL ( dbmInitHandle ( &mDbmHandle, UNDO_NAME ) );

	        // Table creation
	        {
                sprintf ( sSql, "drop table %s", TABLE_NAME );
                _rc = dbmExecuteDDL ( &mDbmHandle, sSql );
                if ( _rc != 0 && _rc != ERR_DBM_TABLE_NOT_IN_DICTIONARY )
                    _THROW ( _rc );

                sprintf ( sSql, "create table %s ( "
                          "c1 int ) "
                          "init 10000000 extend 3000000 max 11000000", TABLE_NAME );
                _CALL( dbmExecuteDDL ( &mDbmHandle, sSql ) );

                sprintf ( sSql, "create index idx_%s on %s ( c1 )", TABLE_NAME, TABLE_NAME );
                _CALL( dbmExecuteDDL ( &mDbmHandle, sSql ) );
	        }

            _CALL( dbmFreeHandle ( &mDbmHandle ) );
		}
		_CATCH
		{
			_CATCH_ERR;
		}
		_FINALLY
		_ENDVOID
	}

	static void TearDownTestCase()
	{
        ASSERT_EQ( system( "../shl/test.undo.sh TFIDX010 drop > /dev/null 2>&1" ), 0 );
	    _T_ENDLOG;
	}

	virtual void SetUp()
	{
	}

	virtual void TearDown()
	{
	    _T_SUB_ENDLOG;
	}

    static dbmHandle mDbmHandle;
};

////////////////////////////////////////////////////////////////////////////////
// class static 변수
////////////////////////////////////////////////////////////////////////////////
dbmHandle TFIDX010::mDbmHandle;


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

TEST_F ( TFIDX010, thr1 )
{
    pthread_t* tid = NULL;
    PARAM*  param = NULL;
    int     loop_cnt = LOOP;
    int     thread_num = THR ;
    int     start;
    int     i;

    _TRY
    {
        tid = (pthread_t*) malloc ( sizeof(pthread_t) * thread_num );
        param = (PARAM*) malloc ( sizeof(PARAM) * thread_num );

        start = 0;
        for ( i = 0; i < thread_num; i++ )
        {
            param[i].tid = i;
            param[i].start = start;
            param[i].aCount = 0;

            _CALL( pthread_create ( &tid[i], NULL, thr1, &param[i] ) );

            start = start + ( LOOP / THR );
            cmnUSleep ( 10 );
        }

        for ( i = 0; i < thread_num; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        free_s ( tid );
        free_s ( param );
    }
    _ENDVOID
}


TEST_F ( TFIDX010, thr2 )
{
    pthread_t* tid = NULL;
    PARAM*  param = NULL;
    int     loop_cnt = LOOP;
    int     thread_num = THR ;
    int     start;
    int     i;

    _TRY
    {
        tid = (pthread_t*) malloc ( sizeof(pthread_t) * thread_num );
        param = (PARAM*) malloc ( sizeof(PARAM) * thread_num );

        start = 0;
        for ( i = 0; i < thread_num; i++ )
        {
            param[i].tid = i;
            param[i].start = start;
            param[i].aCount = 0;

            _CALL( pthread_create ( &tid[i], NULL, thr2, &param[i] ) );

            start = start + ( LOOP / THR );
            cmnUSleep ( 10 );
        }

        for ( i = 0; i < thread_num; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    {
        free_s ( tid );
        free_s ( param );
    }
    _ENDVOID
}


////////////////////////////////////////////////////////////////////////////////
// static functions
////////////////////////////////////////////////////////////////////////////////

void* thr1 ( void *param )
{
    dbmHandle sHandle;
    TABLE   sRow;
    int     nStart, nEnd, aCount;
    cmnTime start, end;
    int     rc;
    int     i;

    _TRY
    {
        aCount = (int) ( ( (PARAM*) param )->aCount );
        nStart = (int) ( ( (PARAM*) param )->start );
        nEnd = nStart + ( LOOP / THR );

        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );
        _CALL( dbmPrepareTable ( &sHandle, (char*) TABLE_NAME ) );

        // Insert
        {
            _PRT( "================ 'insert' [THR:%ld] (start=%d ~ end=%d)\n", pthread_self(), nStart, nEnd );
            cmnTimeGet( &start );
            for ( i = nStart; i < nEnd; i++ )
            {
                sRow.c1 = i;

                _CALL( dbmInsertRow ( &sHandle, TABLE_NAME, &sRow, sizeof(TABLE) ) );
                _CALL( dbmCommit ( &sHandle ) );

                if ( i != nStart && ( i % 100000 ) == 0 )
                    _PRT( "%s %d rows inserted.. (err=%d,tid=%d)\n",
                          cmnTime2Str( strlen("hh:mi:ss.ssssss") + 1 ), i - nStart, errno, gettid_s ( ) );
            }
            cmnTimeGet( &end );
            _PRT( "'insert' [THR:%ld] LOOP=%d, i=%8d, Elap=%.9f\n", pthread_self(), LOOP, i, cmnTimeDiff2( start, end ) );
        }

        _CALL( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
}


void* thr2 ( void *param )
{
    dbmHandle sHandle;
    TABLE   sRow;
    int     nStart, nEnd, aCount;
    cmnTime start, end;
    int     rc;
    int     i;

    _TRY
    {
        aCount = (int) ( ( (PARAM*) param )->aCount );
        nStart = (int) ( ( (PARAM*) param )->start );
        nEnd = nStart + ( LOOP / THR );

        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );
        _CALL( dbmPrepareTable ( &sHandle, (char*) TABLE_NAME ) );

        // Insert + Select
        {
            _PRT( "================ 'select' [THR:%ld] (start=%d ~ end=%d)\n", pthread_self(), nStart, nEnd );
            cmnTimeGet( &start );
            for ( i = nStart; i < nEnd; i++ )
            {
                sRow.c1 = i;

                rc = dbmSelectRowGT ( &sHandle, TABLE_NAME, &sRow );
                _TEST_THROW( rc == 0 || rc == ERR_DBM_NO_MATCH_RECORD, rc );
                if ( rc == ERR_DBM_NO_MATCH_RECORD )
                {
                    _PRT( "SelectRowGT 정상 MA 종료 data not found CNT[%d]\n", i);
                    break;
                }

                _CALL( dbmSelectRowLT ( &sHandle, TABLE_NAME, &sRow ) );
            }
            cmnTimeGet( &end );
            _PRT( "'select' [THR:%ld] LOOP=%d, i=%8d, Elap=%.9f\n", pthread_self(), LOOP, i, cmnTimeDiff2( start, end ) );
        }

        _CALL( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
}


#endif
