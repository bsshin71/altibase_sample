/**
 * @file            TFIDX026.cpp ( unittest/IndexManager/test26.cpp )
 *
 * @note
 *  1. insert insert 단위 테스트 process(key char,int)
 */
#include "dbmGtestApi.h"

#ifdef _GTEST

#define UNDO_NAME       "TFIDX026"
#define TABLE_NAME      "T1"

#define THR             1
#define LOOP            ( 1000 * 1000 * 1 )

typedef struct TABLE
{
    char c1[20];
    int c2;
    int c3;
} TABLE;


////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////
class TFIDX026 : public testing::Test
{
public:
	static void SetUpTestCase ()
	{
        struct timespec start, end;
        int     nStart, nEnd, aCount;
        char    sSql[1024];
        char    sError[2048];
	    char    buffer[1024];
	    int     rc;
	    int     i;

		_TRY
		{
            ASSERT_EQ( system( "../shl/test.undo.sh TFIDX026 > /dev/null 2>&1" ), 0 );
            DBM_INFO ( "Start.. (%s)", UNDO_NAME );

	        _CALL ( dbmInitHandle ( &mDbmHandle, UNDO_NAME ) );

	        // Table creation
	        {
                sprintf ( sSql, "drop table %s", TABLE_NAME );
                _rc = dbmExecuteDDL ( &mDbmHandle, sSql );
                if ( _rc != 0 && _rc != ERR_DBM_TABLE_NOT_IN_DICTIONARY )
                    _THROW ( _rc );

                sprintf ( sSql, "create table %s ( "
                          "c1 char(20) , "
                          "c2 int , "
                          "c3 int ) "
                          "init 500000 extend 500000 max 11000000", TABLE_NAME );
                _CALL( dbmExecuteDDL ( &mDbmHandle, sSql ) );

                sprintf ( sSql, "create index idx_%s on %s ( c1, c2 )", TABLE_NAME, TABLE_NAME );
                _CALL( dbmExecuteDDL ( &mDbmHandle, sSql ) );
	        }

            _CALL( dbmFreeHandle ( &mDbmHandle ) );
		}
		_CATCH
		{
			_CATCH_ERR;
		}
		_FINALLY
		_ENDVOID
	}

	static void TearDownTestCase()
	{
        ASSERT_EQ( system( "../shl/test.undo.sh TFIDX026 drop > /dev/null 2>&1" ), 0 );
	    _T_ENDLOG;
	}

	virtual void SetUp()
	{
	}

	virtual void TearDown()
	{
	    _T_SUB_ENDLOG;
	}

    static dbmHandle mDbmHandle;
};

////////////////////////////////////////////////////////////////////////////////
// class static 변수
////////////////////////////////////////////////////////////////////////////////
dbmHandle TFIDX026::mDbmHandle;


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

TEST_F ( TFIDX026, test26 )
{
    dbmHandle sHandle;
    TABLE   sRow;
    int     loop_cnt = LOOP;
    int     thread_num = THR ;
    int     rc;
    int     i;

    _TRY
    {
        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );
        _CALL( dbmPrepareTable ( &sHandle, (char*) TABLE_NAME ) );

        // insert
        {
            memset ( &sRow, 0x00, sizeof(sRow) );

            _CALL( cmnInitTimer ( &_tc_timer, UNIT_NANO, 500, 500, 20 ) );

            for ( i = 0; i < loop_cnt; i++ )
            {
                sprintf ( sRow.c1, "%d", i );
                sRow.c2 = i;

                _CALL( cmnStartTimer ( _tc_timer ) );

                _CALL( dbmInsertRow ( &sHandle, TABLE_NAME, &sRow, sizeof(TABLE) ) );
                _CALL( dbmCommit ( &sHandle ) );

                _CALL( cmnEndTimer ( _tc_timer ) );

                if ( i % 100000 == 0 )
                    _PRT ( "count : %d\n", i );
            }

            _CALL( cmnElapseTimer ( _tc_timer, loop_cnt, (char*) "TFIDX026" ) );
            _CALL( cmnFinalTimer ( &_tc_timer ) );
        }

        // select
        {
            memset ( &sRow, 0x00, sizeof(sRow) );

            _CALL( cmnInitTimer ( &_tc_timer, UNIT_NANO, 500, 500, 20 ) );

            for ( i = 0; i < loop_cnt; i++ )
            {
                sprintf ( sRow.c1, "%d", i );
                sRow.c2 = i;

                _CALL( cmnStartTimer ( _tc_timer ) );
                _CALL( dbmSelectRow ( &sHandle, TABLE_NAME, &sRow ) );
                _CALL( cmnEndTimer ( _tc_timer ) );

                if ( i % 100000 == 0 )
                    _PRT ( "count : %d\n", i );
            }

            _CALL( cmnElapseTimer ( _tc_timer, loop_cnt, (char*) "TFIDX026" ) );
            _CALL( cmnFinalTimer ( &_tc_timer ) );
        }

        // delete
        {
            memset ( &sRow, 0x00, sizeof(sRow) );

            _CALL( cmnInitTimer ( &_tc_timer, UNIT_NANO, 500, 500, 20 ) );

            for ( i = 0; i < loop_cnt; i++ )
            {
                sprintf ( sRow.c1, "%d", i );
                sRow.c2 = i;

                _CALL( cmnStartTimer ( _tc_timer ) );

                _CALL( dbmDeleteRow ( &sHandle, TABLE_NAME, &sRow ) );
                _CALL( dbmCommit ( &sHandle ) );

                _CALL( cmnEndTimer ( _tc_timer ) );

                if ( i % 100000 == 0 )
                    _PRT ( "count : %d\n", i );
            }

            _CALL( cmnElapseTimer ( _tc_timer, loop_cnt, (char*) "TFIDX026" ) );
            _CALL( cmnFinalTimer ( &_tc_timer ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}


#endif
