/**
 * @file            TBKPB001.cpp ( unittest/koscom_bmt )
 *
 * @note
 *      [삭제가능할듯]
 *      2가지 쓰레드 ( U / S ) 가 0건 데이타인 테이블을 몇번 조회한다. ERR_DBM_NO_MATCH_RECORD 리턴.
 */
#include "dbmGtestApi.h"

#ifdef _GTEST

#define UNDO_NAME       "TBKPB001"

#define THR  2
//#define LOOP 1000000

#ifdef _DEBUG
#define CNT100          20
#define CNT10           2
#else
#define CNT100          100
#define CNT10           10
#endif

#define LOOP 5000
#define MAX  5000

typedef struct qPARAM
{
    char queName[50];
    char id[50];
} qPARAM;

typedef struct qData
{
    int id;
    struct timespec start;
    char msg[401];
} qData;


static void* thr_prepare ( void* );
static void* thr_deqStep1( void* param );
static void* thr_deqStep2( void* param );
static void* thr_deqTrig( void* param );

////////////////////////////////////////////////////////////////////////////////
// class
////////////////////////////////////////////////////////////////////////////////

class TBKPB001 : public testing::Test
{
public:
	static void SetUpTestCase ()
	{
        struct timespec start, end;
        int     nStart, nEnd, aCount;
        char    sSql[1024];
        char    sError[2048];
	    char    buffer[1024];
	    int     rc;
	    int     i;

		_TRY
		{
            ASSERT_EQ( system( "../shl/test.undo.sh TBKPB001 > /dev/null 2>&1" ), 0 );
            DBM_INFO ( "Start.. (%s)", UNDO_NAME );
		}
		_CATCH
		{
			_CATCH_ERR;
		}
		_FINALLY
		_ENDVOID
	}

	static void TearDownTestCase()
	{
//        ASSERT_EQ( system( "../shl/test.undo.sh TBKPB001 drop > /dev/null 2>&1" ), 0 );
	    _T_ENDLOG;
	}

	virtual void SetUp()
	{
	}

	virtual void TearDown()
	{
	    _T_SUB_ENDLOG;
	}

    static dbmHandle mDbmHandle;
};


////////////////////////////////////////////////////////////////////////////////
// class static 변수
////////////////////////////////////////////////////////////////////////////////
dbmHandle TBKPB001::mDbmHandle;


////////////////////////////////////////////////////////////////////////////////
// 테스트 케이스
////////////////////////////////////////////////////////////////////////////////

TEST_F ( TBKPB001, prepare )
{
    dbmHandle sHandle;
    qData     qdata;
    qPARAM     param[101];
    pthread_t tid[101];
    char      sTable[33];
    char      sSql[1024];
    int       rc;
    int       i;
    int       j;

    _TRY
    {
        _PRT( "## Prepare all tables ##" );

        _CALL( dbmInitHandle ( &sHandle, UNDO_NAME ) );

        // 2014.12.14. -okt- ERR_DBM_INVALID_OPERATION, 1028 발생함. 왜?
#if 0
        /**********************************************
         * Drop Que Table
         **********************************************/
        printf ( "drop que table\n" );
        for ( i = 1; i <= CNT100; i++ )
        {
            sprintf ( sSql, "source_que%d", i );
            rc = dbmDropTable ( &sHandle, sSql );
        }

        for ( i = 1; i <= CNT10; i++ )
        {
            sprintf ( sSql, "target_que%d", i );
            rc = dbmDropTable ( &sHandle, sSql );

            sprintf ( sSql, "last_que%d", i );
            rc = dbmDropTable ( &sHandle, sSql );

            sprintf ( sSql, "last_table%d", i );
            rc = dbmDropTable ( &sHandle, sSql );

            sprintf ( sSql, "trig%d", i );
            rc = dbmDropTable ( &sHandle, sSql );
        }
#endif
        /**********************************************
         * Create Que Table
         **********************************************/
        printf ( "create source que table\n" );
        for ( i = 1; i <= CNT100; i++ )
        {
            sprintf ( sSql, "create queue source_que%d msgsize 700 init %d extend 1 max %d", i, MAX, MAX );
            _CALL( dbmExecuteDDL ( &sHandle, sSql ) );
        }

        printf ( "create target, last que table\n" );
        for ( i = 1; i <= CNT10; i++ )
        {
            sprintf ( sSql, "create queue target_que%d msgsize 700 init %d extend 1 max %d", i, ( LOOP * 9 + MAX ), ( LOOP * 9 + MAX ) );
            _CALL( dbmExecuteDDL ( &sHandle, sSql ) );

            sprintf ( sSql, "create queue last_que%d msgsize 700 init %d extend 1 max %d", i, ( LOOP * 9 + MAX ), ( LOOP * 9 + MAX ) );
            _CALL( dbmExecuteDDL ( &sHandle, sSql ) );

            //if ( _dbm_argc > 1 )  //TODO: 항상 아닌가? 물어볼것.
            {
                sprintf ( sSql, "create queue trig%d msgsize 700 init 100000 extend 1 max 100000", i );
                _CALL( dbmExecuteDDL ( &sHandle, sSql ) );
            }
        }

        for ( i = 1; i <= CNT10; i++ )
        {
            sprintf ( sSql, "create table last_table%d ("
                      "id int , "
                      "msg char(500) ) "
                      "init %d extend %d max %d",
                      i, ( LOOP * 9 + MAX ), ( LOOP * 9 + MAX ), ( ( LOOP * 9 + MAX ) * 2 ) );
            _CALL( dbmExecuteDDL ( &sHandle, sSql ) );

            sprintf ( sSql, "create index idx_last_table%d on last_table%d id\n", i, i );
            _CALL( dbmExecuteDDL ( &sHandle, sSql ) );

            // TODO: 트리거 미적용 - oracle 에 반영하는 속도 병목으로 ( 2014/05/29 )
#if 0
            //if (argc > 1)
            {
                memset(sSql, 0x00, sizeof(sSql));
                sprintf(sSql, "create trigger last_table%d oracle\n", i);
                rc = dbmExecuteDDL(&sHandle, sSql);
                ErrorHandle(rc, "create Trigger");
            }
#endif
        }

        /**********************************************
         * Insert into source Que Table
         **********************************************/
        for ( i = 1; i <= CNT100; i++ )
        {
            sprintf ( param[i].queName, "source_que%d", i );
            sprintf ( param[i].id, "%d", i );

            _CALL( pthread_create ( &tid[i], NULL, thr_prepare, &param[i] ) );
        }

        for ( i = 1; i <= CNT100; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }

        printf ( "Complete job\n" );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

/*
 * TODO: 원래는 각각의 process 구성이고 pkill을 하는 것이다. 이를 GTEST에서 구현하기 어려워서 pthread_cancel를 사용했으므로
 *
 */
#define _KILLTEST

TEST_F ( TBKPB001, deqStep2_deqTrig_deqStep1 )
{
    pthread_t tid_deqStep1  [ THR + 1 ];
    pthread_t tid_deqStep2  [ THR + 1 ];
    pthread_t tid_deqTrig   [ THR + 1 ];
    PARAM*  param = NULL;
    int     rc;
    int     i;

    _TRY
    {
        param = (PARAM*) malloc ( sizeof(PARAM) * THR );

        _PRT( "## launch step1 process ##\n" );
        for ( i = 1; i <= THR; i++ )
        {
            param[i].tid = i;

            _CALL( pthread_create ( &tid_deqStep2[i], NULL, thr_deqStep2, &param[i] ) );
            _CALL( pthread_create ( &tid_deqTrig[i], NULL, thr_deqTrig, &param[i] ) );
            cmnUSleep ( 10 );
        }

        _PRT( "## launch step2 process ##\n" );
        for ( i = 1; i <= THR; i++ )
        {
            param[i].tid = i;
            param[i].start = i + THR;

            _CALL( pthread_create ( &tid_deqStep1[i], NULL, thr_deqStep1, &param[i] ) );
            cmnUSleep ( 10 );
        }

#ifdef _KILLTEST
        sleep ( 1 );
        pthread_t sTid;
        for ( i = 1; i <= THR; i++ )
        {
            sTid = tid_deqStep1[i];
            rc = pthread_cancel ( sTid );
            _TEST_THROW ( rc == 0 || rc == ESRCH, rc )
            rc = pthread_join ( sTid, NULL );
            _TEST_THROW ( rc == 0 || rc == ESRCH, rc )

            sTid = tid_deqStep2[i];
            rc = pthread_cancel ( sTid );
            _TEST_THROW ( rc == 0 || rc == ESRCH, rc )
            rc = pthread_join ( sTid, NULL );
            _TEST_THROW ( rc == 0 || rc == ESRCH, rc )

            sTid = tid_deqTrig[i];
            rc = pthread_cancel ( sTid );
            _TEST_THROW ( rc == 0 || rc == ESRCH, rc )
            rc = pthread_join ( sTid, NULL );
            _TEST_THROW ( rc == 0 || rc == ESRCH, rc )
        }
#else
        for ( i = 1; i <= THR; i++ )
        {
            _CALL( pthread_join ( tid_deqStep1[i], NULL ) );
            _CALL( pthread_join ( tid_deqStep2[i], NULL ) );
            _CALL( pthread_join ( tid_deqTrig[i], NULL ) );
        }
#endif
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}

#ifdef _KILLTEST
TEST_F ( TBKPB001, reStart )
{
    pthread_t tid_deqStep1  [ THR + 1 ];
    pthread_t tid_deqStep2  [ THR + 1 ];
    pthread_t tid_deqTrig   [ THR + 1 ];
    PARAM*  param = NULL;
    int     i;

    _TRY
    {
        _PRT( "\n\n" );
        _PRT( "########################################\n" );
        _PRT( "## KILL 이후에 동일 업무 재수행.!!\n" );
        _PRT( "########################################\n" );

        param = (PARAM*) malloc ( sizeof(PARAM) * THR );

        _PRT( "## launch step1 process ##\n" );
        for ( i = 1; i <= THR; i++ )
        {
            param[i].tid = i;

            _CALL( pthread_create ( &tid_deqStep2[i], NULL, thr_deqStep2, &param[i] ) );
            _CALL( pthread_create ( &tid_deqTrig[i], NULL, thr_deqTrig, &param[i] ) );
            cmnUSleep ( 10 );
        }

        _PRT( "## launch step2 process ##\n" );
        for ( i = 1; i <= THR; i++ )
        {
            param[i].tid = i;
            param[i].start = i + THR;

            _CALL( pthread_create ( &tid_deqStep1[i], NULL, thr_deqStep1, &param[i] ) );
            cmnUSleep ( 10 );
        }

        for ( i = 1; i <= THR; i++ )
        {
            _CALL( pthread_join ( tid_deqStep1[i], NULL ) );

            _CALL( pthread_join ( tid_deqStep2[i], NULL ) );
            _CALL( pthread_join ( tid_deqTrig[i], NULL ) );
        }
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDVOID
}
#endif


////////////////////////////////////////////////////////////////////////////////
// static functions
////////////////////////////////////////////////////////////////////////////////


void* thr_prepare ( void *param )
{
    dbmHandle sHandle;
    qData   qdata;
    char    sTable[128];
    int     j, rc, count;
    int     ix;

    _TRY
    {
        sprintf ( sTable, "%s", ( (qPARAM*) param )->queName );
        ix = atoi ( ( (qPARAM*) param )->id );
        _PRT( "================ 'prepare' [THR%02d:%d] enque into %s start...\n", ix, gettid_s(), sTable );

        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );
        _CALL( dbmPrepareTable ( &sHandle, sTable ) );


        count = LOOP;
        if ( ix % CNT10 == 0 )
        {
            count = MAX;
            for ( j = 10000001; j <= ( 10000000 + count ); j++ )
            {
                memset ( &qdata, 0x00, sizeof( qdata ) );
                qdata.id = j;
                sprintf ( qdata.msg, "%0400d", j );

                _CALL( dbmEnqueue ( &sHandle, sTable, &qdata, sizeof( qdata ) ) );
                _CALL( dbmCommit ( &sHandle ) );
            }
        }
        else
        {
            for ( j = 1; j <= count; j++ )
            {
                memset ( &qdata, 0x00, sizeof( qdata ) );
                qdata.id = ix * count + j;
                sprintf ( qdata.msg, "%0400d", j );

                _CALL( dbmEnqueue ( &sHandle, sTable, &qdata, sizeof( qdata ) ) );
                _CALL( dbmCommit ( &sHandle ) );
            }
        }

    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
}


void* thr_deqStep2( void* param )
{
    dbmHandle  sHandle;
    char       sBuffer[800];
    char       errmsg[1024];
    qData      data;
    int        rc;
    int        i=0;
    int        out=0;
    struct timespec start, end;

    char    gUser       [33];
    char    gSrcQueName [33];
    char    gTarQueName [33];
    char    gInsTable   [33];
    char    gTrigQue    [33];
    int     gApiNo      ;

    int     ix;


    _TRY
    {
        ix = (int) ( ( (PARAM*) param )->tid );
        sprintf ( gSrcQueName, "target_que%d", ix );
        sprintf ( gTarQueName, "last_que%d"  , ix );
        sprintf ( gInsTable  , "last_table%d", ix );
        sprintf ( gTrigQue   , "trig%d"      , ix );
        _PRT( "================ 'deqStep2' [THR%0d:%d] Start... (%s)\n", ix, gettid_s(), gSrcQueName );

        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );

        _PRT( "[THR:%d] gSrcQueName=%s, rc=%d\n", gettid_s(), gSrcQueName, _rc );
        _CALL( dbmPrepareTable ( &sHandle, gSrcQueName ) );
        _CALL( dbmPrepareTable ( &sHandle, gTarQueName ) );
        _CALL( dbmPrepareTable ( &sHandle, gInsTable ) );
        _CALL( dbmPrepareTable ( &sHandle, gTrigQue ) );

        /*******************************************
         * Act
         *******************************************/
        clock_gettime_s ( CLOCK_REALTIME, &start );
        while ( 1 )
        {
repeat:
            /*******************************************
             * Deque
             *******************************************/
            rc = dbmDequeue ( &sHandle, gSrcQueName, &data, 10000000 );
            if ( rc == ERR_DBM_NO_MATCH_RECORD )
            {
                if ( out++ >= 3 )
                    break;
                continue;
            }
            _IF_THROW( rc, -1 );

            if ( i == 0 )
            {
                memcpy ( &start, &data.start, sizeof(struct timespec) );
            }

            _CALL( dbmInsertRow ( &sHandle, gInsTable, &data, sizeof( data ) ) );
            _CALL( dbmEnqueue ( &sHandle, gTarQueName, &data, sizeof( data ) ) );

            //TODO: trigger이 없어서임시로 enque 처리 함. Enque target
            _CALL( dbmEnqueue ( &sHandle, gTrigQue, &data, sizeof( data ) ) );

            _CALL( dbmCommit ( &sHandle ) );
        }
        clock_gettime_s ( CLOCK_REALTIME, &end );
        printf ( "deqStep2: total Time = %.9f\n",
                 ( end.tv_sec + end.tv_nsec / 1000000000.0 ) - ( start.tv_sec + start.tv_nsec / 1000000000.0 ) );

        _CALL( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
} /* thr_deqStep2 */


void* thr_deqTrig( void* param )
{
    dbmHandle  sHandle;
    char       sBuffer[800];
    char       errmsg[1024];
    qData      data;
    int        rc;
    int        i=0;
    int        out=0;
    struct timespec start, end;

    char    gUser       [33];
    char    gSrcQueName [33];
    char    gTarQueName [33];
    char    gInsTable   [33];
    char    gTrigQue    [33];
    int     gApiNo      ;

    int     ix;


    _TRY
    {
        ix = (int) ( ( (PARAM*) param )->tid );
        sprintf ( gSrcQueName, "target_que%d", ix );
        sprintf ( gTarQueName, "last_que%d"  , ix );
        sprintf ( gInsTable  , "last_table%d", ix );
        sprintf ( gTrigQue   , "trig%d"      , ix );
        _PRT( "================ 'deqTrig' [THR%02d:%d] Start... (%s)\n", ix, gettid_s(), gTrigQue );

        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );
        _CALL( dbmPrepareTable ( &sHandle, gTrigQue ) );

        /*******************************************
         * Act ( Deque )
         *******************************************/
        clock_gettime_s ( CLOCK_REALTIME, &start );
        while ( 1 )
        {
repeat:
            rc = dbmDequeue ( &sHandle, gTrigQue, &data, 10000000 );
            if ( rc == ERR_DBM_NO_MATCH_RECORD )
            {
                if ( out++ >= 3 )
                    break;

                _PRT( "[THR:%d] gTrigQue=%s, data=%d\n", gettid_s(), gTrigQue, data.id );
                continue;
            }
            _IF_THROW( rc, -1 );

            _CALL( dbmCommit ( &sHandle ) );
        }

        clock_gettime_s ( CLOCK_REALTIME, &end );
        printf ( "deqStep2: total Time = %.9f\n",
                 ( end.tv_sec + end.tv_nsec / 1000000000.0 ) - ( start.tv_sec + start.tv_nsec / 1000000000.0 ) );

        _CALL( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {

       _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
} /* thr_deqTrig */


void* thr_deqStep1( void* param )
{
    dbmHandle  sHandle;
    char       sBuffer[800];
    char       errmsg[1024];
    qData      data;
    int        rc;
    int        i=0;
    int        out=0;
    struct timespec start, end;

    char    gUser       [33];
    char    gSrcQueName [33];
    char    gTarQueName [33];
    char    gInsTable   [33];
    char    gTrigQue    [33];

    int     gApiNo      ;
    int     ix;


    _TRY
    {
        ix = (int) ( ( (PARAM*) param )->tid );
        gApiNo = (int) ( ( (PARAM*) param )->start );
        sprintf ( gSrcQueName, "source_que%d", gApiNo );
        sprintf ( gTarQueName, "target_que%d"  , ix );
        _PRT( "================ 'deqTrig' [THR%02d:%d] Start... (%s)\n", ix, gettid_s(), gSrcQueName );

        _CALL( dbmInitHandle ( &sHandle, (char*) UNDO_NAME ) );

        _PRT( "[THR:%d] gSrcQueName=%s, rc=%d\n", gettid_s(), gSrcQueName, _rc );
        _CALL( dbmPrepareTable ( &sHandle, gSrcQueName ) );
        _CALL( dbmPrepareTable ( &sHandle, gTarQueName ) );

        /*******************************************
         * Act
         *******************************************/
        clock_gettime_s ( CLOCK_REALTIME, &start );
        while ( 1 )
        {
repeat:
            /*******************************************
             * Deque
             *******************************************/
            rc = dbmDequeue ( &sHandle, gSrcQueName, &data, 10000000 );
            if ( rc == ERR_DBM_NO_MATCH_RECORD )
            {
                if ( out++ >= 3 )
                    break;
                continue;
            }
            _IF_THROW( rc, -1 );

            if ( i == 0 )
            {
                memcpy ( &start, &data.start, sizeof(struct timespec) );
            }

            /*******************************************
             * Enque target
            *******************************************/
//            clock_gettime_s(CLOCK_REALTIME, &data.start);
            _CALL( dbmEnqueue ( &sHandle, gTarQueName, &data, sizeof( data ) ) );
            _CALL( dbmCommit ( &sHandle ) );

            cmnUSleep ( 2000 );
        }
        clock_gettime_s ( CLOCK_REALTIME, &end );
        printf ( "deqStep2: total Time = %.9f\n",
                 ( end.tv_sec + end.tv_nsec / 1000000000.0 ) - ( start.tv_sec + start.tv_nsec / 1000000000.0 ) );

        _CALL( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
} /* thr_deqStep1 */


#endif
