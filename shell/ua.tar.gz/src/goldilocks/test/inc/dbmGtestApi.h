/*
 * dbmGtestApi/g.h
 *
 *  Created on: Mar 18, 2014
 *      Author: paul
 */
/*
 * @file            dbmGtestApi/g.cpp
 *
 * @brief           GTEST에서 자주 사용되는 구조체, 정의, 함수 모음
 */
#ifndef DBMGTESTAPI_H_
#define DBMGTESTAPI_H_

#include "cmnApi.h"
#include "dbmAPI.h"

#define _GTEST
#ifdef  _GTEST
#include <gtest/gtest.h>
#endif
#include <dlfcn.h>

// thread parameter variable
typedef struct PARAM
{
    int tid;
    int start;
    int aCount;
    double tps;
} PARAM;

typedef enum
{
    INSERT,
    SELECT,
    UPDATE
} DML_TYPE ;


extern PHTIMER _tc_timer;

extern _VOID TEST_SQL_UNDO ( char* aUndo, int aFlag = 0 );
extern _VOID TEST_SQL_TBL ( char* aUndo, char* aTable, int aFlag = 0 );

/**
 * GTEST 내부에서 사용하기 위한 전용 매크로.
 */
#ifdef _GTEST

#ifdef __cplusplus
extern "C" {
#endif

extern int              _dbm_argc;
extern const char**     _dbm_argv;

#ifdef __cplusplus
}
#endif


//#define _TC_KNOWN_BUG       // 알려진 버그를 막아두는 용도. 풀고 테스트 하면 모든 미제 버그를 테스트

/*
 * TODO: 적용하고 싶으나. 불가.
 * GTEST에서 함수매크로는 TestBody가 출력됨, 이를 가독성 있는 함수 이름으로. 출력할수 있다. 그러나.
 * SetUpTestCase / TearDownTestCase 내부에서 호출되면 NULL이므로 죽는다.
 *
 * 이게되면 로그가 아래와 같다.  TEST_F(xx, perpare) 일때
 * (E)10:20:12.437181 00832    TBKPB001.cpp        TestBody  132 @@@@@@@@@@@@
 * (E)10:20:12.437181 00832    TBKPB001.cpp         prepare  132 @@@@@@@@@@@@
 *
 */
//#undef  __FUNCTION__
//#define __FUNCTION__    ::testing::UnitTest::GetInstance()->current_test_info()->name()

#ifdef _DEBUG
#define _THROW2(x)          { if (!x)  { _PRT( "%s:%d _THROW(0) detected\n", __FILE__, __LINE__ ); _DASSERT(0); } _rc = x; _line=__LINE__; goto _catch; }
#else
#define _THROW2(x)          { _rc = x; _line=__LINE__; goto _catch; }
#endif

#undef  _CALL
#define _CALL(x)            if ( (_rc=(x)) != 0 ) { EXPECT_EQ(_rc,0); _THROW2(_rc); }

#undef  _THROW
#define _THROW(x)           { EXPECT_EQ(x,0); _THROW2(x); }

#undef  _IF_THROW
#define _IF_THROW(exp,x)    if ( unlikely(exp) ) { EXPECT_FALSE(exp); _THROW2(x); }
#undef  _TEST_THROW
#define _TEST_THROW(exp,x)  if ( unlikely( !(exp) ) ) { EXPECT_TRUE(exp); _THROW2(x); }


//#define _T_PRT(a,...)       { printf("%4s"," "); printf( a, ##__VA_ARGS__); fflush(stdout); }
//#define _T_PRT(a,...)       { printf("%-4s",">"); printf( a, ##__VA_ARGS__); fflush(stdout); }
#define _T_PRT(a,...)       { printf("> "); printf( a, ##__VA_ARGS__); fflush(stdout); }
#undef  _PRT
#define _PRT                _T_PRT

//#define _T_ENDLOG           { _test_hdl.mMark = 0; _PRT( "\n" ); }      // _test_hdl 핸들을 여기서 한번더 무효화한다.(혹시나)
#define _T_ENDLOG           { _PRT( "\n" ); }
#define _T_SUB_ENDLOG       //{ _PRT( "\n" ); }

#endif /* _GTEST */


#endif /* DBMGTESTAPI_H_ */
