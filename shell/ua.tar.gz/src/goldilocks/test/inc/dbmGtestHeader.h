/*
 * @file            dbmGtestHeader.h
 * @brief           GTEST에서 자주 사용되는 구조체, 정의, 함수 모음
 */
#ifndef DBMGTESTHEADER_H_
#define DBMGTESTHEADER_H_

#include "dbmGtestApi.h"
#include "dbmHeader.h"

#endif /* DBMGTESTHEADER_H_ */
