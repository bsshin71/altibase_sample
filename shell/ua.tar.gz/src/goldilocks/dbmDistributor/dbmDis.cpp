#include "dbmAPI.h"
#include "dbmObject.h"
#include "dbmDefine.h"



main(int argc, char *argv[])
{
    dbmHandle       sHandle;
    momTopicKey     sTopic;
    momTopicData*   sData;
    char            sBuff[4096];
    int             sRC;

    if (argc < 2)
    {
        fprintf(stdout, "Usage] %s <undoName>\n", argv[0]);
        exit(-1);
    }

    sRC = dbmInitHandle (&sHandle, argv[1]);
    if (sRC)
    {
        fprintf(stdout, "Initfailed rc=%d\n", sRC);
        exit(-1);
    }

    sRC = dbmPrepareTable (&sHandle, MOM_EVENT_FOR_DIS);
    if (sRC)
    {
        fprintf(stdout, "Prep (%s) failed rc=%d\n", MOM_EVENT_FOR_DIS, sRC);
        exit(-1);
    }

    while (1)
    {
        sRC = dbmDequeue (&sHandle, MOM_EVENT_FOR_DIS, (char*)&sTopic, 1000);
        if (sRC == ERR_DBM_NO_MATCH_RECORD) continue;
        else if (sRC && sRC != ETIMEDOUT)
        {
            fprintf(stdout, "Error (%d) break\n", sRC);
            break;
        }

        //fprintf(stdout, "Data=(msgID=%ld, Topic=%s)\n", sTopic.mMsgID, sTopic.mTopic);

        sRC = dbmPrepareTable (&sHandle, sTopic.mTopic);
        if (sRC)
        {
            fprintf(stdout, "Prep (%s) failed rc=%d\n", sTopic.mTopic, sRC);
            break;
        }


        sData = (momTopicData*)sBuff;
        sData->mMsgID = sTopic.mMsgID;

        sRC = dbmSelectForUpdateRow (&sHandle, sTopic.mTopic, sBuff);
        if (sRC)
        {
            fprintf(stdout, "Select (%s) failed rc=%d\n", sTopic.mTopic, sRC);
            break;
        }

        //fprintf(stdout, "Select Data (msgID=%ld, mSize=%d)\n", sData->mMsgID, sData->mSize);

        sRC = dbmCommit (&sHandle);
        if (sRC)
        {
            fprintf(stdout, "Commit failed rc=%d\n", sRC);
            break;
        }
    }

}
