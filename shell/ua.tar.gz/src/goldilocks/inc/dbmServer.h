/*******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*******************************************************************************
 * $Id$
 *
 * Description :
 *
 ******************************************************************************/

#ifndef __O_DBM_SERVER_H__
#define __O_DBM_SERVER_H__

#include "mvp.h"

/*********** Type Definition **************************************************/

#ifdef __cplusplus
extern "C" {
#endif

// 2014.11.24 -okt- 이런 전역변수도, extern "C" 한거랑 안한거랑 호환되지 않는다.
extern int              _dbm_argc;
extern const char**     _dbm_argv;

// 2015.03.04 -okt- dbmDef.h에 중복정의
//extern char* _dbm_getArg ( const char* name );
//extern _VOID _dbm_setArg ( int* pArgc, char** ppArgv );

#ifdef __cplusplus
extern _VOID _dbm_numa_init ( int aNumaNode = -1 );
extern _VOID _dbm_cpuinfo ( int aFlag = 0 );
#else
extern _VOID _dbm_numa_init ( int aNumaNode );
extern _VOID _dbm_cpuinfo ( int aFlag );
#endif

#ifdef __cplusplus
}
#endif

#endif  /* __O_DBM_SERVER_H__ */
