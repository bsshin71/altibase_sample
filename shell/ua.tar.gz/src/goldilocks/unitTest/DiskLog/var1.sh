#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF > /dev/null
    set undo demo_disk; 
    drop table t1;
    create table t1 c1 int, c2 char(100);
    create index idx_t1 on t1 c1;
    quit;
EOF
}


init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb
    create undo demo_disk ;
    quit;
EOF
}


stat_table ()
{
    metaManager --silent << EOF 
    conn demo_disk;
    select * from t1;
    quit;
EOF
}

# Create Table
echo "####################################################################"
echo "# DML Operation "
echo "####################################################################"
rm -rf $DBM_HOME/WAL2  > /dev/null

init_undo
create_table
./var1
stat_table > var1_before.txt


mkdir $DBM_HOME/WAL2 
mv $DBM_HOME/WAL/* $DBM_HOME/WAL2/


## Recovery test 
echo "####################################################################"
echo "# Initialize "
echo "####################################################################"
init_undo

echo "####################################################################"
echo "# dbmRecover"
echo "####################################################################"
dbmRecover -d $DBM_HOME/WAL2 -i demo_disk

stat_table > var1_after.txt

##########################################################
# Check Diff before/after.
##########################################################
diff var1_before.txt var1_after.txt > var1_diff.txt
diff_line=`cat var1_diff.txt | wc -l`
if [ $diff_line -ne 0 ]
then
    echo "FAIL"
else
    echo "OK"
fi

### Undo 테이블을 생성하고 해당 테이블에 CRUD 연산을 수행
