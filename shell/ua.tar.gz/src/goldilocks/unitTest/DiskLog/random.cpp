#include <dbmAPI.h>
#include <dbmHeader.h>


char gInstance[64];
int gTableMax;
int gCount;
int gThrCount;
int gOperCount;

typedef struct
{
    int c1;
    int c2;
    char c3[600];
    char c4[600];
} DataSet;



void CHK_ERROR(const char *aStep, int aRc)
{
    if (aRc)
    {
        _PRT ("%s fail rc=%d\n", aStep, aRc);
        exit(-1);
    }
}



void *thr(void *args)
{
    dbmHandle sHandle;
    DataSet sData;
    char sTable[128];
    int sError = 0;
    int i, j;
    int rc;
   
    rc = dbmInitHandle (&sHandle, gInstance);
    CHK_ERROR ("thr_initHandle", rc);

    for (i=0; i<gTableMax; i++)
    {
        sprintf(sTable, "t%d", i+1);
        rc = dbmPrepareTable (&sHandle, sTable);
        CHK_ERROR("Thr_Prepare_table1", rc);
    }

    for (i=0; i<gOperCount; i++)
    {
        for (j=0; j<gTableMax; j++)
        {
            sData.c1 = rand() % gCount;
            sData.c2 = sData.c1;
            sprintf(sTable, "t%d", rand()%gTableMax + 1);
            rc = dbmUpdateRow (&sHandle, sTable, &sData);
            // dead-lock이 날수 있다.
            if (rc) 
            {
                dbmRollback(&sHandle);
                sError++;
            }
        }
        rc = dbmCommit (&sHandle);
        CHK_ERROR ("Thr_commit", rc);
        //if (i!= 0 && i%100000 == 0) _PRT ("%d executed\n", i);
    }

    return NULL;
}


void Prepare()
{
    dbmHandle sHandle;
    char      sTable[64];
    DataSet   sData;
    int i, j;
    int rc;

    rc = dbmInitHandle (&sHandle, gInstance);
    CHK_ERROR("Prepare_init", rc);

    for (i=0; i<gTableMax; i++)
    {
        sprintf(sTable, "t%d", i+1);
        rc = dbmPrepareTable (&sHandle, sTable);
        CHK_ERROR("Prepare_table1", rc);
    }

    for (i=0; i<gCount; i++)
    {
        sData.c1 = i;
        sData.c2 = 0;
 
        for (j=0; j<gTableMax; j++)
        {
            sprintf(sTable, "t%d", j+1);
            rc = dbmInsertRow (&sHandle, sTable, &sData, sizeof(sData));
            CHK_ERROR ("prepare_insert_t1", rc);
        }

        rc = dbmCommit (&sHandle);
        CHK_ERROR ("prepare_commit", rc);
    }

    dbmFreeHandle (&sHandle);
}


int main(int argc, char *argv[])
{
    pthread_t tid[255];
    int i;

    if (argc < 6)
    {
        _PRT ("Usage] %s <instance> <table-count> <row-count per table> <thrCount> <operCount>\n", argv[0]);
        exit(-1);
    }

    sprintf(gInstance, "%s", argv[1]);
    gTableMax = atoi(argv[2]);
    gCount = atoi(argv[3]);
    gThrCount = atoi(argv[4]);
    gOperCount = atoi(argv[5]);

    Prepare ();


    for (i=0; i<gThrCount; i++)
    {
        pthread_create (&tid[i], NULL, thr, NULL);
    }

    for (i=0; i<gThrCount; i++)
    {
        pthread_join (tid[i], NULL);
    }

    return 0;
}
