#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF > /dev/null
    set undo demo_disk; 
    drop table refRecord;
    create table refRecord ( c1 int , c2 char ( 2048 ) );
    create index refRecord_idx on refRecord ( c1 ) ;
    quit;
EOF
}

simple_test ()
{
    create_table
    metaManager  --silent << EOF > /dev/null
    set undo demo_disk ;
    insert into refRecord values ( 1, 'aaaa' ) ;
    insert into refRecord values ( 2, 'bbbb' );
    commit;
    insert into refRecord values ( 3, 'cccc' ) ;
    insert into refRecord values ( 4, 'dddd' );
    delete from refRecord where c1 = 3;
    commit ;
    insert into refRecord values ( 5, 'eeee' ) ;
    insert into refRecord values ( 6, 'ffff' );
    update refRecord set c2 = 'e4' where c1 = 5 ;
    commit ;
    quit;
EOF
}

init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb;
    create undo demo_disk ;
    quit;
EOF
}
stat_table ()
{
    metaManager --silent << EOF 
    list;
    select * from demo_disk.refRecord;
    quit;
EOF
}

# Create Table
init_undo
simple_test

stat_table 

rm -rf $DBM_HOME/WAL2 
mkdir $DBM_HOME/WAL2 
cp $DBM_HOME/WAL/* $DBM_HOME/WAL2/.
init_undo

## Recovery test 
#echo "dbmRecover -d $DBM_HOME/WAL2 -i demo_disk" && exit 1
dbmRecover -d $DBM_HOME/WAL2 -i demo_disk

stat_table
echo "OK.."
