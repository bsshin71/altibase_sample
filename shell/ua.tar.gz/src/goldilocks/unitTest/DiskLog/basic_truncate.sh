#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF > /dev/null
    set undo demo_disk ;
    drop table basic_t1;
    create table basic_t1 ( c1 int , c2 char ( 2048 ) );
    create index basic_t1_idx on basic_t1 ( c1 ) ;
    quit;
EOF
}

simple_test ()
{
    create_table
    metaManager  --silent << EOF
    set undo demo_disk ;
    insert into basic_t1 values ( 1, 'abcd' ) ;
    insert into basic_t1 values ( 2, 'defg' );
    commit;
    truncate table basic_t1 ;
    commit;
    quit;
EOF
}

init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb
    create undo demo_disk ;
    quit;
EOF
}
stat_table ()
{
    metaManager --silent << EOF 
    list
    quit
EOF
}

# Create Table
echo "##############################################################"
echo "# DML Start"
echo "##############################################################"
init_undo
simple_test

stat_table > basic_truncate_before.txt

rm -rf $DBM_HOME/WAL2 
mkdir $DBM_HOME/WAL2 
cp $DBM_HOME/WAL/* $DBM_HOME/WAL2 

## Recovery test 
init_undo
echo "##############################################################"
echo "# recovery Start"
echo "##############################################################"
dbmRecover -d $DBM_HOME/WAL2  -i demo_disk

stat_table > basic_truncate_after.txt

diff_line=`diff basic_truncate_before.txt basic_truncate_after.txt | wc -l`
if [ $diff_line -ne 0 ]
then
    echo "FAIL"
else
    echo "OK"
fi

### Undo 테이블을 생성하고 해당 테이블에 CRUD 연산을 수행
