#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF 
    set undo demo_disk; 
    drop table setIndex;
    create table setIndex ( c1 int , c2 int, c3 int );
    create non unique index setIndex_idx1 on setIndex ( c1 ) ;
    create index setIndex_idx2 on setIndex ( c2 ) ;
    create index setIndex_idx3 on setIndex ( c3 ) ;
    quit;
EOF
}

simple_test ()
{
    metaManager  --silent << EOF
    set undo demo_disk ;
    insert into setIndex values ( 1, 1, 11 ) ;
    insert into setIndex values ( 1, 2, 12 ) ;
    insert into setIndex values ( 1, 3, 13 ) ;
    insert into setIndex values ( 1, 4, 14 ) ;
    insert into setIndex values ( 1, 5, 15 ) ;
    insert into setIndex values ( 1, 6, 16 ) ;
    insert into setIndex values ( 2, 7, 17 ) ;
    insert into setIndex values ( 2, 8, 18 ) ;
    insert into setIndex values ( 2, 9, 19 ) ;
    commit;
    set index setIndex setIndex_idx2;
    delete from setIndex where c2 = 2;
    set index setIndex setIndex_idx3;
    delete from setIndex where c3 = 17;
    commit;
    quit;
EOF
}

init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb;
    create undo demo_disk ;
    quit;
EOF
}

stat_table ()
{
    metaManager --silent << EOF 
    list;
    select * from demo_disk.setIndex;
    quit;
EOF
}

# Create Table
init_undo
create_table
simple_test

stat_table > setIndex_before.txt

rm -rf $DBM_HOME/WAL2 
mkdir $DBM_HOME/WAL2 
cp $DBM_HOME/WAL/* $DBM_HOME/WAL2/.
init_undo

## Recovery test 
#echo "dbmRecover -d $DBM_HOME/WAL2 -i demo_disk" && exit 1
dbmRecover -d $DBM_HOME/WAL2 -i demo_disk

stat_table > setIndex_after.txt
diff_line=`diff setIndex_before.txt setIndex_after.txt | wc -l`
if [ $diff_line -ne 0 ]
then 
    echo "FAIL"
else
    echo "OK"
fi

