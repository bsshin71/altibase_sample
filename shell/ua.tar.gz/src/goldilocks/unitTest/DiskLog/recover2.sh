#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF > /dev/null
    set undo demo_disk; 
    drop table t1;
    create table t1 (c1 int, c2 int, c3 char(600), c4 char(600), c5 int, c6 int;
    create index idx1_t1 on t1 c1;
    create non unique index idx2_t1 on t1 c1 c2;
    create index idx3_t1 on t1 c5;
    create non unique index idx4_t1 on t1 c6;
    create non unique index idx5_t1 on t1 c2;
EOF
}

act ()
{
    metaManager --silent << EOF 
    set undo demo_disk; 
    insert into t1 values 1 1 1 1 10 1;
    insert into t1 values 2 1 1 1 11 1;
    insert into t1 values 3 1 1 1 12 1;
    insert into t1 values 4 1 1 1 13 1;
    insert into t1 values 5 1 1 1 14 1;
    insert into t1 values 6 1 1 1 15 1;
    insert into t1 values 7 1 1 1 16 1;
    commit;
    set index t1 idx4_t1;
    update t1 set c4 = 'x', c2 = 5 where c6 = 1;
    commit;
    quit;
EOF
}


init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb
    create undo demo_disk ;
    quit;
EOF
}


stat_table ()
{
    metaManager --silent << EOF 
    conn demo_disk;
    select * from t1;
    quit;
EOF
}

# Create Table
echo "####################################################################"
echo "# DML Operation "
echo "####################################################################"
rm -rf $DBM_HOME/WAL2  > /dev/null

init_undo
create_table
act
stat_table > recover2_before.txt


mkdir $DBM_HOME/WAL2 
mv $DBM_HOME/WAL/* $DBM_HOME/WAL2/


## Recovery test 
echo "####################################################################"
echo "# Initialize "
echo "####################################################################"
init_undo

echo "####################################################################"
echo "# dbmRecover"
echo "####################################################################"
dbmRecover -d $DBM_HOME/WAL2 -i demo_disk

stat_table > recover2_after.txt

##########################################################
# Check Diff before/after.
##########################################################
diff recover2_before.txt recover2_after.txt > recover2_diff.txt
diff_line=`cat recover2_diff.txt | wc -l`
if [ $diff_line -ne 0 ]
then
    echo "FAIL"
else
    echo "OK"
fi

### Undo 테이블을 생성하고 해당 테이블에 CRUD 연산을 수행
