#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF > /dev/null
    set undo demo_disk; 
    drop table basic_t1;
    create table basic_t1_0 ( c1 int , c2 char ( 596 ) ) max 10000000;
    create index basic_t1_idx0 on basic_t1_0 ( c1 ) ;
    create table basic_t1_1 ( c1 int , c2 char ( 596 ) ) max 10000000;
    create index basic_t1_idx1 on basic_t1_1 ( c1 ) ;
    create table basic_t1_2 ( c1 int , c2 char ( 596 ) ) max 10000000;
    create index basic_t1_idx2 on basic_t1_2 ( c1 ) ;
    create table basic_t1_3 ( c1 int , c2 char ( 596 ) ) max 10000000;
    create index basic_t1_idx3 on basic_t1_3 ( c1 ) ;
    create table basic_t1_4 ( c1 int , c2 char ( 596 ) ) max 10000000;
    create index basic_t1_idx4 on basic_t1_4 ( c1 ) ;
    quit;
EOF
}

init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb
    create undo demo_disk ;
    quit;
EOF
}
stat_table ()
{
    metaManager --silent << EOF
    list
    quit
EOF
}

show_result () 
{
    metaManager --silent << EOF
    conn demo_disk 
    select * from basic_t1_4 where c1 > 10 limit 10;
    select * from basic_t1_4 where c1 > 1000 limit 10;
    select * from basic_t1_4 where c1 > 10000 limit 10;
    select * from basic_t1_4 where c1 > 100000 limit 10;
    select * from basic_t1_4 where c1 > 999989 limit 10;
    quit
EOF
}


# Create Table
rm -rf $DBM_HOME/WAL2
init_undo

create_table

./complex_table demo_disk basic_t1 1000000

show_result  > big_table.before

mkdir $DBM_HOME/WAL2
mv $DBM_HOME/WAL/* $DBM_HOME/WAL2

init_undo 
#create_table 
echo "Clean complete. start Recovery .... " 

# TODO (OKT): 2014/09/04
# -. 복구한 DB가 호처리하다가 다시 죽으면 연속 복구가 되어야한다.
# -. 만일 부분 복구하면 어떻게 되나?
# -. TRUNCATE 가 중간에 뀌면 불가

## Recovery test 
dbmRecover -d $DBM_HOME/WAL2 -i demo_disk
#time dbmRecover -d $DBM_HOME/WAL -i demo_disk
#time dbmRecover2 -d $DBM_HOME/WAL -i demo_disk

show_result  > big_table.after
ret=`diff big_table.before big_table.after | wc -l`
if [ $ret -ne 0 ]
then
   echo "FAIL.."
else
    echo "OK.."
fi

### Undo 테이블을 생성하고 해당 테이블에 CRUD 연산을 수행
