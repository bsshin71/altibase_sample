#include "dbmAPI.h"


typedef  struct
{
    int c1;
    char c2 [596] ;
} user_data;



int main ( int argc,    char ** argv )
{
    int   sRC;
    char  sUndoName [ 32 ] ;
    char  sTableName [ 32 ] ;

    dbmHandle   sHandle;
    user_data   sData;


    if ( argc  != 3 )
    {
        printf ("Usage : %s undo_name queue_name \n", argv[0] );
        exit ( -1 );
    }


    memset ( sUndoName, 0x00, 32 ) ;
    memset ( sTableName, 0x00, 32 ) ;

    strcpy ( sUndoName , argv [1] ) ;
    strcpy ( sTableName, argv [2] ) ;


    sRC = dbmInitHandle ( &sHandle, sUndoName ) ;
    sRC = dbmPrepareTable ( &sHandle, sTableName ) ;

    while ( true )
    {
        sRC = dbmDequeue ( &sHandle, sTableName, &sData, 0 ) ;
        if ( sRC == ERR_DBM_NO_MATCH_RECORD )
        {
            break;
        }

        printf (" c1 : %d  c2 : %s \n", sData.c1 , sData.c2 ) ;
    }

    sRC = dbmFreeHandle ( &sHandle ) ;

    return 0;

}
