/******************************************************
 * 5개의 Table 을 놓고, 이 테이블을 서로 번갈아가며 Transaction 을 발생시켰을때
 * 제대로 복구 되는지 시험한다.
 * ****************************************************/

#include "dbmAPI.h"

#define TABLE_COUNT 5

char table_name[32];
char undo_name[32];
int  test_count ;
char        sTableNames [ TABLE_COUNT ][32] ;

void prepareData ( dbmHandle * aHandle) ;
void * workThread ( void * aParam ) ;

typedef struct user_struct
{
    int     c1;
    char    c2 [596];
} user_struct ;

void my_error(const char * name, int rc)
{
    if (rc != 0)
    {
        printf("%s fail:[%d]\n", name, rc);
        exit(-1);
    }
    else
    {
//        printf("%s ok\n", name);
    }
}

typedef struct
{
    int        thread_num;
    dbmHandle *mHandle ;
} PARAM ;


int main(int argc, char *argv[])
{
    dbmHandle sHandle [ TABLE_COUNT ] ;
    user_struct sData;
    int i;
    int sRC;
    pthread_t sTID [ TABLE_COUNT ] ;
    PARAM     sParam [ TABLE_COUNT] ;

    if( argc < 4 )
    {
        printf("Usage : %s undo_name table_name_prefix test_count\n", argv[0]);
        exit(0);
    }

    memset(undo_name, 0x00, sizeof(undo_name));
    memset(table_name, 0x00, sizeof(table_name));

    strcpy(undo_name, argv[1]);
    strcpy(table_name, argv[2]);
    test_count = atoi(argv[3]);

    for ( int i = 0 ; i < TABLE_COUNT ; i ++)
    {
        sRC = dbmInitHandle ( &sHandle[i], undo_name) ;
        my_error ( "INIT_HANDLE", sRC ) ;

        sprintf (sTableNames[i] , "%s_%d",  table_name ,i ) ;
    }


    for ( int i = 0 ; i < TABLE_COUNT - 1 ; i ++)
    {
        sRC = dbmPrepareTable ( &sHandle[i], sTableNames[i] ) ;
        my_error ( "TABLE_PREPARE", sRC ) ;
        sRC = dbmPrepareTable ( &sHandle[i], sTableNames[i+1] ) ;
        printf ("%s %s \n", sTableNames[i], sTableNames[i+1]) ;

        sParam[i].thread_num = i ;
        sParam[i].mHandle = &sHandle[i];
   }


    prepareData ( &sHandle[0] ) ;


    for ( int i = 0 ; i < TABLE_COUNT - 1 ; i ++ )
    {
        sRC = pthread_create ( &sTID[i] , NULL, workThread, (void*)&sParam[i]) ;
        my_error ( "THREAD_CREATE Error ", sRC);
    }

    for ( int i = 0 ; i < TABLE_COUNT - 1 ; i ++ )
    {
        sRC = pthread_join ( sTID[i] , NULL) ;
        my_error ("THREAD JOIN ERROR", sRC ) ;
    }

    // Free Handle

    for ( int i = 0 ; i < TABLE_COUNT ; i ++ )
    {
        sRC = dbmFreeHandle ( &sHandle[i] ) ;
        my_error ("Free Handle Error \n" , sRC);
    }

    return 0;

}


void prepareData ( dbmHandle * aHandle )
{
    int         sRC;
    user_struct sData;

    for (   int i = 0 ; i < test_count ; i ++)
    {
        memset ( &sData, 0x00, sizeof (user_struct ));

        sData.c1 = i ;
        sprintf ( sData.c2, "%d", i );

        sRC = dbmInsertRow ( aHandle, sTableNames[0], &sData, sizeof ( user_struct ));
        my_error ( "INSERT", sRC ) ;

        sRC = dbmCommit ( aHandle ) ;
        my_error ( "COMMIT", sRC ) ;
    }
}


// 자기가 처리해야할 테이블을 계속 SELECT 를 수행하면서
// 데이터가 나오면 다음 테이블로 옮겨줌.
void *workThread ( void * aParam )
{
    int             sRC;
    int             sKeyNo = 0 ;
    PARAM           *sParam = (PARAM*)aParam;
    user_struct     sData;

    if ( sParam->thread_num  == TABLE_COUNT - 1 )
    {
        return NULL ;
    }
    else
    {
        while ( true )
        {
            sData.c1 = sKeyNo ;
            sRC = dbmSelectForUpdateRow ( sParam->mHandle,sTableNames[sParam->thread_num], &sData)  ;
            if ( sRC ==  ERR_DBM_NO_MATCH_RECORD  )
            {
                continue;
            }

            sRC = dbmInsertRow ( sParam->mHandle, sTableNames[sParam->thread_num+1] , &sData , sizeof ( user_struct )) ;
            my_error ( "INSERT in thread", sRC ) ;

            sprintf ( sData.c2 , "%d", sData.c1 + sParam->thread_num ) ;
            sRC = dbmUpdateRow ( sParam->mHandle, sTableNames[sParam->thread_num+1] , &sData ) ;
            my_error ( "UPDATE in thread", sRC ) ;

            sRC = dbmDeleteRow ( sParam->mHandle, sTableNames[sParam->thread_num], &sData ) ;
            my_error ( "DELETE in thread", sRC ) ;

            sRC = dbmCommit ( sParam->mHandle ) ;
            my_error ( "COMMIT in thread", sRC ) ;

            sKeyNo ++ ;

            if ( sKeyNo  == test_count )
            {
                break;
            }
        }
    }

    return  NULL;
}

