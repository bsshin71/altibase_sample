#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF > /dev/null
    set undo demo_disk; 
    drop table basic_t1;
    create queue basic_t1_0 msgsize 600;
    create queue basic_t1_1 msgsize 600;
    create queue basic_t1_2 msgsize 600;
    create queue basic_t1_3 msgsize 600;
    create queue basic_t1_4 msgsize 600;
    quit;
EOF
}

init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF
    initdb
    create undo demo_disk;
    quit;
EOF
}

stat_table ()
{
    metaManager --silent << EOF
    list
    quit;
EOF
}

# Create Table
init_undo

create_table
stat_table 

./complex_queue demo_disk basic_t1 1000

rm -rf $DBM_HOME/WAL2 
mkdir $DBM_HOME/WAL2 
cp $DBM_HOME/WAL/* $DBM_HOME/WAL2 

init_undo 
echo "Clean complete. start Recovery .... " 

## Recovery test 
dbmRecover -d $DBM_HOME/WAL2 -i demo_disk -t basic_t1_4

stat_table

./show_queue demo_disk basic_t1_4 
echo "OK.."

