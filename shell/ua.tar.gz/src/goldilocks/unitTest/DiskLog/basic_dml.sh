#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF > /dev/null
    set undo demo_disk; 
    drop table basic_t1;
    create table basic_t1 ( c1 int , c2 char ( 2048 ) );
    create index basic_t1_idx on basic_t1 ( c1 ) ;
    quit;
EOF
}

simple_test ()
{
    create_table
    metaManager  --silent << EOF > /dev/null
    conn demo_disk ;
    insert into basic_t1 values ( 1, 'abcd' ) ;
    insert into basic_t1 values ( 2, 'defg' );
    insert into basic_t1 values ( 3, 'hijk' );
    commit;
    update basic_t1 set c2 = 'bcde' where c1 = 1 ;
    update basic_t1 set c2 = 'efgh' where c1 = 2 ;
    update basic_t1 set c2 = 'hijk' where c1 = 3 ;
    commit ;
    delete from basic_t1 where c1 = 3;
    commit;
    quit;
EOF
}

init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb
    create undo demo_disk ;
    quit;
EOF
}
stat_table ()
{
    metaManager --silent << EOF 
    conn demo_disk;
    list;
    select * from basic_t1;
    quit;
EOF
}

# Create Table
echo "####################################################################"
echo "# DML Operation "
echo "####################################################################"
init_undo
simple_test

stat_table > basic_dml_before.txt


rm -rf $DBM_HOME/WAL2 
mkdir $DBM_HOME/WAL2 
cp $DBM_HOME/WAL/* $DBM_HOME/WAL2/.


## Recovery test 
echo "####################################################################"
echo "# Initialize "
echo "####################################################################"
init_undo

echo "####################################################################"
echo "# dbmRecover" 
echo "####################################################################"
dbmRecover -d $DBM_HOME/WAL2 -i demo_disk
#dbmRecover2 -d $DBM_HOME/WAL2 -i demo_disk

stat_table > basic_dml_after.txt

##########################################################
# Check Diff before/after.
##########################################################
diff basic_dml_before.txt basic_dml_after.txt > basic_diff.txt
diff_line=`cat basic_diff.txt | wc -l`
if [ $diff_line -ne 0 ]
then
    echo "FAIL"
else
    echo "OK"
fi

### Undo 테이블을 생성하고 해당 테이블에 CRUD 연산을 수행
