#!/bin/sh

declare errcnt=0 # 허용가능한 최대 오류 건수
declare loop=0
show_diff()
{
    loop=`expr $loop + 1`

    odiff "[ $1 ]" $1

    # 추적을 위해 오류나면 바로 죽자.
    if [ "x"$? != "x0" ]
    then
        if [ "x"$errcnt == "x0" ]
        then
            # 테스트 오류가 발생시 멈추도록.
            # 1 이상의 값을 선택하면, test 결과 파일이
            printf "[$loop] [FATAL] max error count reached. break.\n"
            exit 1
        fi
        errcnt=`expr $errcnt - 1`
    fi  

    # core 가 있으면 무조건 죽자.
    chk=`ls core* 2>/dev/null |wc -l`
    if [ "x"$chk != "x0" ]
    then
        echo "[ERROR] 테스트 실패 !!"
        exit 1
    fi
}


########################################
# MAIN.
########################################
echo "## TEST START ##"

# diff 파일여부로 결과를 판단하므로 *.diff 를 정리
chk=`ls core* *.diff 2>/dev/null |wc -l`
if [ "x"$chk != "x0" ]
then
    DT=`date "+%d_%H%M"`
    echo "이전 diff 파일 존제, $DT 경로로 백업"

    mkdir $DT
    mv core* *.out *.diff $DT > /dev/null 2>&1
fi


#### Disk Log 테스트를 위해서 Property 를 복사
cp $DBM_HOME/conf/dbm.cfg ./dbm.cfg.old
cp dbm.cfg $DBM_HOME/conf


### 테스트 케이스를 돌린다. 

sh basic_dml.sh > basic_dml.out 
show_diff basic_dml

sh basic_queue.sh > basic_queue.out 
show_diff basic_queue

sh basic_truncate.sh > basic_truncate.out
show_diff basic_truncate 

sh complex_table.sh  > complex_table.out
show_diff complex_table

sh refRecord.sh > refRecord.out 
show_diff refRecord

sh setIndex.sh > setIndex.out 
show_diff setIndex

sh complex_queue.sh  > complex_queue.out
show_diff complex_queue

sh table_point_recover.sh  > table_point_recover.out
show_diff table_point_recover

sh queue_point_recover.sh  > queue_point_recover.out
show_diff queue_point_recover

sh recover1.sh > recover1.out
show_diff recover1

sh recover2.sh > recover2.out
show_diff recover2

sh recover3.sh > recover3.out
show_diff recover3

# order simulation recovery.
sh recover4.sh > recover4.out
show_diff recover4

# variable record size recovery
sh var1.sh > var1.out
show_diff var1

# ha test
sh ha1.sh > ha1.out
show_diff ha1

# random update recovery test
sh random.sh > random.out
show_diff random

sh big_table.sh > big_table.out 
show_diff big_table

# O_DIRECT 관련 최소 테스트는 수행
sed -i -e "s;^DISK_LOG_IO_TYPE.*= 0;DISK_LOG_IO_TYPE = 3;g" $DBM_HOME/conf/dbm.cfg
sh basic_dml.sh > basic_dml_direct.out 
show_diff basic_dml_direct

# 다른 config 파일이다. 테스트 목적은?
sh manual_sample.sh > manual_sample.out
show_diff manual_sample

########################################
# END.
########################################
#### Property 를 복원한다. 
cp ./dbm.cfg.old $DBM_HOME/conf/dbm.cfg

# 정상종료 여부를 상위단으로 알려주어야 한다.
chk=`ls core* *.diff 2>/dev/null |wc -l`
if [ "x"$chk != "x0" ]
then
    echo "[ERROR] 테스트 실패 !!"
    ls -l core* *.diff 2>/dev/null
    exit 1
fi

exit 0
