#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF > /dev/null
    set undo demo_disk; 
    drop table basic_t1;
    create table basic_t1_0 ( c1 int , c2 char ( 596 ) );
    create index basic_t1_idx0 on basic_t1_0 ( c1 ) ;
    create table basic_t1_1 ( c1 int , c2 char ( 596 ) );
    create index basic_t1_idx1 on basic_t1_1 ( c1 ) ;
    create table basic_t1_2 ( c1 int , c2 char ( 596 ) );
    create index basic_t1_idx2 on basic_t1_2 ( c1 ) ;
    create table basic_t1_3 ( c1 int , c2 char ( 596 ) );
    create index basic_t1_idx3 on basic_t1_3 ( c1 ) ;
    create table basic_t1_4 ( c1 int , c2 char ( 596 ) );
    create index basic_t1_idx4 on basic_t1_4 ( c1 ) ;
    quit;
EOF
}

init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb
    create undo demo_disk ;
    quit;
EOF
}
stat_table ()
{
    metaManager --silent << EOF
    list
    quit
EOF
}

show_result () 
{
    metaManager --silent << EOF
    conn demo_disk 
    select * from basic_t1_4 ;
    quit
EOF
}


# Create Table
echo "############################################################"
echo "# Test Start"
echo "############################################################"
init_undo
create_table
./complex_table demo_disk basic_t1 1000
show_result > complex_table_before.txt


rm -rf $DBM_HOME/WAL2 
mkdir $DBM_HOME/WAL2 
cp $DBM_HOME/WAL/* $DBM_HOME/WAL2 

echo "############################################################"
echo "# Recovery Start"
echo "############################################################"
init_undo 
#create_table 
#stat_table 
## Recovery test 
dbmRecover -d $DBM_HOME/WAL2 -i demo_disk
#dbmRecover2 -d $DBM_HOME/WAL2 -i demo_disk

stat_table
show_result > complex_table_after.txt
diff_line=`diff complex_table_before.txt complex_table_after.txt | wc -l`
if [ $diff_line -ne 0 ]
then
    echo "FAIL"
else
    echo "OK"
fi
#echo "OK.."

### Undo 테이블을 생성하고 해당 테이블에 CRUD 연산을 수행
