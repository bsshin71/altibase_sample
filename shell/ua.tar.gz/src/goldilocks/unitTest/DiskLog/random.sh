#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF > /dev/null
    set undo demo_disk; 
    drop table t1;
    drop table t2;
    drop table t3;
    drop table t4;
    drop table t5;
    drop table t6;
    drop table t7;
    drop table t8;
    drop table t9;
    drop table t10;
    create table t1 (c1 int, c2 int, c3 char(600), c4 char(600);
    create index idx_t1 on t1 c1;
    create table t2 (c1 int, c2 int, c3 char(600), c4 char(600);
    create index idx_t2 on t2 c1;
    create table t3 (c1 int, c2 int, c3 char(600), c4 char(600);
    create index idx_t3 on t3 c1;
    create table t4 (c1 int, c2 int, c3 char(600), c4 char(600);
    create index idx_t4 on t4 c1;
    create table t5 (c1 int, c2 int, c3 char(600), c4 char(600);
    create index idx_t5 on t5 c1;
    create table t6 (c1 int, c2 int, c3 char(600), c4 char(600);
    create index idx_t6 on t6 c1;
    create table t7 (c1 int, c2 int, c3 char(600), c4 char(600);
    create index idx_t7 on t7 c1;
    create table t8 (c1 int, c2 int, c3 char(600), c4 char(600);
    create index idx_t8 on t8 c1;
    create table t9 (c1 int, c2 int, c3 char(600), c4 char(600);
    create index idx_t9 on t9 c1;
    create table t10 (c1 int, c2 int, c3 char(600), c4 char(600);
    create index idx_t10 on t10 c1;
    quit;
EOF
}


init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb
    create undo demo_disk ;
    quit;
EOF
}


stat_table ()
{
    metaManager --silent << EOF 
    conn demo_disk;
    select c1, c2 from t1 limit 10;
    select c1, c2 from t2 where c1 > 10000 limit 10;
    select c1, c2 from t3 where c1 > 10000 limit 10;
    select c1, c2 from t4 where c1 > 10000 limit 10;
    select c1, c2 from t5 where c1 > 10000 limit 10;
    select c1, c2 from t6 where c1 > 10000 limit 10;
    select c1, c2 from t7 where c1 > 10000 limit 10;
    select c1, c2 from t8 where c1 > 10000 limit 10;
    select c1, c2 from t9 where c1 > 10000 limit 10;
    select c1, c2 from t10 where c1 > 10000 limit 10;
    quit;
EOF
}

# Create Table
echo "####################################################################"
echo "# DML Operation "
echo "####################################################################"
rm -rf $DBM_HOME/WAL2  > /dev/null

init_undo
create_table
./random demo_disk 10 100000 8 100000
stat_table > random_before.txt


mkdir $DBM_HOME/WAL2 
mv $DBM_HOME/WAL/* $DBM_HOME/WAL2/


## Recovery test 
echo "####################################################################"
echo "# Initialize "
echo "####################################################################"
init_undo

echo "####################################################################"
echo "# dbmRecover"
echo "####################################################################"
dbmRecover -d $DBM_HOME/WAL2 -i demo_disk

stat_table > random_after.txt

##########################################################
# Check Diff before/after.
##########################################################
diff random_before.txt random_after.txt > random_diff.txt
diff_line=`cat random_diff.txt | wc -l`
if [ $diff_line -ne 0 ]
then
    echo "FAIL"
else
    echo "OK"
fi

### Undo 테이블을 생성하고 해당 테이블에 CRUD 연산을 수행
