/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmInsertRow
 */
#include <dbmAPI.h>

typedef struct 
{
    int c1;
    char c2[100];
} data2;



int main ( int argc , char **argv )
{
    dbmHandle   handle;
    data2*      pdata;
    int         rc;
    int         i;

    pdata = (data2*) malloc ( sizeof(data2) );

    rc = dbmInitHandle ( &handle, "demo_disk" );
    if (rc)
    {
        printf("ERR] InitHandle fail\n");
        exit(-1);
    }

    dbmTruncate (&handle, "t1");

    rc = dbmPrepareTable ( &handle, "t1" );
    if (rc)
    {
        printf("ERR] InitHandle fail\n");
        exit(-1);
    }

    for (i=4; i<96; i=i+4)
    {
        memset (pdata, 0x00, sizeof(data2));
        pdata->c1 = i;
        memset (pdata->c2, 'a', i);
        rc = dbmInsertRow ( &handle, "t1", pdata, sizeof(int) + i);
        if (rc) 
        {
           printf("ERR] Insert fail rc=%d\n", rc);
           exit(-1);
        }
        dbmCommit(&handle);
    }

    for (i=96; i>=4; i=i-4)
    {
        memset (pdata, 0x00, sizeof(data2));
        pdata->c1 = i + 100;
        memset (pdata->c2, 'b', i);
        rc = dbmInsertRow ( &handle, "t1", pdata, sizeof(int) + i);
        if (rc) 
        {
           printf("ERR] Insert fail rc=%d\n", rc);
           exit(-1);
        }
        dbmCommit(&handle);
    }

    dbmFreeHandle ( &handle );

    return 0;
}

