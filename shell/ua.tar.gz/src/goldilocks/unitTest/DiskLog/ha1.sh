#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF > /dev/null
    set undo demo_disk; 
    drop table t1;
    create table t1 c1 int, c2 char(100);
    create index idx_t1 on t1 c1;
    create queue q1 msgsize 600;
    quit;
EOF
}

insert_table ()
{
    metaManager --silent << EOF > /dev/null;
    set undo demo_disk; 
    insert into t1 values 1 100;
    insert into t1 values 2 200;
    insert into t1 values 3 300;
    enqueue into q1 values abcdefg;
    commit;
    quit
EOF
}

init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb
    create undo demo_disk ;
    quit;
EOF
}


stat_table ()
{
    metaManager --silent << EOF 
    conn demo_disk;
    select * from t1;
    dequeue from q1;
    quit;
EOF
}

# Create Table
echo "####################################################################"
echo "# DML Operation "
echo "####################################################################"
rm -rf $DBM_HOME/WAL2  > /dev/null

init_undo
create_table
insert_table
stat_table > ha1_before.txt


mkdir $DBM_HOME/WAL2 
mv $DBM_HOME/WAL/* $DBM_HOME/WAL2/


## Recovery test 
echo "####################################################################"
echo "# Initialize "
echo "####################################################################"
init_undo

echo "####################################################################"
echo "# dbmRecover"
echo "####################################################################"
dbmRecover -d $DBM_HOME/WAL2 -i demo_disk

stat_table > ha1_after.txt

##########################################################
# Check Diff before/after.
##########################################################
diff ha1_before.txt ha1_after.txt > ha1_diff.txt
diff_line=`cat ha1_diff.txt | wc -l`
if [ $diff_line -ne 0 ]
then
    echo "FAIL"
else
    echo "OK"
fi

## Recovery test one more!!!!!
rm -f $DBM_HOME/WAL2/*
mv $DBM_HOME/WAL/* $DBM_HOME/WAL2/
echo "####################################################################"
echo "# Initialize "
echo "####################################################################"
init_undo
#
echo "####################################################################"
echo "# dbmRecover"
echo "####################################################################"
dbmRecover -d $DBM_HOME/WAL2 -i demo_disk
#
stat_table > ha2_after.txt
#
###########################################################
## Check Diff before/after.
###########################################################
diff ha1_before.txt ha2_after.txt > ha1_diff.txt
diff_line=`cat ha1_diff.txt | wc -l`
if [ $diff_line -ne 0 ]
then
    echo "FAIL"
else
    echo "OK"
fi


