#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
metaManager << EOF_
initdb;
drop undo demo_disk;
create undo demo_disk;
drop table lim272_t1;
create table lim272_t1
c1 char 20 0
c2 int 10 0
c3 int 10 0
init 10000000 extend 1000000 max 12000000;
create index idx_lim272_t1 on lim272_t1 c1;

drop table item;
create table item
itemcd char 8
itemnm char 20
highprc double 10 2
lowprc double 10 2
smaxprc double 10 2
minprc double 10 2
currprc double 10 2
trdqty long 15 0
trdamt long 15 0
init 10000 extend 10000 max 1000000;
create index item_idx1 on item itemcd;

drop table accnt;
create table accnt
accntno char 8
accntnm char 20
ablemoney long 15 0
unsettle long 15 0
init 30000 extend 10000 max 1000000;
create index accnt_idx1 on accnt accntno;

drop table ordno;
create table ordno
brcd char 3
ordno long 8 0
init 10 extend 100 max 1000;
create index ordno_idx1 on ordno brcd;

drop table order;
create table order
accntno char 8
itemcd  char 8
ordprc  long 8 0
ordqty  long 8 0
ordno   long 8 0
init 1000000 extend 100000 max 10000000;
create index order_idx1 on order accntno itemcd ordno;
create index order_idx2 on order ordno;
list
exit
EOF_
}


init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb
    create undo demo_disk ;
    quit;
EOF
}


stat_table ()
{
    metaManager --silent << EOF 
    conn demo_disk;
    select * from accnt;
    select * from ordno;
    select * from order;
    quit;
EOF
}

# Create Table
echo "####################################################################"
echo "# DML Operation "
echo "####################################################################"
rm -rf $DBM_HOME/WAL2  > /dev/null

init_undo
create_table
./test30 1
stat_table > recover4_before.txt


mkdir $DBM_HOME/WAL2 
mv $DBM_HOME/WAL/* $DBM_HOME/WAL2/


## Recovery test 
echo "####################################################################"
echo "# Initialize "
echo "####################################################################"
init_undo

echo "####################################################################"
echo "# dbmRecover"
echo "####################################################################"
dbmRecover -d $DBM_HOME/WAL2 -i demo_disk

stat_table > recover4_after.txt

##########################################################
# Check Diff before/after.
##########################################################
diff recover4_before.txt recover4_after.txt > recover4_diff.txt
diff_line=`cat recover4_diff.txt | wc -l`
if [ $diff_line -ne 0 ]
then
    echo "FAIL"
else
    echo "OK"
fi

### Undo 테이블을 생성하고 해당 테이블에 CRUD 연산을 수행
