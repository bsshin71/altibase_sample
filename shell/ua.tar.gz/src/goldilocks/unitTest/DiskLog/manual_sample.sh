#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF > /dev/null
    set undo test_instance; 
    drop table t1;
    create table t1 ( c1 int , c2 int,  c3 char ( 100 ) );
    create index t1_idx on t1 ( c1 ) ;
    create queue q1 msgsize 500; 
    quit;
EOF
}

prepare ()
{
    create_table
    metaManager  --silent << EOF > /dev/null
    set undo test_instance ;
    insert into t1 values 1 1 TEST1 ;
    insert into t1 values 2 1 TEST2 ; 
    enqueue into q1 values MSG1; 
    enqueue into q1 values MSG2; 
    commit;
    quit;
EOF
}

sample_test () 
{
 metaManager  --silent << EOF > /dev/null
    set undo test_instance ;

    update t1 set c2 = 100 where c1 = 1 ; 
    dequeue from q1 ; 
    commit ; 
    delete from t1 where c1 = 2 ;
    commit; 
EOF
}

init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb;
    create undo test_instance ;
    quit;
EOF
}
stat_table ()
{
    metaManager --silent << EOF 
    conn test_instance;
    list;
    select * from t1;
    quit;
EOF
}

# Create Table
cp sample_test.cfg $DBM_HOME/conf/dbm.cfg
init_undo
prepare
sample_test

stat_table 
echo "########################################################################################"

rm -rf $DBM_HOME/WAL2 
mkdir $DBM_HOME/WAL2 
cp $DBM_HOME/WAL/* $DBM_HOME/WAL2 
#create_table 


## Recovery test 
init_undo 
dbmRecover -d $DBM_HOME/WAL2 -i test_instance
stat_table
echo "OK.."

