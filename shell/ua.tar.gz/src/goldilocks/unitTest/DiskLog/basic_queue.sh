#!/bin/sh

##### Initialize DBM   #####

create_table ()
{
    metaManager --silent << EOF > /dev/null
    set undo demo_disk; 
    drop queue basic_q1;
    create queue basic_q1 msgsize 2048;
    quit;
EOF
}

simple_test ()
{
    create_table
    metaManager  --silent << EOF > /dev/null
    set undo demo_disk; 
    enqueue into basic_q1 values ( aaaa ) ; 
    enqueue into basic_q1 values ( bbbb ) ; 
    commit; 
    enqueue into basic_q1 values ( cccc ) ; 
    commit; 
    dequeue from basic_q1 ; 
    dequeue from basic_q1 ; 
    commit; 
    quit;
EOF
}

init_undo ()
{
    rmipc $BASE_NAME > /dev/null
    rm -rf $DBM_HOME/WAL/*

    metaManager --silent << EOF 
    initdb
    create undo demo_disk ;
    quit;
EOF
}

stat_table ()
{
    metaManager --silent << EOF 
    list
    quit
EOF
}

# Create Table
init_undo
simple_test

stat_table 

rm -rf $DBM_HOME/WAL2 
mkdir $DBM_HOME/WAL2 
cp $DBM_HOME/WAL/* $DBM_HOME/WAL2 

## Recovery test 
init_undo
dbmRecover -d $DBM_HOME/WAL2  -i demo_disk

stat_table
echo "OK.."

