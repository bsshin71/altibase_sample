rm -f test.log
make clean; make all
./test
cat test.log

