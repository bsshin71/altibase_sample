
#include "dbmHeader.h"

void test2(char *aFormat, ...)
{
    va_list sArgs;
    char   sMsg[4096];

    va_start (sArgs, aFormat);
    vsprintf(sMsg, aFormat, sArgs);
    va_end(sArgs);

    printf("===> %s", sMsg);
}




void test1( )
{
    int      sRC;
    char     sFormat[1024];

    sRC = ERR_DBM_SPACE_SAMPLE1;
    cmnErrorManager::mGetFormat (sRC, sFormat);
    printf("ErrCode=%d, ErrFormat=[%s]", sRC, sFormat);

    memset(sFormat, 0x00, sizeof(sFormat));
    sRC = ERR_DBM_INDEX_SAMPLE1;
    cmnErrorManager::mGetFormat (sRC, sFormat);
    printf("ErrCode=%d, ErrFormat=[%s]", sRC, sFormat);

    DBM_ERR("index1", "index2");
}



int main( )
{
    cmnErrorManager::mInitialize();
    test1();
}
