
#include "dbmHeader.h"

/*
void testAllocFree( )
{
    dbmDictionary sDic;

    int i, rc;
    int sSegNo, sOffset;

    sDic.mInitialize();
    rc = sDic.mCreate();
    printf( "create rc=%d\n", rc );

    rc = sDic.mAttach();
    printf( "attach rc=%d, mDicShmCount=%d\n", rc, sDic.mGetShmCount() );

    for( i=0;i<100000; i++ )
    {
        rc = 0;
        rc = sDic.mAllocSlot( &sSegNo, &sOffset );
        if ( rc ) break;
        rc = sDic.mFreeSlot( sSegNo, sOffset );
    }
    system( "ipcs -m" );

    for( i=0;i<100000; i++ )
    {
        rc = 0;
        rc = sDic.mAllocSlot( &sSegNo, &sOffset );
        if ( rc ) break;
        if ( i%1000 == 0) printf( "segNo=%d, offset=%d\n", sSegNo, sOffset );
    }
    printf( "break( i=%d, rc=%d )\n", i, rc );

    sDic.mDrop();
}
 */


void testTBS( )
{
    dbmDicObject    sObj;
    dbmDictionary   sDic;
    dbmTBSDic       sTBS;
    dbmTableDic     sTable;
    dbmColumnDic    sCol;
    dbmColumnSetDic sColSet;
    dbmIndexDic     sIndex  ;
    dbmTableInfo    sTableInfo;

    int             i, rc;

    /*****************************************
     * 최초 Dic Creation시 예제
     *****************************************/
    sDic.mInitialize();
    rc = sDic.mCreate();
    printf( "create rc=%d\n", rc );
    if ( rc ) exit( -1 );

    /*****************************************
     * 사용자가 Attach할려면
     *****************************************/
    rc = sDic.mAttach();
    printf( "attach rc=%d, mDicShmCount=%d\n", rc, sDic.mGetShmCount() );
    if ( rc ) exit( -1 );

    /*****************************************
     * Parser를 통해 Trans가 부를때 아래처럼.
     *****************************************/
    memset( &sTBS, 0x00, sizeof(sTBS) );
    strcpy( sTBS.mUndoName, "undo5" );
    strcpy( sTBS.mTBSName, "undo5" );
    sTBS.mInitSize = 1024;
    sTBS.mExtendSize = 1024* 1024;
    sTBS.mMaxSize = -1;

#if 0
    rc = sDic.mInsertTBS( &sTBS );
    printf( "insertTBS rc=%d\n", rc );
#else
    /*****************************************
     * 1개의 Undo 정보를 입력할때 예제.
     *****************************************/
    sObj.mSQLType = DBM_CREATE_UNDO;
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mInsert( &sObj );
    /*****************************************
     * 제대로 TBS_ID가 나오는지 확인한다.
     *****************************************/
    printf( "insertTBS rc=%d, TBS_ID=%ld\n", rc, ( ( dbmTBSDic*)&sObj.mObj )->mTBSID );
#endif

    /*****************************************
     * 이하 몇 개의 UNDO정보를 더 넣어본다.
     *****************************************/
    strcpy( sTBS.mUndoName, "undo1" );
    strcpy( sTBS.mTBSName, "undo1" );
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mInsert( &sObj );
    printf( "insertTBS rc=%d, TBS_ID=%ld\n", rc, ( ( dbmTBSDic*)&sObj.mObj )->mTBSID );


    strcpy( sTBS.mUndoName, "undo7" );
    strcpy( sTBS.mTBSName, "undo7" );
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mInsert( &sObj );
    printf( "insertTBS rc=%d, TBS_ID=%ld\n", rc, ( ( dbmTBSDic*)&sObj.mObj )->mTBSID );

    strcpy( sTBS.mUndoName, "undo2" );
    strcpy( sTBS.mTBSName, "undo2" );
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mInsert( &sObj );
    printf( "insertTBS rc=%d, TBS_ID=%ld\n", rc, ( ( dbmTBSDic*)&sObj.mObj )->mTBSID );

    strcpy( sTBS.mUndoName, "undo3" );
    strcpy( sTBS.mTBSName, "undo3" );
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mInsert( &sObj );
    printf( "insertTBS rc=%d, TBS_ID=%ld\n", rc, ( ( dbmTBSDic*)&sObj.mObj )->mTBSID );

    strcpy( sTBS.mUndoName, "undo6" );
    strcpy( sTBS.mTBSName, "undo6" );
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mInsert( &sObj );
    printf( "insertTBS rc=%d, TBS_ID=%ld\n", rc, ( ( dbmTBSDic*)&sObj.mObj )->mTBSID );

    strcpy( sTBS.mUndoName, "undo4" );
    strcpy( sTBS.mTBSName, "undo4" );
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mInsert( &sObj );
    printf( "insertTBS rc=%d, TBS_ID=%ld\n", rc, ( ( dbmTBSDic*)&sObj.mObj )->mTBSID );

    strcpy( sTBS.mUndoName, "undo6" );
    strcpy( sTBS.mTBSName, "undo6" );
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mInsert( &sObj );
    printf( "insertTBS rc=%d, TBS_ID=%ld\n", rc, ( ( dbmTBSDic*)&sObj.mObj )->mTBSID );


    /*****************************************
     * 특정 TBS를 Search해본다.
     *****************************************/
    memset( &sTBS, 0x00, sizeof(sTBS) );
    strcpy( sTBS.mUndoName, "undo2" );
    strcpy( sTBS.mTBSName, "undo2" );
    sObj.mSQLType = DBM_CREATE_UNDO;
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mSelect( &sObj );
    memcpy( &sTBS, &sObj.mObj, sizeof(dbmTBSDic) );
    printf( "SerchTBS( undo2) rc=%d [TBS_ID=%ld, Init=%ld, Extend=%ld, Max=%ld]\n", rc, sTBS.mTBSID, sTBS.mInitSize, sTBS.mExtendSize, sTBS.mMaxSize );

    /*****************************************
     * 특정 TBS를 Search해본다.
     *****************************************/
    memset( &sTBS, 0x00, sizeof(sTBS) );
    strcpy( sTBS.mUndoName, "undo6" );
    strcpy( sTBS.mTBSName, "undo6" );
    sObj.mSQLType = DBM_CREATE_UNDO;
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mSelect( &sObj );
    memcpy( &sTBS, &sObj.mObj, sizeof(dbmTBSDic) );
    printf( "SerchTBS rc=%d [TBS_ID=%ld, Init=%ld, Extend=%ld, Max=%ld]\n", rc, sTBS.mTBSID, sTBS.mInitSize, sTBS.mExtendSize, sTBS.mMaxSize );

    /*****************************************
     * 특정 TBS를 삭제해본다.
     *****************************************/
    memset( &sTBS, 0x00, sizeof(sTBS) );
    strcpy( sTBS.mUndoName, "undo2" );
    strcpy( sTBS.mTBSName, "undo2" );
    sObj.mSQLType = DBM_DROP_UNDO;
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mDelete( &sObj );
    printf( "delete TBS( undo2) rc=%d\n", rc );

    memset( &sTBS, 0x00, sizeof(sTBS) );
    strcpy( sTBS.mUndoName, "undo3" );
    strcpy( sTBS.mTBSName, "undo3" );
    sObj.mSQLType = DBM_CREATE_UNDO;
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mSelect( &sObj );
    memcpy( &sTBS, &sObj.mObj, sizeof(dbmTBSDic) );
    printf( "SerchTBS rc=%d [TBS_ID=%ld, Init=%ld, Extend=%ld, Max=%ld]\n", rc, sTBS.mTBSID, sTBS.mInitSize, sTBS.mExtendSize, sTBS.mMaxSize );

    strcpy( sTBS.mUndoName, "undo2" );
    strcpy( sTBS.mTBSName, "undo2" );
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mInsert( &sObj );
    printf( "insertTBS( undo2) rc=%d, TBS_ID=%ld\n", rc, ( ( dbmTBSDic*)&sObj.mObj )->mTBSID );

    memset( &sTBS, 0x00, sizeof(sTBS) );
    strcpy( sTBS.mUndoName, "undo2" );
    strcpy( sTBS.mTBSName, "undo2" );
    sObj.mSQLType = DBM_CREATE_UNDO;
    memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
    rc = sDic.mSelect( &sObj );
    memcpy( &sTBS, &sObj.mObj, sizeof(dbmTBSDic) );
    printf( "SerchTBS( undo2) rc=%d [TBS_ID=%ld, Init=%ld, Extend=%ld, Max=%ld]\n", rc, sTBS.mTBSID, sTBS.mInitSize, sTBS.mExtendSize, sTBS.mMaxSize );




    /*****************************************
     * 특정 Table을 넣어본다.
     *****************************************/
    memset( &sTable, 0x00, sizeof(sTable) );
    strcpy( sTable.mUndoName, "undo2" );
    strcpy( sTable.mTableName, "T5" );
    sTable.mColumnCount = 3;
    sTable.mRecordSize = 1024;
    sTable.mMaxSize = 1024* 1024;

    /*****************************************
     * 0번 컬럼
     *****************************************/
    memset( &sCol, 0x00, sizeof(dbmColumnDic) );
    strcpy( sCol.mColumnName, "emp" );
    sCol.mSize = 10;
    sCol.mPrecision = 10;
    sCol.mScale = 0;
    memcpy( &sColSet.mCols[0], &sCol, sizeof(dbmColumnDic) );

    /*****************************************
     * 1번 컬럼
     *****************************************/
    memset( &sCol, 0x00, sizeof(dbmColumnDic) );
    strcpy( sCol.mColumnName, "school" );
    sCol.mSize = 10;
    sCol.mPrecision = 10;
    sCol.mScale = 0;
    memcpy( &sColSet.mCols[1], &sCol, sizeof(dbmColumnDic) );

    /*****************************************
     * 2번 컬럼
     *****************************************/
    memset( &sCol, 0x00, sizeof(dbmColumnDic) );
    strcpy( sCol.mColumnName, "addr" );
    sCol.mSize = 10;
    sCol.mPrecision = 10;
    sCol.mScale = 0;
    memcpy( &sColSet.mCols[2], &sCol, sizeof(dbmColumnDic) );

    sColSet.mCount = 3;


    /*****************************************
     * 테이블을 넣자.
     *****************************************/
    memset( &sTableInfo, 0x00, sizeof(sTableInfo) );
    memcpy( &sTableInfo.mTable, &sTable, sizeof(dbmTableDic) );
    memcpy( &sTableInfo.mColumn, &sColSet, sizeof(dbmColumnSetDic) );

    sObj.mSQLType = DBM_CREATE_TABLE;
    memcpy( &sObj.mObj, &sTableInfo, sizeof(dbmTableInfo) );
    rc = sDic.mInsert( &sObj );
    printf( "mInsert table with Columns::  rc=%d( UNDO_ID=%ld, TABLE_ID=%ld )\n",
               rc, ( ( dbmTableInfo*)&sObj.mObj )->mTable.mUndoID, ( ( dbmTableInfo*)&sObj.mObj )->mTable.mTableID );


    /*****************************************
     * 테이블을 조회해보자. ( Undo, Table 이름 2개외에는 밖에서 모를꺼다. )
     *****************************************/
    memset( &sTableInfo, 0x00, sizeof(sTableInfo) );
    memset( &sTable, 0x00, sizeof(sTable) );
    strcpy( sTable.mUndoName, "undo2" );
    strcpy( sTable.mTableName, "T5" );
    memcpy( &sTableInfo.mTable, &sTable, sizeof(dbmTableDic) );
    memcpy( &sObj.mObj, &sTableInfo, sizeof(dbmTableInfo) );
    sObj.mSQLType = DBM_CREATE_TABLE;
    rc = sDic.mSelect( &sObj );
    memcpy( &sTableInfo, &sObj.mObj, sizeof(dbmTableInfo) );

    printf( "mSelect Table rc=%d( TABLE_ID=%ld, IndexCount=%d )\n", rc, sTableInfo.mTable.mTableID, sTableInfo.mIndexCount );
    for( i=0; i<sTableInfo.mColumn.mCount; i++ )
    {
        printf( "UNDO-TABLE_ID[%ld:%ld], ColID=[%d], ColName[%-32.32s], ColSize[%d]\n",
               sTableInfo.mColumn.mCols[i].mUndoID,
               sTableInfo.mColumn.mCols[i].mTableID,
               sTableInfo.mColumn.mCols[i].mColumnID,
               sTableInfo.mColumn.mCols[i].mColumnName,
               sTableInfo.mColumn.mCols[i].mSize );
    }


    /*****************************************
     * Column을 지워보자.
     *****************************************/



    /*****************************************
     * Index를 넣어보자.
     *****************************************/
    memset( &sIndex, 0x00, sizeof(sIndex) );
    strcpy( sIndex.mUndoName, "undo2" );
    strcpy( sIndex.mTableName, "T5" );
    strcpy( sIndex.mIndexName, "IDX_T5" );

    sIndex.mIndexType = DBM_INDEX_BTREE;
    sIndex.mColumnCount = 3;
    sIndex.mKeySize = 40;
    memcpy( &sIndex.mKey[0], &sTableInfo.mColumn.mCols[0], sizeof(dbmColumnDic) );
    memcpy( &sIndex.mKey[1], &sTableInfo.mColumn.mCols[1], sizeof(dbmColumnDic) );
    memcpy( &sIndex.mKey[2], &sTableInfo.mColumn.mCols[2], sizeof(dbmColumnDic) );

    sObj.mSQLType = DBM_CREATE_INDEX;
    memcpy( &sObj.mObj, &sIndex, sizeof(dbmIndexObject) );
    rc = sDic.mInsert( &sObj );
    printf( "insert index rc = %d\n", rc );

    /*****************************************
     * Index만 탐색.
     *****************************************/
    memset( &sIndex, 0x00, sizeof(sIndex) );
    strcpy( sIndex.mUndoName, "undo2" );
    strcpy( sIndex.mTableName, "T5" );
    strcpy( sIndex.mIndexName, "IDX_T5" );

    sObj.mSQLType = DBM_CREATE_INDEX;
    memcpy( &sObj.mObj, &sIndex, sizeof(dbmIndexObject) );
    rc = sDic.mSelect( &sObj );
    printf( "search index rc = %d, ( UNDO=%ld, TABLE=%ld, INDEX=%ld )\n", rc,
            ( ( dbmIndexObject*)&sObj.mObj )->mUndoID,
            ( ( dbmIndexObject*)&sObj.mObj )->mTableID,
            ( ( dbmIndexObject*)&sObj.mObj )->mIndexID );


    /*****************************************
     * 테이블을 조회해보자. ( Undo, Table 이름 2개외에는 밖에서 모를꺼다. )
     *****************************************/
    memset( &sTableInfo, 0x00, sizeof(sTableInfo) );
    memset( &sTable, 0x00, sizeof(sTable) );
    strcpy( sTable.mUndoName, "undo2" );
    strcpy( sTable.mTableName, "T5" );
    memcpy( &sTableInfo.mTable, &sTable, sizeof(dbmTableDic) );
    memcpy( &sObj.mObj, &sTableInfo, sizeof(dbmTableInfo) );
    sObj.mSQLType = DBM_CREATE_TABLE;
    rc = sDic.mSelect( &sObj );
    memcpy( &sTableInfo, &sObj.mObj, sizeof(dbmTableInfo) );

    printf( "mSelect Table rc=%d( TABLE_ID=%ld, IndexCount=%d )\n", rc, sTableInfo.mTable.mTableID, sTableInfo.mIndexCount );
    for( i=0; i<sTableInfo.mIndexCount; i++ )
    {
        printf( "IndexName = [%-32.32s]\n", sTableInfo.mIndex[i].mIndexName );
    }

    /*****************************************
     * Index만 삭제.
     *****************************************/
    memset( &sIndex, 0x00, sizeof(sIndex) );
    strcpy( sIndex.mUndoName, "undo2" );
    strcpy( sIndex.mTableName, "T5" );
    strcpy( sIndex.mIndexName, "IDX_T5" );

    sObj.mSQLType = DBM_DROP_INDEX;
    memcpy( &sObj.mObj, &sIndex, sizeof(dbmIndexObject) );
    printf( "Delete Index start\n" );
    rc = sDic.mDelete( &sObj );
    printf( "Index Delete rc = %d\n", rc );

    memset( &sIndex, 0x00, sizeof(sIndex) );
    strcpy( sIndex.mUndoName, "undo2" );
    strcpy( sIndex.mTableName, "T5" );
    strcpy( sIndex.mIndexName, "IDX_T5" );

    sIndex.mIndexType = DBM_INDEX_BTREE;
    sIndex.mColumnCount = 3;
    sIndex.mKeySize = 40;
    memcpy( &sIndex.mKey[0], &sTableInfo.mColumn.mCols[0], sizeof(dbmColumnDic) );
    memcpy( &sIndex.mKey[1], &sTableInfo.mColumn.mCols[1], sizeof(dbmColumnDic) );
    memcpy( &sIndex.mKey[2], &sTableInfo.mColumn.mCols[2], sizeof(dbmColumnDic) );

    sObj.mSQLType = DBM_CREATE_INDEX;
    memcpy( &sObj.mObj, &sIndex, sizeof(dbmIndexObject) );
    rc = sDic.mInsert( &sObj );
    printf( "insert index rc = %d\n", rc );

    /*****************************************
     * Table 삭제.
     *****************************************/
    memset( &sTableInfo, 0x00, sizeof(sTableInfo) );
    memset( &sTable, 0x00, sizeof(sTable) );
    strcpy( sTable.mUndoName, "undo2" );
    strcpy( sTable.mTableName, "T5" );
    memcpy( &sTableInfo.mTable, &sTable, sizeof(dbmTableDic) );
    memcpy( &sObj.mObj, &sTableInfo, sizeof(dbmTableInfo) );
    sObj.mSQLType = DBM_DROP_TABLE;
    printf( "delete table...start\n" );
    rc = sDic.mDelete( &sObj );
    printf( "mdelete table rc=%d\n", rc );


    /*****************************************
     * Dictionary shm 삭제.
     *****************************************/
    sDic.mDrop();
}


void randomTest( )
{
    dbmDicObject    sObj;
    dbmDictionary   sDic;
    dbmTBSDic       sTBS;
    dbmRID          sRID;
    dbmTableDic     sTable;
    dbmColumnDic    sCol;
    dbmColumnSetDic sColSet;
    dbmIndexDic     sIndex  ;
    dbmTableInfo    sTableInfo;
    int             count = 20;
    int             num[100] = {50, 1, 5, 9, 51, 70, 81, 90, 3, 4, 13, 8, 7, 6, 2, 71, 55, 23, 48, 100};

    int             i, j, rc;

    /*****************************************
     * 최초 Dic Creation시 예제
     *****************************************/
    sDic.mInitialize();
    rc = sDic.mCreate();
    printf( "create rc=%d\n", rc );
    if ( rc ) exit( -1 );

    /*****************************************
     * 사용자가 Attach할려면
     *****************************************/
    rc = sDic.mAttach();
    printf( "attach rc=%d, mDicShmCount=%d\n", rc, sDic.mGetShmCount() );
    if ( rc ) exit( -1 );


    /*****************************************
     * 1개의 Undo 정보를 입력할때 예제.
     *****************************************/
    for( i=0; i<count; i++ )
    {
        memset( &sTBS, 0x00, sizeof(sTBS) );
        sprintf( sTBS.mUndoName, "undo%010d", num[i] );
        sprintf( sTBS.mTBSName, "undo%010d", num[i] );
        sTBS.mInitSize = 1024;
        sTBS.mExtendSize = 1024* 1024;
        sTBS.mMaxSize = -1;

        memset( &sObj, 0x00, sizeof(sObj) );
        sObj.mSQLType = DBM_CREATE_UNDO;
        memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
        rc = sDic.mInsert( &sObj );
        if ( rc )
        {
            printf( "Insert(%d th )Error rc=%d\n", i, rc );
            exit( -1 );
        }
    }
    printf( "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" );
    sRID.mSegNo = -1;
    printf( "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" );
    /*****************************************
     * 0번 컬럼
     *****************************************/
    memset( &sCol, 0x00, sizeof(dbmColumnDic) );
    strcpy( sCol.mColumnName, "emp" );
    sCol.mSize = 10;
    sCol.mPrecision = 10;
    sCol.mScale = 0;
    memcpy( &sColSet.mCols[0], &sCol, sizeof(dbmColumnDic) );

    /*****************************************
     * 1번 컬럼
     *****************************************/
    memset( &sCol, 0x00, sizeof(dbmColumnDic) );
    strcpy( sCol.mColumnName, "school" );
    sCol.mSize = 10;
    sCol.mPrecision = 10;
    sCol.mScale = 0;
    memcpy( &sColSet.mCols[1], &sCol, sizeof(dbmColumnDic) );

    /*****************************************
     * 2번 컬럼
     *****************************************/
    memset( &sCol, 0x00, sizeof(dbmColumnDic) );
    strcpy( sCol.mColumnName, "addr" );
    sCol.mSize = 10;
    sCol.mPrecision = 10;
    sCol.mScale = 0;
    memcpy( &sColSet.mCols[2], &sCol, sizeof(dbmColumnDic) );

    sColSet.mCount = 3;



    for( j=0; j<count; j++ )
    {
        memset( &sTBS, 0x00, sizeof(sTBS) );
        sprintf( sTBS.mUndoName, "undo%010d", num[j] );
        sprintf( sTBS.mTBSName, "undo%010d", num[j] );

        memset( &sObj, 0x00, sizeof(sObj) );
        sObj.mSQLType = DBM_DROP_UNDO;
        memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
        rc = sDic.mDelete( &sObj );
        if ( rc )
        {
            printf( "Delete(%d th )Error rc=%d\n", j, rc );
            break;
        }

        memset( &sTBS, 0x00, sizeof(sTBS) );
        sprintf( sTBS.mUndoName, "undo%010d", num[j] );
        sprintf( sTBS.mTBSName, "undo%010d", num[j] );

        memset( &sObj, 0x00, sizeof(sObj) );
        sObj.mSQLType = DBM_CREATE_UNDO;
        memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
        rc = sDic.mInsert( &sObj );
        if ( rc )
        {
            printf( "Retry Insert(%d th )Error rc=%d\n", j, rc );
            break;
        }
    }
    printf( "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" );
    sRID.mSegNo = -1;
    printf( "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" );

    memset( &sIndex, 0x00, sizeof(sIndex) );
    strcpy( sIndex.mUndoName, "undo0000000050" );
    strcpy( sIndex.mTableName, "table0000000001" );
    strcpy( sIndex.mIndexName, "IDX_T1" );

    sIndex.mIndexType = DBM_INDEX_BTREE;
    sIndex.mColumnCount = 3;
    sIndex.mKeySize = 40;
    memcpy( &sIndex.mKey[0], &sTableInfo.mColumn.mCols[0], sizeof(dbmColumnDic) );
    memcpy( &sIndex.mKey[1], &sTableInfo.mColumn.mCols[1], sizeof(dbmColumnDic) );
    memcpy( &sIndex.mKey[2], &sTableInfo.mColumn.mCols[2], sizeof(dbmColumnDic) );

    sObj.mSQLType = DBM_CREATE_INDEX;
    memcpy( &sObj.mObj, &sIndex, sizeof(dbmIndexObject) );
    rc = sDic.mInsert( &sObj );
    printf( "insert index rc = %d\n", rc );



    /*****************************************
     * GetFirst
     *****************************************/
    memset( &sObj, 0x00, sizeof(sObj) );
    sObj.mSQLType = DBM_CREATE_UNDO;
    rc = sDic.mGetFirst( &sObj );
    printf( "getFirst rc=%d, [%-64.64s]\n", rc, ( ( dbmTBSDic*)&sObj.mObj )->mUndoName );

#if 1
    while ( 1 )
    {
        sObj.mSQLType = DBM_CREATE_UNDO;
        rc = sDic.mGetNext( &sObj );
        if ( rc ) break;
        printf( "getNext rc=%d, [%-64.64s]\n", rc, ( ( dbmTBSDic*)&sObj.mObj )->mUndoName );
    }
#endif

    /*****************************************
     * Dictionary shm 삭제.
     *****************************************/
    sDic.mDrop();
}




void randomTest2( int opt )
{
    dbmDicObject    sObj;
    dbmDictionary   sDic;
    dbmTBSDic       sTBS;
    dbmTableDic     sTable;
    dbmIndexDic     sIndex  ;
    dbmColumnDic    sCol;
    dbmColumnSetDic sColSet;
    dbmTableInfo    sTableInfo;
    dbmRID          sRID;
    int             count = 20;
    int             num[100] = {50, 1, 5, 9, 51, 70, 81, 90, 3, 4, 13, 8, 7, 6, 2, 71, 55, 23, 48, 100};

    int i, j, rc;

    /*****************************************
     * 최초 Dic Creation시 예제
     *****************************************/
    sDic.mInitialize();
    rc = sDic.mCheck();
    printf("mCheck stage1, rc=%d\n", rc);

    rc = sDic.mCreate();
    printf( "create rc=%d\n", rc );
    //if ( rc ) exit( -1 );

    rc = sDic.mCheck();
    printf("mCheck stage2, rc=%d\n", rc);
    /*****************************************
     * 사용자가 Attach할려면
     *****************************************/
    rc = sDic.mAttach();
    printf( "attach rc=%d, mDicShmCount=%d\n", rc, sDic.mGetShmCount() );
    if ( rc ) exit( -1 );

    rc = sDic.mCheck();
    printf("mCheck stage3, rc=%d\n", rc);

    /*****************************************
     * 1개의 Undo 정보를 입력할때 예제.
     *****************************************/
    i = 0;
    {
        memset( &sTBS, 0x00, sizeof(sTBS) );
        sprintf( sTBS.mUndoName, "lim272");
        sprintf( sTBS.mTBSName, "lim272");
        sTBS.mInitSize = 1024;
        sTBS.mExtendSize = 1024* 1024;
        sTBS.mMaxSize = -1;

        memset( &sObj, 0x00, sizeof(sObj) );
        sObj.mSQLType = DBM_CREATE_UNDO;
        memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
        rc = sDic.mInsert( &sObj );
        if ( rc )
        {
            printf( "Insert(%d th )Error rc=%d\n", i, rc );
            exit( -1 );
        }
    }

    i = 0;
    {
        memset( &sTBS, 0x00, sizeof(sTBS) );
        sprintf( sTBS.mUndoName, "lim272");
        sprintf( sTBS.mTBSName, "DATA0");
        sTBS.mInitSize = 1024;
        sTBS.mExtendSize = 1024* 1024;
        sTBS.mMaxSize = -1;

        memset( &sObj, 0x00, sizeof(sObj) );
        sObj.mSQLType = DBM_CREATE_DATA;
        memcpy( &sObj.mObj, &sTBS, sizeof(dbmTBSDic) );
        rc = sDic.mInsert( &sObj );
        if ( rc )
        {
            printf( "Insert(%d th )Error rc=%d\n", i, rc );
            exit( -1 );
        }
    }

    /*****************************************
     * 0번 컬럼
     *****************************************/
    memset( &sCol, 0x00, sizeof(dbmColumnDic) );
    strcpy( sCol.mColumnName, "emp" );
    sCol.mSize = 10;
    sCol.mPrecision = 10;
    sCol.mScale = 0;
    memcpy( &sColSet.mCols[0], &sCol, sizeof(dbmColumnDic) );

    /*****************************************
     * 1번 컬럼
     *****************************************/
    memset( &sCol, 0x00, sizeof(dbmColumnDic) );
    strcpy( sCol.mColumnName, "school" );
    sCol.mSize = 10;
    sCol.mPrecision = 10;
    sCol.mScale = 0;
    memcpy( &sColSet.mCols[1], &sCol, sizeof(dbmColumnDic) );

    /*****************************************
     * 2번 컬럼
     *****************************************/
    memset( &sCol, 0x00, sizeof(dbmColumnDic) );
    strcpy( sCol.mColumnName, "addr" );
    sCol.mSize = 10;
    sCol.mPrecision = 10;
    sCol.mScale = 0;
    memcpy( &sColSet.mCols[2], &sCol, sizeof(dbmColumnDic) );

    sColSet.mCount = 3;


    for( j=0; j<count; j++ )
    {
        memset( &sTable, 0x00, sizeof(sTable) );
        sprintf( sTable.mUndoName, "lim272");
        sprintf( sTable.mTableName, "table%010d", num[j] );
        sTable.mInitSize = 10240000;
        sTable.mExtendSize = cmnGetBuddy( 10240000 );
        sTable.mColumnCount = 3;
        sTable.mRecordSize = 600;
        memset( &sObj, 0x00, sizeof(sObj) );
        sObj.mSQLType = DBM_CREATE_TABLE;
        memcpy (&( ( dbmTableInfo*)&sObj.mObj )->mColumn, &sColSet, sizeof(dbmColumnSetDic));
        memcpy( &( ( dbmTableInfo*)&sObj.mObj )->mTable, &sTable, sizeof(dbmTableDic) );
        rc = sDic.mInsert( &sObj );
        if ( rc )
        {
            printf( "Insert Table(%d th )Error rc=%d\n", j, rc );
            break;
        }
    }

    memset( &sIndex, 0x00, sizeof(sIndex) );
    strcpy( sIndex.mUndoName, "undo0000000050" );
    strcpy( sIndex.mTableName, "table0000000001" );
    strcpy( sIndex.mIndexName, "IDX_T1" );

    sIndex.mIndexType = DBM_INDEX_BTREE;
    sIndex.mColumnCount = 3;
    sIndex.mKeySize = 40;

    sObj.mSQLType = DBM_DROP_INDEX;
    memcpy( &sObj.mObj, &sIndex, sizeof(dbmIndexObject) );
    rc = sDic.mDelete( &sObj );
    printf( "Delete index rc = %d\n", rc );


    sObj.mSQLType = DBM_CREATE_INDEX;
    memcpy( &sObj.mObj, &sIndex, sizeof(dbmIndexObject) );
    rc = sDic.mInsert( &sObj );
    printf( "insert index rc = %d\n", rc );

    sObj.mSQLType = DBM_DROP_INDEX;
    memcpy( &sObj.mObj, &sIndex, sizeof(dbmIndexObject) );
    rc = sDic.mDelete( &sObj );
    printf( "Delete index rc = %d\n", rc );

    printf( "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" );
    sDic.mPrintAll();
    printf( "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n" );

    memset( &sTableInfo, 0x00, sizeof(sTableInfo) );
    memset( &sTable, 0x00, sizeof(sTable) );
    strcpy( sTable.mUndoName, "lim272");
    strcpy( sTable.mTableName, "table0000000001" );
    memcpy( &sTableInfo.mTable, &sTable, sizeof(dbmTableDic) );
    memcpy( &sObj.mObj, &sTableInfo, sizeof(dbmTableInfo) );
    sObj.mSQLType = DBM_CREATE_TABLE;
    rc = sDic.mSelect( &sObj );
    memcpy( &sTableInfo, &sObj.mObj, sizeof(dbmTableInfo) );

    printf( "mSelect Table (%s) rc=%d( TABLE_ID=%ld, IndexCount=%d )\n", sTable.mTableName, rc, sTableInfo.mTable.mTableID, sTableInfo.mIndexCount );

#if 0
    /*****************************************
     * GetFirst
     *****************************************/
    memset( &sObj, 0x00, sizeof(sObj) );
    sprintf( sTable.mUndoName, "undo%010d", num[0] );

    sObj.mSQLType = DBM_CREATE_TABLE;
    memcpy( &( ( dbmTableInfo*)&sObj.mObj )->mTable, &sTable, sizeof(dbmTableDic) );

    rc = sDic.mGetFirst( &sObj );
    printf( "getFirst rc=%d, [%-64.64s], Init=%ld, extend=%ld, indexCount=%d\n", rc,
                          ( ( dbmTableInfo*)&sObj.mObj )->mTable.mTableName
                        , ( ( dbmTableInfo*)&sObj.mObj )->mTable.mInitSize
                        , ( ( dbmTableInfo*)&sObj.mObj )->mTable.mExtendSize
                        , ( ( dbmTableInfo*)&sObj.mObj )->mTable.mRecordSize
                        , ( ( dbmTableInfo*)&sObj.mObj )->mIndexCount);

#if 1
    while ( 1 )
    {
        sObj.mSQLType = DBM_CREATE_TABLE;
        rc = sDic.mGetNext( &sObj );
        if ( rc ) break;
        printf( "getNext rc=%d, [%-64.64s], Init=%ld, extend=%ld\n", rc,
                          ( ( dbmTableInfo*)&sObj.mObj )->mTable.mTableName
                        , ( ( dbmTableInfo*)&sObj.mObj )->mTable.mInitSize
                        , ( ( dbmTableInfo*)&sObj.mObj )->mTable.mExtendSize
                        , ( ( dbmTableInfo*)&sObj.mObj )->mTable.mRecordSize
                        , ( ( dbmTableInfo*)&sObj.mObj )->mIndexCount);
    }
#endif

    memset( &sTableInfo, 0x00, sizeof(sTableInfo) );
    memset( &sTable, 0x00, sizeof(sTable) );
    strcpy( sTable.mUndoName, "lim272");
    strcpy( sTable.mTableName, "table0000000001" );
    memcpy( &sTableInfo.mTable, &sTable, sizeof(dbmTableDic) );
    memcpy( &sObj.mObj, &sTableInfo, sizeof(dbmTableInfo) );
    sObj.mSQLType = DBM_CREATE_TABLE;
    rc = sDic.mSelect( &sObj );
    memcpy( &sTableInfo, &sObj.mObj, sizeof(dbmTableInfo) );

    printf( "mSelect Table rc=%d( TABLE_ID=%ld, IndexCount=%d )\n", rc, sTableInfo.mTable.mTableID, sTableInfo.mIndexCount );

#endif


    /*****************************************
     * Dictionary shm 삭제.
     *****************************************/
    if (opt == 1)
    {
        sDic.mDrop();
        fprintf(stdout, "Dictionary Dropped.........\n");
    }
    else
    {
        system("ls -lrt $DBM_HOME/dic/*");
    }
}



void onlyList(  )
{
    dbmDicObject    sObj;
    dbmDictionary   sDic;
    dbmTBSDic       sTBS;
    dbmTableDic     sTable;
    dbmRID          sRID;
    dbmTableInfo    sTableInfo;
    int             count = 20;
    int             num[100] = {50, 1, 5, 9, 51, 70, 81, 90, 3, 4, 13, 8, 7, 6, 2, 71, 55, 23, 48, 100};

    int i, j, rc;

    system("./rmipc");
    printf("########################################################################################################\n");
    /*****************************************
     * Recover확인.
     *****************************************/
    sDic.mInitialize();
    rc = sDic.mCheck();
    printf("mCheck stage4 rc=%d\n", rc);

    sDic.mRecover();
    //sDic.mRecoverLog();


    /*****************************************
     * GetFirst
     *****************************************/
    memset( &sObj, 0x00, sizeof(sObj) );
    sprintf( sTable.mUndoName, "lim272");

    sObj.mSQLType = DBM_CREATE_TABLE;
    memcpy( &( ( dbmTableInfo*)&sObj.mObj )->mTable, &sTable, sizeof(dbmTableDic) );

    rc = sDic.mGetFirst( &sObj );
    printf( "getFirst rc=%d, [%-64.64s], recSize=%d\n", rc, ( ( dbmTableDic*)&sObj.mObj )->mTableName,
                                                            ( ( dbmTableDic*)&sObj.mObj )->mRecordSize );

#if 1
    while ( 1 )
    {
        sObj.mSQLType = DBM_CREATE_TABLE;
        rc = sDic.mGetNext( &sObj );
        if ( rc ) break;
        printf( "getNext rc=%d, [%-64.64s], recSize=%d\n", rc, ( ( dbmTableDic*)&sObj.mObj )->mTableName,
                                                            ( ( dbmTableDic*)&sObj.mObj )->mRecordSize );
    }
#endif

    memset( &sTableInfo, 0x00, sizeof(sTableInfo) );
    memset( &sTable, 0x00, sizeof(sTable) );
    strcpy( sTable.mUndoName, "lim272");
    strcpy( sTable.mTableName, "table0000000001" );
    memcpy( &sTableInfo.mTable, &sTable, sizeof(dbmTableDic) );
    memcpy( &sObj.mObj, &sTableInfo, sizeof(dbmTableInfo) );
    sObj.mSQLType = DBM_CREATE_TABLE;
    rc = sDic.mSelect( &sObj );
    memcpy( &sTableInfo, &sObj.mObj, sizeof(dbmTableInfo) );

    printf( "mSelect Table rc=%d( TABLE_ID=%ld, IndexCount=%d )\n", rc, sTableInfo.mTable.mTableID, sTableInfo.mIndexCount );


    //sDic.mDrop();
}




int main(int argc, char *argv[] )
{
    //testAllocFree();
    //testTBS();
    //randomTest();
    if (argc == 1)
    {
        //randomTest2(1);
        randomTest2(0);
        onlyList();
    }
    else
    {
        onlyList();
    }
}
