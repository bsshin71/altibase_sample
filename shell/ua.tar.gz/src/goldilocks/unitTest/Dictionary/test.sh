rmipc 
rm -f $DBM_HOME/dic/*
./test
