#!/bin/sh

source $DBM_HOME/shl/test.env.sh

export UNDO_NAME=lim272_undo
export TABLE_NAME=lim272_t1

res=0

sh initBig.sh
usleep 10000

# make clean; make test6

run="./test6"
test_and_valgrind
res=$?

########################################
# Finally
########################################
test "x"$res == "x0" && rmipc

