#!/bin/sh

# pkill test
# make clean; make all
# rm -f $DBM_HOME/dic/*
# rm -f $DBM_HOME/WAL/*
# rmipc


# ls -lrt $DBM_HOME/dic/*

metaManager << EOF_
--initdb;
--drop undo $UNDO_NAME;
--create undo $UNDO_NAME;
drop table $TABLE_NAME;
create table $TABLE_NAME
c1 char 20 0
c2 int 10 0
c3 int 10 0
init 10000000 extend 1000000 max 120000000;
--init 10000000 extend 1000000 max 12000000;
create index idx_$TABLE_NAME on $TABLE_NAME c2;
list
exit
EOF_
