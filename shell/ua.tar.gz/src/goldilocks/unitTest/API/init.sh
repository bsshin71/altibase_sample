pkill test
make clean; make all
rm -f /dev/shm/lim272/*
rm -f $DBM_HOME/dic/*
rm -f $DBM_HOME/WAL/*
rmipc

metaManager << EOF_
initdb;
drop undo lim272_undo;
create undo lim272_undo;
drop table lim272_t1;
create table lim272_t1
c1 char 20 0
c2 int 10 0
c3 int 10 0
init 10000000 extend 1000000 max 12000000;
create index idx_lim272_t1 on lim272_t1 c1;

drop table item;
create table item
itemcd char 8
itemnm char 20
highprc double 10 2
lowprc double 10 2
smaxprc double 10 2
minprc double 10 2
currprc double 10 2
trdqty long 15 0
trdamt long 15 0
init 10000 extend 10000 max 1000000;
create index item_idx1 on item itemcd;

drop table accnt;
create table accnt
accntno char 8
accntnm char 20
ablemoney long 15 0
unsettle long 15 0
init 30000 extend 10000 max 1000000;
create index accnt_idx1 on accnt accntno;

drop table ordno;
create table ordno
brcd char 3
ordno long 8 0
init 10 extend 100 max 1000;
create index ordno_idx1 on ordno brcd;

drop table order;
create table order
accntno char 8
itemcd  char 8
ordprc  long 8 0
ordqty  long 8 0
ordno   long 8 0
init 1000000 extend 100000 max 10000000;
create index order_idx1 on order accntno itemcd ordno;
create index order_idx2 on order ordno;
list
exit
EOF_
