/******************************************************************************
 * Copyright 2012, OnmirSoft Corporation or its subsidiaries.
 * All rights reserved.
 ******************************************************************************/

/*
 * Demo : dbmSelectRowGT
 */
#include <dbmAPI.h>

#define LOOP 5000000    // 500만

typedef struct data
{
    int     c1;
    char    c2[10];
    char    c3[10];
    int     c4;
} data;

char INSTANCE_NAME[34];
char TABLE_NAME[34];

int main ( int argc , char **argv )
{
    dbmHandle   handle;
    data*       pdata;
    int         rc;
    int         i;
    int         sCount=0;
    struct timespec start, end;

    if (getenv("UNDO_NAME") == NULL)
    {
        printf("export UNDO_NAME\n");
        exit(-1);
    }
    if (getenv("TABLE_NAME") == NULL)
    {
        printf("export TABLE_NAME\n");
        exit(-1);
    }

    sprintf(INSTANCE_NAME, "%s", getenv("UNDO_NAME"));
    sprintf(TABLE_NAME, "%s", getenv("TABLE_NAME"));

    pdata = (data*) malloc ( sizeof(data) );

    /*------------------------------------------------------
     * allocate handle & transaction
     ------------------------------------------------------*/
    rc = dbmInitHandle ( &handle, INSTANCE_NAME );
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    /*------------------------------------------------------
     * prepare table
     ------------------------------------------------------*/
    rc = dbmPrepareTable ( &handle, TABLE_NAME);
    if (rc)
    {
        printf("prepare %s rc=%d (%s)\n", (char*)TABLE_NAME, rc, dbmGetError(rc) );
        exit(-1);
    }

    /*------------------------------------------------------
     * truncate table ( remove test dependency )
     ------------------------------------------------------*/
    rc = dbmTruncate(&handle, TABLE_NAME );
    if (rc)
    {
        printf("truncate %s rc=%d (%s)\n", (char*)TABLE_NAME, rc, dbmGetError(rc) );
        exit(-1);
    }

    /*------------------------------------------------------
     * insert record into table
     ------------------------------------------------------*/
    for (i=1; i<=LOOP; i++)
    {
        pdata->c1 = i;
        sprintf( pdata->c2, "%d", i);
        sprintf( pdata->c3, "%d", i);
        pdata->c4 = i;
        rc = dbmInsertRow (&handle, TABLE_NAME, pdata, sizeof(data));
        if (rc)
        {
            printf("insert %s rc=%d (%s)\n", (char*)TABLE_NAME, rc, dbmGetError(rc) );
            exit(-1);
        }
        rc = dbmCommit(&handle);
        if (rc)
        {
            printf("commit %s rc=%d (%s)\n", (char*)TABLE_NAME, rc, dbmGetError(rc) );
            exit(-1);
        }
    }

    /*------------------------------------------------------
     * update
     ------------------------------------------------------*/
    clock_gettime(CLOCK_REALTIME, &start);
    for (i=1; i<=LOOP; i++)
    {
        pdata->c1 = i;
        sprintf( pdata->c2, "%010d", i);
        sprintf( pdata->c3, "%010d", i);
        pdata->c4 = i;

        rc = dbmUpdateRow ( &handle, TABLE_NAME, pdata );
        if ( rc )
        {
            printf("update %s c2=%d rc=%d (%s)\n", (char*)TABLE_NAME, pdata->c2, rc, dbmGetError(rc) );
            exit(-1);
        }
        rc = dbmCommit(&handle);
        if (rc)
        {
            printf("commit %s rc=%d (%s)\n", (char*)TABLE_NAME, rc, dbmGetError(rc) );
            exit(-1);
        }
        sCount++;
    }
    clock_gettime(CLOCK_REALTIME, &end);

    double elapse = (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0));
    printf("#%-20s sCount=%d TPS=%-10d (Elap=%-15.9f)\n", "dbmUpdateRow", sCount, (int)((double)sCount/elapse), elapse);

    /*------------------------------------------------------
     * finalize handle & transaction
     ------------------------------------------------------*/
    dbmFreeHandle ( &handle );

    return 0;
}
