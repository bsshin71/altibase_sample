#!/bin/sh

export DBM_TRCLOG_ECHO=0

#export UNDO_NAME=test_undo
export UNDO_NAME=$DBM_INSTANCE  # demo
export TABLE_NAME=t1

set -x

sh initBig.sh
usleep 10000

# make clean; make test6

./test6
rc=$?

set +x

########################################
# Finally
########################################
#test "x"$rc == "x0" && rmipc

# 정상종료 여부를 상위단으로 알려주어야 한다.
exit $rc

