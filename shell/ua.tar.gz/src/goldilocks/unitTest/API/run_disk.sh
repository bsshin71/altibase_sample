#!/bin/sh

export DBM_TRCLOG_ECHO=0

export UNDO_NAME=demo_disk
export TABLE_NAME=disk_t1

res=0

set -x

sh initBig.sh
usleep 10000

# make clean; make test6

test6_disk
res=$?

set +x

########################################
# Finally
########################################
#test "x"$res == "x0" && rmipc

