
#include "dbmHeader.h"

typedef struct
{
    int c1;
    int c2;
    int c3;
} TABLE;


#define UNDO_NAME  "lim272_undo"
#define TABLE_NAME "lim272_t1"
#define THR  1
#define LOOP 1000000



typedef struct
{
    int start;
    int aCount;
} PARAM;


void *thr1(void*);
void *thr2(void *);



void *thr1(void *param)
{
    dbmHandle sHandle;
    int rc;
    int i;
    int nStart, nEnd, aCount;
    TABLE  data;
    struct timespec start, end;
    char buff[8192];


    nStart = (int)(((PARAM*)param)->start);
    aCount = (int)(((PARAM*)param)->aCount);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);


    rc = dbmInitHandle (&sHandle, (char*)UNDO_NAME);
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, (char*)TABLE_NAME);
    if (rc)
    {
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }
    rc = dbmPrepareTable (&sHandle, (char*)"lim272_t2");
    if (rc)
    {
        printf("prepare t2 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }


    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=4; i>=1; i--)
    {
        memset(&data, 0x00, sizeof(TABLE));
        data.c1 = i;

        rc = dbmSelectForUpdateRow (&sHandle, (char*)TABLE_NAME, (char*)&data);
        if (rc)
        {
            printf("Forupdate (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            exit(-1);
        }
        data.c2 = data.c2 + 1;
        data.c3 = data.c3 + 1;


        memcpy(buff, &data.c1, sizeof(int));
        //rc = dbmUpdateRow (&sHandle, (char*)TABLE_NAME, (char*)&data);
        rc = dbmUpdateRow (&sHandle, (char*)TABLE_NAME, (char*)buff);
        if (rc)
        {
            printf("update (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            exit(-1);
        }

        memset(&data, 0x00, sizeof(TABLE));
        data.c1 = i;
        rc = dbmSelectForUpdateRow (&sHandle, (char*)"lim272_t2", (char*)&data);
        if (rc)
        {
            printf("Forupdate (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            exit(-1);
        }
        data.c2 = data.c2 + 1;
        data.c3 = data.c3 + 1;

        memcpy(buff, &data.c1, sizeof(int));
        //rc = dbmUpdateRow (&sHandle, (char*)"lim272_t2", (char*)&data);
        rc = dbmUpdateRow (&sHandle, (char*)TABLE_NAME, (char*)buff);
        if (rc)
        {
            printf("update (%s) (row=%d) rc=%d (%s)\n", "lim272_t2", i, rc, dbmGetError(rc) );
            exit(-1);
        }
        sleep(1);
#if 0
        if (i !=0 && (i % 10000) == 0) printf ("%d rows inserted..\n", i - nStart);
#endif
    }
    printf("Update Sleep...\n");
    sleep(10);
    clock_gettime_s(CLOCK_REALTIME, &end);
    printf("LOOP=%d, i=%d, Elap=%.9f\n",
            LOOP, i, (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0)));

    memset(&data, 0x00, sizeof(data));
    data.c1 = 1;
    rc = dbmSelectRowGT (&sHandle, (char*)TABLE_NAME, (char*)&data);
    printf("GT T1, rc = %d, data.c1 = (%d, %d, %d)\n", rc, data.c1, data.c2, data.c3);

    dbmFreeHandle (&sHandle);
    return NULL;
}


void *thr2(void *param)
{
    dbmHandle sHandle;
    int rc;
    int i;
    int nStart, nEnd, aCount;
    TABLE  data;
    struct timespec start, end;


    nStart = (int)(((PARAM*)param)->start);
    aCount = (int)(((PARAM*)param)->aCount);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);


    rc = dbmInitHandle (&sHandle, (char*)UNDO_NAME);
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, (char*)TABLE_NAME);
    if (rc)
    {
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }
    rc = dbmPrepareTable (&sHandle, (char*)"lim272_t2");
    if (rc)
    {
        printf("prepare t2 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }


    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=1; i<10; i++)
    {
        memset(&data, 0x00, sizeof(TABLE));
        data.c1 = i;

        rc = dbmSelectRow (&sHandle, (char*)TABLE_NAME, (char*)&data);
        if (rc)
        {
            printf("Select (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            break;
        }
        printf("T1: (%d, %d, %d)\n", data.c1, data.c2, data.c3);

        rc = dbmSelectRow (&sHandle, (char*)"lim272_t2", (char*)&data);
        if (rc)
        {
            printf("Select (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            break;
        }
        printf("T2: (%d, %d, %d)\n", data.c1, data.c2, data.c3);

        sleep(1);

#if 0
        rc = dbmCommit (&sHandle);
        if (rc)
        {
            printf("Commit t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }
#endif
#if 0
        if (i !=0 && (i % 10000) == 0) printf ("%d rows inserted..\n", i - nStart);
#endif
    }
    clock_gettime_s(CLOCK_REALTIME, &end);
    printf("LOOP=%d, i=%d, Elap=%.9f\n",
            LOOP, i, (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0)));

    dbmFreeHandle (&sHandle);
    return NULL;
}




int main()
{
    pthread_t tid[THR*2];
    int i, start;
    PARAM  param[THR*2];
    dbmHandle sHandle;


#if 1
    // Perf Test
    start = 0;
    for (i=0;i<THR*2;i=i+2)
    {
        param[i].start = start;
        param[i].aCount = 0;
        pthread_create(&tid[i], NULL, thr1, &param[i]);

        param[i+1].start = start;
        param[i+1].aCount = 0;
        pthread_create(&tid[i+1], NULL, thr2, &param[i+1]);
    }
    for (i=0;i<THR*2;i++)
    {
        pthread_join(tid[i], NULL);
    }
#endif

#if 0
    // Perf Test
    start = 0;
    for (i=0;i<THR;i++)
    {
        param[i].start = start;
        param[i].aCount = 0;
        pthread_create(&tid[i], NULL, thr2, &param[i]);
        start = start + (LOOP / THR);
    }
    for (i=0;i<THR;i++)
    {
        pthread_join(tid[i], NULL);
    }
#endif

    return 0;
}
