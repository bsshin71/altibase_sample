#include "dbmHeader.h"

typedef struct
{
    char c1[20];
    int c2;
    int c3;
} TABLE;


char UNDO_NAME[34];
char TABLE_NAME[34];

int THR = 1;
#define LOOP 5000000


typedef struct
{
    int idx;
    int start;
    int aCount;
    double tps;
} PARAM;

PARAM gParam[100];

void *thr1(void*);
void *thr2(void *);
void *thr3(void *);
void *thr4(void *);



void *thr1(void *param)
{
    dbmHandle sHandle;
    int rc;
    int i;
    int		nStart;
    int		nEnd;
    int         idx;
    TABLE  data;
    struct timespec start, end;


    idx = (int)(((PARAM*)param)->idx);
    nStart = (int)(((PARAM*)param)->start);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);


    rc = dbmInitHandle (&sHandle, (char*)UNDO_NAME);
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, (char*)TABLE_NAME);
    if (rc)
    {
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    //for (i=nEnd-1; i>=nStart; i--)
    {
        memset(&data, 0x00, sizeof(TABLE));
        sprintf(data.c1, "%019d", i);
        //data.c1 = i;
        data.c2 = i;
        data.c3 = 0;

        rc = dbmInsertRow (&sHandle, (char*)TABLE_NAME, (char*)&data, sizeof(TABLE));
        if (rc)
        {
            printf("Insert (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            exit(-1);
        }

        rc = dbmCommit (&sHandle);
        if (rc)
        {
            //printf("Commit t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }

#if 0
        if (i !=0 && (i % 10000) == 0) printf ("%d rows inserted..\n", i - nStart);
#endif
    }
    clock_gettime_s(CLOCK_REALTIME, &end);
    gParam[idx].tps = LOOP/THR/((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0));
    dbmFreeHandle (&sHandle);
    return NULL;
}





void *thr2(void *param)
{
    dbmHandle sHandle;
    int rc;
    int i;
    int		nStart;
    int		nEnd;
    int         idx;
    TABLE  data;
    struct timespec start, end;


    idx = (int)(((PARAM*)param)->idx);
    nStart = (int)(((PARAM*)param)->start);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);


    rc = dbmInitHandle (&sHandle, (char*)UNDO_NAME);
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, (char*)TABLE_NAME);
    if (rc)
    {
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    {
        memset(&data, 0x00, sizeof(TABLE));
        sprintf(data.c1, "%019d", i);
        data.c2 = i;

        rc = dbmSelectRow (&sHandle, (char*)TABLE_NAME, (char*)&data);
        if (rc)
        {
            printf("SelectFail (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            exit(-1);
        }

#if 0
        rc = dbmCommit (&sHandle);
        if (rc)
        {
            printf("Commit t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }
#endif
#if 0
        if (i !=0 && (i % 10000) == 0) printf ("%d rows inserted..\n", i - nStart);
#endif
    }
    clock_gettime_s(CLOCK_REALTIME, &end);
    gParam[idx].tps = LOOP/THR/((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0));

    dbmFreeHandle (&sHandle);
    return NULL;
}


void *thr3(void *param)
{
    dbmHandle sHandle;
    int rc;
    int i, j;
    int		nStart;
    int		nEnd;
    int         idx;
    //int		aCount;
    TABLE  data;
    struct timespec start, end;


    idx = (int)(((PARAM*)param)->idx);
    nStart = (int)(((PARAM*)param)->start);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);


    rc = dbmInitHandle (&sHandle, (char*)UNDO_NAME);
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, (char*)TABLE_NAME);
    if (rc)
    {
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    {
        memset(&data, 0x00, sizeof(TABLE));
        sprintf(data.c1, "%019d", i);
        data.c2 = i;

        rc = dbmUpdateRow (&sHandle, (char*)TABLE_NAME, (char*)&data);
        if (rc)
        {
            printf("SelectFail (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            break;
        }

#if 1
        rc = dbmCommit (&sHandle);
        if (rc)
        {
            printf("Commit t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }
#endif
#if 0
        if (i !=0 && (i % 10000) == 0) printf ("%d rows inserted..\n", i - nStart);
#endif
    }
    clock_gettime_s(CLOCK_REALTIME, &end);
    gParam[idx].tps = LOOP/THR/((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0));

    dbmFreeHandle (&sHandle);
    return NULL;
}



void *thr4(void *param)
{
    dbmHandle sHandle;
    int rc;
    int i, j;
    int		nStart;
    int		nEnd;
    int         idx;
    TABLE  data;
    struct timespec start, end;


    idx = (int)(((PARAM*)param)->idx);
    nStart = (int)(((PARAM*)param)->start);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);


    rc = dbmInitHandle (&sHandle, (char*)UNDO_NAME);
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, (char*)TABLE_NAME);
    if (rc)
    {
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    {
        memset(&data, 0x00, sizeof(TABLE));
        sprintf(data.c1, "%019d", i);
        data.c2 = i;

        rc = dbmDeleteRow (&sHandle, (char*)TABLE_NAME, (char*)&data);
        if (rc)
        {
            printf("SelectFail (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            break;
        }

#if 1
        rc = dbmCommit (&sHandle);
        if (rc)
        {
            printf("Commit t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }
#endif
    }
    clock_gettime_s(CLOCK_REALTIME, &end);
    gParam[idx].tps = LOOP/THR/((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0));

    dbmFreeHandle (&sHandle);
    return NULL;
}


int main ( int argc , char **argv )
{
    pthread_t tid[100];
    int i, start;
    double sum = 0;


    if (getenv("UNDO_NAME") == NULL)
    {
        printf("export UNDO_NAME\n");
        exit(-1);
    }
    if (getenv("TABLE_NAME") == NULL)
    {
        printf("export TABLE_NAME\n");
        exit(-1);
    }

    sprintf(UNDO_NAME, "%s", getenv("UNDO_NAME"));
    sprintf(TABLE_NAME, "%s", getenv("TABLE_NAME"));

    if (argc < 2)
    {
        fprintf(stdout, "usage] %s thr#\n", argv[0]);
        exit(-1);
    }

    THR = atoi(argv[1]);

#if 0
    rc = dbmInitHandle (&sHandle, (char*)UNDO_NAME);
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }
    rc = dbmTruncate(&sHandle, TABLE_NAME);
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }
    dbmTruncate(&sHandle, TABLE_NAME);
    dbmFreeHandle(&sHandle);

#endif


#if 1
    // Perf Test
    start = 0;
    for (i=0;i<THR;i++)
    {
        gParam[i].start = start;
        gParam[i].aCount = 0;
        gParam[i].idx = i;
        pthread_create(&tid[i], NULL, thr1, &gParam[i]);
        start = start + (LOOP / THR);
    }
    for (i=0;i<THR;i++)
    {
        pthread_join(tid[i], NULL);
        sum = sum + gParam[i].tps;
    }
    fprintf(stdout, "Insert TPS = %.2f\n", sum);
    sum = 0;
#endif

#if 1
    // Perf Test
    start = 0;
    for (i=0;i<THR;i++)
    {
        gParam[i].start = start;
        gParam[i].aCount = 0;
        gParam[i].idx = i;
        pthread_create(&tid[i], NULL, thr2, &gParam[i]);
        start = start + (LOOP / THR);
    }
    for (i=0;i<THR;i++)
    {
        pthread_join(tid[i], NULL);
        sum = sum + gParam[i].tps;
    }
    fprintf(stdout, "Select TPS = %.2f\n", sum);
    sum = 0;
#endif

#if 1
    // Perf Test
    start = 0;
    for (i=0;i<THR;i++)
    {
        gParam[i].start = start;
        gParam[i].aCount = 0;
        gParam[i].idx = i;
        pthread_create(&tid[i], NULL, thr3, &gParam[i]);
        start = start + (LOOP / THR);
    }
    for (i=0;i<THR;i++)
    {
        pthread_join(tid[i], NULL);
        sum = sum + gParam[i].tps;
    }
    fprintf(stdout, "Update TPS = %.2f\n", sum);
    sum = 0;
#endif

#if 1
    // Perf Test
    start = 0;
    for (i=0;i<THR;i++)
    {
        gParam[i].start = start;
        gParam[i].aCount = 0;
        gParam[i].idx = i;
        pthread_create(&tid[i], NULL, thr4, &gParam[i]);
        start = start + (LOOP / THR);
    }
    for (i=0;i<THR;i++)
    {
        pthread_join(tid[i], NULL);
        sum = sum + gParam[i].tps;
    }
    fprintf(stdout, "Delete TPS = %.2f\n", sum);
#endif


    return 0;
}
