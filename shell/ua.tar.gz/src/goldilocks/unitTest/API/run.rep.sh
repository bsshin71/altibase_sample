#!/bin/sh

export DBM_TRCLOG_ECHO=0

#export UNDO_NAME=test_undo
export UNDO_NAME=$DBM_INSTANCE  # demo

# 이중화 테스트를 위해, 있으면 지정하지 않음
if [ "x"TABLE_NAME == "x" ]
then
    export TABLE_NAME=t1
fi

set -x

sh initBig.rep.sh
usleep 10000

# make clean; make test6

./test6
rc=$?

set +x

########################################
# Finally
########################################
#test "x"$rc == "x0" && rmipc

# 정상종료 여부를 상위단으로 알려주어야 한다.
exit $rc

