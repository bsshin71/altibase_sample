typedef struct
{
    char   itemcd  [8];
    char   itemnm  [20];
    double highprc;
    double lowprc ;
    double smaxprc;
    double minprc ;
    double currprc;
    long long   trdqty ;
    long long   trdamt ;
} item;


typedef struct
{
    char    accntno [8];
    char    accntnm [20];
    long long ablemoney;
    long long unsettle;
} accnt;


typedef struct
{
    char    brcd[3];
    long long ordno;
} ordno;



typedef struct
{
    char   accntno [8];
    char   itemcd  [8];
    long long   ordprc;
    long long   ordqty;
    long long   ordno;
} order;
