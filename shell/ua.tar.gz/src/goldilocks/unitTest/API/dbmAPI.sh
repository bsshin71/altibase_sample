export UNDO_NAME=demo
export TABLE_NAME=T1

if [ -f $DBM_HOME/conf/defs/dbm.cfg.defs ]
then
    cp $DBM_HOME/conf/defs/dbm.cfg.defs $DBM_HOME/conf/dbm.cfg
fi
rmipc
. $GDSRC/unitTest/shl/testenv
initdb
sh $DBM_HOME/demo/schema/schema.sh

./dbmFetchNextGT
./dbmFetchNextLT
./dbmInsertRow
./dbmSelectRowGT
./dbmSelectRowLT
./dbmUpdateRow
