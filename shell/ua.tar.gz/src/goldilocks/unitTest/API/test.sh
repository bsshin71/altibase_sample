make clean; make all
rm -f /dev/shm/*
rmipc
cd ../Dictionary
sh test.sh
cd -
./test 123
#sleep 3
#perf stat -e cache-misses ./test
./test
#./test1 0 &
#./test1 0 &
#./test1 0 &
#./test1 0 &
