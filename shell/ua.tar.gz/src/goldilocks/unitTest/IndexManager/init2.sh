pkill test
make clean; make all
rm -f /dev/shm/*
rm -f $DBM_HOME/dic/*
rm -f $DBM_HOME/logfiles/*
rmipc

metaManager << EOF_
initdb;
drop undo lim272_undo;
create undo lim272_undo;
drop table lim272_t1;
create table lim272_t1 
c1 int 10 0
c2 int 10 0
c3 int 10 0
init 1000000 extend 100000 max 1100000;
create index lim272_idx_t1 on lim272_t1 c1; 

drop table lim272_t2;
create table lim272_t2 
c1 int 10 0
c2 int 10 0
c3 int 10 0
init 1000000 extend 100000 max 1100000;
create index lim272_idx_t2 on lim272_t2 c1; 
list;
insert into lim272_t1 values (1 1 1);
insert into lim272_t1 values (2 1 1);
insert into lim272_t1 values (3 1 1);
insert into lim272_t1 values (4 1 1);
insert into lim272_t2 values (1 1 1);
insert into lim272_t2 values (2 1 1);
insert into lim272_t2 values (3 1 1);
insert into lim272_t2 values (4 1 1);
commit;

drop table item;
create table item 
itemcd char 8 0
itemnm char 20 0
highprc double 10 2
lowprc double 10 2
smaxprc double 10 2
minprc double 10 2
currprc double 10 2
trdqty long 15 0
trdamt long 15 0
init 10000 extend 10000 max 10000;
create index item_idx1 on item itemcd;

drop table accnt;
create table accnt
accntno char 8 0
accntnm char 20 0
ablemoney long 15 0
unsettle long 15 0
init 10000 extend 10000 max 30000;
create index accnt_idx1 on accnt accntno;

drop table ordno;
create table ordno
brcd char 3 0
ordno long 8 0
init 100 extend 100 max 10;
create index ordno_idx1 on ordno brcd;

drop table order;
create table order 
accntno char 8 0
itemcd  char 8 0
ordprc  long 8 0
ordqty  long 8 0
ordno   long 8 0
init 1000000 extend 10000 max 1000000;

create index order_idx1 on order accntno itemcd ordno;
create index order_idx2 on order ordno;

list
exit
EOF_
