pkill test
make clean; make all
rm -f /dev/shm/*
rm -f $DBM_HOME/dic/*
rm -f $DBM_HOME/logfiles/*
rmipc

metaManager << EOF_
initdb;
drop undo lim272_undo;
create undo lim272_undo;
drop table lim272_t1;
create queue lim272_t1 msgsize 600;
list
exit
EOF_
