#include "cmnApi.h"
#include "dbmAPI.h"

#define TEST_COUNT 1000000

PHTIMER timer;

typedef struct user_struct
{
    char c1[10];
    char c2[10];
}user_struct;

void my_error(const char * name, int rc)
{
    if (rc != 0)
    {
        printf("%s fail:[%d]\n", name, rc);
        exit(-1);
    }
}

int main( int argc, char *argv[])
{
    dbmHandle sHandle;
    user_struct data;
    int i,rc;
    char table_name[16];
    char undo_name[16];
    char sql[1024];
    int test_count;
    int fd;


    //if( argc < 2 )
    //{
    //    printf("Usage : %s [test_count]\n", argv[0]);
    //    exit(0);
    //}

    //test_count = atoi(argv[1]);
    test_count = TEST_COUNT;

    memset(undo_name, 0x00, sizeof(undo_name));
    memset(table_name, 0x00, sizeof(table_name));
    memset(sql, 0x00, sizeof(sql));

    strcpy(table_name, "hwson");   /* 요것만 이름 바꾸어서 사용할 것 */


    /*
     * 준비 작업 (dbmInitHandle, dbmExecuteDDL (table, index), dbmPrepareTable)
     */
    sprintf(undo_name, "%s_undo", table_name);
    rc = dbmInitHandle(&sHandle, (char *)undo_name);
    my_error("init handle", rc);

    sprintf(sql, "create table %s \n"
                  "c1 char 10 0 \n"
                  "c2 char 10 0\n"
                  "init 500000 extend 500000 max 11000000\n", table_name);

    rc = dbmExecuteDDL (&sHandle, sql);
    my_error("create table", rc);

    memset(sql, 0x00, sizeof(sql));

    sprintf(sql, "create index idx_%s on %s c1 c2\n", table_name, table_name);

    rc = dbmExecuteDDL (&sHandle, sql);
    my_error("create index", rc);

    rc = dbmPrepareTable(&sHandle, table_name);
    my_error("prepare table", rc);


    /*
     * insert
     */
    memset(&data, 0x00, sizeof(data));

    rc = cmnInitTimer(&timer, UNIT_NANO, 500, 500, 20 );

    for(i=0; i<test_count; i++)
    {
        //data.c1 = i;
        sprintf(data.c1,"%d",i);
        sprintf(data.c2,"%d",i);
        cmnStartTimer(timer);

        rc = dbmInsertRow(&sHandle, table_name, (char *)&data, 20);
        my_error("insert ", rc);

        rc = dbmCommit(&sHandle);
        my_error("commit ", rc);

        cmnEndTimer(timer);

        if( i % 10000 == 0 ) printf("count : %d\n", i);
    }

    cmnElapseTimer(timer, test_count,(char*)"test3");
    cmnFinalTimer(&timer);

    /*
     * select
     */
    memset(&data, 0x00, sizeof(data));

    rc = cmnInitTimer(&timer, UNIT_NANO, 500, 500, 20 );

    for(i=0; i<test_count; i++)
    {
        //data.c1 = i;
        sprintf(data.c1,"%d" ,i);
        sprintf(data.c2,"%d", i);

        cmnStartTimer(timer);

        rc = dbmSelectRow(&sHandle, table_name, (char *)&data );
        my_error("select ", rc);

        cmnEndTimer(timer);

        if( i % 10000 == 0 ) printf("count : %d\n", i);
    }

    cmnElapseTimer(timer, test_count,(char*)"test3");
    cmnFinalTimer(&timer);

    fd=open("result.data",O_CREAT|O_APPEND|O_RDWR,0775);
    if(fd<=0)
    {
        fprintf(stdout,"file open error \n");
        exit(-1);
    }

    rc=write(fd,"0",1);
    if(rc<0)
    {
        fprintf(stdout,"file write erro r\n");
        exit(-1);
    }

    close(fd);

    printf("ok. end...\n");
}
