###############################################################################
# 설명 : 공통
#        환경 Clear
###############################################################################

ulimit -c unlimited

export DBM_TRCLOG_ECHO=0

SQL="metaManager --silent -f "

cfg_clear2()
{
    rm -f ../pid/*
    # rm -f core*
    
    rm -f $DBM_HOME/dic/*
    rm -f $DBM_HOME/dbm/*anchor
    rm -f ../pid/*
    # rm -f core*
	rm -f result.data
    rm -rf /dev/shm/$DBM_SHM_PREFIX/trans_test_undo*
    rm -rf /dev/shm/$DBM_SHM_PREFIX/*hwson*
    rm -rf /dev/shm/$DBM_SHM_PREFIX/*
    # -paul-paul00000000_undo-paul00000000_table_1_000 변경 대응
    rmipc
}

cfg_clear()
{
    # 웅이꺼 test1,test3,test4 test9~test13
    cfg_clear2

    echo "
initdb
create undo undo0000000500;
quit
" > .mm.sql
    ${SQL} .mm.sql
}

cfg_clear3()
{
    # 웅이꺼 test1,test3,test4 test9~test13
    cfg_clear2

    echo "
initdb
create undo hwson_undo;
quit
" > .mm.sql
    ${SQL} .mm.sql
}

cfg_clear4()
{
    # 웅이꺼 test1,test3,test4 test9~test13
    cfg_clear2

    echo "
initdb
create undo undo0000000500 init 400 extend 400 max 4000;
quit
" > .mm.sql
    ${SQL} .mm.sql
}

cfg_del()
{
	# make clean; make all
	cfg_clear
}


cfg_del2()
{
    # make clean;make all
	cfg_clear2
}

cfg_del3()
{
    # make clean;make all
    cfg_clear3
}

cfg_del4()
{
    cfg_clear4
}

########################################
# MAIN.
########################################
LOOP=1
IDXTYPE="unique"
TEST_NAME=""
test "x$1" != "x" && LOOP=$1
test "x$2" != "x" && IDXTYPE="$2"
test "x$3" != "x" && TEST_NAME=$3

echo "LOOP=$LOOP"
echo "IDXTYPE=$IDXTYPE"
echo "TEST_NAME=$TEST_NAME"

########################################
# 설명 : test_1
#
# 체크 : 정상 리턴값 0 체크
########################################

#. LOOP COUNT
CNT=$LOOP
#. test_1
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest_1" && break
	echo "## test_1 start ##"

	#.환경 제거
    cfg_del
    
    #1. 테이블 Create
    test_1 123
    
    #2. execute
    test_1
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test_1 success [$CNT]!!!"
    else
    	echo "test_1 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test_1_2
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest_1_2" && break
	echo "## test_1_2 start ##"

	#.환경 제거
    cfg_del
    
    #1. 테이블 Create
    test_1_2 123
    
    #2. execute
    test_1_2
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test_1_2 success [$CNT]!!!"
    else
    	echo "test_1_2 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test3_3
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest3_3" && break
	echo "## test3_3 start ##"

	#.환경 제거
    cfg_del
    
    #1. 테이블 Create
    test3_3 123
    
    #2. execute
    test3_3
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test3_3 success [$CNT]!!!"
    else
    	echo "test3_3 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test3_3_1
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest3_3_1" && break
	echo "## test3_3_1 start ##"

	#.환경 제거
    cfg_del
    
    #1. 테이블 Create
    test3_3_1 123
    
    #2. execute
    test3_3_1
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test3_3_1 success [$CNT]!!!"
    else
    	echo "test3_3_1 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test3_3_3
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest3_3_3" && break
	echo "## test3_3_3 start ##"

	#.환경 제거
    cfg_del
    
    #1. 테이블 Create
    test3_3_3 123
    
    #2. execute
    test3_3_3
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test3_3_3 success [$CNT]!!!"
    else
    	echo "test3_3_3 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done

#. LOOP COUNT
#CNT=$LOOP
#. test4_4
# 동시성 문제 관련 동표형과 아직 협의 되지 않았다. 어디가 문제인지 모름.
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest4_4" && break
	echo "## test4_4 start ##"

	#.환경 제거
    cfg_del
    
    #1. 테이블 Create
    test4_4 123
    
    #2. execute
    test4_4
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test4_4 success [$CNT]!!!"
    else
    	echo "test4_4 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test9 (select row gt,lt (c1,c2) test)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest9" && break
	echo "## test9 start ##"

	#.환경 제거
    cfg_del2
    
    #. table create
    echo "
initdb
create undo undo0000000500;
drop table hwson_t1;
create table hwson_t1 
(
    c1 char(20),
    c2 int,
    c3 int
)
init 10000000 extend 3000000 max 11000000;
create ${IDXTYPE} index hwson_idx_t1 on hwson_t1 c1 c2;
list
quit
" > .mm.sql
    ${SQL} .mm.sql

    #1. execute
    test9
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test9 success [$CNT]!!!"
    else
    	echo "test9 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done


#. LOOP COUNT
CNT=$LOOP
#. test9_9 (select row gt,lt (c1,c2,c3) test)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest9_9" && break
	echo "## test9_9 start ##"

	#.환경 제거
    cfg_del2
    
    #. table create
    echo "
initdb
create undo undo0000000500;
drop table hwson_t1;
create table hwson_t1 
(
    c1 char(20),
    c2 int,
    c3 int
)
init 10000000 extend 3000000 max 11000000;
create ${IDXTYPE} index hwson_idx_t1 on hwson_t1 c1 c2 c3;
list
quit
" > .mm.sql
    ${SQL} .mm.sql

    #1. execute
    test9_9
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test9_9 success [$CNT]!!!"
    else
    	echo "test9_9 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test10 (select row gt,lt (c1 integer) test)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest10" && break
	echo "## test10 start ##"

	#.환경 제거
    cfg_del2
    
    #. table create
    echo "
initdb
create undo undo0000000500 init 400 extend 400 max 10000;
drop table hwson_t1;
create table hwson_t1 ( c1 int )
init 10000000 extend 3000000 max 11000000;
create ${IDXTYPE} index hwson_idx_t1 on hwson_t1 c1;
list
quit
" > .mm.sql
    ${SQL} .mm.sql

    #1. execute
    test10
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test10 success [$CNT]!!!"
    else
    	echo "test10 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done

#. LOOP COUNT
#CNT=$LOOP
#. test10_10 (select row gt,lt (c1 integer) 검증 test)
#. 현재 delete 동시성 문제로 동표님 검증하고 있음. 테스트 불가.
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest10_10" && break
	echo "## test10_10 start ##"

	#.환경 제거
    cfg_del2
    
    #. table create
    echo "
initdb
create undo undo0000000500 init 400 extend 400 max 10000;
drop table hwson_t1;
create table hwson_t1 ( c1 int )
init 10000000 extend 3000000 max 11000000;
create ${IDXTYPE} index hwson_idx_t1 on hwson_t1 c1;
list
quit
" > .mm.sql
    ${SQL} .mm.sql

    #1. execute
    test10_10
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test10_10 success [$CNT]!!!"
    else
    	echo "test10_10 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done


#. LOOP COUNT
CNT=$LOOP
#. test10_10_1 (select row gt,lt (c1,c2,c3 integer) 검증 test)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest10_10_1" && break
	echo "## test10_10_1 start ##"

	#.환경 제거
    cfg_del2
    
    #. table create
    echo "
initdb
create undo undo0000000500;
drop table hwson_t1;
create table hwson_t1 
(
    c1 char(20),
    c2 int,
    c3 int
)
init 10000000 extend 3000000 max 11000000;
create ${IDXTYPE} index hwson_idx_t1 on hwson_t1 c1,c2,c3;
list
quit
" > .mm.sql
    ${SQL} .mm.sql

    #1. execute
    test10_10_1
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test10_10_1 success [$CNT]!!!"
    else
    	echo "test10_10_1 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test10_10_2 (select row gt,lt (c1 integer) 검증 test)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest10_10_2" && break
	echo "## test10_10_2 start ##"

	#.환경 제거
    cfg_del2
    
    #. table create
    echo "
initdb
create undo undo0000000500 init 400 extend 400 max 10000;
drop table hwson_t1;
create table hwson_t1 ( c1 int )
init 10000000 extend 3000000 max 11000000;
create ${IDXTYPE} index hwson_idx_t1 on hwson_t1 c1;
list
quit
" > .mm.sql
    ${SQL} .mm.sql

    #1. execute
    test10_10_2
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test10_10_2 success [$CNT]!!!"
    else
    	echo "test10_10_2 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test11 (하나의 트랜잭션에서 insert select selectrowgt lt 처리)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest11" && break
	echo "## test11 start ##"

	#.환경 제거
    cfg_del2
    
    #. table create
    echo "
initdb
create undo undo0000000500;
drop table hwson_t1;
create table hwson_t1 
(
    c1 char(20),
    c2 int,
    c3 int
)
init 10000000 extend 3000000 max 11000000;
create ${IDXTYPE} index hwson_idx_t1 on hwson_t1 c2;
list
quit
" > .mm.sql
    ${SQL} .mm.sql

    #1. execute
    test11
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test11 success [$CNT]!!!"
    else
    	echo "test11 Failure !!![$RESULT]"
		exit 1
    fi

	CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test12 
# insert select process
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest12" && break
	echo "## test12 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test12
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test12 success [$CNT]!!!"
    else
    	echo "test12 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test13
# insert select & delete 단위 테스트 process(key int)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest13" && break
	echo "## test13 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test13
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test13 success [$CNT]!!!"
    else
    	echo "test13 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test14
# insert select 단위 테스트 process(key int,char)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest14" && break
	echo "## test14 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test14
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test14 success [$CNT]!!!"
    else
    	echo "test14 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test15
# insert select & delete 단위 테스트 process(key int,char)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest15" && break
	echo "## test15 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test15
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test15 success [$CNT]!!!"
    else
    	echo "test15 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test16
# insert select & delete 단위 테스트 process(key int,char)
# commit 단위를 트랜잭션 %10으로 commit 처리 테스트
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest16" && break
	echo "## test16 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test16
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test16 success [$CNT]!!!"
    else
    	echo "test16 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test17
# insert select 단위 테스트 process(key char,char)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest17" && break
	echo "## test17 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test17
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test17 success [$CNT]!!!"
    else
    	echo "test17 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test18
# insert select & delete 단위 테스트 process(key char,char)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest18" && break
	echo "## test18 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test18
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test18 success [$CNT]!!!"
    else
    	echo "test18 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test19
# insert select 단위 테스트 process(key char)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest19" && break
	echo "## test19 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test19
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test19 success [$CNT]!!!"
    else
    	echo "test19 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test20
# insert select & delete 단위 테스트 process(key char)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest20" && break
	echo "## test20 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test20
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test20 success [$CNT]!!!"
    else
    	echo "test20 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test21
# insert select 단위 테스트 process(key int,int)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest21" && break
	echo "## test21 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test21
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test21 success [$CNT]!!!"
    else
    	echo "test21 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test22
# insert select & delete 단위 테스트 process(key int,int)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest22" && break
	echo "## test22 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test22
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test22 success [$CNT]!!!"
    else
    	echo "test22 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test23
# insert insert & selectLT 단위 테스트 process(key int)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest23" && break
	echo "## test23 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test23
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test23 success [$CNT]!!!"
    else
    	echo "test23 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test24
# insert insert & selectLT  & selectGT 단위 테스트 process(key int)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest24" && break
	echo "## test24 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test24
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test24 success [$CNT]!!!"
    else
    	echo "test24 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test25
# insert insert 단위 테스트 process(key char,int)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest25" && break
	echo "## test25 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test25
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test25 success [$CNT]!!!"
    else
    	echo "test25 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done

#. LOOP COUNT
CNT=$LOOP
#. test26
# insert insert 단위 테스트 process(key char,int)
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest26" && break
	echo "## test26 start ##"

	#.환경 제거
    cfg_del3
    
    #1. execute
    test26
    
    #3. check value diff
    RESULT=`cat result.data`
    
    if [ "$RESULT" == "0" ]
    then
    	echo "test26 success [$CNT]!!!"
    else
    	echo "test26 Failure !!![$RESULT]"
    	exit 1
    fi
    
    CNT=`expr $CNT - 1`
done


########################################
# non unique 전용
########################################
if [ "x$IDXTYPE" == "xnon unique" ]
then

#. LOOP COUNT
CNT=1
#. test27
# insert insert 단위 테스트 process(key char,int)
# Bulck성 commit 테스트
while [ "$CNT" -gt 0 ];
do
	test "x"${TEST_NAME} != "x" -a "x"${TEST_NAME} != "xtest27" && break
    echo "## test_27 start ##"

    #.환경 제거
    cfg_del4

    #1. 테이블 Create
    test27 123

    #2. execute
    test27

    #3. check value diff
    RESULT=`cat result.data`

    if [ "$RESULT" == "0" ]
    then
        echo "test_27 success [$CNT]!!!"
    else
        echo "test_27 Failure !!![$RESULT]"
        exit 1
    fi

    CNT=`expr $CNT - 1`

done

fi  # non unique 전용

# 정상종료 여부를 상위단으로 알려주어야 한다.
exit 0

