pkill test
make clean; make all
rm -f /dev/shm/*
rm -f $DBM_HOME/dic/*
rm -f $DBM_HOME/logfiles/*
rmipc

metaManager << EOF_
initdb;
drop undo lim272_undo;
create undo lim272_undo;
drop table lim272_t1;
create table lim272_t1 
c1 int 10 0
c2 int 10 0
init 5000 extend 5000 max 1100000;
create index lim272_idx_t1 on lim272_t1 c2;
list
exit
EOF_
