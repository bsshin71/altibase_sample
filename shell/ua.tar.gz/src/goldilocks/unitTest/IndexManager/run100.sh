sh ./run.sh 100 "unique" $*
