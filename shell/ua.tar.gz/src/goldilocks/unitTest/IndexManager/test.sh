make clean; make all
#make clean;make test4_4
rm -f /dev/shm/*
rmipc
#cd ../Dictionary
#sh test.sh
#cd -


#test test
#./test 123
#sleep 3
#perf stat -e cache-misses ./test
#./test

#test_1 test
#./test_1 123
#./test_1

#test_1_2 test
#./test_1_2 123
#./test_1_2

#test3_3 test
#./test3_3 123
#./test3_3

#test3_3_1 test
#./test3_3_1 123
#./test3_3_1

#test3_3_2 test
# 설명 : insert size 작게 하여 오류 나게 하고 delete 처리 시 정상 적으로 처리 후 rollback이 정상 적으로 되는지 테스트.
#./test3_3_2 123
#./test3_3_2

#test3_3_3 test
# 설명 : table init 생성 size 작게하고 테스트 
#./test3_3_3 123
#./test3_3_3

#test4_4 test
./test4_4 123
./test4_4
