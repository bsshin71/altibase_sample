#include "dbmAPI.h"
#include "dbmInternalHandle.h"


#define THR  4
#define LOOP 3000000

typedef struct PARAM
{
    int tid;
    int start;
    int aCount;
} PARAM;

static void mCreate();
static void *test1(void *);
static void *testSelect1(void *param);


int main( int argc, char *argv[])
{
    dbmSegmentManager *sMgr;
    pthread_t tid[THR];
    int i;
    int start;
    PARAM  param[THR];
    int rc = 0;
    int fd = -1;

    _TRY
    {
        // 테이블 만들려면 인자를 한개 줘라.
        if ( argc > 1 )
        {
            //rc = dbmSegmentManager::Create ("undo0000000500", 256 * 1024, 1000, 1000, 10000, 8192, sLog, &sMgr);
            _PRT ( "create undo rc=%d\n", rc );
            mCreate ( );
            exit ( -1 );
        }

        // Perf Test
        start = 0;
        for ( i = 0; i < THR; i++ )
        {
            /* start = 0
             * start = 0 + (1000000 /4) --> 250000
             * start = 250000
             * start = 250000 + (1000000/4) --> 500000
             * start = 500000
             * start = 500000 + (1000000/4) --> 750000
             */

            param[i].tid = i;
            param[i].start = start;
            param[i].aCount = argc;
            _CALL( pthread_create ( &tid[i], NULL, test1, &param[i] ) );
            start = start + ( LOOP / THR );
            sleep ( 1 );
        }

        for ( i = 0; i < THR; i++ )
        {
            _CALL( pthread_join ( tid[i], NULL ) );
        }

        fd = open ( "result.data", O_CREAT | O_APPEND | O_RDWR, 0775 );
        _IF_THROW ( fd <= 0, -1 );

        rc = write ( fd, "0", 1 );
        _IF_THROW ( rc < 0, -1 );

        close ( fd );
        fd = -1;
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _END
} // main


void mCreate()
{
    dbmHandle sHandle;
    char      buffer[1024];
    int i;
    int nStart, nEnd, aCount;
    struct timespec start, end;

    _TRY
    {
        _CALL( dbmInitHandle ( &sHandle, "undo0000000500" ) );
        _PRT ( "initHandle rc=%d (Mark=%lld, Name=%s, trans_id=%d)\n",
                 _rc,
                 sHandle.mMark,
                 ( (dbmInternalHandle *) sHandle.mHandle )->mInstanceName,
                 ( (dbmInternalHandle *) sHandle.mHandle )->mTrans->mGetTransID ( ) );

        // Table creation
        {
            _CALL( dbmExecuteDDL ( &sHandle, "create table table0010 \n"
                                "c1 int 10 0 \n"
                                "init 1000000 extend 1000000 max 20000000\n" ) );

            _CALL( dbmExecuteDDL ( &sHandle, "create non unique index idx_table0010 on table0010 c1\n" ) );

            _PRT ( "initHandle rc=%d (Mark=%lld, Name=%s, trans_id=%d)\n",
                     _rc,
                     sHandle.mMark,
                     ( (dbmInternalHandle *) sHandle.mHandle )->mInstanceName,
                     ( (dbmInternalHandle *) sHandle.mHandle )->mTrans->mGetTransID ( ) );
        }

        _CALL( dbmFreeHandle ( &sHandle ) );

    }
    _CATCH
    {
        _CATCH_ERR;
        exit ( -1 );        // 원래 코드가 죽게 되어있었음.
    }
    _FINALLY
    _ENDVOID
} // mCreate

__thread int sECnt = 0 ;

void *test1(void *param)
{
    dbmHandle sHandle;
    char      buffer[1024];
    int i;
    int nStart, nEnd, aCount;
    struct timespec start, end;

    _TRY
    {
        nStart = (int) ( ( (PARAM*) param )->start );
        aCount = (int) ( ( (PARAM*) param )->aCount ) ;
        nEnd = nStart + ( LOOP / THR );

        DBM_INFO ( "================ tid[%lld] start (%d ~ %d)\n", ( (PARAM*) param )->tid, nStart, nEnd - 1 );

        _CALL( dbmInitHandle ( &sHandle, "undo0000000500" ) );
        DBM_INFO ( "initHandle rc=%d (Mark=%lld, Name=%s, trans_id=)\n", _rc, sHandle.mMark, ( (dbmInternalHandle *) sHandle.mHandle )->mInstanceName );

        _CALL( dbmPrepareTable ( &sHandle, "table0010" ) );

        _CALL( clock_gettime_s ( CLOCK_REALTIME, &start ) );

        for ( i = nStart; i < nEnd; i++ )
        {
            memset ( buffer, 0x00, sizeof( buffer ) );
            memcpy ( buffer,&i,sizeof(int));

            _CALL( dbmInsertRow ( &sHandle, "table0010", buffer, 4 ) );
            _CALL( dbmInsertRow ( &sHandle, "table0010", buffer, 4 ) );
            _CALL( dbmInsertRow ( &sHandle, "table0010", buffer, 4 ) );

            _CALL( dbmCommit ( &sHandle ) );

            _rc = dbmDeleteRow ( &sHandle, "table0010", buffer );
            if ( _rc )
            {
                DBM_INFO ( "[i=%d] tid[%d], key[%d] : delete error [%d][%s]", i, ((PARAM*)param)->tid, *(int*)buffer, _rc, dbmGetError(_rc) );
                exit(-1);
            }

            _CALL( dbmCommit ( &sHandle ) );

            if ( i != 0 && ( i % 100000 ) == 0 )
                _PRT ( "%d rows inserted..\n", i );
        }

        clock_gettime_s ( CLOCK_REALTIME, &end );
        DBM_INFO ( "LOOP=%d, i=%d, Elap=%.9lf\n", LOOP, i,
                 (double) ( ( end.tv_sec + end.tv_nsec / 1000000000.0 ) - ( start.tv_sec + start.tv_nsec / 1000000000.0 ) ) );

        _CALL( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
        exit ( -1 );
    }
    _FINALLY
    _ENDNULL
}


void *testSelect1(void *param)
{
    dbmHandle sHandle;
    char      buffer[1024];
    int i;
    int nStart, nEnd, aCount;
    struct timespec start, end;

    _TRY
    {

        nStart = (int) ( ( (PARAM*) param )->start );
        aCount = (int) ( ( (PARAM*) param )->aCount );
        nEnd = nStart + ( LOOP / THR );
        _PRT ( "start (%d ~ %d)\n", nStart, nEnd );

        _CALL( dbmInitHandle ( &sHandle, "undo0000000500" ) );
        _PRT ( "initHandle rc=%d (Mark=%lld, Name=%s, trans_id=%d)\n",
                 _rc,
                 sHandle.mMark,
                 ( (dbmInternalHandle *) sHandle.mHandle )->mInstanceName,
                 ( (dbmInternalHandle *) sHandle.mHandle )->mTrans->mGetTransID ( ) );

#if 1
        _CALL( dbmPrepareTable ( &sHandle, "table0010" ) );

        clock_gettime_s ( CLOCK_REALTIME, &start );
        for ( i = nStart; i < nEnd; i++ )
        {
            //printf("%d select\n", i);
            memcpy ( buffer, &i, sizeof(int) );
            memcpy ( buffer + sizeof(int), &i, sizeof(int) );
            _CALL( dbmSelectRow ( &sHandle, "table0010", buffer ) );
        }
        clock_gettime_s ( CLOCK_REALTIME, &end );
        _PRT ( "SELECT LOOP=%d, i=%d, Elap=%.9f\n",
                 LOOP,
                 i,
                 (double) ( ( end.tv_sec + end.tv_nsec / 1000000000.0 ) - ( start.tv_sec + start.tv_nsec / 1000000000.0 ) ) );
#endif
        _CALL( dbmFreeHandle ( &sHandle ) );
    }
    _CATCH
    {
        _CATCH_ERR;
    }
    _FINALLY
    _ENDNULL
}

