#include "dbmAPI.h"
#include "dbmInternalHandle.h"


#define DISP 100000

typedef struct
{
    int c1;
    int c2;
    int c3;
    char c4[500];
    struct timespec start;
    struct timespec end;
} TABLE;


#define UNDO_NAME  "lim272_undo"
#define TABLE_NAME "lim272_t1"
#define THR  1
#define LOOP 1000000

int gStart = 0;
int gSleep = 0;


typedef struct
{
    int start;
    int aCount;
} PARAM;


void *thr1(void*);
void *thr2(void *);



void *thr1(void *param)
{
    dbmHandle sHandle;
    int rc;
    int i, j;
    int nStart, nEnd, aCount;
    TABLE  data;
    double sum = 0.0;
    struct timespec start, end;
    int range[20];
    long long tot = 0;
    double avg = 0.0;


    nStart = (int)(((PARAM*)param)->start);
    aCount = (int)(((PARAM*)param)->aCount);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);

    for (i=0;i<=18;i++) range[i]= 0;


    rc = dbmInitHandle (&sHandle, (char*)UNDO_NAME);
    if (rc)
    {
        dbmGetError(rc, dbmGetError(rc) );
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, (char*)TABLE_NAME);
    if (rc)
    {
        dbmGetError(rc, dbmGetError(rc) );
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    gStart = 1;
    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    {
        memset(&data, 0x00, sizeof(TABLE));
        rc = dbmDequeue (&sHandle, (char*)TABLE_NAME, (char*)&data, 10000000);
        if (rc)
        {
            dbmGetError(rc, dbmGetError(rc) );
            printf("Deque Fail. (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            exit(-1);
        }

#if 1
        fprintf(stdout, "Deq (c1=%d, c2=%d)\n", data.c1, data.c2);
#endif
        clock_gettime_s(CLOCK_REALTIME, &data.end);
        sum = (data.end.tv_sec + data.end.tv_nsec/1000000000.0) - (data.start.tv_sec + data.start.tv_nsec/1000000000.0);
        if (sum < 0.000001) range[0]++;
        else if (sum >= 0.000001 && sum < 0.000002) range[1]++;
        else if (sum >= 0.000002 && sum < 0.000003) range[2]++;
        else if (sum >= 0.000003 && sum < 0.000004) range[3]++;
        else if (sum >= 0.000004 && sum < 0.000005) range[4]++;
        else if (sum >= 0.000005 && sum < 0.000006) range[5]++;
        else if (sum >= 0.000006 && sum < 0.000007) range[6]++;
        else if (sum >= 0.000007 && sum < 0.000008) range[7]++;
        else if (sum >= 0.000008 && sum < 0.000009) range[8]++;
        else if (sum >= 0.000009 && sum < 0.000010) range[9]++;
        else if (sum >= 0.000010 && sum < 0.000011) range[10]++;
        else if (sum >= 0.000011 && sum < 0.000012) range[11]++;
        else if (sum >= 0.000012 && sum < 0.000013) range[12]++;
        else if (sum >= 0.000013 && sum < 0.000014) range[13]++;
        else if (sum >= 0.000014 && sum < 0.000015) range[14]++;
        else if (sum >= 0.000015 && sum < 0.000020) range[15]++;
        else if (sum >= 0.000020 && sum < 0.000025) range[16]++;
        else if (sum >= 0.000025 && sum < 0.000030) range[17]++;
        else range[18]++;
        avg = avg + sum;

        tot = 0;
        for (j=0;j<=18;j++) tot = tot + range[j];
        if (tot % DISP == 0)
        {
            clock_gettime_s(CLOCK_REALTIME, &end);
            printf("Total Running Time : %.9f (%lld)\n", (end.tv_sec + end.tv_nsec / 1000000000.0) -
                                                        (start.tv_sec + start.tv_nsec / 1000000000.0), tot);
            printf("=========================================== LAST RESULT (%lld)= \n", tot);
            printf("             Time < 0.000001    : %8d (%6.2f%%)\n", range[0], (double)((double)range[0]/tot)*100.0);
            printf("0.000001 <=  Time < 0.000002    : %8d (%6.2f%%)\n", range[1], (double)((double)range[1]/tot)*100.0);
            printf("0.000002 <=  Time < 0.000003    : %8d (%6.2f%%)\n", range[2], (double)((double)range[2]/tot)*100.0);
            printf("0.000003 <=  Time < 0.000004    : %8d (%6.2f%%)\n", range[3], (double)((double)range[3]/tot)*100.0);
            printf("0.000004 <=  Time < 0.000005    : %8d (%6.2f%%)\n", range[4], (double)((double)range[4]/tot)*100.0);
            printf("0.000005 <=  Time < 0.000006    : %8d (%6.2f%%)\n", range[5], (double)((double)range[5]/tot)*100.0);
            printf("0.000006 <=  Time < 0.000007    : %8d (%6.2f%%)\n", range[6], (double)((double)range[6]/tot)*100.0);
            printf("0.000007 <=  Time < 0.000008    : %8d (%6.2f%%)\n", range[7], (double)((double)range[7]/tot)*100.0);
            printf("0.000008 <=  Time < 0.000009    : %8d (%6.2f%%)\n", range[8], (double)((double)range[8]/tot)*100.0);
            printf("0.000009 <=  Time < 0.000010    : %8d (%6.2f%%)\n", range[9], (double)((double)range[9]/tot)*100.0);
            printf("0.000010 <=  Time < 0.000011    : %8d (%6.2f%%)\n", range[10], (double)((double)range[10]/tot)*100.0);
            printf("0.000011 <=  Time < 0.000012    : %8d (%6.2f%%)\n", range[11], (double)((double)range[11]/tot)*100.0);
            printf("0.000012 <=  Time < 0.000013    : %8d (%6.2f%%)\n", range[12], (double)((double)range[12]/tot)*100.0);
            printf("0.000013 <=  Time < 0.000014    : %8d (%6.2f%%)\n", range[13], (double)((double)range[13]/tot)*100.0);
            printf("0.000014 <=  Time < 0.000015    : %8d (%6.2f%%)\n", range[14], (double)((double)range[14]/tot)*100.0);
            printf("0.000015 <=  Time < 0.000020    : %8d (%6.2f%%)\n", range[15], (double)((double)range[15]/tot)*100.0);
            printf("0.000020 <=  Time < 0.000025    : %8d (%6.2f%%)\n", range[16], (double)((double)range[16]/tot)*100.0);
            printf("0.000025 <=  Time < 0.000030    : %8d (%6.2f%%)\n", range[17], (double)((double)range[17]/tot)*100.0);
            printf("            Time >= 0.000030    : %8d (%6.2f%%)\n", range[18], (double)((double)range[18]/tot)*100.0);

            printf("[%d] :: Average (%.9f), curr=%.9f\n", getpid(), (double)(avg / tot), sum);
            for (j=0; j<=18; j++) range[j] = 0;
            avg = 0;
        }

#if 0
if (i!=0 && i%100000 == 0)
{
    fprintf(stdout, "data c1=%d, c2=%d, c3=%d\n", data.c1, data.c2, data.c3);
}
#endif

        rc = dbmCommit (&sHandle);
        if (rc)
        {
            dbmGetError(rc, dbmGetError(rc) );
            printf("Commit t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }
#if 0
        if (i !=0 && (i % 10000) == 0) printf ("%d rows inserted..\n", i - nStart);
#endif
    }
    clock_gettime_s(CLOCK_REALTIME, &end);
    printf("(DEQ) LOOP=%d, i=%d, Elap=%.9f, Average=%.9f\n",
            LOOP, i, (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0)),
            (double)(avg/(i-1)));

    dbmFreeHandle (&sHandle);
    return NULL;
}


void *thr2(void *param)
{
    dbmHandle sHandle;
    int rc;
    int i;
    int nStart, nEnd, aCount;
    TABLE  data;
    struct timespec start, end;


    nStart = (int)(((PARAM*)param)->start);
    aCount = (int)(((PARAM*)param)->aCount);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);


    rc = dbmInitHandle (&sHandle, (char*)UNDO_NAME);
    if (rc)
    {
        dbmGetError(rc, dbmGetError(rc) );
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, (char*)TABLE_NAME);
    if (rc)
    {
        dbmGetError(rc, dbmGetError(rc) );
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    //for (i=0; i<2; i++)
    {
        memset(&data, 0x00, sizeof(TABLE));
        data.c1 = i;
        data.c2 = i;
        data.c3 = i;
        clock_gettime_s(CLOCK_REALTIME, &data.start);

        rc = dbmEnqueue (&sHandle, (char*)TABLE_NAME, (char*)&data, sizeof(data));
        if (rc)
        {
            dbmGetError(rc, dbmGetError(rc) );
            printf("Enque Fail. (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            exit(-1);
        }

        rc = dbmEnqueue (&sHandle, (char*)TABLE_NAME, (char*)&data, sizeof(data));
        if (rc)
        {
            dbmGetError(rc, dbmGetError(rc) );
            printf("Enque Fail. (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            exit(-1);
        }

#if 1
        rc = dbmCommit (&sHandle);
        if (rc)
        {
            dbmGetError(rc, dbmGetError(rc) );
            printf("Commit t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }
#endif

        if (gSleep != 0)
        {
            usleep(gSleep);
        }
    }
    clock_gettime_s(CLOCK_REALTIME, &end);
    printf("(ENQ) LOOP=%d, i=%d, Elap=%.9f\n",
            LOOP, i, (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0)));

    dbmFreeHandle (&sHandle);
    return NULL;
}




int main(int argc, char *argv[])
{
    pthread_t tid[THR * 2];
    int i, start;
    PARAM  param[THR * 2];


    if (argc > 1)
    {
        gSleep = (int)atoi(argv[1]);
    }

    // Perf Test
    start = 0;
    for (i=0;i<THR*2;i=i+2)
    {
#if 1
        param[i].start = start;
        param[i].aCount = 0;
        pthread_create(&tid[i], NULL, thr1, &param[i]);
#endif
        while (gStart == 0)
        {
            usleep(1000);
        }

#if 1
        param[i+1].start = start;
        param[i+1].aCount = 0;
        pthread_create(&tid[i+1], NULL, thr2, &param[i+1]);
#endif

        start = start + (LOOP / THR);
    }

    for (i=0;i<THR*2;i=i+2)
    {
#if 1
        pthread_join(tid[i], NULL);
#endif
        pthread_join(tid[i+1], NULL);
    }

    return 0;
}
