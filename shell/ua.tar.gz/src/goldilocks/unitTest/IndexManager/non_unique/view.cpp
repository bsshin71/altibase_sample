#include "dbmAPI.h"
#include "dbmInternalHandle.h"


//#define UNDO_NAME  "undo0000000500"
//#define TABLE_NAME "hwson_t1"
#define UNDO_NAME  "undo0000000500"
#define TABLE_NAME "table0010"
#define THR  1
#define LOOP 1000000


typedef struct
{
    char c1[20];
    int c2;
    int c3;
} TABLE;


#if 0
void dbmIndexManager::PrintNodeElement2(dbmIndexNode* pNode)
{
    int             i,j;
    int             sRC;
    int             sKeyIndexOffset;
    dbmIndexNode*   pChild;
    dbmIndexNode*   pInter;

    char*           sSlotAddr;

    sKeyIndexOffset = 0;

    /* Print Post-order */
    if(pNode->mIndexSlotHeader.mLeafcheck == 1)
    {
        pChild = NULL;
    }
    else
    {
        sRC = mSegMgr->Slot2Addr(pNode->mChild[0], &sSlotAddr);
        MVP_TEST_RAISE( sRC, SLOT2ADDR_FAIL );
        pChild = (dbmIndexNode*)sSlotAddr;
    }

    if(pChild == NULL)
    {   /* leaf */
        fprintf(stdout, "[ ");
        //DBM_DBG("[ ");
        for(i=0; i<pNode->mIndexSlotHeader.mNodeCount; i++)
        {
            for(j=0;j<mIndexHeader->mIndex.mColumnCount;j++)
            {
                switch(mIndexHeader->mIndex.mKey[j].mColumnType)
                {
                    case DBM_COLUMN_CHAR_TYPE:
                        fprintf(stdout,"%s",
                                INDEX_POS( pNode,i,mIndexHeader->mIndex.mKeySize)+ sKeyIndexOffset);

                        break;
                    case DBM_COLUMN_SHORT_TYPE:
                        fprintf(stdout,"%d",
                        *(short *)INDEX_POS( pNode,i,mIndexHeader->mIndex.mKeySize)+sKeyIndexOffset);

                        break;

                    case DBM_COLUMN_INT_TYPE:
                        fprintf(stdout,"%d",
                        *(int *)INDEX_POS( pNode,i,mIndexHeader->mIndex.mKeySize)+sKeyIndexOffset);

                        break;

                    case DBM_COLUMN_LONG_TYPE:
                        fprintf(stdout,"%lld",
                        *(long long*)INDEX_POS( pNode,i,mIndexHeader->mIndex.mKeySize)+sKeyIndexOffset);
                        break;
                    default:
                        DBM_DBG("Column type not Found type [%d]  \n", mIndexHeader->mIndex.mKey[j].mColumnType);
                        break;
                }

                sKeyIndexOffset = sKeyIndexOffset + mIndexHeader->mIndex.mKey[j].mSize;

            }

            fprintf(stdout," ");
        }
        fprintf(stdout, "] ");

        return;
    }

    /* leftmost child 출력 */
    sRC = mSegMgr->Slot2Addr(pNode->mChild[0], &sSlotAddr);
    MVP_TEST_RAISE( sRC, SLOT2ADDR_FAIL );
    pInter = (dbmIndexNode*)sSlotAddr;

    PrintNodeElement2(pInter);

    /* node 내의 key와 other child 출력 */
    for(i=1; i<DBM_INDEX_DEGREE; ++i)
    {
        if( pNode->mChild[i] < 1 )
            pInter = NULL;
        else
        {
            sRC = mSegMgr->Slot2Addr(pNode->mChild[i], &sSlotAddr);
            MVP_TEST_RAISE( sRC, SLOT2ADDR_FAIL );
            pInter = (dbmIndexNode*)sSlotAddr;
        }

        if(pInter == NULL)
        {
            return;
        }
        PrintNodeElement2(pInter);

        for(j=0;j<mIndexHeader->mIndex.mColumnCount;j++)
        {
            switch(mIndexHeader->mIndex.mKey[j].mColumnType)
            {
                case DBM_COLUMN_CHAR_TYPE:
                    fprintf(stdout,"%s",
                            INDEX_POS( pNode,(i-1),mIndexHeader->mIndex.mKeySize)+sKeyIndexOffset);

                    break;
                case DBM_COLUMN_SHORT_TYPE:
                    fprintf(stdout,"%d",
                    *(short *)INDEX_POS( pNode,(i-1),mIndexHeader->mIndex.mKeySize)+sKeyIndexOffset);

                    break;

                case DBM_COLUMN_INT_TYPE:
                    fprintf(stdout,"%d",
                    *(int *)INDEX_POS( pNode,(i-1),mIndexHeader->mIndex.mKeySize)+sKeyIndexOffset);

                    break;

                case DBM_COLUMN_LONG_TYPE:
                    fprintf(stdout,"%lld",
                    *(long long*)INDEX_POS( pNode,(i-1),mIndexHeader->mIndex.mKeySize)+sKeyIndexOffset);

                    break;
                default:
                    DBM_DBG("Column type not Found type [%d]  \n", mIndexHeader->mIndex.mKey[j].mColumnType);
                    break;
            }
            fprintf(stdout," ");

            sKeyIndexOffset = sKeyIndexOffset + mIndexHeader->mIndex.mKey[j].mSize;
        }
    }

    return;

    MVP_EXCEPTION( SLOT2ADDR_FAIL )
    {
        DBM_CERR("Slot2Addr faile \n");
    }
    MVP_EXCEPTION_END;

    return;
}
#endif

int main()
{
    dbmHandle sHandle;
    int rc;
    TABLE  data;

    rc = dbmInitHandle (&sHandle, (char*)UNDO_NAME);
    if (rc)
    {
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, (char*)TABLE_NAME);
    if (rc)
    {
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    memset(&data, 0x00, sizeof(TABLE));
#if 0
    data.c1 = 0;
    data.c2 = 6879098;
#endif

    sprintf(data.c1,"%d",974882);
    data.c2 = 974882;

    rc = dbmSelectRow(&sHandle, (char*)TABLE_NAME, (char*)&data);
    if (rc)
    {
        printf("Select error\n" );
        exit(-1);
    }

    printf("select ok \n");

#if 0
    dbmSegmentManager* mGetSegMgr() { return mSegMgr; }
    rc = dbmSegmentManager::Attach(aIndexName, mLogH, &mSegMgr );
    MVP_TEST_RAISE( sRC, ATTACH_SEG_FAIL );
#endif

    dbmFreeHandle (&sHandle);

    return 0;
}


