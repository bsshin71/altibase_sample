pkill test
make clean; make all
rm -f /dev/shm/*
rm -f $DBM_HOME/dic/*
rm -f $DBM_HOME/logfiles/*
rmipc_big



# test9
#./metaManager << EOF
#initdb
#create undo undo0000000500 init 400 extend 400 max 10000;
#drop table hwson_t1;
#create table hwson_t1
#c1 char 20 0
#c2 int 10 0
#c3 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create index hwson_idx_t1 on hwson_t1 c1 c2;
#list
#exit
#EOF
#./test9

# test9_9
#./metaManager << EOF
#initdb
#create undo undo0000000500 init 400 extend 400 max 10000;
#drop table hwson_t1;
#create table hwson_t1
#c1 char 20 0
#c2 int 10 0
#c3 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create index hwson_idx_t1 on hwson_t1 c1 c2 c3;
#list
#exit
#EOF
#./test9_9

# test10
#./metaManager << EOF
#initdb
#create undo undo0000000500 init 400 extend 400 max 10000;
#drop table hwson_t1;
#create table hwson_t1
#c1 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create index hwson_idx_t1 on hwson_t1 c1;
#list
#exit
#EOF
#./test10

# test10_10
#./metaManager << EOF
#initdb
#create undo undo0000000500 init 400 extend 400 max 10000;
#drop table hwson_t1;
#create table hwson_t1
#c1 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create index hwson_idx_t1 on hwson_t1 c1;
#list
#exit
#EOF
#./test10_10

# test10_10_1
#./metaManager << EOF
#initdb
#create undo undo0000000500 init 400 extend 400 max 10000;
#drop table hwson_t1;
#create table hwson_t1
#c1 char 20 0
#c2 int 10 0
#c3 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create index hwson_idx_t1 on hwson_t1 c1,c2,c3;
#list
#exit
#EOF
#./test10_10_1

# test11
./metaManager << EOF
initdb
create undo undo0000000500 init 400 extend 400 max 10000;
drop table hwson_t1;
create table hwson_t1
c1 char 20 0
c2 int 10 0
c3 int 10 0
init 10000000 extend 3000000 max 11000000;
create index hwson_idx_t1 on hwson_t1 c2;
list
exit
EOF

# test12
#./metaManager << EOF
#initdb
#create undo undo0000000500 init 400 extend 400 max 10000;
#drop table hwson_t1;
#create table hwson_t1
#c1 char 20 0
#c2 int 10 0
#c3 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create index hwson_idx_t1 on hwson_t1 c1;
#list
#exit
#EOF
