#include "dbmAPI.h"
#include "dbmInternalHandle.h"


#define THR  4
#define LOOP 3000000
//#define LOOP 383

typedef struct
{
    int tid;
    int start;
    int aCount;
} PARAM;

void *test1(void *);


void mCreate()
{
    dbmHandle sHandle;
    char      buffer[1024];
    int rc;
    int i;
    int nStart, nEnd, aCount;
    struct timespec start, end;


    rc = dbmInitHandle (&sHandle, "undo0000000500");
    if (rc)
    {
        printf("first initHandle rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }
    printf("initHandle rc=%d (Mark=%lld, Name=%s, trans_id=%d)\n",
            rc, sHandle.mMark
            , ((dbmInternalHandle *)sHandle.mHandle)->mInstanceName
            , ((dbmInternalHandle *)sHandle.mHandle)->mTrans->mGetTransID()
            );

#if 1
    // Table creation
    {
        rc = dbmExecuteDDL (&sHandle, "create table table0010 \n"
                                     "c1 int 10 0 \n"
                                     "c2 int 10 0 \n"
                                     "init 100000 extend 100000 max 20000000\n");
        printf("create table rc=%d (%s)\n", rc, dbmGetError(rc) );
        if (rc) exit(-1);

        rc = dbmExecuteDDL (&sHandle, "create non unique index idx_table0010 on table0010 c2\n");
        printf("create index rc=%d (%s)\n", rc, dbmGetError(rc) );
        if (rc) exit(-1);

        printf("initHandle rc=%d (Mark=%lld, Name=%s, trans_id=%d)\n",
            rc, sHandle.mMark
            , ((dbmInternalHandle *)sHandle.mHandle)->mInstanceName
            , ((dbmInternalHandle *)sHandle.mHandle)->mTrans->mGetTransID()
            );
    }
#endif

    dbmFreeHandle (&sHandle);
}


void *test1(void *param)
{
    dbmHandle sHandle;
    char      buffer[1024];
    int rc;
    int i;
    int nStart, nEnd, aCount;
    struct timespec start, end;


    nStart = (int)(((PARAM*)param)->start);
    aCount = (int)(((PARAM*)param)->aCount);
    nEnd = nStart + (LOOP / THR);
    printf("================ [%lu] start (%d ~ %d)\n", (unsigned long)pthread_self(), nStart, nEnd);

    rc = dbmInitHandle (&sHandle, "undo0000000500");
    if (rc)
    {
        printf("first initHandle rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }
    printf("initHandle rc=%d (Mark=%lld, Name=%s, trans_id=)\n",
            rc, sHandle.mMark
            , ((dbmInternalHandle *)sHandle.mHandle)->mInstanceName
            );


    rc = dbmPrepareTable (&sHandle, "table0010");
    printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
    if (rc) exit(-1);

#if 1
    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    {
        memcpy(buffer, &i, sizeof(int));
        memcpy(buffer + sizeof(int), &i, sizeof(int));
        rc = dbmInsertRow (&sHandle, "table0010", buffer, 8);
        if (rc)
        {
            printf("insert t1 rc=%d (%s) data[%d]\n", rc, dbmGetError(rc), i);
            break;
        }

        rc = dbmInsertRow (&sHandle, "table0010", buffer, 8);
        if (rc)
        {
            printf("insert t1 rc=%d (%s) data[%d]\n", rc, dbmGetError(rc), i);
            break;
        }

        rc = dbmInsertRow (&sHandle, "table0010", buffer, 8);
        if (rc)
        {
            printf("insert t1 rc=%d (%s) data[%d]\n", rc, dbmGetError(rc), i);
            break;
        }

        rc = dbmCommit (&sHandle);
        if (rc)
        {
            printf("commit t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
            break;
        }

        if (i !=0 && (i % 100000) == 0) printf ("%d rows inserted..\n", i - nStart);
    }
    clock_gettime_s(CLOCK_REALTIME, &end);
    printf("LOOP=%d, i=%d, Elap=%.9f\n", LOOP, i, (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0)));
#endif

#if 0
    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    {
        memcpy(buffer, &i, sizeof(int));
        memcpy(buffer + sizeof(int), &i, sizeof(int));
        rc = dbmSelectRow (&sHandle, "table0010", buffer);
        if (rc)
        {
            printf("select row not found t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
            break;
        }

        if (i !=0 && (i % 100000) == 0) printf ("%d rows select \n", i - nStart);
    }
    clock_gettime_s(CLOCK_REALTIME, &end);
    printf("LOOP=%d, i=%d, Elap=%.9f\n", LOOP, i, (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0)));
#endif

#if 1
    // Delete
    clock_gettime_s(CLOCK_REALTIME,&start);

    printf(" *** [%lu] delete start (%d ~ %d) \n", (unsigned long)pthread_self(), nStart,nEnd);


    for(i=nStart; i<nEnd; i++)
    {
        memset(buffer,0x00,sizeof(buffer));

        memcpy(buffer, &i, sizeof(int));
        memcpy(buffer + sizeof(int), &i, sizeof(int));

        rc = dbmDeleteRow(&sHandle,"table0010",buffer);
        if(rc)
        {
            printf("delete errror [%d][%s] \n", rc, dbmGetError(rc) );
            break;
        }

        rc = dbmCommit(&sHandle);
        if(rc)
        {
            printf("commit erorr [%d][%s] \n",rc, dbmGetError(rc) );
            break;
        }

        if( i%10000 == 0)
            printf("delete loop [%d] \n", i);
    }

    clock_gettime_s(CLOCK_REALTIME,&end);
    printf("elpaed time [%.9f] \n", (double)((end.tv_sec+end.tv_nsec/100000000.0)-(start.tv_sec+start.tv_nsec/100000000.0)));
#endif


    dbmFreeHandle (&sHandle);

    return NULL;
}


void *testSelect1(void *param)
{
    dbmHandle sHandle;
    char      buffer[1024];
    int rc;
    int i;
    int nStart, nEnd, aCount;
    struct timespec start, end;


    nStart = (int)(((PARAM*)param)->start);
    aCount = (int)(((PARAM*)param)->aCount);
    nEnd = nStart + (LOOP / THR);
    printf("start (%d ~ %d)\n", nStart, nEnd);

    rc = dbmInitHandle (&sHandle, "undo0000000500");
    if (rc)
    {
        printf("first initHandle rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }
    printf("initHandle rc=%d (Mark=%lld, Name=%s, trans_id=%d)\n",
            rc, sHandle.mMark
            , ((dbmInternalHandle *)sHandle.mHandle)->mInstanceName
            , ((dbmInternalHandle *)sHandle.mHandle)->mTrans->mGetTransID()
            );


#if 1
    rc = dbmPrepareTable (&sHandle, "table0010");
    printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
    if (rc) exit(-1);

    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    {
//printf("%d select\n", i);
        memcpy(buffer, &i, sizeof(int));
        memcpy(buffer + sizeof(int), &i, sizeof(int));
        rc = dbmSelectRow (&sHandle, "table0010", buffer);
        if (rc)
        {
            printf("select row not found t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
            break;
        }
    }
    clock_gettime_s(CLOCK_REALTIME, &end);
    printf("SELECT LOOP=%d, i=%d, Elap=%.9f\n", LOOP, i, (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0)));
#endif
    dbmFreeHandle (&sHandle);

    return NULL;
}


int main( int argc, char *argv[])
{
    dbmSegmentManager *sMgr;
    pthread_t tid[THR];
    int i, start;
    PARAM  param[THR];
    int rc = 0;
    int fd = -1;

    // 테이블 만들려면 인자를 한개 줘라.
    // 테이블맹글구 꽥.
    if (argc > 1)
    {
        //rc = dbmSegmentManager::Create ("undo0000000500", 256 * 1024, 1000, 1000, 10000, 8192, sLog, &sMgr);
        mCreate();
        printf("create undo rc=%d\n", rc);
        if (rc) exit(-1);
        exit(-1);
    }

#if 1
    // Perf Test
    start = 0;
    for (i=0;i<THR;i++)
    {
        /* start = 0
         * start = 0 + (1000000 /4) --> 250000
         * start = 250000
         * start = 250000 + (1000000/4) --> 500000
         * start = 500000
         * start = 500000 + (1000000/4) --> 750000
         */

        param[i].tid = i;
        param[i].start = start;
        param[i].aCount = argc;
        pthread_create(&tid[i], NULL, test1, &param[i]);
        start = start + (LOOP / THR);
        sleep(1);
    }
    for (i=0;i<THR;i++)
    {
        pthread_join(tid[i], NULL);
    }
#endif

#if 0
    // Perf Test
    start = 0;
    for (i=0;i<THR;i++)
    {
        param[i].start = start;
        param[i].aCount = argc;
        pthread_create(&tid[i], NULL, testSelect1, &param[i]);
        start = start + (LOOP / THR);
    }
    for (i=0;i<THR;i++)
    {
        pthread_join(tid[i], NULL);
    }
#endif


    fd = open("result.data",O_CREAT|O_APPEND|O_RDWR,0775);
    if(fd<=0)
    {
        fprintf(stdout,"file open error \n");
        exit(-1);
    }

    rc = write(fd,"0",1);
    if(rc<0)
    {
        fprintf(stdout,"file write error \n");
        exit(-1);
    }

    close(fd);

}
