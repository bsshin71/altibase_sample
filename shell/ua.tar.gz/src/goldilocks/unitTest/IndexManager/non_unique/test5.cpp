#include "dbmAPI.h"
#include "dbmInternalHandle.h"


typedef struct
{
    int c1;
    int c2;
    int c3;
} TABLE;


#define UNDO_NAME  "lim272_undo"
#define TABLE_NAME "lim272_t1"
#define THR  4
#define LOOP 1000000



typedef struct
{
    int start;
    int aCount;
} PARAM;


void *thr1(void*);
void *thr2(void *);



void *thr1(void *param)
{
    dbmHandle sHandle;
    int rc;
    int i;
    int nStart, nEnd, aCount;
    TABLE  data;
    struct timespec start, end;


    nStart = (int)(((PARAM*)param)->start);
    aCount = (int)(((PARAM*)param)->aCount);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);


    rc = dbmInitHandle (&sHandle, (char*)UNDO_NAME);
    if (rc)
    {
        dbmGetError(rc, dbmGetError(rc) );
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, (char*)TABLE_NAME);
    if (rc)
    {
        dbmGetError(rc, dbmGetError(rc) );
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    {
        memset(&data, 0x00, sizeof(TABLE));
        data.c1 = i;
        data.c2 = 0;
        data.c3 = 0;

        rc = dbmInsertRow (&sHandle, (char*)TABLE_NAME, (char*)&data, sizeof(TABLE));
        if (rc)
        {
            dbmGetError(rc, dbmGetError(rc) );
            printf("Insert (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            exit(-1);
        }

        rc = dbmCommit (&sHandle);
        if (rc)
        {
            dbmGetError(rc, dbmGetError(rc) );
            printf("Commit t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }
#if 0
        if (i !=0 && (i % 10000) == 0) printf ("%d rows inserted..\n", i - nStart);
#endif
    }
    clock_gettime_s(CLOCK_REALTIME, &end);
    printf("LOOP=%d, i=%d, Elap=%.9f\n",
            LOOP, i, (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0)));

    dbmFreeHandle (&sHandle);
    return NULL;
}


void *thr2(void *param)
{
    dbmHandle sHandle;
    int rc;
    int i, j;
    int nStart, nEnd, aCount;
    TABLE  data;
    struct timespec start, end;


    nStart = (int)(((PARAM*)param)->start);
    aCount = (int)(((PARAM*)param)->aCount);
    nEnd = nStart + (LOOP / THR);
    printf("================ [THR:%lu] (start=%d ~ end=%d)\n", (unsigned long)pthread_self(), nStart, nEnd);


    rc = dbmInitHandle (&sHandle, (char*)UNDO_NAME);
    if (rc)
    {
        dbmGetError(rc, dbmGetError(rc) );
        printf("InitHandle fail, rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    rc = dbmPrepareTable (&sHandle, (char*)TABLE_NAME);
    if (rc)
    {
        dbmGetError(rc, dbmGetError(rc) );
        printf("prepare t1 rc=%d (%s)\n", rc, dbmGetError(rc) );
        exit(-1);
    }

    j = 589292;
    clock_gettime_s(CLOCK_REALTIME, &start);
    for (i=nStart; i<nEnd; i++)
    {
        memset(&data, 0x00, sizeof(TABLE));
        data.c1 = j;

        rc = dbmSelectForUpdateRow (&sHandle, (char*)TABLE_NAME, (char*)&data);
        if (rc)
        {
            dbmGetError(rc, dbmGetError(rc) );
            printf("SelectLock. (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            exit(-1);
        }

        data.c2 = data.c2 + 1;
        rc = dbmUpdateRow(&sHandle, (char*)TABLE_NAME, (char*)&data);
        if (rc)
        {
            dbmGetError(rc, dbmGetError(rc) );
            printf("updateFail. (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
            exit(-1);
        }
#if 0
        rc = dbmCommit (&sHandle);
        if (rc)
        {
            dbmGetError(rc, dbmGetError(rc) );
            printf("Commit t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }
#else
        rc = dbmRollback (&sHandle);
        if (rc)
        {
            dbmGetError(rc, dbmGetError(rc) );
            printf("Rollbacl t1 (%d) rc=%d (%s)\n", i, rc, dbmGetError(rc) );
            break;
        }
#endif
#if 0
        if (i !=0 && (i % 10000) == 0) printf ("%d rows inserted..\n", i - nStart);
#endif
    }
    clock_gettime_s(CLOCK_REALTIME, &end);
    printf("LOOP=%d, i=%d, Elap=%.9f\n",
            LOOP, i, (double)((end.tv_sec+end.tv_nsec/1000000000.0)-(start.tv_sec+start.tv_nsec/1000000000.0)));

    memset(&data, 0x00, sizeof(data));
    data.c1 = j;
    rc = dbmSelectRow (&sHandle, (char*)TABLE_NAME, (char*)&data);
    if (rc)
    {
        dbmGetError(rc, dbmGetError(rc) );
        printf("SelectRow. (%s) (row=%d) rc=%d (%s)\n", TABLE_NAME, i, rc, dbmGetError(rc) );
        exit(-1);
    }
    printf("Select Row: c1=%d, c2=%d, c3=%d\n", data.c1, data.c2, data.c3);

    dbmFreeHandle (&sHandle);
    return NULL;
}




int main()
{
    pthread_t tid[THR];
    int i, start;
    PARAM  param[THR];

#if 1
    // Perf Test
    start = 0;
    for (i=0;i<THR;i++)
    {
        param[i].start = start;
        param[i].aCount = 0;
        pthread_create(&tid[i], NULL, thr1, &param[i]);
        start = start + (LOOP / THR);
    }
    for (i=0;i<THR;i++)
    {
        pthread_join(tid[i], NULL);
    }
#endif

#if 1
    // Perf Test
    start = 0;
    for (i=0;i<THR;i++)
    {
        param[i].start = start;
        param[i].aCount = 0;
        pthread_create(&tid[i], NULL, thr2, &param[i]);
        start = start + (LOOP / THR);
    }
    for (i=0;i<THR;i++)
    {
        pthread_join(tid[i], NULL);
    }
#endif

    return 0;
}
