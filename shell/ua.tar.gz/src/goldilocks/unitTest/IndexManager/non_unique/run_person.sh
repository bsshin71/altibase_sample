###############################################################################
# 설명 : 공통
#        환경 Clear
###############################################################################

cfg_clear()
{
    /* 웅이꺼 test1,test3,test4
    test9~test13 */

    rm -f ../pid/*
    rm -f core*

    rm -f $DBM_HOME/dic/*
    rm -f $DBM_HOME/dbm/*anchor
    rm -f ../pid/*
    rm -f core*
    rm -f /dev/shm/$DBM_SHM_PREFIX/trans_test_undo*
    rm -f /dev/shm/$DBM_SHM_PREFIX/*hwson*
    rm -f /dev/shm/$DBM_SHM_PREFIX/*
	rm -f result.data

metaManager << EOF
initdb
create undo undo0000000500;
quit
EOF

}

cfg_clear2()
{
    rm -f ../pid/*
    rm -f core*

    rm -f $DBM_HOME/dic/*
    rm -f $DBM_HOME/dbm/*anchor
    rm -f ../pid/*
    rm -f core*
    rm -f /dev/shm/$DBM_SHM_PREFIX/trans_test_undo*
    rm -f /dev/shm/$DBM_SHM_PREFIX/*hwson*
    rm -f /dev/shm/$DBM_SHM_PREFIX/*
	rm -f result.data
}

cfg_clear3()
{
    /* 웅이꺼 test1,test3,test4
    test9~test13 */

    rm -f ../pid/*
    rm -f core*

    rm -f $DBM_HOME/dic/*
    rm -f $DBM_HOME/dbm/*anchor
    rm -f ../pid/*
    rm -f core*
    rm -f /dev/shm/$DBM_SHM_PREFIX/trans_test_undo*
    rm -f /dev/shm/$DBM_SHM_PREFIX/*hwson*
    rm -f /dev/shm/$DBM_SHM_PREFIX/*
	rm -f result.data

metaManager << EOF
initdb
create undo hwson_undo;
quit
EOF

}

cfg_clear4()
{
    /* 웅이꺼 test1,test3,test4
    test9~test13 */

    rm -f ../pid/*
    rm -f core*

    rm -f $DBM_HOME/dic/*
    rm -f $DBM_HOME/dbm/*anchor
    rm -f ../pid/*
    rm -f core*
    rm -f /dev/shm/$DBM_SHM_PREFIX/trans_test_undo*
    rm -f /dev/shm/$DBM_SHM_PREFIX/*hwson*
    rm -f /dev/shm/$DBM_SHM_PREFIX/*
	rm -f result.data

metaManager << EOF
initdb
create undo undo0000000500 init 400 extend 400 max 4000;
quit
EOF

}

cfg_del()
{
	#make clean; make all
	#make clean;make test_1
	#make clean;make test_1_2
	#make clean;make test3_3
	#make clean;make test3_3_1
	#make clean;make test3_3_3
	#make clean;make test4_4
	cfg_clear
}


cfg_del2()
{
    #make clean;make all
	#make clean;make test9
	#make clean;make test9_9
	#make clean;make test10
	#make clean;make test10_10
	#make clean;make test10_10_1
	#make clean;make test10_10_2
	#make clean;make test11

	cfg_clear2
}

cfg_del3()
{
    #make clean;make all
	#make clean;make test12
	#make clean;make test13
	#make clean;make test14
	#make clean;make test15
	#make clean;make test16
	#make clean;make test17
	#make clean;make test18
	#make clean;make test19
	#make clean;make test20
	#make clean;make test21
	#make clean;make test22
	#make clean;make test23
	#make clean;make test24
	#make clean;make test25
	#make clean;make test26

	cfg_clear3
}


cfg_del4()
{

	cfg_clear4
}




###############################################################################
# 설명 : test_1
#
# 체크 : 정상 리턴값 0 체크
###############################################################################

#. LOOP COUNT
CNT=1
#
#
##. test_1
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test_1 start ##"
#	#.환경 제거
#    cfg_del
#
#    #1. 테이블 Create
#    test_1 123
#
#    #2. execute
#    test_1
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test_1 success [$CNT]!!!"
#    else
#    	echo "test_1 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#
#done

#. test_1_2
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test_1_2 start ##"
#
#	#.환경 제거
#    cfg_del
#
#    #1. 테이블 Create
#    test_1_2 123
#
#    #2. execute
#    test_1_2
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test_1_2 success [$CNT]!!!"
#    else
#    	echo "test_1_2 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#
#done

#. test3_3
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test3_3 start ##"
#
#	#.환경 제거
#    cfg_del
#
#    #1. 테이블 Create
#    test3_3 123
#
#    #2. execute
#    test3_3
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test3_3 success [$CNT]!!!"
#    else
#    	echo "test3_3 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#done

#. test3_3_1
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test3_3_1 start ##"
#
#	#.환경 제거
#    cfg_del
#
#    #1. 테이블 Create
#    test3_3_1 123
#
#    #2. execute
#    test3_3_1
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test3_3_1 success [$CNT]!!!"
#    else
#    	echo "test3_3_1 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#done

#. test3_3_3
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test3_3_3 start ##"
#
#	#.환경 제거
#    cfg_del
#
#    #1. 테이블 Create
#    test3_3_3 123
#
#    #2. execute
#    test3_3_3
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test3_3_3 success [$CNT]!!!"
#    else
#    	echo "test3_3_3 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#done

#. test4_4
# 동시성 문제 관련 동표형과 아직 협의 되지 않았다. 어디가 문제인지 모름.
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test4_4 start ##"
#
#	#.환경 제거
#    cfg_del
#
#    #1. 테이블 Create
#    test4_4 123
#
#    #2. execute
#    test4_4
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test4_4 success [$CNT]!!!"
#    else
#    	echo "test4_4 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#done

#. test9 (select row gt,lt (c1,c2) test)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test9 start ##"
#
#	#.환경 제거
#    cfg_del2
#
#    #. table create
#metaManager << EOF
#initdb
#create undo undo0000000500;
#drop table hwson_t1;
#create table hwson_t1
#c1 char 20 0
#c2 int 10 0
#c3 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create non unique index hwson_idx_t1 on hwson_t1 c1 c2;
#list
#quit
#EOF
#    #1. execute
#    test9
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test9 success [$CNT]!!!"
#    else
#    	echo "test9 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#done


#. test9_9 (select row gt,lt (c1,c2,c3) test)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test9_9 start ##"
#
#	#.환경 제거
#    cfg_del2
#
#    #. table create
#metaManager << EOF
#initdb
#create undo undo0000000500;
#drop table hwson_t1;
#create table hwson_t1
#c1 char 20 0
#c2 int 10 0
#c3 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create non unique index hwson_idx_t1 on hwson_t1 c1 c2 c3;
#list
#quit
#EOF
#    #1. execute
#    test9_9
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test9_9 success [$CNT]!!!"
#    else
#    	echo "test9_9 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#done

#. test10 (select row gt,lt (c1 integer) test)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test10 start ##"
#
#	#.환경 제거
#    cfg_del2
#
#    #. table create
#metaManager << EOF
#initdb
#create undo undo0000000500 init 400 extend 400 max 10000;
#drop table hwson_t1;
#create table hwson_t1
#c1 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create non unique index hwson_idx_t1 on hwson_t1 c1;
#list
#exit
#EOF
#    #1. execute
#    test10
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test10 success [$CNT]!!!"
#    else
#    	echo "test10 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#done

#. test10_10 (select row gt,lt (c1 integer) 검증 test)
#. 현재 delete 동시성 문제로 동표님 검증하고 있음. 테스트 불가.
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test10_10 start ##"
#
#	#.환경 제거
#    cfg_del2
#
#    #. table create
#metaManager << EOF
#initdb
#create undo undo0000000500 init 400 extend 400 max 10000;
#drop table hwson_t1;
#create table hwson_t1
#c1 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create non unique index hwson_idx_t1 on hwson_t1 c1;
#list
#exit
#EOF
#    #1. execute
#    test10_10
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test10_10 success [$CNT]!!!"
#    else
#    	echo "test10_10 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#done


#. test10_10_1 (select row gt,lt (c1,c2,c3 integer) 검증 test)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test10_10_1 start ##"
#
#	#.환경 제거
#    cfg_del2
#
#    #. table create
#metaManager << EOF
#initdb
#create undo undo0000000500;
#drop table hwson_t1;
#create table hwson_t1
#c1 char 20 0
#c2 int 10 0
#c3 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create non unique index hwson_idx_t1 on hwson_t1 c1,c2,c3;
#list
#exit
#EOF
#
#    #1. execute
#    test10_10_1
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test10_10_1 success [$CNT]!!!"
#    else
#    	echo "test10_10_1 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#done

#. test10_10_2 (select row gt,lt (c1 integer) 검증 test)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test10_10_2 start ##"
#
#	#.환경 제거
#    cfg_del2
#
#    #. table create
#metaManager << EOF
#initdb
#create undo undo0000000500 init 400 extend 400 max 10000;
#drop table hwson_t1;
#create table hwson_t1
#c1 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create non unique index hwson_idx_t1 on hwson_t1 c1;
#list
#exit
#EOF
#    #1. execute
#    test10_10_2
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test10_10_2 success [$CNT]!!!"
#    else
#    	echo "test10_10_2 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#done

#. test11 (하나의 트랜잭션에서 insert select selectrowgt lt 처리)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test11 start ##"
#
#	#.환경 제거
#    cfg_del2

##. table create
##echo "
##initdb
##create undo undo0000000500;
##drop table hwson_t1;
##create table hwson_t1
##c1 char 20 0
##c2 int 10 0
##c3 int 10 0
##init 10000000 extend 3000000 max 11000000;
##create non unique index hwson_idx_t1 on hwson_t1 c2;
##list
##exit
##" > .mm.sql
##	metaManager -f .mm.sql
#metaManager << EOF
#initdb
#create undo undo0000000500;
#drop table hwson_t1;
#create table hwson_t1
#c1 char 20 0
#c2 int 10 0
#c3 int 10 0
#init 10000000 extend 3000000 max 11000000;
#create non unique index hwson_idx_t1 on hwson_t1 c2;
#list
#exit
#EOF
#    #1. execute
#    test11
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test11 success [$CNT]!!!"
#    else
#    	echo "test11 Failure !!![$RESULT]"
#    	exit
#    fi
#
#	CNT=`expr $CNT - 1`
#done

#. test12
# insert select process
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test12 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test12
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test12 success [$CNT]!!!"
#    else
#    	echo "test12 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test13
# insert select & delete 단위 테스트 process(key int)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test13 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test13
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test13 success [$CNT]!!!"
#    else
#    	echo "test13 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test14
# insert select 단위 테스트 process(key int,char)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test14 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test14
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test14 success [$CNT]!!!"
#    else
#    	echo "test14 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test15
# insert select & delete 단위 테스트 process(key int,char)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test15 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test15
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test15 success [$CNT]!!!"
#    else
#    	echo "test15 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test16
# insert select & delete 단위 테스트 process(key int,char)
# commit 단위를 트랜잭션 %10으로 commit 처리 테스트
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test16 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test16
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test16 success [$CNT]!!!"
#    else
#    	echo "test16 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test17
# insert select 단위 테스트 process(key char,char)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test17 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test17
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test17 success [$CNT]!!!"
#    else
#    	echo "test17 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test18
# insert select & delete 단위 테스트 process(key char,char)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test18 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test18
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test18 success [$CNT]!!!"
#    else
#    	echo "test18 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test19
# insert select 단위 테스트 process(key char)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test19 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test19
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test19 success [$CNT]!!!"
#    else
#    	echo "test19 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test20
# insert select & delete 단위 테스트 process(key char)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test20 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test20
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test20 success [$CNT]!!!"
#    else
#    	echo "test20 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test21
# insert select 단위 테스트 process(key int,int)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test21 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test21
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test21 success [$CNT]!!!"
#    else
#    	echo "test21 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test22
# insert select & delete 단위 테스트 process(key int,int)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test22 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test22
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test22 success [$CNT]!!!"
#    else
#    	echo "test22 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test23
# insert insert & selectLT 단위 테스트 process(key int)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test23 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test23
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test23 success [$CNT]!!!"
#    else
#    	echo "test23 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test24
# insert insert & selectLT  & selectGT 단위 테스트 process(key int)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test24 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test24
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test24 success [$CNT]!!!"
#    else
#    	echo "test24 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test25
# insert insert 단위 테스트 process(key char,int)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test25 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test25
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test25 success [$CNT]!!!"
#    else
#    	echo "test25 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test26
# insert insert 단위 테스트 process(key char,int)
#while [ "$CNT" -gt 0 ];
#do
#	echo "## test26 start ##"
#
#	#.환경 제거
#    cfg_del3
#
#    #1. execute
#    test26
#
#    #3. check value diff
#    RESULT=`cat result.data`
#
#    if [ "$RESULT" == "0" ]
#    then
#    	echo "test26 success [$CNT]!!!"
#    else
#    	echo "test26 Failure !!![$RESULT]"
#    	exit
#    fi
#
#    CNT=`expr $CNT - 1`
#done

#. test27
# insert insert 단위 테스트 process(key char,int)
# Bulck성 commit 테스트
while [ "$CNT" -gt 0 ];
do
	echo "## test_27 start ##"
	#.환경 제거
    cfg_del4

    #1. 테이블 Create
    test27 123

    #2. execute
    test27

    #3. check value diff
    RESULT=`cat result.data`

    if [ "$RESULT" == "0" ]
    then
    	echo "test_27 success [$CNT]!!!"
    else
    	echo "test_27 Failure !!![$RESULT]"
    	exit
    fi

	CNT=`expr $CNT - 1`

done
