#include "cmnApi.h"
#include "dbmAPI.h"

/*
 개별 Delete Test 검증하는 프로그램이다
 */

#define TEST_COUNT  300000

PHTIMER timer;

typedef struct user_struct
{
    int  c1;
    char c2[596];
}user_struct;

void my_error(const char * name, int rc)
{
    if (rc != 0)
    {
        printf("%s fail:[%d]\n", name, rc);
        exit(-1);
    }
}

int main( int argc, char *argv[])
{
    dbmHandle sHandle;
    user_struct data;
    int i,rc;
    char table_name[16];
    char undo_name[16];
    char sql[1024];
    int test_count;


    if( argc < 2 )
    {
        printf("Usage : %s [test_count]\n", argv[0]);
        exit(0);
    }

    test_count = atoi(argv[1]);

    memset(undo_name, 0x00, sizeof(undo_name));
    memset(table_name, 0x00, sizeof(table_name));
    memset(sql, 0x00, sizeof(sql));

    strcpy(table_name, "hwson");   /* 요것만 이름 바꾸어서 사용할 것 */


    /*
     * 준비 작업 (dbmInitHandle, dbmExecuteDDL (table, index), dbmPrepareTable)
     */
    sprintf(undo_name, "%s_undo", table_name);
    rc = dbmInitHandle(&sHandle, (char *)undo_name);
    my_error("init handle", rc);

    sprintf(sql, "create table %s \n"
                  "c1 int 10 0 \n"
                  "c2 char 596 0\n"
                  "init 500000 extend 500000 max 11000000\n", table_name);

    rc = dbmExecuteDDL (&sHandle, sql);
    my_error("create table", rc);

    memset(sql, 0x00, sizeof(sql));

    sprintf(sql, "create index idx_%s on %s c1\n", table_name, table_name);

    rc = dbmExecuteDDL (&sHandle, sql);
    my_error("create index", rc);

    rc = dbmPrepareTable(&sHandle, table_name);
    my_error("prepare table", rc);


    /*
     * insert
     */
    memset(&data, 0x00, sizeof(data));
    strcpy(data.c2, "33333");

    rc = cmnInitTimer(&timer, UNIT_NANO, 500, 500, 20 );

#if 0 //test1
    data.c1 = 1;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 2;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 3;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 4;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 5;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 6;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test2
    data.c1 = 1;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 2;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 3;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 4;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 5;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 6;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 7;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 8;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 9;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 10;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 11;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 12;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 13;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test3
    data.c1 = 1;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 2;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 3;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 4;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 5;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = 2;
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test4
    data.c1 = 1;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 2;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 3;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 4;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 5;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 6;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 7;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    data.c1 = 8;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test5
    data.c1 = 1;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 2;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 3;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 4;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 5;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 6;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 7;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 8;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 9;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 10;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 11;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 12;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 13;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 14;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 15;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 16;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 17;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 18;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 19;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 20;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test6  right sibling 01.14 example14 delete 1x
    data.c1 = 1;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 2;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 3;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 4;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 5;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 6;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 7;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 8;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 9;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 10;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 11;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 12;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 13;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif


#if 0 //test 7 right sibling 01.14 example15 delete 1x
    for(i=1; i<16;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test9 left sibling 01.15 example3-1 delete 13
    // 15 delete
    for(i=1;i<9;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char*)&data,600);
        my_error("insert ",rc);
    }

    data.c1 = 11;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 12;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 13;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 9;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 10;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = 12;
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);


    printf("delete ok \n");
#endif

#if 0 //test10 left sibling 01.15 example16 delete 15 DEGREE 10
    data.c1 = 1;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 2;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 3;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 4;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 10;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 11;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 12;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 13;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 14;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 15;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 5;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 6;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 7;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 8;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 9;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = 14;
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = 13;
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);




    printf("delete ok \n");
#endif

#if 0 //test11 left sibling 01.15 example4-1 delete 11 DEGREE 5
    for(i=1; i<12;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = 10;
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);


    printf("delete ok \n");
#endif

#if 0 //test12 left sibling 01.15 example17 delete 5 DEGREE 5
    for(i=1; i<6;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = 4;
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test13 left sibling 01.15 example18 delete 6 DEGREE 5
    for(i=1; i<8;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = 6;
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test14 left sibling 01.16 example19 delete 13 DEGREE 5
    for(i=1; i<14;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = 12;
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test15 left sibling 01.16 example20 delete 16 DEGREE 5
    for(i=1; i<7;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    for(i=10; i<17;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    data.c1 = 7;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 8;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 9;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);


    data.c1 =  15;
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);


    printf("delete ok \n");
#endif

#if 0 //test16 left sibling 01.16 example5-1 delete 4 DEGREE 5
    for(i=1; i<8;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = 5;
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);


    printf("delete ok \n");
#endif

#if 0 //test17 left sibling 01.16 example6-1 delete 5 DEGREE 5
    for(i=1; i<8;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test18 left sibling 01.16 example7-1 delete 4 DEGREE 5
    for(i=1; i<10;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test18 left sibling 01.16 example8-1 delete 11 DEGREE 5
    for(i=1; i<9;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    data.c1 = 11;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 12;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 13;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 9;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 10;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test19 left sibling 01.17 example9-1 delete 19 DEGREE 5
    for(i=1; i<20;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);


    data.c1 = 18;
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test20 left sibling 01.17 example21 delete 7 DEGREE 5
    for(i=1; i<12;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test21 left sibling 01.20 example10-1 delete 7 DEGREE 5
    for(i=1; i<20;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test22 left sibling 01.21 example10-2 delete 13 DEGREE 5
    for(i=1; i<20;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test23 left sibling 01.21 example21 delete 7 DEGREE 5
    for(i=1; i<12;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 0 //test24 left sibling 01.21 example22 delete 7 DEGREE 5
    for(i=1; i<15;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif

#if 1 //test25 left sibling 01.21 example23 delete 7 DEGREE 5
    for(i=1; i<9;i++)
    {
        data.c1 = i;
        rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
        my_error("insert ",rc);
    }

    data.c1 = 11;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 12;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 13;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 9;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    data.c1 = 10;
    rc = dbmInsertRow(&sHandle,table_name,(char *)&data,600);
    my_error("insert ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    data.c1 = atoi(argv[1]);
    rc = dbmDeleteRow(&sHandle,table_name,(char *)&data);
    my_error("delete ",rc);

    rc = dbmCommit(&sHandle);
    my_error("commit ",rc);

    printf("delete ok \n");
#endif
    sprintf(sql, "drop table %s\n", table_name);

    rc = dbmExecuteDDL (&sHandle, sql);
    my_error("drop table", rc);

/*
    sprintf(sql, "drop index idx_%s\n", table_name);

    rc = dbmExecuteDDL (&sHandle, sql);
    my_error("drop index", rc);
*/

    printf("ok. end...\n");
}
