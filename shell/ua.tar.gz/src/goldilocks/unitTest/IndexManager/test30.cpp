#include "dbmHeader.h"
#include "order.h"

/************************************************
 * 한 쓰레드당 25만건씩 주문처리를 한다.
************************************************/
#define LOOP 250000
#define THR  4


void DError(int, dbmHandle*);
void *ORDER(void*);
void initEnv();


typedef struct
{
    int    start;
    double tps;
} PARAM;



/************************************************
 * DBM 에러가 발생하는지 체크한다.
************************************************/
void DError(int rc, dbmHandle *aHandle)
{
    if (rc == 0) return;

    printf("DERROR:: rc =%d, error=%s\n", rc, dbmGetError(rc) );

    dbmRollback(aHandle);
    exit(-1);
}




/************************************************
 * 주문처리를 위한 계좌, 종목 정보를 간단히 초기화한다.
************************************************/
void initEnv()
{
    dbmHandle Handle;
    item      Item;
    ordno     Ordno;
    accnt     Accnt;
    int rc;
    int rz;
    int i;

    rc = dbmInitHandle(&Handle, "lim272_undo");
    DError(rc, &Handle);

    dbmTruncate(&Handle, "item");
    dbmTruncate(&Handle, "accnt");
    dbmTruncate(&Handle, "ordno");
    dbmTruncate(&Handle, "order");

    rc = dbmPrepareTable(&Handle, "item");
    DError(rc, &Handle);

    rc = dbmPrepareTable(&Handle, "accnt");
    DError(rc, &Handle);

    for (i=0; i<10000; i++)
    {
       memset(&Item, 0x00, sizeof(Item));
       sprintf(Item.itemcd, "%08d", i);
       sprintf(Item.itemnm, "%08d", i);
       Item.highprc = 10000;
       Item.lowprc  = 1;
       Item.smaxprc = 10000;
       Item.minprc  = 1;
       Item.currprc = 10000;
       Item.trdqty  = 0;
       Item.trdamt  = 0;

       rc = dbmInsertRow(&Handle, "item", (char*)&Item, sizeof(Item));
       DError(rc, &Handle);

       memset(&Accnt, 0x00, sizeof(Accnt));
       sprintf(Accnt.accntno, "%08d", i);
       sprintf(Accnt.accntnm, "NAME%08d", i);
       Accnt.ablemoney = (long long)100000000L;
       Accnt.unsettle  = (long long)0;

       rc = dbmInsertRow(&Handle, "accnt", (char*)&Accnt, sizeof(Accnt));
       DError(rc, &Handle);

       rc = dbmCommit(&Handle);
       DError(rc, &Handle);
    }

    rc = dbmPrepareTable(&Handle, "ordno");
    DError(rc, &Handle);

    sprintf(Ordno.brcd, "001");
    Ordno.ordno = 0;
    rc = dbmInsertRow(&Handle, "ordno", (char*)&Ordno, sizeof(Ordno));
    DError(rc, &Handle);

    sprintf(Ordno.brcd, "002");
    Ordno.ordno = 0;
    rc = dbmInsertRow(&Handle, "ordno", (char*)&Ordno, sizeof(Ordno));
    DError(rc, &Handle);

    sprintf(Ordno.brcd, "003");
    Ordno.ordno = 0;
    rc = dbmInsertRow(&Handle, "ordno", (char*)&Ordno, sizeof(Ordno));
    DError(rc, &Handle);

    sprintf(Ordno.brcd, "004");
    Ordno.ordno = 0;
    rc = dbmInsertRow(&Handle, "ordno", (char*)&Ordno, sizeof(Ordno));
    DError(rc, &Handle);

    rc = dbmCommit(&Handle);
    DError(rc, &Handle);

    dbmFreeHandle(&Handle);

}




/************************************************
 * 실제 주문을 처리하는 쓰레드 함수 부분이다.
************************************************/
void *ORDER(void *param)
{
    dbmHandle Handle;
    int i, rz, rc, k;
    accnt   Accnt;
    item    Item;
    ordno   Ordno;
    order   Order;
    double  sum = 0.0;
    struct timespec start, end;

    dbmInitHandle(&Handle, "lim272_undo");

    rc = dbmPrepareTable(&Handle, "item");
    DError(rc, &Handle);

    rc = dbmPrepareTable(&Handle, "accnt");
    DError(rc, &Handle);

    rc = dbmPrepareTable(&Handle, "ordno");
    DError(rc, &Handle);

    rc = dbmPrepareTable(&Handle, "order");
    DError(rc, &Handle);

    for (i=0; i<LOOP; i++)
    {
    clock_gettime_s(CLOCK_REALTIME, &start);
        /* 계좌, 주문종목 만들기 */
        sprintf(Order.accntno, "%08d", i%3000);
        sprintf(Order.itemcd,   "%08d", i%3000);
        Order.ordqty = i + 1;
        Order.ordprc = i + 1;

        /* 계좌 체크 */
        memset(&Accnt, 0x00, sizeof(Accnt));
        memcpy(Accnt.accntno, Order.accntno, sizeof(Order.accntno));
        rc = dbmSelectForUpdateRow(&Handle, "accnt", (char*)&Accnt);
        if (rc)
        {
            printf("dbmSelectRow:accnt [%d, %s] [%8.8s]\n", rc, dbmGetError(rc), Accnt.accntno);
            exit(-1);
        }
        if (Accnt.ablemoney <= 0)
        {
            printf("This Account has no money to order. [%lld]\n", Accnt.ablemoney);
            break;
        }

        /* 종목 체크: 한 10번쯤 요런 비슷한 테이블Select를 한다고 가정한다.  */
        for (k=0; k<1; k++)
        {
            memcpy(Item.itemcd, Order.itemcd, sizeof(Order.itemcd));
            rc = dbmSelectRow(&Handle, "item", (char*)&Item);
            if (rc)
            {
                printf("dbmSelectRow:item [%d, %s]\n", rc, dbmGetError(rc) );
                exit(-1);
            }
        }
        if (Order.ordprc > (Item.smaxprc + i))
        {
            printf("This Order prices is greater than max price of item.\n");
            break;
        }
        if (Order.ordprc < Item.minprc)
        {
            printf("This Order prices is lower than min price of item.\n");
            break;
        }

        /* 채번 : 동일지점으로 채번을 하도록 하여 병목을 여기에 몰리게 한다.     */
        memset(&Ordno, 0x00, sizeof(Ordno));
        sprintf(Ordno.brcd, "001");
        rc = dbmSelectForUpdateRow(&Handle, "ordno", (char*)&Ordno);
        if (rc)
        {
            exit(-1);
        }

        Ordno.ordno = Ordno.ordno + 1;
        rc = dbmUpdateRow(&Handle, "ordno", (char*)&Ordno);
        if (rc)
        {
            printf("dbmUpdateRow:ordNo [%d, %s]\n", rc, dbmGetError(rc) );
	    dbmRollback(&Handle);
            break;
        }

        /* 계좌 잔고 update */
        Accnt.unsettle = Accnt.unsettle + i;
        rc = dbmUpdateRow(&Handle, "accnt", (char*)&Accnt);
        if (rc)
        {
            printf("dbmUpdateRow:accnt [%d, %s]\n", rc, dbmGetError(rc) );
	    dbmRollback(&Handle);
            break;
        }


        /* 주문내역 삽입 */
        Order.ordno = Ordno.ordno;
        rc = dbmInsertRow(&Handle, "order", (char*)&Order, sizeof(Order));
        if (rc)
        {
            printf("error=%d, %s\n", rc, dbmGetError(rc) );
            exit(-1);
        }

        rc = dbmCommit(&Handle);
        if (rc)
        {
            printf("dbmCommit: [%d, %s]\n", rc, dbmGetError(rc) );
            break;
        }
    clock_gettime_s(CLOCK_REALTIME, &end);
    sum = sum + (end.tv_sec + end.tv_nsec/1000000000.0) - (start.tv_sec + start.tv_nsec/1000000000.0);
    //usleep(200);
    }
    dbmFreeHandle(&Handle);

    printf("ElapsedTime [%.9f], Average [%.9f]\n", sum, sum/LOOP);
    ((PARAM*)param)->tps = sum/LOOP;
}


main(int argc, char *argv[])
{
    int i;
    double sum = 0;
    pthread_t tid[40];
    PARAM     param[THR];


    if (argc == 2)
    {
        initEnv();
    }

    printf("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\n");
    for (i=0; i<THR; i++)
    {
        param[i].tps = 0;
        pthread_create(&tid[i], NULL, ORDER, &param[i]);
    }

    for (i=0; i<THR; i++)
    {
        pthread_join(tid[i], NULL);
    }

    for (i=0; i<THR; i++)
    {
        sum = sum + param[i].tps;
    }

    printf("Sum: %.6f,  Average : %.9f\n", sum/THR, (double)(sum/THR/(THR*LOOP)) );
}



