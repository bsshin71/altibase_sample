
#include "dbmHeader.h"

void testConfigManager( )
{
    dbmConfig sConf;
    char sVal[1024];
    int  rc;

    rc = sConf.mLoad( "COMMON" );
    printf( "mLoad rc = %d\n", rc );

    rc = sConf.mLoad( "fhan" );
    printf( "mLoad rc = %d\n", rc );

    rc = sConf.mLoad( "test" );
    printf( "mLoad rc = %d\n", rc );

    sConf.mPrintAll();
#if 0
    rc = sConf.mSearch( "sys", "DISK_LOG_DIR", sVal );
    printf( "mSearc rc = %d, sys_log_dir=[%s]\n", rc, sVal );

    rc = sConf.mSearch( "COMMON", "DBM_INSTANCE", sVal );
    printf( "mSearc rc = %d, UNDO=[%s]\n", rc, sVal );

    rc = sConf.mSearch( "COMMON", "DISK_LOG_DIR", sVal );
    printf( "mSearc rc = %d, LOG_DIR=[%s]\n", rc, sVal );

#endif
    rc = sConf.mSearch( "fhan", "TRACE_LOG_DIR", sVal );
    printf( "mSearc rc = %d, TRACE_LOG_DIR( fhan)=[%s]\n", rc, sVal );

    rc = sConf.mSearch( "test", "TRACE_LOG_DIR", sVal );
    printf( "mSearc rc = %d, TRACE_LOG_DIR( test)=[%s]\n", rc, sVal );
#if 0

    rc = sConf.mSearch( "lim272", "DISK_LOG_ENABLE", sVal );
    printf( "mSearc rc = %d, DISK_LOG_ENABLE (lim272)=[%s]\n", rc, sVal );
#endif
}



int main( )
{
    testConfigManager();
}
