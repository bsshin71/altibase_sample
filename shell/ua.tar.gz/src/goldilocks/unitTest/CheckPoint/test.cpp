#include "dbmHeader.h"

#define UNDO_NAME "lim272"


void test1( )
{
    dbmDiskLogManager   *sDisk;
    dbmAnchorManager    *sAnchor;
    char                sFileName[8192];
    int                 rc, i;
    char                *sData;
    dbmDiskLogHeader    *sHeader;
    dbmDiskLogPiece     *sLog;
    dbmCheckPoint       sCkpt;

    // 최초 열기
    sAnchor = new dbmAnchorManager ( );
    rc = sAnchor->mInitialize( UNDO_NAME );
    rc = sAnchor->mCreateAnchor( UNDO_NAME);
    printf( "mCreateAnchor rc=%d\n", rc );
    //if ( rc ) exit( -1 );
    //
    sDisk = new dbmDiskLogManager( );
    rc = sDisk->mInitialize (UNDO_NAME, DBM_CKPT_ONLY);
    printf( "mInitDisk rc=%d\n", rc);

    sAnchor->mSetAnchor(DBM_CKPT_ONLY);
    sAnchor->mTestRewind();

    rc = sCkpt.mInitialize (UNDO_NAME);
    if (rc) { printf("init failed rc=%d\n", rc); exit(-1); }

    while (1)
    {
        rc = sAnchor->mGetTaskForCkpt(sFileName);
        //printf("Wakeup [%s]\n", sFileName);

        i = 0;
        while (1)
        {
            if (i == 0)
            {
                rc = sDisk->mReadFirst (sFileName, &sData);
            }
            else
            {
                rc = sDisk->mReadNext (&sData);
            }
            sHeader = (dbmDiskLogHeader *)sData;
            printf("readFirst rc = %d, Header TotalSize=%d, TimeVal(%ld,%ld)\n",
                     rc, sHeader->mTotalSize, sHeader->mWriteTime.tv_sec, sHeader->mWriteTime.tv_usec);
            if (rc == 0)
            {
                rc = sCkpt.mGetFirstPiece (sData, &sLog);
                //printf("First Size=%d, SCN=%ld\n", sLog->mSize, sLog->mSCN);
                while (rc == RC_SUCCESS)
                {
                    rc = sCkpt.mWriteData (sLog);
                    if (rc)
                    {
                        printf("write fail rc=%d (sLog->offset)=(%d)\n", rc,
                                                  sLog->mOffset);
                        exit(-1);
                    }
                    rc = sCkpt.mGetNextPiece (sData, &sLog);
                    if (rc == RC_FAILURE) break;
                    //printf("Next rc=%d, Size=%d, SCN=%ld\n", rc, sLog->mSize, sLog->mSCN);
                }
            }
            else break;
            i++;
        }
        rc = sCkpt.mSyncDataFile();
        printf("Sync rc=%d\n", rc);

        rc = sAnchor->mCommitTaskForCkpt(sFileName);
        printf("CONF::CommitTask rc=%d, Wakeup [%s], Read Log=%d\n", rc, sFileName, i);
    }

    delete sAnchor;
}


void test2( )
{
    dbmDiskLogManager   *sDisk;
    dbmAnchorManager    *sAnchor;
    int                 rc;
    dbmCheckPoint       sCkpt;

    // 최초 열기
    sAnchor = new dbmAnchorManager ( );
    rc = sAnchor->mInitialize( UNDO_NAME );
    rc = sAnchor->mCreateAnchor( UNDO_NAME );
    printf( "mCreateAnchor rc=%d\n", rc );
    //if ( rc ) exit( -1 );
    sDisk = new dbmDiskLogManager( );
    rc = sDisk->mInitialize (UNDO_NAME, DBM_CKPT_ONLY);
    printf( "mInitDisk rc=%d\n", rc);

    sAnchor->mSetAnchor(DBM_CKPT_ONLY);
    sAnchor->mTestRewind();

    rc = sCkpt.mInitialize (UNDO_NAME);
    if (rc) { printf("init failed rc=%d\n", rc); exit(-1); }


    rc = sCkpt.mRestartRecovery (UNDO_NAME);
    if (rc) { printf("restart recovery failed rc=%d\n", rc); exit(-1); }
}




int main( )
{
    test1();
    //test2();
}
