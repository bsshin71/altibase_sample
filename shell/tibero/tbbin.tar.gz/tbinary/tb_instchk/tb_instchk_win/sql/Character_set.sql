SET FEEDBACK OFF
SET HEADING OFF

select value from _dd_props where name='NLS_CHARACTERSET';

exit