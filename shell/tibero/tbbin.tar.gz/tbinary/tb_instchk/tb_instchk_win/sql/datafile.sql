SET FEEDBACK OFF
SET HEADING OFF

select name from v$datafile;

exit