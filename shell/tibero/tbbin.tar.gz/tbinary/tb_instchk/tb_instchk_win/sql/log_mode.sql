SET FEEDBACK OFF
SET HEADING OFF

select log_mode from v$database;

exit