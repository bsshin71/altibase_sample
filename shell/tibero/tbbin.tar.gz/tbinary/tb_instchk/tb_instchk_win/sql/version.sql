SET FEEDBACK OFF


select * from v$version;

exit