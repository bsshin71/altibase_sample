SET FEEDBACK OFF
SET HEADING OFF

select name from v$database;

exit