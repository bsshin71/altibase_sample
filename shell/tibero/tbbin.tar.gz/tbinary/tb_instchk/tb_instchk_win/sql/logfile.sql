SET FEEDBACK OFF
SET HEADING OFF

select member from v$logfile;

exit