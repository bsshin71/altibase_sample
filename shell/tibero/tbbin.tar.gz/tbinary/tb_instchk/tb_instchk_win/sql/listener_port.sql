SET FEEDBACK OFF
SET HEADING OFF

col value FOR a7

select value from _vt_parameter where name='LISTENER_PORT';

exit