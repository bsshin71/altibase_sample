SET FEEDBACK OFF

select file_name from dba_data_files;

exit