#!/bin/ksh
su - tibero -c "tbdown abort"
exit 
