column sql_id format a25
