CREATE DATABASE DBPJSS
USER SYS IDENTIFIED BY TIBERO
CHARACTER SET UTF8
LOGFILE GROUP 0 ('/tibero_data01/redo/redo01.redo','/tibero_data02/redo/redo02.redo') SIZE 1024M,
        GROUP 1 ('/tibero_data01/redo/redo11.redo','/tibero_data02/redo/redo12.redo') SIZE 1024M,
        GROUP 2 ('/tibero_data01/redo/redo21.redo','/tibero_data02/redo/redo22.redo') SIZE 1024M,
        GROUP 3 ('/tibero_data01/redo/redo31.redo','/tibero_data02/redo/redo32.redo') SIZE 1024M,
        GROUP 4 ('/tibero_data01/redo/redo41.redo','/tibero_data02/redo/redo42.redo') SIZE 1024M
maxdatafiles 10240
maxlogfiles 100
maxlogmembers 8
noarchivelog
DATAFILE '/tibero_data01/system/system01.dtf' SIZE 1G autoextend off 
DEFAULT TABLESPACE USR
DATAFILE '/tibero_data01/system/usr01.dtf' SIZE 1G autoextend off 
DEFAULT TEMPORARY TABLESPACE TEMP
TEMPFILE '/tibero_data01/system/temp01.dtf' SIZE 32G  autoextend off 
        ,'/tibero_data02/system/temp02.dtf' SIZE 32G  autoextend off 
        ,'/tibero_data01/system/temp03.dtf' SIZE 32G  autoextend off 
        ,'/tibero_data02/system/temp04.dtf' SIZE 32G  autoextend off 
        ,'/tibero_data01/system/temp05.dtf' SIZE 32G  autoextend off 
        ,'/tibero_data02/system/temp06.dtf' SIZE 32G  autoextend off 
EXTENT MANAGEMENT LOCAL AUTOALLOCATE
UNDO TABLESPACE UNDO0
DATAFILE '/tibero_data01/system/undo001.dtf' SIZE 32G autoextend off 
        ,'/tibero_data02/system/undo002.dtf' SIZE 32G autoextend off
EXTENT MANAGEMENT LOCAL AUTOALLOCATE;

