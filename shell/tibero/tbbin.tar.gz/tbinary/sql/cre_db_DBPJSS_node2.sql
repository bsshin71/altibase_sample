create undo tablespace UNDO1
DATAFILE '/tibero_data01/system/undo101.dtf' SIZE 32G autoextend off 
        ,'/tibero_data02/system/undo102.dtf' SIZE 32G autoextend off
EXTENT MANAGEMENT LOCAL AUTOALLOCATE
;

alter database add logfile thread 1 group 5 ('/tibero_data01/redo/redo51.redo','/tibero_data02/redo/redo52.redo') SIZE 1024M ;
alter database add logfile thread 1 group 6 ('/tibero_data01/redo/redo61.redo','/tibero_data02/redo/redo62.redo') SIZE 1024M ;
alter database add logfile thread 1 group 7 ('/tibero_data01/redo/redo71.redo','/tibero_data02/redo/redo72.redo') SIZE 1024M ;
alter database add logfile thread 1 group 8 ('/tibero_data01/redo/redo81.redo','/tibero_data02/redo/redo82.redo') SIZE 1024M ;
alter database add logfile thread 1 group 9 ('/tibero_data01/redo/redo91.redo','/tibero_data02/redo/redo92.redo') SIZE 1024M ;

alter database enable public thread 1 ;

